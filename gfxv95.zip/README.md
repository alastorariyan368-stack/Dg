# GfxV70 — Full Stack Platform

A complete marketplace + tools platform built with **Next.js 15**, **Prisma**, **PostgreSQL**, and **Socket.IO**.

---

## 🚀 Quick Start (Fully Automatic)

### 1. Clone & Install

```bash
git clone <your-repo>
cd gfxv70
npm install
```

### 2. Configure `.env`

```env
DATABASE_URL=postgresql://user:pass@host:port/dbname
NEXTAUTH_SECRET=your-secret-here
NEXTAUTH_URL=https://yourdomain.com
NEXT_PUBLIC_APP_URL=https://yourdomain.com

PORT=5000
SMTP_PORT=25
```

> **That's it.** Everything else is automatic on first run.

### 3. Run

```bash
# Development
npm run custom-dev

# Production
npm run custom-start
```

---

## ✅ What Happens Automatically on Start

When the server starts, **zero manual setup required**:

| Step | What happens |
|------|-------------|
| 🗄️ **Database** | Schema pushed + seeded automatically |
| 📧 **Temp Mail** | `mail.yourdomain.com` registered as email domain |
| 🌐 **Cloudflare DNS** | A record + MX record auto-created via Cloudflare API |
| 📱 **Temp Number** | 10 country configs seeded (US, UK, DE, FR, IN, BD, CA, AU, SG, NL) |
| 📬 **SMTP Server** | Built-in mail server starts on port 25 (no Postfix/Mailgun needed) |
| 🧹 **Auto Cleanup** | Expired inboxes/numbers deleted every 30 minutes |

---

## 📦 Features

### 🛒 Marketplace
- Buy/sell digital items (graphics, code, videos, apps)
- Seller applications & verification
- Reviews, ratings, wishlists, cart
- Custom orders & bidding system
- Coupon codes & discounts

### 👤 User System
- Auth via NextAuth (email + OAuth)
- Wallet & transactions
- Referral system
- Badges & rewards
- Leaderboard
- Teams & friends

### 📧 Temp Mail (Built-in, Zero Config)
- Disposable email addresses — no signup needed
- Built-in SMTP server receives real emails
- Auto-expires after 1 hour
- Real-time inbox (auto-refresh every 8s)
- **URL:** `/tempmail`

### 📱 Temp Number (Built-in, Zero Config)
- Temporary phone numbers for SMS verification
- 10 countries pre-configured
- Auto-expires (configurable per country)
- Real-time SMS inbox
- **URL:** `/tempnum`

### 🤖 AI Suite
- AI Chat (multi-provider: OpenAI, Claude, Ollama, etc.)
- AI Image Generation
- AI Video Generation
- AI Voice
- AI IDE / Code Editor
- AI training data management

### 🖥️ VPS / Server Management
- VPS order management
- Pterodactyl panel integration
- App deployments
- Zero Trust tunnels (Cloudflare)

### 💬 Real-time
- Socket.IO powered live chat
- Private messaging
- Notifications
- Support tickets

---

## ⚙️ Admin Panel

Access at `/admin` with ADMIN or SUPER_ADMIN role.

| Page | URL | Purpose |
|------|-----|---------|
| Dashboard | `/admin` | Stats, quick actions |
| Users | `/admin/users` | Manage all users |
| Items | `/admin` → Items | Approve/reject uploads |
| Transactions | `/admin` → Transactions | Payment management |
| VPS Orders | `/admin/vps-orders` | Server orders |
| Temp Mail Config | `/admin/tempmail` | Domains + DNS auto-setup |
| Temp Number Config | `/admin/tempnum` | Country configs |
| AI Chat | `/admin/ai-chat` | AI provider management |
| Email Settings | `/admin/email-settings` | SMTP outbound config |
| Zero Trust | `/admin/zerotrust` | Cloudflare tunnel config |
| Health Check | `/admin/health` | System status |

---

## 🌐 Cloudflare Setup (One Time)

1. Go to **Admin → Zero Trust**
2. Add your **Cloudflare Account ID** and **API Token**
3. Go to **Admin → Temp Mail Config**
4. Click **"Auto Setup DNS"** — A record + MX record created automatically

> After this, `mail.yourdomain.com` receives real emails with zero external dependencies.

---

## 🗂️ Project Structure

```
gfxv70/
├── src/
│   ├── app/
│   │   ├── admin/          # Admin pages
│   │   ├── api/            # API routes (Next.js App Router)
│   │   ├── tempmail/       # Temp Mail frontend
│   │   ├── tempnum/        # Temp Number frontend
│   │   └── ...             # Other pages
│   ├── lib/
│   │   ├── db.ts           # Prisma client
│   │   ├── auth.ts         # NextAuth config
│   │   ├── smtp-server.ts  # Built-in SMTP server
│   │   ├── temp-services-seed.ts  # Auto DNS + seeding
│   │   └── ...
│   └── components/         # Shared UI components
├── prisma/
│   ├── schema.prisma       # Database schema
│   └── seed.ts             # Initial seed data
├── server.ts               # Custom server (HTTP + Socket.IO + SMTP)
├── .env                    # Environment variables
└── package.json
```

---

## 🔧 Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `DATABASE_URL` | ✅ | PostgreSQL connection string |
| `NEXTAUTH_SECRET` | ✅ | Random secret for session encryption |
| `NEXTAUTH_URL` | ✅ | Full URL of your site |
| `NEXT_PUBLIC_APP_URL` | ✅ | Same as NEXTAUTH_URL (used for auto DNS) |
| `PORT` | ❌ | HTTP server port (default: 5000) |
| `SMTP_PORT` | ❌ | Built-in SMTP port (default: 25, use 2525 if 25 blocked) |
| `TEMPNUM_WEBHOOK_SECRET` | ❌ | Secret for external SMS webhook (optional) |

---

## 📬 Temp Mail — How It Works

```
Someone sends email to random123@mail.yourdomain.com
         ↓
Built-in SMTP server (port 25) receives it
         ↓
mailparser parses the email
         ↓
Saved to DB (TempMailMessage)
         ↓
Frontend auto-refreshes every 8 seconds → user sees it
```

No Postfix, no Mailgun, no external webhook — **100% built-in**.

---

## 📱 Temp Number — How It Works

```
User clicks "Get Temp Number" → gets e.g. +1201XXXXXXX
         ↓
SMS sent to that number by any service
         ↓
If using Twilio/Vonage: configure webhook → POST /api/tempnum/receive
         ↓
Message saved to DB → user sees it in real-time
```

---

## 🛠️ Scripts

```bash
npm run dev           # Next.js dev (without custom server)
npm run custom-dev    # Full server with Socket.IO + SMTP (recommended)
npm run build         # Build for production
npm run custom-start  # Production with custom server
npm run db:push       # Push schema changes
npm run db:seed       # Re-run seed
```

---

## 👤 Default Admin Credentials

After first run:
- **Email:** `kakmare.pa@gmail.com`
- **Password:** `akash9x1`

> Change these immediately in production.

---

## 📄 License

Private — All rights reserved.