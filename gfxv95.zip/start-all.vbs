Set WshShell = CreateObject("WScript.Shell")

' Start pornhub-api on port 3099
WshShell.Run "cmd.exe /c cd /d C:\Users\Administrator\Downloads\gfxv85\pornhub-api && set PATH=C:\Program Files\nodejs;%PATH% && node src\server.js", 0, False

' Wait a moment then start main server
WScript.Sleep 3000
WshShell.Run "cmd.exe /c cd /d C:\Users\Administrator\Downloads\gfxv85 && set PATH=C:\Program Files\nodejs;%PATH% && node node_modules\tsx\dist\cli.mjs server.ts", 0, False
