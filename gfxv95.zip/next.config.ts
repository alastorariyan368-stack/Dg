import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  eslint: {
    ignoreDuringBuilds: true,
  },
  allowedDevOrigins: [
    '*.pike.replit.dev',
    '*.sisko.replit.dev',
    '*.spock.replit.dev',
    '*.picard.replit.dev',
    '*.replit.dev',
    '*.repl.co',
    '**.replit.dev',
    '**.repl.co',
    '*',
  ],
  compress: true,
  poweredByHeader: false,
  images: {
    minimumCacheTTL: 600,
    remotePatterns: [
      { protocol: 'https', hostname: '**' },
      { protocol: 'http', hostname: '**' },
    ],
    formats: ['image/avif', 'image/webp'],
    dangerouslyAllowSVG: true,
    contentSecurityPolicy: "default-src 'self'; script-src 'none'; sandbox;",
  },
  productionBrowserSourceMaps: false,
  onDemandEntries: {
    maxInactiveAge: 120 * 1000,
    pagesBufferLength: 8,
  },
  webpack(config, { dev }) {
    // Minimize bundle size
    if (!dev) {
      config.optimization = {
        ...config.optimization,
        sideEffects: true,
      }
    }

    const currentWatchOptions = config.watchOptions || {}
    const ignored = (currentWatchOptions as any).ignored
    const extraIgnores = [
      'C:\\DumpStack.log.tmp',
      'C:\\pagefile.sys',
      'C:\\hiberfil.sys',
      'C:\\swapfile.sys',
      '**/node_modules/**',
      '**/.git/**',
    ]
    const base = Array.isArray(ignored) ? ignored : ignored ? [ignored] : []
    const baseStrings = base.filter((v: any) => typeof v === 'string' && v.trim().length > 0)
    config.watchOptions = { ...(currentWatchOptions as any), ignored: [...baseStrings, ...extraIgnores] }
    return config
  },
  experimental: {
    serverActions: {
      bodySizeLimit: '4gb',
    },
    optimizePackageImports: [
      '@radix-ui/react-accordion',
      '@radix-ui/react-alert-dialog',
      '@radix-ui/react-dialog',
      '@radix-ui/react-dropdown-menu',
      '@radix-ui/react-popover',
      '@radix-ui/react-tabs',
      '@radix-ui/react-select',
      '@radix-ui/react-switch',
      'lucide-react',
      'socket.io-client',
      'framer-motion',
    ],
    // Turbo for faster dev builds
    turbo: {
      rules: {
        '*.svg': {
          loaders: ['@svgr/webpack'],
          as: '*.js',
        },
      },
    },
  },
  async headers() {
    return [
      {
        source: '/_next/static/(.*)',
        headers: [
          { key: 'Cache-Control', value: 'public, max-age=31536000, immutable' },
          { key: 'X-Content-Type-Options', value: 'nosniff' },
        ],
      },
      {
        source: '/uploads/(.*)',
        headers: [
          { key: 'Cache-Control', value: 'public, max-age=3600, stale-while-revalidate=86400' },
        ],
      },
      {
        source: '/api/(.*)',
        headers: [
          { key: 'Cache-Control', value: 'no-store, no-cache, must-revalidate' },
        ],
      },
      {
        source: '/(.*)',
        headers: [
          { key: 'X-Frame-Options', value: 'SAMEORIGIN' },
          { key: 'X-Content-Type-Options', value: 'nosniff' },
        ],
      },
    ];
  },
};

export default nextConfig;
