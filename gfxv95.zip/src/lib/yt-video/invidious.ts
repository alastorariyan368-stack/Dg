import { Innertube, UniversalCache } from 'youtubei.js'

let innertube: Innertube | null = null

async function getClient() {
  if (!innertube) {
    innertube = await Innertube.create({
      cache: new UniversalCache(false),
      lang: 'en',
      location: 'US',
      retrieve_player: false,
    })
  }
  return innertube
}

interface VideoInfo {
  id: string
  title: string
  description: string
  thumbnail: string
  thumbnailHQ: string
  duration: number
  durationLabel: string
  viewCount: number
  viewCountLabel: string
  channel: string
  channelUrl: string
  channelSubs: string
  publishedAt: string
  publishedLabel: string
  ageRestricted: boolean
  likes: number
  category: string
  tags: string[]
  formats: any[]
  audioFormats: any[]
}

export async function fetchVideoInfo(videoId: string): Promise<VideoInfo> {
  const yt = await getClient()
  const video = await yt.getInfo(videoId)

  const details = video.basic_info
  const thumb = `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`

  return {
    id: videoId,
    title: details.title || 'Untitled Video',
    description: details.short_description?.slice(0, 500) || '',
    thumbnail: thumb,
    thumbnailHQ: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
    duration: details.duration || 0,
    durationLabel: formatDuration(details.duration || 0),
    viewCount: Number(details.view_count || 0),
    viewCountLabel: formatNumber(Number(details.view_count || 0)),
    channel: details.author?.name || details.channel?.name || 'Unknown Channel',
    channelUrl: `https://youtube.com/channel/${details.author?.id || details.channel?.id || ''}`,
    channelSubs: details.author?.subscriber_count
      ? formatNumber(Number(details.author.subscriber_count))
      : 'N/A',
    publishedAt: details.publish_date || 'Unknown',
    publishedLabel: formatDate(details.publish_date || ''),
    ageRestricted: !!details.age_restricted,
    likes: Number(details.likes || 0),
    category: details.category || '',
    tags: (details.keywords || []).slice(0, 5),
    formats: [],
    audioFormats: [],
  }
}

function formatDuration(seconds: number): string {
  if (!seconds || seconds <= 0) return '0:00'
  const h = Math.floor(seconds / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  const s = Math.floor(seconds % 60)
  if (h > 0) return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`
  return `${m}:${s.toString().padStart(2, '0')}`
}

function formatNumber(num: number): string {
  if (num >= 10000000) return (num / 10000000).toFixed(1) + 'Cr'
  if (num >= 100000) return (num / 100000).toFixed(1) + 'L'
  if (num >= 1000) return (num / 1000).toFixed(1) + 'K'
  return num.toString()
}

function formatDate(dateString: string): string {
  if (!dateString) return 'Unknown'
  try {
    const date = new Date(dateString)
    const now = new Date()
    const diffDays = Math.ceil(Math.abs(now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24))
    if (diffDays === 0) return 'Today'
    if (diffDays === 1) return 'Yesterday'
    if (diffDays < 7) return `${diffDays} days ago`
    if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`
    if (diffDays < 365) return `${Math.floor(diffDays / 30)} months ago`
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
  } catch {
    return dateString
  }
}
