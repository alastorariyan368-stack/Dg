import ytdl from '@distube/ytdl-core'

const AGENTS = [
  ytdl.createAgent([
    { name: 'User-Agent', value: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36' },
    { name: 'Accept', value: 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8' },
    { name: 'Accept-Language', value: 'en-US,en;q=0.9' },
    { name: 'Sec-Fetch-Dest', value: 'document' },
    { name: 'Sec-Fetch-Mode', value: 'navigate' },
    { name: 'Sec-Fetch-Site', value: 'none' },
    { name: 'Sec-Fetch-User', value: '?1' },
    { name: 'Upgrade-Insecure-Requests', value: '1' },
  ]),
]

export function getAgent() {
  return AGENTS[0]
}
