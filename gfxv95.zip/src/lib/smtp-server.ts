import SMTPServer from 'smtp-server'
import { simpleParser } from 'mailparser'
import { db } from './db'

let smtpServerInstance: SMTPServer.SMTPServer | null = null

export function startBuiltinSmtpServer(port = 25) {
  if (smtpServerInstance) return

  smtpServerInstance = new SMTPServer.SMTPServer({
    // Accept everything — no auth needed (we check the "to" domain ourselves)
    authOptional: true,
    disabledCommands: ['STARTTLS'],
    banner: 'GfxV70 Temp Mail Server',

    onConnect(session, cb) {
      cb()
    },

    onAuth(auth, session, cb) {
      cb(null, { user: 'anonymous' })
    },

    onRcptTo(address, session, cb) {
      // Accept mail for any address — we validate domain/inbox in onData
      cb()
    },

    async onData(stream, session, cb) {
      try {
        const parsed = await simpleParser(stream)

        const toAddresses: string[] = []
        const toField = parsed.to
        if (toField) {
          const arr = Array.isArray(toField) ? toField : [toField]
          for (const addrObj of arr) {
            if ('value' in addrObj) {
              for (const v of addrObj.value) {
                if (v.address) toAddresses.push(v.address.toLowerCase())
              }
            }
          }
        }

        const fromAddress = (parsed.from?.value?.[0]?.address || '').toLowerCase()
        const fromName = parsed.from?.value?.[0]?.name || null
        const subject = parsed.subject || '(no subject)'
        const bodyText = parsed.text || ''
        const bodyHtml = parsed.html || ''

        for (const to of toAddresses) {
          const inbox = await db.tempMailInbox.findUnique({ where: { address: to } })
          if (!inbox) continue
          if (inbox.expiresAt < new Date()) continue

          await db.tempMailMessage.create({
            data: {
              inboxId: inbox.id,
              fromAddress,
              fromName,
              subject,
              bodyText,
              bodyHtml,
            },
          })
          console.log(`[SMTP] Delivered: ${fromAddress} → ${to} | "${subject}"`)
        }

        cb()
      } catch (err: any) {
        console.error('[SMTP] onData error:', err?.message)
        cb(new Error('Processing error'))
      }
    },

  })

  smtpServerInstance.on('error', (err) => {
    console.error('[SMTP] Uncaught error:', err.message)
  })

  smtpServerInstance.listen(port, '0.0.0.0', () => {
    console.log(`> [SMTP] Built-in mail server listening on port ${port}`)
  })
}

export function stopBuiltinSmtpServer() {
  if (smtpServerInstance) {
    smtpServerInstance.close(() => {})
    smtpServerInstance = null
  }
}
