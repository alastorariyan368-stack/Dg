import nodemailer from 'nodemailer'
import { db } from '@/lib/db'
import dns from 'dns'
import { promisify } from 'util'

const resolveMx = promisify(dns.resolveMx)

export interface MailOptions {
  to: string
  subject: string
  html: string
  from?: string
}

interface EmailConfig {
  provider: 'smtp' | 'resend' | 'direct' | 'gmail'
  host?: string
  port?: number
  secure?: boolean
  user?: string
  pass?: string
  resendKey?: string
  fromName?: string
  fromAddress?: string
}

async function getEmailConfig(): Promise<EmailConfig | null> {
  // 1. Check env vars first
  if (process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS) {
    return {
      provider: 'smtp',
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: process.env.SMTP_SECURE === 'true',
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    }
  }
  if (process.env.RESEND_API_KEY) {
    return { provider: 'resend', resendKey: process.env.RESEND_API_KEY }
  }

  // 2. Check DB smtpConfig
  try {
    const settings = await db.siteSettings.findFirst({ select: { smtpConfig: true } })
    if (settings?.smtpConfig && typeof settings.smtpConfig === 'object') {
      const cfg = settings.smtpConfig as any
      if (cfg.provider) return cfg as EmailConfig
    }
  } catch {
    // ignore DB errors
  }

  return null
}

async function sendViaResend(
  apiKey: string, options: MailOptions, fromAddr: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const { Resend } = await import('resend')
    const resend = new Resend(apiKey)
    const { error } = await resend.emails.send({
      from: fromAddr,
      to: options.to,
      subject: options.subject,
      html: options.html,
    })
    if (error) return { success: false, error: error.message }
    console.log(`[Mailer] ✅ Sent via Resend → ${options.to}`)
    return { success: true }
  } catch (e: any) {
    return { success: false, error: e?.message || 'Resend failed' }
  }
}

async function sendViaSmtp(
  cfg: EmailConfig, options: MailOptions, fromAddr: string
): Promise<{ success: boolean; error?: string }> {
  try {
    const transporter = nodemailer.createTransport({
      host: cfg.host,
      port: cfg.port || 587,
      secure: cfg.secure ?? false,
      auth: { user: cfg.user, pass: cfg.pass },
      tls: { rejectUnauthorized: false },
    })
    await transporter.sendMail({
      from: fromAddr,
      to: options.to,
      subject: options.subject,
      html: options.html,
    })
    console.log(`[Mailer] ✅ Sent via SMTP (${cfg.host}) → ${options.to}`)
    return { success: true }
  } catch (e: any) {
    return { success: false, error: e?.message || 'SMTP failed' }
  }
}

async function sendViaDirectMx(
  options: MailOptions, fromAddr: string
): Promise<{ success: boolean; error?: string }> {
  const recipientDomain = options.to.split('@')[1]
  if (!recipientDomain) return { success: false, error: 'Invalid recipient address' }

  let mxRecords: dns.MxRecord[]
  try {
    mxRecords = await resolveMx(recipientDomain)
    mxRecords.sort((a, b) => a.priority - b.priority)
  } catch (err: any) {
    return { success: false, error: `DNS MX lookup failed: ${err.message}` }
  }

  if (!mxRecords.length) return { success: false, error: `No MX records for ${recipientDomain}` }

  for (const mx of mxRecords) {
    try {
      const transporter = nodemailer.createTransport({
        host: mx.exchange,
        port: 25,
        secure: false,
        ignoreTLS: false,
        tls: { rejectUnauthorized: false },
        connectionTimeout: 10000,
        greetingTimeout: 8000,
        socketTimeout: 10000,
        name: process.env.MAIL_HOSTNAME || 'gfxstore.app',
      } as any)

      await transporter.sendMail({
        from: fromAddr,
        to: options.to,
        subject: options.subject,
        html: options.html,
        headers: {
          'X-Mailer': 'GfxStore Mailer 1.0',
          'Message-ID': `<${Date.now()}.${Math.random().toString(36).slice(2)}@gfxstore.app>`,
        },
      })

      console.log(`[Mailer] ✅ Direct delivery OK → ${options.to} via ${mx.exchange}`)
      return { success: true }
    } catch (err: any) {
      console.warn(`[Mailer] ⚠ MX ${mx.exchange} failed: ${err.message}`)
    }
  }

  return { success: false, error: `All MX servers rejected the email for ${recipientDomain}` }
}

async function storeEmail(options: MailOptions) {
  try {
    await db.sentEmail.create({
      data: { to: options.to, subject: options.subject, html: options.html },
    })
    console.log(`[Mailer] 📥 Stored in Admin Inbox for: ${options.to}`)
  } catch (err) {
    console.error('[Mailer] Store failed:', err)
  }
}

export async function sendMail(options: MailOptions): Promise<{ success: boolean; error?: string; fallback?: boolean }> {
  const cfg = await getEmailConfig()
  const fromAddr = options.from ||
    (cfg?.fromName && cfg?.fromAddress
      ? `${cfg.fromName} <${cfg.fromAddress}>`
      : process.env.EMAIL_FROM || 'GfxStore <noreply@gfxstore.app>')

  if (cfg) {
    if (cfg.provider === 'resend' && cfg.resendKey) {
      const r = await sendViaResend(cfg.resendKey, options, fromAddr)
      if (r.success) return { success: true }
      console.warn('[Mailer] Resend failed:', r.error)
    } else if (cfg.provider === 'gmail' || cfg.provider === 'smtp') {
      const smtpCfg: EmailConfig = cfg.provider === 'gmail'
        ? { ...cfg, host: 'smtp.gmail.com', port: 587, secure: false }
        : cfg
      const r = await sendViaSmtp(smtpCfg, options, fromAddr)
      if (r.success) return { success: true }
      console.warn('[Mailer] SMTP failed:', r.error)
    } else if (cfg.provider === 'direct') {
      const r = await sendViaDirectMx(options, fromAddr)
      if (r.success) return { success: true }
      console.warn('[Mailer] Direct MX failed:', r.error)
    }
  } else {
    // No config — try direct MX as best-effort
    const r = await sendViaDirectMx(options, fromAddr)
    if (r.success) return { success: true }
    console.warn('[Mailer] Direct MX failed (no config):', r.error)
  }

  // Final fallback: store in admin inbox
  await storeEmail(options)
  return { success: true, fallback: true }
}

export async function testEmailConfig(
  cfg: EmailConfig, testTo: string
): Promise<{ success: boolean; error?: string }> {
  const from = cfg.fromName && cfg.fromAddress
    ? `${cfg.fromName} <${cfg.fromAddress}>`
    : 'GfxStore <noreply@gfxstore.app>'
  const opts: MailOptions = {
    to: testTo,
    subject: 'GfxStore Email Test',
    html: `<div style="font-family:sans-serif;padding:24px;background:#0a0a12;color:#fff;border-radius:12px;">
      <h2 style="color:#a78bfa;">✅ Email working!</h2>
      <p style="color:#ccc;">This test email from GfxStore confirms your email settings are working correctly.</p>
      <p style="color:#888;font-size:12px;">Provider: ${cfg.provider} · Sent at ${new Date().toISOString()}</p>
    </div>`,
    from,
  }

  if (cfg.provider === 'resend' && cfg.resendKey) {
    return sendViaResend(cfg.resendKey, opts, from)
  }
  if (cfg.provider === 'gmail' || cfg.provider === 'smtp') {
    const smtpCfg = cfg.provider === 'gmail'
      ? { ...cfg, host: 'smtp.gmail.com', port: 587, secure: false }
      : cfg
    return sendViaSmtp(smtpCfg, opts, from)
  }
  if (cfg.provider === 'direct') {
    return sendViaDirectMx(opts, from)
  }
  return { success: false, error: 'Unknown provider' }
}

export function buildNotificationEmailHtml(opts: {
  username: string
  title: string
  message: string
  ctaText?: string
  ctaLink?: string
  color?: string
}) {
  const accentColor = opts.color || '#7c3aed'
  return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/></head>
<body style="margin:0;padding:0;background:#0a0a12;font-family:'Segoe UI',Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#0a0a12;min-height:100vh;">
  <tr><td align="center" style="padding:48px 16px;">
    <table width="100%" style="max-width:480px;background:#13131f;border-radius:20px;border:1px solid rgba(255,255,255,0.08);overflow:hidden;">
      <tr>
        <td style="background:linear-gradient(135deg,${accentColor},#06b6d4);padding:28px 32px;text-align:center;">
          <span style="font-size:22px;font-weight:800;color:#fff;letter-spacing:-0.5px;">⚡ GfxStore</span>
        </td>
      </tr>
      <tr>
        <td style="padding:36px 32px;">
          <h2 style="margin:0 0 8px;font-size:20px;font-weight:700;color:#fff;">${opts.title}</h2>
          <p style="margin:0 0 20px;color:#8888aa;font-size:15px;line-height:1.6;">
            Hi <strong style="color:#fff;">${opts.username}</strong>,<br/><br/>
            ${opts.message}
          </p>
          ${opts.ctaText && opts.ctaLink ? `
          <table width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td align="center" style="padding:8px 0 20px;">
                <a href="${opts.ctaLink}"
                   style="display:inline-block;padding:12px 32px;background:linear-gradient(135deg,${accentColor},#06b6d4);color:#fff;border-radius:10px;text-decoration:none;font-weight:700;font-size:14px;">
                  ${opts.ctaText}
                </a>
              </td>
            </tr>
          </table>` : ''}
        </td>
      </tr>
      <tr>
        <td style="padding:16px 32px 28px;border-top:1px solid rgba(255,255,255,0.06);">
          <p style="margin:0;color:#444466;font-size:12px;line-height:1.6;">
            This is an automated notification from GfxStore. Please do not reply to this email.
          </p>
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>`
}

export function buildResetEmailHtml(opts: { username: string; resetLink: string }) {
  return `<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"/><meta name="viewport" content="width=device-width,initial-scale=1"/></head>
<body style="margin:0;padding:0;background:#0a0a12;font-family:'Segoe UI',Arial,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#0a0a12;min-height:100vh;">
  <tr><td align="center" style="padding:48px 16px;">
    <table width="100%" style="max-width:480px;background:#13131f;border-radius:20px;border:1px solid rgba(255,255,255,0.08);overflow:hidden;">
      <tr>
        <td style="background:linear-gradient(135deg,#7c3aed,#06b6d4);padding:32px;text-align:center;">
          <span style="font-size:26px;font-weight:800;color:#fff;letter-spacing:-0.5px;">⚡ GfxStore</span>
        </td>
      </tr>
      <tr>
        <td style="padding:40px 36px;">
          <h1 style="margin:0 0 8px;font-size:24px;font-weight:700;color:#fff;">Password Reset</h1>
          <p style="margin:0 0 24px;color:#8888aa;font-size:15px;line-height:1.6;">
            Hi <strong style="color:#fff;">${opts.username}</strong>,<br/>
            We received a request to reset your GfxStore password. Click the button below — the link expires in <strong style="color:#a78bfa;">1 hour</strong>.
          </p>
          <table width="100%" cellpadding="0" cellspacing="0">
            <tr>
              <td align="center" style="padding:8px 0 24px;">
                <a href="${opts.resetLink}"
                   style="display:inline-block;padding:14px 36px;background:linear-gradient(135deg,#7c3aed,#06b6d4);color:#fff;border-radius:12px;text-decoration:none;font-weight:700;font-size:16px;">
                  Reset my password
                </a>
              </td>
            </tr>
          </table>
          <p style="margin:0 0 16px;color:#555577;font-size:13px;">Or paste this link in your browser:</p>
          <div style="background:#0a0a12;border:1px solid rgba(255,255,255,0.06);border-radius:8px;padding:12px 16px;word-break:break-all;font-size:12px;color:#7c3aed;">
            ${opts.resetLink}
          </div>
        </td>
      </tr>
      <tr>
        <td style="padding:20px 36px 32px;border-top:1px solid rgba(255,255,255,0.06);">
          <p style="margin:0;color:#444466;font-size:12px;line-height:1.6;">
            If you didn't request this, you can safely ignore this email.
          </p>
        </td>
      </tr>
    </table>
  </td></tr>
</table>
</body>
</html>`
}
