/**
 * GfxV1 AI Brain Engine
 * Self-contained, persistent AI system with knowledge base.
 * - Knowledge stored in PostgreSQL (survives restarts)
 * - Learns from every interaction
 * - Keyword-based matching for instant local answers
 * - Falls back to Pollinations (free) or any configured API
 * - Admin can train, edit, and correct the brain
 */

import { db } from '@/lib/db'
import { getCache, setCache } from '@/lib/cache'

const BRAIN_CACHE_KEY = 'gfx:brain:all'
const CONFIG_CACHE_KEY = 'gfx:ai:config'
const BRAIN_CACHE_TTL = 120 // 2 min
const MIN_MATCH_SCORE = 0.25

const PROVIDER_BASE_URLS: Record<string, string> = {
  openai: 'https://api.openai.com/v1',
  anthropic: 'https://api.anthropic.com/v1',
  google: 'https://generativelanguage.googleapis.com/v1beta/openai',
  openrouter: 'https://openrouter.ai/api/v1',
  zai: 'https://api.z.ai/v1',
  xai: 'https://api.x.ai/v1',
  groq: 'https://api.groq.com/openai/v1',
  deepseek: 'https://api.deepseek.com/v1',
  pollinations: 'https://text.pollinations.ai/openai',
}

async function loadAiProviders() {
  try {
    const providers = await (db as any).aiProvider.findMany({
      where: { enabled: true },
      orderBy: [{ priority: 'desc' }, { name: 'asc' }],
    })
    return providers.map((provider: any) => ({
      ...provider,
      models: Array.isArray(provider.models) ? provider.models : JSON.parse(provider.models || '[]'),
      features: Array.isArray(provider.features) ? provider.features : JSON.parse(provider.features || '[]'),
    }))
  } catch {
    return []
  }
}

function getProviderModel(provider: any) {
  if (provider.models && Array.isArray(provider.models) && provider.models.length) return provider.models[0]
  return 'gpt-4o-mini'
}

function getProviderBaseUrl(provider: any) {
  if (provider.apiBase?.trim()) return provider.apiBase.trim().replace(/\/+$/, '')
  if (provider.slug && PROVIDER_BASE_URLS[provider.slug]) return PROVIDER_BASE_URLS[provider.slug]
  return PROVIDER_BASE_URLS.openai
}

function safeProviderKey(provider: any) {
  return provider.apiKey?.trim() || ''
}

export interface BrainEntry {
  id: string
  category: string
  question: string
  answer: string
  keywords: string
  confidence: number
  usageCount: number
  source: string
  isActive: boolean
}

export interface AiConfig {
  systemPrompt: string
  personality: string
  version: string
}

// ── Keyword scoring ────────────────────────────────────────────────────────

function tokenize(text: string): string[] {
  return text.toLowerCase()
    .replace(/[^\w\s\u0980-\u09FF]/g, ' ')
    .split(/\s+/)
    .filter(t => t.length > 1)
}

function scoreMatch(query: string, entry: BrainEntry): number {
  const queryTokens = new Set(tokenize(query))
  if (queryTokens.size === 0) return 0

  const entryTokens = new Set([
    ...tokenize(entry.question),
    ...tokenize(entry.keywords),
    ...tokenize(entry.category),
  ])

  let matches = 0
  for (const t of queryTokens) {
    if (entryTokens.has(t)) matches++
    // Partial match bonus
    else {
      for (const et of entryTokens) {
        if (et.includes(t) || t.includes(et)) { matches += 0.5; break }
      }
    }
  }

  const precision = matches / queryTokens.size
  const recall = matches / Math.max(entryTokens.size, 1)
  return (2 * precision * recall) / (precision + recall + 0.001) * entry.confidence
}

// ── Load brain from DB (cached) ───────────────────────────────────────────

export async function loadBrain(): Promise<BrainEntry[]> {
  const cached = getCache<BrainEntry[]>(BRAIN_CACHE_KEY)
  if (cached) return cached

  try {
    const entries = await (db as any).gfxAiBrain.findMany({
      where: { isActive: true },
      orderBy: { usageCount: 'desc' },
      take: 500,
    })
    setCache(BRAIN_CACHE_KEY, entries, BRAIN_CACHE_TTL)
    return entries
  } catch {
    return []
  }
}

export async function invalidateBrainCache() {
  const { clearCache } = await import('@/lib/cache')
  clearCache(BRAIN_CACHE_KEY)
  clearCache(CONFIG_CACHE_KEY)
}

// ── Load AI config ────────────────────────────────────────────────────────

export async function loadAiConfig(): Promise<AiConfig> {
  const cached = getCache<AiConfig>(CONFIG_CACHE_KEY)
  if (cached) return cached

  try {
    let cfg = await (db as any).gfxAiConfig.findFirst({ where: { name: 'GFXV1' } })
    if (!cfg) {
      cfg = await (db as any).gfxAiConfig.create({
        data: {
          name: 'GFXV1',
          systemPrompt: '',
          personality: 'professional',
          version: '5.0.0',
        },
      })
    }
    const result: AiConfig = {
      systemPrompt: cfg.systemPrompt || '',
      personality: cfg.personality || 'professional',
      version: cfg.version || '5.0.0',
    }
    setCache(CONFIG_CACHE_KEY, result, 300)
    return result
  } catch {
    return { systemPrompt: '', personality: 'professional', version: '5.0.0' }
  }
}

// ── Find best matching entry ──────────────────────────────────────────────

export async function findBestMatch(query: string): Promise<{ entry: BrainEntry; score: number } | null> {
  const brain = await loadBrain()
  if (!brain.length) return null

  let best: { entry: BrainEntry; score: number } | null = null

  for (const entry of brain) {
    const score = scoreMatch(query, entry)
    if (score > MIN_MATCH_SCORE && (!best || score > best.score)) {
      best = { entry, score }
    }
  }

  return best
}

// ── Learn from interaction (store in brain) ───────────────────────────────

export async function learnFromInteraction(
  question: string,
  answer: string,
  source: 'learned' | 'api' | 'manual' = 'learned',
  category = 'general',
) {
  if (!question?.trim() || !answer?.trim() || answer.length < 10) return

  const keywords = [...new Set(tokenize(question + ' ' + category))].slice(0, 20).join(' ')

  try {
    // Check if very similar entry already exists
    const brain = await loadBrain()
    for (const entry of brain) {
      if (scoreMatch(question, entry) > 0.85) {
        // Update existing entry
        await (db as any).gfxAiBrain.update({
          where: { id: entry.id },
          data: {
            usageCount: { increment: 1 },
            answer: source === 'api' ? answer : entry.answer, // API answers override
            updatedAt: new Date(),
          },
        })
        invalidateBrainCache()
        return
      }
    }

    // Store new entry (only if not too similar)
    await (db as any).gfxAiBrain.create({
      data: {
        category,
        question: question.slice(0, 500),
        answer: answer.slice(0, 3000),
        keywords,
        confidence: source === 'manual' ? 1.0 : source === 'api' ? 0.85 : 0.7,
        source,
        usageCount: 1,
      },
    })
    invalidateBrainCache()
  } catch (e) {
    // Silently fail — learning should never crash the main flow
  }
}

// ── Save conversation to memory ───────────────────────────────────────────

export async function saveMemory(userId: string, sessionId: string, role: 'user' | 'assistant', content: string) {
  try {
    await (db as any).gfxAiMemory.create({
      data: { userId, sessionId, role, content: content.slice(0, 2000) },
    })
  } catch {}
}

// ── Load recent memory for a user ────────────────────────────────────────

export async function loadMemory(userId: string, sessionId: string, limit = 10): Promise<Array<{ role: string; content: string }>> {
  try {
    const rows = await (db as any).gfxAiMemory.findMany({
      where: { userId, sessionId },
      orderBy: { createdAt: 'asc' },
      take: limit,
      select: { role: true, content: true },
    })
    return rows
  } catch {
    return []
  }
}

// ── Pollinations free text API ────────────────────────────────────────────

async function callPollinations(systemInstruction: string, messages: Array<{ role: string; content: string }>, maxTokens = 1500): Promise<string> {
  const allMessages = [
    { role: 'system', content: systemInstruction },
    ...messages.map(m => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: m.content })),
  ]

  // Try two Pollinations endpoints in parallel and take the first to respond
  const makeReq = (model: string, timeout: number) =>
    fetch('https://text.pollinations.ai/openai', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model, messages: allMessages, max_tokens: maxTokens, temperature: 0.75, private: true }),
      signal: AbortSignal.timeout(timeout),
    }).catch(() => null)

  const [res1, res2] = await Promise.allSettled([
    makeReq('openai-large', 12000),
    makeReq('openai', 12000),
  ])

  for (const result of [res1, res2]) {
    if (result.status === 'fulfilled' && result.value?.ok) {
      const data = await result.value.json().catch(() => ({}))
      const reply = data?.choices?.[0]?.message?.content || ''
      if (reply) return reply
    }
  }
  throw new Error('All Pollinations endpoints failed')
}

// ── Main generate function ────────────────────────────────────────────────

export async function generateGfxResponse(opts: {
  prompt: string
  messages: Array<{ role: string; content: string }>
  userId: string
  sessionId: string
  settings: any
  modelName?: string
  style?: string
}): Promise<{ response: string; source: 'brain' | 'api' | 'pollinations'; learned: boolean }> {
  const { prompt, messages, userId, sessionId, settings, modelName = 'GFXV1', style = 'general' } = opts

  const [aiConfig, bestMatch] = await Promise.all([
    loadAiConfig(),
    findBestMatch(prompt),
  ])

  const wantsCode = style === 'code'

  const baseSystemPrompt = buildSystemPrompt(modelName, aiConfig, wantsCode)

  // ── 1. Check Brain first ──────────────────────────────────────────────
  if (bestMatch && bestMatch.score > 0.55) {
    const brainAnswer = bestMatch.entry.answer

    // Update usage count
    try {
      await (db as any).gfxAiBrain.update({
        where: { id: bestMatch.entry.id },
        data: { usageCount: { increment: 1 } },
      })
    } catch {}

    // Enhance the brain answer with current context if API is available
    let finalAnswer = brainAnswer
    if (settings?.geminiApiKey || settings?.openaiApiKey) {
      try {
        const enhancePrompt = `You have this relevant knowledge: "${brainAnswer}"\n\nUser asked: "${prompt}"\n\nProvide a natural, contextual response based on this knowledge. Be concise.`
        finalAnswer = await callExternalApi(settings, baseSystemPrompt, [{ role: 'user', content: enhancePrompt }], 800) || brainAnswer
      } catch {
        finalAnswer = brainAnswer
      }
    }

    await saveMemory(userId, sessionId, 'user', prompt)
    await saveMemory(userId, sessionId, 'assistant', finalAnswer)

    return { response: finalAnswer, source: 'brain', learned: false }
  }

  // ── 2. Try external API (Gemini → OpenAI → others) ──────────────────
  const fullMessages = [
    ...messages.slice(-8),
    { role: 'user', content: prompt },
  ]

  let response = ''
  let source: 'api' | 'pollinations' = 'pollinations'

  // Try all configured providers (Gemini, OpenAI, Anthropic, Deepseek, Mistral, xAI, Groq, Together, Cohere, Ollama)
  if (!response && settings) {
    try {
      response = await callExternalApi(settings, baseSystemPrompt, fullMessages, 2000)
      if (response) source = 'api'
    } catch {}
  }

  // Pollinations (always-free final fallback) — try multiple times
  if (!response) {
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        response = await callPollinations(baseSystemPrompt, fullMessages, 2000)
        if (response) { source = 'pollinations'; break; }
      } catch {
        if (attempt === 2) {
          // Last resort: generate a smart local response
          response = generateLocalResponse(prompt, modelName)
        }
        await new Promise(r => setTimeout(r, 800))
      }
    }
  }

  // ── 3. Learn from this interaction ──────────────────────────────────
  let learned = false
  if (response && response.length > 20) {
    await saveMemory(userId, sessionId, 'user', prompt)
    await saveMemory(userId, sessionId, 'assistant', response)

    // Store in brain if the response looks good
    await learnFromInteraction(prompt, response, source === 'api' ? 'api' : 'learned')
    learned = true
  }

  // ── 4. Update config stats ───────────────────────────────────────────
  try {
    await (db as any).gfxAiConfig.updateMany({
      where: { name: 'GFXV1' },
      data: { totalResponses: { increment: 1 } },
    })
  } catch {}

  return { response, source, learned }
}

// ── API helpers ───────────────────────────────────────────────────────────

export async function callExternalApi(settings: any, systemPrompt: string, messages: any[], maxTokens: number): Promise<string> {
  const providers = await loadAiProviders()
  if (providers.length) {
    for (const provider of providers) {
      try {
        const result = await callProvider(provider, systemPrompt, messages, maxTokens)
        if (result) return result
      } catch {
        continue
      }
    }
    return ''
  }

  // Legacy fallback for older deployments that still use site settings
  if (settings?.geminiApiKey) {
    const r = await callGemini(settings.geminiApiKey, systemPrompt, messages, maxTokens).catch(() => '')
    if (r) return r
  }
  if (settings?.openaiApiKey) {
    const r = await callOpenAI(settings.openaiApiKey, systemPrompt, messages, maxTokens).catch(() => '')
    if (r) return r
  }
  if (settings?.anthropicApiKey) {
    const r = await callAnthropic(settings.anthropicApiKey, systemPrompt, messages, maxTokens).catch(() => '')
    if (r) return r
  }
  if (settings?.deepseekApiKey) {
    const r = await callOpenAICompat('https://api.deepseek.com/v1', settings.deepseekApiKey, 'deepseek-chat', systemPrompt, messages, maxTokens).catch(() => '')
    if (r) return r
  }
  if (settings?.mistralApiKey) {
    const r = await callOpenAICompat('https://api.mistral.ai/v1', settings.mistralApiKey, 'mistral-small-latest', systemPrompt, messages, maxTokens).catch(() => '')
    if (r) return r
  }
  if (settings?.xaiApiKey) {
    const r = await callOpenAICompat('https://api.x.ai/v1', settings.xaiApiKey, 'grok-3-mini', systemPrompt, messages, maxTokens).catch(() => '')
    if (r) return r
  }
  if (settings?.togetherApiKey) {
    const r = await callOpenAICompat('https://api.together.xyz/v1', settings.togetherApiKey, 'meta-llama/Llama-3.3-70B-Instruct-Turbo-Free', systemPrompt, messages, maxTokens).catch(() => '')
    if (r) return r
  }
  if (settings?.cohereApiKey) {
    const r = await callCohere(settings.cohereApiKey, systemPrompt, messages, maxTokens).catch(() => '')
    if (r) return r
  }
  if (settings?.groqApiKey) {
    const r = await callOpenAICompat('https://api.groq.com/openai/v1', settings.groqApiKey, 'llama-3.1-8b-instant', systemPrompt, messages, maxTokens).catch(() => '')
    if (r) return r
  }
  if (settings?.ollamaUrl) {
    const r = await callOpenAICompat(`${settings.ollamaUrl}/v1`, 'ollama', settings.ollamaModel || 'llama3', systemPrompt, messages, maxTokens).catch(() => '')
    if (r) return r
  }
  return ''
}

async function callProvider(provider: any, systemPrompt: string, messages: any[], maxTokens: number): Promise<string> {
  const apiKey = safeProviderKey(provider)
  const baseUrl = getProviderBaseUrl(provider)
  const model = getProviderModel(provider)

  if (!apiKey && provider.slug !== 'pollinations') return ''

  if (provider.slug === 'anthropic' || baseUrl.includes('anthropic.com')) {
    return callAnthropic(apiKey, systemPrompt, messages, maxTokens)
  }
  if (provider.slug === 'google' || baseUrl.includes('googleapis.com')) {
    return callGemini(apiKey, systemPrompt, messages, maxTokens, model, baseUrl)
  }
  if (provider.slug === 'pollinations' || baseUrl.includes('pollinations.ai')) {
    return callPollinations(systemPrompt, messages, maxTokens)
  }

  const extraHeaders: Record<string, string> = {}
  if (baseUrl.includes('openrouter.ai')) {
    extraHeaders['X-Title'] = 'GFX Store'
    extraHeaders['Referer'] = 'https://gfxstore'
  }

  return callOpenAICompat(baseUrl, apiKey, model, systemPrompt, messages, maxTokens, extraHeaders)
}

async function callGemini(apiKey: string, systemPrompt: string, messages: any[], maxTokens: number, model = 'gemini-2.0-flash', baseUrl = 'https://generativelanguage.googleapis.com/v1beta'): Promise<string> {
  const res = await fetch(`${baseUrl}/models/${model}:generateContent?key=${apiKey}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [
        { role: 'user', parts: [{ text: `SYSTEM: ${systemPrompt}` }] },
        { role: 'model', parts: [{ text: 'Understood. I am GFXV1 Agent.' }] },
        ...messages.map((m: any) => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] })),
      ],
      generationConfig: { maxOutputTokens: maxTokens, temperature: 0.75 },
    }),
    signal: AbortSignal.timeout(15000),
  }).catch(() => null)
  if (!res?.ok) return ''
  const data = await res.json().catch(() => ({}))
  return data?.candidates?.[0]?.content?.parts?.[0]?.text || ''
}

async function callOpenAI(apiKey: string, systemPrompt: string, messages: any[], maxTokens: number): Promise<string> {
  return callOpenAICompat('https://api.openai.com/v1', apiKey, 'gpt-4o-mini', systemPrompt, messages, maxTokens)
}

async function callAnthropic(apiKey: string, systemPrompt: string, messages: any[], maxTokens: number): Promise<string> {
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
      'content-type': 'application/json',
    },
    body: JSON.stringify({
      model: 'claude-3-5-haiku-20241022',
      max_tokens: maxTokens,
      system: systemPrompt,
      messages: messages.map((m: any) => ({ role: m.role === 'assistant' ? 'assistant' : 'user', content: m.content })),
    }),
    signal: AbortSignal.timeout(15000),
  }).catch(() => null)
  if (!res?.ok) return ''
  const data = await res.json().catch(() => ({}))
  return data?.content?.[0]?.text || ''
}

async function callCohere(apiKey: string, systemPrompt: string, messages: any[], maxTokens: number): Promise<string> {
  const chatHistory = messages.slice(0, -1).map((m: any) => ({
    role: m.role === 'assistant' ? 'CHATBOT' : 'USER',
    message: m.content,
  }))
  const lastMsg = messages[messages.length - 1]?.content || ''
  const res = await fetch('https://api.cohere.ai/v1/chat', {
    method: 'POST',
    headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: 'command-r-plus-08-2024',
      preamble: systemPrompt,
      chat_history: chatHistory,
      message: lastMsg,
      max_tokens: maxTokens,
    }),
    signal: AbortSignal.timeout(15000),
  }).catch(() => null)
  if (!res?.ok) return ''
  const data = await res.json().catch(() => ({}))
  return data?.text || ''
}

async function callOpenAICompat(base: string, apiKey: string, model: string, systemPrompt: string, messages: any[], maxTokens: number, extraHeaders: Record<string, string> = {}): Promise<string> {
  const headers: Record<string, string> = {
    Authorization: `Bearer ${apiKey}`,
    'Content-Type': 'application/json',
    ...extraHeaders,
  }

  const res = await fetch(`${base}/chat/completions`, {
    method: 'POST',
    headers,
    body: JSON.stringify({
      model,
      messages: [{ role: 'system', content: systemPrompt }, ...messages],
      max_tokens: maxTokens,
      temperature: 0.75,
    }),
    signal: AbortSignal.timeout(15000),
  }).catch(() => null)

  if (!res?.ok) return ''
  const data = await res.json().catch(() => ({}))
  return data?.choices?.[0]?.message?.content || ''
}

// ── Local fallback response generator ────────────────────────────────────

function generateLocalResponse(prompt: string, modelName: string): string {
  const p = prompt.toLowerCase().trim()

  if (p.includes('কে তৈরি') || p.includes('বানাল') || p.includes('who made') || p.includes('who built') || p.includes('who created')) {
    return `আমি **${modelName}** — Akash Devx তৈরি করেছেন। আমি GfxStore-এর AI Assistant। আপনাকে সাহায্য করতে সদা প্রস্তুত! 🚀`
  }
  if (p.includes('হ্যালো') || p.includes('hello') || p.includes('hi ') || p === 'hi' || p.includes('নমস্কার') || p.includes('আস্সালামু') || p.includes('salaam')) {
    return `হ্যালো! আমি **${modelName}**। আপনাকে কীভাবে সাহায্য করতে পারি? 😊\n\nআমি code লিখতে, প্রশ্নের উত্তর দিতে, এবং সৃজনশীল কাজে সাহায্য করতে পারি।`
  }
  if (p.includes('কেমন আছ') || p.includes('how are you')) {
    return `আমি ভালো আছি, ধন্যবাদ! আপনি কেমন আছেন? আপনার জন্য আমি কী করতে পারি?`
  }
  if (p.includes('code') || p.includes('কোড') || p.includes('program') || p.includes('function') || p.includes('script')) {
    return `অবশ্যই! আপনার coding সংক্রান্ত প্রশ্নে আমি সাহায্য করব। একটু বিস্তারিত বলুন — কোন language (JavaScript, Python, etc.) এবং কী করতে চান?`
  }
  if (p.includes('gfxstore') || p.includes('gfx store')) {
    return `**GfxStore** হলো একটি premium digital marketplace যেখানে আপনি AI tools, scripts, mods, graphics এবং digital assets পাবেন। আমি GfxStore-এর AI Assistant। আপনার কী জানতে চান?`
  }

  // Default intelligent response
  return `আপনার প্রশ্নটি পেয়েছি। আমি **${modelName}** — আপনাকে সাহায্য করতে চাই। \n\nআপনি কি একটু বিস্তারিত বলবেন? আমি code লেখা, প্রশ্নের উত্তর দেওয়া, সমস্যা সমাধান সহ সব ধরনের সাহায্য করতে পারি।`
}

// ── System prompt builder ─────────────────────────────────────────────────

export function buildSystemPrompt(modelName: string, config: AiConfig, wantsCode = false): string {
  const custom = config.systemPrompt?.trim()
  const base = `You are ${modelName} (Version: ${config.version}), a powerful AI Agent built by Akash Devx for GfxStore.
- If asked who built you: "I was built by Akash Devx — founder of GfxStore."
- GfxStore is the ultimate digital marketplace for AI tools, scripts, mods, graphics, and digital assets.
- Personality: ${config.personality}.
- Respond in the same language the user writes in (Bengali, English, Hindi, etc.)
- Give comprehensive, helpful, professional responses.

${custom ? `Admin Training Instructions:\n${custom}\n` : ''}
${wantsCode ? `
Coding Protocol:
- Provide complete, production-ready code.
- Explain your implementation choices.
- Use proper Markdown code blocks.
- Suggest security best practices.` : `
General Protocol:
- Be comprehensive and detailed.
- Anticipate follow-up questions.
- Use clear structure (headers, bullets) for complex answers.`}`

  return base
}
