export async function generateVideoThumbnail(
  source: File | string,
  seekTo: number = 1
): Promise<Blob> {
  return new Promise((resolve, reject) => {
    const video = document.createElement('video')
    video.crossOrigin = 'anonymous'
    video.preload = 'metadata'
    video.muted = true
    video.playsInline = true

    const cleanup = () => {
      try {
        if (typeof source !== 'string' && video.src.startsWith('blob:')) {
          URL.revokeObjectURL(video.src)
        }
      } catch {}
      video.remove()
    }

    video.onloadedmetadata = () => {
      const target = Math.min(Math.max(0.1, seekTo), Math.max(0.1, (video.duration || 1) / 2))
      try { video.currentTime = target } catch { reject(new Error('Cannot seek')) }
    }

    video.onseeked = () => {
      try {
        const w = video.videoWidth || 720
        const h = video.videoHeight || 1280
        const maxSide = 720
        const scale = Math.min(1, maxSide / Math.max(w, h))
        const cw = Math.round(w * scale)
        const ch = Math.round(h * scale)
        const canvas = document.createElement('canvas')
        canvas.width = cw
        canvas.height = ch
        const ctx = canvas.getContext('2d')
        if (!ctx) { cleanup(); reject(new Error('No canvas ctx')); return }
        ctx.drawImage(video, 0, 0, cw, ch)
        canvas.toBlob(
          (blob) => {
            cleanup()
            if (blob) resolve(blob)
            else reject(new Error('Blob failed'))
          },
          'image/jpeg',
          0.85
        )
      } catch (e) {
        cleanup()
        reject(e)
      }
    }

    video.onerror = () => {
      cleanup()
      reject(new Error('Video load failed'))
    }

    if (typeof source === 'string') {
      video.src = source
    } else {
      video.src = URL.createObjectURL(source)
    }
  })
}

export async function getVideoDuration(source: File | string): Promise<number> {
  return new Promise((resolve) => {
    const video = document.createElement('video')
    video.preload = 'metadata'
    video.muted = true
    const cleanup = () => {
      try { if (typeof source !== 'string' && video.src.startsWith('blob:')) URL.revokeObjectURL(video.src) } catch {}
      video.remove()
    }
    video.onloadedmetadata = () => {
      const d = isFinite(video.duration) ? Math.round(video.duration) : 0
      cleanup(); resolve(d)
    }
    video.onerror = () => { cleanup(); resolve(0) }
    if (typeof source === 'string') video.src = source
    else video.src = URL.createObjectURL(source)
  })
}

export async function generateAndUploadThumbnail(
  source: File | string
): Promise<string | null> {
  try {
    const blob = await generateVideoThumbnail(source)
    const fd = new FormData()
    const file = new File([blob], `auto-thumb-${Date.now()}.jpg`, { type: 'image/jpeg' })
    fd.append('file', file)
    fd.append('type', 'general')
    const res = await fetch('/api/upload', { method: 'POST', body: fd })
    if (!res.ok) return null
    const data = await res.json()
    return data.url || null
  } catch {
    return null
  }
}
