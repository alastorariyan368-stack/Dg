// Simple in-memory cache for frequently accessed data
type CacheEntry<T> = { value: T; expiresAt: number }
const cache = new Map<string, CacheEntry<any>>()

export function getCache<T>(key: string): T | null {
  const entry = cache.get(key)
  if (!entry) return null
  if (Date.now() > entry.expiresAt) {
    cache.delete(key)
    return null
  }
  return entry.value as T
}

export function setCache<T>(key: string, value: T, ttlSeconds: number = 300): T {
  cache.set(key, {
    value,
    expiresAt: Date.now() + ttlSeconds * 1000,
  })
  return value
}

export function clearCache(key: string): void {
  cache.delete(key)
}

export function clearAllCache(): void {
  cache.clear()
}

// Pre-defined cache keys with short TTLs
export const CACHE_KEYS = {
  SETTINGS: 'site:settings', // 5 min
  AI_MODELS: 'ai:models', // 10 min
  ANNOUNCEMENTS: 'announcements', // 5 min
  CATEGORIES: 'categories', // 10 min
} as const
