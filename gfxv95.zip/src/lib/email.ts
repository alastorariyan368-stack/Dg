import nodemailer from 'nodemailer'
import { db } from './db'

export interface MailMessage {
  to: string | string[]
  subject: string
  html: string
  text?: string
}

interface SmtpConfig {
  provider?: string
  host?: string; port?: number; secure?: boolean
  user?: string; pass?: string; from?: string
  fromName?: string; fromAddress?: string
  resendKey?: string
}

// Always persist a copy to the admin inbox (db.sentEmail), regardless of which provider succeeded.
async function recordSent(to: string | string[], subject: string, html: string) {
  try {
    const recipients = Array.isArray(to) ? to : [to]
    for (const r of recipients) {
      await db.sentEmail.create({
        data: { to: String(r).slice(0, 320), subject: subject.slice(0, 500), html: html.slice(0, 100_000) },
      }).catch(() => null)
    }
  } catch { /* non-fatal */ }
}

export async function sendMail(message: MailMessage): Promise<{ ok: boolean; provider?: string; error?: string }> {
  let lastError = ''
  try {
    const settings = await db.siteSettings.findFirst()
    const smtp = (settings?.smtpConfig as SmtpConfig) || {}
    const fromAddr = settings?.fromEmail || smtp.from || process.env.MAIL_FROM || 'GfxStore <onboarding@resend.dev>'
    const gmailUser = (settings as any)?.gmailUser || process.env.GMAIL_USER

    // 1. Gmail App Password (PREFERRED — user wants Gmail-app-password instead of Resend for blasts)
    const gmailAppPass = (settings as any)?.gmailAppPassword || process.env.GMAIL_APP_PASSWORD
    if (gmailUser && gmailAppPass) {
      try {
        const transport = nodemailer.createTransport({
          service: 'gmail',
          auth: { user: gmailUser, pass: gmailAppPass },
        })
        await transport.sendMail({
          from: fromAddr || gmailUser,
          to: Array.isArray(message.to) ? message.to.join(', ') : message.to,
          subject: message.subject,
          html: message.html,
          text: message.text,
        })
        await recordSent(message.to, message.subject, message.html)
        return { ok: true, provider: 'gmail-app-password' }
      } catch (e: any) {
        lastError = `Gmail app password: ${e?.message || e}`
        console.error('Gmail app password failed, trying next provider:', e?.message)
      }
    }

    // 2. Gmail via email-settings page (smtpConfig.provider === 'gmail')
    if (smtp.provider === 'gmail' && smtp.user && smtp.pass) {
      try {
        const transport = nodemailer.createTransport({
          service: 'gmail',
          auth: { user: smtp.user, pass: smtp.pass },
        })
        await transport.sendMail({
          from: smtp.fromAddress || smtp.user,
          to: Array.isArray(message.to) ? message.to.join(', ') : message.to,
          subject: message.subject,
          html: message.html,
          text: message.text,
        })
        await recordSent(message.to, message.subject, message.html)
        return { ok: true, provider: 'gmail-settings' }
      } catch (e: any) {
        lastError = `Gmail (email-settings): ${e?.message || e}`
        console.error('Gmail (email-settings) failed:', e?.message)
      }
    }

    // 3. Gmail OAuth2
    const gmailClientId = (settings as any)?.gmailClientId || process.env.GMAIL_CLIENT_ID
    const gmailClientSecret = (settings as any)?.gmailClientSecret || process.env.GMAIL_CLIENT_SECRET
    const gmailRefreshToken = (settings as any)?.gmailRefreshToken || process.env.GMAIL_REFRESH_TOKEN
    if (gmailUser && gmailClientId && gmailClientSecret && gmailRefreshToken) {
      try {
        const transport = nodemailer.createTransport({
          service: 'gmail',
          auth: {
            type: 'OAuth2',
            user: gmailUser,
            clientId: gmailClientId,
            clientSecret: gmailClientSecret,
            refreshToken: gmailRefreshToken,
          },
        })
        await transport.sendMail({
          from: fromAddr || gmailUser,
          to: Array.isArray(message.to) ? message.to.join(', ') : message.to,
          subject: message.subject,
          html: message.html,
          text: message.text,
        })
        await recordSent(message.to, message.subject, message.html)
        return { ok: true, provider: 'gmail-oauth2' }
      } catch (e: any) {
        lastError = `Gmail OAuth2: ${e?.message || e}`
        console.error('Gmail OAuth2 failed:', e?.message)
      }
    }

    // 4. SMTP fallback
    const host = smtp.host || process.env.SMTP_HOST
    const port = smtp.port || Number(process.env.SMTP_PORT) || 587
    const user = smtp.user || process.env.SMTP_USER
    const pass = smtp.pass || process.env.SMTP_PASS
    if (host && user && pass) {
      try {
        const transport = nodemailer.createTransport({
          host, port, secure: smtp.secure ?? port === 465,
          auth: { user, pass },
        })
        await transport.sendMail({
          from: fromAddr,
          to: Array.isArray(message.to) ? message.to.join(', ') : message.to,
          subject: message.subject,
          html: message.html,
          text: message.text,
        })
        await recordSent(message.to, message.subject, message.html)
        return { ok: true, provider: 'smtp' }
      } catch (e: any) {
        lastError = `SMTP: ${e?.message || e}`
        console.error('SMTP failed:', e?.message)
      }
    }

    // 5. Resend (last resort — admin asked to AVOID Resend for blasts, so we keep it last)
    const resendKey = settings?.resendApiKey || process.env.RESEND_API_KEY
    if (resendKey) {
      try {
        const recipients = Array.isArray(message.to) ? message.to : [message.to]
        for (let i = 0; i < recipients.length; i += 50) {
          const chunk = recipients.slice(i, i + 50)
          const res = await fetch('https://api.resend.com/emails', {
            method: 'POST',
            headers: { Authorization: `Bearer ${resendKey}`, 'Content-Type': 'application/json' },
            body: JSON.stringify({
              from: fromAddr,
              to: chunk,
              subject: message.subject,
              html: message.html,
              text: message.text,
            }),
          })
          if (!res.ok) {
            const body = await res.text().catch(() => '')
            throw new Error(`Resend HTTP ${res.status}: ${body.slice(0, 200)}`)
          }
        }
        await recordSent(message.to, message.subject, message.html)
        return { ok: true, provider: 'resend' }
      } catch (e: any) {
        lastError = `Resend: ${e?.message || e}`
        console.error('Resend failed:', e?.message)
      }
    }

    // Even if all providers failed, log the attempt to the admin inbox so admins can recover codes
    await recordSent(message.to, `[FAILED] ${message.subject}`, message.html)

    return {
      ok: false,
      error: lastError || 'No email provider configured. Add a Gmail App Password (preferred), Gmail OAuth2, SMTP, or Resend key in Admin → Email settings.',
    }
  } catch (e: any) {
    return { ok: false, error: e?.message || 'Email send failed' }
  }
}

export function announcementEmailHtml(title: string, content: string, siteName = 'GfxStore') {
  const safe = (s: string) => s.replace(/[<>]/g, (c) => ({ '<': '&lt;', '>': '&gt;' }[c] as string))
  return `<!doctype html><html><body style="font-family:Inter,Arial,sans-serif;background:#0a0a12;color:#fff;padding:0;margin:0;">
  <div style="max-width:560px;margin:0 auto;padding:32px 16px;">
    <div style="background:linear-gradient(135deg,#7c3aed,#06b6d4);padding:1px;border-radius:18px;">
      <div style="background:#0f0f1a;border-radius:17px;padding:28px;">
        <div style="font-size:12px;letter-spacing:2px;color:#a78bfa;text-transform:uppercase;margin-bottom:8px;">📢 ${safe(siteName)} announcement</div>
        <h1 style="color:#fff;font-size:22px;margin:0 0 16px;">${safe(title)}</h1>
        <div style="color:#cbd5e1;font-size:15px;line-height:1.6;white-space:pre-wrap;">${safe(content)}</div>
        <div style="margin-top:28px;font-size:12px;color:#64748b;">— The ${safe(siteName)} team</div>
      </div>
    </div>
  </div>
</body></html>`
}

export function otpEmailHtml(otp: string, username: string, siteName = 'GfxStore') {
  return `<!doctype html><html><body style="font-family:Inter,Arial,sans-serif;background:#0a0a12;color:#fff;padding:0;margin:0;">
  <div style="max-width:480px;margin:0 auto;padding:32px 16px;">
    <div style="background:linear-gradient(135deg,#7c3aed,#06b6d4);padding:1px;border-radius:18px;">
      <div style="background:#0f0f1a;border-radius:17px;padding:32px;text-align:center;">
        <div style="font-size:40px;margin-bottom:8px;">🔐</div>
        <h1 style="color:#fff;font-size:22px;margin:0 0 8px;">Verify Your Email</h1>
        <p style="color:#94a3b8;margin:0 0 28px;font-size:15px;">Hi <strong>${username}</strong>, enter this code to complete your registration:</p>
        <div style="background:linear-gradient(135deg,#7c3aed22,#06b6d422);border:1px solid #7c3aed44;border-radius:12px;padding:20px;margin:0 0 24px;">
          <div style="font-size:40px;font-weight:900;letter-spacing:8px;color:#a78bfa;font-family:monospace;">${otp}</div>
        </div>
        <p style="color:#64748b;font-size:13px;margin:0;">This code expires in <strong style="color:#94a3b8;">10 minutes</strong>.<br>If you didn't request this, ignore this email.</p>
        <div style="margin-top:24px;padding-top:20px;border-top:1px solid #ffffff10;font-size:12px;color:#64748b;">— The ${siteName} team</div>
      </div>
    </div>
  </div>
</body></html>`
}
