export type GfxPanelConfig = {
  gfxPanelUrl?: string | null
  gfxPanelApiKey?: string | null
  gfxDefaultNodeId?: string | null
  gfxDefaultOs?: string | null
  gfxDefaultUserId?: string | null
}

export function isGfxConfigured(config?: GfxPanelConfig | null) {
  return !!(config?.gfxPanelUrl && config?.gfxPanelApiKey)
}

function baseUrl(panelUrl: string) {
  return panelUrl.replace(/\/$/, '')
}

export async function gfxPanelRequest(config: GfxPanelConfig, path: string, init: RequestInit = {}) {
  if (!config.gfxPanelUrl || !config.gfxPanelApiKey) {
    throw new Error('GFX Panel URL and API key are required')
  }

  const res = await fetch(`${baseUrl(config.gfxPanelUrl)}/api/v1${path}`, {
    ...init,
    headers: {
      Accept: 'application/json',
      'Content-Type': 'application/json',
      'X-API-Key': config.gfxPanelApiKey,
      ...(init.headers || {}),
    },
  })

  const data = await res.json().catch(() => ({}))
  return { ok: res.ok, status: res.status, data }
}

export async function getGfxInfo(config: GfxPanelConfig) {
  const [info, health, nodes, vps, stats] = await Promise.allSettled([
    gfxPanelRequest(config, '/info'),
    gfxPanelRequest(config, '/health'),
    gfxPanelRequest(config, '/nodes'),
    gfxPanelRequest(config, '/vps'),
    gfxPanelRequest(config, '/system/stats'),
  ])

  return {
    info: info.status === 'fulfilled' ? info.value : null,
    health: health.status === 'fulfilled' ? health.value : null,
    nodes: nodes.status === 'fulfilled' ? nodes.value : null,
    vps: vps.status === 'fulfilled' ? vps.value : null,
    stats: stats.status === 'fulfilled' ? stats.value : null,
  }
}

export async function createGfxVps(config: GfxPanelConfig, payload: {
  hostname: string
  userId?: string | number
  nodeId?: string | number
  osVersion?: string
  cpu: string | number
  ram: string | number
  storage: string | number
}) {
  return gfxPanelRequest(config, '/vps', {
    method: 'POST',
    body: JSON.stringify({
      hostname: payload.hostname,
      user_id: Number(payload.userId || config.gfxDefaultUserId || 1),
      node_id: Number(payload.nodeId || config.gfxDefaultNodeId || 1),
      os_version: payload.osVersion || config.gfxDefaultOs || 'ubuntu:22.04',
      cpu: Number(payload.cpu),
      ram: Number(payload.ram),
      storage: Number(payload.storage),
    }),
  })
}

export async function ensureGfxUser(config: GfxPanelConfig, user: { username: string; email: string }) {
  const usersRes = await gfxPanelRequest(config, '/users')
  const users = usersRes.data?.users || usersRes.data?.data || []
  const existing = Array.isArray(users)
    ? users.find((item: any) => String(item.email || '').toLowerCase() === user.email.toLowerCase())
    : null

  if (existing?.id) {
    return { userId: existing.id, password: null, created: false }
  }

  const password = Math.random().toString(36).slice(2, 10) + Math.random().toString(36).slice(2, 6).toUpperCase() + '!1'
  const username = user.username.replace(/[^a-z0-9_]/gi, '_').toLowerCase().slice(0, 24) || user.email.split('@')[0]
  const createRes = await gfxPanelRequest(config, '/users', {
    method: 'POST',
    body: JSON.stringify({
      username,
      email: user.email,
      password,
      is_admin: false,
    }),
  })

  if (!createRes.ok || createRes.data?.success === false) {
    throw new Error(createRes.data?.error || JSON.stringify(createRes.data) || 'Failed to create GFX Panel user')
  }

  return { userId: createRes.data?.user_id || createRes.data?.user?.id, password, created: true }
}
