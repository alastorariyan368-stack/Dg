import { writeFile, mkdir } from 'fs/promises'
import { existsSync } from 'fs'
import { join } from 'path'
import crypto from 'crypto'

export type ImagePurpose = 'image' | 'thumbnail' | 'video-thumbnail' | 'avatar' | 'banner'

export interface ImageGenOptions {
  prompt: string
  size?: string
  purpose?: ImagePurpose
  settings?: any
}

export interface ImageGenResult {
  url: string
  imageUrl: string
  model: string
  provider: string
  purpose: ImagePurpose
}

function sizeFor(purpose: ImagePurpose, requested?: string): string {
  if (requested && requested.includes('x')) return requested
  switch (purpose) {
    case 'thumbnail':
    case 'video-thumbnail':
    case 'banner':
      return '1536x1024'
    case 'avatar':
      return '1024x1024'
    default:
      return '1024x1024'
  }
}

function dimsFromSize(size: string): { width: number; height: number } {
  const [w, h] = size.split('x').map((n) => parseInt(n, 10))
  return { width: w || 1024, height: h || 1024 }
}

async function persistImage(buffer: Buffer, ext = 'png'): Promise<string> {
  const dir = join(process.cwd(), 'public', 'uploads', 'ai')
  if (!existsSync(dir)) await mkdir(dir, { recursive: true })
  const name = `${crypto.randomUUID()}.${ext}`
  await writeFile(join(dir, name), buffer)
  return `/uploads/ai/${name}`
}

async function watermarkImage(buffer: Buffer): Promise<Buffer> {
  try {
    const sharp = (await import('sharp')).default
    const meta = await sharp(buffer).metadata()
    const w = meta.width || 1024
    const h = meta.height || 1024
    const fontSize = Math.max(18, Math.round(w / 32))
    const padX = Math.round(w / 40)
    const padY = Math.round(fontSize * 0.6)
    const text = 'GfxStore'
    const svg = `<svg width="${w}" height="${h}" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="0">
      <stop offset="0%" stop-color="#a78bfa"/><stop offset="100%" stop-color="#22d3ee"/>
    </linearGradient>
  </defs>
  <g transform="translate(${padX}, ${h - padY - fontSize})">
    <rect x="-10" y="-${Math.round(fontSize * 0.25)}" rx="10" ry="10" width="${fontSize * (text.length * 0.62) + 20}" height="${fontSize * 1.4}" fill="rgba(0,0,0,0.55)"/>
    <text x="0" y="${fontSize}" font-family="Inter,Arial,sans-serif" font-weight="800" font-size="${fontSize}" fill="url(#g)" letter-spacing="1">${text}</text>
  </g>
</svg>`
    return await sharp(buffer).composite([{ input: Buffer.from(svg) }]).png().toBuffer()
  } catch {
    return buffer
  }
}

type ProviderResult = { ok: boolean; buf?: Buffer; error?: string }

async function bufferFromUrl(url: string): Promise<Buffer | null> {
  try {
    const r = await fetch(url)
    if (!r.ok) return null
    return Buffer.from(await r.arrayBuffer())
  } catch { return null }
}

// ----------------- Providers -----------------

async function tryOpenAI(baseUrl: string, apiKey: string, model: string, prompt: string, size: string): Promise<ProviderResult> {
  try {
    const body: any = { model, prompt, size, n: 1 }
    if (model === 'gpt-image-1') body.quality = 'auto'
    else { body.quality = 'standard'; body.response_format = 'b64_json' }
    const res = await fetch(`${baseUrl}/images/generations`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    })
    const data = await res.json().catch(() => ({}))
    if (!res.ok) return { ok: false, error: data?.error?.message || `HTTP ${res.status}` }
    const item = data?.data?.[0]
    if (!item) return { ok: false, error: 'Empty response' }
    if (item.b64_json) return { ok: true, buf: Buffer.from(item.b64_json, 'base64') }
    if (item.url) {
      const buf = await bufferFromUrl(item.url)
      if (buf) return { ok: true, buf }
    }
    return { ok: false, error: 'No image data' }
  } catch (e: any) { return { ok: false, error: e?.message || 'OpenAI failed' } }
}

async function tryGeminiImagen(apiKey: string, prompt: string): Promise<ProviderResult> {
  try {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/imagen-3.0-generate-002:predict?key=${apiKey}`
    const res = await fetch(url, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ instances: [{ prompt }], parameters: { sampleCount: 1 } }),
    })
    const data: any = await res.json().catch(() => ({}))
    if (!res.ok) return { ok: false, error: data?.error?.message || `HTTP ${res.status}` }
    const b64 = data?.predictions?.[0]?.bytesBase64Encoded
    if (!b64) return { ok: false, error: 'No image returned' }
    return { ok: true, buf: Buffer.from(b64, 'base64') }
  } catch (e: any) { return { ok: false, error: e?.message || 'Gemini Imagen failed' } }
}

async function tryNanoBanana(apiKey: string, prompt: string): Promise<ProviderResult> {
  try {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image-preview:generateContent?key=${apiKey}`
    const res = await fetch(url, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] }),
    })
    const data: any = await res.json().catch(() => ({}))
    if (!res.ok) return { ok: false, error: data?.error?.message || `HTTP ${res.status}` }
    const parts = data?.candidates?.[0]?.content?.parts || []
    for (const p of parts) {
      const b64 = p?.inlineData?.data || p?.inline_data?.data
      if (b64) return { ok: true, buf: Buffer.from(b64, 'base64') }
    }
    return { ok: false, error: 'Nano-Banana returned no image' }
  } catch (e: any) { return { ok: false, error: e?.message || 'Nano-Banana failed' } }
}

async function tryStability(apiKey: string, prompt: string, size: string): Promise<ProviderResult> {
  try {
    const { width, height } = dimsFromSize(size)
    const form = new FormData()
    form.append('prompt', prompt)
    form.append('output_format', 'png')
    form.append('aspect_ratio', width >= height ? '16:9' : '1:1')
    const res = await fetch('https://api.stability.ai/v2beta/stable-image/generate/core', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, Accept: 'image/*' },
      body: form as any,
    })
    if (!res.ok) {
      const txt = await res.text().catch(() => '')
      return { ok: false, error: `HTTP ${res.status} ${txt.slice(0, 200)}` }
    }
    return { ok: true, buf: Buffer.from(await res.arrayBuffer()) }
  } catch (e: any) { return { ok: false, error: e?.message || 'Stability failed' } }
}

async function tryReplicate(apiKey: string, prompt: string, size: string): Promise<ProviderResult> {
  try {
    const { width, height } = dimsFromSize(size)
    const aspect = width >= height ? '16:9' : '1:1'
    const create = await fetch('https://api.replicate.com/v1/models/black-forest-labs/flux-schnell/predictions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json', Prefer: 'wait' },
      body: JSON.stringify({ input: { prompt, aspect_ratio: aspect, output_format: 'png', num_outputs: 1 } }),
    })
    const data: any = await create.json().catch(() => ({}))
    if (!create.ok) return { ok: false, error: data?.detail || `HTTP ${create.status}` }
    let output = data?.output
    let status = data?.status
    let getUrl = data?.urls?.get
    let tries = 0
    while (status && status !== 'succeeded' && status !== 'failed' && tries < 30) {
      await new Promise((r) => setTimeout(r, 2000))
      const poll = await fetch(getUrl, { headers: { Authorization: `Bearer ${apiKey}` } })
      const pd: any = await poll.json().catch(() => ({}))
      status = pd?.status; output = pd?.output
      tries++
    }
    if (status === 'failed') return { ok: false, error: 'Replicate prediction failed' }
    const url = Array.isArray(output) ? output[0] : output
    if (!url) return { ok: false, error: 'No output URL' }
    const buf = await bufferFromUrl(url)
    return buf ? { ok: true, buf } : { ok: false, error: 'Failed to fetch output' }
  } catch (e: any) { return { ok: false, error: e?.message || 'Replicate failed' } }
}

async function tryHuggingFace(apiKey: string, prompt: string): Promise<ProviderResult> {
  try {
    const models = [
      'black-forest-labs/FLUX.1-schnell',
      'stabilityai/stable-diffusion-xl-base-1.0',
      'runwayml/stable-diffusion-v1-5',
    ]
    let lastErr = 'HF failed'
    for (const model of models) {
      const res = await fetch(`https://api-inference.huggingface.co/models/${model}`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json', Accept: 'image/png' },
        body: JSON.stringify({ inputs: prompt }),
      })
      if (res.ok) {
        const ct = res.headers.get('content-type') || ''
        if (ct.startsWith('image/')) return { ok: true, buf: Buffer.from(await res.arrayBuffer()) }
        const txt = await res.text().catch(() => '')
        lastErr = `${model}: ${txt.slice(0, 120)}`
      } else {
        const txt = await res.text().catch(() => '')
        lastErr = `${model}: HTTP ${res.status} ${txt.slice(0, 120)}`
      }
    }
    return { ok: false, error: lastErr }
  } catch (e: any) { return { ok: false, error: e?.message || 'HF failed' } }
}

async function tryTogether(apiKey: string, prompt: string, size: string): Promise<ProviderResult> {
  try {
    const { width, height } = dimsFromSize(size)
    const res = await fetch('https://api.together.xyz/v1/images/generations', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'black-forest-labs/FLUX.1-schnell-Free',
        prompt, width, height, steps: 4, n: 1, response_format: 'b64_json',
      }),
    })
    const data: any = await res.json().catch(() => ({}))
    if (!res.ok) return { ok: false, error: data?.error?.message || `HTTP ${res.status}` }
    const item = data?.data?.[0]
    if (item?.b64_json) return { ok: true, buf: Buffer.from(item.b64_json, 'base64') }
    if (item?.url) {
      const buf = await bufferFromUrl(item.url)
      if (buf) return { ok: true, buf }
    }
    return { ok: false, error: 'No image data' }
  } catch (e: any) { return { ok: false, error: e?.message || 'Together failed' } }
}

async function tryPollinations(prompt: string, size: string, model = 'flux'): Promise<ProviderResult> {
  try {
    const { width, height } = dimsFromSize(size)
    const seed = Math.floor(Math.random() * 1000000)
    const url = `https://image.pollinations.ai/prompt/${encodeURIComponent(prompt)}?width=${width}&height=${height}&nologo=true&enhance=true&model=${model}&seed=${seed}`
    const buf = await bufferFromUrl(url)
    return buf ? { ok: true, buf } : { ok: false, error: 'Pollinations fetch failed' }
  } catch (e: any) { return { ok: false, error: e?.message || 'Pollinations failed' } }
}

async function tryPixabay(apiKey: string, prompt: string): Promise<ProviderResult> {
  try {
    const url = `https://pixabay.com/api/?key=${apiKey}&q=${encodeURIComponent(prompt)}&image_type=photo&per_page=3&safesearch=true`
    const res = await fetch(url)
    const data: any = await res.json().catch(() => ({}))
    if (!res.ok) return { ok: false, error: `HTTP ${res.status}` }
    const hit = data?.hits?.[0]
    if (!hit?.largeImageURL) return { ok: false, error: 'No results' }
    const buf = await bufferFromUrl(hit.largeImageURL)
    return buf ? { ok: true, buf } : { ok: false, error: 'Pixabay download failed' }
  } catch (e: any) { return { ok: false, error: e?.message || 'Pixabay failed' } }
}

async function tryUnsplash(apiKey: string, prompt: string): Promise<ProviderResult> {
  try {
    const url = `https://api.unsplash.com/photos/random?query=${encodeURIComponent(prompt)}&orientation=landscape`
    const res = await fetch(url, { headers: { Authorization: `Client-ID ${apiKey}` } })
    const data: any = await res.json().catch(() => ({}))
    if (!res.ok) return { ok: false, error: data?.errors?.[0] || `HTTP ${res.status}` }
    const link = data?.urls?.regular || data?.urls?.full
    if (!link) return { ok: false, error: 'No image' }
    const buf = await bufferFromUrl(link)
    return buf ? { ok: true, buf } : { ok: false, error: 'Unsplash download failed' }
  } catch (e: any) { return { ok: false, error: e?.message || 'Unsplash failed' } }
}

function getOpenAIKey(settings: any): { key: string; baseUrl: string } | null {
  const userKey = settings?.openaiApiKey || settings?.aiApiKey || process.env.OPENAI_API_KEY
  if (userKey) return { key: userKey, baseUrl: 'https://api.openai.com/v1' }
  const replitKey = process.env.AI_INTEGRATIONS_OPENAI_API_KEY
  const replitUrl = process.env.AI_INTEGRATIONS_OPENAI_BASE_URL
  if (replitKey && replitUrl) return { key: replitKey, baseUrl: replitUrl }
  return null
}

export async function callAiImage(options: ImageGenOptions): Promise<ImageGenResult> {
  const { prompt, size, purpose = 'image', settings } = options
  let finalPrompt = prompt.trim()
  
  if (purpose === 'thumbnail' || purpose === 'video-thumbnail') {
    finalPrompt = `Hyper-professional viral YouTube thumbnail of: ${finalPrompt}. Cinematic lighting with strong rim-light, ultra-sharp 8K detail, dramatic high-contrast color grade (saturated reds/cyans/yellows), one bold focal subject, expressive face/emotion, depth-of-field background blur, MrBeast-style composition, magazine-cover quality, hyper-realistic, trending on ArtStation, 16:9 wide composition, leave clear negative space on the left for title text, NO text, NO watermark, NO logo.`
  } else if (purpose === 'banner') {
    finalPrompt = `Wide cinematic banner image of: ${finalPrompt}. Premium production quality, ultra-detailed 8K, dramatic lighting, professional color grade, hero composition, no text.`
  } else if (purpose === 'avatar') {
    finalPrompt = `Professional avatar / profile portrait of: ${finalPrompt}. Studio lighting, sharp focus, clean background, magazine-cover quality, ultra-detailed.`
  } else {
    finalPrompt = `${finalPrompt}. Professional, ultra-sharp 8K detail, cinematic lighting, vibrant color grade, magazine-quality composition, hyper-realistic, no watermark.`
  }

  const finalSize = sizeFor(purpose, size)
  const errors: string[] = []

  const finalize = async (buf: Buffer, model: string, provider: string) => {
    const watermarked = await watermarkImage(buf)
    const url = await persistImage(watermarked, 'png')
    return { url, imageUrl: url, model, purpose, provider }
  }

  const openaiCreds = getOpenAIKey(settings)
  const geminiKey = settings?.geminiApiKey || process.env.GEMINI_API_KEY
  const bananaKey = settings?.bananaApiKey || geminiKey
  const stabilityKey = settings?.stabilityApiKey || process.env.STABILITY_API_KEY
  const replicateKey = settings?.replicateApiKey || process.env.REPLICATE_API_TOKEN
  const hfKey = settings?.huggingfaceApiKey || process.env.HUGGINGFACE_API_KEY
  const togetherKey = settings?.togetherApiKey || process.env.TOGETHER_API_KEY
  const pixabayKey = settings?.pixabayApiKey || process.env.PIXABAY_API_KEY
  const unsplashKey = settings?.unsplashApiKey || process.env.UNSPLASH_ACCESS_KEY

  type Step = { name: string; provider: string; run: () => Promise<ProviderResult> }
  const steps: Step[] = []
  if (openaiCreds) {
    steps.push({ name: 'gpt-image-1', provider: 'openai', run: () => tryOpenAI(openaiCreds.baseUrl, openaiCreds.key, 'gpt-image-1', finalPrompt, finalSize) })
    steps.push({ name: 'dall-e-3', provider: 'openai', run: () => tryOpenAI(openaiCreds.baseUrl, openaiCreds.key, 'dall-e-3', finalPrompt, finalSize) })
  }
  if (bananaKey) steps.push({ name: 'nano-banana', provider: 'gemini', run: () => tryNanoBanana(bananaKey, finalPrompt) })
  if (geminiKey) steps.push({ name: 'imagen-3', provider: 'gemini', run: () => tryGeminiImagen(geminiKey, finalPrompt) })
  if (togetherKey) steps.push({ name: 'flux-schnell', provider: 'together', run: () => tryTogether(togetherKey, finalPrompt, finalSize) })
  if (stabilityKey) steps.push({ name: 'stable-image-core', provider: 'stability', run: () => tryStability(stabilityKey, finalPrompt, finalSize) })
  if (replicateKey) steps.push({ name: 'flux-schnell', provider: 'replicate', run: () => tryReplicate(replicateKey, finalPrompt, finalSize) })
  if (hfKey) steps.push({ name: 'flux/sdxl', provider: 'huggingface', run: () => tryHuggingFace(hfKey, finalPrompt) })
  
  // Always-available free fallback
  steps.push({ name: 'pollinations', provider: 'pollinations', run: () => tryPollinations(finalPrompt, finalSize) })
  
  if (pixabayKey) steps.push({ name: 'pixabay-stock', provider: 'pixabay', run: () => tryPixabay(pixabayKey, finalPrompt) })
  if (unsplashKey) steps.push({ name: 'unsplash-stock', provider: 'unsplash', run: () => tryUnsplash(unsplashKey, finalPrompt) })

  for (const s of steps) {
    const r = await s.run()
    if (r.ok && r.buf) return finalize(r.buf, s.name, s.provider)
    errors.push(`${s.provider}/${s.name}: ${r.error}`)
  }

  throw new Error(`Image generation failed: ${errors.slice(-1)[0] || 'Unknown error'}`)
}
