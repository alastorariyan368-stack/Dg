import { db } from '@/lib/db'

type ProviderId = 'openai' | 'anthropic' | 'google' | 'deepseek' | 'openrouter' | 'zai' | 'xai' | 'groq' | 'pollinations'

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant'
  content: string
}

function detectProvider(model: string): ProviderId {
  const m = (model || '').toLowerCase()
  if (m.startsWith('claude')) return 'anthropic'
  if (m.startsWith('gemini')) return 'google'
  if (m.startsWith('deepseek')) return 'deepseek'
  if (m.startsWith('grok')) return 'xai'
  if (m.startsWith('llama') || m.startsWith('mixtral') || m.startsWith('gemma')) return 'groq'
  if (m.startsWith('z-ai/')) return 'zai'
  if (m.includes('/')) return 'openrouter'
  return 'openai'
}

function getKeyFor(provider: ProviderId, settings: any): string | null | undefined {
  switch (provider) {
    case 'openai':
      return settings?.openaiApiKey || settings?.aiApiKey || process.env.OPENAI_API_KEY
        || process.env.AI_INTEGRATIONS_OPENAI_API_KEY
    case 'anthropic': return settings?.anthropicApiKey
    case 'google': return settings?.geminiApiKey || process.env.GEMINI_API_KEY
    case 'deepseek': return settings?.deepseekApiKey
    case 'openrouter': return settings?.openrouterApiKey
    case 'zai': return settings?.zaiApiKey || process.env.ZAI_API_KEY
    case 'xai': return settings?.xaiApiKey
    case 'groq': return settings?.groqApiKey
    case 'pollinations': return 'free' // no key needed
  }
}

function getOpenAiBase(): string {
  if (process.env.AI_INTEGRATIONS_OPENAI_BASE_URL && !process.env.OPENAI_API_KEY) {
    return process.env.AI_INTEGRATIONS_OPENAI_BASE_URL
  }
  return 'https://api.openai.com/v1'
}

async function callOpenAICompatible(
  baseUrl: string, apiKey: string, model: string, systemPrompt: string,
  cleanMessages: ChatMessage[], maxTokens: number, extraHeaders: Record<string, string> = {}
) {
  const res = await fetch(`${baseUrl}/chat/completions`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json', ...extraHeaders },
    body: JSON.stringify({
      model,
      messages: [{ role: 'system', content: systemPrompt }, ...cleanMessages],
      max_tokens: maxTokens,
      temperature: 0.7,
    }),
  })
  const data = await res.json().catch(() => ({}))
  return { res, reply: data?.choices?.[0]?.message?.content || '', errorMsg: data?.error?.message || data?.message }
}

// Pollinations.ai free text API - no key required
async function callPollinations(systemPrompt: string, messages: ChatMessage[], maxTokens: number): Promise<string> {
  const allMessages = [
    { role: 'system', content: systemPrompt },
    ...messages.map(m => ({ role: m.role, content: m.content }))
  ]
  
  // Use Pollinations OpenAI-compatible endpoint
  const res = await fetch('https://text.pollinations.ai/openai', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: 'openai-large',
      messages: allMessages,
      max_tokens: maxTokens,
      temperature: 0.7,
      private: true,
    }),
  })
  
  if (!res.ok) {
    const txt = await res.text().catch(() => '')
    throw new Error(`Pollinations API error ${res.status}: ${txt.slice(0, 200)}`)
  }
  
  const data = await res.json().catch(() => ({}))
  const reply = data?.choices?.[0]?.message?.content || ''
  if (!reply) throw new Error('No reply from Pollinations')
  return reply
}

/**
 * Run a chat completion against the user's preferred AI model, with automatic
 * fallback to any other configured provider on failure.
 * Always falls back to Pollinations (free, no API key needed) as final resort.
 *
 * Returns { reply, provider, model } on success, or throws on total failure.
 */
export async function callAiText(opts: {
  systemPrompt: string
  messages: ChatMessage[]
  maxTokens?: number
  model?: string
  json?: boolean
}): Promise<{ reply: string; provider: string; model: string }> {
  const settings = await db.siteSettings.findFirst()
  const defaultModel = opts.model || (settings as any)?.aiModel || 'gpt-4o-mini'
  const maxTokens = opts.maxTokens ?? ((settings as any)?.lowTokenMode ? 500 : 1200)

  const cleanMessages: ChatMessage[] = opts.messages
    .filter(m => m && typeof m.content === 'string' && m.content.trim().length > 0)
    .map(m => ({
      role: m.role === 'assistant' ? 'assistant' : (m.role === 'system' ? 'system' : 'user'),
      content: String(m.content).slice(0, 8000)
    }))

  const primary = detectProvider(defaultModel)
  const fallbackOrder: { provider: ProviderId; model: string }[] = [{ provider: primary, model: defaultModel }]

  const fallbackModels: Partial<Record<ProviderId, string>> = {
    openai: 'gpt-4o-mini',
    anthropic: 'claude-3-5-haiku-20241022',
    google: 'gemini-1.5-flash',
    deepseek: 'deepseek-chat',
    openrouter: 'openai/gpt-4o-mini',
    zai: 'z-ai/glm-4.5',
    xai: 'grok-2-latest',
    groq: 'llama-3.1-8b-instant',
  }
  const allProviders: ProviderId[] = ['openai', 'anthropic', 'google', 'deepseek', 'openrouter', 'zai', 'xai', 'groq']
  for (const p of allProviders) {
    if (p === primary) continue
    if (getKeyFor(p, settings)) fallbackOrder.push({ provider: p, model: fallbackModels[p] || p })
  }
  // Always add Pollinations as final free fallback (no API key needed)
  fallbackOrder.push({ provider: 'pollinations', model: 'openai-large' })

  let lastError = 'AI text generation failed'

  for (const { provider, model } of fallbackOrder) {
    try {
      // Pollinations - free, no key needed
      if (provider === 'pollinations') {
        const reply = await callPollinations(opts.systemPrompt, cleanMessages, maxTokens)
        if (reply) return { reply, provider: 'pollinations', model: 'openai-large' }
        continue
      }

      const apiKey = getKeyFor(provider, settings)
      if (!apiKey) { lastError = `No API key for ${provider}`; continue }

      let reply = ''
      let res: Response | null = null
      let errMsg = ''

      if (provider === 'openai') {
        const out = await callOpenAICompatible(getOpenAiBase(), apiKey, model, opts.systemPrompt, cleanMessages, maxTokens)
        res = out.res; reply = out.reply; errMsg = out.errorMsg
      } else if (provider === 'deepseek') {
        const out = await callOpenAICompatible('https://api.deepseek.com/v1', apiKey, model, opts.systemPrompt, cleanMessages, maxTokens)
        res = out.res; reply = out.reply; errMsg = out.errorMsg
      } else if (provider === 'openrouter') {
        const out = await callOpenAICompatible('https://openrouter.ai/api/v1', apiKey, model, opts.systemPrompt, cleanMessages, maxTokens, {
          'HTTP-Referer': 'https://gfxstore.app', 'X-Title': 'GfxStore',
        })
        res = out.res; reply = out.reply; errMsg = out.errorMsg
      } else if (provider === 'zai') {
        const out = await callOpenAICompatible('https://api.z.ai/v1', apiKey, model, opts.systemPrompt, cleanMessages, maxTokens)
        res = out.res; reply = out.reply; errMsg = out.errorMsg
      } else if (provider === 'xai') {
        const out = await callOpenAICompatible('https://api.x.ai/v1', apiKey, model, opts.systemPrompt, cleanMessages, maxTokens)
        res = out.res; reply = out.reply; errMsg = out.errorMsg
      } else if (provider === 'groq') {
        const out = await callOpenAICompatible('https://api.groq.com/openai/v1', apiKey, model, opts.systemPrompt, cleanMessages, maxTokens)
        res = out.res; reply = out.reply; errMsg = out.errorMsg
      } else if (provider === 'anthropic') {
        res = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST',
          headers: { 'x-api-key': apiKey, 'Content-Type': 'application/json', 'anthropic-version': '2023-06-01' },
          body: JSON.stringify({ model, max_tokens: maxTokens, temperature: 0.7, system: opts.systemPrompt, messages: cleanMessages }),
        })
        const data: any = await res.json().catch(() => ({}))
        reply = data?.content?.[0]?.text || ''
        errMsg = data?.error?.message
      } else if (provider === 'google') {
        const geminiBody = {
          contents: [{ role: 'user', parts: [{ text: opts.systemPrompt + '\n\n' + cleanMessages.map(m => `${m.role}: ${m.content}`).join('\n') }] }],
          generationConfig: { temperature: 0.7, maxOutputTokens: maxTokens },
        }
        res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`, {
          method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(geminiBody),
        })
        const data: any = await res.json().catch(() => ({}))
        reply = data?.candidates?.[0]?.content?.parts?.[0]?.text || ''
        errMsg = data?.error?.message
      }

      if (res && res.ok && reply) {
        return { reply, provider, model }
      }
      lastError = errMsg || `${provider} returned ${res?.status || 'unknown error'}`
    } catch (e: any) {
      lastError = e?.message || `${provider} request failed`
    }
  }

  throw new Error(lastError)
}

/**
 * Robust JSON extraction — handles plain JSON, fenced ```json blocks, and any
 * leading/trailing prose the model adds.
 */
export function extractJson<T = any>(text: string): T | null {
  if (!text) return null
  const fence = text.match(/```(?:json)?\s*([\s\S]*?)```/i)
  const candidate = fence ? fence[1] : text
  const first = candidate.indexOf('{')
  const last = candidate.lastIndexOf('}')
  if (first === -1 || last === -1 || last < first) return null
  const slice = candidate.slice(first, last + 1)
  try { return JSON.parse(slice) as T } catch {}
  const fa = candidate.indexOf('[')
  const la = candidate.lastIndexOf(']')
  if (fa !== -1 && la > fa) {
    try { return JSON.parse(candidate.slice(fa, la + 1)) as T } catch {}
  }
  return null
}
