import { db } from '@/lib/db'

export function parseBadgeIds(raw: unknown): string[] {
  if (Array.isArray(raw)) return raw.filter((x) => typeof x === 'string')
  if (typeof raw === 'string') {
    try {
      const parsed = JSON.parse(raw)
      if (Array.isArray(parsed)) return parsed.filter((x) => typeof x === 'string')
    } catch {
      // ignore
    }
  }
  return []
}

export async function getBadgeDetailsByIds(ids: string[]) {
  const uniqueIds = Array.from(new Set(ids)).filter(Boolean)
  if (uniqueIds.length === 0) return []

  const badges = await db.badge.findMany({
    where: { id: { in: uniqueIds }, isActive: true },
    select: { id: true, name: true, icon: true, color: true, description: true },
  })

  const index = new Map(uniqueIds.map((id, i) => [id, i]))
  return badges.sort((a: any, b: any) => (index.get(a.id) ?? 0) - (index.get(b.id) ?? 0))
}

