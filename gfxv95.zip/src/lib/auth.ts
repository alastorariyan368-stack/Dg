import { NextAuthOptions } from 'next-auth'
import CredentialsProvider from 'next-auth/providers/credentials'
import GoogleProvider from 'next-auth/providers/google'
import DiscordProvider from 'next-auth/providers/discord'
import { PrismaAdapter } from '@next-auth/prisma-adapter'
import { db } from '@/lib/db'
import bcrypt from 'bcryptjs'
import { logActivity } from '@/lib/log-activity'

function generateUsername(name: string, email: string) {
  const base = (name || (email ? email.split('@')[0] : 'user') || 'user')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '')
    .slice(0, 16) || 'user'
  return base + Math.floor(Math.random() * 9000 + 1000)
}

function ipFromReq(req: any): string | undefined {
  if (!req) return undefined
  const cleanIp = (raw?: string | null): string | undefined => {
    if (!raw) return undefined
    let ip = String(raw).trim()
    if (ip.toLowerCase().startsWith('::ffff:')) ip = ip.slice(7)
    if (!ip || ip === '::1' || ip === '127.0.0.1' || ip === '0.0.0.0') return undefined
    return ip
  }
  try {
    const h = req.headers || {}
    const get = (k: string) => (typeof h.get === 'function' ? h.get(k) : h[k])
    // Trusted proxy/edge headers — these are the user's real (phone) IP
    const cf = cleanIp(get('cf-connecting-ip')); if (cf) return cf
    const tci = cleanIp(get('true-client-ip')); if (tci) return tci
    const xff = get('x-forwarded-for')
    if (xff) {
      const first = cleanIp(String(xff).split(',')[0]); if (first) return first
    }
    const xreal = cleanIp(get('x-real-ip')); if (xreal) return xreal
    return undefined
  } catch {
    return undefined
  }
}

// ─── Build providers (Credentials always; OAuth from DB SiteSettings + env fallback) ─────
async function buildProviders() {
  const providers: any[] = [
    CredentialsProvider({
      name: 'credentials',
      credentials: {
        email: { label: 'Email', type: 'email' },
        password: { label: 'Password', type: 'password' }
      },
      async authorize(credentials, req) {
        if (!credentials?.email || !credentials?.password) return null
        try {
          const loginId = credentials.email.trim()
          const user = await db.user.findFirst({
            where: {
              OR: [
                { email: { equals: loginId.toLowerCase(), mode: 'insensitive' } },
                { username: { equals: loginId, mode: 'insensitive' } },
              ]
            }
          })
          if (!user || !user.password) {
            // log failed attempt with IP
            const ip = ipFromReq(req)
            db.activityLog.create({
              data: {
                userId: null, username: credentials.email,
                action: 'LOGIN_FAILED', details: 'Invalid email or password',
                ipAddress: ip, path: '/auth/signin', method: 'POST', status: 401,
              }
            }).catch(() => {})
            return null
          }
          const isPasswordValid = await bcrypt.compare(credentials.password, user.password)
          if (!isPasswordValid) {
            const ip = ipFromReq(req)
            db.activityLog.create({
              data: {
                userId: user.id, username: user.username,
                action: 'LOGIN_FAILED', details: 'Wrong password',
                ipAddress: ip, path: '/auth/signin', method: 'POST', status: 401,
              }
            }).catch(() => {})
            return null
          }
          // success log with IP
          const ip = ipFromReq(req)
          db.activityLog.create({
            data: {
              userId: user.id, username: user.username,
              action: 'LOGIN', details: 'Signed in with credentials',
              ipAddress: ip, path: '/auth/signin', method: 'POST', status: 200,
            }
          }).catch(() => {})
          return {
            id: user.id,
            email: user.email,
            username: user.username,
            role: user.role,
          }
        } catch (error) {
          console.error('Auth error:', error instanceof Error ? error.message : String(error))
          return null
        }
      }
    }),
  ]

  // Pull OAuth credentials from DB (admin panel) with env-var fallback
  let s: any = null
  try { s = await db.siteSettings.findFirst() } catch { s = null }
  const oauthEnabled = s?.oauthEnabled !== false

  const googleId = (s?.googleClientId || process.env.GOOGLE_CLIENT_ID || '').trim()
  const googleSecret = (s?.googleClientSecret || process.env.GOOGLE_CLIENT_SECRET || '').trim()
  const discordId = (s?.discordClientId || process.env.DISCORD_CLIENT_ID || '').trim()
  const discordSecret = (s?.discordClientSecret || process.env.DISCORD_CLIENT_SECRET || '').trim()

  if (oauthEnabled && googleId && googleSecret) {
    providers.push(GoogleProvider({
      clientId: googleId,
      clientSecret: googleSecret,
      profile: (profile: any) => ({
        id: profile.sub,
        email: profile.email,
        name: profile.name,
        image: profile.picture,
      }) as any,
    }))
  }
  if (oauthEnabled && discordId && discordSecret) {
    providers.push(DiscordProvider({
      clientId: discordId,
      clientSecret: discordSecret,
    }))
  }

  return providers
}

const baseCallbacks = {
  async signIn({ user, account }: any) {
    if (account?.provider === 'google' || account?.provider === 'discord') {
      try {
        if (!user.email) {
          console.error('OAuth login failed: No email returned from provider')
          return false
        }
        
        const existingUser = await db.user.findUnique({ where: { email: user.email } })
        
        // Note: PrismaAdapter handles User and Account creation automatically.
        // We only manually create the user here if we want to set a custom username 
        // before the adapter links the account.
        if (!existingUser) {
          const username = await (async () => {
            let base = generateUsername(user.name || '', user.email || '')
            let exists = await db.user.findUnique({ where: { username: base } })
            while (exists) {
              base = generateUsername(user.name || '', user.email || '')
              exists = await db.user.findUnique({ where: { username: base } })
            }
            return base
          })()
          
          // Create user record manually so we can set the username.
          // NextAuth adapter will find this user by email and link the account.
          await db.user.create({
            data: {
              email: user.email,
              username,
              avatar: user.image || null,
              emailVerified: new Date(),
              role: 'USER',
            }
          })
          
          logActivity({ 
            userId: 'new-user', 
            username: username, 
            action: 'OAUTH_REGISTER', 
            details: `Registered via ${account.provider}`, 
            path: '/auth/signin' 
          }).catch(() => {})
        } else {
          logActivity({ 
            userId: existingUser.id, 
            username: existingUser.username, 
            action: 'OAUTH_LOGIN', 
            details: `Signed in via ${account.provider}`, 
            path: '/auth/signin' 
          }).catch(() => {})
        }
      } catch (e) {
        console.error('OAuth signIn error:', e)
        return false
      }
    }
    return true
  },
  async jwt({ token, user, account }: any) {
    if (user) {
      token.role = (user as any).role
      token.username = (user as any).username
      token.avatar = (user as any).avatar || (user as any).image || null
    }
    // For OAuth initial login or token refresh, ensure we have the latest DB fields
    if (account?.provider && account.provider !== 'credentials' && token.email) {
      const dbUser = await db.user.findUnique({ where: { email: token.email } })
      if (dbUser) {
        token.sub = dbUser.id
        token.role = dbUser.role
        token.username = dbUser.username
        token.avatar = dbUser.avatar || null
      }
    }
    return token
  },
  async session({ session, token }: any) {
    if (token && token.sub) {
      session.user.id = token.sub
      session.user.username = token.username as string
      
      // Fetch fresh data if needed, but try to use token values for speed
      try {
        const dbUser = await db.user.findUnique({
          select: { role: true, avatar: true, username: true },
          where: { id: token.sub }
        })
        if (dbUser) {
          session.user.role = dbUser.role
          session.user.username = dbUser.username
          session.user.image = dbUser.avatar || session.user.image
        } else {
          session.user.role = token.role as string
        }
      } catch (e) {
        session.user.role = token.role as string
      }
    }
    return session
  }
}

// Static authOptions used by getServerSession() in API routes
// (providers list here is intentionally minimal — actual login route uses getAuthOptions())
export const authOptions: NextAuthOptions = {
  adapter: PrismaAdapter(db),
  secret: process.env.NEXTAUTH_SECRET || process.env.SESSION_SECRET,
  providers: [
    CredentialsProvider({
      name: 'credentials',
      credentials: {
        email: { label: 'Email', type: 'email' },
        password: { label: 'Password', type: 'password' }
      },
      async authorize() { return null }, // unused — see getAuthOptions()
    }),
  ],
  session: { strategy: 'jwt' },
  callbacks: baseCallbacks as any,
  pages: { signIn: '/auth/signin' },
}

// Dynamic auth options used by the NextAuth route handler — pulls OAuth keys from DB on each request.
export async function getAuthOptions(): Promise<NextAuthOptions> {
  const providers = await buildProviders()
  return {
    adapter: PrismaAdapter(db),
    secret: process.env.NEXTAUTH_SECRET || process.env.SESSION_SECRET,
    providers,
    session: { strategy: 'jwt' },
    callbacks: baseCallbacks as any,
    pages: { signIn: '/auth/signin' },
  }
}
