import { db } from './db'
import { NextRequest } from 'next/server'

export interface LogActivityOptions {
  userId?: string
  username?: string
  action: string
  details?: string
  request?: NextRequest | Request
  status?: number
  path?: string
  method?: string
}

export async function logActivity(opts: LogActivityOptions) {
  try {
    const req = opts.request
    let ipAddress: string | undefined
    let userAgent: string | undefined
    let path = opts.path
    let method = opts.method

    if (req) {
      const headers = req.headers
      const cleanIp = (raw?: string | null): string | undefined => {
        if (!raw) return undefined
        let ip = String(raw).trim()
        if (ip.toLowerCase().startsWith('::ffff:')) ip = ip.slice(7)
        if (!ip || ip === '::1' || ip === '127.0.0.1' || ip === '0.0.0.0') return undefined
        return ip
      }
      ipAddress =
        cleanIp(headers.get('cf-connecting-ip'))
        || cleanIp(headers.get('true-client-ip'))
        || cleanIp(headers.get('x-forwarded-for')?.split(',')[0])
        || cleanIp(headers.get('x-real-ip'))
        || undefined
      userAgent = headers.get('user-agent') || undefined
      if ('nextUrl' in req) {
        path = path || (req as any).nextUrl?.pathname
        method = method || req.method
      }
    }

    await db.activityLog.create({
      data: {
        userId: opts.userId,
        username: opts.username,
        action: opts.action,
        details: opts.details,
        ipAddress,
        userAgent,
        path,
        method,
        status: opts.status,
      }
    })
  } catch (e) {
    // Non-blocking - don't throw
  }
}
