'use client'

import { useEffect, useState } from 'react'
import { io, Socket } from 'socket.io-client'

let sharedSocket: Socket | null = null
let socketUserId: string | null = null

export function getMessagesSocket(userId?: string): Socket {
  const uid = userId || null

  if (sharedSocket && socketUserId !== uid && uid) {
    sharedSocket.disconnect()
    sharedSocket = null
    socketUserId = null
  }

  if (sharedSocket) return sharedSocket

  const url = typeof window !== 'undefined' ? window.location.origin : ''
  socketUserId = uid
  sharedSocket = io(`${url}/messages`, {
    path: '/socket.io/',
    transports: ['websocket', 'polling'],
    auth: uid ? { userId: uid } : undefined,
    autoConnect: true,
    reconnection: true,
    reconnectionDelay: 1000,
    reconnectionDelayMax: 5000,
    reconnectionAttempts: Infinity, // Keep trying forever
  })

  sharedSocket.on('connect_error', (error) => {
    console.error('[messages-socket] connect error:', error)
  })

  return sharedSocket
}

export function useMessagesSocket(userId?: string) {
  const [connected, setConnected] = useState(false)
  const [socket, setSocket] = useState<Socket | null>(null)

  useEffect(() => {
    if (!userId) return

    const s = getMessagesSocket(userId)
    setSocket(s)

    const onConnect = () => setConnected(true)
    const onDisconnect = () => setConnected(false)
    s.on('connect', onConnect)
    s.on('disconnect', onDisconnect)
    if (s.connected) setConnected(true)

    return () => {
      s.off('connect', onConnect)
      s.off('disconnect', onDisconnect)
    }
  }, [userId])

  return { socket, connected }
}
