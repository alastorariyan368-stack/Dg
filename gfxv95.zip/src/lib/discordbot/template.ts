import { writeFileSync, mkdirSync, existsSync } from 'fs'
import { join } from 'path'

export function generateTemplate(name: string, prefix: string): Record<string, string> {
  return {
    'index.js': `const { Client, GatewayIntentBits, Collection } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { token, prefix, clientId } = require('./config.json');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
  ]
});

client.commands = new Collection();
const commandFiles = fs.readdirSync(path.join(__dirname, 'commands')).filter(f => f.endsWith('.js'));
for (const file of commandFiles) {
  try {
    const command = require(\`./commands/\${file}\`);
    if (command.name && command.execute) {
      client.commands.set(command.name, command);
      console.log(\`Loaded command: \${command.name}\`);
    }
  } catch (err) {
    console.error(\`Failed to load command \${file}:\`, err);
  }
}

const eventFiles = fs.readdirSync(path.join(__dirname, 'events')).filter(f => f.endsWith('.js'));
for (const file of eventFiles) {
  try {
    const event = require(\`./events/\${file}\`);
    if (event.name && typeof event.execute === 'function') {
      if (event.once) {
        client.once(event.name, (...args) => event.execute(...args, client));
      } else {
        client.on(event.name, (...args) => event.execute(...args, client));
      }
      console.log(\`Loaded event: \${event.name}\`);
    }
  } catch (err) {
    console.error(\`Failed to load event \${file}:\`, err);
  }
}

client.login(token).catch(err => {
  console.error('Failed to login:', err.message);
  process.exit(1);
});

process.on('unhandledRejection', (err) => {
  console.error('Unhandled rejection:', err);
});`,
    'package.json': JSON.stringify({
      name: name || 'discord-bot',
      version: '1.0.0',
      main: 'index.js',
      dependencies: {
        'discord.js': '^14.16.3'
      }
    }, null, 2),
    'config.json': JSON.stringify({
      token: 'YOUR_BOT_TOKEN',
      prefix: prefix || '!',
      clientId: 'YOUR_CLIENT_ID'
    }, null, 2),
    'commands/ping.js': `module.exports = {
  name: 'ping',
  description: 'Replies with Pong!',
  execute(message, args, client) {
    message.reply('Pong! 🏓');
  },
};`,
    'events/ready.js': `module.exports = {
  name: 'ready',
  once: true,
  execute(client) {
    console.log(\`✅ Logged in as \${client.user.tag}\`);
    client.user.setActivity('with prefix commands', { type: 0 });
  },
};`,
    'events/messageCreate.js': `module.exports = {
  name: 'messageCreate',
  execute(message, client) {
    if (message.author.bot) return;

    const prefix = require('../config.json').prefix;
    if (!message.content.startsWith(prefix)) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();

    if (!client.commands.has(commandName)) return;

    try {
      const command = client.commands.get(commandName);
      command.execute(message, args, client);
    } catch (error) {
      console.error(\`Error executing command \${commandName}:\`, error);
      message.reply('There was an error executing that command.').catch(() => {});
    }
  },
};`,
  }
}

export function createBotFiles(botId: string, name: string, prefix: string): void {
  const dir = getBotDir(botId)
  mkdirSync(dir, { recursive: true })
  mkdirSync(join(dir, 'commands'), { recursive: true })
  mkdirSync(join(dir, 'events'), { recursive: true })

  const files = generateTemplate(name, prefix)
  for (const [filePath, content] of Object.entries(files)) {
    writeFileSync(join(dir, filePath), content, 'utf-8')
  }
}

export function getBotDir(botId: string): string {
  return join(process.cwd(), 'discordbots', botId)
}
