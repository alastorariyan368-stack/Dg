import { db } from '@/lib/db'

const SYSTEM_PROMPT = `You are an expert Discord bot developer specializing in Discord.js v14.
You help users write, debug, and improve Discord bot code.
Provide complete, working code snippets with proper error handling.
Use CommonJS (require/module.exports) syntax for compatibility with Node.js.
Always include necessary intents and permissions. Keep security in mind.`

async function callAI(prompt: string, apiKey?: string, model?: string): Promise<string> {
  const key = apiKey || process.env.OPENAI_API_KEY
  const m = model || process.env.AI_MODEL || 'gpt-4o-mini'

  if (!key) {
    return generateMockResponse(prompt)
  }

  const res = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${key}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model: m,
      messages: [
        { role: 'system', content: SYSTEM_PROMPT },
        { role: 'user', content: prompt },
      ],
      max_tokens: 2000,
      temperature: 0.7,
    }),
  })

  if (!res.ok) {
    const err = await res.text().catch(() => 'Unknown error')
    throw new Error(`AI API error ${res.status}: ${err.slice(0, 300)}`)
  }

  const data = await res.json()
  const reply = data?.choices?.[0]?.message?.content
  if (!reply) throw new Error('No response from AI')
  return reply
}

function generateMockResponse(prompt: string): string {
  const lower = prompt.toLowerCase()

  if (lower.includes('fix') || lower.includes('error') || lower.includes('bug')) {
    return `Here's how to debug your Discord bot:

1. **Check the error message** - Look at the console output for stack traces
2. **Verify intents** - Make sure you've enabled the necessary privileged intents in Discord Developer Portal:
   - \`GatewayIntentBits.MessageContent\`
   - \`GatewayIntentBits.GuildMembers\`
3. **Check your token** - Ensure the bot token in config.json is correct
4. **Permissions** - Verify the bot has the required OAuth2 scopes and permissions

If you need more specific help, please configure an API key in Settings for AI-powered debugging.`
  }

  if (lower.includes('command') || lower.includes('generate')) {
    return `To create a new Discord.js v14 prefix command:

1. Create a new file in the \`commands/\` folder
2. Use this structure:
\`\`\`js
module.exports = {
  name: 'commandname',
  description: 'What your command does',
  execute(message, args, client) {
    // Your code here
    message.reply('Hello!');
  },
};
\`\`\`
3. Restart the bot

For AI-assisted command generation, please configure an API key in Settings.`
  }

  return `Discord.js v14 Bot Development Tips:

• Use \`GatewayIntentBits.Guilds\`, \`GuildMessages\`, \`MessageContent\`, \`GuildMembers\` for basic functionality
• Store commands in separate files under \`commands/\` folder
• Use \`events/\` folder for event handlers
• Always handle errors with try/catch blocks
• Use \`process.on('unhandledRejection')\` for global error catching

Configure an AI API key in Settings for full AI-powered assistance including code generation, debugging, and optimization.`
}

async function getSettings() {
  try {
    return await db.siteSettings.findFirst()
  } catch {
    return null
  }
}

export async function askAI(prompt: string, code: string, apiKey?: string): Promise<string> {
  const settings = await getSettings()
  const key = apiKey || (settings as any)?.openaiApiKey || (settings as any)?.aiApiKey
  const model = (settings as any)?.aiModel || 'gpt-4o-mini'

  const fullPrompt = `Here is the user's Discord bot code:\n\`\`\`js\n${code}\n\`\`\`\n\nUser question/request:\n${prompt}\n\nPlease analyze the code and provide a helpful response.`
  return callAI(fullPrompt, key || undefined, model)
}

export async function generateCommand(userRequest: string, apiKey?: string): Promise<string> {
  const settings = await getSettings()
  const key = apiKey || (settings as any)?.openaiApiKey || (settings as any)?.aiApiKey
  const model = (settings as any)?.aiModel || 'gpt-4o-mini'

  const fullPrompt = `Generate a complete Discord.js v14 prefix command module based on this description: "${userRequest}"

Return ONLY the command file content as a JavaScript module using module.exports.
The command should follow this structure:
- name (string)
- description (string)
- execute(message, args, client) function
Use proper error handling and send helpful replies.`

  return callAI(fullPrompt, key || undefined, model)
}

export async function fixCode(errorLog: string, code: string, apiKey?: string): Promise<string> {
  const settings = await getSettings()
  const key = apiKey || (settings as any)?.openaiApiKey || (settings as any)?.aiApiKey
  const model = (settings as any)?.aiModel || 'gpt-4o-mini'

  const fullPrompt = `The following Discord bot code produced an error:

Error:
\`\`\`
${errorLog}
\`\`\`

Code:
\`\`\`js
${code}
\`\`\`

Please analyze the error and provide the corrected version of the code. Explain the issue briefly and return the fixed code.`

  return callAI(fullPrompt, key || undefined, model)
}
