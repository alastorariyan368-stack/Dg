import { spawn, ChildProcess, exec } from 'child_process'
import { existsSync } from 'fs'
import { join } from 'path'
import { PrismaClient } from '@prisma/client'
import { createBotFiles, getBotDir } from './template'

const prisma = new PrismaClient()
const processes = new Map<string, ChildProcess>()

async function logToDb(botId: string, content: string, type: string = 'info') {
  try {
    await prisma.discordBotLog.create({
      data: { botId, content, type }
    })
  } catch {}
}

function sanitizeDir(p: string): string {
  return p.replace(/\.\.[/\\]/g, '').replace(/^[/\\]+/, '').replace(/[/\\]$/, '')
}

export async function startBot(botId: string): Promise<{ success: boolean; error?: string }> {
  try {
    const bot = await prisma.discordBot.findUnique({ where: { id: botId } })
    if (!bot) return { success: false, error: 'Bot not found' }

    const dir = getBotDir(botId)
    if (!existsSync(dir)) {
      createBotFiles(botId, bot.name, bot.prefix)
    }

    const nodeModules = join(dir, 'node_modules')
    if (!existsSync(nodeModules)) {
      await logToDb(botId, 'Installing dependencies...', 'info')
      const install = await installDeps(botId)
      if (!install.success) {
        return { success: false, error: `npm install failed: ${install.output}` }
      }
    }

    if (processes.has(botId)) {
      const existing = processes.get(botId)
      if (existing && existing.exitCode === null) {
        return { success: false, error: 'Bot is already running' }
      }
      processes.delete(botId)
    }

    const child = spawn('node', ['index.js'], {
      cwd: dir,
      env: { ...process.env },
      stdio: ['ignore', 'pipe', 'pipe'],
    })

    processes.set(botId, child)

    const ts = new Date().toISOString()
    await logToDb(botId, `[${ts}] Bot started (PID: ${child.pid})`, 'info')

    child.stdout?.on('data', (data: Buffer) => {
      const text = data.toString().trim()
      if (text) logToDb(botId, text, 'info')
    })

    child.stderr?.on('data', (data: Buffer) => {
      const text = data.toString().trim()
      if (text) logToDb(botId, text, 'error')
    })

    child.on('exit', async (code, signal) => {
      processes.delete(botId)
      const ts2 = new Date().toISOString()
      await prisma.discordBot.update({
        where: { id: botId },
        data: { status: 'stopped', pid: null }
      })
      await logToDb(botId, `[${ts2}] Process exited (code: ${code}, signal: ${signal})`, 'error')
    })

    await prisma.discordBot.update({
      where: { id: botId },
      data: { status: 'running', pid: child.pid || null }
    })

    return { success: true }
  } catch (err: any) {
    return { success: false, error: err.message || 'Failed to start bot' }
  }
}

export async function stopBot(botId: string): Promise<{ success: boolean; error?: string }> {
  try {
    const bot = await prisma.discordBot.findUnique({ where: { id: botId } })
    if (!bot) return { success: false, error: 'Bot not found' }

    const child = processes.get(botId)
    if (child && child.exitCode === null) {
      child.kill('SIGTERM')
      setTimeout(() => {
        try { if (child.exitCode === null) child.kill('SIGKILL') } catch {}
      }, 5000)
    } else if (bot.pid) {
      try {
        process.kill(bot.pid, 'SIGTERM')
        setTimeout(() => {
          try { process.kill(bot.pid!, 'SIGKILL') } catch {}
        }, 5000)
      } catch {}
    }

    processes.delete(botId)

    const ts = new Date().toISOString()
    await prisma.discordBot.update({
      where: { id: botId },
      data: { status: 'stopped', pid: null }
    })
    await logToDb(botId, `[${ts}] Bot stopped`, 'info')

    return { success: true }
  } catch (err: any) {
    return { success: false, error: err.message || 'Failed to stop bot' }
  }
}

export async function restartBot(botId: string): Promise<{ success: boolean; error?: string }> {
  const stop = await stopBot(botId)
  if (!stop.success) return stop
  await new Promise(r => setTimeout(r, 1000))
  return startBot(botId)
}

export async function getBotStatus(botId: string): Promise<{ status: string; pid: number | null; running: boolean }> {
  try {
    const bot = await prisma.discordBot.findUnique({ where: { id: botId } })
    if (!bot) return { status: 'not_found', pid: null, running: false }

    const child = processes.get(botId)
    const isRunning = child !== undefined && child.exitCode === null

    if (!isRunning && bot.status === 'running') {
      await prisma.discordBot.update({
        where: { id: botId },
        data: { status: 'stopped', pid: null }
      })
      return { status: 'stopped', pid: null, running: false }
    }

    return {
      status: isRunning ? 'running' : bot.status,
      pid: isRunning ? (child.pid || bot.pid) : null,
      running: isRunning,
    }
  } catch {
    return { status: 'error', pid: null, running: false }
  }
}

export async function executeCommand(botId: string, command: string): Promise<{ output: string; error?: string }> {
  const dir = getBotDir(botId)
  if (!existsSync(dir)) {
    return { output: '', error: 'Bot directory does not exist' }
  }

  return new Promise((resolve) => {
    exec(command, { cwd: dir, timeout: 60000 }, (err, stdout, stderr) => {
      const output = (stdout || '') + (stderr || '')
      if (err) {
        resolve({ output, error: err.message })
      } else {
        resolve({ output })
      }
    })
  })
}

export async function installDeps(botId: string): Promise<{ success: boolean; output: string }> {
  const dir = getBotDir(botId)
  if (!existsSync(dir)) {
    return { success: false, output: 'Bot directory does not exist' }
  }

  return new Promise((resolve) => {
    const child = exec('npm install', { cwd: dir, timeout: 120000 }, (err, stdout, stderr) => {
      const output = (stdout || '') + (stderr || '')
      if (err) {
        resolve({ success: false, output: output || err.message })
      } else {
        resolve({ success: true, output })
      }
    })
    child.stdout?.pipe(process.stdout)
    child.stderr?.pipe(process.stderr)
  })
}

export function ensureDirs(botId: string): void {
  const dir = getBotDir(botId)
  const { mkdirSync } = require('fs')
  mkdirSync(dir, { recursive: true })
  mkdirSync(join(dir, 'commands'), { recursive: true })
  mkdirSync(join(dir, 'events'), { recursive: true })
}
