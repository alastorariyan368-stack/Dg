import { Client, ConnectConfig } from 'ssh2'

export interface SSHOptions {
  host: string
  port: number
  username: string
  password?: string
  privateKey?: string
  tmate?: boolean
}

export interface CommandResult {
  stdout: string
  stderr: string
  code: number | null
}

export class SSHConnection {
  private client: Client
  private connected = false

  constructor() {
    this.client = new Client()
  }

  async connect(opts: SSHOptions): Promise<void> {
    return new Promise((resolve, reject) => {
      const config: ConnectConfig = {
        host: opts.host,
        port: opts.port || 22,
        username: opts.username,
        readyTimeout: 30000,
        keepaliveInterval: 10000,
        hostVerifier: () => true,
      }
      if (opts.password) config.password = opts.password
      if (opts.privateKey) config.privateKey = opts.privateKey

      this.client.on('ready', () => { this.connected = true; resolve() })
      this.client.on('error', reject)
      this.client.on('close', () => { this.connected = false })
      this.client.connect(config)
    })
  }

  async exec(command: string): Promise<CommandResult> {
    return new Promise((resolve, reject) => {
      this.client.exec(command, (err, stream) => {
        if (err) return reject(err)
        let stdout = '', stderr = ''
        stream.on('data', (data: Buffer) => { stdout += data.toString() })
        stream.stderr.on('data', (data: Buffer) => { stderr += data.toString() })
        stream.on('close', (code: number) => resolve({ stdout, stderr, code }))
      })
    })
  }

  async execWithEmit(command: string, emit: (line: string) => void): Promise<CommandResult> {
    return new Promise((resolve, reject) => {
      this.client.exec(command, (err, stream) => {
        if (err) return reject(err)
        let stdout = '', stderr = ''
        stream.on('data', (data: Buffer) => {
          const text = data.toString()
          stdout += text
          text.split('\n').filter(Boolean).forEach(l => emit(l))
        })
        stream.stderr.on('data', (data: Buffer) => {
          const text = data.toString()
          stderr += text
          text.split('\n').filter(Boolean).forEach(l => emit(`[ERR] ${l}`))
        })
        stream.on('close', (code: number) => {
          emit(`[EXIT] ${code}`)
          resolve({ stdout, stderr, code })
        })
      })
    })
  }

  async execInteractive(command: string, onData: (chunk: string) => void): Promise<number> {
    return new Promise((resolve, reject) => {
      this.client.exec(command, (err, stream) => {
        if (err) return reject(err)
        stream.on('data', (data: Buffer) => onData(data.toString()))
        stream.stderr.on('data', (data: Buffer) => onData(`[ERR] ${data.toString()}`))
        stream.on('close', (code: number) => resolve(code))
      })
    })
  }

  async disconnect(): Promise<void> {
    if (this.connected) {
      this.client.end()
      this.connected = false
    }
  }

  isConnected(): boolean { return this.connected }
}
