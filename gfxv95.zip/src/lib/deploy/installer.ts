import { SSHConnection, SSHOptions } from './ssh'
import { installPterodactyl } from './scripts/pterodactyl'
import { installJellyfin } from './scripts/jellyfin'
import { installGeneric } from './scripts/generic'
import { setupCloudflare } from './scripts/cloudflare'
import { setupTailscale } from './scripts/tailscale'

export interface DeployRequest {
  ssh: SSHOptions
  software: string
  customCommand?: string
  customType?: 'docker' | 'binary' | 'script' | 'apt'
  softwareName?: string
  port?: string
  domain?: string
  email?: string
  cfToken?: string
  cfApiKey?: string
  cfEmail?: string
  tailscaleKey?: string
  tailscaleHostname?: string
  dbPassword?: string
  mediaPath?: string
}

export type DeployEvent = { type: 'log'; message: string } | { type: 'error'; message: string } | { type: 'done'; data?: any }

export async function runDeployment(
  req: DeployRequest,
  onEvent: (event: DeployEvent) => void
): Promise<void> {
  const ssh = new SSHConnection()

  try {
    onEvent({ type: 'log', message: '🔌 Connecting to server...' })
    await ssh.connect(req.ssh)
    onEvent({ type: 'log', message: '✅ SSH connected successfully' })

    const emit = (line: string) => onEvent({ type: 'log', message: line })
    const software = req.software.toLowerCase()

    switch (software) {
      case 'pterodactyl':
        await installPterodactyl(ssh, {
          domain: req.domain,
          email: req.email,
          dbPassword: req.dbPassword,
        }, emit)
        break

      case 'jellyfin':
        await installJellyfin(ssh, {
          port: req.port,
          mediaPath: req.mediaPath,
        }, emit)
        break

      case 'docker':
        await installGeneric(ssh, {
          name: 'Docker',
          installCmd: 'curl -fsSL https://get.docker.com | sh',
          type: 'script',
        }, emit)
        break

      case 'nginx':
        await installGeneric(ssh, {
          name: 'Nginx',
          installCmd: 'nginx',
          type: 'apt',
          port: '80',
        }, emit)
        break

      case 'mysql':
      case 'mariadb':
        await installGeneric(ssh, {
          name: 'MariaDB',
          installCmd: 'mariadb-server mariadb-client',
          type: 'apt',
          port: '3306',
        }, emit)
        break

      case 'php':
        await installGeneric(ssh, {
          name: 'PHP',
          installCmd: 'php8.3 php8.3-cli php8.3-common php8.3-mysql php8.3-fpm php8.3-curl php8.3-xml php8.3-mbstring php8.3-zip php8.3-intl php8.3-bcmath composer',
          type: 'apt',
        }, emit)
        break

      case 'node':
        await installGeneric(ssh, {
          name: 'Node.js',
          installCmd: 'curl -fsSL https://deb.nodesource.com/setup_22.x | bash - && apt install -y nodejs',
          type: 'script',
        }, emit)
        break

      case 'python':
        await installGeneric(ssh, {
          name: 'Python',
          installCmd: 'python3 python3-pip python3-venv',
          type: 'apt',
        }, emit)
        break

      case 'portainer':
        await installGeneric(ssh, {
          name: 'Portainer',
          installCmd: 'docker volume create portainer_data && docker run -d -p 9443:9443 --name portainer --restart=always -v /var/run/docker.sock:/var/run/docker.sock -v portainer_data:/data portainer/portainer-ce:latest',
          type: 'docker',
          port: '9443',
        }, emit)
        break

      case 'uptime-kuma':
        await installGeneric(ssh, {
          name: 'Uptime Kuma',
          installCmd: 'docker run -d --restart=always -p 3001:3001 -v uptime-kuma:/app/data --name uptime-kuma louislam/uptime-kuma:latest',
          type: 'docker',
          port: '3001',
        }, emit)
        break

      case 'n8n':
        await installGeneric(ssh, {
          name: 'n8n',
          installCmd: 'docker run -d --restart=always -p 5678:5678 -v n8n_data:/home/node/.n8n --name n8n n8nio/n8n:latest',
          type: 'docker',
          port: '5678',
        }, emit)
        break

      case 'custom':
        if (req.customCommand) {
          const customName = req.softwareName || req.customCommand.split(' ')[0]
          await installGeneric(ssh, {
            name: customName,
            installCmd: req.customCommand,
            type: req.customType || 'script',
            port: req.port,
          }, emit)
        } else {
          onEvent({ type: 'error', message: '❌ Custom command required' })
        }
        break

      default:
        onEvent({ type: 'log', message: `⚠️ Unknown software: ${software}. Running custom command if provided...` })
        if (req.customCommand) {
          await installGeneric(ssh, {
            name: req.softwareName || software,
            installCmd: req.customCommand,
            type: req.customType || 'script',
            port: req.port,
          }, emit)
        }
    }

    if (req.cfToken) {
      onEvent({ type: 'log', message: '\n--- Cloudflare Setup ---' })
      await setupCloudflare(ssh, req.domain || '', req.cfEmail || '', req.cfApiKey || req.cfToken, emit)
    }

    if (req.tailscaleKey) {
      onEvent({ type: 'log', message: '\n--- Tailscale Setup ---' })
      await setupTailscale(ssh, req.tailscaleKey, req.tailscaleHostname || req.software, emit)
    }

    onEvent({ type: 'done', data: { software: req.software, domain: req.domain } })
  } catch (err: any) {
    onEvent({ type: 'error', message: `❌ Deployment failed: ${err.message}` })
  } finally {
    await ssh.disconnect()
  }
}
