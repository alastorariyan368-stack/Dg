import { SSHConnection } from '../ssh'

export async function setupTailscale(
  ssh: SSHConnection,
  authKey: string,
  hostname: string,
  emit: (line: string) => void
): Promise<boolean> {
  emit('🚀 Starting Tailscale setup...')

  const r = await ssh.exec('which tailscale || echo "not_installed"')

  if (r.stdout.trim() === 'not_installed') {
    emit('📦 Installing Tailscale...')
    const osResp = await ssh.exec('cat /etc/os-release | grep -i "ubuntu\\|debian" || true')

    if (osResp.stdout.toLowerCase().includes('ubuntu') || osResp.stdout.toLowerCase().includes('debian')) {
      await ssh.exec('curl -fsSL https://tailscale.com/install.sh | sh 2>&1 || true')
    } else {
      await ssh.exec('curl -fsSL https://tailscale.com/install.sh | sh 2>&1 || true')
    }
    emit('✅ Tailscale installed')
  } else {
    emit('✅ Tailscale already installed')
  }

  if (authKey) {
    emit('🔗 Connecting to Tailscale network...')
    const cmd = `tailscale up --authkey=${authKey} ${hostname ? `--hostname=${hostname}` : ''} --accept-routes --accept-dns=false 2>&1 || true`
    const upR = await ssh.exec(cmd)
    emit(upR.stdout)
    emit('✅ Tailscale connected')
  } else {
    emit('⚠️ No auth key provided. Run `tailscale up` manually.')
  }

  const ipR = await ssh.exec('tailscale ip -4 2>/dev/null || echo "not_connected"')
  emit(`🌐 Tailscale IP: ${ipR.stdout.trim()}`)

  return true
}
