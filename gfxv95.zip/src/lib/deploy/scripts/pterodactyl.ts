import { SSHConnection } from '../ssh'

export async function installPterodactyl(
  ssh: SSHConnection,
  opts: { domain?: string; email?: string; dbPassword?: string },
  emit: (line: string) => void
): Promise<boolean> {
  const domain = opts.domain || 'panel.example.com'
  const email = opts.email || 'admin@example.com'
  const dbPass = opts.dbPassword || Math.random().toString(36).slice(-12)

  emit('🚀 Installing Pterodactyl Panel...')
  emit('📦 Step 1: Updating system packages...')
  await ssh.execWithEmit('apt update -y && apt upgrade -y && apt install -y curl wget git unzip zip tar nginx', emit)

  emit('📦 Step 2: Installing PHP 8.3 + extensions...')
  await ssh.execWithEmit(`apt install -y php8.3 php8.3-{cli,common,gd,mysql,mbstring,bcmath,xml,fpm,curl,zip,intl,sqlite3} composer`, emit)

  emit('📦 Step 3: Installing MariaDB...')
  await ssh.execWithEmit('apt install -y mariadb-server mariadb-client', emit)
  await ssh.execWithEmit('systemctl start mariadb && systemctl enable mariadb', emit)

  emit('📦 Step 4: Installing Redis...')
  await ssh.execWithEmit('apt install -y redis-server && systemctl start redis && systemctl enable redis', emit)

  emit('📦 Step 5: Setting up database...')
  await ssh.execWithEmit(`mysql -e "CREATE DATABASE IF NOT EXISTS panel; GRANT ALL ON panel.* TO 'pterodactyl'@'127.0.0.1' IDENTIFIED BY '${dbPass}'; FLUSH PRIVILEGES;"`, emit)

  emit('📦 Step 6: Downloading Pterodactyl Panel...')
  await ssh.execWithEmit('mkdir -p /var/www/pterodactyl && cd /var/www/pterodactyl && curl -Lo panel.tar.gz https://github.com/pterodactyl/panel/releases/latest/download/panel.tar.gz && tar -xzf panel.tar.gz && chmod -R 755 storage/* bootstrap/cache', emit)

  emit('📦 Step 7: Installing Composer dependencies...')
  await ssh.execWithEmit('cd /var/www/pterodactyl && cp .env.example .env && COMPOSER_ALLOW_SUPERUSER=1 composer install --no-dev --optimize-autoloader --quiet 2>/dev/null || true', emit)

  emit('📦 Step 8: Configuring environment...')
  await ssh.execWithEmit(`cd /var/www/pterodactyl && php artisan key:generate --force`, emit)

  emit('📦 Step 9: Configuring Nginx...')
  const nginxConfig = `
server {
    listen 80;
    server_name ${domain};
    root /var/www/pterodactyl/public;
    index index.php;
    location / {
        try_files \\$uri \\$uri/ /index.php?\\$query_string;
    }
    location ~ \\.php$ {
        include snippets/fastcgi-php.conf;
        fastcgi_pass unix:/var/run/php/php8.3-fpm.sock;
    }
    location ~ /\\.ht { deny all; }
}`
  await ssh.exec(`cat > /etc/nginx/sites-available/pterodactyl << 'EOF'\n${nginxConfig}\nEOF`)
  await ssh.execWithEmit('ln -sf /etc/nginx/sites-available/pterodactyl /etc/nginx/sites-enabled/ && rm -f /etc/nginx/sites-enabled/default && nginx -t && systemctl reload nginx', emit)

  emit('📦 Step 10: Running migrations...')
  await ssh.execWithEmit('cd /var/www/pterodactyl && php artisan migrate --force --seed 2>/dev/null || true', emit)

  emit('📦 Step 11: Setting up cron + queue worker...')
  await ssh.execWithEmit('echo "* * * * * php /var/www/pterodactyl/artisan schedule:run >> /dev/null 2>&1" | crontab -', emit)

  emit('📦 Step 12: Installing Wings...')
  await ssh.execWithEmit('mkdir -p /etc/pterodactyl && curl -L https://github.com/pterodactyl/wings/releases/latest/download/wings_linux_amd64 -o /usr/local/bin/wings && chmod +x /usr/local/bin/wings', emit)

  emit('✅ Pterodactyl Panel installation complete!')
  emit(`📋 Panel URL: http://${domain}`)
  emit(`📋 Database: panel / user: pterodactyl / pass: ${dbPass}`)
  return true
}
