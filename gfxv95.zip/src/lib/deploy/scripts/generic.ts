import { SSHConnection } from '../ssh'

export async function installGeneric(
  ssh: SSHConnection,
  opts: {
    name: string
    installCmd: string
    port?: string
    type: 'docker' | 'binary' | 'script' | 'apt'
  },
  emit: (line: string) => void
): Promise<boolean> {
  emit(`🚀 Installing ${opts.name}...`)

  await ssh.execWithEmit('apt update -y && apt install -y curl wget git', emit)

  if (opts.type === 'docker') {
    emit('📦 Setting up Docker...')
    const dr = await ssh.exec('which docker || echo "not_installed"')
    if (dr.stdout.trim() === 'not_installed') {
      await ssh.execWithEmit('curl -fsSL https://get.docker.com | sh', emit)
    }

    if (opts.installCmd) {
      emit(`🐳 Running Docker command: ${opts.installCmd}`)
      await ssh.execWithEmit(opts.installCmd, emit)
    }
  } else if (opts.type === 'binary') {
    emit(`📦 Downloading binary...`)
    await ssh.execWithEmit(opts.installCmd, emit)
  } else if (opts.type === 'script') {
    emit(`📦 Running install script...`)
    await ssh.execWithEmit(opts.installCmd, emit)
  } else if (opts.type === 'apt') {
    emit('📦 Installing via apt...')
    await ssh.execWithEmit(`apt install -y ${opts.installCmd}`, emit)
  }

  if (opts.port) {
    emit(`🔓 Opening port ${opts.port}...`)
    await ssh.execWithEmit(`ufw allow ${opts.port}/tcp 2>/dev/null || firewall-cmd --add-port=${opts.port}/tcp --permanent 2>/dev/null || true`, emit)
  }

  const ipR = await ssh.exec('curl -s ifconfig.me || curl -s icanhazip.com || hostname -I | awk "{print \$1}"')
  const ip = ipR.stdout.trim()

  emit(`✅ ${opts.name} installed!`)
  if (opts.port) emit(`📋 Access at: http://${ip}:${opts.port}`)

  return true
}
