import { SSHConnection } from '../ssh'

export async function setupCloudflare(
  ssh: SSHConnection,
  domain: string,
  email: string,
  apiKey: string,
  emit: (line: string) => void
): Promise<boolean> {
  emit('🚀 Starting Cloudflare setup...')

  const r1 = await ssh.exec('which cloudflared || echo "not_installed"')
  if (r1.stdout.trim() === 'not_installed') {
    emit('📦 Installing cloudflared...')
    const osResp = await ssh.exec('cat /etc/os-release | grep -i ubuntu || true')
    const isUbuntu = osResp.stdout.toLowerCase().includes('ubuntu')

    if (isUbuntu) {
      await ssh.exec('curl -L https://github.com/cloudflare/cloudflare-warp/releases/latest/download/cloudflare-warp-$(uname -m).deb -o /tmp/cloudflared.deb 2>/dev/null || curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o /usr/local/bin/cloudflared')
      await ssh.exec('chmod +x /usr/local/bin/cloudflared 2>/dev/null || dpkg -i /tmp/cloudflared.deb 2>/dev/null || true')
    } else {
      await ssh.exec('curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o /usr/local/bin/cloudflared && chmod +x /usr/local/bin/cloudflared')
    }
    emit('✅ cloudflared installed')
  } else {
    emit('✅ cloudflared already installed')
  }

  emit('🔑 Authenticating cloudflared...')
  await ssh.exec(`cloudflared tunnel login --token "${apiKey}" 2>/dev/null || echo "token_used"`)

  const tunnelName = domain?.replace(/[^a-zA-Z0-9]/g, '-') || 'auto-tunnel'
  emit(`🔗 Creating tunnel: ${tunnelName}`)

  const tR = await ssh.exec(`cloudflared tunnel create ${tunnelName} 2>&1 || true`)
  emit(tR.stdout)

  const cR = await ssh.exec(`cloudflared tunnel list --name ${tunnelName} 2>&1 | grep -oP '[a-f0-9-]{36}' || true`)
  const tunnelId = cR.stdout.trim()

  const configPath = `~/.cloudflared/${tunnelId || tunnelName}.yml`
  const config = `
tunnel: ${tunnelId || tunnelName}
credentials-file: /root/.cloudflared/${tunnelId || tunnelName}.json
ingress:
  - hostname: ${domain || 'localhost'}
    service: http://localhost:80
  - service: http_status:404
`
  await ssh.exec(`mkdir -p ~/.cloudflared && cat > ${configPath} << 'EOF'\n${config}\nEOF`)
  await ssh.exec(`cloudflared tunnel route dns ${tunnelId || tunnelName} ${domain || 'auto.example.com'} 2>/dev/null || true`)
  await ssh.exec(`cloudflared tunnel install 2>/dev/null || cloudflared service install 2>/dev/null || true`)

  emit('✅ Cloudflare tunnel configured')
  return true
}

export async function setupCloudflareTunnel(
  ssh: SSHConnection,
  token: string,
  emit: (line: string) => void
): Promise<boolean> {
  emit('🚀 Installing Cloudflare Tunnel (quick tunnel)...')
  const r = await ssh.exec('which cloudflared || echo "not_installed"')
  if (r.stdout.trim() === 'not_installed') {
    await ssh.exec('curl -L https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -o /usr/local/bin/cloudflared && chmod +x /usr/local/bin/cloudflared')
    emit('✅ cloudflared installed')
  }
  await ssh.exec(`cloudflared service install ${token} 2>/dev/null || true`)
  emit('✅ Cloudflare tunnel service installed')
  return true
}
