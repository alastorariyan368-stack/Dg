import { SSHConnection } from '../ssh'

export async function installJellyfin(
  ssh: SSHConnection,
  opts: { port?: string; mediaPath?: string },
  emit: (line: string) => void
): Promise<boolean> {
  const port = opts.port || '8096'
  const mediaPath = opts.mediaPath || '/media'

  emit('🚀 Installing Jellyfin Media Server...')

  emit('📦 Step 1: Updating packages...')
  await ssh.execWithEmit('apt update -y && apt install -y curl wget gnupg', emit)

  emit('📦 Step 2: Adding Jellyfin repository...')
  const r = await ssh.exec('cat /etc/os-release | grep -oP "UBUNTU_CODENAME=\\K.*" || cat /etc/os-release | grep -oP "VERSION_CODENAME=\\K.*" || echo "jammy"')
  const codename = r.stdout.trim() || 'jammy'

  await ssh.execWithEmit(`
    curl -fsSL https://repo.jellyfin.org/jellyfin_team.gpg.key | gpg --dearmor -o /etc/apt/trusted.gpg.d/jellyfin.gpg 2>/dev/null
    echo "deb [arch=$(dpkg --print-architecture)] https://repo.jellyfin.org/$(awk -F= '/^ID=/{print $2}' /etc/os-release | tr -d '"') ${codename} main" > /etc/apt/sources.list.d/jellyfin.list
  `, emit)

  emit('📦 Step 3: Installing Jellyfin...')
  await ssh.execWithEmit('apt update -y && apt install -y jellyfin', emit)

  emit('📦 Step 4: Starting Jellyfin...')
  await ssh.execWithEmit('systemctl start jellyfin && systemctl enable jellyfin', emit)

  emit('📦 Step 5: Creating media directory...')
  await ssh.execWithEmit(`mkdir -p ${mediaPath} && chown -R jellyfin:jellyfin ${mediaPath}`, emit)

  emit('📦 Step 6: Configuring firewall...')
  await ssh.execWithEmit(`ufw allow ${port}/tcp 2>/dev/null || firewall-cmd --add-port=${port}/tcp --permanent 2>/dev/null || true`, emit)

  const ipR = await ssh.exec('curl -s ifconfig.me || curl -s icanhazip.com || hostname -I | awk "{print \$1}"')
  const ip = ipR.stdout.trim()

  emit('✅ Jellyfin installation complete!')
  emit(`📋 Access at: http://${ip}:${port}`)
  emit(`📋 Media path: ${mediaPath}`)
  return true
}
