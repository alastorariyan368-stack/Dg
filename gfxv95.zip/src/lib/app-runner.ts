import { spawn, ChildProcess } from 'child_process'
import { writeFile, mkdir, rm } from 'fs/promises'
import { join } from 'path'
import { existsSync } from 'fs'
import * as net from 'net'

interface RunningApp {
  process: ChildProcess | null
  port: number
  type: string
  logs: string
  startedAt: Date
}

const runningApps = new Map<string, RunningApp>()

async function findFreePort(start = 4500): Promise<number> {
  return new Promise((resolve) => {
    const server = net.createServer()
    server.unref()
    server.on('error', () => resolve(findFreePort(start + 1)))
    server.listen(start, '127.0.0.1', () => {
      const addr = server.address() as net.AddressInfo
      server.close(() => resolve(addr.port))
    })
  })
}

export async function startApp(
  id: string,
  type: string,
  files: Array<{ name: string; content: string; binary?: boolean }>
): Promise<{ port: number; url: string; logs: string }> {
  await stopApp(id)

  const port = await findFreePort(4500)
  const appDir = join(process.cwd(), '.deployed', id)
  await mkdir(appDir, { recursive: true })

  for (const file of files) {
    if (!file.name) continue
    const safeName = file.name.replace(/\.\.[/\\]/g, '').replace(/^[/\\]+/, '')
    if (!safeName) continue
    const filePath = join(appDir, safeName)
    const fileDir = filePath.substring(0, filePath.lastIndexOf(require('path').sep))
    if (fileDir !== appDir && !existsSync(fileDir)) {
      await mkdir(fileDir, { recursive: true }).catch(() => {})
    }
    try {
      if (file.binary && file.content?.startsWith('data:')) {
        const base64 = file.content.split(',')[1] || ''
        await writeFile(filePath, Buffer.from(base64, 'base64'))
      } else {
        await writeFile(filePath, file.content || '')
      }
    } catch {}
  }

  const ts = new Date().toISOString()
  let initLogs = `[${ts}] Starting ${type} app...\n[${ts}] Internal port: ${port}\n`

  let childProcess: ChildProcess | null = null

  if (type === 'nodejs') {
    childProcess = spawn('node', ['index.js'], {
      cwd: appDir,
      env: { ...process.env, PORT: String(port), NODE_ENV: 'production' },
    })
    initLogs += `[${ts}] Command: node index.js\n`
  } else if (type === 'python') {
    childProcess = spawn('python3', ['app.py'], {
      cwd: appDir,
      env: { ...process.env, PORT: String(port) },
    })
    initLogs += `[${ts}] Command: python3 app.py\n`
  } else {
    const staticServer = `
const http=require('http'),fs=require('fs'),path=require('path')
const PORT=process.env.PORT||${port}
const ROOT=${JSON.stringify(appDir)}
const MIME={'.html':'text/html','.css':'text/css','.js':'application/javascript','.mjs':'application/javascript','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.gif':'image/gif','.webp':'image/webp','.svg':'image/svg+xml','.ico':'image/x-icon','.woff':'font/woff','.woff2':'font/woff2','.ttf':'font/ttf','.mp4':'video/mp4','.mp3':'audio/mpeg'}
http.createServer((req,res)=>{
  res.setHeader('Access-Control-Allow-Origin','*')
  let p=req.url.split('?')[0]
  if(p.endsWith('/'))p+='index.html'
  let fp=path.join(ROOT,decodeURIComponent(p))
  if(!fp.startsWith(ROOT)){res.writeHead(403);return res.end('Forbidden')}
  if(!fs.existsSync(fp))fp=path.join(ROOT,'index.html')
  fs.readFile(fp,(err,data)=>{
    if(err){res.writeHead(404,{'Content-Type':'text/plain'});return res.end('Not found')}
    res.writeHead(200,{'Content-Type':MIME[path.extname(fp).toLowerCase()]||'application/octet-stream'})
    res.end(data)
  })
}).listen(PORT,()=>console.log('Static server ready on port '+PORT))
`
    childProcess = spawn('node', ['-e', staticServer], {
      env: { ...process.env, PORT: String(port) },
    })
    initLogs += `[${ts}] Command: static file server (HTML/React)\n`
  }

  const app: RunningApp = { process: childProcess, port, type, logs: initLogs, startedAt: new Date() }
  runningApps.set(id, app)

  if (childProcess) {
    childProcess.stdout?.on('data', (data: Buffer) => {
      const entry = runningApps.get(id)
      if (entry) entry.logs += data.toString()
    })
    childProcess.stderr?.on('data', (data: Buffer) => {
      const entry = runningApps.get(id)
      if (entry) entry.logs += data.toString()
    })
    childProcess.on('exit', (code: number | null) => {
      const entry = runningApps.get(id)
      if (entry) entry.logs += `\n[Process exited with code ${code ?? 'unknown'}]\n`
    })
  }

  await new Promise(r => setTimeout(r, 800))

  const replitDomain = process.env.REPLIT_DEV_DOMAIN
  const customDomain = process.env.CUSTOM_DOMAIN
  const baseDomain = customDomain || replitDomain
  const url = baseDomain
    ? `https://${baseDomain}/deployed/${id}/`
    : `http://localhost:${port}`

  const entry = runningApps.get(id)
  if (entry) entry.logs += `[${ts}] App URL: ${url}\n`

  return { port, url, logs: runningApps.get(id)?.logs || initLogs }
}

export async function stopApp(id: string): Promise<string> {
  const app = runningApps.get(id)
  const logs = app?.logs || ''
  if (app?.process) {
    try { app.process.kill('SIGTERM') } catch {}
    setTimeout(() => { try { app.process?.kill('SIGKILL') } catch {} }, 3000)
  }
  runningApps.delete(id)
  try {
    const appDir = join(process.cwd(), '.deployed', id)
    if (existsSync(appDir)) await rm(appDir, { recursive: true, force: true })
  } catch {}
  return logs
}

export function getAppInfo(id: string): { running: boolean; port: number; logs: string } | null {
  const app = runningApps.get(id)
  if (!app) return null
  const running = app.process !== null && app.process.exitCode === null && app.process.signalCode === null
  return { running, port: app.port, logs: app.logs }
}

export function getRunningApps(): Map<string, RunningApp> {
  return runningApps
}
