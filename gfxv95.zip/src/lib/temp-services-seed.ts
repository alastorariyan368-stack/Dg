import { db } from './db'
import * as net from 'net'

// ─── Default country configs ──────────────────────────────────────────────────
const DEFAULT_COUNTRIES = [
  { countryCode: 'US', countryName: 'United States', numberPrefix: '+1201', expiryMinutes: 30, maxPerUser: 3 },
  { countryCode: 'UK', countryName: 'United Kingdom', numberPrefix: '+4470', expiryMinutes: 30, maxPerUser: 3 },
  { countryCode: 'DE', countryName: 'Germany',        numberPrefix: '+4915', expiryMinutes: 30, maxPerUser: 3 },
  { countryCode: 'FR', countryName: 'France',         numberPrefix: '+3360', expiryMinutes: 30, maxPerUser: 3 },
  { countryCode: 'IN', countryName: 'India',          numberPrefix: '+9190', expiryMinutes: 30, maxPerUser: 3 },
  { countryCode: 'BD', countryName: 'Bangladesh',     numberPrefix: '+8801', expiryMinutes: 30, maxPerUser: 3 },
  { countryCode: 'CA', countryName: 'Canada',         numberPrefix: '+1416', expiryMinutes: 30, maxPerUser: 3 },
  { countryCode: 'AU', countryName: 'Australia',      numberPrefix: '+6140', expiryMinutes: 30, maxPerUser: 3 },
  { countryCode: 'SG', countryName: 'Singapore',      numberPrefix: '+6591', expiryMinutes: 30, maxPerUser: 3 },
  { countryCode: 'NL', countryName: 'Netherlands',    numberPrefix: '+3160', expiryMinutes: 30, maxPerUser: 3 },
]

// ─── Detect this server's public IP ──────────────────────────────────────────
async function getPublicIp(): Promise<string> {
  const services = [
    'https://api.ipify.org?format=json',
    'https://api4.my-ip.io/ip.json',
    'https://ipinfo.io/json',
  ]
  for (const url of services) {
    try {
      const r = await fetch(url, { signal: AbortSignal.timeout(3000) })
      const j = await r.json() as any
      const ip = j.ip || j.IPv4
      if (ip && net.isIPv4(ip)) return ip
    } catch {}
  }
  return ''
}

// ─── Get base hostname from env ───────────────────────────────────────────────
function getBaseHostname(): string {
  for (const key of ['NEXT_PUBLIC_APP_URL', 'NEXTAUTH_URL']) {
    const val = process.env[key]
    if (!val) continue
    try {
      const host = new URL(val).hostname
      if (host && host !== 'localhost' && !host.startsWith('127.') && !host.startsWith('0.')) return host
    } catch {}
  }
  return ''
}

// ─── Cloudflare: auto-create A + MX records for mail subdomain ───────────────
async function autoSetupCloudflareDns(mailSubdomain: string, serverIp: string): Promise<boolean> {
  try {
    const settings = await db.siteSettings.findFirst({
      select: { cfApiToken: true, cfAccountId: true },
    })
    if (!settings?.cfApiToken || !settings?.cfAccountId) {
      console.log('> [TempMail] No Cloudflare credentials — skipping auto-DNS (add them in Admin → Zero Trust / API Keys)')
      return false
    }

    const token = settings.cfApiToken
    const accountId = settings.cfAccountId

    // Get the root domain zone from Cloudflare (e.g. gfxv70.com from mail.gfxv70.com)
    const zonesRes = await fetch(
      `https://api.cloudflare.com/client/v4/zones?account.id=${accountId}&per_page=50&status=active`,
      { headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' } }
    )
    const zonesData = await zonesRes.json() as any
    if (!zonesData.success) {
      console.warn('> [TempMail] Cloudflare zones fetch failed:', zonesData.errors?.[0]?.message)
      return false
    }

    // Find which zone owns this subdomain
    const zones: any[] = zonesData.result || []
    const zone = zones.find((z: any) => mailSubdomain.endsWith(z.name))
    if (!zone) {
      console.warn(`> [TempMail] No Cloudflare zone found for ${mailSubdomain}. Add your domain to Cloudflare first.`)
      return false
    }

    const zoneId = zone.id
    const cfHeaders = { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }

    // Check existing records
    const existingRes = await fetch(
      `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records?name=${mailSubdomain}&per_page=20`,
      { headers: cfHeaders }
    )
    const existingData = await existingRes.json() as any
    const existing: any[] = existingData.result || []

    const hasA  = existing.some((r: any) => r.type === 'A')
    const hasMX = existing.some((r: any) => r.type === 'MX')

    // Create A record if missing
    if (!hasA) {
      const aRes = await fetch(`https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`, {
        method: 'POST',
        headers: cfHeaders,
        body: JSON.stringify({ type: 'A', name: mailSubdomain, content: serverIp, ttl: 1, proxied: false }),
      })
      const aData = await aRes.json() as any
      if (aData.success) console.log(`> [TempMail] ✅ Cloudflare A record created: ${mailSubdomain} → ${serverIp}`)
      else console.warn(`> [TempMail] A record error:`, aData.errors?.[0]?.message)
    } else {
      console.log(`> [TempMail] A record already exists for ${mailSubdomain}`)
    }

    // Create MX record if missing
    if (!hasMX) {
      const mxRes = await fetch(`https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`, {
        method: 'POST',
        headers: cfHeaders,
        body: JSON.stringify({ type: 'MX', name: mailSubdomain, content: mailSubdomain, priority: 10, ttl: 1 }),
      })
      const mxData = await mxRes.json() as any
      if (mxData.success) console.log(`> [TempMail] ✅ Cloudflare MX record created: ${mailSubdomain} → ${mailSubdomain}`)
      else console.warn(`> [TempMail] MX record error:`, mxData.errors?.[0]?.message)
    } else {
      console.log(`> [TempMail] MX record already exists for ${mailSubdomain}`)
    }

    return true
  } catch (err: any) {
    console.warn('> [TempMail] Cloudflare DNS setup error (non-fatal):', err?.message)
    return false
  }
}

// ─── Main auto-seed function ──────────────────────────────────────────────────
export async function autoSeedTempServices() {
  try {
    // 1. Seed default country configs
    for (const country of DEFAULT_COUNTRIES) {
      await db.tempPhoneConfig.upsert({
        where: { countryCode: country.countryCode },
        update: {},
        create: country,
      })
    }
    console.log('> [TempNum] Default country configs ready (10 countries)')

    // 2. Auto-register mail domain + Cloudflare DNS
    const baseHost = getBaseHostname()
    if (baseHost) {
      const mailDomain = baseHost.startsWith('mail.') ? baseHost : `mail.${baseHost}`

      // Register in DB
      await db.tempMailDomain.upsert({
        where: { domain: mailDomain },
        update: {},
        create: { domain: mailDomain, isActive: true },
      })
      console.log(`> [TempMail] Domain registered: ${mailDomain}`)

      // Auto-setup Cloudflare DNS (A + MX)
      const serverIp = await getPublicIp()
      if (serverIp) {
        console.log(`> [TempMail] Server public IP: ${serverIp}`)
        await autoSetupCloudflareDns(mailDomain, serverIp)
      } else {
        console.warn('> [TempMail] Could not detect public IP — skipping Cloudflare DNS auto-setup')
      }
    } else {
      const existing = await db.tempMailDomain.count()
      if (existing === 0) {
        console.log('> [TempMail] Set NEXT_PUBLIC_APP_URL=https://yourdomain.com for auto DNS setup')
      } else {
        console.log(`> [TempMail] ${existing} domain(s) already configured`)
      }
    }

    // 3. Initial cleanup of expired entries
    const cutoff = new Date(Date.now() - 2 * 60 * 60 * 1000)
    const [di, dp] = await Promise.all([
      db.tempMailInbox.deleteMany({ where: { expiresAt: { lt: cutoff } } }),
      db.tempPhone.deleteMany({ where: { expiresAt: { lt: cutoff } } }),
    ])
    if (di.count > 0 || dp.count > 0) {
      console.log(`> [TempCleanup] Removed ${di.count} expired inboxes, ${dp.count} expired phones`)
    }

  } catch (err: any) {
    console.warn('> [TempServices] Auto-seed warning (non-fatal):', err?.message)
  }
}

// ─── Background cleanup every 30 min ─────────────────────────────────────────
export function startTempServicesCleanup() {
  const runCleanup = async () => {
    try {
      const cutoff = new Date(Date.now() - 2 * 60 * 60 * 1000)
      const [i, p] = await Promise.all([
        db.tempMailInbox.deleteMany({ where: { expiresAt: { lt: cutoff } } }),
        db.tempPhone.deleteMany({ where: { expiresAt: { lt: cutoff } } }),
      ])
      if (i.count > 0 || p.count > 0) {
        console.log(`> [TempCleanup] Removed ${i.count} inboxes, ${p.count} phones`)
      }
    } catch {}
  }
  setInterval(runCleanup, 30 * 60 * 1000)
  console.log('> [TempCleanup] Background cleanup started (every 30min)')
}
