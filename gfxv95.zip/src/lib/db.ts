import { PrismaClient } from '@prisma/client'

const globalForPrisma = global as unknown as {
  prisma: PrismaClient | undefined
}

function createPrismaClient() {
  const client = new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['error'] : ['error'],
    errorFormat: 'colorless'
  })
  return client
}

if (!globalForPrisma.prisma) {
  globalForPrisma.prisma = createPrismaClient()
}

export const db = globalForPrisma.prisma

export async function ensureDatabaseReady() {
  try {
    await db.$connect()
    await db.$queryRaw`SELECT 1`
    console.log('✅ Database connection established and verified')
  } catch (error) {
    console.error('❌ Database connection check failed:', error)
    try {
      await db.$disconnect()
      await new Promise(r => setTimeout(r, 2000))
      await db.$connect()
      await db.$queryRaw`SELECT 1`
      console.log('✅ Database reconnected on retry')
    } catch (e2) {
      console.error('❌ Database reconnection also failed:', e2)
    }
  }
}

export async function reconnectDatabase() {
  try {
    await db.$disconnect()
    await new Promise(r => setTimeout(r, 1000))
    await db.$connect()
    await db.$queryRaw`SELECT 1`
    console.log('✅ Database reconnected successfully')
  } catch (error) {
    console.error('❌ Database reconnection failed:', error)
  }
}
