'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Search, UserPlus, Check, Loader2, Users, MessageCircle } from 'lucide-react'
import { toast } from 'sonner'

interface User {
  id: string
  username: string
  avatar?: string
  bio?: string
  isActive: boolean
}

interface UserSearchProps {
  onSelectFriend?: (friend: User) => void
}

export function UserSearch({ onSelectFriend }: UserSearchProps) {
  const [searchQuery, setSearchQuery] = useState('')
  const [results, setResults] = useState<User[]>([])
  const [loading, setLoading] = useState(true)
  const [sentRequests, setSentRequests] = useState<Set<string>>(new Set())
  const [error, setError] = useState('')
  const [page, setPage] = useState(1)
  const [totalPages, setTotalPages] = useState(1)
  const [total, setTotal] = useState(0)
  const [limit] = useState(20)
  const [isSearchMode, setIsSearchMode] = useState(false)

  // Load suggested users on component mount
  useEffect(() => {
    loadSuggestedUsers(1)
  }, [])

  const loadSuggestedUsers = async (pageNum: number = 1) => {
    try {
      setLoading(true)
      const res = await fetch(`/api/users/discover?page=${pageNum}&limit=${limit}&sortBy=recent`)
      if (res.ok) {
        const data = await res.json()
        setResults(data.users || [])
        setTotal(data.total || 0)
        setTotalPages(data.totalPages || 1)
        setPage(pageNum)
        setIsSearchMode(false)
      } else {
        setError('Failed to load suggested users')
      }
    } catch {
      setError('Error loading suggested users')
    } finally {
      setLoading(false)
    }
  }

  const handleSearch = async (query: string, pageNum: number = 1) => {
    setSearchQuery(query)
    setError('')
    setPage(pageNum)
    if (!query.trim()) {
      loadSuggestedUsers(1)
      return
    }
    try {
      setLoading(true)
      setIsSearchMode(true)
      const res = await fetch(`/api/users/search?q=${encodeURIComponent(query)}&page=${pageNum}&limit=${limit}`)
      if (res.ok) {
        const data = await res.json()
        setResults(data.users || [])
        setTotal(data.total || 0)
        setTotalPages(data.totalPages || 1)
      }
      else setError('Search failed')
    } catch { setError('Error searching users') } finally { setLoading(false) }
  }

  const handleNextPage = () => {
    if (page < totalPages) {
      if (isSearchMode) {
        handleSearch(searchQuery, page + 1)
      } else {
        loadSuggestedUsers(page + 1)
      }
    }
  }

  const handlePreviousPage = () => {
    if (page > 1) {
      if (isSearchMode) {
        handleSearch(searchQuery, page - 1)
      } else {
        loadSuggestedUsers(page - 1)
      }
    }
  }

  const handleSendRequest = async (userId: string) => {
    try {
      const res = await fetch('/api/friends/send-request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: results.find(u => u.id === userId)?.username })
      })
      if (res.ok) {
        setSentRequests(new Set(sentRequests).add(userId))
        toast.success('Friend request sent!')
      } else {
        const data = await res.json()
        toast.error(data.error || 'Failed to send request')
      }
    } catch { toast.error('Error sending request') }
  }

  return (
    <div className="w-full h-full flex flex-col bg-slate-900 rounded-2xl border border-white/10 overflow-hidden">
      <div className="p-4 border-b border-white/10">
        <div className="flex items-center gap-2 mb-3">
          <Users className="w-4 h-4 text-purple-400" />
          <h2 className="font-semibold text-white text-sm">Find Friends</h2>
        </div>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-white/30" />
          <Input
            placeholder="Search by username..."
            value={searchQuery}
            onChange={e => handleSearch(e.target.value)}
            className="pl-9 h-9 bg-white/5 border-white/10 text-white placeholder:text-white/30 text-sm rounded-xl focus:border-purple-500/50"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-3">
        {error && (
          <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-xs text-red-400 mb-3">{error}</div>
        )}

        {loading ? (
          <div className="flex items-center justify-center py-8">
            <Loader2 className="w-5 h-5 animate-spin text-purple-400" />
          </div>
        ) : results.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-8 text-center">
            <Users className="w-8 h-8 text-white/20 mb-2" />
            <p className="text-sm text-white/40">
              {searchQuery ? `No users found for "${searchQuery}"` : 'No suggested users at this time'}
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            <div className="flex items-center justify-between px-1 py-2 mb-2 sticky top-0">
              <p className="text-xs text-white/50">
                {isSearchMode ? `${total} user${total !== 1 ? 's' : ''} found` : 'Suggested users'}
              </p>
              <p className="text-xs text-white/50">
                Page {page} of {totalPages}
              </p>
            </div>
            {results.map(user => (
              <div key={user.id} className="flex items-center gap-3 p-3 rounded-xl bg-white/5 hover:bg-white/10 transition-colors">
                <Avatar className="h-9 w-9 flex-shrink-0">
                  {user.avatar && <AvatarImage src={user.avatar} alt={user.username} onError={(e) => {e.currentTarget.style.display = 'none'}} />}
                  <AvatarFallback className="bg-purple-500/20 text-purple-300 text-xs font-bold">
                    {user.username.slice(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-white text-sm truncate">{user.username}</p>
                  <div className="flex items-center gap-1.5">
                    <span className={`w-1.5 h-1.5 rounded-full ${user.isActive ? 'bg-green-400' : 'bg-white/20'}`} />
                    <p className="text-xs text-white/40">{user.isActive ? 'Online' : 'Offline'}</p>
                    {user.bio && <span className="text-white/30">·</span>}
                    {user.bio && <p className="text-xs text-white/40 truncate">{user.bio}</p>}
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <Button
                    size="sm"
                    onClick={() => onSelectFriend?.(user)}
                    className="h-7 w-7 p-0 text-purple-400 hover:text-purple-300 hover:bg-purple-500/20 bg-purple-500/10 rounded-lg transition-all duration-200"
                    title="Send message"
                  >
                    <MessageCircle className="w-3.5 h-3.5" />
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => handleSendRequest(user.id)}
                    disabled={sentRequests.has(user.id)}
                    className={`h-7 px-3 text-xs rounded-lg border-0 ${
                      sentRequests.has(user.id)
                        ? 'bg-green-500/20 text-green-400 cursor-default'
                        : 'bg-purple-500/20 hover:bg-purple-500/40 text-purple-300'
                    }`}
                  >
                    {sentRequests.has(user.id) ? (
                      <><Check className="w-3 h-3 mr-1" />Sent</>
                    ) : (
                      <><UserPlus className="w-3 h-3 mr-1" />Add</>
                    )}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      
      {/* Pagination Controls */}
      {totalPages > 1 && results.length > 0 && (
        <div className="border-t border-white/10 p-3 flex items-center justify-between bg-white/[0.02]">
          <Button
            size="sm"
            variant="ghost"
            onClick={handlePreviousPage}
            disabled={page === 1}
            className="h-8 text-xs text-white/70 hover:text-white hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            ← Previous
          </Button>
          <span className="text-xs text-white/50">
            {Math.min(page * limit, total)} of {total}
          </span>
          <Button
            size="sm"
            variant="ghost"
            onClick={handleNextPage}
            disabled={page === totalPages}
            className="h-8 text-xs text-white/70 hover:text-white hover:bg-white/10 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            Next →
          </Button>
        </div>
      )}
    </div>
  )
}
