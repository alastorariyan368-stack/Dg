'use client'

import { useEffect, useRef, useState } from 'react'
import { Phone, PhoneOff, Mic, MicOff, Video, VideoOff, Volume2, VolumeX } from 'lucide-react'
import { getMessagesSocket } from '@/lib/messages-socket'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'

// Public STUN + free TURN (Open Relay) servers for NAT traversal
const ICE_SERVERS: RTCIceServer[] = [
  { urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] },
  { urls: ['stun:stun2.l.google.com:19302', 'stun:stun3.l.google.com:19302'] },
  {
    urls: 'turn:openrelay.metered.ca:80',
    username: 'openrelayproject',
    credential: 'openrelayproject',
  },
  {
    urls: 'turn:openrelay.metered.ca:443',
    username: 'openrelayproject',
    credential: 'openrelayproject',
  },
]

export type CallPeer = { id: string; username: string; avatar?: string | null }

interface CallModalProps {
  open: boolean
  onClose: () => void
  callId: string
  peer: CallPeer
  type: 'AUDIO' | 'VIDEO'
  isInitiator: boolean
  myUserId: string
  initialAccepted?: boolean
}

function fmt(s: number) { return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}` }

function createOutgoingRingtone(): { start: () => void; stop: () => void } {
  let ctx: AudioContext | null = null
  let interval: ReturnType<typeof setInterval> | null = null
  let running = false

  function playTone() {
    try {
      if (!ctx) ctx = new AudioContext()
      if (ctx.state === 'suspended') ctx.resume()
      const now = ctx.currentTime
      const osc = ctx.createOscillator()
      const gain = ctx.createGain()
      osc.connect(gain)
      gain.connect(ctx.destination)
      osc.type = 'sine'
      osc.frequency.setValueAtTime(440, now)
      osc.frequency.exponentialRampToValueAtTime(480, now + 1.5)
      gain.gain.setValueAtTime(0, now)
      gain.gain.linearRampToValueAtTime(0.1, now + 0.1)
      gain.gain.linearRampToValueAtTime(0, now + 1.5)
      osc.start(now)
      osc.stop(now + 1.5)
    } catch {}
  }

  return {
    start() {
      if (running) return
      running = true
      playTone()
      interval = setInterval(playTone, 3000)
    },
    stop() {
      running = false
      if (interval) { clearInterval(interval); interval = null }
      try { ctx?.close() } catch {}
      ctx = null
    },
  }
}

export function CallModal({ open, onClose, callId, peer, type, isInitiator, myUserId, initialAccepted = false }: CallModalProps) {
  const [phase, setPhase] = useState<'ringing' | 'in-call' | 'ended'>('ringing')
  const [muted, setMuted] = useState(false)
  const [camOff, setCamOff] = useState(false)
  const [speakerOff, setSpeakerOff] = useState(false)
  const [secs, setSecs] = useState(0)
  const [errMsg, setErrMsg] = useState('')

  const localVideoRef = useRef<HTMLVideoElement>(null)
  const remoteVideoRef = useRef<HTMLVideoElement>(null)
  const remoteAudioRef = useRef<HTMLAudioElement>(null)
  const pcRef = useRef<RTCPeerConnection | null>(null)
  const localStreamRef = useRef<MediaStream | null>(null)
  const startTsRef = useRef(0)
  const endedRef = useRef(false)
  const outgoingRingRef = useRef<{ start: () => void; stop: () => void } | null>(null)

  useEffect(() => {
    if (isInitiator && phase === 'ringing') {
      if (!outgoingRingRef.current) outgoingRingRef.current = createOutgoingRingtone()
      outgoingRingRef.current.start()
    } else {
      outgoingRingRef.current?.stop()
    }
    return () => outgoingRingRef.current?.stop()
  }, [isInitiator, phase])

  // Call timer
  useEffect(() => {
    if (phase !== 'in-call') return
    if (!startTsRef.current) startTsRef.current = Date.now()
    const t = setInterval(() => setSecs(Math.floor((Date.now() - startTsRef.current) / 1000)), 1000)
    return () => clearInterval(t)
  }, [phase])

  // endCall is stable — uses refs, no stale closure issues
  function endCall(remote = false) {
    if (endedRef.current) return
    endedRef.current = true
    setPhase('ended')
    const socket = getMessagesSocket(myUserId)
    if (!remote) socket.emit('call:end', { callId, targetUserIds: [peer.id] })
    try { pcRef.current?.close() } catch {}
    pcRef.current = null
    localStreamRef.current?.getTracks().forEach(t => t.stop())
    localStreamRef.current = null
    const dur = startTsRef.current ? Math.floor((Date.now() - startTsRef.current) / 1000) : 0
    fetch('/api/calls', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        callId,
        status: dur > 0 ? 'ENDED' : (isInitiator ? 'CANCELLED' : 'REJECTED'),
        durationSec: dur,
      }),
    }).catch(() => {})
    setTimeout(onClose, 600)
  }

  // Main WebRTC + signaling setup
  useEffect(() => {
    if (!open) return
    endedRef.current = false

    const socket = getMessagesSocket(myUserId)
    let cancelled = false

    // ── ICE candidate queue (buffer until remote description is set) ──
    const iceBuf: RTCIceCandidateInit[] = []
    let hasRemote = false

    async function flushIce(pc: RTCPeerConnection) {
      hasRemote = true
      for (const c of iceBuf) {
        try { await pc.addIceCandidate(new RTCIceCandidate(c)) } catch {}
      }
      iceBuf.length = 0
    }

    // ── Create PeerConnection ──
    const pc = new RTCPeerConnection({ iceServers: ICE_SERVERS })
    pcRef.current = pc

    pc.onicecandidate = (e) => {
      if (e.candidate && !cancelled) {
        socket.emit('webrtc:ice', { callId, to: peer.id, candidate: e.candidate.toJSON() })
      }
    }

    pc.ontrack = (e) => {
      if (cancelled) return
      const [remote] = e.streams
      if (!remote) return
      // Audio — plays for both AUDIO and VIDEO calls
      if (remoteAudioRef.current) {
        remoteAudioRef.current.srcObject = remote
        remoteAudioRef.current.play().catch(() => {})
      }
      // Video
      if (type === 'VIDEO' && remoteVideoRef.current) {
        remoteVideoRef.current.srcObject = remote
        remoteVideoRef.current.play().catch(() => {})
      }
      if (!cancelled) setPhase('in-call')
    }

    pc.onconnectionstatechange = () => {
      if (pc.connectionState === 'connected' && !cancelled) setPhase('in-call')
      if ((pc.connectionState === 'failed' || pc.connectionState === 'disconnected') && !cancelled) {
        setErrMsg('Connection lost')
        setTimeout(() => endCall(true), 1500)
      }
    }

    // ── Signal handlers — registered SYNCHRONOUSLY before any async work ──
    // This is critical: events can arrive at any time; handlers must be ready.

    // Callee receives offer → answers
    const onOffer = async ({ callId: cid, sdp }: any) => {
      if (cid !== callId || cancelled || isInitiator) return
      try {
        await pc.setRemoteDescription(new RTCSessionDescription(sdp))
        await flushIce(pc)
        const answer = await pc.createAnswer()
        await pc.setLocalDescription(answer)
        socket.emit('webrtc:answer', { callId, to: peer.id, sdp: answer })
      } catch { if (!cancelled) setErrMsg('Connection failed') }
    }

    // Caller receives answer → completes handshake
    const onAnswer = async ({ callId: cid, sdp }: any) => {
      if (cid !== callId || cancelled || !isInitiator) return
      try {
        await pc.setRemoteDescription(new RTCSessionDescription(sdp))
        await flushIce(pc)
      } catch { if (!cancelled) setErrMsg('Connection failed') }
    }

    // Both sides add ICE candidates (buffered if remote desc not set yet)
    const onIce = async ({ callId: cid, candidate }: any) => {
      if (cid !== callId || cancelled) return
      if (hasRemote) {
        try { await pc.addIceCandidate(new RTCIceCandidate(candidate)) } catch {}
      } else {
        iceBuf.push(candidate)
      }
    }

    // Caller receives webrtc:ready from callee → NOW safe to send offer
    // (callee's modal is mounted, media acquired, PC ready)
    const onReady = async ({ callId: cid }: any) => {
      if (cid !== callId || cancelled || !isInitiator) return
      try {
        const offer = await pc.createOffer({ offerToReceiveAudio: true, offerToReceiveVideo: type === 'VIDEO' })
        await pc.setLocalDescription(offer)
        socket.emit('webrtc:offer', { callId, to: peer.id, sdp: offer })
      } catch { if (!cancelled) setErrMsg('Failed to start call') }
    }

    const onEnded = ({ callId: cid }: any) => {
      if (cid === callId && !cancelled) endCall(true)
    }

    const onRejected = ({ callId: cid }: any) => {
      if (cid === callId && !cancelled) {
        setErrMsg('Call was declined')
        endCall(true)
      }
    }

    // Also handle call:accepted so caller knows callee accepted
    // (the actual offer is sent after webrtc:ready, not here)
    const onAccepted = ({ callId: cid }: any) => {
      // No action needed — we wait for webrtc:ready to send the offer
      if (cid === callId && !cancelled) {
        // Show "connecting..." visually if needed — phase stays 'ringing' until stream arrives
      }
    }

    socket.on('webrtc:ready', onReady)
    socket.on('webrtc:offer', onOffer)
    socket.on('webrtc:answer', onAnswer)
    socket.on('webrtc:ice', onIce)
    socket.on('call:accepted', onAccepted)
    socket.on('call:ended', onEnded)
    socket.on('call:rejected', onRejected)

    // ── Get mic/camera (async — happens AFTER listeners are registered) ──
    ;(async () => {
      try {
        const constraints: MediaStreamConstraints = {
          audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
          video: type === 'VIDEO'
            ? { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: 'user' }
            : false,
        }
        const stream = await navigator.mediaDevices.getUserMedia(constraints)
        if (cancelled) { stream.getTracks().forEach(t => t.stop()); return }

        localStreamRef.current = stream
        if (localVideoRef.current && type === 'VIDEO') {
          localVideoRef.current.srcObject = stream
          localVideoRef.current.play().catch(() => {})
        }
        stream.getTracks().forEach(t => pc.addTrack(t, stream))

        // Callee: signal caller that we're ready to receive the offer
        if (!isInitiator) {
          socket.emit('webrtc:ready', { callId, to: peer.id })
        }
      } catch (e: any) {
        if (!cancelled) setErrMsg(e?.message || 'Microphone/camera permission denied')
      }
    })()

    return () => {
      cancelled = true
      socket.off('webrtc:ready', onReady)
      socket.off('webrtc:offer', onOffer)
      socket.off('webrtc:answer', onAnswer)
      socket.off('webrtc:ice', onIce)
      socket.off('call:accepted', onAccepted)
      socket.off('call:ended', onEnded)
      socket.off('call:rejected', onRejected)
    }
  }, [open])

  // ── Controls ──
  function toggleMute() {
    const s = localStreamRef.current; if (!s) return
    const next = !muted
    s.getAudioTracks().forEach(t => (t.enabled = !next))
    setMuted(next)
  }
  function toggleCam() {
    const s = localStreamRef.current; if (!s) return
    const next = !camOff
    s.getVideoTracks().forEach(t => (t.enabled = !next))
    setCamOff(next)
  }
  function toggleSpeaker() {
    const next = !speakerOff
    setSpeakerOff(next)
    if (remoteAudioRef.current) remoteAudioRef.current.muted = next
    if (remoteVideoRef.current) remoteVideoRef.current.muted = next
  }

  if (!open) return null

  const statusText =
    phase === 'ringing'
      ? isInitiator ? 'Ringing…' : 'Connecting…'
      : phase === 'in-call'
      ? `${type === 'VIDEO' ? '📹 Video' : '📞 Voice'} · ${fmt(secs)}`
      : 'Call ended'

  return (
    <div className="fixed inset-0 z-[200] bg-black/95 backdrop-blur-md flex items-center justify-center p-4">
      {/* Hidden audio element — plays remote audio for both voice and video calls */}
      <audio ref={remoteAudioRef} autoPlay playsInline className="hidden" />

      <div className="relative w-full max-w-2xl rounded-3xl border border-white/10 bg-[#0f0f1a] overflow-hidden shadow-2xl">

        {/* ── Header ── */}
        <div className="p-5 flex items-center gap-4 border-b border-white/[0.07]">
          <div className="relative">
            <Avatar className="w-12 h-12 border-2 border-violet-500/40">
              {peer.avatar && <AvatarImage src={peer.avatar} />}
              <AvatarFallback className="bg-violet-700 text-white font-semibold">
                {peer.username.slice(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            {phase === 'in-call' && (
              <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-emerald-400 border-2 border-[#0f0f1a]" />
            )}
          </div>
          <div className="flex-1 min-w-0">
            <div className="font-semibold text-white text-lg leading-tight">{peer.username}</div>
            <div className={`text-sm mt-0.5 ${phase === 'in-call' ? 'text-emerald-400' : 'text-white/50'}`}>
              {statusText}
            </div>
          </div>
        </div>

        {/* ── Video area ── */}
        {type === 'VIDEO' ? (
          <div className="relative bg-black aspect-video">
            {/* Remote video */}
            <video
              ref={remoteVideoRef}
              autoPlay
              playsInline
              className={`w-full h-full object-cover transition-opacity duration-300 ${phase === 'in-call' ? 'opacity-100' : 'opacity-0'}`}
            />
            {/* Avatar overlay while connecting */}
            {phase !== 'in-call' && (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-gradient-to-br from-violet-950/80 to-cyan-950/80">
                <Avatar className={`w-28 h-28 border-4 border-white/20 ${phase === 'ringing' ? 'animate-pulse' : ''}`}>
                  {peer.avatar && <AvatarImage src={peer.avatar} />}
                  <AvatarFallback className="bg-violet-700 text-white text-4xl">{peer.username.slice(0, 2).toUpperCase()}</AvatarFallback>
                </Avatar>
                <p className="text-white/60 text-sm">{statusText}</p>
              </div>
            )}
            {/* Local pip */}
            <div className="absolute bottom-3 right-3 w-32 sm:w-40 rounded-xl overflow-hidden border-2 border-white/20 bg-black shadow-lg" style={{ aspectRatio: '16/9' }}>
              <video
                ref={localVideoRef}
                autoPlay
                muted
                playsInline
                className={`w-full h-full object-cover [transform:scaleX(-1)] ${camOff ? 'invisible' : ''}`}
              />
              {camOff && (
                <div className="absolute inset-0 flex items-center justify-center text-white/40 text-xs bg-neutral-900">
                  Cam off
                </div>
              )}
            </div>
          </div>
        ) : (
          /* ── Audio call UI ── */
          <div className="flex flex-col items-center justify-center py-14 gap-5 bg-gradient-to-b from-violet-950/40 to-[#0f0f1a]">
            <div className={`relative ${phase === 'ringing' ? 'animate-pulse' : ''}`}>
              <Avatar className="w-28 h-28 border-4 border-violet-500/30">
                {peer.avatar && <AvatarImage src={peer.avatar} />}
                <AvatarFallback className="bg-violet-700 text-white text-4xl">
                  {peer.username.slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              {phase === 'in-call' && (
                <span className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-emerald-400 border-2 border-[#0f0f1a] flex items-center justify-center">
                  <span className="w-2 h-2 rounded-full bg-white animate-ping" />
                </span>
              )}
            </div>
            <div className="text-center">
              <div className="text-white text-xl font-semibold">{peer.username}</div>
              <div className={`text-sm mt-1 ${phase === 'in-call' ? 'text-emerald-400' : 'text-white/50'}`}>{statusText}</div>
            </div>
          </div>
        )}

        {/* ── Error banner ── */}
        {errMsg && (
          <div className="mx-4 mb-0 mt-0 bg-red-500/15 border border-red-500/25 text-red-300 text-xs px-4 py-2 rounded-lg text-center">
            {errMsg}
          </div>
        )}

        {/* ── Controls ── */}
        <div className="flex items-center justify-center gap-3 px-6 py-5">
          {/* Mute mic */}
          <button
            onClick={toggleMute}
            title={muted ? 'Unmute mic' : 'Mute mic'}
            className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${
              muted ? 'bg-red-600 text-white shadow-lg shadow-red-900/40' : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            {muted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
          </button>

          {/* Speaker */}
          <button
            onClick={toggleSpeaker}
            title={speakerOff ? 'Unmute speaker' : 'Mute speaker'}
            className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${
              speakerOff ? 'bg-red-600 text-white shadow-lg shadow-red-900/40' : 'bg-white/10 text-white hover:bg-white/20'
            }`}
          >
            {speakerOff ? <VolumeX className="w-6 h-6" /> : <Volume2 className="w-6 h-6" />}
          </button>

          {/* Camera (video only) */}
          {type === 'VIDEO' && (
            <button
              onClick={toggleCam}
              title={camOff ? 'Turn on camera' : 'Turn off camera'}
              className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${
                camOff ? 'bg-red-600 text-white shadow-lg shadow-red-900/40' : 'bg-white/10 text-white hover:bg-white/20'
              }`}
            >
              {camOff ? <VideoOff className="w-6 h-6" /> : <Video className="w-6 h-6" />}
            </button>
          )}

          {/* End call */}
          <button
            onClick={() => endCall()}
            title="End call"
            className="w-16 h-14 rounded-full bg-red-600 hover:bg-red-500 text-white flex items-center justify-center transition-all shadow-lg shadow-red-900/40"
          >
            <PhoneOff className="w-6 h-6" />
          </button>
        </div>
      </div>
    </div>
  )
}

// ── Incoming call toast ──────────────────────────────────────────────────────

interface IncomingCallToastProps {
  open: boolean
  callId: string
  type: 'AUDIO' | 'VIDEO'
  from: CallPeer
  onAccept: () => void
  onReject: () => void
}

export function IncomingCallToast({ open, from, type, onAccept, onReject }: IncomingCallToastProps) {
  if (!open) return null
  
  return (
    <>
      {/* Dark overlay backdrop */}
      <div className="fixed inset-0 z-[99998] bg-black/60 backdrop-blur-sm" />
      
      {/* Full-screen Messenger-style incoming call modal */}
      <div className="fixed inset-0 z-[99999] flex items-center justify-center p-4">
        <div className="w-full max-w-md rounded-3xl bg-gradient-to-b from-[#1a1a2e] to-[#111120] border border-white/10 shadow-2xl overflow-hidden animate-in zoom-in-50 fade-in duration-300">
          
          {/* Header with minimalist design */}
          <div className="px-6 py-4 text-center border-b border-white/5">
            <div className="text-sm font-medium text-white/60 uppercase tracking-widest">
              {type === 'VIDEO' ? '📹 Incoming Video Call' : '📞 Incoming Audio Call'}
            </div>
          </div>

          {/* Caller info - centered and prominent */}
          <div className="flex flex-col items-center justify-center py-12 px-6">
            {/* Avatar with animated ring */}
            <div className="relative mb-8">
              <div className="absolute inset-0 w-32 h-32 bg-emerald-500/20 rounded-full animate-pulse blur-xl" />
              <Avatar className="w-32 h-32 border-4 border-emerald-400/40 shadow-2xl shadow-emerald-500/20">
                {from.avatar && <AvatarImage src={from.avatar} />}
                <AvatarFallback className="bg-gradient-to-br from-violet-600 to-violet-800 text-white text-4xl font-bold">
                  {from.username.slice(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              {/* Pulsing dot indicator */}
              <span className="absolute bottom-2 right-2 w-5 h-5 rounded-full bg-emerald-400 animate-pulse shadow-lg shadow-emerald-500/50 flex items-center justify-center">
                <span className="w-2 h-2 rounded-full bg-white" />
              </span>
            </div>

            {/* Caller name */}
            <h2 className="text-3xl font-bold text-white mb-2 text-center">{from.username}</h2>
            
            {/* Status */}
            <div className="flex items-center justify-center gap-2 mb-8">
              <Phone className="w-4 h-4 text-emerald-400 animate-pulse" />
              <p className="text-sm font-medium text-emerald-400">Calling...</p>
            </div>
          </div>

          {/* Action buttons - large and prominent */}
          <div className="flex flex-col gap-3 p-6 bg-white/[0.02]">
            {/* Accept button - primary, bright green */}
            <button
              onClick={onAccept}
              className="w-full h-16 rounded-2xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-white text-lg font-bold flex items-center justify-center gap-3 transition-all shadow-lg shadow-emerald-500/30 hover:shadow-emerald-500/50"
            >
              <Phone className="w-6 h-6" />
              <span>Accept Call</span>
            </button>

            {/* Decline button - secondary, red */}
            <button
              onClick={onReject}
              className="w-full h-14 rounded-2xl bg-red-600/20 hover:bg-red-600/40 text-red-400 hover:text-red-300 text-base font-bold flex items-center justify-center gap-2 transition-all border border-red-500/20 hover:border-red-500/40"
            >
              <PhoneOff className="w-5 h-5" />
              <span>Decline</span>
            </button>
          </div>

          {/* Footer info */}
          <div className="px-6 py-4 text-center border-t border-white/5">
            <p className="text-xs text-white/40 font-medium">
              {type === 'VIDEO' 
                ? 'They want to share their video and audio' 
                : 'They want to talk to you'}
            </p>
          </div>
        </div>
      </div>
    </>
  )
}
