'use client'

import { useState, useEffect, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { MessageCircle, Send, ChevronLeft, Loader2, Phone, Video } from 'lucide-react'
import { getMessagesSocket } from '@/lib/messages-socket'
import { CallModal, type CallPeer } from '@/components/messaging/call-modal'
import { toast } from 'sonner'

interface Message {
  id: string; senderId: string; receiverId: string; content: string
  isRead: boolean; createdAt: string; vpsOrderInfo?: any
  sender: { id: string; username: string; avatar?: string }
  receiver: { id: string; username: string; avatar?: string }
}

interface Conversation {
  userId: string; username: string; avatar?: string
  lastMessage: string; lastMessageTime: string; unreadCount: number
}

interface OtherUser {
  id: string; username: string; avatar?: string; isActive: boolean
}

interface PrivateChatProps {
  selectedFriend?: { id: string; username: string; avatar?: string; bio?: string; isActive: boolean } | null
  onBack?: () => void
}

export function PrivateChat({ selectedFriend, onBack }: PrivateChatProps) {
  const { data: session } = useSession()
  const myId = (session?.user as any)?.id || ''
  const [conversations, setConversations] = useState<Conversation[]>([])
  const [selectedUser, setSelectedUser] = useState<OtherUser | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [messageText, setMessageText] = useState('')
  const [loading, setLoading] = useState(false)
  const [sending, setSending] = useState(false)
  const [showConversations, setShowConversations] = useState(true)
  const [activeCall, setActiveCall] = useState<{ callId: string; type: 'AUDIO' | 'VIDEO' } | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const selectedUserRef = useRef<OtherUser | null>(null)

  const isFetchingRef = useRef(false)
  const lastOpenedFriendIdRef = useRef<string | null>(null)

  useEffect(() => {
    selectedUserRef.current = selectedUser
  }, [selectedUser])

  useEffect(() => { 
    fetchConversations() 
  }, [])

  useEffect(() => {
    if (!myId) return
    const socket = getMessagesSocket(myId)
    const onNewMsg = (msg: Message) => {
      const peer = selectedUserRef.current
      if (peer && (msg.senderId === peer.id || msg.receiverId === peer.id)) {
        setMessages(prev => prev.some(m => m.id === msg.id) ? prev : [...prev, msg])
      }
      fetchConversations()
    }
    socket.on('newPrivateMessage', onNewMsg)
    socket.on('newMessage', onNewMsg)
    socket.on('messageSent', onNewMsg)
    
    // Standardize: ensure we join the room if socket reconnected
    if (socket.connected) {
      socket.emit('join', { userId: myId })
    }
    socket.on('connect', () => {
      socket.emit('join', { userId: myId })
      fetchConversations()
    })

    return () => {
      socket.off('newPrivateMessage', onNewMsg)
      socket.off('newMessage', onNewMsg)
      socket.off('messageSent', onNewMsg)
      socket.off('connect')
    }
  }, [myId])

  // ✅ FIXED (NO LOOP)
  useEffect(() => { 
    if (!selectedFriend?.id) return

    if (lastOpenedFriendIdRef.current === selectedFriend.id) return

    lastOpenedFriendIdRef.current = selectedFriend.id

    const newUser: OtherUser = {
      id: selectedFriend.id,
      username: selectedFriend.username,
      avatar: selectedFriend.avatar,
      isActive: selectedFriend.isActive
    }

    setTimeout(() => {
      openChat(newUser)
    }, 0)

  }, [selectedFriend])

  useEffect(() => { 
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }) 
  }, [messages])

  const fetchConversations = async () => {
    try {
      const res = await fetch('/api/messages/conversations')
      if (res.ok) { 
        const data = await res.json()
        setConversations(data.conversations || []) 
      }
    } catch (error) {
      console.error('Error fetching conversations:', error)
    }
  }

  // ✅ FIXED (ANTI SPAM + TIMEOUT)
  const fetchMessages = async (userId: string) => {
    if (isFetchingRef.current) return

    try {
      isFetchingRef.current = true
      setLoading(true)

      const controller = new AbortController()
      const timeoutId = setTimeout(() => controller.abort(), 10000) // 10 second timeout

      const res = await fetch(`/api/messages/${userId}`, {
        cache: 'no-store',
        signal: controller.signal
      })

      clearTimeout(timeoutId)

      if (res.ok) {
        const data = await res.json()

        setMessages(prev => {
          const newMsgs = data.messages || []

          if (JSON.stringify(prev) === JSON.stringify(newMsgs)) {
            return prev
          }

          return newMsgs
        })
      } else if (res.status === 404) {
        setMessages([])
      }

    } catch (error) {
      console.error('Error fetching messages:', error)
      // Don't show error to user, just clear messages on failure
      if (messages.length === 0) {
        setMessages([])
      }
    } finally { 
      setLoading(false) 
      isFetchingRef.current = false
    }
  }

  // ✅ FIXED
  const openChat = async (user: OtherUser) => {
    if (selectedUser?.id === user.id) return
    if (isFetchingRef.current) return

    setSelectedUser(user)
    setShowConversations(false)

    await fetchMessages(user.id)
  }

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!messageText.trim() || !selectedUser) return

    setSending(true)
    const socket = getMessagesSocket(myId)

    try {
      // ✅ Emit via socket for instant real-time sync
      socket.emit('sendMessage', { 
        receiverId: selectedUser.id, 
        content: messageText.trim() 
      })

      // Also call API to persist (socket handler in server.ts already persists, but we'll follow existing pattern)
      // Actually, server.ts already persists it in the 'sendMessage' listener.
      // So we only need to clear the input.
      
      setMessageText('')
      // fetchConversations() is already called in the socket listener
    } catch (error) {
      console.error('Error sending message:', error)
    } finally { 
      setSending(false) 
    }
  }

  const initiateCall = async (type: 'AUDIO' | 'VIDEO') => {
    if (!selectedUser || !myId) return
    
    try {
      const res = await fetch('/api/calls', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          receiverId: selectedUser.id, 
          type 
        })
      })

      if (res.ok) {
        const { callId } = await res.json()
        const socket = getMessagesSocket(myId)
        
        // Notify recipient via socket
        socket.emit('call:invite', {
          callId,
          targetUserIds: [selectedUser.id],
          type,
          from: { 
            id: myId, 
            username: session?.user?.name || 'User',
            avatar: (session?.user as any)?.avatar
          }
        })

        setActiveCall({ callId, type })
      } else {
        const error = await res.json()
        toast.error(error.error || 'Failed to initiate call')
      }
    } catch (error) {
      toast.error('Could not connect to call service')
    }
  }

  if (!showConversations && selectedUser) {
    return (
      <div className="bg-white/[0.03] border border-white/8 rounded-2xl flex flex-col h-[500px]">
        <div className="flex items-center gap-3 p-4 border-b border-white/10">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => {
              setShowConversations(true)
              setSelectedUser(null)
              lastOpenedFriendIdRef.current = null
              onBack?.()
            }}
            className="h-7 w-7 p-0 text-white/40 hover:text-white hover:bg-white/5 rounded-lg"
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>

          <Avatar className="h-8 w-8">
            {selectedUser.avatar && (
              <AvatarImage
                src={selectedUser.avatar}
                alt={selectedUser.username}
                onError={(e) => { e.currentTarget.style.display = 'none' }}
              />
            )}
            <AvatarFallback className="bg-purple-500/20 text-purple-300 text-xs">
              {selectedUser.username.slice(0, 2).toUpperCase()}
            </AvatarFallback>
          </Avatar>

          <div className="flex-1 min-w-0">
            <p className="font-semibold text-white text-sm truncate">{selectedUser.username}</p>
            <div className="flex items-center gap-1.5">
              <span className={`w-1.5 h-1.5 rounded-full ${selectedUser.isActive ? 'bg-green-400' : 'bg-white/20'}`} />
              <p className="text-xs text-white/40">{selectedUser.isActive ? 'Online' : 'Offline'}</p>
            </div>
          </div>

          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => initiateCall('AUDIO')}
              className="h-8 w-8 text-white/40 hover:text-green-400 hover:bg-green-400/10 rounded-lg"
            >
              <Phone className="w-4 h-4" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => initiateCall('VIDEO')}
              className="h-8 w-8 text-white/40 hover:text-blue-400 hover:bg-blue-400/10 rounded-lg"
            >
              <Video className="w-4 h-4" />
            </Button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-5 h-5 animate-spin text-purple-400" />
            </div>
          ) : messages.length === 0 ? (
            <div className="text-center py-12">
              <MessageCircle className="w-8 h-8 mx-auto text-white/15 mb-2" />
              <p className="text-sm text-white/30">No messages yet. Say hello!</p>
            </div>
          ) : (
            messages.map(msg => {
              const isOwn = msg.senderId !== selectedUser.id
              return (
                <div key={msg.id} className={`flex ${isOwn ? 'justify-end' : 'justify-start'}`}>
                  <div className={`max-w-[75%] px-3.5 py-2 rounded-2xl text-sm ${
                    isOwn
                      ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white rounded-br-md'
                      : 'bg-white/5 text-white/80 border border-white/10 rounded-bl-md'
                  }`}>
                    <p className="break-words">{msg.content}</p>
                    <p className={`text-[10px] mt-1 ${isOwn ? 'text-white/60' : 'text-white/30'}`}>
                      {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>
              )
            })
          )}
          <div ref={messagesEndRef} />
        </div>

        <form onSubmit={sendMessage} className="border-t border-white/10 p-3 flex gap-2">
          <Input
            placeholder="Type a message..."
            value={messageText}
            onChange={e => setMessageText(e.target.value)}
            className="flex-1 h-10 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl text-sm"
          />
          <Button
            type="submit"
            disabled={!messageText.trim() || sending}
            size="sm"
            className="h-10 px-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl"
          >
            <Send className="w-4 h-4" />
          </Button>
        </form>

        {activeCall && (
          <CallModal
            open
            onClose={() => setActiveCall(null)}
            callId={activeCall.callId}
            peer={{
              id: selectedUser.id,
              username: selectedUser.username,
              avatar: selectedUser.avatar
            }}
            type={activeCall.type}
            isInitiator={true}
            myUserId={myId}
          />
        )}
      </div>
    )
  }

  return (
    <div className="bg-white/[0.03] border border-white/8 rounded-2xl overflow-hidden h-[500px] flex flex-col">
      <div className="p-4 border-b border-white/10 flex items-center gap-2">
        <MessageCircle className="w-4 h-4 text-purple-400" />
        <span className="font-semibold text-white text-sm">Messages</span>
      </div>

      {conversations.length === 0 ? (
        <div className="flex-1 flex items-center justify-center text-center p-4">
          <div>
            <MessageCircle className="w-10 h-10 mx-auto text-white/15 mb-3" />
            <p className="text-sm text-white/30 mb-1">No conversations yet</p>
            <p className="text-xs text-white/20">Add friends to start chatting!</p>
          </div>
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto">
          {conversations.map(conv => (
            <button
              key={conv.userId}
              onClick={() => openChat({
                id: conv.userId,
                username: conv.username,
                avatar: conv.avatar,
                isActive: true
              })}
              className="w-full text-left p-3 hover:bg-white/5 transition-colors border-b border-white/5 last:border-0"
            >
              <div className="flex items-center gap-3">
                <Avatar className="h-9 w-9 flex-shrink-0">
                  {conv.avatar && <AvatarImage src={conv.avatar} alt={conv.username} />}
                  <AvatarFallback>{conv.username.slice(0, 2).toUpperCase()}</AvatarFallback>
                </Avatar>

                <div className="flex-1 min-w-0">
                  <p className="font-medium text-white text-sm truncate">{conv.username}</p>
                  <p className="text-xs text-white/30 truncate">{conv.lastMessage}</p>
                </div>

                {conv.unreadCount > 0 && (
                  <Badge className="bg-purple-500 text-white text-xs">
                    {conv.unreadCount}
                  </Badge>
                )}
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}