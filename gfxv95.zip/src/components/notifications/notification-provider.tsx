'use client'

import { useState, useEffect, createContext, useContext, ReactNode } from 'react'
import { useSession } from 'next-auth/react'
import { io, Socket } from 'socket.io-client'

interface Notification {
  id: string
  title: string
  content: string
  type: 'ITEM_APPROVED' | 'ITEM_REJECTED' | 'NEW_REVIEW' | 'DOWNLOAD_COMPLETE' | 'SYSTEM_ANNOUNCEMENT' | 'USER_MENTIONED' | 'DEPOSIT_APPROVED' | 'TRANSACTION_APPROVED' | 'ITEM_LIKED' | 'NEW_MESSAGE' | 'ADMIN_ANNOUNCEMENT'
  isRead: boolean
  createdAt: Date
  itemId?: string
}

export interface IncomingCallData {
  callId: string
  type: 'AUDIO' | 'VIDEO'
  from: { id: string; username: string; avatar?: string | null }
}

interface NotificationContextType {
  notifications: Notification[]
  unreadCount: number
  markAsRead: (id: string) => void
  clearAll: () => void
  // Real-time incoming call — set by the notification socket (always connected)
  incomingCall: IncomingCallData | null
  dismissIncomingCall: () => void
  // Expose socket so GlobalCallHandler can emit signaling events on the same connection
  notifSocket: Socket | null
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined)

export function NotificationProvider({ children }: { children: ReactNode }) {
  const { data: session } = useSession()
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [socket, setSocket] = useState<Socket | null>(null)
  const [incomingCall, setIncomingCall] = useState<IncomingCallData | null>(null)
  const [isConnected, setIsConnected] = useState(false)

  const unreadCount = notifications.filter(n => !n.isRead).length

  useEffect(() => {
    if (!session) {
      setSocket(null)
      setIsConnected(false)
      return
    }

    const userId = (session.user as any)?.id as string | undefined
    const username = (session.user as any)?.username || session.user?.name || session.user?.email

    // Create persistent socket connection
    const notificationSocket = io('/notifications', {
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 5000,
      reconnectionAttempts: Infinity,
      // Provide explicit auth payload so server can identify the user even if
      // session-cookie auth fails in some environments.
      auth: userId ? { userId, username } : undefined,
    })

    notificationSocket.on('connect', () => {
      setIsConnected(true)
    })

    notificationSocket.on('disconnect', () => {
      setIsConnected(false)
    })

    notificationSocket.on('connect_error', (error) => {
      console.error('[notif] connect error:', error)
    })

    notificationSocket.on('notification', (notification: Notification) => {
      setNotifications(prev => [notification, ...prev])
      if (Notification.permission === 'granted') {
        new Notification(notification.title, {
          body: notification.content,
          icon: '/favicon.ico'
        })
      }
    })

    notificationSocket.on('notifications', (userNotifications: Notification[]) => {
      setNotifications(userNotifications)
    })

    // ── Call signaling via notification namespace ──────────────────────────
    // The notification namespace is ALWAYS connected for every authenticated user
    // (session-cookie auth). Using it as the delivery channel for call:incoming
    // guarantees the callee receives the ring regardless of which page they are on.
    notificationSocket.on('call:incoming', (data: IncomingCallData) => {
      setIncomingCall(prev => {
        // Ignore duplicate events for the same call
        if (prev?.callId === data.callId) return prev
        return data
      })
    })

    notificationSocket.on('call:cancelled', ({ callId }: { callId: string }) => {
      setIncomingCall(prev => (prev?.callId === callId ? null : prev))
    })

    setSocket(notificationSocket)

    // Don't disconnect on unmount — keep the socket alive across page navigations
    return () => {
      // Only disconnect if there's no session
      if (!session) {
        notificationSocket.disconnect()
      }
    }
  }, [session])

  const markAsRead = async (id: string) => {
    try {
      const response = await fetch('/api/notifications/read', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id })
      })
      if (response.ok) {
        setNotifications(prev =>
          prev.map(n => n.id === id ? { ...n, isRead: true } : n)
        )
      }
    } catch {}
  }

  const clearAll = async () => {
    try {
      const response = await fetch('/api/notifications/clear', { method: 'POST' })
      if (response.ok) setNotifications([])
    } catch {}
  }

  return (
    <NotificationContext.Provider value={{
      notifications,
      unreadCount,
      markAsRead,
      clearAll,
      incomingCall,
      dismissIncomingCall: () => setIncomingCall(null),
      notifSocket: socket,
    }}>
      {children}
    </NotificationContext.Provider>
  )
}

export function useNotifications() {
  const context = useContext(NotificationContext)
  if (context === undefined) {
    throw new Error('useNotifications must be used within a NotificationProvider')
  }
  return context
}
