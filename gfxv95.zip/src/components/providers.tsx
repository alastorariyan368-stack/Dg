'use client'

import { SessionProvider } from 'next-auth/react'
import { ThemeProvider } from 'next-themes'
import { NotificationProvider } from '@/components/notifications/notification-provider'
import { Toaster } from '@/components/ui/toaster'
import { Suspense } from 'react'
import dynamic from 'next/dynamic'

const GlobalCallHandler = dynamic(() => import('@/components/global-call-handler').then(mod => mod.GlobalCallHandler), {
  ssr: false,
  loading: () => null,
})

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <SessionProvider>
      <ThemeProvider
        attribute="class"
        defaultTheme="system"
        enableSystem
        disableTransitionOnChange
      >
        <NotificationProvider>
          {children}
          <Toaster />
          <Suspense fallback={null}>
            <GlobalCallHandler />
          </Suspense>
        </NotificationProvider>
      </ThemeProvider>
    </SessionProvider>
  )
}
