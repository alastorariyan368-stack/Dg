'use client'

import { useEffect, useState, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Send, Users, MessageCircle, Loader2, AtSign, GripHorizontal } from 'lucide-react'
import { io, Socket } from 'socket.io-client'

function safeDate(val: any): Date {
  if (!val) return new Date()
  const d = new Date(val)
  return isFinite(d.getTime()) ? d : new Date()
}

function safeTimeStr(d: Date): string {
  try {
    const t = d.getTime()
    if (!isFinite(t)) return ''
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  } catch { return '' }
}

interface Message {
  id: string
  username: string
  message: string
  timestamp: Date
  mentions?: string[]
}

interface User {
  id: string
  username: string
  email: string
  avatar?: string
}

interface ChatWidgetProps {
  isOpen: boolean
  onToggle: () => void
}

export function ChatWidget({ isOpen, onToggle }: ChatWidgetProps) {
  const { data: session } = useSession()
  const [messages, setMessages] = useState<Message[]>([])
  const [onlineCount, setOnlineCount] = useState(0)
  const [message, setMessage] = useState('')
  const [isConnected, setIsConnected] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [allUsers, setAllUsers] = useState<User[]>([])
  const [showMentionSuggestions, setShowMentionSuggestions] = useState(false)
  const [mentionSearch, setMentionSearch] = useState('')
  const [filteredUsers, setFilteredUsers] = useState<User[]>([])
  const [position, setPosition] = useState({ x: 0, y: 0 })
  const [isDragging, setIsDragging] = useState(false)
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 })
  const [isMobile, setIsMobile] = useState(false)
  const [isInitialized, setIsInitialized] = useState(false)
  const socketRef = useRef<Socket | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  // Check if we're on Vercel (production) - disable Socket.IO for Vercel
  const isVercel = typeof window !== 'undefined' && window.location.hostname.includes('vercel.app')
  const useSocketIO = !isVercel
  const inputRef = useRef<HTMLInputElement>(null)
  const scrollAreaRef = useRef<HTMLDivElement>(null)
  const chatWidgetRef = useRef<HTMLDivElement>(null)

  // Initialize position and detect mobile on mount
  useEffect(() => {
    const checkMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }
    
    checkMobile()
    window.addEventListener('resize', checkMobile)
    
    // Set initial position to bottom-right
    setPosition({
      x: window.innerWidth - 410,
      y: window.innerHeight - 450
    })
    
    return () => window.removeEventListener('resize', checkMobile)
  }, [])

  // Fetch all users on mount
  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const res = await fetch('/api/users/list')
        if (res.ok) {
          const data = await res.json()
          setAllUsers(Array.isArray(data.users) ? data.users : [])
        }
      } catch (error) {
        console.error('Failed to fetch users:', error)
      }
    }
    
    fetchUsers()
  }, [])

  useEffect(() => {
    if (!isOpen) {
      setIsLoading(false)
      // Disconnect socket when closed to save resources
      if (socketRef.current) {
        socketRef.current.disconnect()
        socketRef.current = null
      }
      return
    }

    setIsLoading(true)
    let mounted = true

    // Allow guest visitors to chat
    let guestId = ''
    let guestName = ''
    if (!session?.user && typeof window !== 'undefined') {
      try {
        guestId = sessionStorage.getItem('gfx_guest_id') || ''
        guestName = sessionStorage.getItem('gfx_guest_name') || ''
        if (!guestId) {
          guestId = 'guest_' + Math.random().toString(36).slice(2, 10)
          sessionStorage.setItem('gfx_guest_id', guestId)
        }
        if (!guestName) {
          guestName = 'Guest_' + Math.floor(1000 + Math.random() * 9000)
          sessionStorage.setItem('gfx_guest_name', guestName)
        }
      } catch {}
    }

    const authUserId = session?.user?.id || guestId
    const authUsername = (session?.user?.name || session?.user?.email || guestName || 'Guest').toString()

    if (useSocketIO) {
      try {
        // Disconnect existing if any
        if (socketRef.current) socketRef.current.disconnect()

        const socket = io(typeof window !== 'undefined' ? window.location.origin : '', {
          path: '/socket.io/',
          transports: ['polling', 'websocket'],
          reconnection: true,
          reconnectionDelay: 1000,
          reconnectionAttempts: 10,
          timeout: 20000,
          auth: {
            userId: authUserId,
            username: authUsername,
            sessionId: authUserId,
            guest: !session?.user,
          }
        })

      socket.on('connect', () => {
        console.log('✅ Chat connected:', socket.id)
        if (mounted) {
          setIsConnected(true)
          setIsLoading(false)
        }
      })

      socket.on('disconnect', () => {
        console.log('❌ Chat disconnected')
        if (mounted) setIsConnected(false)
      })

      socket.on('chatMessages', (msgs: any) => {
        console.log('📨 Received initial messages:', msgs?.length || 0)
        if (Array.isArray(msgs) && mounted) {
          setMessages(msgs.map((m: any) => ({
            id: m.id || '',
            username: m.username || 'Unknown',
            message: m.message || '',
            timestamp: safeDate(m.timestamp),
            mentions: m.mentions || []
          })))
        }
      })

      socket.on('newMessage', (msg: any) => {
        console.log('💬 New message received:', msg)
        if (msg && msg.id && mounted) {
          setMessages(prev => [...prev, {
            id: msg.id,
            username: msg.username || 'Unknown',
            message: msg.message || '',
            timestamp: safeDate(msg.timestamp),
            mentions: msg.mentions || []
          }])
        }
      })

      socket.on('onlineUsers', (count: number) => {
        console.log('👥 Online users:', count)
        if (mounted) setOnlineCount(count || 0)
      })

      socket.on('error', (err: any) => {
        console.error('Chat error:', err)
        if (mounted) setIsLoading(false)
      })

      socket.on('connect_error', (err: any) => {
        console.error('Connection error:', err)
        if (mounted) {
          setIsLoading(false)
          setIsConnected(false)
        }
      })

      socketRef.current = socket

      return () => {
        mounted = false
        if (socketRef.current) {
          socketRef.current.disconnect()
        }
      }
    } catch (error) {
      console.error('Failed to initialize chat:', error)
      if (mounted) setIsLoading(false)
    }
    } else {
      // Fallback for Vercel/production - no real-time chat
      setIsConnected(false)
      setIsLoading(false)
      console.log('ℹ️ Real-time chat disabled on Vercel')
    }
  }, [isOpen, session])

  useEffect(() => {
    const scrollViewport = scrollAreaRef.current?.querySelector('[data-radix-scroll-area-viewport]') as HTMLElement
    if (scrollViewport) {
      setTimeout(() => {
        scrollViewport.scrollTop = scrollViewport.scrollHeight
      }, 50)
    }
  }, [messages])

  const handleMouseDown = (e: React.MouseEvent) => {
    if ((e.target as HTMLElement).closest('input, button')) return
    
    setIsDragging(true)
    if (chatWidgetRef.current) {
      const rect = chatWidgetRef.current.getBoundingClientRect()
      setDragOffset({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      })
    }
  }

  useEffect(() => {
    if (!isDragging) return

    const handleMouseMove = (e: MouseEvent) => {
      let newX = e.clientX - dragOffset.x
      let newY = e.clientY - dragOffset.y

      // Constrain position to viewport
      newX = Math.max(0, Math.min(newX, window.innerWidth - 384))
      newY = Math.max(0, Math.min(newY, window.innerHeight - 384))

      setPosition({
        x: newX,
        y: newY
      })
    }

    const handleMouseUp = () => {
      setIsDragging(false)
    }

    window.addEventListener('mousemove', handleMouseMove)
    window.addEventListener('mouseup', handleMouseUp)

    return () => {
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('mouseup', handleMouseUp)
    }
  }, [isDragging, dragOffset])

  const extractMentions = (text: string): string[] => {
    const mentionRegex = /@(\w+)/g
    const matches = text.match(mentionRegex) || []
    return matches.map(m => m.slice(1))
  }

  const handleMessageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const text = e.target.value
    setMessage(text)

    const lastAtIndex = text.lastIndexOf('@')
    if (lastAtIndex !== -1) {
      const afterAt = text.substring(lastAtIndex + 1)
      const isValidMentionStart = lastAtIndex === 0 || text[lastAtIndex - 1] === ' '
      
      if (isValidMentionStart && afterAt && !afterAt.includes(' ')) {
        setMentionSearch(afterAt.toLowerCase())
        const filtered = (Array.isArray(allUsers) ? allUsers : []).filter(user =>
          user.username?.toLowerCase().includes(afterAt.toLowerCase())
        )
        setFilteredUsers(filtered)
        setShowMentionSuggestions(true)
      } else {
        setShowMentionSuggestions(false)
      }
    } else {
      setShowMentionSuggestions(false)
    }
  }

  const handleUserMention = (username: string) => {
    const lastAtIndex = message.lastIndexOf('@')
    const beforeAt = message.substring(0, lastAtIndex)
    const afterAt = message.substring(lastAtIndex + 1)
    const afterSearch = afterAt.substring(mentionSearch.length)
    
    const newMessage = beforeAt + '@' + username + ' ' + afterSearch
    setMessage(newMessage)
    
    inputRef.current?.focus()
    
    setTimeout(() => {
      const event = new Event('input', { bubbles: true })
      inputRef.current?.dispatchEvent(event)
    }, 0)
  }

  const handleSend = () => {
    if (!message.trim() || !socketRef.current) {
      console.log('❌ Cannot send: empty message or no socket')
      return
    }

    try {
      const mentions = extractMentions(message.trim())
      console.log('📤 Sending message:', message.trim(), 'Mentions:', mentions)
      socketRef.current.emit('sendMessage', {
        text: message.trim(),
        mentions
      })
      setMessage('')
      setShowMentionSuggestions(false)
      console.log('✅ Message emitted')
    } catch (error) {
      console.error('❌ Failed to send message:', error)
    }
  }

  if (!isOpen) {
    return (
      <Button
        onClick={(e) => {
          e.preventDefault()
          e.stopPropagation()
          onToggle()
        }}
        className="fixed bottom-6 right-6 z-[9999] rounded-full w-14 h-14 shadow-2xl bg-gradient-to-br from-blue-600 to-violet-600 hover:scale-110 active:scale-95 transition-all duration-300"
        size="icon"
      >
        <MessageCircle className="h-6 w-6" />
        {onlineCount > 0 && (
          <Badge className="absolute -top-1 -right-1 bg-green-500 text-white text-xs">
            {onlineCount}
          </Badge>
        )}
      </Button>
    )
  }

  return (
    <div
      ref={chatWidgetRef}
      style={{
        position: 'fixed',
        left: isMobile ? '0' : `${position.x}px`,
        top: isMobile ? 'auto' : `${position.y}px`,
        bottom: isMobile ? '0' : 'auto',
        width: isMobile ? '100%' : '384px',
        height: isMobile ? '80vh' : '480px',
        zIndex: 99999,
        boxShadow: '0 20px 25px -5px rgba(0, 0, 0, 0.5)',
        overflow: 'hidden'
      }}
      className="flex flex-col rounded-t-3xl md:rounded-2xl border border-white/10 bg-[#0a0a1a] backdrop-blur-2xl"
    >
      <Card className="h-full flex flex-col">
        <CardHeader 
          onMouseDown={handleMouseDown}
          className="flex flex-row items-center justify-between space-y-0 pb-3 cursor-move select-none"
        >
          <div className="flex items-center gap-2">
            <GripHorizontal className="h-4 w-4 text-muted-foreground" />
            <CardTitle className="text-lg flex items-center gap-2">
              <MessageCircle className="h-5 w-5" />
              Chat
            </CardTitle>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="outline" className="text-xs">
              <Users className="h-3 w-3 mr-1" />
              {onlineCount}
            </Badge>
            <Button variant="ghost" size="sm" onClick={onToggle}>
              ×
            </Button>
          </div>
        </CardHeader>

        <CardContent className="flex-1 flex flex-col p-0 gap-0 overflow-hidden min-w-0">
          <ScrollArea ref={scrollAreaRef} className="flex-1 w-full overflow-hidden">
            <div className="space-y-2 px-2 py-2 w-full min-w-0">
              {isLoading && (
                <div className="flex items-center justify-center py-8 text-muted-foreground">
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  Loading...
                </div>
              )}
              {!isLoading && messages.length === 0 && (
                <div className="text-center text-xs text-muted-foreground py-8 px-2">
                  No messages yet. Use @username to mention someone!
                </div>
              )}
              {!isLoading && messages.length > 0 && messages.map((msg) => {
                const username = session?.user?.name?.split('@')[0] || session?.user?.username?.split('@')[0] || ''
                const hasHighlight = msg.mentions?.includes(username)
                const highlightClass = hasHighlight ? 'bg-yellow-500/20 border border-yellow-500/50' : ''

                return (
                  <div key={msg.id} className={`flex flex-col gap-0.5 p-1.5 rounded min-w-0 ${highlightClass}`}>
                    <div className="flex items-baseline gap-1 flex-wrap min-w-0">
                      <span className="font-semibold text-xs text-primary truncate min-w-0">
                        {msg.username}
                      </span>
                      <span className="text-xs text-muted-foreground whitespace-nowrap flex-shrink-0">
                        {safeTimeStr(msg.timestamp)}
                      </span>
                    </div>
                    <div className="text-xs text-foreground pl-1 min-w-0 overflow-hidden break-words">
                      {msg.message}
                    </div>
                    {msg.mentions && msg.mentions.length > 0 && (
                      <div className="text-xs mt-0.5 text-blue-600 min-w-0 break-words">
                        📌 @{msg.mentions.join(', @')}
                      </div>
                    )}
                  </div>
                )
              })}
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>

          {true ? (
            <div className="p-3 border-t">
              {!session?.user && (
                <div className="text-[10px] text-muted-foreground mb-1.5 text-center">
                  You're chatting as a guest. <a href="/auth/signin" className="text-primary underline">Sign in</a> for a permanent name.
                </div>
              )}
              <div className="relative">
                <div className="flex gap-2">
                  <Input
                    ref={inputRef}
                    value={message}
                    onChange={handleMessageChange}
                    onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                    placeholder={session?.user ? "Message... (type @ to mention)" : "Say hi to the community..."}
                    disabled={!isConnected}
                    className="flex-1 text-sm"
                  />
                  <Button
                    onClick={handleSend}
                    size="icon"
                    disabled={!isConnected || !message.trim()}
                    className="h-9 w-9"
                  >
                    <Send className="h-4 w-4" />
                  </Button>
                </div>

                {showMentionSuggestions && filteredUsers.length > 0 && (
                  <div className="absolute bottom-full mb-2 left-0 right-0 bg-background border border-primary rounded-lg shadow-lg max-h-40 overflow-y-auto z-50">
                    <div className="p-2 space-y-1">
                      {filteredUsers.map((user) => (
                        <button
                          key={user.id}
                          onClick={() => handleUserMention(user.username)}
                          className="w-full text-left px-3 py-2 rounded hover:bg-muted flex items-center gap-2 text-sm transition-colors"
                        >
                          <AtSign className="h-3 w-3 text-blue-600" />
                          <span className="font-medium">{user.username}</span>
                          <span className="text-xs text-muted-foreground ml-auto">
                            ({user.email})
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="p-3 border-t text-center text-xs text-muted-foreground">
              Sign in to chat
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
