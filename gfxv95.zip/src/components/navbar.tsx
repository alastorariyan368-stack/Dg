'use client'

import React, { useState, useEffect, useRef } from 'react'
import Link from 'next/link'
import { useSession, signOut } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuSeparator, DropdownMenuTrigger, DropdownMenuLabel,
} from '@/components/ui/dropdown-menu'
import { Input } from '@/components/ui/input'
import {
  Upload, User, LogOut, Settings, Package, Wallet,
  MessageCircle, Search, Heart, ShoppingCart, LayoutDashboard,
  Crown, Menu, X, Bell, Users, Home, Grid3X3, Gift,
  Award, Handshake, Video, Smartphone, Code2, Sparkles,
  Briefcase, CalendarDays, Users2, Shield, ChevronRight, Zap, BarChart2, Server,
  Trophy, ArrowDownCircle, ArrowUpCircle, ShoppingBag, Coins, ClipboardList,
  Youtube, Film, Mic, Globe, Key, Mail, Hash, Image as ImageIcon,   Tv, Bot
} from 'lucide-react'
import { NotificationBell } from '@/components/notifications/notification-bell'
import { useRouter, usePathname } from 'next/navigation'
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet'
import { Logo } from '@/components/logo'

interface NavbarProps { onChatToggle?: () => void }

const PRIMARY_LINKS = [
  { href: '/browse', label: 'Browse', icon: Grid3X3 },
  { href: '/features', label: 'Features', icon: Sparkles },
  { href: '/tasks', label: 'Earn', icon: Coins },
  { href: '/afk', label: 'AFK', icon: Zap },
  { href: '/ai', label: 'GFXV1 AI', icon: Sparkles },
  { href: '/reels', label: 'Reels', icon: Video },
  { href: '/videos', label: 'Videos', icon: Video },
  { href: '/apps', label: 'Apps', icon: Smartphone },
  { href: '/code', label: 'Code', icon: Code2 },
  { href: '/freebies', label: 'Freebies', icon: Gift },
  { href: '/community', label: 'Community', icon: Users },
  { href: '/tvchannel', label: 'TV Channel', icon: Tv },
  { href: '/adult', label: 'Adult 18+', icon: Film },
  { href: '/deploy', label: 'Deploy', icon: Server },
  { href: '/discordbot', label: 'Discord Bot', icon: Bot },
  { href: '/yt-video', label: 'YT Video', icon: Video },
  { href: '/memberships', label: 'Premium', icon: Crown },
]

const SECONDARY_LINKS = [
  { href: '/categories', label: 'Categories', icon: Package },
  { href: '/creators', label: 'Creators', icon: Users },
  { href: '/leaderboard', label: 'Leaderboard', icon: Trophy },
  { href: '/badges', label: 'Badges', icon: Award },
  { href: '/teams', label: 'Teams', icon: Users2 },
  { href: '/campaigns', label: 'Campaigns', icon: CalendarDays },
  { href: '/collaborations', label: 'Collaborations', icon: Handshake },
  { href: '/custom-orders', label: 'Custom Orders', icon: Briefcase },
  { href: '/vps', label: 'VPS Hosting', icon: Server },
  { href: '/panel', label: 'Server Panel', icon: Server },
  { href: '/rewards', label: 'Rewards', icon: Gift },
  { href: '/ai-chat', label: 'AI Assistant', icon: Sparkles },
  { href: '/ai-generate', label: 'AI Generate', icon: Zap },
  { href: '/ai-ide', label: 'AI Code IDE', icon: Code2 },
  { href: '/appdeploy', label: 'App Deploy', icon: Server },
  { href: '/youtube-gen', label: 'YouTube Gen', icon: Youtube },
  { href: '/ai-video', label: 'AI Video Gen', icon: Film },
  { href: '/google-vids', label: 'Google Vids', icon: Video },
  { href: '/ai-voice', label: 'AI Voice (TTS)', icon: Mic },
  { href: '/developer', label: 'Developer Portal', icon: Key },
  { href: '/tickets', label: 'Support Tickets', icon: ClipboardList },
]

export function Navbar({ onChatToggle }: NavbarProps) {
  const { data: session } = useSession()
  const router = useRouter()
  const pathname = usePathname()

  const [balance, setBalance] = useState(0)
  const [cartCount, setCartCount] = useState(0)
  const [wishlistCount, setWishlistCount] = useState(0)
  const [searchQuery, setSearchQuery] = useState('')
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const scrolledRef = useRef(false)
  const [mounted, setMounted] = useState(false)
  const [isSearchVisible, setIsSearchVisible] = useState(false)

  const isAdmin = session?.user?.role === 'ADMIN' || session?.user?.role === 'SUPER_ADMIN'

  useEffect(() => {
    setMounted(true)
    if (session?.user?.id) {
      const loadNavData = () => fetchNavData()
      const idleId = 'requestIdleCallback' in window
        ? window.requestIdleCallback(loadNavData, { timeout: 2000 })
        : setTimeout(loadNavData, 500)
      const t = setInterval(fetchNavData, 120000)
      return () => {
        clearInterval(t)
        if ('cancelIdleCallback' in window && typeof idleId === 'number') window.cancelIdleCallback(idleId)
        else clearTimeout(idleId)
      }
    }
  }, [session?.user?.id])

  useEffect(() => { setDrawerOpen(false) }, [pathname])

  useEffect(() => {
    const onScroll = () => {
      const next = window.scrollY > 4
      if (scrolledRef.current !== next) {
        scrolledRef.current = next
        setScrolled(next)
      }
    }
    window.addEventListener('scroll', onScroll, { passive: true })
    onScroll()
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const fetchNavData = async () => {
    try {
      const r = await fetch('/api/users/nav-data')
      if (r.ok) {
        const d = await r.json()
        setBalance(d.balance ?? 0)
        setCartCount(d.cartCount ?? 0)
        setWishlistCount(d.wishlistCount ?? 0)
      }
    } catch {}
  }

  const submitSearch = (e: React.FormEvent) => {
    e.preventDefault()
    if (!searchQuery.trim()) return
    router.push(`/browse?q=${encodeURIComponent(searchQuery.trim())}`)
    setDrawerOpen(false)
  }

  const isActive = (href: string) =>
    mounted && (href === '/' ? pathname === '/' : pathname === href || pathname.startsWith(href + '/'))

  return (
    <React.Fragment>
      {/* Top header */}
      <header className={`sticky top-0 z-50 w-full transition-all duration-300 ${scrolled ? 'bg-[#0a0a12]/90 backdrop-blur-xl border-b border-white/[0.06] shadow-[0_4px_20px_rgba(0,0,0,0.4)]' : 'bg-[#0a0a12]/80 backdrop-blur-md border-b border-white/[0.04]'}`}>
        <div className="container mx-auto flex h-16 items-center px-3 sm:px-4 gap-2 sm:gap-4">
          {/* Mobile: hamburger */}
          {mounted && (
            <Sheet open={drawerOpen} onOpenChange={setDrawerOpen}>
              <SheetTrigger asChild>
                <button className="lg:hidden p-2 -ml-1 rounded-lg text-white/70 hover:text-white hover:bg-white/5 transition" aria-label="Menu">
                  <Menu className="w-5 h-5" />
                </button>
              </SheetTrigger>
              <SheetContent side="left" className="w-[88%] max-w-sm bg-[#0a0a12] border-r border-white/[0.06] text-white p-0 overflow-y-auto">
                <SheetHeader className="px-5 pt-5 pb-4 border-b border-white/[0.05]">
                  <SheetTitle className="sr-only">Menu</SheetTitle>
                  <Logo size="md" animated={false} />
                </SheetHeader>

                <form onSubmit={submitSearch} className="px-5 py-4 border-b border-white/[0.05]">
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                    <Input
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search marketplace…"
                      className="pl-9 h-11 bg-white/[0.04] border-white/10 text-white placeholder:text-white/30"
                    />
                  </div>
                </form>

                {session?.user && (
                  <Link href="/profile" className="flex items-center gap-3 px-5 py-4 border-b border-white/[0.05] hover:bg-white/[0.03]">
                    <Avatar className="w-11 h-11 border-2 border-violet-500/30">
                      <AvatarImage src={session.user.image || (session.user as any).avatar || undefined} />
                      <AvatarFallback className="bg-gradient-to-br from-violet-600 to-cyan-600 text-white font-semibold">
                        {(session.user.name || (session.user as any).username || 'U')?.[0]?.toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="min-w-0 flex-1">
                      <div className="font-semibold truncate">{session.user.name || (session.user as any).username || 'User'}</div>
                      <div className="text-xs text-white/40 truncate">৳{balance.toLocaleString()} balance</div>
                    </div>
                    <ChevronRight className="w-4 h-4 text-white/30" />
                  </Link>
                )}

                <div className="px-3 py-3 space-y-0.5">
                  <div className="text-[10px] font-bold text-white/30 uppercase tracking-wider px-3 mb-1">Discover</div>
                  {PRIMARY_LINKS.map(({ href, label, icon: Icon }) => (
                    <Link key={href} href={href}
                      className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition ${isActive(href) ? 'bg-violet-500/15 text-violet-300' : 'text-white/70 hover:text-white hover:bg-white/[0.04]'}`}>
                      <Icon className="w-4 h-4" /> {label}
                    </Link>
                  ))}

                  <div className="text-[10px] font-bold text-white/30 uppercase tracking-wider px-3 mb-1 mt-4">Free Tools</div>
                  <Link href="/tempmail" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-sky-400/80 hover:text-sky-300 hover:bg-sky-500/[0.06] transition">
                    <Mail className="w-4 h-4" /> Temp Mail
                  </Link>
                  <Link href="/tempnum" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-emerald-400/80 hover:text-emerald-300 hover:bg-emerald-500/[0.06] transition">
                    <Hash className="w-4 h-4" /> Temp Number
                  </Link>
                  <Link href="/yt-thumbnail" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-rose-400/80 hover:text-rose-300 hover:bg-rose-500/[0.06] transition">
                    <ImageIcon className="w-4 h-4" /> YT Thumbnail DL
                  </Link>
                  <Link href="/yt-video" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-rose-400/80 hover:text-rose-300 hover:bg-rose-500/[0.06] transition">
                    <Video className="w-4 h-4" /> YT Video DL
                  </Link>
                  <div className="text-[10px] font-bold text-white/30 uppercase tracking-wider px-3 mb-1 mt-4">Community & Tools</div>
                  {SECONDARY_LINKS.map(({ href, label, icon: Icon }) => (
                    <Link key={href} href={href}
                      className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition ${isActive(href) ? 'bg-violet-500/15 text-violet-300' : 'text-white/70 hover:text-white hover:bg-white/[0.04]'}`}>
                      <Icon className="w-4 h-4" /> {label}
                    </Link>
                  ))}

                  {session?.user && (
                    <React.Fragment>
                      <div className="text-[10px] font-bold text-white/30 uppercase tracking-wider px-3 mb-1 mt-4">My Account</div>
                      <Link href="/dashboard" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-white/70 hover:text-white hover:bg-white/[0.04]">
                        <LayoutDashboard className="w-4 h-4" /> Dashboard
                      </Link>
                      <Link href="/cart" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-white/70 hover:text-white hover:bg-white/[0.04]">
                        <ShoppingCart className="w-4 h-4" /> Cart {cartCount > 0 && <Badge className="ml-auto bg-violet-500 text-white">{cartCount}</Badge>}
                      </Link>
                      <Link href="/wishlist" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-white/70 hover:text-white hover:bg-white/[0.04]">
                        <Heart className="w-4 h-4" /> Wishlist {wishlistCount > 0 && <Badge className="ml-auto bg-violet-500 text-white">{wishlistCount}</Badge>}
                      </Link>
                      <Link href="/orders" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-white/70 hover:text-white hover:bg-white/[0.04]">
                        <ShoppingBag className="w-4 h-4" /> My Orders
                      </Link>
                      <Link href="/messages" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-white/70 hover:text-white hover:bg-white/[0.04]">
                        <MessageCircle className="w-4 h-4" /> Messages
                      </Link>
                      <Link href="/tunnels" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-orange-400/80 hover:text-orange-300 hover:bg-orange-500/[0.06]">
                        <Globe className="w-4 h-4" /> Zero Trust Tunnels
                      </Link>
                      <div className="text-[10px] font-bold text-white/30 uppercase tracking-wider px-3 mb-1 mt-3">Finance</div>
                      <Link href="/deposit" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/[0.06]">
                        <ArrowDownCircle className="w-4 h-4" /> Deposit
                      </Link>
                      <Link href="/wallet" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-cyan-400 hover:text-cyan-300 hover:bg-cyan-500/[0.06]">
                        <ArrowUpCircle className="w-4 h-4" /> Withdraw
                      </Link>
                      <Link href="/wallet" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-white/70 hover:text-white hover:bg-white/[0.04]">
                        <Wallet className="w-4 h-4" /> Wallet
                      </Link>
                      <div className="text-[10px] font-bold text-white/30 uppercase tracking-wider px-3 mb-1 mt-3">Seller</div>
                      <Link href="/upload" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-white/70 hover:text-white hover:bg-white/[0.04]">
                        <Upload className="w-4 h-4" /> Upload Item
                      </Link>
                      <Link href="/leaderboard" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-white/70 hover:text-white hover:bg-white/[0.04]">
                        <Trophy className="w-4 h-4" /> Leaderboard
                      </Link>
                      <Link href="/settings" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-white/70 hover:text-white hover:bg-white/[0.04]">
                        <Settings className="w-4 h-4" /> Settings
                      </Link>
                      {isAdmin && (
                        <Link href="/admin" className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-violet-400 hover:text-violet-300 hover:bg-violet-500/[0.08]">
                          <Shield className="w-4 h-4" /> Admin Panel
                        </Link>
                      )}
                      <button onClick={() => signOut()} className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-white/70 hover:text-red-400 hover:bg-red-500/[0.06] w-full text-left transition">
                        <LogOut className="w-4 h-4" /> Sign Out
                      </button>
                    </React.Fragment>
                  )}

                  {!session?.user && (
                    <div className="flex flex-col gap-2 mt-4 px-1">
                      <Button asChild variant="outline" className="w-full border-white/10 text-white hover:bg-white/[0.05]">
                        <Link href="/auth/signin">Sign In</Link>
                      </Button>
                      <Button asChild className="w-full bg-gradient-to-r from-violet-600 to-cyan-600 text-white">
                        <Link href="/auth/signup">Sign Up</Link>
                      </Button>
                    </div>
                  )}
                </div>
              </SheetContent>
            </Sheet>
          )}

          <Logo size="md" />

          {/* Desktop nav */}
          <nav className="hidden lg:flex items-center gap-0.5 ml-2">
            {PRIMARY_LINKS.map(({ href, label }) => (
              <Link key={href} href={href}
                className={`px-2.5 py-1.5 rounded-lg text-[13px] font-bold transition ${isActive(href) ? 'text-white bg-white/[0.07]' : 'text-white/60 hover:text-white hover:bg-white/[0.04]'}`}>
                {label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-1.5 ml-auto">
            {/* Desktop Search */}
            <form onSubmit={submitSearch} className="hidden lg:flex items-center">
              <div className={`relative transition-all duration-300 ${isSearchVisible ? 'w-64 opacity-100' : 'w-0 opacity-0 pointer-events-none'}`}>
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search…"
                  className="pl-9 h-9 bg-white/[0.04] border-white/[0.08] text-white placeholder:text-white/30 text-sm rounded-full"
                />
              </div>
              <button 
                type="button"
                onClick={() => setIsSearchVisible(!isSearchVisible)}
                className={`p-2 rounded-full transition-colors ${isSearchVisible ? 'text-violet-400 bg-violet-500/10' : 'text-white/60 hover:text-white hover:bg-white/5'}`}
              >
                <Search className="w-5 h-5" />
              </button>
            </form>

            {session?.user ? (
              <React.Fragment>
                <div className="flex items-center gap-1 sm:gap-1.5">
                  <NotificationBell />
                  <div className="hidden md:flex items-center gap-1">
                    <Link href="/cart" className="relative p-2 rounded-lg text-white/60 hover:text-white hover:bg-white/[0.05] transition">
                      <ShoppingCart className="w-5 h-5" />
                      {cartCount > 0 && <span className="absolute top-1 right-1 w-4 h-4 bg-violet-500 rounded-full text-[10px] flex items-center justify-center text-white font-bold">{cartCount}</span>}
                    </Link>
                  </div>
                </div>

                <Link href="/deposit" className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-full bg-white/[0.04] border border-white/[0.08] text-white/80 hover:text-white hover:bg-white/[0.07] text-[10px] sm:text-sm transition ml-0.5 sm:ml-1">
                  <Wallet className="w-3.5 h-3.5 text-violet-400" />
                  <span className="font-bold tracking-tight">৳{balance.toLocaleString()}</span>
                </Link>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button className="flex items-center gap-2 p-1 rounded-full hover:bg-white/[0.05] transition border border-white/5">
                      <Avatar className="w-8 h-8 border border-violet-500/30">
                        <AvatarImage src={session.user.image || (session.user as any).avatar || undefined} />
                        <AvatarFallback className="bg-gradient-to-br from-violet-600 to-cyan-600 text-white text-xs font-semibold">
                          {(session.user.name || (session.user as any).username || 'U')?.[0]?.toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-64 bg-[#0f0f1a] border-white/[0.08] text-white">
                    <div className="flex items-center gap-3 px-3 py-3">
                      <Avatar className="w-10 h-10 border border-violet-500/30">
                        <AvatarImage src={session.user.image || (session.user as any).avatar || undefined} />
                        <AvatarFallback className="bg-gradient-to-br from-violet-600 to-cyan-600 text-white text-sm font-semibold">
                          {(session.user.name || (session.user as any).username || 'U')?.[0]?.toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="min-w-0 flex-1">
                        <div className="font-semibold text-sm text-white truncate">{session.user.name || (session.user as any).username || 'User'}</div>
                        <div className="text-xs text-white/40 truncate">{session.user.email}</div>
                      </div>
                    </div>
                    <DropdownMenuSeparator className="bg-white/[0.06]" />
                    <DropdownMenuItem asChild><Link href="/profile" className="flex items-center gap-2"><User className="w-4 h-4" /> Profile</Link></DropdownMenuItem>
                    <DropdownMenuItem asChild><Link href="/dashboard" className="flex items-center gap-2"><LayoutDashboard className="w-4 h-4" /> Dashboard</Link></DropdownMenuItem>
                    <DropdownMenuSeparator className="bg-white/[0.06]" />
                    <DropdownMenuItem asChild>
                      <Link href="/deposit" className="flex items-center gap-2 text-emerald-400 focus:text-emerald-400">
                        <ArrowDownCircle className="w-4 h-4" /> Deposit
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem asChild><Link href="/wallet" className="flex items-center gap-2 text-cyan-400 focus:text-cyan-400"><ArrowUpCircle className="w-4 h-4" /> Withdraw</Link></DropdownMenuItem>
                    <DropdownMenuItem asChild><Link href="/wallet" className="flex items-center gap-2"><Wallet className="w-4 h-4" /> Wallet</Link></DropdownMenuItem>
                    <DropdownMenuSeparator className="bg-white/[0.06]" />
                    <DropdownMenuItem asChild><Link href="/upload" className="flex items-center gap-2"><Upload className="w-4 h-4" /> Upload Item</Link></DropdownMenuItem>
                    <DropdownMenuItem asChild><Link href="/orders" className="flex items-center gap-2"><ShoppingBag className="w-4 h-4" /> My Orders</Link></DropdownMenuItem>
                    <DropdownMenuItem asChild><Link href="/messages" className="flex items-center gap-2"><MessageCircle className="w-4 h-4" /> Messages</Link></DropdownMenuItem>
                    <DropdownMenuItem asChild><Link href="/tasks" className="flex items-center gap-2"><Briefcase className="w-4 h-4" /> Tasks</Link></DropdownMenuItem>
                    <DropdownMenuItem asChild><Link href="/your-tasks" className="flex items-center gap-2"><ClipboardList className="w-4 h-4" /> My Tasks</Link></DropdownMenuItem>
                    <DropdownMenuItem asChild><Link href="/leaderboard" className="flex items-center gap-2"><Trophy className="w-4 h-4" /> Leaderboard</Link></DropdownMenuItem>
                    <DropdownMenuSeparator className="bg-white/[0.06]" />
                    <DropdownMenuLabel className="text-[10px] uppercase tracking-wider text-white/40">AI Studio</DropdownMenuLabel>
                    <DropdownMenuItem asChild><Link href="/ai-chat" className="flex items-center gap-2"><Sparkles className="w-4 h-4 text-violet-400" /> AI Assistant</Link></DropdownMenuItem>
                    <DropdownMenuItem asChild><Link href="/ai-generate" className="flex items-center gap-2"><Zap className="w-4 h-4 text-cyan-400" /> AI Image Gen</Link></DropdownMenuItem>
                    <DropdownMenuItem asChild><Link href="/ai-ide" className="flex items-center gap-2"><Code2 className="w-4 h-4 text-emerald-400" /> AI Code IDE</Link></DropdownMenuItem>
                    <DropdownMenuItem asChild><Link href="/youtube-gen" className="flex items-center gap-2"><Youtube className="w-4 h-4 text-red-400" /> YouTube Gen</Link></DropdownMenuItem>
                    <DropdownMenuItem asChild><Link href="/ai-video" className="flex items-center gap-2"><Film className="w-4 h-4 text-fuchsia-400" /> AI Video Gen</Link></DropdownMenuItem>
                    <DropdownMenuItem asChild><Link href="/ai-voice" className="flex items-center gap-2"><Mic className="w-4 h-4 text-amber-400" /> AI Voice (TTS)</Link></DropdownMenuItem>
                    <DropdownMenuItem asChild><Link href="/yt-thumbnail" className="flex items-center gap-2"><ImageIcon className="w-4 h-4 text-rose-400" /> YT Thumbnail DL</Link></DropdownMenuItem>
                    <DropdownMenuItem asChild><Link href="/yt-video" className="flex items-center gap-2"><Video className="w-4 h-4 text-rose-400" /> YT Video DL</Link></DropdownMenuItem>
                    <DropdownMenuSeparator className="bg-white/[0.06]" />
                    <DropdownMenuLabel className="text-[10px] uppercase tracking-wider text-white/40">Free Tools</DropdownMenuLabel>
                    <DropdownMenuItem asChild><Link href="/tempmail" className="flex items-center gap-2"><Mail className="w-4 h-4 text-sky-400" /> Temp Mail</Link></DropdownMenuItem>
                    <DropdownMenuItem asChild><Link href="/tempnum" className="flex items-center gap-2"><Hash className="w-4 h-4 text-emerald-400" /> Temp Number</Link></DropdownMenuItem>
                    <DropdownMenuSeparator className="bg-white/[0.06]" />
                    <DropdownMenuItem asChild><Link href="/settings" className="flex items-center gap-2"><Settings className="w-4 h-4" /> Settings</Link></DropdownMenuItem>
                      {isAdmin && (
                        <React.Fragment>
                          <DropdownMenuSeparator className="bg-white/[0.06]" />
                          <DropdownMenuItem asChild><Link href="/admin" className="flex items-center gap-2 text-violet-400"><Shield className="w-4 h-4" /> Admin Panel</Link></DropdownMenuItem>
                          <DropdownMenuItem asChild><Link href="/admin/ai" className="flex items-center gap-2 text-purple-400"><Sparkles className="w-4 h-4" /> AI GFXV1 Control</Link></DropdownMenuItem>
                          <DropdownMenuItem asChild><Link href="/admin/discordbot" className="flex items-center gap-2 text-cyan-400"><Bot className="w-4 h-4" /> Discord Bot Config</Link></DropdownMenuItem>
                        </React.Fragment>
                      )}
                    <DropdownMenuSeparator className="bg-white/[0.06]" />
                    <DropdownMenuItem onClick={() => signOut()} className="text-red-400 focus:text-red-400 flex items-center gap-2 cursor-pointer">
                      <LogOut className="w-4 h-4" /> Sign Out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </React.Fragment>
            ) : (
              <React.Fragment>
                <Button asChild variant="ghost" size="sm" className="text-white/70 hover:text-white">
                  <Link href="/auth/signin">Sign In</Link>
                </Button>
                <Button asChild size="sm" className="bg-gradient-to-r from-violet-600 to-cyan-600 text-white">
                  <Link href="/auth/signup">Sign Up</Link>
                </Button>
              </React.Fragment>
            )}
          </div>
        </div>
      </header>

    </React.Fragment>
  )
}
