'use client'

import { useMemo, useRef } from 'react'
import Link from 'next/link'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel'
import Autoplay from 'embla-carousel-autoplay'
import { Play, Smartphone, Code2, Package, Video as VideoIcon, ArrowRight, Eye, Heart, Download } from 'lucide-react'

type Slide = {
  id: string
  href: string
  title: string
  subtitle?: string
  image?: string
  kind: 'video' | 'reel' | 'app' | 'code' | 'item'
  badge?: string
  meta?: string
}

const KIND_META: Record<Slide['kind'], { label: string; icon: any; gradient: string; ring: string; pillBg: string }> = {
  video: { label: 'VIDEO', icon: VideoIcon, gradient: 'from-rose-600/30 via-pink-600/20 to-fuchsia-600/30', ring: 'ring-rose-500/40', pillBg: 'bg-rose-500/30 text-rose-100 border-rose-400/40' },
  reel:  { label: 'REEL',  icon: Play,      gradient: 'from-pink-600/30 via-violet-600/20 to-cyan-600/30',  ring: 'ring-pink-500/40',  pillBg: 'bg-pink-500/30 text-pink-100 border-pink-400/40' },
  app:   { label: 'APP',   icon: Smartphone,gradient: 'from-emerald-600/30 via-teal-600/20 to-cyan-600/30', ring: 'ring-emerald-500/40', pillBg: 'bg-emerald-500/30 text-emerald-100 border-emerald-400/40' },
  code:  { label: 'CODE',  icon: Code2,     gradient: 'from-amber-600/30 via-orange-600/20 to-yellow-600/30', ring: 'ring-amber-500/40', pillBg: 'bg-amber-500/30 text-amber-100 border-amber-400/40' },
  item:  { label: 'ITEM',  icon: Package,   gradient: 'from-violet-600/30 via-fuchsia-600/20 to-cyan-600/30', ring: 'ring-violet-500/40', pillBg: 'bg-violet-500/30 text-violet-100 border-violet-400/40' },
}

interface Props {
  apps: any[]
  codes: any[]
  videos: any[]
  reels: any[]
  items: any[]
  title?: string
  subtitle?: string
  compact?: boolean
}

function fmt(n: number = 0) {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`
  return String(n)
}

export function HomeHeroSlides({ apps, codes, videos, reels, items, title, subtitle, compact }: Props) {
  const autoplay = useRef(Autoplay({ delay: 4500, stopOnInteraction: false, stopOnMouseEnter: true }))

  const slides = useMemo<Slide[]>(() => {
    const interleave: Slide[] = []
    const queues: Slide[][] = [
      (videos || []).slice(0, 6).map((v: any): Slide => ({
        id: `v-${v.id}`, href: `/videos/${v.id}`, title: v.title, subtitle: v.description || v.author?.username,
        image: v.thumbnail, kind: 'video', meta: `${fmt(v.views)} views`,
      })),
      (reels || []).slice(0, 6).map((r: any): Slide => ({
        id: `r-${r.id}`, href: `/videos/${r.id}`, title: r.title, subtitle: r.author?.username,
        image: r.thumbnail, kind: 'reel', meta: `${fmt(r.views)} plays`,
      })),
      (apps || []).slice(0, 6).map((a: any): Slide => ({
        id: `a-${a.id}`, href: `/apps/${a.id}`, title: a.title, subtitle: a.shortDesc || a.category,
        image: a.icon || a.banner, kind: 'app', meta: `${fmt(a.downloads)} downloads`,
      })),
      (codes || []).slice(0, 6).map((c: any): Slide => ({
        id: `c-${c.id}`, href: `/code/${c.id}`, title: c.title, subtitle: c.shortDesc || `${c.language || ''} ${c.type || ''}`.trim(),
        image: c.thumbnail, kind: 'code', meta: `${fmt(c.downloads)} downloads`,
      })),
      (items || []).slice(0, 8).map((i: any): Slide => ({
        id: `i-${i.id}`, href: `/items/${i.slug}`, title: i.title, subtitle: i.shortDesc || i.category?.name,
        image: i.logo || i.banner, kind: 'item', meta: `${fmt(i.likes)} likes`,
      })),
    ]
    let idx = 0
    while (queues.some(q => q.length)) {
      const q = queues[idx % queues.length]
      const next = q.shift()
      if (next) interleave.push(next)
      idx++
    }
    return interleave
  }, [apps, codes, videos, reels, items])

  if (slides.length === 0) return null

  return (
    <section className={compact ? 'px-3 sm:px-4 pt-3 pb-3' : 'px-3 sm:px-4 pt-4 pb-8'}>
      <div className="container mx-auto">
        <div className={`flex items-end justify-between ${compact ? 'mb-2' : 'mb-4'} px-1`}>
          <div>
            <Badge className={`${compact ? 'mb-1 px-2 py-0.5 text-[9px]' : 'mb-2 px-3 py-1 text-[10px]'} bg-violet-500/20 text-violet-200 border-violet-500/30 tracking-wider`}>
              FRESH ON GFXSTORE
            </Badge>
            <h2 className={compact ? 'text-base sm:text-lg font-bold text-white' : 'text-2xl sm:text-3xl font-bold text-white'}>{title || 'Latest from creators'}</h2>
            {!compact && <p className="text-white/50 text-sm mt-1">{subtitle || 'Videos, reels, apps, code & items — auto-rotating slideshow'}</p>}
          </div>
          <Link href="/browse?sort=-createdAt" className="hidden sm:inline-flex">
            <Button variant="ghost" className="text-white/60 hover:text-white gap-2">
              View All <ArrowRight className="w-4 h-4" />
            </Button>
          </Link>
        </div>

        <Carousel
          opts={{ align: 'start', loop: true }}
          plugins={[autoplay.current]}
          onMouseEnter={() => autoplay.current.stop()}
          onMouseLeave={() => autoplay.current.play()}
          className="relative"
        >
          <CarouselContent className="-ml-3">
            {slides.map((s) => {
              const meta = KIND_META[s.kind]
              const Icon = meta.icon
              const isVertical = s.kind === 'reel'
              return (
                <CarouselItem key={s.id} className={compact ? 'pl-3 basis-[60%] sm:basis-[40%] md:basis-[28%] lg:basis-[22%]' : 'pl-3 basis-[85%] sm:basis-[60%] md:basis-[45%] lg:basis-[33%]'}>
                  <Link href={s.href} className="block group">
                    <div className={`relative ${compact ? 'aspect-[16/10]' : isVertical ? 'aspect-[9/14]' : 'aspect-[16/9]'} ${compact ? 'rounded-2xl' : 'rounded-3xl'} overflow-hidden border border-white/10 bg-gradient-to-br ${meta.gradient} shadow-lg shadow-black/40 transition-all group-hover:ring-2 ${meta.ring}`}>
                      {s.image ? (
                        <img src={s.image} alt={s.title} className="absolute inset-0 w-full h-full object-cover" />
                      ) : (
                        <div className="absolute inset-0 flex items-center justify-center">
                          <Icon className="w-16 h-16 text-white/30" />
                        </div>
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-black/30" />

                      <div className="absolute top-3 left-3 flex items-center gap-2">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-bold tracking-wider border backdrop-blur-md ${meta.pillBg}`}>
                          <Icon className="w-3 h-3" /> {meta.label}
                        </span>
                      </div>

                      {(s.kind === 'video' || s.kind === 'reel') && (
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="w-14 h-14 rounded-full bg-white/15 backdrop-blur-md border border-white/30 flex items-center justify-center group-hover:scale-110 group-hover:bg-white/25 transition-transform">
                            <Play className="w-6 h-6 text-white fill-white ml-0.5" />
                          </div>
                        </div>
                      )}

                      <div className={`absolute text-white ${compact ? 'left-2.5 right-2.5 bottom-2.5' : 'left-4 right-4 bottom-4'}`}>
                        <h3 className={`${compact ? 'text-xs sm:text-sm' : 'text-base sm:text-lg'} font-bold leading-tight line-clamp-2 drop-shadow`}>{s.title}</h3>
                        {s.subtitle && !compact && <p className="text-xs text-white/70 mt-1 line-clamp-1">{s.subtitle}</p>}
                        {s.meta && (
                          <div className={`flex items-center gap-2 ${compact ? 'mt-1 text-[10px]' : 'mt-2 text-[11px]'} text-white/80`}>
                            {s.kind === 'video' || s.kind === 'reel' ? <Eye className="w-3 h-3" /> : s.kind === 'item' ? <Heart className="w-3 h-3" /> : <Download className="w-3 h-3" />}
                            <span>{s.meta}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </Link>
                </CarouselItem>
              )
            })}
          </CarouselContent>
          <CarouselPrevious className="hidden md:flex -left-3 bg-black/50 border-white/20 text-white hover:bg-black/70" />
          <CarouselNext className="hidden md:flex -right-3 bg-black/50 border-white/20 text-white hover:bg-black/70" />
        </Carousel>
      </div>
    </section>
  )
}
