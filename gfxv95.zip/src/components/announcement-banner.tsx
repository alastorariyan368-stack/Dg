'use client'

import { useEffect, useState } from 'react'
import { Megaphone, X, ChevronLeft, ChevronRight } from 'lucide-react'

interface Announcement {
  id: string
  title: string
  content: string
  createdAt: string
}

export function AnnouncementBanner() {
  const [items, setItems] = useState<Announcement[]>([])
  const [idx, setIdx] = useState(0)
  const [dismissed, setDismissed] = useState<Record<string, boolean>>({})

  useEffect(() => {
    fetch('/api/announcements', { cache: 'no-store' })
      .then((r) => (r.ok ? r.json() : { announcements: [] }))
      .then((d) => setItems(Array.isArray(d?.announcements) ? d.announcements : []))
      .catch(() => setItems([]))
    try {
      const raw = localStorage.getItem('gfx_dismissed_announcements')
      if (raw) setDismissed(JSON.parse(raw))
    } catch {}
  }, [])

  const visible = items.filter((a) => !dismissed[a.id])
  if (visible.length === 0) return null
  const current = visible[Math.min(idx, visible.length - 1)]

  const dismiss = () => {
    const next = { ...dismissed, [current.id]: true }
    setDismissed(next)
    try { localStorage.setItem('gfx_dismissed_announcements', JSON.stringify(next)) } catch {}
    setIdx(0)
  }

  return (
    <div className="relative z-30 border-b border-violet-500/20 bg-gradient-to-r from-violet-600/15 via-fuchsia-600/15 to-cyan-600/15 backdrop-blur">
      <div className="container mx-auto px-4 py-2.5 flex items-center gap-3">
        <Megaphone className="w-4 h-4 text-violet-300 flex-shrink-0" />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[11px] uppercase tracking-wider text-violet-300 font-bold">{current.title}</span>
            <span className="text-sm text-white/80 truncate">{current.content}</span>
          </div>
        </div>
        {visible.length > 1 && (
          <div className="flex items-center gap-1 text-white/60 text-xs">
            <button onClick={() => setIdx((i) => (i - 1 + visible.length) % visible.length)} className="p-1 hover:text-white">
              <ChevronLeft className="w-3.5 h-3.5" />
            </button>
            <span>{idx + 1}/{visible.length}</span>
            <button onClick={() => setIdx((i) => (i + 1) % visible.length)} className="p-1 hover:text-white">
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
        <button onClick={dismiss} className="p-1 text-white/60 hover:text-white" aria-label="Dismiss">
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  )
}
