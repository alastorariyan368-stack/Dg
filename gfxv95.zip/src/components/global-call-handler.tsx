'use client'

import { useEffect, useRef, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useNotifications } from '@/components/notifications/notification-provider'
import { getMessagesSocket } from '@/lib/messages-socket'
import { CallModal, IncomingCallToast, type CallPeer } from '@/components/messaging/call-modal'
import { toast } from 'sonner'

function createRingtone(): { start: () => void; stop: () => void } {
  let ctx: AudioContext | null = null
  let interval: ReturnType<typeof setInterval> | null = null
  let running = false

  function playMessengerTone() {
    try {
      if (!ctx) ctx = new AudioContext()
      if (ctx.state === 'suspended') ctx.resume()
      
      const now = ctx.currentTime
      // Create a more "Messenger-like" double-beep tone
      const frequencies = [660, 880] 
      
      frequencies.forEach((freq, i) => {
        const osc = ctx!.createOscillator()
        const gain = ctx!.createGain()
        osc.connect(gain)
        gain.connect(ctx!.destination)
        osc.type = 'sine'
        osc.frequency.setValueAtTime(freq, now + i * 0.1)
        gain.gain.setValueAtTime(0, now + i * 0.1)
        gain.gain.linearRampToValueAtTime(0.3, now + i * 0.1 + 0.05)
        gain.gain.linearRampToValueAtTime(0, now + i * 0.1 + 0.2)
        osc.start(now + i * 0.1)
        osc.stop(now + i * 0.1 + 0.2)
      })
    } catch {}
  }

  return {
    start() {
      if (running) return
      running = true
      playMessengerTone()
      interval = setInterval(playMessengerTone, 1500)
    },
    stop() {
      running = false
      if (interval) { clearInterval(interval); interval = null }
      try { ctx?.close() } catch {}
      ctx = null
    },
  }
}

export function GlobalCallHandler() {
  const { data: session, status } = useSession()
  const myId = (session?.user as any)?.id || ''

  // ── Use the notification context — its socket is PROVEN to work (always connected) ──
  const { incomingCall, dismissIncomingCall } = useNotifications()

  const [activeCall, setActiveCall] = useState<{
    callId: string; peer: CallPeer; type: 'AUDIO' | 'VIDEO'; isInitiator: boolean; initialAccepted: boolean
  } | null>(null)

  const ringtoneRef = useRef<{ start: () => void; stop: () => void } | null>(null)
  const lastRingingCallId = useRef<string | null>(null)
  const socketRef = useRef<ReturnType<typeof getMessagesSocket> | null>(null)

  useEffect(() => {
    ringtoneRef.current = createRingtone()
    return () => { ringtoneRef.current?.stop() }
  }, [])

  // Initialize socket when authenticated
  useEffect(() => {
    if (status === 'authenticated' && myId) {
      socketRef.current = getMessagesSocket(myId)
    }
  }, [status, myId])

  // Play/stop ringtone whenever incomingCall changes
  useEffect(() => {
    if (incomingCall) {
      if (lastRingingCallId.current !== incomingCall.callId) {
        lastRingingCallId.current = incomingCall.callId
        ringtoneRef.current?.start()
      }
    } else {
      ringtoneRef.current?.stop()
      lastRingingCallId.current = null
    }
  }, [incomingCall])

  // Listen for cancellation via messages socket as well
  useEffect(() => {
    if (status !== 'authenticated' || !myId || !socketRef.current) return
    
    const socket = socketRef.current
    
    const onCancelled = ({ callId }: { callId: string }) => {
      if (incomingCall?.callId === callId) {
        dismissIncomingCall()
        ringtoneRef.current?.stop()
      }
      if (activeCall?.callId === callId) {
        setActiveCall(null)
      }
    }

    const onAccepted = ({ callId }: { callId: string }) => {
      // If we were ringing for this call, stop
      if (incomingCall?.callId === callId) {
        ringtoneRef.current?.stop()
      }
    }

    socket.on('call:cancelled', onCancelled)
    socket.on('call:ended', onCancelled)
    socket.on('call:accepted', onAccepted)

    return () => {
      socket.off('call:cancelled', onCancelled)
      socket.off('call:ended', onCancelled)
      socket.off('call:accepted', onAccepted)
    }
  }, [status, myId, incomingCall, activeCall])

  async function acceptIncoming() {
    if (!incomingCall) return
    ringtoneRef.current?.stop()
    const { callId, from, type } = incomingCall
    dismissIncomingCall()

    await fetch('/api/calls', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ callId, status: 'ACCEPTED' }),
    }).catch(e => console.error('[acceptIncoming] API error:', e))

    // Emit call:accept via messages socket so caller gets notified
    if (socketRef.current) {
      socketRef.current.emit('call:accept', { callId, targetUserId: from.id })
    }

    setActiveCall({ callId, peer: from, type, isInitiator: false, initialAccepted: true })
  }

  async function rejectIncoming() {
    if (!incomingCall) return
    ringtoneRef.current?.stop()
    const { callId, from } = incomingCall
    dismissIncomingCall()

    await fetch('/api/calls', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ callId, status: 'REJECTED' }),
    }).catch(e => console.error('[rejectIncoming] API error:', e))

    if (socketRef.current) {
      socketRef.current.emit('call:reject', { callId, targetUserId: from.id })
    }

    toast.info('Call declined')
  }

  // Show call UI only when authenticated
  if (status !== 'authenticated' || !myId) {
    return null
  }

  return (
    <>
      {incomingCall && !activeCall && (
        <IncomingCallToast
          open
          callId={incomingCall.callId}
          type={incomingCall.type}
          from={incomingCall.from}
          onAccept={acceptIncoming}
          onReject={rejectIncoming}
        />
      )}
      {activeCall && (
        <CallModal
          open
          onClose={() => setActiveCall(null)}
          callId={activeCall.callId}
          peer={activeCall.peer}
          type={activeCall.type}
          isInitiator={activeCall.isInitiator}
          myUserId={myId}
          initialAccepted={activeCall.initialAccepted}
        />
      )}
    </>
  )
}
