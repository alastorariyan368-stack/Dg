'use client'

import { useState, useEffect } from 'react'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Button } from '@/components/ui/button'
import { AlertCircle, CheckCircle2, Copy, Smartphone, Bitcoin, Building2, Globe, Wallet, ArrowLeft } from 'lucide-react'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'

interface DepositModalProps { isOpen: boolean; onClose: () => void; onSuccess: () => void }

const METHOD_STYLE: Record<string, any> = {
  nagad:   { color: 'orange', icon: Smartphone, badgeClass: 'bg-orange-500/20 text-orange-300 border-orange-500/30', btnClass: 'bg-orange-500 hover:bg-orange-600', border: 'border-orange-500/40', glow: 'shadow-orange-500/20' },
  bkash:   { color: 'pink',   icon: Smartphone, badgeClass: 'bg-pink-500/20 text-pink-300 border-pink-500/30', btnClass: 'bg-pink-500 hover:bg-pink-600', border: 'border-pink-500/40', glow: 'shadow-pink-500/20' },
  binance: { color: 'yellow', icon: Bitcoin,     badgeClass: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30', btnClass: 'bg-yellow-500 hover:bg-yellow-600', border: 'border-yellow-500/40', glow: 'shadow-yellow-500/20' },
  bank:    { color: 'blue',   icon: Building2,   badgeClass: 'bg-blue-500/20 text-blue-300 border-blue-500/30', btnClass: 'bg-blue-500 hover:bg-blue-600', border: 'border-blue-500/40', glow: 'shadow-blue-500/20' },
  paypal:  { color: 'sky',    icon: Globe,       badgeClass: 'bg-sky-500/20 text-sky-300 border-sky-500/30', btnClass: 'bg-sky-500 hover:bg-sky-600', border: 'border-sky-500/40', glow: 'shadow-sky-500/20' },
}

export function DepositModal({ isOpen, onClose, onSuccess }: DepositModalProps) {
  const [step, setStep] = useState<'method' | 'details'>('method')
  const [methods, setMethods] = useState<any[]>([])
  const [selectedMethod, setSelectedMethod] = useState<string | null>(null)
  const [paymentInfo, setPaymentInfo] = useState<any>(null)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const [methodsLoading, setMethodsLoading] = useState(true)

  useEffect(() => {
    if (isOpen) {
      setMethodsLoading(true)
      fetch('/api/payment/deposit-info').then(r => r.json()).then(d => {
        setMethods(d.methods || [])
      }).catch(() => {}).finally(() => setMethodsLoading(false))
    }
  }, [isOpen])

  const handleSelectMethod = async (method: string) => {
    setError(''); setSelectedMethod(method); setLoading(true)
    try {
      const res = await fetch('/api/payment/deposit-info', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ method }),
      })
      const data = await res.json()
      if (!res.ok) { setError(data.error || 'Failed to load payment info'); setSelectedMethod(null); return }
      setPaymentInfo(data); setStep('details')
    } catch { setError('Network error. Try again.') }
    finally { setLoading(false) }
  }

  const copy = (text: string) => { navigator.clipboard.writeText(text).then(() => {}).catch(() => {}) }

  const handleBack = () => { setStep('method'); setError(''); setSelectedMethod(null); setPaymentInfo(null) }

  const handleClose = () => { handleBack(); onClose() }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md bg-[#0d0d1a] border-white/[0.08] text-white max-h-[90vh] overflow-y-auto">
        {step === 'method' ? (
          <>
            <DialogHeader className="pb-2">
              <DialogTitle className="text-xl text-white">Add Funds</DialogTitle>
              <DialogDescription className="text-white/40">Choose your payment method</DialogDescription>
            </DialogHeader>

            {error && (
              <Alert className="border-red-500/30 bg-red-500/10">
                <AlertCircle className="h-4 w-4 text-red-400" />
                <AlertDescription className="text-red-300">{error}</AlertDescription>
              </Alert>
            )}

            {methodsLoading ? (
              <div className="py-8 flex justify-center"><div className="w-6 h-6 border-2 border-violet-500 border-t-transparent rounded-full animate-spin" /></div>
            ) : methods.length === 0 ? (
              <div className="py-8 text-center text-white/40 text-sm">No payment methods configured. Contact admin.</div>
            ) : (
              <div className="grid grid-cols-2 gap-3 py-2">
                {methods.map((m) => {
                  const style = METHOD_STYLE[m.id] || METHOD_STYLE.bank
                  const Icon = style.icon
                  const isLoading = loading && selectedMethod === m.id
                  return (
                    <button
                      key={m.id}
                      onClick={() => !loading && handleSelectMethod(m.id)}
                      disabled={loading}
                      className={`group relative p-4 rounded-2xl border bg-white/[0.03] hover:bg-white/[0.06] transition-all text-left ${style.border} hover:shadow-lg ${style.glow} ${isLoading ? 'opacity-70' : ''}`}
                    >
                      <div className="flex items-center justify-between mb-3">
                        <Icon className={`w-5 h-5 text-${style.color}-400`} />
                        <Badge className={`text-[10px] ${style.badgeClass}`}>{m.badge}</Badge>
                      </div>
                      <p className={`font-semibold text-sm text-${style.color}-300`}>{m.label}</p>
                      {isLoading && <div className="absolute inset-0 rounded-2xl flex items-center justify-center bg-black/40"><div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" /></div>}
                    </button>
                  )
                })}
              </div>
            )}

            <div className="flex items-center gap-2 p-3 rounded-xl bg-white/[0.03] border border-white/[0.06] mt-1">
              <Wallet className="w-4 h-4 text-violet-300 flex-shrink-0" />
              <p className="text-white/40 text-xs">Send payment first, then contact admin with your reference to get approved.</p>
            </div>
          </>
        ) : (
          <>
            <DialogHeader className="pb-2">
              <div className="flex items-center gap-2">
                <button onClick={handleBack} className="text-white/40 hover:text-white transition-colors">
                  <ArrowLeft className="w-4 h-4" />
                </button>
                <div>
                  <DialogTitle className="text-xl text-white">Pay via {paymentInfo?.methodName}</DialogTitle>
                  <DialogDescription className="text-white/40 text-xs">Send your payment using the details below</DialogDescription>
                </div>
              </div>
            </DialogHeader>

            {paymentInfo && (
              <div className="space-y-3">
                {/* Instruction */}
                {paymentInfo.instruction && (
                  <div className="flex items-start gap-2 p-3 rounded-xl bg-white/[0.03] border border-white/[0.06]">
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                    <p className="text-white/60 text-xs">{paymentInfo.instruction}</p>
                  </div>
                )}

                {/* Mobile money */}
                {paymentInfo.type === 'mobile' && paymentInfo.phoneNumber && (
                  <PayBox label="Send Money Number" color="violet">
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-bold text-2xl text-white tracking-wider">{paymentInfo.phoneNumber}</span>
                      <CopyBtn onClick={() => copy(paymentInfo.phoneNumber)} />
                    </div>
                  </PayBox>
                )}

                {/* Binance */}
                {paymentInfo.type === 'crypto' && paymentInfo.binanceId && (
                  <PayBox label="Binance Pay ID" color="yellow">
                    <div className="flex items-center justify-between">
                      <span className="font-mono font-bold text-xl text-white tracking-wider">{paymentInfo.binanceId}</span>
                      <CopyBtn onClick={() => copy(paymentInfo.binanceId)} />
                    </div>
                  </PayBox>
                )}

                {/* PayPal */}
                {paymentInfo.type === 'paypal' && paymentInfo.email && (
                  <PayBox label="PayPal Email" color="sky">
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-white">{paymentInfo.email}</span>
                      <CopyBtn onClick={() => copy(paymentInfo.email)} />
                    </div>
                  </PayBox>
                )}

                {/* Bank */}
                {paymentInfo.type === 'bank' && paymentInfo.bankDetails && (
                  <PayBox label="Bank Details" color="blue">
                    <div className="space-y-2">
                      {[
                        { label: 'Bank', value: paymentInfo.bankDetails.bankName },
                        { label: 'Account Name', value: paymentInfo.bankDetails.accountName },
                        { label: 'Account No.', value: paymentInfo.bankDetails.accountNumber },
                        { label: 'Routing No.', value: paymentInfo.bankDetails.routingNumber },
                        { label: 'SWIFT', value: paymentInfo.bankDetails.swiftCode },
                        { label: 'Branch', value: paymentInfo.bankDetails.branch },
                      ].filter(f => f.value).map(f => (
                        <div key={f.label} className="flex items-center justify-between">
                          <div><p className="text-white/30 text-[10px]">{f.label}</p><p className="font-mono text-sm text-white">{f.value}</p></div>
                          <CopyBtn onClick={() => copy(f.value)} />
                        </div>
                      ))}
                    </div>
                  </PayBox>
                )}

                {/* QR code */}
                {paymentInfo.qr && (
                  <div className="flex justify-center">
                    <div className="p-3 bg-white rounded-2xl">
                      <img src={paymentInfo.qr} alt="QR Code" className="w-32 h-32 object-contain" />
                    </div>
                  </div>
                )}

                <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                  <p className="text-amber-300 text-xs">After sending, contact admin support with your transaction ID. Your wallet will be credited within 30 minutes.</p>
                </div>

                <Button onClick={handleClose} className="w-full bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl">
                  Done — I've sent the payment
                </Button>
              </div>
            )}
          </>
        )}
      </DialogContent>
    </Dialog>
  )
}

function PayBox({ label, color, children }: { label: string; color: string; children: React.ReactNode }) {
  return (
    <div className={`p-4 rounded-xl border border-${color}-500/20 bg-${color}-500/5`}>
      <p className={`text-${color}-300 text-[10px] font-semibold uppercase tracking-wider mb-2`}>{label}</p>
      {children}
    </div>
  )
}

function CopyBtn({ onClick }: { onClick: () => void }) {
  const [copied, setCopied] = useState(false)
  const handle = () => { onClick(); setCopied(true); setTimeout(() => setCopied(false), 2000) }
  return (
    <button onClick={handle} className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-white/[0.06] hover:bg-white/[0.1] text-white/60 hover:text-white text-xs transition-all flex-shrink-0">
      {copied ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
      {copied ? 'Copied!' : 'Copy'}
    </button>
  )
}
