'use client'

import React from 'react'
import Link from 'next/link'
import { motion } from 'framer-motion'
import { Sparkles } from 'lucide-react'

interface LogoProps {
  size?: 'sm' | 'md' | 'lg'
  animated?: boolean
  className?: string
}

export function Logo({ size = 'md', animated = true, className = '' }: LogoProps) {
  const dim = size === 'sm' ? 'w-7 h-7' : size === 'lg' ? 'w-12 h-12' : 'w-10 h-10'
  const textSize = size === 'sm' ? 'text-lg' : size === 'lg' ? 'text-2xl' : 'text-xl'
  const iconSize = size === 'sm' ? 'w-4 h-4' : size === 'lg' ? 'w-6 h-6' : 'w-5 h-5'

  return (
    <Link href="/" className={`flex items-center gap-2.5 flex-shrink-0 group ${className}`}>
      <motion.div
        whileHover={animated ? { scale: 1.05, rotate: 5 } : {}}
        whileTap={animated ? { scale: 0.95 } : {}}
        className={`${dim} relative rounded-xl bg-gradient-to-br from-violet-500 via-fuchsia-500 to-cyan-500 p-[1.5px] shadow-lg shadow-violet-600/20`}
      >
        <div className="w-full h-full rounded-[10px] bg-[#0a0a12] flex items-center justify-center relative overflow-hidden">
          {animated && (
            <motion.div
              animate={{
                opacity: [0.2, 0.5, 0.2],
                scale: [1, 1.2, 1],
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="absolute inset-0 bg-gradient-to-tr from-violet-500/20 to-cyan-500/20"
            />
          )}
          <motion.div
            animate={animated ? {
              rotate: [0, 10, 0, -10, 0],
            } : {}}
            transition={{
              duration: 5,
              repeat: Infinity,
              ease: "easeInOut"
            }}
          >
            <Sparkles className={`${iconSize} text-white`} />
          </motion.div>
        </div>
      </motion.div>
      
      <div className="flex flex-col leading-none">
        <motion.span 
          className={`font-black text-white ${textSize} tracking-tight whitespace-nowrap`}
          initial={animated ? { opacity: 0, x: -10 } : {}}
          animate={animated ? { opacity: 1, x: 0 } : {}}
          transition={{ duration: 0.5 }}
        >
          GFX<span className="bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent">STORE</span>
        </motion.span>
        {size !== 'sm' && (
          <motion.span 
            className="text-[10px] font-bold text-white/30 uppercase tracking-[0.2em]"
            initial={animated ? { opacity: 0 } : {}}
            animate={animated ? { opacity: 1 } : {}}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            Creative Hub
          </motion.span>
        )}
      </div>
    </Link>
  )
}
