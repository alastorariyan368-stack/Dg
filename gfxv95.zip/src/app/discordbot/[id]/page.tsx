'use client'
import { useState, useEffect, useRef } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Switch } from '@/components/ui/switch'
import { toast } from 'sonner'
import {
  ArrowLeft, Play, Square, RefreshCw, FileCode, Terminal, ScrollText, Settings, Brain,
  Folder, File, ChevronRight, ChevronDown, Save, Trash2, Send, Trash, AlertCircle,
  Loader2, Copy, PanelRightClose, PanelRight
} from 'lucide-react'

const STATUS_STYLES: Record<string, { label: string; dot: string; text: string; bg: string }> = {
  running: { label: 'Running', dot: 'bg-emerald-400', text: 'text-emerald-400', bg: 'bg-emerald-500/10 border-emerald-500/25' },
  stopped: { label: 'Stopped', dot: 'bg-yellow-400', text: 'text-yellow-400', bg: 'bg-yellow-500/10 border-yellow-500/25' },
  error: { label: 'Error', dot: 'bg-red-400', text: 'text-red-400', bg: 'bg-red-500/10 border-red-500/25' },
}

const LOG_STYLES: Record<string, string> = {
  info: 'text-blue-400',
  error: 'text-red-400',
  warn: 'text-yellow-400',
}

const LANG_MAP: Record<string, string> = {
  js: 'javascript',
  ts: 'typescript',
  json: 'json',
  py: 'python',
  env: 'plaintext',
  txt: 'plaintext',
  md: 'markdown',
  yml: 'yaml',
  yaml: 'yaml',
  html: 'html',
  css: 'css',
}

type FileNode = {
  name: string
  path: string
  type: 'file' | 'dir'
  size: number
  children?: FileNode[]
}

type AIMessage = {
  role: 'user' | 'assistant'
  content: string
  code?: string
}

function FileTreeNode({ node, depth, selectedFile, onSelect, expandedDirs, onToggle }: {
  node: FileNode
  depth: number
  selectedFile: string | null
  onSelect: (path: string) => void
  expandedDirs: Set<string>
  onToggle: (path: string) => void
}) {
  const isExpanded = expandedDirs.has(node.path)
  const isSelected = selectedFile === node.path

  if (node.type === 'dir') {
    return (
      <div>
        <button
          onClick={() => onToggle(node.path)}
          className={`w-full flex items-center gap-1.5 px-2 py-1 text-sm rounded hover:bg-white/5 transition-colors ${isSelected ? 'bg-purple-500/10 text-purple-300' : 'text-white/70'}`}
          style={{ paddingLeft: `${depth * 16 + 8}px` }}
        >
          {isExpanded ? <ChevronDown className="w-3.5 h-3.5 flex-shrink-0" /> : <ChevronRight className="w-3.5 h-3.5 flex-shrink-0" />}
          <Folder className="w-3.5 h-3.5 flex-shrink-0 text-yellow-500" />
          <span className="truncate">{node.name}</span>
        </button>
        {isExpanded && node.children?.map(child => (
          <FileTreeNode
            key={child.path}
            node={child}
            depth={depth + 1}
            selectedFile={selectedFile}
            onSelect={onSelect}
            expandedDirs={expandedDirs}
            onToggle={onToggle}
          />
        ))}
      </div>
    )
  }

  return (
    <button
      onClick={() => onSelect(node.path)}
      className={`w-full flex items-center gap-1.5 px-2 py-1 text-sm rounded hover:bg-white/5 transition-colors ${isSelected ? 'bg-purple-500/10 text-purple-300' : 'text-white/60'}`}
      style={{ paddingLeft: `${depth * 16 + 8}px` }}
    >
      <File className="w-3.5 h-3.5 flex-shrink-0 text-blue-400" />
      <span className="truncate">{node.name}</span>
      <span className="ml-auto text-[10px] text-white/20">{node.size}B</span>
    </button>
  )
}

function TabIcon({ icon: Icon, label }: { icon: any; label: string }) {
  return (
    <span className="flex items-center gap-1.5">
      <Icon className="w-4 h-4" />
      <span className="hidden sm:inline">{label}</span>
    </span>
  )
}

export default function BotDetailPage() {
  const params = useParams()
  const router = useRouter()
  const id = params.id as string

  const [bot, setBot] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [actionLoading, setActionLoading] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState('files')
  const [deleteConfirm, setDeleteConfirm] = useState(false)
  const [deleting, setDeleting] = useState(false)

  const [fileTree, setFileTree] = useState<FileNode[]>([])
  const [expandedDirs, setExpandedDirs] = useState<Set<string>>(new Set(['']))
  const [selectedFile, setSelectedFile] = useState<string | null>(null)
  const [fileContent, setFileContent] = useState('')
  const [originalContent, setOriginalContent] = useState('')
  const [saving, setSaving] = useState(false)
  const [showFileTree, setShowFileTree] = useState(true)

  const [terminalOutput, setTerminalOutput] = useState<string[]>([])
  const [terminalInput, setTerminalInput] = useState('')
  const [executing, setExecuting] = useState(false)
  const terminalRef = useRef<HTMLDivElement>(null)

  const [logs, setLogs] = useState<any[]>([])

  const [settingsForm, setSettingsForm] = useState({
    name: '', description: '', token: '', clientId: '', prefix: '', language: 'en', autoRestart: true, mainFile: 'index.js',
  })
  const [savingSettings, setSavingSettings] = useState(false)

  const [aiMode, setAiMode] = useState<'ask' | 'command' | 'fix'>('ask')
  const [aiMessages, setAiMessages] = useState<AIMessage[]>([])
  const [aiInput, setAiInput] = useState('')
  const [aiCode, setAiCode] = useState('')
  const [aiErrorLog, setAiErrorLog] = useState('')
  const [aiLoading, setAiLoading] = useState(false)

  const [statusCheckInterval, setStatusCheckInterval] = useState<ReturnType<typeof setInterval> | null>(null)

  useEffect(() => {
    if (id) fetchBot()
    return () => {
      if (statusCheckInterval) clearInterval(statusCheckInterval)
    }
  }, [id])

  useEffect(() => {
    if (activeTab === 'files' && id) fetchFileTree()
  }, [activeTab, id])

  useEffect(() => {
    if (activeTab === 'logs' && id) {
      fetchLogs()
      const iv = setInterval(fetchLogs, 3000)
      return () => clearInterval(iv)
    }
  }, [activeTab, id])

  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight
    }
  }, [terminalOutput])

  const fetchBot = async () => {
    try {
      const res = await fetch(`/api/discordbot/${id}`)
      if (!res.ok) { router.push('/discordbot'); return }
      const data = await res.json()
      setBot(data)
      setSettingsForm({
        name: data.name || '',
        description: data.description || '',
        token: data.token || '',
        clientId: data.clientId || '',
        prefix: data.prefix || '!',
        language: data.language || 'en',
        autoRestart: data.autoRestart ?? true,
        mainFile: data.mainFile || 'index.js',
      })
    } catch { router.push('/discordbot') }
    setLoading(false)
  }

  const fetchStatus = async () => {
    try {
      const res = await fetch(`/api/discordbot/${id}/status`)
      if (res.ok) {
        const data = await res.json()
        setBot((prev: any) => prev ? { ...prev, status: data.status || prev.status } : prev)
      }
    } catch {}
  }

  const startStatusPolling = () => {
    if (statusCheckInterval) clearInterval(statusCheckInterval)
    const iv = setInterval(fetchStatus, 2000)
    setStatusCheckInterval(iv)
    setTimeout(() => {
      clearInterval(iv)
      setStatusCheckInterval(null)
      fetchStatus()
    }, 30000)
  }

  const handleAction = async (action: string) => {
    setActionLoading(action)
    try {
      const res = await fetch(`/api/discordbot/${id}/${action}`, { method: 'POST' })
      const data = await res.json()
      if (!res.ok) { toast.error(data.error || `Failed to ${action}`); return }
      setBot((prev: any) => prev ? { ...prev, status: action === 'stop' ? 'stopped' : 'running' } : prev)
      toast.success(`Bot ${action === 'stop' ? 'stopped' : action === 'start' ? 'started' : 'restarted'}!`)
      if (action !== 'stop') startStatusPolling()
      if (action === 'stop') {
        setTimeout(fetchStatus, 2000)
      }
    } catch { toast.error(`Failed to ${action} bot`) }
    setActionLoading(null)
  }

  const handleDelete = async () => {
    setDeleting(true)
    try {
      const res = await fetch(`/api/discordbot/${id}`, { method: 'DELETE' })
      if (!res.ok) { toast.error('Failed to delete bot'); setDeleting(false); return }
      toast.success('Bot deleted')
      router.push('/discordbot')
    } catch { toast.error('Failed to delete bot'); setDeleting(false) }
  }

  const fetchFileTree = async () => {
    try {
      const res = await fetch(`/api/discordbot/${id}/files`, { method: 'POST' })
      if (res.ok) {
        const data = await res.json()
        const tree = Array.isArray(data) ? data : data.tree || []
        setFileTree(tree)
        const dirs = new Set<string>([''])
        const collect = (nodes: FileNode[], base: string) => {
          nodes.forEach(n => {
            if (n.type === 'dir') { dirs.add(n.path); if (n.children) collect(n.children, n.path) }
          })
        }
        collect(tree, '')
        setExpandedDirs(dirs)
        if (tree.length > 0) {
          const firstFile = findFirstFile(tree)
          if (firstFile) handleSelectFile(firstFile)
        }
      }
    } catch {}
  }

  const findFirstFile = (nodes: FileNode[]): string | null => {
    for (const n of nodes) {
      if (n.type === 'file') return n.path
      if (n.children) { const f = findFirstFile(n.children); if (f) return f }
    }
    return null
  }

  const handleSelectFile = async (path: string) => {
    setSelectedFile(path)
    setSaving(false)
    try {
      const res = await fetch(`/api/discordbot/${id}/files/${path.replace(/\\/g, '/')}`)
      if (res.ok) {
        const data = await res.json()
        setFileContent(data.content || '')
        setOriginalContent(data.content || '')
      }
    } catch {}
  }

  const handleSaveFile = async () => {
    if (!selectedFile) return
    setSaving(true)
    try {
      const res = await fetch(`/api/discordbot/${id}/files/${selectedFile.replace(/\\/g, '/')}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: fileContent }),
      })
      if (res.ok) {
        setOriginalContent(fileContent)
        toast.success('Saved!')
      } else {
        const data = await res.json()
        toast.error(data.error || 'Failed to save')
      }
    } catch { toast.error('Failed to save file') }
    setSaving(false)
  }

  const handleDeleteFile = async () => {
    if (!selectedFile) return
    if (!confirm(`Delete ${selectedFile}?`)) return
    try {
      const res = await fetch(`/api/discordbot/${id}/files/${selectedFile.replace(/\\/g, '/')}`, { method: 'DELETE' })
      if (res.ok) {
        toast.success('File deleted')
        setSelectedFile(null)
        setFileContent('')
        fetchFileTree()
      } else {
        const data = await res.json()
        toast.error(data.error || 'Failed to delete')
      }
    } catch { toast.error('Failed to delete file') }
  }

  const handleTerminalSubmit = async () => {
    const cmd = terminalInput.trim()
    if (!cmd) return
    setTerminalOutput(prev => [...prev, `> ${cmd}`])
    setTerminalInput('')
    setExecuting(true)
    try {
      const res = await fetch(`/api/discordbot/${id}/terminal`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: cmd }),
      })
      if (res.ok) {
        const data = await res.json()
        if (data.output) setTerminalOutput(prev => [...prev, data.output])
        if (data.error) setTerminalOutput(prev => [...prev, `ERROR: ${data.error}`])
      } else {
        const data = await res.json()
        setTerminalOutput(prev => [...prev, `ERROR: ${data.error || 'Command failed'}`])
      }
    } catch { setTerminalOutput(prev => [...prev, 'ERROR: Request failed']) }
    setExecuting(false)
  }

  const fetchLogs = async () => {
    try {
      const res = await fetch(`/api/discordbot/${id}`)
      if (res.ok) {
        const data = await res.json()
        if (data.logs) setLogs(data.logs)
      }
    } catch {}
  }

  const handleSaveSettings = async () => {
    setSavingSettings(true)
    try {
      const res = await fetch(`/api/discordbot/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settingsForm),
      })
      if (res.ok) {
        const data = await res.json()
        setBot((prev: any) => prev ? { ...prev, ...data } : prev)
        toast.success('Settings saved!')
      } else {
        const data = await res.json()
        toast.error(data.error || 'Failed to save')
      }
    } catch { toast.error('Failed to save settings') }
    setSavingSettings(false)
  }

  const handleAiSubmit = async () => {
    if (aiMode === 'ask' && !aiInput.trim()) return
    if (aiMode === 'command' && !aiInput.trim()) return
    if (aiMode === 'fix' && (!aiErrorLog.trim() || !aiCode.trim())) return

    const userMsg: AIMessage = aiMode === 'fix'
      ? { role: 'user', content: `Error Log:\n${aiErrorLog}\n\nCurrent Code:\n${aiCode}` }
      : { role: 'user', content: aiInput }

    setAiMessages(prev => [...prev, userMsg])
    setAiLoading(true)

    try {
      const body: any = { type: aiMode === 'command' ? 'command' : aiMode === 'fix' ? 'fix' : 'ask' }
      if (aiMode === 'ask') body.prompt = aiInput
      else if (aiMode === 'command') body.prompt = aiInput
      else {
        body.errorLog = aiErrorLog
        body.code = aiCode
      }

      const res = await fetch(`/api/discordbot/${id}/ai`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      })

      if (res.ok) {
        const data = await res.json()
        const assistantMsg: AIMessage = { role: 'assistant', content: data.response }
        const codeMatch = data.response.match(/```(\w+)?\n([\s\S]*?)```/)
        if (codeMatch) assistantMsg.code = codeMatch[2]
        setAiMessages(prev => [...prev, assistantMsg])
      } else {
        const data = await res.json()
        setAiMessages(prev => [...prev, { role: 'assistant', content: `Error: ${data.error || 'AI request failed'}` }])
      }
    } catch {
      setAiMessages(prev => [...prev, { role: 'assistant', content: 'Error: Failed to reach AI service' }])
    }

    if (aiMode === 'ask') setAiInput('')
    setAiLoading(false)
  }

  const copyToFile = (code: string) => {
    const path = `commands/${Date.now()}.js`
    setActiveTab('files')
    setFileContent(code)
    toast.info('Code loaded into editor. Name your file and save.')
  }

  const getFileExtension = (path: string) => {
    const ext = path.split('.').pop() || ''
    return LANG_MAP[ext] || 'plaintext'
  }

  const toggleDir = (path: string) => {
    setExpandedDirs(prev => {
      const next = new Set(prev)
      if (next.has(path)) next.delete(path); else next.add(path)
      return next
    })
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
        </div>
        <Footer />
      </div>
    )
  }

  if (!bot) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <AlertCircle className="w-16 h-16 text-red-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold mb-2">Bot not found</h2>
            <Button onClick={() => router.push('/discordbot')} variant="outline">Go Back</Button>
          </div>
        </div>
        <Footer />
      </div>
    )
  }

  const st = STATUS_STYLES[bot.status] || STATUS_STYLES.stopped

  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col">
      <Navbar />
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 py-4 md:py-6">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" onClick={() => router.push('/discordbot')} className="text-white/40 hover:text-white">
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div className="w-10 h-10 rounded-xl bg-purple-500/15 border border-purple-500/25 flex items-center justify-center">
              <FileCode className="w-5 h-5 text-purple-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl md:text-2xl font-bold text-white">{bot.name}</h1>
                <span className={`flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-medium border ${st.bg} ${st.text}`}>
                  <span className={`w-1.5 h-1.5 rounded-full ${st.dot} ${bot.status === 'running' ? 'animate-pulse' : ''}`} />
                  {st.label}
                </span>
              </div>
              <p className="text-xs text-white/40">Prefix: {bot.prefix} | Language: {bot.language?.toUpperCase()}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button size="sm" onClick={() => handleAction('start')} disabled={bot.status === 'running' || !!actionLoading}
              className="bg-emerald-600 hover:bg-emerald-500 text-white h-8 px-3 text-xs gap-1.5 rounded-full">
              {actionLoading === 'start' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Play className="w-3.5 h-3.5" />}
              Start
            </Button>
            <Button size="sm" onClick={() => handleAction('stop')} disabled={bot.status !== 'running' || !!actionLoading}
              className="bg-amber-600 hover:bg-amber-500 text-white h-8 px-3 text-xs gap-1.5 rounded-full">
              {actionLoading === 'stop' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Square className="w-3.5 h-3.5" />}
              Stop
            </Button>
            <Button size="sm" onClick={() => handleAction('restart')} disabled={!!actionLoading}
              className="bg-purple-600 hover:bg-purple-500 text-white h-8 px-3 text-xs gap-1.5 rounded-full">
              {actionLoading === 'restart' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
              Restart
            </Button>
          </div>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="bg-gray-800 border border-white/[0.06] rounded-xl p-1 mb-4 w-full sm:w-auto flex overflow-x-auto">
            <TabsTrigger value="files" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white text-white/50 flex-1 sm:flex-none">
              <TabIcon icon={FileCode} label="Files" />
            </TabsTrigger>
            <TabsTrigger value="terminal" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white text-white/50 flex-1 sm:flex-none">
              <TabIcon icon={Terminal} label="Terminal" />
            </TabsTrigger>
            <TabsTrigger value="logs" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white text-white/50 flex-1 sm:flex-none">
              <TabIcon icon={ScrollText} label="Logs" />
            </TabsTrigger>
            <TabsTrigger value="settings" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white text-white/50 flex-1 sm:flex-none">
              <TabIcon icon={Settings} label="Settings" />
            </TabsTrigger>
            <TabsTrigger value="ai" className="data-[state=active]:bg-purple-600 data-[state=active]:text-white text-white/50 flex-1 sm:flex-none">
              <TabIcon icon={Brain} label="AI" />
            </TabsTrigger>
          </TabsList>

          <TabsContent value="files" className="mt-0">
            <div className="flex gap-0 border border-white/[0.06] rounded-xl overflow-hidden bg-gray-800/50 min-h-[500px]">
              {showFileTree && (
                <div className="w-56 md:w-64 flex-shrink-0 border-r border-white/[0.06] bg-gray-900/50 hidden sm:block">
                  <div className="p-2 border-b border-white/[0.06] flex items-center justify-between">
                    <span className="text-xs font-medium text-white/40 uppercase tracking-wider">Files</span>
                    <button onClick={() => setShowFileTree(false)} className="text-white/30 hover:text-white/60">
                      <PanelRightClose className="w-4 h-4" />
                    </button>
                  </div>
                  <ScrollArea className="h-[calc(500px-37px)]">
                    <div className="py-1">
                      {fileTree.map(node => (
                        <FileTreeNode
                          key={node.path}
                          node={node}
                          depth={0}
                          selectedFile={selectedFile}
                          onSelect={handleSelectFile}
                          expandedDirs={expandedDirs}
                          onToggle={toggleDir}
                        />
                      ))}
                      {fileTree.length === 0 && (
                        <p className="text-xs text-white/30 text-center py-8">No files found</p>
                      )}
                    </div>
                  </ScrollArea>
                </div>
              )}

              {!showFileTree && (
                <button onClick={() => setShowFileTree(true)} className="hidden sm:flex items-center gap-1 px-2 py-1 text-xs text-white/30 hover:text-white/60 border-r border-white/[0.06]">
                  <PanelRight className="w-4 h-4" />
                </button>
              )}

              <div className="flex-1 flex flex-col">
                <div className="flex items-center justify-between px-3 py-2 border-b border-white/[0.06] bg-gray-800/80">
                  <div className="flex items-center gap-2">
                    <button onClick={() => setShowFileTree(prev => !prev)} className="sm:hidden text-white/40 hover:text-white">
                      <Folder className="w-4 h-4" />
                    </button>
                    <span className="text-xs text-white/40 font-mono">{selectedFile || 'No file selected'}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    {selectedFile && (
                      <>
                        <Button size="sm" variant="ghost" onClick={handleDeleteFile} className="h-7 px-2 text-xs text-red-400/50 hover:text-red-400">
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                        <Button size="sm" onClick={handleSaveFile} disabled={saving || fileContent === originalContent}
                          className="h-7 px-3 text-xs bg-purple-600 hover:bg-purple-500 text-white rounded-md gap-1">
                          {saving ? <Loader2 className="w-3 h-3 animate-spin" /> : <Save className="w-3 h-3" />}
                          Save
                        </Button>
                      </>
                    )}
                  </div>
                </div>
                {selectedFile ? (
                  <textarea
                    value={fileContent}
                    onChange={e => setFileContent(e.target.value)}
                    className="flex-1 w-full bg-gray-950 text-gray-200 font-mono text-sm p-4 resize-none outline-none border-0 min-h-[460px]"
                    spellCheck={false}
                  />
                ) : (
                  <div className="flex-1 flex items-center justify-center text-white/20 text-sm">
                    Select a file from the tree
                  </div>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="terminal" className="mt-0">
            <div className="border border-white/[0.06] rounded-xl overflow-hidden bg-black min-h-[500px] flex flex-col">
              <div className="flex items-center justify-between px-3 py-2 bg-gray-900 border-b border-white/[0.06]">
                <span className="text-xs font-medium text-white/40 uppercase tracking-wider">Terminal</span>
                <Button size="sm" variant="ghost" onClick={() => setTerminalOutput([])} className="h-7 px-2 text-xs text-white/30 hover:text-white/60">
                  <Trash className="w-3.5 h-3.5" />
                </Button>
              </div>
              <div ref={terminalRef} className="flex-1 p-4 font-mono text-sm overflow-y-auto max-h-[460px]" style={{ backgroundColor: '#0a0a0a' }}>
                {terminalOutput.length === 0 && (
                  <div className="text-gray-600 mb-2">
                    <p>Discord Bot Terminal - {bot.name}</p>
                    <p>Working directory: /home/bot</p>
                    <p className="mt-1">Type a command and press Enter.</p>
                  </div>
                )}
                {terminalOutput.map((line, i) => (
                  <div key={i} className="whitespace-pre-wrap break-all" style={{ color: line.startsWith('ERROR:') ? '#ff4444' : '#33ff00' }}>
                    {line}
                  </div>
                ))}
                {executing && (
                  <div style={{ color: '#33ff00' }}>
                    <Loader2 className="w-3.5 h-3.5 animate-spin inline mr-1" /> Running...
                  </div>
                )}
              </div>
              <div className="flex items-center gap-2 px-3 py-2 bg-gray-900 border-t border-white/[0.06]">
                <span className="text-green-400 font-mono text-sm flex-shrink-0">$</span>
                <input
                  value={terminalInput}
                  onChange={e => setTerminalInput(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter' && !executing) handleTerminalSubmit() }}
                  placeholder="Type a command..."
                  className="flex-1 bg-transparent text-green-400 font-mono text-sm outline-none border-0 placeholder:text-gray-600"
                  disabled={executing}
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="logs" className="mt-0">
            <div className="border border-white/[0.06] rounded-xl overflow-hidden bg-gray-800/50 min-h-[500px] flex flex-col">
              <div className="flex items-center justify-between px-3 py-2 border-b border-white/[0.06] bg-gray-800/80">
                <span className="text-xs font-medium text-white/40 uppercase tracking-wider">Logs (Auto-refresh 3s)</span>
                <Button size="sm" variant="ghost" onClick={fetchLogs} className="h-7 px-2 text-xs text-white/30 hover:text-white/60">
                  <RefreshCw className="w-3.5 h-3.5" />
                </Button>
              </div>
              <ScrollArea className="flex-1">
                <div className="p-3 space-y-1">
                  {logs.length === 0 && (
                    <p className="text-white/20 text-sm text-center py-8">No logs yet</p>
                  )}
                  {logs.map((log: any) => (
                    <div key={log.id} className="flex items-start gap-2 text-sm py-0.5 font-mono">
                      <span className="text-[10px] text-white/20 flex-shrink-0 w-16 text-right">
                        {new Date(log.createdAt).toLocaleTimeString()}
                      </span>
                      <span className={`flex-shrink-0 text-[10px] uppercase font-bold w-12 ${LOG_STYLES[log.type] || 'text-white/40'}`}>
                        [{log.type}]
                      </span>
                      <span className="text-white/70 break-all">{log.content}</span>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          </TabsContent>

          <TabsContent value="settings" className="mt-0">
            <div className="border border-white/[0.06] rounded-xl overflow-hidden bg-gray-800/50">
              <div className="px-4 md:px-6 py-4 border-b border-white/[0.06]">
                <h2 className="text-lg font-semibold text-white">Bot Settings</h2>
                <p className="text-sm text-white/40 mt-0.5">Configure your Discord bot properties</p>
              </div>
              <div className="p-4 md:p-6 space-y-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label className="text-sm text-white/60 mb-1.5 block">Bot Name</Label>
                    <Input value={settingsForm.name} onChange={e => setSettingsForm(p => ({ ...p, name: e.target.value }))}
                      className="bg-gray-900 border-white/10 text-white" />
                  </div>
                  <div>
                    <Label className="text-sm text-white/60 mb-1.5 block">Prefix</Label>
                    <Input value={settingsForm.prefix} onChange={e => setSettingsForm(p => ({ ...p, prefix: e.target.value }))}
                      className="bg-gray-900 border-white/10 text-white font-mono" maxLength={5} />
                  </div>
                  <div>
                    <Label className="text-sm text-white/60 mb-1.5 block">Token</Label>
                    <Input value={settingsForm.token} onChange={e => setSettingsForm(p => ({ ...p, token: e.target.value }))}
                      type="password" className="bg-gray-900 border-white/10 text-white font-mono" placeholder="Enter bot token" />
                  </div>
                  <div>
                    <Label className="text-sm text-white/60 mb-1.5 block">Client ID</Label>
                    <Input value={settingsForm.clientId} onChange={e => setSettingsForm(p => ({ ...p, clientId: e.target.value }))}
                      className="bg-gray-900 border-white/10 text-white font-mono" placeholder="Discord application ID" />
                  </div>
                  <div>
                    <Label className="text-sm text-white/60 mb-1.5 block">Main File</Label>
                    <Input value={settingsForm.mainFile} onChange={e => setSettingsForm(p => ({ ...p, mainFile: e.target.value }))}
                      className="bg-gray-900 border-white/10 text-white font-mono" />
                  </div>
                  <div>
                    <Label className="text-sm text-white/60 mb-1.5 block">Language</Label>
                    <select value={settingsForm.language} onChange={e => setSettingsForm(p => ({ ...p, language: e.target.value }))}
                      className="w-full rounded-xl bg-gray-900 border border-white/10 text-white text-sm p-2.5 focus:outline-none focus:border-purple-500/40">
                      <option value="en">English</option>
                      <option value="bn">Bangla</option>
                    </select>
                  </div>
                </div>
                <div>
                  <Label className="text-sm text-white/60 mb-1.5 block">Description</Label>
                  <textarea value={settingsForm.description} onChange={e => setSettingsForm(p => ({ ...p, description: e.target.value }))}
                    className="w-full rounded-xl bg-gray-900 border border-white/10 text-white text-sm p-3 resize-none h-24 focus:outline-none focus:border-purple-500/40"
                    placeholder="Bot description" />
                </div>
                <div className="flex items-center justify-between bg-gray-900 rounded-xl px-4 py-3 border border-white/[0.06]">
                  <div>
                    <p className="text-sm text-white font-medium">Auto Restart</p>
                    <p className="text-xs text-white/40">Automatically restart the bot if it crashes</p>
                  </div>
                  <Switch
                    checked={settingsForm.autoRestart}
                    onCheckedChange={v => setSettingsForm(p => ({ ...p, autoRestart: v }))}
                    className="data-[state=checked]:bg-purple-600"
                  />
                </div>
                <Button onClick={handleSaveSettings} disabled={savingSettings}
                  className="bg-purple-600 hover:bg-purple-500 text-white gap-2 rounded-full w-full md:w-auto">
                  {savingSettings ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                  Save Settings
                </Button>
              </div>
            </div>

            <div className="border border-red-500/20 rounded-xl overflow-hidden bg-red-500/5 mt-6">
              <div className="px-4 md:px-6 py-4 border-b border-red-500/10">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-red-400" />
                  <h2 className="text-lg font-semibold text-red-400">Danger Zone</h2>
                </div>
              </div>
              <div className="p-4 md:p-6">
                <p className="text-sm text-white/50 mb-4">Once you delete a bot, there is no going back. All files and data will be permanently removed.</p>
                {deleteConfirm ? (
                  <div className="flex items-center gap-3">
                    <Button onClick={handleDelete} disabled={deleting}
                      className="bg-red-600 hover:bg-red-500 text-white gap-2 rounded-full">
                      {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                      Confirm Delete
                    </Button>
                    <Button variant="ghost" onClick={() => setDeleteConfirm(false)} className="text-white/50 hover:text-white">
                      Cancel
                    </Button>
                  </div>
                ) : (
                  <Button onClick={() => setDeleteConfirm(true)}
                    className="bg-red-600/20 hover:bg-red-600/40 text-red-400 border border-red-500/30 gap-2 rounded-full">
                    <Trash2 className="w-4 h-4" />
                    Delete Bot
                  </Button>
                )}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="ai" className="mt-0">
            <div className="border border-white/[0.06] rounded-xl overflow-hidden bg-gray-800/50 min-h-[500px] flex flex-col">
              <div className="px-4 py-3 border-b border-white/[0.06]">
                <div className="flex items-center gap-3 mb-2">
                  <Brain className="w-5 h-5 text-purple-400" />
                  <h2 className="text-lg font-semibold text-white">AI Assistant</h2>
                </div>
                <div className="flex gap-1 bg-gray-900 rounded-lg p-1 w-fit">
                  {(['ask', 'command', 'fix'] as const).map(mode => (
                    <button key={mode} onClick={() => setAiMode(mode)}
                      className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${aiMode === mode ? 'bg-purple-600 text-white' : 'text-white/40 hover:text-white/70'}`}>
                      {mode === 'ask' ? 'Ask' : mode === 'command' ? 'Generate Command' : 'Fix Errors'}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex-1 p-4 overflow-y-auto max-h-[400px] space-y-3">
                {aiMessages.length === 0 && (
                  <div className="text-center text-white/20 text-sm py-12">
                    {aiMode === 'ask' && <p>Ask any question about Discord.js v14 development</p>}
                    {aiMode === 'command' && <p>Describe a command and I'll generate the code</p>}
                    {aiMode === 'fix' && <p>Paste your error log and code to get fixes</p>}
                  </div>
                )}
                {aiMessages.map((msg, i) => (
                  <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[85%] rounded-xl px-4 py-2.5 ${msg.role === 'user' ? 'bg-purple-600/20 border border-purple-500/20' : 'bg-gray-800 border border-white/[0.06]'}`}>
                      <p className="text-sm text-white/80 whitespace-pre-wrap">{msg.content}</p>
                      {msg.code && (
                        <div className="mt-2 bg-gray-950 rounded-lg p-3 border border-white/[0.06]">
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-[10px] text-white/30 uppercase">Generated Code</span>
                            <button onClick={() => copyToFile(msg.code!)} className="text-purple-400 hover:text-purple-300 text-xs flex items-center gap-1">
                              <Copy className="w-3 h-3" /> Copy to File
                            </button>
                          </div>
                          <pre className="text-xs text-green-400 font-mono overflow-x-auto whitespace-pre-wrap">{msg.code}</pre>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
                {aiLoading && (
                  <div className="flex justify-start">
                    <div className="bg-gray-800 border border-white/[0.06] rounded-xl px-4 py-3">
                      <Loader2 className="w-5 h-5 animate-spin text-purple-400" />
                    </div>
                  </div>
                )}
              </div>

              <div className="p-4 border-t border-white/[0.06] bg-gray-900/50">
                {aiMode === 'fix' ? (
                  <div className="space-y-3">
                    <textarea value={aiErrorLog} onChange={e => setAiErrorLog(e.target.value)}
                      placeholder="Paste your error log here..."
                      className="w-full rounded-xl bg-gray-950 border border-white/10 text-white text-sm p-3 resize-none h-24 font-mono placeholder:text-white/20 focus:outline-none focus:border-purple-500/40" />
                    <textarea value={aiCode} onChange={e => setAiCode(e.target.value)}
                      placeholder="Paste your current code here..."
                      className="w-full rounded-xl bg-gray-950 border border-white/10 text-white text-sm p-3 resize-none h-24 font-mono placeholder:text-white/20 focus:outline-none focus:border-purple-500/40" />
                    <Button onClick={handleAiSubmit} disabled={aiLoading || !aiErrorLog.trim() || !aiCode.trim()}
                      className="bg-purple-600 hover:bg-purple-500 text-white gap-2 rounded-full">
                      {aiLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                      Fix Code
                    </Button>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <input
                      value={aiInput}
                      onChange={e => setAiInput(e.target.value)}
                      onKeyDown={e => { if (e.key === 'Enter' && !aiLoading) handleAiSubmit() }}
                      placeholder={aiMode === 'command' ? 'Describe the command to generate...' : 'Ask anything about Discord.js v14...'}
                      className="flex-1 bg-gray-950 border border-white/10 text-white text-sm rounded-xl px-4 py-2.5 outline-none focus:border-purple-500/40 placeholder:text-white/20"
                      disabled={aiLoading}
                    />
                    <Button onClick={handleAiSubmit} disabled={aiLoading || !aiInput.trim()}
                      className="bg-purple-600 hover:bg-purple-500 text-white h-10 w-10 p-0 rounded-full flex-shrink-0">
                      {aiLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                    </Button>
                  </div>
                )}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </main>
      <Footer />
    </div>
  )
}
