'use client'
import { useState, useEffect, useCallback } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import {
  Plus, Play, Square, Trash2, Settings, Terminal, Code, Loader2, X, AlertCircle, Clock, MessageSquare, CheckCircle
} from 'lucide-react'
import { toast } from 'sonner'
import { formatDistanceToNow } from 'date-fns'

interface Bot {
  id: string
  name: string
  status: 'running' | 'stopped' | 'error'
  prefix: string
  description: string
  language: string
  logCount: number
  createdAt: string
}

const STATUS_STYLES: Record<string, { label: string; dot: string; text: string; bg: string }> = {
  running: { label: 'Running', dot: 'bg-emerald-400', text: 'text-emerald-400', bg: 'bg-emerald-500/10 border-emerald-500/25' },
  stopped: { label: 'Stopped', dot: 'bg-yellow-400', text: 'text-yellow-400', bg: 'bg-yellow-500/10 border-yellow-500/25' },
  error: { label: 'Error', dot: 'bg-red-400', text: 'text-red-400', bg: 'bg-red-500/10 border-red-500/25' },
}

function RobotIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="3" y="11" width="18" height="10" rx="2" />
      <circle cx="9" cy="15" r="1.5" fill="currentColor" />
      <circle cx="15" cy="15" r="1.5" fill="currentColor" />
      <path d="M9 5 L12 2 L15 5" />
      <path d="M9 5 L9 11" />
      <path d="M15 5 L15 11" />
      <path d="M5 21 L5 24" />
      <path d="M19 21 L19 24" />
    </svg>
  )
}

const CREATE_FORM_DEFAULTS = { name: '', description: '', prefix: '!', language: 'en' }

export default function DiscordBotPage() {
  const [bots, setBots] = useState<Bot[]>([])
  const [loading, setLoading] = useState(true)
  const [actionLoading, setActionLoading] = useState<string | null>(null)
  const [showCreate, setShowCreate] = useState(false)
  const [creating, setCreating] = useState(false)
  const [form, setForm] = useState({ ...CREATE_FORM_DEFAULTS })
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null)

  const fetchBots = useCallback(async () => {
    try {
      const res = await fetch('/api/discordbot')
      if (res.ok) {
        const data = await res.json()
        setBots(Array.isArray(data) ? data : data.bots || [])
      }
    } catch {
      toast.error('Failed to load bots')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => { fetchBots() }, [fetchBots])

  const handleCreate = async () => {
    if (!form.name.trim()) { toast.error('Bot name is required'); return }
    setCreating(true)
    try {
      const res = await fetch('/api/discordbot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: form.name.trim(),
          description: form.description.trim(),
          prefix: form.prefix || '!',
          language: form.language,
        }),
      })
      const data = await res.json()
      if (!res.ok) { toast.error(data.error || 'Failed to create bot'); return }
      setBots(prev => [data, ...prev])
      setShowCreate(false)
      setForm({ ...CREATE_FORM_DEFAULTS })
      toast.success('Bot created!')
    } catch {
      toast.error('Failed to create bot')
    } finally {
      setCreating(false)
    }
  }

  const toggleBot = async (bot: Bot) => {
    const action = bot.status === 'running' ? 'stop' : 'start'
    setActionLoading(`${action}-${bot.id}`)
    try {
      const res = await fetch(`/api/discordbot/${bot.id}/${action}`, { method: 'POST' })
      const data = await res.json()
      if (!res.ok) { toast.error(data.error || `Failed to ${action}`); return }
      setBots(prev => prev.map(b => b.id === bot.id ? { ...b, status: data.status || (action === 'start' ? 'running' : 'stopped') } : b))
      toast.success(action === 'start' ? 'Bot started!' : 'Bot stopped')
    } catch {
      toast.error(`Failed to ${action} bot`)
    } finally {
      setActionLoading(null)
    }
  }

  const deleteBot = async (id: string) => {
    setDeleteConfirm(null)
    setActionLoading(`delete-${id}`)
    try {
      const res = await fetch(`/api/discordbot/${id}`, { method: 'DELETE' })
      if (!res.ok) { toast.error('Failed to delete'); return }
      setBots(prev => prev.filter(b => b.id !== id))
      toast.success('Bot deleted')
    } catch {
      toast.error('Failed to delete bot')
    } finally {
      setActionLoading(null)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
        </div>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white flex flex-col">
      <Navbar />
      <main className="flex-1 max-w-6xl mx-auto w-full px-4 py-8 md:py-10">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center">
              <RobotIcon className="w-6 h-6 text-purple-400" />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-black text-white">Discord Bot Manager</h1>
              <p className="text-white/40 text-sm mt-0.5">Create and manage your Discord bots</p>
            </div>
          </div>
          <Button onClick={() => setShowCreate(true)} className="bg-purple-600 hover:bg-purple-500 text-white rounded-full gap-2 shadow-lg shadow-purple-500/25">
            <Plus className="w-4 h-4" /> New Bot
          </Button>
        </div>

        {bots.length === 0 ? (
          <div className="text-center py-20 md:py-28 border-2 border-dashed border-white/10 rounded-2xl">
            <RobotIcon className="w-20 h-20 text-white/10 mx-auto mb-4" />
            <p className="text-white/40 text-lg mb-1">No bots yet</p>
            <p className="text-white/25 text-sm mb-6">Create your first Discord bot to get started</p>
            <Button onClick={() => setShowCreate(true)} className="bg-purple-600 hover:bg-purple-500 text-white rounded-full gap-2">
              <Plus className="w-4 h-4" /> Create Your First Bot
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {bots.map(bot => {
              const st = STATUS_STYLES[bot.status] || STATUS_STYLES.stopped
              const isDeleting = actionLoading === `delete-${bot.id}`
              const isToggling = actionLoading === `start-${bot.id}` || actionLoading === `stop-${bot.id}`
              return (
                <div key={bot.id} className="bg-gray-800 border border-white/[0.06] rounded-2xl p-5 hover:border-purple-500/30 transition group">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center flex-shrink-0">
                        <Code className="w-5 h-5 text-purple-400" />
                      </div>
                      <div className="min-w-0">
                        <h3 className="font-bold text-white truncate">{bot.name}</h3>
                        <span className="text-[11px] text-white/30">Prefix: {bot.prefix}</span>
                      </div>
                    </div>
                    <div className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${st.bg} ${st.text} flex-shrink-0`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${st.dot} ${bot.status === 'running' ? 'animate-pulse' : ''}`} />
                      {st.label}
                    </div>
                  </div>

                  {bot.description && (
                    <p className="text-sm text-white/50 mb-3 line-clamp-2">{bot.description}</p>
                  )}

                  <div className="flex items-center gap-3 text-xs text-white/30 mb-4">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {formatDistanceToNow(new Date(bot.createdAt), { addSuffix: true })}
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageSquare className="w-3 h-3" />
                      {bot.logCount} logs
                    </span>
                    {bot.language && (
                      <Badge className="bg-white/5 text-white/40 border-white/10 text-[10px]">{bot.language.toUpperCase()}</Badge>
                    )}
                  </div>

                  <div className="flex items-center gap-2 pt-3 border-t border-white/[0.06]">
                    <Button size="sm" asChild variant="ghost" className="h-8 px-3 text-xs text-white/50 hover:text-white hover:bg-white/5 gap-1.5">
                      <a href={`/discordbot/${bot.id}`}>
                        <Settings className="w-3.5 h-3.5" /> Manage
                      </a>
                    </Button>
                    <Button size="sm" onClick={() => toggleBot(bot)} disabled={!!isToggling}
                      className={`h-8 px-3 text-xs gap-1.5 ${bot.status === 'running' ? 'bg-amber-600 hover:bg-amber-500' : 'bg-emerald-600 hover:bg-emerald-500'} text-white`}>
                      {isToggling ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : bot.status === 'running' ? <Square className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                      {bot.status === 'running' ? 'Stop' : 'Start'}
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => setDeleteConfirm(bot.id)} disabled={!!isDeleting}
                      className="h-8 w-8 p-0 text-red-400/40 hover:text-red-400 hover:bg-red-500/10 ml-auto">
                      {isDeleting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                    </Button>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </main>
      <Footer />

      {showCreate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm" onClick={() => !creating && setShowCreate(false)}>
          <div className="bg-gray-800 border border-white/[0.08] rounded-2xl p-6 w-full max-w-md shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-purple-500/15 border border-purple-500/25 flex items-center justify-center">
                  <Plus className="w-5 h-5 text-purple-400" />
                </div>
                <h2 className="text-lg font-bold text-white">Create Bot</h2>
              </div>
              <button onClick={() => !creating && setShowCreate(false)} className="text-white/30 hover:text-white/60 transition">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <Label className="text-sm text-white/60 mb-1.5 block">Bot Name *</Label>
                <Input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
                  placeholder="My Awesome Bot" className="bg-gray-900 border-white/10 text-white placeholder:text-white/30"
                  onKeyDown={e => e.key === 'Enter' && handleCreate()} />
              </div>
              <div>
                <Label className="text-sm text-white/60 mb-1.5 block">Description</Label>
                <textarea value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))}
                  placeholder="What does your bot do?"
                  className="w-full rounded-xl bg-gray-900 border border-white/10 text-white text-sm p-3 resize-none h-24 placeholder:text-white/30 focus:outline-none focus:border-purple-500/40" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-sm text-white/60 mb-1.5 block">Prefix</Label>
                  <Input value={form.prefix} onChange={e => setForm(p => ({ ...p, prefix: e.target.value }))}
                    placeholder="!" maxLength={5} className="bg-gray-900 border-white/10 text-white placeholder:text-white/30 font-mono" />
                </div>
                <div>
                  <Label className="text-sm text-white/60 mb-1.5 block">Language</Label>
                  <Select value={form.language} onValueChange={v => setForm(p => ({ ...p, language: v }))}>
                    <SelectTrigger className="bg-gray-900 border-white/10 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-800 border-white/10 text-white">
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="bn">Bangla</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            <div className="flex gap-3 mt-6">
              <Button variant="ghost" onClick={() => setShowCreate(false)} disabled={creating} className="flex-1 text-white/60 hover:text-white">
                Cancel
              </Button>
              <Button onClick={handleCreate} disabled={creating} className="flex-1 bg-purple-600 hover:bg-purple-500 text-white gap-2 rounded-full">
                {creating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />}
                Create Bot
              </Button>
            </div>
          </div>
        </div>
      )}

      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm" onClick={() => setDeleteConfirm(null)}>
          <div className="bg-gray-800 border border-white/[0.08] rounded-2xl p-6 w-full max-w-sm shadow-2xl text-center" onClick={e => e.stopPropagation()}>
            <div className="w-12 h-12 rounded-full bg-red-500/10 border border-red-500/25 flex items-center justify-center mx-auto mb-4">
              <AlertCircle className="w-6 h-6 text-red-400" />
            </div>
            <h2 className="text-lg font-bold text-white mb-2">Delete Bot?</h2>
            <p className="text-sm text-white/50 mb-6">This action cannot be undone. The bot will be permanently removed.</p>
            <div className="flex gap-3">
              <Button variant="ghost" onClick={() => setDeleteConfirm(null)} className="flex-1 text-white/60 hover:text-white">
                Cancel
              </Button>
              <Button onClick={() => deleteBot(deleteConfirm)} disabled={actionLoading === `delete-${deleteConfirm}`}
                className="flex-1 bg-red-600 hover:bg-red-500 text-white gap-2 rounded-full">
                {actionLoading === `delete-${deleteConfirm}` ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                Delete
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
