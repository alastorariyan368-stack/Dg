'use client'

import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Loader2, Gift, Sparkles, Trophy, Clock, CheckCircle } from 'lucide-react'
import { toast } from 'sonner'

type Reward = {
  id: string; name: string; type: string; value: number; probability: number; isActive: boolean
}

function getTimeUntil(isoDate: string): string {
  const diff = new Date(isoDate).getTime() - Date.now()
  if (diff <= 0) return '0h 0m'
  const h = Math.floor(diff / 3600000)
  const m = Math.floor((diff % 3600000) / 60000)
  return `${h}h ${m}m`
}

export default function RewardsPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [rewards, setRewards] = useState<Reward[]>([])
  const [userBalance, setUserBalance] = useState(0)
  const [loading, setLoading] = useState(true)
  const [claiming, setClaiming] = useState(false)
  const [lastReward, setLastReward] = useState<any>(null)
  const [nextClaimAt, setNextClaimAt] = useState<string | null>(null)
  const [canClaim, setCanClaim] = useState(true)
  const [timeLeft, setTimeLeft] = useState('')

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin')
  }, [status, router])

  useEffect(() => {
    if (status !== 'authenticated') return
    const load = async () => {
      setLoading(true)
      try {
        const [rewardsRes, userRes] = await Promise.all([
          fetch('/api/rewards'),
          fetch('/api/users/me')
        ])
        if (rewardsRes.ok) { const d = await rewardsRes.json(); setRewards(d.rewards || []) }
        if (userRes.ok) {
          const d = await userRes.json()
          setUserBalance(d.walletBalance || 0)
          if (d.lastRewardClaim) {
            const next = new Date(new Date(d.lastRewardClaim).getTime() + 24 * 60 * 60 * 1000)
            if (next > new Date()) {
              setCanClaim(false)
              setNextClaimAt(next.toISOString())
              setTimeLeft(getTimeUntil(next.toISOString()))
            }
          }
        }
      } catch { toast.error('Failed to load rewards') }
      finally { setLoading(false) }
    }
    load()
  }, [status])

  useEffect(() => {
    if (!nextClaimAt) return
    const interval = setInterval(() => {
      const t = getTimeUntil(nextClaimAt)
      setTimeLeft(t)
      if (new Date(nextClaimAt) <= new Date()) {
        setCanClaim(true); setNextClaimAt(null); clearInterval(interval)
      }
    }, 60000)
    return () => clearInterval(interval)
  }, [nextClaimAt])

  const claimReward = async () => {
    if (!canClaim) return
    setClaiming(true)
    try {
      const res = await fetch('/api/rewards/claim', { method: 'POST' })
      const data = await res.json()
      if (res.ok) {
        setLastReward(data.reward)
        setUserBalance(data.newBalance || userBalance)
        setCanClaim(false)
        setNextClaimAt(data.nextClaimAt)
        setTimeLeft(getTimeUntil(data.nextClaimAt))
        toast.success(`🎉 You won: ${data.reward.name}!`)
      } else if (res.status === 429) {
        setCanClaim(false)
        setNextClaimAt(data.nextClaimAt)
        setTimeLeft(getTimeUntil(data.nextClaimAt))
        toast.error(`Already claimed today. Come back in ${data.hoursRemaining}h`)
      } else {
        toast.error(data.error || 'Failed to claim reward')
      }
    } catch { toast.error('Failed to claim reward') }
    finally { setClaiming(false) }
  }

  if (status === 'loading' || loading) {
    return <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin text-purple-400" /></div>
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      <div className="container mx-auto px-4 py-10 max-w-4xl">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Gift className="w-6 h-6 text-purple-400" />
            <h1 className="text-3xl font-bold">Daily Rewards</h1>
          </div>
          <p className="text-white/40">Claim once per day — win coins and special bonuses!</p>
        </div>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
          <div className="bg-gradient-to-br from-purple-600/20 to-blue-600/20 border border-purple-500/30 rounded-2xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-white">Your Wallet</h2>
              <Trophy className="w-6 h-6 text-yellow-400" />
            </div>
            <p className="text-4xl font-bold text-emerald-400 mb-2">${userBalance.toFixed(2)}</p>
            <p className="text-sm text-white/40">Total balance</p>
          </div>

          <div className="bg-gradient-to-br from-orange-600/20 to-red-600/20 border border-orange-500/30 rounded-2xl p-6 flex flex-col justify-between">
            <div className="mb-4">
              <h2 className="text-lg font-semibold text-white mb-1">
                {canClaim ? 'Ready to Claim!' : 'Already Claimed'}
              </h2>
              {!canClaim && nextClaimAt ? (
                <div className="flex items-center gap-2 text-sm text-white/50">
                  <Clock className="w-4 h-4" />
                  <span>Next claim in {timeLeft}</span>
                </div>
              ) : (
                <p className="text-sm text-white/40">Spin the wheel and try your luck!</p>
              )}
            </div>
            <Button
              onClick={claimReward}
              disabled={claiming || !canClaim || rewards.length === 0}
              className={`w-full border-0 rounded-lg gap-2 h-12 text-base font-semibold ${canClaim ? 'bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-500 hover:to-red-500 text-white' : 'bg-white/5 text-white/30 cursor-not-allowed'}`}
            >
              {claiming ? (
                <><Loader2 className="w-5 h-5 animate-spin" />Spinning...</>
              ) : !canClaim ? (
                <><CheckCircle className="w-5 h-5" />Claimed Today</>
              ) : (
                <><Sparkles className="w-5 h-5" />Claim Daily Reward</>
              )}
            </Button>
          </div>
        </div>

        {lastReward && (
          <div className="bg-gradient-to-r from-emerald-500/20 to-green-500/20 border border-emerald-500/30 rounded-2xl p-6 mb-8 animate-in fade-in">
            <h3 className="text-lg font-semibold text-white mb-2">🎉 You Won!</h3>
            <p className="text-2xl font-bold text-emerald-400">
              {lastReward.type === 'COINS' ? `+$${lastReward.value}` : `${lastReward.value}% Discount`}
            </p>
            <p className="text-sm text-white/50 mt-1">{lastReward.name}</p>
          </div>
        )}

        <div className="mb-8">
          <h2 className="text-lg font-semibold text-white mb-4">Possible Rewards</h2>
          {rewards.length === 0 ? (
            <div className="bg-white/[0.02] border border-white/5 rounded-2xl p-8 text-center">
              <Gift className="w-12 h-12 text-white/10 mx-auto mb-3" />
              <p className="text-white/30">No rewards configured yet</p>
              <p className="text-xs text-white/20 mt-1">Admins can add rewards from the admin panel</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {rewards.map(reward => (
                <div key={reward.id} className="bg-white/[0.03] border border-white/8 rounded-xl p-4 hover:border-purple-500/20 transition-colors">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-sm font-semibold text-white flex-1">{reward.name}</h3>
                    <Badge className="text-[9px] bg-amber-500/15 text-amber-300 border-amber-500/20">
                      {(reward.probability * 100).toFixed(0)}% chance
                    </Badge>
                  </div>
                  <p className="text-xl font-bold text-purple-400 mb-1">
                    {reward.type === 'COINS' ? `$${reward.value}` : `${reward.value}% OFF`}
                  </p>
                  <p className="text-[11px] text-white/40">
                    {reward.type === 'COINS' ? '💰 Wallet Bonus' : '🎫 Discount Coupon'}
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="bg-white/[0.02] border border-white/5 rounded-2xl p-6">
          <h3 className="text-base font-semibold text-white mb-3">How It Works</h3>
          <ul className="space-y-2 text-sm text-white/40">
            <li className="flex gap-3"><span className="text-purple-400 font-bold">1.</span><span>Click "Claim Daily Reward" once per day</span></li>
            <li className="flex gap-3"><span className="text-purple-400 font-bold">2.</span><span>A random reward is selected based on probability weights</span></li>
            <li className="flex gap-3"><span className="text-purple-400 font-bold">3.</span><span>Coin rewards are added directly to your wallet balance</span></li>
            <li className="flex gap-3"><span className="text-purple-400 font-bold">4.</span><span>Come back every 24 hours to claim again</span></li>
          </ul>
        </div>
      </div>
      <Footer />
    </div>
  )
}
