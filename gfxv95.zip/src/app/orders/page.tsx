'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { ShoppingBag, Package, Clock, CheckCircle, XCircle, ArrowRight, Loader2, DollarSign, RefreshCw } from 'lucide-react'
import { toast } from 'sonner'

interface Order {
  id: string; amount: number; status: string; discountAmount: number
  createdAt: string; deliveredAt?: string
  item: { id: string; title: string; slug: string; logo?: string; price: number }
  buyer: { id: string; username: string; avatar?: string }
  seller: { id: string; username: string; avatar?: string; isVerified: boolean }
  coupon?: { code: string; discountValue: number; discountType: string }
}

const statusConfig: Record<string, { label: string; color: string; icon: React.ReactNode }> = {
  PENDING: { label: 'Pending', color: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30', icon: <Clock className="w-3 h-3" /> },
  IN_PROGRESS: { label: 'In Progress', color: 'bg-blue-500/20 text-blue-400 border-blue-500/30', icon: <RefreshCw className="w-3 h-3" /> },
  DELIVERED: { label: 'Delivered', color: 'bg-green-500/20 text-green-400 border-green-500/30', icon: <CheckCircle className="w-3 h-3" /> },
  CANCELLED: { label: 'Cancelled', color: 'bg-red-500/20 text-red-400 border-red-500/30', icon: <XCircle className="w-3 h-3" /> },
  REFUNDED: { label: 'Refunded', color: 'bg-purple-500/20 text-purple-400 border-purple-500/30', icon: <DollarSign className="w-3 h-3" /> },
}

function OrderCard({ order, isSeller, onUpdateStatus }: { order: Order; isSeller: boolean; onUpdateStatus: (id: string, status: string) => void }) {
  const s = statusConfig[order.status] || statusConfig.PENDING
  return (
    <div className="bg-white/[0.03] border border-white/8 hover:border-purple-500/20 rounded-2xl p-5 transition-all">
      <div className="flex items-start gap-4">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500/20 to-blue-500/20 border border-white/10 flex items-center justify-center flex-shrink-0">
          {order.item.logo ? <img src={order.item.logo} alt={order.item.title} className="w-full h-full object-cover rounded-xl" /> : <Package className="w-5 h-5 text-white/30" />}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2 flex-wrap">
            <div>
              <Link href={`/items/${order.item.slug}`} className="font-semibold text-white hover:text-purple-300 transition-colors text-sm line-clamp-1">{order.item.title}</Link>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-xs text-white/40">
                  {isSeller ? `Buyer: ${order.buyer.username}` : `Seller: ${order.seller.username}`}
                </span>
                {order.seller.isVerified && <Badge className="h-4 text-[9px] bg-blue-500/20 text-blue-400 border-blue-500/30">✓ Verified</Badge>}
              </div>
            </div>
            <Badge className={`${s.color} border text-xs flex items-center gap-1`}>
              {s.icon}{s.label}
            </Badge>
          </div>
          <div className="flex items-center justify-between mt-3 flex-wrap gap-2">
            <div className="flex items-center gap-3 text-xs text-white/40">
              <span className="text-green-400 font-semibold text-sm">${order.amount.toFixed(2)}</span>
              {order.discountAmount > 0 && <span className="text-white/30 line-through">${(order.amount + order.discountAmount).toFixed(2)}</span>}
              {order.coupon && <Badge className="bg-orange-500/10 text-orange-400 border-orange-500/20 text-[10px]">{order.coupon.code}</Badge>}
              <span>{new Date(order.createdAt).toLocaleDateString()}</span>
            </div>
            {isSeller && order.status === 'PENDING' && (
              <Button size="sm" onClick={() => onUpdateStatus(order.id, 'IN_PROGRESS')}
                className="h-7 text-xs bg-blue-500/20 hover:bg-blue-500/40 text-blue-400 border-0 rounded-lg">
                Accept Order
              </Button>
            )}
            {isSeller && order.status === 'IN_PROGRESS' && (
              <Button size="sm" onClick={() => onUpdateStatus(order.id, 'DELIVERED')}
                className="h-7 text-xs bg-green-500/20 hover:bg-green-500/40 text-green-400 border-0 rounded-lg">
                Mark Delivered
              </Button>
            )}
            {!isSeller && order.status === 'DELIVERED' && (
              <Link href={`/items/${order.item.slug}`}>
                <Button size="sm" className="h-7 text-xs bg-purple-500/20 hover:bg-purple-500/40 text-purple-400 border-0 rounded-lg gap-1">
                  Download <ArrowRight className="w-3 h-3" />
                </Button>
              </Link>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default function OrdersPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [buyerOrders, setBuyerOrders] = useState<Order[]>([])
  const [sellerOrders, setSellerOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin')
    if (status === 'authenticated') fetchOrders()
  }, [status])

  const fetchOrders = async () => {
    try {
      const [buyerRes, sellerRes] = await Promise.all([
        fetch('/api/orders?type=buyer'),
        fetch('/api/orders?type=seller')
      ])
      if (buyerRes.ok) { const d = await buyerRes.json(); setBuyerOrders(d.orders || []) }
      if (sellerRes.ok) { const d = await sellerRes.json(); setSellerOrders(d.orders || []) }
    } catch {} finally { setLoading(false) }
  }

  const handleUpdateStatus = async (id: string, status: string) => {
    try {
      const res = await fetch(`/api/orders/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) })
      if (res.ok) { toast.success(`Order updated to ${status}`); fetchOrders() }
      else { const d = await res.json(); toast.error(d.error) }
    } catch { toast.error('Failed to update order') }
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      <Navbar />
      <div className="container mx-auto px-4 py-12 max-w-4xl">
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-1">
            <ShoppingBag className="h-5 w-5 text-purple-400" />
            <span className="text-sm font-medium text-purple-400 uppercase tracking-wider">Commerce</span>
          </div>
          <h1 className="text-3xl font-bold text-white">My Orders</h1>
          <p className="text-white/40 mt-1 text-sm">Track your purchases and sales</p>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-purple-400" /></div>
        ) : (
          <Tabs defaultValue="purchases">
            <TabsList className="bg-white/5 border border-white/10 rounded-xl p-1 mb-6 inline-flex gap-1">
              <TabsTrigger value="purchases" className="rounded-lg text-xs px-4 py-2 data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-300 text-white/50">
                My Purchases ({buyerOrders.length})
              </TabsTrigger>
              <TabsTrigger value="sales" className="rounded-lg text-xs px-4 py-2 data-[state=active]:bg-purple-500/20 data-[state=active]:text-purple-300 text-white/50">
                My Sales ({sellerOrders.length})
              </TabsTrigger>
            </TabsList>

            <TabsContent value="purchases">
              {buyerOrders.length === 0 ? (
                <div className="text-center py-16">
                  <ShoppingBag className="w-12 h-12 mx-auto text-white/10 mb-3" />
                  <p className="text-white/40">No purchases yet</p>
                  <Link href="/browse" className="mt-4 inline-block">
                    <Button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl mt-3">Browse Content</Button>
                  </Link>
                </div>
              ) : (
                <div className="space-y-3">{buyerOrders.map(o => <OrderCard key={o.id} order={o} isSeller={false} onUpdateStatus={handleUpdateStatus} />)}</div>
              )}
            </TabsContent>

            <TabsContent value="sales">
              {sellerOrders.length === 0 ? (
                <div className="text-center py-16">
                  <Package className="w-12 h-12 mx-auto text-white/10 mb-3" />
                  <p className="text-white/40">No sales yet</p>
                  <Link href="/upload" className="mt-4 inline-block">
                    <Button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl mt-3">Upload Content</Button>
                  </Link>
                </div>
              ) : (
                <div className="space-y-3">{sellerOrders.map(o => <OrderCard key={o.id} order={o} isSeller={true} onUpdateStatus={handleUpdateStatus} />)}</div>
              )}
            </TabsContent>
          </Tabs>
        )}
      </div>
      <Footer />
    </div>
  )
}
