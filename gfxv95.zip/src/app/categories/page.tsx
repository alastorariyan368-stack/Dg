'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Badge } from '@/components/ui/badge'
import { Loader2, Layers, Package, ArrowRight } from 'lucide-react'

interface Category {
  id: string; name: string; slug: string; description?: string; icon?: string; color?: string
  _count?: { items: number }
}

export default function CategoriesPage() {
  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/categories')
      .then(r => r.json())
      .then(d => setCategories(Array.isArray(d) ? d : d.categories || []))
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  const categoryColors = [
    'from-purple-500/20 to-violet-500/10 border-purple-500/20',
    'from-blue-500/20 to-cyan-500/10 border-blue-500/20',
    'from-green-500/20 to-emerald-500/10 border-green-500/20',
    'from-orange-500/20 to-amber-500/10 border-orange-500/20',
    'from-pink-500/20 to-rose-500/10 border-pink-500/20',
    'from-indigo-500/20 to-blue-500/10 border-indigo-500/20',
    'from-teal-500/20 to-green-500/10 border-teal-500/20',
    'from-red-500/20 to-orange-500/10 border-red-500/20',
  ]

  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      <Navbar />
      <section className="relative py-16 px-4 text-center">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff06_1px,transparent_1px),linear-gradient(to_bottom,#ffffff06_1px,transparent_1px)] bg-[size:32px_32px]" />
        <div className="container mx-auto relative z-10">
          <Badge className="mb-4 px-4 py-1.5 bg-purple-500/10 text-purple-300 border-purple-500/30"><Layers className="w-3.5 h-3.5 mr-1.5" />Browse by Category</Badge>
          <h1 className="text-4xl font-bold text-white mb-3">All Categories</h1>
          <p className="text-white/50 text-lg max-w-lg mx-auto">Explore our full collection of digital resources organized by type</p>
        </div>
      </section>

      <div className="container mx-auto px-4 pb-20 max-w-5xl">
        {loading ? (
          <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-purple-400" /></div>
        ) : categories.length === 0 ? (
          <div className="text-center py-20"><Layers className="w-16 h-16 mx-auto text-white/10 mb-4" /><p className="text-white/40">No categories found</p></div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {categories.map((cat, i) => (
              <Link key={cat.id} href={`/browse?category=${cat.slug}`}>
                <div className={`group bg-gradient-to-br ${categoryColors[i % categoryColors.length]} border rounded-2xl p-5 transition-all duration-300 hover:scale-105 cursor-pointer h-full`}>
                  <div className="flex items-center gap-3 mb-3">
                    <div className="w-10 h-10 rounded-xl bg-white/5 flex items-center justify-center text-xl">
                      {cat.icon || <Package className="w-5 h-5 text-white/50" />}
                    </div>
                    <h3 className="font-semibold text-white group-hover:text-purple-200 transition-colors">{cat.name}</h3>
                  </div>
                  {cat.description && <p className="text-white/50 text-xs mb-3 line-clamp-2">{cat.description}</p>}
                  <div className="flex items-center justify-between">
                    {cat._count ? <span className="text-xs text-white/30">{cat._count.items} items</span> : <span />}
                    <ArrowRight className="h-4 w-4 text-white/30 group-hover:text-purple-400 transition-colors" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
      <Footer />
    </div>
  )
}
