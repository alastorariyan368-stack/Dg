'use client'

import { useState, useEffect } from 'react'
import { useParams } from 'next/navigation'
import { useSession } from 'next-auth/react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Textarea } from '@/components/ui/textarea'
import {
  Download, Star, Eye, Calendar, Package, Tag, Heart, Share2,
  FileArchive, MessageSquare, Send, Image as ImageIcon, Shield,
  ChevronLeft, ChevronRight, Zap, CheckCircle, Loader2, Clock,
  BarChart3, ArrowLeft, ExternalLink, ShoppingCart
} from 'lucide-react'
import Link from 'next/link'
import { ReportButton } from '@/components/report-button'
import { toast } from 'sonner'

interface Item {
  id: string; title: string; slug: string; description: string; shortDesc: string
  moreInfo?: string; downloads: number; likes: number; views: number; price: number
  createdAt: string; updatedAt: string; status: string; tags: string[]; featured: boolean
  logo?: string; accessType?: string
  author: { id: string; username: string; avatar?: string; isVerified?: boolean; sellerLevel?: number }
  category: { name: string; slug: string }
  subcategory?: { name: string; slug: string }
  versions: { id: string; version: string; fileName: string; fileSize: number; downloadUrl: string; changelog?: string; createdAt: string }[]
  screenshots: { id: string; url: string; alt?: string; sortOrder: number }[]
  _count: { reviews: number }
}

interface Review {
  id: string; rating: number; comment: string; createdAt: string
  user: { id: string; username: string; avatar?: string }
}

const levelColors: Record<number, string> = {
  1: 'text-gray-400', 2: 'text-green-400', 3: 'text-blue-400', 4: 'text-purple-400', 5: 'text-yellow-400'
}

function StarRating({ rating, interactive, onChange }: { rating: number; interactive?: boolean; onChange?: (r: number) => void }) {
  const [hovered, setHovered] = useState(0)
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map(s => (
        <button
          key={s}
          type="button"
          disabled={!interactive}
          onClick={() => interactive && onChange?.(s)}
          onMouseEnter={() => interactive && setHovered(s)}
          onMouseLeave={() => interactive && setHovered(0)}
          className={`transition-colors ${interactive ? 'cursor-pointer hover:scale-110' : 'cursor-default'}`}
        >
          <Star className={`w-4 h-4 ${(hovered || rating) >= s ? 'text-yellow-400 fill-yellow-400' : 'text-white/20'}`} />
        </button>
      ))}
    </div>
  )
}

function formatFileSize(bytes: number) {
  if (!bytes) return '0 B'
  const sizes = ['B', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(1024))
  return (bytes / Math.pow(1024, i)).toFixed(1) + ' ' + sizes[i]
}

function timeAgo(dateStr: string) {
  const diff = Date.now() - new Date(dateStr).getTime()
  const d = Math.floor(diff / 86400000)
  if (d === 0) return 'Today'
  if (d === 1) return 'Yesterday'
  if (d < 30) return `${d}d ago`
  if (d < 365) return `${Math.floor(d / 30)}mo ago`
  return `${Math.floor(d / 365)}y ago`
}

export default function ItemPage() {
  const params = useParams()
  const slug = params.slug as string
  const { data: session } = useSession()
  const [item, setItem] = useState<Item | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [selectedVersion, setSelectedVersion] = useState<string>('')
  const [isLiked, setIsLiked] = useState(false)
  const [isWishlisted, setIsWishlisted] = useState(false)
  const [activeImg, setActiveImg] = useState(0)
  const [reviews, setReviews] = useState<Review[]>([])
  const [newReview, setNewReview] = useState({ rating: 5, comment: '' })
  const [submitting, setSubmitting] = useState(false)
  const [downloading, setDownloading] = useState(false)
  const [addingToCart, setAddingToCart] = useState(false)
  const [activeTab, setActiveTab] = useState<'description' | 'versions' | 'reviews'>('description')

  useEffect(() => { if (slug) fetchItem() }, [slug])

  const fetchItem = async () => {
    try {
      const res = await fetch(`/api/items/${slug}`)
      if (res.ok) {
        const data = await res.json()
        setItem(data)
        if (data.versions.length > 0) setSelectedVersion(data.versions[0].id)
        fetchReviews(data.id)
      }
    } catch {}
    finally { setIsLoading(false) }
  }

  const fetchReviews = async (itemId: string) => {
    try {
      const res = await fetch(`/api/reviews?itemId=${itemId}`)
      if (res.ok) { const d = await res.json(); setReviews(d.reviews || []) }
    } catch {}
  }

  const handleDownload = async () => {
    if (!item) return
    setDownloading(true)
    try {
      const tokenRes = await fetch('/api/download/generate-token', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ itemId: item.id }),
      })
      if (tokenRes.ok) {
        const { token } = await tokenRes.json()
        window.open(`/api/download/secure?token=${token}`, '_blank')
        setItem(prev => prev ? { ...prev, downloads: prev.downloads + 1 } : null)
        toast.success('Download started!')
      } else {
        const err = await tokenRes.json()
        toast.error(err.error || 'Download failed')
      }
    } catch { toast.error('Download error') }
    finally { setDownloading(false) }
  }

  const handleAddToCart = async () => {
    if (!session) { toast.error('Sign in to add to cart'); return }
    if (!item) return
    setAddingToCart(true)
    try {
      const res = await fetch('/api/cart', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ itemId: item.id }),
      })
      if (res.ok) toast.success('Added to cart!')
      else { const d = await res.json(); toast.error(d.error || 'Failed to add') }
    } catch { toast.error('Error adding to cart') }
    finally { setAddingToCart(false) }
  }

  const handleLike = async () => {
    if (!session || !item) return
    try {
      const res = await fetch(`/api/items/${item.slug}/like`, { method: 'POST' })
      if (res.ok) {
        setIsLiked(!isLiked)
        setItem(prev => prev ? { ...prev, likes: isLiked ? prev.likes - 1 : prev.likes + 1 } : null)
      }
    } catch {}
  }

  const handleShare = () => {
    const url = window.location.href
    if (navigator.share) navigator.share({ title: item?.title, url })
    else { navigator.clipboard.writeText(url); toast.success('Link copied!') }
  }

  const handleSubmitReview = async () => {
    if (!session || !item || !newReview.comment.trim()) return
    setSubmitting(true)
    try {
      const res = await fetch('/api/reviews', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ itemId: item.id, rating: newReview.rating, comment: newReview.comment }),
      })
      if (res.ok) {
        const d = await res.json()
        setReviews(prev => [d.review, ...prev])
        setNewReview({ rating: 5, comment: '' })
        toast.success('Review submitted!')
      } else { const d = await res.json(); toast.error(d.error || 'Failed to submit') }
    } catch { toast.error('Error submitting review') }
    finally { setSubmitting(false) }
  }

  const avgRating = reviews.length ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1) : null

  if (isLoading) return (
    <div className="min-h-screen bg-[#0a0a0f]">
      <Navbar />
      <div className="container mx-auto px-4 py-16 flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-purple-400 animate-spin" />
      </div>
    </div>
  )

  if (!item) return (
    <div className="min-h-screen bg-[#0a0a0f]">
      <Navbar />
      <div className="container mx-auto px-4 py-20 text-center">
        <div className="text-6xl mb-4">🔍</div>
        <h1 className="text-2xl font-bold text-white mb-2">Item Not Found</h1>
        <p className="text-white/40 mb-6">The item you're looking for doesn't exist or was removed.</p>
        <Link href="/browse">
          <Button className="bg-purple-600 hover:bg-purple-700 text-white rounded-xl">Browse Items</Button>
        </Link>
      </div>
      <Footer />
    </div>
  )

  const currentVersion = item.versions.find(v => v.id === selectedVersion) || item.versions[0]
  const isFree = item.accessType === 'FREE'
  const isPaid = item.accessType === 'PAID'
  const requiresRole = item.accessType === 'ROLE'
  const mainImg = item.screenshots[activeImg] || null

  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      <Navbar />

      <div className="container mx-auto px-4 py-6 max-w-7xl">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-xs text-white/30 mb-6">
          <Link href="/" className="hover:text-white/60 transition-colors">Home</Link>
          <span>/</span>
          <Link href="/browse" className="hover:text-white/60 transition-colors">Browse</Link>
          <span>/</span>
          <Link href={`/browse?category=${item.category.slug}`} className="hover:text-white/60 transition-colors">{item.category.name}</Link>
          <span>/</span>
          <span className="text-white/60 truncate max-w-[200px]">{item.title}</span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* LEFT: Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Header Card */}
            <div className="bg-[#0f0f1a] border border-white/8 rounded-2xl p-6">
              <div className="flex flex-col sm:flex-row gap-5">
                {/* Logo */}
                <div className="w-24 h-24 sm:w-28 sm:h-28 flex-shrink-0 rounded-2xl overflow-hidden bg-white/5 border border-white/10">
                  {item.logo || (item.screenshots[0]?.url) ? (
                    <img src={item.logo || item.screenshots[0]?.url} alt={item.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center"><ImageIcon className="w-10 h-10 text-white/20" /></div>
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  {/* Badges */}
                  <div className="flex flex-wrap gap-2 mb-2">
                    <Link href={`/browse?category=${item.category.slug}`}>
                      <Badge className="bg-purple-500/15 text-purple-300 border-purple-500/20 hover:bg-purple-500/25 text-[10px] cursor-pointer">{item.category.name}</Badge>
                    </Link>
                    {item.subcategory && (
                      <Badge className="bg-blue-500/15 text-blue-300 border-blue-500/20 text-[10px]">{item.subcategory.name}</Badge>
                    )}
                    {item.featured && (
                      <Badge className="bg-yellow-500/20 text-yellow-300 border-yellow-500/30 text-[10px]">⭐ Featured</Badge>
                    )}
                    {isFree ? (
                      <Badge className="bg-green-500/15 text-green-300 border-green-500/20 text-[10px]">Free</Badge>
                    ) : isPaid ? (
                      <Badge className="bg-orange-500/15 text-orange-300 border-orange-500/20 text-[10px]">Premium</Badge>
                    ) : requiresRole ? (
                      <Badge className="bg-purple-500/15 text-purple-300 border-purple-500/20 text-[10px]">🔒 Membership</Badge>
                    ) : (
                      <Badge className="bg-gray-500/15 text-gray-300 border-gray-500/20 text-[10px]">Free</Badge>
                    )}
                  </div>

                  <h1 className="text-2xl sm:text-3xl font-bold text-white mb-1 leading-tight">{item.title}</h1>
                  <p className="text-white/50 text-sm mb-3 line-clamp-2">{item.shortDesc}</p>

                  {/* Stats row */}
                  <div className="flex flex-wrap items-center gap-4 text-xs text-white/40">
                    <span className="flex items-center gap-1"><Download className="w-3.5 h-3.5" />{item.downloads.toLocaleString()} downloads</span>
                    <span className="flex items-center gap-1"><Eye className="w-3.5 h-3.5" />{item.views.toLocaleString()} views</span>
                    {avgRating && <span className="flex items-center gap-1"><Star className="w-3.5 h-3.5 text-yellow-400" />{avgRating} ({reviews.length})</span>}
                    <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" />{timeAgo(item.updatedAt)}</span>
                  </div>

                  {/* Author */}
                  <div className="flex items-center gap-2 mt-3">
                    <span className="text-white/30 text-xs">by</span>
                    <Link href={`/profile/${item.author.username}`} className="flex items-center gap-1.5 group">
                      <Avatar className="w-5 h-5">
                        <AvatarImage src={item.author.avatar} />
                        <AvatarFallback className="text-[8px] bg-purple-900">{item.author.username[0].toUpperCase()}</AvatarFallback>
                      </Avatar>
                      <span className="text-sm font-medium text-white/80 group-hover:text-purple-300 transition-colors">{item.author.username}</span>
                      {item.author.isVerified && <CheckCircle className="w-3.5 h-3.5 text-blue-400" />}
                      {item.author.sellerLevel && <span className={`text-[10px] font-bold ${levelColors[item.author.sellerLevel] || 'text-white/40'}`}>Lv{item.author.sellerLevel}</span>}
                    </Link>
                  </div>
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-2 mt-4 pt-4 border-t border-white/5">
                <Button
                  onClick={handleLike}
                  disabled={!session}
                  variant="ghost"
                  size="sm"
                  className={`gap-1.5 rounded-xl text-xs h-8 ${isLiked ? 'text-red-400 bg-red-500/10' : 'text-white/50 hover:text-white hover:bg-white/5'}`}
                >
                  <Heart className={`w-3.5 h-3.5 ${isLiked ? 'fill-current' : ''}`} />{item.likes}
                </Button>
                <Button onClick={handleShare} variant="ghost" size="sm" className="gap-1.5 rounded-xl text-xs h-8 text-white/50 hover:text-white hover:bg-white/5">
                  <Share2 className="w-3.5 h-3.5" />Share
                </Button>
                {session && <ReportButton itemId={item.id} />}
              </div>
            </div>

            {/* Screenshot Gallery */}
            {item.screenshots.length > 0 && (
              <div className="bg-[#0f0f1a] border border-white/8 rounded-2xl overflow-hidden">
                <div className="relative aspect-video bg-black">
                  <img src={mainImg?.url || item.screenshots[0]?.url} alt={mainImg?.alt || item.title} className="w-full h-full object-contain" />
                  {item.screenshots.length > 1 && (
                    <>
                      <button onClick={() => setActiveImg(i => Math.max(0, i - 1))} className="absolute left-3 top-1/2 -translate-y-1/2 w-8 h-8 bg-black/50 hover:bg-black/70 rounded-full flex items-center justify-center transition-colors">
                        <ChevronLeft className="w-4 h-4 text-white" />
                      </button>
                      <button onClick={() => setActiveImg(i => Math.min(item.screenshots.length - 1, i + 1))} className="absolute right-3 top-1/2 -translate-y-1/2 w-8 h-8 bg-black/50 hover:bg-black/70 rounded-full flex items-center justify-center transition-colors">
                        <ChevronRight className="w-4 h-4 text-white" />
                      </button>
                      <div className="absolute bottom-3 right-3 bg-black/60 rounded-full px-2.5 py-1 text-[10px] text-white/70">
                        {activeImg + 1} / {item.screenshots.length}
                      </div>
                    </>
                  )}
                </div>
                {item.screenshots.length > 1 && (
                  <div className="p-3 flex gap-2 overflow-x-auto">
                    {item.screenshots.map((s, i) => (
                      <button key={s.id} onClick={() => setActiveImg(i)} className={`flex-shrink-0 w-16 h-12 rounded-lg overflow-hidden border-2 transition-all ${activeImg === i ? 'border-purple-500' : 'border-white/10 hover:border-white/30'}`}>
                        <img src={s.url} alt="" className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Tabs */}
            <div className="bg-[#0f0f1a] border border-white/8 rounded-2xl overflow-hidden">
              <div className="flex border-b border-white/8">
                {(['description', 'versions', 'reviews'] as const).map(tab => (
                  <button key={tab} onClick={() => setActiveTab(tab)}
                    className={`px-5 py-3.5 text-xs font-medium capitalize transition-colors ${activeTab === tab ? 'text-purple-300 border-b-2 border-purple-500 bg-purple-500/5' : 'text-white/40 hover:text-white'}`}>
                    {tab === 'reviews' ? `Reviews (${reviews.length})` : tab === 'versions' ? `Versions (${item.versions.length})` : tab}
                  </button>
                ))}
              </div>

              <div className="p-6">
                {/* Description Tab */}
                {activeTab === 'description' && (
                  <div className="space-y-5">
                    <div className="text-white/70 text-sm leading-relaxed whitespace-pre-wrap">{item.description}</div>
                    {item.moreInfo && (
                      <div className="border-t border-white/5 pt-5">
                        <h3 className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-3">Additional Info</h3>
                        <div className="text-white/60 text-sm leading-relaxed whitespace-pre-wrap">{item.moreInfo}</div>
                      </div>
                    )}
                    {item.tags.length > 0 && (
                      <div className="border-t border-white/5 pt-5">
                        <h3 className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-3">Tags</h3>
                        <div className="flex flex-wrap gap-1.5">
                          {item.tags.map((tag, i) => (
                            <Link key={i} href={`/browse?search=${encodeURIComponent(tag)}`}>
                              <span className="inline-block bg-white/5 hover:bg-white/10 border border-white/8 rounded-lg px-2.5 py-1 text-xs text-white/60 transition-colors cursor-pointer">#{tag}</span>
                            </Link>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Versions Tab */}
                {activeTab === 'versions' && (
                  <div className="space-y-3">
                    {item.versions.length === 0 ? (
                      <div className="text-center py-8 text-white/30 text-sm">No versions available</div>
                    ) : item.versions.map((v, i) => (
                      <div key={v.id}
                        onClick={() => setSelectedVersion(v.id)}
                        className={`p-4 rounded-xl border cursor-pointer transition-all ${selectedVersion === v.id ? 'border-purple-500/50 bg-purple-500/5' : 'border-white/8 bg-white/[0.02] hover:border-white/20'}`}>
                        <div className="flex items-start justify-between gap-3">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <span className="text-sm font-semibold text-white">v{v.version}</span>
                              {i === 0 && <Badge className="bg-green-500/15 text-green-300 border-green-500/20 text-[9px] h-4">Latest</Badge>}
                            </div>
                            {v.changelog && <p className="text-xs text-white/50 mt-1">{v.changelog}</p>}
                            <p className="text-[10px] text-white/30 mt-1">{timeAgo(v.createdAt)}</p>
                          </div>
                          <div className="flex items-center gap-1.5 text-white/40 flex-shrink-0">
                            <FileArchive className="w-3.5 h-3.5" />
                            <span className="text-xs">{formatFileSize(v.fileSize)}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Reviews Tab */}
                {activeTab === 'reviews' && (
                  <div className="space-y-6">
                    {/* Rating Summary */}
                    {reviews.length > 0 && (
                      <div className="flex items-center gap-6 p-4 bg-white/[0.02] rounded-xl border border-white/5">
                        <div className="text-center">
                          <div className="text-4xl font-bold text-white">{avgRating}</div>
                          <StarRating rating={Math.round(Number(avgRating))} />
                          <div className="text-xs text-white/40 mt-1">{reviews.length} review{reviews.length !== 1 ? 's' : ''}</div>
                        </div>
                        <div className="flex-1 space-y-1.5">
                          {[5, 4, 3, 2, 1].map(n => {
                            const count = reviews.filter(r => r.rating === n).length
                            const pct = reviews.length ? (count / reviews.length) * 100 : 0
                            return (
                              <div key={n} className="flex items-center gap-2">
                                <span className="text-[10px] text-white/40 w-4">{n}</span>
                                <Star className="w-3 h-3 text-yellow-400 fill-yellow-400 flex-shrink-0" />
                                <div className="flex-1 h-1.5 bg-white/10 rounded-full overflow-hidden">
                                  <div className="h-full bg-yellow-400 rounded-full transition-all" style={{ width: `${pct}%` }} />
                                </div>
                                <span className="text-[10px] text-white/30 w-5">{count}</span>
                              </div>
                            )
                          })}
                        </div>
                      </div>
                    )}

                    {/* Write a Review */}
                    {session && (
                      <div className="bg-white/[0.02] border border-white/8 rounded-xl p-4">
                        <h3 className="text-sm font-semibold text-white mb-3">Write a Review</h3>
                        <div className="mb-3">
                          <label className="text-xs text-white/40 mb-1.5 block">Rating</label>
                          <StarRating rating={newReview.rating} interactive onChange={r => setNewReview(p => ({ ...p, rating: r }))} />
                        </div>
                        <Textarea
                          value={newReview.comment}
                          onChange={e => setNewReview(p => ({ ...p, comment: e.target.value }))}
                          placeholder="Share your experience with this item..."
                          className="bg-white/5 border-white/10 focus:border-purple-500/50 text-white text-sm rounded-xl resize-none min-h-[80px] placeholder:text-white/20"
                        />
                        <Button
                          onClick={handleSubmitReview}
                          disabled={submitting || !newReview.comment.trim()}
                          size="sm"
                          className="mt-3 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs h-8 gap-1.5"
                        >
                          {submitting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
                          Submit Review
                        </Button>
                      </div>
                    )}

                    {/* Reviews List */}
                    {reviews.length === 0 ? (
                      <div className="text-center py-10">
                        <MessageSquare className="w-10 h-10 text-white/10 mx-auto mb-2" />
                        <p className="text-white/30 text-sm">No reviews yet. Be the first!</p>
                      </div>
                    ) : (
                      <div className="space-y-3">
                        {reviews.map(r => (
                          <div key={r.id} className="bg-white/[0.02] border border-white/5 rounded-xl p-4">
                            <div className="flex items-start gap-3">
                              <Avatar className="w-8 h-8 flex-shrink-0">
                                <AvatarImage src={r.user.avatar} />
                                <AvatarFallback className="text-[10px] bg-purple-900">{r.user.username[0]?.toUpperCase()}</AvatarFallback>
                              </Avatar>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center justify-between gap-2 mb-1">
                                  <div className="flex items-center gap-2">
                                    <Link href={`/profile/${r.user.username}`} className="text-sm font-medium text-white hover:text-purple-300 transition-colors">{r.user.username}</Link>
                                    <StarRating rating={r.rating} />
                                  </div>
                                  <span className="text-[10px] text-white/30 flex-shrink-0">{timeAgo(r.createdAt)}</span>
                                </div>
                                <p className="text-sm text-white/60 leading-relaxed">{r.comment}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {!session && (
                      <div className="text-center py-6 border border-white/5 rounded-xl bg-white/[0.01]">
                        <p className="text-sm text-white/40 mb-3">Sign in to leave a review</p>
                        <Link href="/auth/signin">
                          <Button size="sm" className="bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs h-8">Sign In</Button>
                        </Link>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* RIGHT: Sidebar */}
          <div className="space-y-4">
            {/* Purchase / Download Card */}
            <div className="bg-[#0f0f1a] border border-white/8 rounded-2xl p-5 sticky top-20">
              <div className="mb-4">
                <div className="text-3xl font-bold text-white mb-0.5">
                  {isFree ? <span className="text-green-400">Free</span> : isPaid ? `$${item.price.toFixed(2)}` : <span className="text-purple-400">Membership</span>}
                </div>
                {isPaid && <p className="text-xs text-white/40">One-time purchase · Lifetime access</p>}
                {requiresRole && <p className="text-xs text-white/40">Requires membership access</p>}
              </div>

              {/* Version info */}
              {currentVersion && (
                <div className="bg-white/[0.03] border border-white/5 rounded-xl p-3 mb-4 space-y-1.5">
                  <div className="flex justify-between text-xs">
                    <span className="text-white/40">Latest Version</span>
                    <span className="text-white font-medium">v{currentVersion.version}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-white/40">File Size</span>
                    <span className="text-white font-medium">{formatFileSize(currentVersion.fileSize)}</span>
                  </div>
                  <div className="flex justify-between text-xs">
                    <span className="text-white/40">Updated</span>
                    <span className="text-white font-medium">{timeAgo(item.updatedAt)}</span>
                  </div>
                </div>
              )}

              {isFree ? (
                <Button onClick={handleDownload} disabled={downloading} className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white rounded-xl h-11 font-semibold text-sm gap-2 shadow-lg shadow-purple-500/20">
                  {downloading ? <><Loader2 className="w-4 h-4 animate-spin" />Downloading...</> : <><Download className="w-4 h-4" />Download Free</>}
                </Button>
              ) : isPaid ? (
                <div className="space-y-2">
                  <Button onClick={handleAddToCart} disabled={addingToCart} className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white rounded-xl h-11 font-semibold text-sm gap-2 shadow-lg shadow-purple-500/20">
                    {addingToCart ? <><Loader2 className="w-4 h-4 animate-spin" />Adding...</> : <><ShoppingCart className="w-4 h-4" />Add to Cart</>}
                  </Button>
                  <Button onClick={handleDownload} disabled={downloading} variant="outline" className="w-full border-white/10 hover:bg-white/5 text-white rounded-xl h-9 text-sm gap-2">
                    {downloading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Download className="w-3.5 h-3.5" />}
                    {session ? 'Download (if purchased)' : 'Sign in to Download'}
                  </Button>
                </div>
              ) : requiresRole ? (
                <Button disabled className="w-full bg-gray-600 hover:bg-gray-600 text-white rounded-xl h-11 font-semibold text-sm gap-2">
                  <Zap className="w-4 h-4" />Requires Membership
                </Button>
              ) : (
                <Button onClick={handleDownload} disabled={downloading} className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white rounded-xl h-11 font-semibold text-sm gap-2 shadow-lg shadow-purple-500/20">
                  {downloading ? <><Loader2 className="w-4 h-4 animate-spin" />Downloading...</> : <><Download className="w-4 h-4" />Download Free</>}
                </Button>
              )}

              <div className="flex items-center gap-2 mt-4 pt-4 border-t border-white/5">
                <Shield className="w-3.5 h-3.5 text-green-400" />
                <span className="text-xs text-white/40">Secure download · No malware guarantee</span>
              </div>
            </div>

            {/* Author Card */}
            <div className="bg-[#0f0f1a] border border-white/8 rounded-2xl p-5">
              <h3 className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-3">Creator</h3>
              <Link href={`/profile/${item.author.username}`} className="flex items-center gap-3 group">
                <Avatar className="w-11 h-11 border border-white/10">
                  <AvatarImage src={item.author.avatar} />
                  <AvatarFallback className="bg-gradient-to-br from-purple-900 to-blue-900 text-white text-sm">{item.author.username[0].toUpperCase()}</AvatarFallback>
                </Avatar>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-sm font-semibold text-white group-hover:text-purple-300 transition-colors">{item.author.username}</span>
                    {item.author.isVerified && <CheckCircle className="w-3.5 h-3.5 text-blue-400" />}
                  </div>
                  {item.author.sellerLevel && (
                    <span className={`text-xs font-medium ${levelColors[item.author.sellerLevel] || 'text-white/40'}`}>Level {item.author.sellerLevel} Seller</span>
                  )}
                </div>
              </Link>
              <Link href={`/profile/${item.author.username}`}>
                <Button variant="ghost" size="sm" className="w-full mt-3 h-8 text-xs text-white/50 hover:text-white hover:bg-white/5 rounded-xl gap-1.5">
                  <ExternalLink className="w-3 h-3" />View Profile
                </Button>
              </Link>
            </div>

            {/* Stats Card */}
            <div className="bg-[#0f0f1a] border border-white/8 rounded-2xl p-5">
              <h3 className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-3">Details</h3>
              <div className="space-y-2.5">
                {[
                  { icon: Download, label: 'Downloads', value: item.downloads.toLocaleString() },
                  { icon: Eye, label: 'Views', value: item.views.toLocaleString() },
                  { icon: Heart, label: 'Likes', value: item.likes.toLocaleString() },
                  { icon: MessageSquare, label: 'Reviews', value: reviews.length.toString() },
                  { icon: Calendar, label: 'Updated', value: timeAgo(item.updatedAt) },
                  { icon: Package, label: 'Category', value: item.category.name },
                ].map(({ icon: Icon, label, value }) => (
                  <div key={label} className="flex items-center justify-between text-xs">
                    <div className="flex items-center gap-1.5 text-white/40">
                      <Icon className="w-3.5 h-3.5" />{label}
                    </div>
                    <span className="text-white/80 font-medium">{value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  )
}
