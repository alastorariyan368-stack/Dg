'use client'

import { useState, useEffect, useRef } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Upload, Video, Image as ImageIcon, X, Loader2, Film, Link2, CheckCircle } from 'lucide-react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import Link from 'next/link'
import { generateAndUploadThumbnail, getVideoDuration } from '@/lib/video-thumbnail'

const CATEGORIES = ['General', 'Gaming', 'Tech', 'Tutorial', 'Entertainment', 'Music', 'Education', 'Sports', 'Other']

export default function VideoUploadPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [thumbnailPreview, setThumbnailPreview] = useState<string | null>(null)
  const [uploadingThumb, setUploadingThumb] = useState(false)
  const [uploadingVideo, setUploadingVideo] = useState(false)
  const [uploadVideoProgress, setUploadVideoProgress] = useState(0)
  const [uploadMode, setUploadMode] = useState<'url' | 'file'>('url')
  const videoInputRef = useRef<HTMLInputElement>(null)

  const [form, setForm] = useState({
    title: '',
    description: '',
    videoUrl: '',
    thumbnail: '',
    category: 'General',
    tags: '',
    duration: '',
    type: 'video',
  })

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin')
    
    // Check URL params for type
    const urlParams = new URLSearchParams(window.location.search)
    const typeParam = urlParams.get('type')
    if (typeParam === 'reel') {
      setForm(f => ({ ...f, type: 'reel' }))
    }
  }, [status])

  const handleThumbnailUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    setUploadingThumb(true)
    try {
      const fd = new FormData()
      fd.append('file', file)
      fd.append('type', 'general')
      const res = await fetch('/api/upload', { method: 'POST', body: fd })
      if (res.ok) {
        const data = await res.json()
        setForm(f => ({ ...f, thumbnail: data.url }))
        setThumbnailPreview(data.url)
        toast.success('Thumbnail uploaded!')
      } else {
        const err = await res.json()
        toast.error(err.error || 'Thumbnail upload failed')
      }
    } catch { toast.error('Error') }
    setUploadingThumb(false)
  }

  const handleVideoFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    
    // Check file type
    const allowedTypes = ['video/mp4', 'video/webm', 'video/quicktime', 'video/avi', 'video/x-msvideo', 'video/x-matroska']
    const ext = file.name.split('.').pop()?.toLowerCase()
    const allowedExts = ['mp4', 'mov', 'avi', 'webm', 'mkv', '3gp', 'm4v']
    
    if (!allowedExts.includes(ext || '')) {
      toast.error('Only MP4, MOV, AVI, WebM, MKV files supported')
      return
    }

    // Auto-detect duration
    try {
      const dur = await getVideoDuration(file)
      if (dur > 0) setForm(f => f.duration ? f : { ...f, duration: String(dur) })
    } catch {}

    // Auto-generate thumbnail from video frame (only if user hasn't provided one)
    if (!form.thumbnail) {
      try {
        setUploadingThumb(true)
        const thumbUrl = await generateAndUploadThumbnail(file)
        if (thumbUrl) {
          setForm(f => f.thumbnail ? f : { ...f, thumbnail: thumbUrl })
          setThumbnailPreview(prev => prev || thumbUrl)
        }
      } catch {} finally { setUploadingThumb(false) }
    }

    setUploadingVideo(true)
    setUploadVideoProgress(10)
    toast.info('Uploading video... please wait')

    try {
      const fd = new FormData()
      fd.append('file', file)
      fd.append('type', 'video')

      // Use XMLHttpRequest for progress tracking
      await new Promise<void>((resolve, reject) => {
        const xhr = new XMLHttpRequest()
        xhr.upload.onprogress = (e) => {
          if (e.lengthComputable) {
            setUploadVideoProgress(Math.round((e.loaded / e.total) * 90))
          }
        }
        xhr.onload = () => {
          if (xhr.status === 200) {
            const data = JSON.parse(xhr.responseText)
            setForm(f => ({ ...f, videoUrl: data.url }))
            setUploadVideoProgress(100)
            toast.success('Video uploaded successfully!')
            resolve()
          } else {
            try {
              const err = JSON.parse(xhr.responseText)
              reject(new Error(err.error || 'Upload failed'))
            } catch {
              reject(new Error('Upload failed'))
            }
          }
        }
        xhr.onerror = () => reject(new Error('Network error'))
        xhr.open('POST', '/api/upload')
        xhr.send(fd)
      })
    } catch (err: any) {
      toast.error(err.message || 'Video upload failed')
      setUploadVideoProgress(0)
    }
    setUploadingVideo(false)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.title.trim()) { toast.error('Title is required'); return }
    if (!form.videoUrl.trim()) { toast.error('Video URL or file required'); return }

    setLoading(true)
    try {
      const tags = form.tags.split(',').map(t => t.trim()).filter(Boolean)
      const res = await fetch('/api/videos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, tags, duration: form.duration ? parseInt(form.duration) : null })
      })
      if (res.ok) {
        const data = await res.json()
        toast.success(data?.message || 'Video submitted successfully!')
        setTimeout(() => router.push('/videos'), 1500)
      } else {
        const err = await res.json().catch(() => ({}))
        toast.error(err.error || 'Failed to upload video')
      }
    } catch { toast.error('Error uploading video') }
    setLoading(false)
  }

  if (status === 'loading') return null

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      <main className="container mx-auto px-4 py-6 max-w-2xl">
        <div className="mb-6">
          <h1 className="text-2xl sm:text-3xl font-bold flex items-center gap-3">
            <span className="p-2 bg-red-600 rounded-lg flex-shrink-0"><Video className="w-5 h-5 sm:w-6 sm:h-6" /></span>
            Upload Video
          </h1>
          <p className="text-white/50 mt-1 text-sm">Share your video. Will be published after admin review.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Basic Info */}
          <div className="bg-white/5 rounded-2xl p-5 border border-white/10 space-y-4">
            <h2 className="font-semibold">Video Info</h2>

            <div>
              <Label className="text-white/70 mb-1.5 block text-sm">Title <span className="text-red-400">*</span></Label>
              <Input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
                placeholder="Enter your video title" maxLength={100}
                className="bg-white/5 border-white/10 text-white placeholder:text-white/30 text-base" />
            </div>

            <div>
              <Label className="text-white/70 mb-1.5 block text-sm">Description</Label>
              <Textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                placeholder="Write details about your video..."
                className="bg-white/5 border-white/10 text-white placeholder:text-white/30 min-h-[100px] text-base" />
            </div>

            {/* Video Source Toggle */}
            <div>
              <Label className="text-white/70 mb-2 block text-sm">Video Source <span className="text-red-400">*</span></Label>
              <div className="flex rounded-xl overflow-hidden border border-white/10 mb-3">
                <button type="button" onClick={() => setUploadMode('url')}
                  className={`flex-1 py-2.5 text-sm font-medium transition-all flex items-center justify-center gap-2 ${uploadMode === 'url' ? 'bg-red-600 text-white' : 'bg-white/5 text-white/50 hover:bg-white/10'}`}>
                  <Link2 className="w-4 h-4" /> Paste URL
                </button>
                <button type="button" onClick={() => setUploadMode('file')}
                  className={`flex-1 py-2.5 text-sm font-medium transition-all flex items-center justify-center gap-2 ${uploadMode === 'file' ? 'bg-red-600 text-white' : 'bg-white/5 text-white/50 hover:bg-white/10'}`}>
                  <Film className="w-4 h-4" /> Upload File
                </button>
              </div>

              {uploadMode === 'url' ? (
                <div>
                  <Input value={form.videoUrl} onChange={e => setForm(f => ({ ...f, videoUrl: e.target.value }))}
                    onBlur={async () => {
                      const url = form.videoUrl.trim()
                      if (!url) return
                      const isDirect = /\.(mp4|webm|mov|m4v)(\?.*)?$/i.test(url)
                      if (!isDirect) return
                      try {
                        const dur = await getVideoDuration(url)
                        if (dur > 0) setForm(f => f.duration ? f : { ...f, duration: String(dur) })
                      } catch {}
                      if (form.thumbnail) return
                      try {
                        setUploadingThumb(true)
                        const t = await generateAndUploadThumbnail(url)
                        if (t) { setForm(f => f.thumbnail ? f : { ...f, thumbnail: t }); setThumbnailPreview(prev => prev || t) }
                      } catch {} finally { setUploadingThumb(false) }
                    }}
                    placeholder="https://youtube.com/watch?v=... or direct video URL"
                    className="bg-white/5 border-white/10 text-white placeholder:text-white/30 text-base" />
                  <p className="text-xs text-white/30 mt-1">Supports YouTube, MP4, WebM, MOV — thumbnail auto-detected for direct video URLs</p>
                </div>
              ) : (
                <div>
                  <input ref={videoInputRef} type="file" accept="video/*,.mp4,.mov,.avi,.webm,.mkv" className="hidden"
                    onChange={handleVideoFileUpload}  />
                  
                  {form.videoUrl && uploadMode === 'file' ? (
                    <div className="flex items-center gap-3 bg-green-500/10 border border-green-500/20 rounded-xl p-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-green-400 font-medium">Video uploaded successfully!</p>
                        <p className="text-xs text-white/40 truncate">{form.videoUrl}</p>
                      </div>
                      <button type="button" onClick={() => { setForm(f => ({ ...f, videoUrl: '' })); setUploadVideoProgress(0) }}
                        className="text-white/40 hover:text-white p-1"><X className="w-4 h-4" /></button>
                    </div>
                  ) : uploadingVideo ? (
                    <div className="bg-white/5 border border-white/10 rounded-xl p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Loader2 className="w-4 h-4 text-red-400 animate-spin" />
                        <span className="text-sm text-white/70">Uploading... {uploadVideoProgress}%</span>
                      </div>
                      <div className="w-full bg-white/10 rounded-full h-2">
                        <div className="bg-red-500 h-2 rounded-full transition-all" style={{ width: `${uploadVideoProgress}%` }} />
                      </div>
                    </div>
                  ) : (
                    <button type="button" onClick={() => videoInputRef.current?.click()}
                      className="w-full flex flex-col items-center justify-center py-8 rounded-xl border-2 border-dashed border-white/20 hover:border-red-400 hover:bg-red-500/5 transition-all">
                      <Film className="w-10 h-10 text-white/20 mb-2" />
                      <p className="text-white/50 font-medium">Choose Video File</p>
                      <p className="text-white/30 text-xs mt-1">MP4, MOV, AVI, WebM, MKV</p>
                      <p className="text-white/20 text-xs">From phone gallery or file manager</p>
                    </button>
                  )}
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-white/70 mb-1.5 block text-sm">Type</Label>
                <Select value={form.type || 'video'} onValueChange={v => setForm(f => ({ ...f, type: v }))}>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-[#1a1a2e] border-white/10 text-white">
                    <SelectItem value="video">Video</SelectItem>
                    <SelectItem value="reel">Reel</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-white/70 mb-1.5 block text-sm">Category</Label>
                <Select value={form.category} onValueChange={v => setForm(f => ({ ...f, category: v }))}>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-[#1a1a2e] border-white/10 text-white">
                    {CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label className="text-white/70 mb-1.5 block text-sm">Duration (seconds)</Label>
              <Input value={form.duration} onChange={e => setForm(f => ({ ...f, duration: e.target.value }))}
                placeholder="e.g. 360" type="number" min="0"
                className="bg-white/5 border-white/10 text-white placeholder:text-white/30 text-sm" />
            </div>

            <div>
              <Label className="text-white/70 mb-1.5 block text-sm">Tags (comma separated)</Label>
              <Input value={form.tags} onChange={e => setForm(f => ({ ...f, tags: e.target.value }))}
                placeholder="gaming, tutorial, design"
                className="bg-white/5 border-white/10 text-white placeholder:text-white/30 text-base" />
            </div>
          </div>

          {/* Thumbnail */}
          <div className="bg-white/5 rounded-2xl p-5 border border-white/10">
            <h2 className="font-semibold mb-1">Thumbnail <span className="text-white/40 text-xs font-normal">(optional)</span></h2>
            <p className="text-xs text-white/40 mb-3">Auto-generated from your video. Upload your own to override.</p>
            <label className="flex flex-col items-center justify-center w-full aspect-video rounded-xl border-2 border-dashed border-white/20 cursor-pointer hover:border-red-400 hover:bg-white/5 transition-all overflow-hidden">
              {uploadingThumb ? (
                <Loader2 className="w-8 h-8 text-white/40 animate-spin" />
              ) : thumbnailPreview ? (
                <img src={thumbnailPreview} alt="Thumbnail" className="w-full h-full object-cover" />
              ) : (
                <div className="flex flex-col items-center text-white/30 py-6">
                  <ImageIcon className="w-8 h-8 mb-2" />
                  <span className="text-sm font-medium">Upload Thumbnail</span>
                  <span className="text-xs mt-1">PNG, JPG, WebP</span>
                  <span className="text-xs text-white/20">Choose from gallery</span>
                </div>
              )}
              <input type="file" className="hidden" accept="image/*" onChange={handleThumbnailUpload} />
            </label>
            {thumbnailPreview && (
              <button type="button" onClick={() => { setThumbnailPreview(null); setForm(f => ({ ...f, thumbnail: '' })) }}
                className="mt-2 text-xs text-white/30 hover:text-white flex items-center gap-1">
                <X className="w-3 h-3" /> Remove thumbnail
              </button>
            )}
            <div className="mt-3">
              <p className="text-xs text-white/30 mb-1">Or paste URL:</p>
              <Input value={form.thumbnail} onChange={e => { setForm(f => ({ ...f, thumbnail: e.target.value })); setThumbnailPreview(e.target.value || null) }}
                placeholder="https://example.com/thumb.jpg"
                className="bg-white/5 border-white/10 text-white placeholder:text-white/20 text-sm" />
            </div>
          </div>

          {/* Submit */}
          <div className="flex flex-col sm:flex-row gap-3">
            <Button type="submit" disabled={loading || uploadingVideo} className="bg-red-600 hover:bg-red-700 flex-1 h-12 text-base">
              {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Submitting...</> : <><Upload className="w-4 h-4 mr-2" /> Submit Video</>}
            </Button>
            <Link href="/videos" className="w-full sm:w-auto">
              <Button type="button" variant="outline" className="border-white/20 hover:bg-white/10 h-12 w-full">Cancel</Button>
            </Link>
          </div>
          <p className="text-xs text-white/30 text-center">Video will be published after admin review</p>
        </form>
      </main>
      <Footer />
    </div>
  )
}
