'use client'

import { useState, useEffect } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Play, Search, Upload, Eye, Heart, Clock, TrendingUp, Video as VideoIcon, Filter } from 'lucide-react'
import Link from 'next/link'
import { useSession } from 'next-auth/react'
import { formatDistanceToNow } from 'date-fns'

interface Video {
  id: string
  title: string
  description?: string
  thumbnail?: string
  videoUrl: string
  duration?: number
  views: number
  likes: number
  category: string
  tags: any[]
  createdAt: string
  author: { id: string; username: string; avatar?: string; isVerified: boolean }
  _count: { comments: number; videoLikes: number }
}

const CATEGORIES = ['All', 'General', 'Gaming', 'Tech', 'Tutorial', 'Entertainment', 'Music', 'Education', 'Sports', 'Other']

function formatDuration(seconds?: number) {
  if (!seconds) return ''
  const m = Math.floor(seconds / 60)
  const s = seconds % 60
  return `${m}:${s.toString().padStart(2, '0')}`
}

function formatViews(views: number) {
  if (views >= 1000000) return `${(views / 1000000).toFixed(1)}M`
  if (views >= 1000) return `${(views / 1000).toFixed(1)}K`
  return views.toString()
}

export default function VideosPage() {
  const { data: session } = useSession()
  const [videos, setVideos] = useState<Video[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('All')
  const [total, setTotal] = useState(0)

  useEffect(() => {
    fetchVideos()
  }, [selectedCategory])

  const fetchVideos = async (searchQuery = '') => {
    setLoading(true)
    try {
      const params = new URLSearchParams({ limit: '24', type: 'video' })
      if (selectedCategory !== 'All') params.set('category', selectedCategory)
      if (searchQuery) params.set('search', searchQuery)
      const res = await fetch(`/api/videos?${params}`)
      if (res.ok) {
        const data = await res.json()
        setVideos(data.videos || [])
        setTotal(data.total || 0)
      }
    } catch {}
    setLoading(false)
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    fetchVideos(search)
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-3">
              <span className="p-2 bg-red-600 rounded-lg"><VideoIcon className="w-6 h-6" /></span>
              Videos
            </h1>
            <p className="text-white/60 mt-1">{total.toLocaleString()} videos available</p>
          </div>
          {session && (
            <Link href="/videos/upload">
              <Button className="bg-red-600 hover:bg-red-700 gap-2">
                <Upload className="w-4 h-4" /> Upload Video
              </Button>
            </Link>
          )}
        </div>

        {/* Search & Filter */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <form onSubmit={handleSearch} className="flex gap-2 flex-1">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
              <Input
                placeholder="Search videos..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="pl-9 bg-white/5 border-white/10 text-white placeholder:text-white/40"
              />
            </div>
            <Button type="submit" variant="outline" className="border-white/20 hover:bg-white/10">
              <Search className="w-4 h-4" />
            </Button>
          </form>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap gap-2 mb-8">
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all ${
                selectedCategory === cat
                  ? 'bg-red-600 text-white'
                  : 'bg-white/5 text-white/60 hover:bg-white/10 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Videos Grid */}
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="aspect-video bg-white/5 rounded-xl mb-3" />
                <div className="flex gap-3">
                  <div className="w-9 h-9 rounded-full bg-white/5 flex-shrink-0" />
                  <div className="flex-1 space-y-2">
                    <div className="h-4 bg-white/5 rounded w-3/4" />
                    <div className="h-3 bg-white/5 rounded w-1/2" />
                  </div>
                </div>
              </div>
            ))}
          </div>
        ) : videos.length === 0 ? (
          <div className="text-center py-20">
            <VideoIcon className="w-16 h-16 text-white/20 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white/60 mb-2">No videos found</h3>
            <p className="text-white/40 mb-6">Be the first to upload a video!</p>
            {session && (
              <Link href="/videos/upload">
                <Button className="bg-red-600 hover:bg-red-700">Upload Video</Button>
              </Link>
            )}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {videos.map(video => (
              <Link key={video.id} href={`/videos/${video.id}`} className="group block">
                <div className="rounded-xl overflow-hidden bg-white/5 border border-white/5 hover:border-white/20 transition-all">
                  {/* Thumbnail */}
                  <div className="relative aspect-video bg-black">
                    {video.thumbnail ? (
                      <img
                        src={video.thumbnail}
                        alt={video.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-gradient-to-br from-red-900/30 to-purple-900/30">
                        <Play className="w-12 h-12 text-white/30" />
                      </div>
                    )}
                    <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="bg-black/60 rounded-full p-3">
                        <Play className="w-6 h-6 text-white fill-white" />
                      </div>
                    </div>
                    {video.duration && (
                      <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-1.5 py-0.5 rounded">
                        {formatDuration(video.duration)}
                      </div>
                    )}
                  </div>
                  {/* Info */}
                  <div className="p-3">
                    <div className="flex gap-2">
                      <Avatar className="w-8 h-8 flex-shrink-0 mt-0.5">
                        <AvatarImage src={video.author.avatar} />
                        <AvatarFallback className="text-xs bg-purple-700">
                          {video.author.username[0].toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <h3 className="text-sm font-medium text-white line-clamp-2 leading-snug group-hover:text-red-400 transition-colors">
                          {video.title}
                        </h3>
                        <p className="text-xs text-white/50 mt-1">{video.author.username}</p>
                        <div className="flex items-center gap-2 text-xs text-white/40 mt-0.5">
                          <span className="flex items-center gap-1">
                            <Eye className="w-3 h-3" /> {formatViews(video.views)}
                          </span>
                          <span>•</span>
                          <span>{formatDistanceToNow(new Date(video.createdAt), { addSuffix: true })}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </main>
      <Footer />
    </div>
  )
}
