'use client'

import { useState, useEffect, useRef } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { ThumbsUp, MessageSquare, Share2, Eye, Clock, Send, AlertCircle, ChevronDown } from 'lucide-react'
import { useSession } from 'next-auth/react'
import { formatDistanceToNow } from 'date-fns'
import Link from 'next/link'
import { toast } from 'sonner'
import { useParams } from 'next/navigation'

interface VideoData {
  id: string
  title: string
  description?: string
  thumbnail?: string
  videoUrl: string
  duration?: number
  views: number
  likes: number
  category: string
  tags: any[]
  createdAt: string
  status: string
  author: { id: string; username: string; avatar?: string; isVerified: boolean; bio?: string }
  comments: Comment[]
  _count: { comments: number; videoLikes: number }
}

interface Comment {
  id: string
  content: string
  createdAt: string
  author: { id: string; username: string; avatar?: string }
}

function isYouTubeUrl(url: string) {
  return url.includes('youtube.com') || url.includes('youtu.be')
}

function getYouTubeId(url: string) {
  const match = url.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/)([^&\n?#]+)/)
  return match ? match[1] : null
}

function getYouTubeEmbed(url: string) {
  const id = getYouTubeId(url)
  return id ? `https://www.youtube.com/embed/${id}` : null
}

export default function VideoPage() {
  const params = useParams()
  const id = params.id as string
  const { data: session } = useSession()
  const [video, setVideo] = useState<VideoData | null>(null)
  const [loading, setLoading] = useState(true)
  const [userLiked, setUserLiked] = useState(false)
  const [comment, setComment] = useState('')
  const [submittingComment, setSubmittingComment] = useState(false)
  const [relatedVideos, setRelatedVideos] = useState<any[]>([])
  const [showFullDesc, setShowFullDesc] = useState(false)
  const [comments, setComments] = useState<Comment[]>([])
  const [likesCount, setLikesCount] = useState(0)

  useEffect(() => {
    if (id) {
      fetchVideo()
      fetchRelated()
    }
  }, [id])

  const fetchVideo = async () => {
    try {
      const res = await fetch(`/api/videos/${id}`)
      if (res.ok) {
        const data = await res.json()
        setVideo(data.video)
        setUserLiked(data.userLiked)
        setComments(data.video.comments || [])
        setLikesCount(data.video.likes || 0)
      }
    } catch {}
    setLoading(false)
  }

  const fetchRelated = async () => {
    try {
      const res = await fetch('/api/videos?limit=8')
      if (res.ok) {
        const data = await res.json()
        setRelatedVideos(data.videos || [])
      }
    } catch {}
  }

  const handleLike = async () => {
    if (!session) { toast.error('Sign in to like videos'); return }
    try {
      const res = await fetch(`/api/videos/${id}/like`, { method: 'POST' })
      if (res.ok) {
        const data = await res.json()
        setUserLiked(data.liked)
        setLikesCount(prev => data.liked ? prev + 1 : prev - 1)
      }
    } catch {}
  }

  const handleComment = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!session) { toast.error('Sign in to comment'); return }
    if (!comment.trim()) return
    setSubmittingComment(true)
    try {
      const res = await fetch(`/api/videos/${id}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: comment })
      })
      if (res.ok) {
        const data = await res.json()
        setComments(prev => [data.comment, ...prev])
        setComment('')
        toast.success('Comment added!')
      }
    } catch {}
    setSubmittingComment(false)
  }

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href)
    toast.success('Link copied to clipboard!')
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] text-white">
        <Navbar />
        <div className="container mx-auto px-4 py-8">
          <div className="animate-pulse">
            <div className="aspect-video bg-white/5 rounded-xl mb-4" />
            <div className="h-7 bg-white/5 rounded w-3/4 mb-2" />
            <div className="h-5 bg-white/5 rounded w-1/2" />
          </div>
        </div>
        <Footer />
      </div>
    )
  }

  if (!video) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] text-white flex items-center justify-center">
        <Navbar />
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-red-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Video not found</h2>
          <Link href="/videos"><Button variant="outline">Browse Videos</Button></Link>
        </div>
      </div>
    )
  }

  const isYT = isYouTubeUrl(video.videoUrl)
  const ytEmbed = isYT ? getYouTubeEmbed(video.videoUrl) : null

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      <main className="container mx-auto px-4 py-6">
        <div className="flex flex-col xl:flex-row gap-6">
          {/* Main content */}
          <div className="flex-1 min-w-0">
            {/* Video Player */}
            <div className="aspect-video bg-black rounded-xl overflow-hidden mb-4">
              {isYT && ytEmbed ? (
                <iframe
                  src={ytEmbed}
                  className="w-full h-full"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              ) : (
                <video
                  src={video.videoUrl}
                  controls
                  className="w-full h-full"
                  poster={video.thumbnail}
                >
                  Your browser does not support the video tag.
                </video>
              )}
            </div>

            {/* Title */}
            <h1 className="text-xl font-bold text-white mb-3">{video.title}</h1>

            {/* Stats & Actions */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-4 pb-4 border-b border-white/10">
              <div className="flex items-center gap-4 text-sm text-white/60">
                <span className="flex items-center gap-1.5"><Eye className="w-4 h-4" /> {video.views.toLocaleString()} views</span>
                <span>•</span>
                <span>{formatDistanceToNow(new Date(video.createdAt), { addSuffix: true })}</span>
                <Badge className="bg-white/10 text-white/60 hover:bg-white/10">{video.category}</Badge>
              </div>
              <div className="flex items-center gap-2">
                <Button
                  onClick={handleLike}
                  variant="outline"
                  size="sm"
                  className={`border-white/20 gap-2 ${userLiked ? 'bg-blue-600 border-blue-600 text-white' : 'hover:bg-white/10'}`}
                >
                  <ThumbsUp className={`w-4 h-4 ${userLiked ? 'fill-white' : ''}`} />
                  {likesCount.toLocaleString()}
                </Button>
                <Button onClick={handleShare} variant="outline" size="sm" className="border-white/20 hover:bg-white/10 gap-2">
                  <Share2 className="w-4 h-4" /> Share
                </Button>
              </div>
            </div>

            {/* Author info */}
            <div className="flex items-start gap-3 mb-4">
              <Link href={`/profile/${video.author.username}`}>
                <Avatar className="w-10 h-10">
                  <AvatarImage src={video.author.avatar} />
                  <AvatarFallback className="bg-purple-700">{video.author.username[0].toUpperCase()}</AvatarFallback>
                </Avatar>
              </Link>
              <div>
                <Link href={`/profile/${video.author.username}`} className="font-medium hover:text-purple-400 flex items-center gap-1">
                  {video.author.username}
                  {video.author.isVerified && <Badge className="bg-blue-600 text-xs px-1 py-0">✓</Badge>}
                </Link>
                {video.author.bio && <p className="text-sm text-white/50 mt-0.5">{video.author.bio}</p>}
              </div>
            </div>

            {/* Description */}
            {video.description && (
              <div className="bg-white/5 rounded-xl p-4 mb-6">
                <p className={`text-white/70 text-sm whitespace-pre-wrap ${!showFullDesc && 'line-clamp-3'}`}>
                  {video.description}
                </p>
                {video.description.length > 200 && (
                  <button
                    onClick={() => setShowFullDesc(!showFullDesc)}
                    className="text-white/40 text-sm mt-2 hover:text-white flex items-center gap-1"
                  >
                    {showFullDesc ? 'Show less' : 'Show more'}
                    <ChevronDown className={`w-4 h-4 transition-transform ${showFullDesc ? 'rotate-180' : ''}`} />
                  </button>
                )}
                {video.tags && Array.isArray(video.tags) && video.tags.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mt-3">
                    {(video.tags as string[]).map(tag => (
                      <span key={tag} className="text-blue-400 text-sm hover:underline cursor-pointer">#{tag}</span>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Comments */}
            <div>
              <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
                <MessageSquare className="w-5 h-5" />
                {comments.length} Comments
              </h3>

              {/* Add comment */}
              {session ? (
                <form onSubmit={handleComment} className="flex gap-3 mb-6">
                  <Avatar className="w-8 h-8 flex-shrink-0">
                    <AvatarImage src={session.user?.image || undefined} />
                    <AvatarFallback className="bg-purple-700 text-sm">
                      {(session.user?.name || 'U')[0].toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex-1 flex gap-2">
                    <Input
                      value={comment}
                      onChange={e => setComment(e.target.value)}
                      placeholder="Add a comment..."
                      className="bg-white/5 border-white/10 text-white placeholder:text-white/40"
                    />
                    <Button type="submit" disabled={submittingComment || !comment.trim()} size="sm" className="bg-blue-600 hover:bg-blue-700">
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </form>
              ) : (
                <div className="bg-white/5 rounded-lg p-3 text-center text-white/50 text-sm mb-6">
                  <Link href="/auth/signin" className="text-blue-400 hover:underline">Sign in</Link> to comment
                </div>
              )}

              <div className="space-y-4">
                {comments.map(c => (
                  <div key={c.id} className="flex gap-3">
                    <Avatar className="w-8 h-8 flex-shrink-0">
                      <AvatarImage src={c.author.avatar} />
                      <AvatarFallback className="bg-purple-700 text-xs">{c.author.username[0].toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="flex items-center gap-2">
                        <Link href={`/profile/${c.author.username}`} className="text-sm font-medium hover:text-purple-400">
                          {c.author.username}
                        </Link>
                        <span className="text-xs text-white/40">
                          {formatDistanceToNow(new Date(c.createdAt), { addSuffix: true })}
                        </span>
                      </div>
                      <p className="text-sm text-white/70 mt-0.5">{c.content}</p>
                    </div>
                  </div>
                ))}
                {comments.length === 0 && (
                  <p className="text-white/40 text-sm text-center py-4">No comments yet. Be the first!</p>
                )}
              </div>
            </div>
          </div>

          {/* Sidebar - Related Videos */}
          <div className="xl:w-80 flex-shrink-0">
            <h3 className="font-semibold mb-4">More Videos</h3>
            <div className="space-y-3">
              {relatedVideos.filter(v => v.id !== id).slice(0, 7).map(rv => (
                <Link key={rv.id} href={`/videos/${rv.id}`} className="flex gap-3 group">
                  <div className="relative w-32 aspect-video rounded-lg overflow-hidden bg-black flex-shrink-0">
                    {rv.thumbnail ? (
                      <img src={rv.thumbnail} alt={rv.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-purple-900/30">
                        <Clock className="w-4 h-4 text-white/30" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium line-clamp-2 group-hover:text-red-400 transition-colors">{rv.title}</p>
                    <p className="text-xs text-white/50 mt-1">{rv.author.username}</p>
                    <p className="text-xs text-white/40">{rv.views.toLocaleString()} views</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
