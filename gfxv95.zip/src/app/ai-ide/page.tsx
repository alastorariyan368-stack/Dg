'use client'

import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Code2, Zap, Terminal, Globe, Sparkles, GitBranch,
  Play, ExternalLink, FileCode, Layers, Shield, Cpu,
  Download, Upload, RefreshCw, AlertCircle
} from 'lucide-react'
import Link from 'next/link'

const FEATURES = [
  { icon: Sparkles, title: 'Multi-Provider AI', desc: 'Supports OpenAI, Gemini, Anthropic, Deepseek, Mistral, Groq, xAI, and more', color: 'violet' },
  { icon: FileCode, title: 'Live Code Saving', desc: 'All code is auto-saved to disk in real-time as you generate it', color: 'emerald' },
  { icon: Terminal, title: 'Built-in Terminal', desc: 'Full WebSocket-powered terminal — run commands, install packages, preview live', color: 'cyan' },
  { icon: Globe, title: 'Live Preview', desc: 'Instant browser preview of your running app right inside the IDE', color: 'blue' },
  { icon: Layers, title: 'Multi-Agent Build', desc: 'Parallel AI agents collaborate to build complex apps faster', color: 'fuchsia' },
  { icon: GitBranch, title: 'Project Management', desc: 'Organize projects, manage files, fork and share with the community', color: 'amber' },
  { icon: Cpu, title: 'AI Chat Assistant', desc: 'Ask questions, get code explanations, debug issues — all in context', color: 'rose' },
  { icon: Shield, title: 'Secure & Private', desc: 'Your code and API keys are encrypted. Projects are private by default', color: 'slate' },
]

const COLOR_MAP: Record<string, string> = {
  violet: 'bg-violet-500/10 border-violet-500/20 text-violet-400',
  emerald: 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400',
  cyan: 'bg-cyan-500/10 border-cyan-500/20 text-cyan-400',
  blue: 'bg-blue-500/10 border-blue-500/20 text-blue-400',
  fuchsia: 'bg-fuchsia-500/10 border-fuchsia-500/20 text-fuchsia-400',
  amber: 'bg-amber-500/10 border-amber-500/20 text-amber-400',
  rose: 'bg-rose-500/10 border-rose-500/20 text-rose-400',
  slate: 'bg-slate-500/10 border-slate-500/20 text-slate-400',
}

export default function AiIdePage() {
  const { data: session } = useSession()
  const router = useRouter()
  const [ideUrl, setIdeUrl] = useState<string | null>(null)
  const [checking, setChecking] = useState(true)
  const [online, setOnline] = useState(false)

  useEffect(() => {
    // Compute the codeai URL from the current hostname
    // Replit pattern: <id>-00-<slug>.<region>.replit.dev → port 8080: <id>-00-8080-<slug>.<region>.replit.dev
    const hostname = window.location.hostname
    let codeaiHost = hostname

    // Handle Replit dev domain: insert port between -00- and the rest
    if (hostname.includes('-00-') && hostname.includes('.replit.dev')) {
      codeaiHost = hostname.replace('-00-', '-00-8080-')
    } else if (hostname.includes('.picard.replit.dev') || hostname.includes('.sisko.replit.dev') || hostname.includes('.janeway.replit.dev')) {
      // Already handled by the -00- replacement above
      codeaiHost = hostname.replace('-00-', '-00-8080-')
    } else {
      // Local dev fallback
      codeaiHost = `${window.location.hostname}:8080`
    }

    const url = `https://${codeaiHost}`
    setIdeUrl(url)

    // Check if codeai is online
    const check = async () => {
      setChecking(true)
      try {
        const r = await fetch(url, { mode: 'no-cors', signal: AbortSignal.timeout(5000) })
        setOnline(true)
      } catch {
        setOnline(false)
      }
      setChecking(false)
    }
    check()
  }, [])

  const openIde = () => {
    if (ideUrl) window.open(ideUrl, '_blank', 'noopener')
  }

  return (
    <div className="min-h-screen bg-[#0a0a12] text-white">
      <Navbar />

      {/* Hero */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-violet-900/20 via-transparent to-cyan-900/10" />
        <div className="absolute top-20 left-1/4 w-96 h-96 bg-violet-600/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 right-1/4 w-64 h-64 bg-cyan-600/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative container mx-auto px-4 py-20 text-center">
          <Badge className="mb-6 bg-emerald-500/10 text-emerald-400 border-emerald-500/20 hover:bg-emerald-500/15">
            <Zap className="w-3 h-3 mr-1" /> Powered by Multi-Provider AI
          </Badge>
          <h1 className="text-5xl md:text-6xl font-black bg-gradient-to-r from-violet-400 via-cyan-400 to-emerald-400 bg-clip-text text-transparent mb-6">
            GfxCode AI IDE
          </h1>
          <p className="text-xl text-white/60 max-w-2xl mx-auto mb-10 leading-relaxed">
            A professional AI-powered code editor built into GfxStore. Generate complete full-stack apps, debug code, run commands, and preview live — all in your browser.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button
              onClick={openIde}
              disabled={checking}
              size="lg"
              className="bg-gradient-to-r from-violet-600 to-cyan-600 hover:from-violet-500 hover:to-cyan-500 text-white font-bold px-8 py-4 text-lg shadow-lg shadow-violet-500/20 min-w-[200px]"
            >
              {checking ? (
                <><RefreshCw className="w-5 h-5 mr-2 animate-spin" /> Checking...</>
              ) : (
                <><Play className="w-5 h-5 mr-2" /> Open AI IDE</>
              )}
            </Button>
            <div className="flex items-center gap-2 text-sm">
              {checking ? (
                <span className="text-white/40">Checking status...</span>
              ) : online ? (
                <>
                  <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                  <span className="text-emerald-400">Online & Ready</span>
                </>
              ) : (
                <>
                  <div className="w-2 h-2 rounded-full bg-amber-400" />
                  <span className="text-amber-400">Starting up...</span>
                </>
              )}
            </div>
          </div>

          {!online && !checking && (
            <div className="mt-6 flex items-center gap-2 justify-center text-sm text-amber-400/80 bg-amber-500/5 border border-amber-500/20 rounded-xl px-6 py-3 max-w-lg mx-auto">
              <AlertCircle className="w-4 h-4 flex-shrink-0" />
              <span>The IDE may still be starting up. Click "Open AI IDE" to try, or wait a moment and refresh.</span>
            </div>
          )}
        </div>
      </div>

      {/* Features Grid */}
      <div className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold text-center mb-3">Everything You Need to Build</h2>
        <p className="text-white/50 text-center mb-12">Professional-grade tools powered by the latest AI models</p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {FEATURES.map(({ icon: Icon, title, desc, color }) => (
            <div key={title} className={`relative p-5 rounded-2xl border bg-white/[0.02] ${COLOR_MAP[color].split(' ').slice(1).join(' ')} hover:bg-white/[0.04] transition-all group`}>
              <div className={`inline-flex p-2.5 rounded-xl mb-4 ${COLOR_MAP[color]}`}>
                <Icon className="w-5 h-5" />
              </div>
              <h3 className="font-semibold text-white mb-2">{title}</h3>
              <p className="text-sm text-white/50 leading-relaxed">{desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Supported AI Providers */}
      <div className="container mx-auto px-4 py-12">
        <div className="bg-white/[0.02] border border-white/[0.06] rounded-3xl p-8 text-center">
          <h3 className="text-xl font-bold mb-2">Supported AI Providers</h3>
          <p className="text-white/50 text-sm mb-8">Connect your own API keys or use built-in free providers</p>
          <div className="flex flex-wrap gap-3 justify-center">
            {['OpenAI (GPT-4o)', 'Google Gemini', 'Anthropic Claude', 'Deepseek', 'Mistral', 'xAI Grok', 'Groq (Free)', 'Together AI', 'Cohere', 'Ollama (Local)'].map(p => (
              <span key={p} className="px-4 py-2 rounded-full bg-white/[0.04] border border-white/[0.08] text-white/70 text-sm font-medium">
                {p}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* CTA */}
      <div className="container mx-auto px-4 py-16 text-center">
        <div className="max-w-2xl mx-auto">
          <Code2 className="w-12 h-12 text-violet-400 mx-auto mb-6" />
          <h2 className="text-3xl font-bold mb-4">Ready to Build Something Amazing?</h2>
          <p className="text-white/50 mb-8">The AI IDE runs alongside GfxStore. Click below to launch it in a new tab and start coding with AI.</p>
          <Button
            onClick={openIde}
            size="lg"
            className="bg-gradient-to-r from-violet-600 to-emerald-600 hover:from-violet-500 hover:to-emerald-500 text-white font-bold px-10"
          >
            <ExternalLink className="w-5 h-5 mr-2" /> Launch GfxCode IDE
          </Button>
        </div>
      </div>
    </div>
  )
}
