'use client'

import { useState, useEffect } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Textarea } from '@/components/ui/textarea'
import { Download, Star, StarIcon, Share2, Shield, Smartphone, Package, AlertCircle, ChevronLeft, ChevronRight, Send, Loader2 } from 'lucide-react'
import { useSession } from 'next-auth/react'
import { formatDistanceToNow } from 'date-fns'
import Link from 'next/link'
import { toast } from 'sonner'
import { useParams } from 'next/navigation'

interface AppData {
  id: string
  title: string
  description?: string
  shortDesc?: string
  packageName: string
  version: string
  icon?: string
  coverImage?: string
  screenshots: any[]
  apkUrl?: string
  category: string
  tags: any[]
  downloads: number
  rating: number
  status: string
  platform: string
  size?: string
  minSdk?: string
  permissions: any[]
  changelog?: string
  createdAt: string
  author: { id: string; username: string; avatar?: string; isVerified: boolean; bio?: string }
  appReviews: Review[]
  _count: { appReviews: number }
}

interface Review {
  id: string
  content?: string
  rating: number
  createdAt: string
  author: { id: string; username: string; avatar?: string }
}

function StarRating({ rating, interactive = false, onRate }: { rating: number; interactive?: boolean; onRate?: (r: number) => void }) {
  const [hover, setHover] = useState(0)
  return (
    <div className="flex items-center gap-0.5">
      {[1,2,3,4,5].map(i => (
        <StarIcon
          key={i}
          className={`w-5 h-5 transition-colors ${interactive ? 'cursor-pointer' : ''} ${
            i <= (hover || rating) ? 'fill-yellow-400 text-yellow-400' : 'text-white/20'
          }`}
          onMouseEnter={() => interactive && setHover(i)}
          onMouseLeave={() => interactive && setHover(0)}
          onClick={() => interactive && onRate?.(i)}
        />
      ))}
    </div>
  )
}

export default function AppDetailPage() {
  const params = useParams()
  const id = params.id as string
  const { data: session } = useSession()
  const [app, setApp] = useState<AppData | null>(null)
  const [loading, setLoading] = useState(true)
  const [activeScreenshot, setActiveScreenshot] = useState(0)
  const [userRating, setUserRating] = useState(0)
  const [reviewContent, setReviewContent] = useState('')
  const [submittingReview, setSubmittingReview] = useState(false)
  const [reviews, setReviews] = useState<Review[]>([])

  useEffect(() => {
    if (id) fetchApp()
  }, [id])

  const fetchApp = async () => {
    try {
      const res = await fetch(`/api/apps/${id}`)
      if (res.ok) {
        const data = await res.json()
        setApp(data.app)
        setReviews(data.app.appReviews || [])
      }
    } catch {}
    setLoading(false)
  }

  const handleReview = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!session) { toast.error('Sign in to review'); return }
    if (!userRating) { toast.error('Please select a rating'); return }
    setSubmittingReview(true)
    try {
      const res = await fetch(`/api/apps/${id}/review`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rating: userRating, content: reviewContent })
      })
      if (res.ok) {
        const data = await res.json()
        toast.success('Review submitted!')
        setReviews(prev => [data.review, ...prev.filter(r => r.author.id !== session.user?.id)])
        setReviewContent('')
      } else {
        toast.error('Failed to submit review')
      }
    } catch {}
    setSubmittingReview(false)
  }

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href)
    toast.success('Link copied!')
  }

  const handleDownload = () => {
    if (app?.apkUrl) {
      window.open(app.apkUrl, '_blank')
    } else {
      toast.info('APK download link not available')
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] text-white">
        <Navbar />
        <div className="container mx-auto px-4 py-8 animate-pulse">
          <div className="flex gap-6 mb-8">
            <div className="w-24 h-24 rounded-2xl bg-white/5" />
            <div className="flex-1"><div className="h-8 bg-white/5 rounded w-1/2 mb-3" /><div className="h-4 bg-white/5 rounded w-1/3" /></div>
          </div>
        </div>
        <Footer />
      </div>
    )
  }

  if (!app) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] text-white flex items-center justify-center">
        <Navbar />
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-red-400 mx-auto mb-4" />
          <h2 className="text-2xl font-bold">App not found</h2>
          <Link href="/apps"><Button className="mt-4" variant="outline">Browse Apps</Button></Link>
        </div>
      </div>
    )
  }

  const screenshots = Array.isArray(app.screenshots) ? app.screenshots as string[] : []

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        {/* App Header */}
        <div className="flex flex-col sm:flex-row gap-6 mb-8">
          <div className="w-24 h-24 rounded-2xl overflow-hidden flex-shrink-0 bg-gradient-to-br from-green-500/20 to-blue-500/20 flex items-center justify-center">
            {app.icon ? (
              <img src={app.icon} alt={app.title} className="w-full h-full object-cover" />
            ) : (
              <Smartphone className="w-12 h-12 text-green-400" />
            )}
          </div>
          <div className="flex-1">
            <div className="flex flex-wrap items-start gap-3 mb-2">
              <h1 className="text-3xl font-bold">{app.title}</h1>
              <Badge className="bg-green-600/20 text-green-400 border-green-500/30">{app.platform}</Badge>
            </div>
            <Link href={`/profile/${app.author.username}`} className="text-white/60 hover:text-green-400 flex items-center gap-1 mb-2">
              <Avatar className="w-5 h-5"><AvatarImage src={app.author.avatar} /><AvatarFallback className="text-xs bg-green-700">{app.author.username[0].toUpperCase()}</AvatarFallback></Avatar>
              {app.author.username}
              {app.author.isVerified && <Badge className="bg-blue-600 text-xs px-1">✓</Badge>}
            </Link>
            <div className="flex flex-wrap items-center gap-4 text-sm text-white/60">
              {app.rating > 0 && (
                <span className="flex items-center gap-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  {app.rating.toFixed(1)} ({app._count.appReviews} reviews)
                </span>
              )}
              <span className="flex items-center gap-1"><Download className="w-4 h-4" /> {app.downloads.toLocaleString()} downloads</span>
              <span>v{app.version}</span>
              <span>{app.category}</span>
            </div>
            <div className="flex flex-wrap gap-2 mt-4">
              <Button onClick={handleDownload} className="bg-green-600 hover:bg-green-700 gap-2">
                <Download className="w-4 h-4" /> Download
              </Button>
              <Button onClick={handleShare} variant="outline" className="border-white/20 hover:bg-white/10 gap-2">
                <Share2 className="w-4 h-4" /> Share
              </Button>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
          <div className="xl:col-span-2 space-y-8">
            {/* Screenshots */}
            {screenshots.length > 0 && (
              <div>
                <h2 className="text-lg font-semibold mb-4">Screenshots</h2>
                <div className="relative">
                  <div className="overflow-hidden rounded-xl">
                    <img src={screenshots[activeScreenshot]} alt={`Screenshot ${activeScreenshot + 1}`} className="w-full max-h-80 object-contain bg-black rounded-xl" />
                  </div>
                  {screenshots.length > 1 && (
                    <div className="flex gap-2 mt-3 overflow-x-auto pb-1">
                      {screenshots.map((s, i) => (
                        <button key={i} onClick={() => setActiveScreenshot(i)}
                          className={`flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden border-2 transition-all ${i === activeScreenshot ? 'border-green-500' : 'border-white/10 opacity-60 hover:opacity-100'}`}>
                          <img src={s} alt={`Thumb ${i+1}`} className="w-full h-full object-cover" />
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Description */}
            {app.description && (
              <div>
                <h2 className="text-lg font-semibold mb-3">About This App</h2>
                <p className="text-white/70 leading-relaxed whitespace-pre-wrap">{app.description}</p>
              </div>
            )}

            {/* Changelog */}
            {app.changelog && (
              <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                <h3 className="font-semibold mb-2 flex items-center gap-2"><Package className="w-4 h-4" /> What's New (v{app.version})</h3>
                <p className="text-white/60 text-sm whitespace-pre-wrap">{app.changelog}</p>
              </div>
            )}

            {/* Reviews */}
            <div>
              <h2 className="text-lg font-semibold mb-4">Reviews & Ratings</h2>

              {/* Rating summary */}
              {app._count.appReviews > 0 && (
                <div className="flex items-center gap-6 mb-6 bg-white/5 rounded-xl p-4">
                  <div className="text-center">
                    <div className="text-4xl font-bold">{app.rating.toFixed(1)}</div>
                    <StarRating rating={app.rating} />
                    <div className="text-xs text-white/40 mt-1">{app._count.appReviews} reviews</div>
                  </div>
                </div>
              )}

              {/* Write review */}
              {session && (
                <form onSubmit={handleReview} className="bg-white/5 rounded-xl p-4 mb-6 border border-white/10">
                  <h3 className="font-medium mb-3">Write a Review</h3>
                  <div className="mb-3">
                    <p className="text-sm text-white/60 mb-2">Your rating</p>
                    <StarRating rating={userRating} interactive onRate={setUserRating} />
                  </div>
                  <Textarea
                    value={reviewContent}
                    onChange={e => setReviewContent(e.target.value)}
                    placeholder="Share your experience with this app..."
                    className="bg-white/5 border-white/10 text-white placeholder:text-white/30 mb-3"
                  />
                  <Button type="submit" disabled={submittingReview || !userRating} size="sm" className="bg-green-600 hover:bg-green-700">
                    {submittingReview ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Send className="w-4 h-4 mr-2" />}
                    Submit Review
                  </Button>
                </form>
              )}

              {/* Reviews list */}
              <div className="space-y-4">
                {reviews.map(r => (
                  <div key={r.id} className="bg-white/5 rounded-xl p-4 border border-white/5">
                    <div className="flex items-start gap-3">
                      <Avatar className="w-9 h-9"><AvatarImage src={r.author.avatar} /><AvatarFallback className="bg-green-700 text-sm">{r.author.username[0].toUpperCase()}</AvatarFallback></Avatar>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-sm">{r.author.username}</span>
                          <StarRating rating={r.rating} />
                          <span className="text-xs text-white/40">{formatDistanceToNow(new Date(r.createdAt), { addSuffix: true })}</span>
                        </div>
                        {r.content && <p className="text-white/70 text-sm">{r.content}</p>}
                      </div>
                    </div>
                  </div>
                ))}
                {reviews.length === 0 && <p className="text-white/40 text-sm text-center py-4">No reviews yet. Be the first to review!</p>}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            <div className="bg-white/5 rounded-xl p-4 border border-white/10">
              <h3 className="font-semibold mb-3">App Info</h3>
              <dl className="space-y-2 text-sm">
                <div className="flex justify-between"><dt className="text-white/50">Package</dt><dd className="text-white/80 font-mono text-xs">{app.packageName}</dd></div>
                <div className="flex justify-between"><dt className="text-white/50">Version</dt><dd className="text-white/80">{app.version}</dd></div>
                <div className="flex justify-between"><dt className="text-white/50">Platform</dt><dd className="text-white/80">{app.platform}</dd></div>
                {app.size && <div className="flex justify-between"><dt className="text-white/50">Size</dt><dd className="text-white/80">{app.size}</dd></div>}
                {app.minSdk && <div className="flex justify-between"><dt className="text-white/50">Requires</dt><dd className="text-white/80">{app.minSdk}</dd></div>}
                <div className="flex justify-between"><dt className="text-white/50">Downloads</dt><dd className="text-white/80">{app.downloads.toLocaleString()}</dd></div>
                <div className="flex justify-between"><dt className="text-white/50">Released</dt><dd className="text-white/80">{formatDistanceToNow(new Date(app.createdAt), { addSuffix: true })}</dd></div>
              </dl>
            </div>

            {Array.isArray(app.permissions) && (app.permissions as string[]).length > 0 && (
              <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                <h3 className="font-semibold mb-3 flex items-center gap-2"><Shield className="w-4 h-4 text-yellow-400" /> Permissions</h3>
                <ul className="space-y-1">
                  {(app.permissions as string[]).map((p, i) => (
                    <li key={i} className="text-sm text-white/60 flex items-center gap-2">
                      <div className="w-1.5 h-1.5 rounded-full bg-yellow-400/50 flex-shrink-0" />
                      {p}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {app.tags && Array.isArray(app.tags) && (app.tags as string[]).length > 0 && (
              <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                <h3 className="font-semibold mb-3">Tags</h3>
                <div className="flex flex-wrap gap-1.5">
                  {(app.tags as string[]).map(tag => (
                    <Badge key={tag} className="bg-white/10 text-white/60 hover:bg-white/15">{tag}</Badge>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
