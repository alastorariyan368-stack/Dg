'use client'

import { useState, useEffect } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Smartphone, Search, Upload, Download, Star, Filter, ChevronDown } from 'lucide-react'
import Link from 'next/link'
import { useSession } from 'next-auth/react'

interface App {
  id: string
  title: string
  description?: string
  shortDesc?: string
  icon?: string
  category: string
  platform: string
  downloads: number
  rating: number
  version: string
  tags: any[]
  createdAt: string
  author: { id: string; username: string; avatar?: string; isVerified: boolean }
  _count: { appReviews: number }
}

const CATEGORIES = ['All', 'General', 'Games', 'Tools', 'Social', 'Education', 'Entertainment', 'Productivity', 'Finance', 'Health', 'Other']
const PLATFORMS = ['All', 'Android', 'iOS', 'Cross-Platform']

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1,2,3,4,5].map(i => (
        <Star key={i} className={`w-3 h-3 ${i <= Math.round(rating) ? 'fill-yellow-400 text-yellow-400' : 'text-white/20'}`} />
      ))}
    </div>
  )
}

export default function AppsPage() {
  const { data: session } = useSession()
  const [apps, setApps] = useState<App[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('All')
  const [selectedPlatform, setSelectedPlatform] = useState('All')
  const [total, setTotal] = useState(0)

  useEffect(() => {
    fetchApps()
  }, [selectedCategory, selectedPlatform])

  const fetchApps = async (searchQuery = '') => {
    setLoading(true)
    try {
      const params = new URLSearchParams({ limit: '24' })
      if (selectedCategory !== 'All') params.set('category', selectedCategory)
      if (selectedPlatform !== 'All') params.set('platform', selectedPlatform)
      if (searchQuery) params.set('search', searchQuery)
      const res = await fetch(`/api/apps?${params}`)
      if (res.ok) {
        const data = await res.json()
        setApps(data.apps || [])
        setTotal(data.total || 0)
      }
    } catch {}
    setLoading(false)
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    fetchApps(search)
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-3">
              <span className="p-2 bg-green-600 rounded-lg"><Smartphone className="w-6 h-6" /></span>
              App Store
            </h1>
            <p className="text-white/60 mt-1">{total.toLocaleString()} apps available</p>
          </div>
          {session && (
            <Link href="/apps/upload">
              <Button className="bg-green-600 hover:bg-green-700 gap-2">
                <Upload className="w-4 h-4" /> Submit App
              </Button>
            </Link>
          )}
        </div>

        {/* Hero Banner */}
        <div className="bg-gradient-to-r from-green-900/30 via-blue-900/20 to-purple-900/30 rounded-2xl p-6 mb-8 border border-green-500/20">
          <p className="text-sm text-green-400 font-medium mb-1">Open Platform</p>
          <h2 className="text-2xl font-bold mb-2">Discover & Download Apps</h2>
          <p className="text-white/60 text-sm">Upload your apps, get downloads, reviews, and feedback from our community. All apps are reviewed before publishing.</p>
        </div>

        {/* Search & Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <form onSubmit={handleSearch} className="flex gap-2 flex-1">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
              <Input
                placeholder="Search apps..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="pl-9 bg-white/5 border-white/10 text-white placeholder:text-white/40"
              />
            </div>
            <Button type="submit" variant="outline" className="border-white/20 hover:bg-white/10">Search</Button>
          </form>
        </div>

        {/* Category Filter */}
        <div className="flex flex-wrap gap-2 mb-4">
          {CATEGORIES.map(cat => (
            <button key={cat} onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all ${selectedCategory === cat ? 'bg-green-600 text-white' : 'bg-white/5 text-white/60 hover:bg-white/10 hover:text-white'}`}>
              {cat}
            </button>
          ))}
        </div>

        {/* Platform Filter */}
        <div className="flex flex-wrap gap-2 mb-8">
          {PLATFORMS.map(p => (
            <button key={p} onClick={() => setSelectedPlatform(p)}
              className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all border ${selectedPlatform === p ? 'border-green-500 bg-green-600/20 text-green-400' : 'border-white/10 text-white/40 hover:border-white/30 hover:text-white/70'}`}>
              {p}
            </button>
          ))}
        </div>

        {/* Apps Grid */}
        {loading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
            {Array.from({ length: 12 }).map((_, i) => (
              <div key={i} className="animate-pulse bg-white/5 rounded-xl p-4">
                <div className="w-16 h-16 rounded-2xl bg-white/10 mx-auto mb-3" />
                <div className="h-3 bg-white/10 rounded mb-2" />
                <div className="h-2 bg-white/10 rounded w-2/3 mx-auto" />
              </div>
            ))}
          </div>
        ) : apps.length === 0 ? (
          <div className="text-center py-20">
            <Smartphone className="w-16 h-16 text-white/20 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white/60 mb-2">No apps found</h3>
            <p className="text-white/40 mb-6">Be the first to submit an app!</p>
            {session && <Link href="/apps/upload"><Button className="bg-green-600 hover:bg-green-700">Submit App</Button></Link>}
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
            {apps.map(app => (
              <Link key={app.id} href={`/apps/${app.id}`} className="group block">
                <div className="bg-white/5 rounded-2xl p-4 border border-white/5 hover:border-green-500/30 hover:bg-white/10 transition-all text-center">
                  {/* Icon */}
                  <div className="w-16 h-16 rounded-2xl overflow-hidden mx-auto mb-3 bg-gradient-to-br from-green-500/20 to-blue-500/20 flex items-center justify-center">
                    {app.icon ? (
                      <img src={app.icon} alt={app.title} className="w-full h-full object-cover" />
                    ) : (
                      <Smartphone className="w-8 h-8 text-green-400" />
                    )}
                  </div>
                  <h3 className="text-sm font-medium text-white line-clamp-1 mb-1 group-hover:text-green-400 transition-colors">{app.title}</h3>
                  <p className="text-xs text-white/40 line-clamp-1 mb-2">{app.author.username}</p>
                  {app.rating > 0 && (
                    <div className="flex items-center justify-center gap-1 mb-2">
                      <StarRating rating={app.rating} />
                      <span className="text-xs text-white/40">{app.rating.toFixed(1)}</span>
                    </div>
                  )}
                  <div className="flex items-center justify-center gap-1 text-xs text-white/40">
                    <Download className="w-3 h-3" />
                    <span>{app.downloads.toLocaleString()}</span>
                  </div>
                  <Badge className="mt-2 text-xs bg-white/5 text-white/40 hover:bg-white/5">{app.platform}</Badge>
                </div>
              </Link>
            ))}
          </div>
        )}
      </main>
      <Footer />
    </div>
  )
}
