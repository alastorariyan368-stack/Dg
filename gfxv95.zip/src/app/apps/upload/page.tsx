'use client'

import { useState, useEffect, useRef } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Smartphone, Upload, X, Image as ImageIcon, Plus, Loader2, Package, Link, CheckCircle } from 'lucide-react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import NextLink from 'next/link'

const CATEGORIES = ['General', 'Games', 'Tools', 'Social', 'Education', 'Entertainment', 'Productivity', 'Finance', 'Health', 'Other']

export default function AppUploadPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [iconPreview, setIconPreview] = useState<string | null>(null)
  const [coverPreview, setCoverPreview] = useState<string | null>(null)
  const [screenshotPreviews, setScreenshotPreviews] = useState<string[]>([])
  const [uploadingIcon, setUploadingIcon] = useState(false)
  const [uploadingCover, setUploadingCover] = useState(false)
  const [uploadingScreenshot, setUploadingScreenshot] = useState(false)
  const [uploadingApk, setUploadingApk] = useState(false)
  const [apkProgress, setApkProgress] = useState(0)
  const [apkMode, setApkMode] = useState<'url' | 'file'>('url')
  const [permissionInput, setPermissionInput] = useState('')
  const apkInputRef = useRef<HTMLInputElement>(null)

  const [form, setForm] = useState({
    title: '', description: '', shortDesc: '',
    packageName: '', version: '1.0.0',
    icon: '', coverImage: '', screenshots: [] as string[],
    apkUrl: '', category: 'General', tags: '',
    platform: 'Android', size: '', minSdk: '',
    permissions: [] as string[], changelog: '',
  })

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin')
  }, [status])

  const handleUploadImg = async (file: File, type: string): Promise<string | null> => {
    try {
      const fd = new FormData()
      fd.append('file', file)
      fd.append('type', 'general')
      const res = await fetch('/api/upload', { method: 'POST', body: fd })
      if (res.ok) { const d = await res.json(); return d.url }
      toast.error(`${type} upload failed`)
    } catch { toast.error(`${type} upload error`) }
    return null
  }

  const handleIconUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return
    setUploadingIcon(true)
    const url = await handleUploadImg(file, 'Icon')
    if (url) { setForm(f => ({ ...f, icon: url })); setIconPreview(url); toast.success('Icon uploaded!') }
    setUploadingIcon(false)
  }

  const handleCoverUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return
    setUploadingCover(true)
    const url = await handleUploadImg(file, 'Cover')
    if (url) { setForm(f => ({ ...f, coverImage: url })); setCoverPreview(url); toast.success('Cover uploaded!') }
    setUploadingCover(false)
  }

  const handleScreenshotUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []); if (!files.length) return
    setUploadingScreenshot(true)
    for (const file of files.slice(0, 8 - form.screenshots.length)) {
      const url = await handleUploadImg(file, 'Screenshot')
      if (url) { setForm(f => ({ ...f, screenshots: [...f.screenshots, url] })); setScreenshotPreviews(p => [...p, url]) }
    }
    setUploadingScreenshot(false)
  }

  const handleApkFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]; if (!file) return
    const ext = file.name.split('.').pop()?.toLowerCase() || ''
    if (!['apk', 'aab', 'xapk', 'zip'].includes(ext)) {
      toast.error('Only APK, AAB, XAPK, ZIP files supported')
      return
    }
    setUploadingApk(true)
    setApkProgress(5)
    toast.info('Uploading APK...')
    try {
      const fd = new FormData()
      fd.append('file', file)
      fd.append('type', 'app')
      await new Promise<void>((resolve, reject) => {
        const xhr = new XMLHttpRequest()
        xhr.upload.onprogress = (e) => { if (e.lengthComputable) setApkProgress(Math.round((e.loaded / e.total) * 90)) }
        xhr.onload = () => {
          if (xhr.status === 200) {
            const data = JSON.parse(xhr.responseText)
            setForm(f => ({ ...f, apkUrl: data.url, size: `${(file.size / 1024 / 1024).toFixed(1)} MB` }))
            setApkProgress(100)
            toast.success('APK uploaded successfully!')
            resolve()
          } else {
            try { reject(new Error(JSON.parse(xhr.responseText).error || 'Upload failed')) }
            catch { reject(new Error('Upload failed')) }
          }
        }
        xhr.onerror = () => reject(new Error('Network error'))
        xhr.open('POST', '/api/upload')
        xhr.send(fd)
      })
    } catch (err: any) { toast.error(err.message); setApkProgress(0) }
    setUploadingApk(false)
  }

  const removeScreenshot = (i: number) => {
    setForm(f => ({ ...f, screenshots: f.screenshots.filter((_, j) => j !== i) }))
    setScreenshotPreviews(p => p.filter((_, j) => j !== i))
  }

  const addPermission = () => {
    if (permissionInput.trim() && form.permissions.length < 20) {
      setForm(f => ({ ...f, permissions: [...f.permissions, permissionInput.trim()] }))
      setPermissionInput('')
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.title.trim()) { toast.error('App name is required'); return }
    if (!form.packageName.trim()) { toast.error('Package name is required (e.g. com.example.app)'); return }
    setLoading(true)
    try {
      const tags = form.tags.split(',').map(t => t.trim()).filter(Boolean)
      const res = await fetch('/api/apps', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, tags })
      })
      if (res.ok) { toast.success('App submitted for review!'); router.push('/apps') }
      else { const err = await res.json(); toast.error(err.error || 'Submission failed') }
    } catch { toast.error('Error submitting app') }
    setLoading(false)
  }

  if (status === 'loading') return null

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      <main className="container mx-auto px-4 py-6 max-w-2xl">
        <div className="mb-6">
          <h1 className="text-2xl sm:text-3xl font-bold flex items-center gap-3">
            <span className="p-2 bg-green-600 rounded-lg flex-shrink-0"><Smartphone className="w-5 h-5 sm:w-6 sm:h-6" /></span>
            Submit App
          </h1>
          <p className="text-white/50 mt-1 text-sm">Share your app with the community. Published after admin approval.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="bg-white/5 rounded-2xl p-5 border border-white/10 space-y-4">
            <h2 className="font-semibold">App Information</h2>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <Label className="text-white/70 mb-1.5 block text-sm">App Name <span className="text-red-400">*</span></Label>
                <Input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} placeholder="My Awesome App" className="bg-white/5 border-white/10 text-white placeholder:text-white/30 text-base" />
              </div>
              <div>
                <Label className="text-white/70 mb-1.5 block text-sm">Package Name <span className="text-red-400">*</span></Label>
                <Input value={form.packageName} onChange={e => setForm(f => ({ ...f, packageName: e.target.value }))} placeholder="com.yourname.app" className="bg-white/5 border-white/10 text-white placeholder:text-white/30 font-mono text-sm" />
              </div>
            </div>

            <div>
              <Label className="text-white/70 mb-1.5 block text-sm">Short Description</Label>
              <Input value={form.shortDesc} onChange={e => setForm(f => ({ ...f, shortDesc: e.target.value }))} placeholder="Describe your app in one line" maxLength={100} className="bg-white/5 border-white/10 text-white placeholder:text-white/30 text-base" />
            </div>

            <div>
              <Label className="text-white/70 mb-1.5 block text-sm">Full Description</Label>
              <Textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="App features, how to use it..." className="bg-white/5 border-white/10 text-white placeholder:text-white/30 min-h-[100px] text-base" />
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <Label className="text-white/70 mb-1.5 block text-sm">Version</Label>
                <Input value={form.version} onChange={e => setForm(f => ({ ...f, version: e.target.value }))} placeholder="1.0.0" className="bg-white/5 border-white/10 text-white placeholder:text-white/30 text-sm" />
              </div>
              <div>
                <Label className="text-white/70 mb-1.5 block text-sm">Platform</Label>
                <Select value={form.platform} onValueChange={v => setForm(f => ({ ...f, platform: v }))}>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-[#1a1a2e] border-white/10 text-white">
                    {['Android', 'iOS', 'Cross-Platform'].map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-white/70 mb-1.5 block text-sm">Category</Label>
                <Select value={form.category} onValueChange={v => setForm(f => ({ ...f, category: v }))}>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-[#1a1a2e] border-white/10 text-white">
                    {CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label className="text-white/70 mb-2 block text-sm">APK / Download</Label>
              <div className="flex rounded-xl overflow-hidden border border-white/10 mb-3">
                <button type="button" onClick={() => setApkMode('url')}
                  className={`flex-1 py-2.5 text-sm font-medium transition-all flex items-center justify-center gap-2 ${apkMode === 'url' ? 'bg-green-600 text-white' : 'bg-white/5 text-white/50 hover:bg-white/10'}`}>
                  <Link className="w-4 h-4" /> Paste URL
                </button>
                <button type="button" onClick={() => setApkMode('file')}
                  className={`flex-1 py-2.5 text-sm font-medium transition-all flex items-center justify-center gap-2 ${apkMode === 'file' ? 'bg-green-600 text-white' : 'bg-white/5 text-white/50 hover:bg-white/10'}`}>
                  <Package className="w-4 h-4" /> Upload APK File
                </button>
              </div>

              {apkMode === 'url' ? (
                <Input value={form.apkUrl} onChange={e => setForm(f => ({ ...f, apkUrl: e.target.value }))} placeholder="https://example.com/app.apk" className="bg-white/5 border-white/10 text-white placeholder:text-white/30 text-base" />
              ) : (
                <div>
                  <input ref={apkInputRef} type="file" accept=".apk,.aab,.xapk,.zip" className="hidden" onChange={handleApkFileUpload} />
                  {form.apkUrl && apkMode === 'file' ? (
                    <div className="flex items-center gap-3 bg-green-500/10 border border-green-500/20 rounded-xl p-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <p className="text-sm text-green-400 font-medium">APK uploaded successfully!</p>
                        {form.size && <p className="text-xs text-white/40">Size: {form.size}</p>}
                      </div>
                      <button type="button" onClick={() => { setForm(f => ({ ...f, apkUrl: '' })); setApkProgress(0) }} className="text-white/40 hover:text-white p-1"><X className="w-4 h-4" /></button>
                    </div>
                  ) : uploadingApk ? (
                    <div className="bg-white/5 border border-white/10 rounded-xl p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Loader2 className="w-4 h-4 text-green-400 animate-spin" />
                        <span className="text-sm text-white/70">Uploading... {apkProgress}%</span>
                      </div>
                      <div className="w-full bg-white/10 rounded-full h-2">
                        <div className="bg-green-500 h-2 rounded-full transition-all" style={{ width: `${apkProgress}%` }} />
                      </div>
                    </div>
                  ) : (
                    <button type="button" onClick={() => apkInputRef.current?.click()}
                      className="w-full flex flex-col items-center justify-center py-8 rounded-xl border-2 border-dashed border-white/20 hover:border-green-400 hover:bg-green-500/5 transition-all">
                      <Package className="w-10 h-10 text-white/20 mb-2" />
                      <p className="text-white/50 font-medium">Choose APK File</p>
                      <p className="text-white/30 text-xs mt-1">APK, AAB, XAPK, ZIP supported</p>
                    </button>
                  )}
                </div>
              )}
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-white/70 mb-1.5 block text-sm">File Size</Label>
                <Input value={form.size} onChange={e => setForm(f => ({ ...f, size: e.target.value }))} placeholder="45 MB" className="bg-white/5 border-white/10 text-white placeholder:text-white/30 text-sm" />
              </div>
              <div>
                <Label className="text-white/70 mb-1.5 block text-sm">Min. Requirement</Label>
                <Input value={form.minSdk} onChange={e => setForm(f => ({ ...f, minSdk: e.target.value }))} placeholder="Android 6.0+" className="bg-white/5 border-white/10 text-white placeholder:text-white/30 text-sm" />
              </div>
            </div>

            <div>
              <Label className="text-white/70 mb-1.5 block text-sm">Tags (comma separated)</Label>
              <Input value={form.tags} onChange={e => setForm(f => ({ ...f, tags: e.target.value }))} placeholder="game, free, offline, puzzle" className="bg-white/5 border-white/10 text-white placeholder:text-white/30 text-base" />
            </div>

            <div>
              <Label className="text-white/70 mb-1.5 block text-sm">Changelog</Label>
              <Textarea value={form.changelog} onChange={e => setForm(f => ({ ...f, changelog: e.target.value }))} placeholder="What's new in this version..." className="bg-white/5 border-white/10 text-white placeholder:text-white/30 text-sm" />
            </div>
          </div>

          <div className="bg-white/5 rounded-2xl p-5 border border-white/10 space-y-4">
            <h2 className="font-semibold">Icon &amp; Screenshots</h2>
            <div className="flex gap-4 items-start">
              <div>
                <p className="text-white/50 text-xs mb-2">App Icon</p>
                <label className="flex items-center justify-center w-20 h-20 rounded-2xl border-2 border-dashed border-white/20 cursor-pointer hover:border-green-400 transition-all overflow-hidden">
                  {uploadingIcon ? <Loader2 className="w-6 h-6 text-white/40 animate-spin" /> :
                   iconPreview ? <img src={iconPreview} alt="Icon" className="w-full h-full object-cover" /> :
                   <Smartphone className="w-8 h-8 text-white/30" />}
                  <input type="file" className="hidden" accept="image/*" onChange={handleIconUpload} />
                </label>
              </div>
              <div className="flex-1">
                <p className="text-white/50 text-xs mb-2">Cover Image</p>
                <label className="flex items-center justify-center w-full h-20 rounded-xl border-2 border-dashed border-white/20 cursor-pointer hover:border-green-400 transition-all overflow-hidden">
                  {uploadingCover ? <Loader2 className="w-6 h-6 text-white/40 animate-spin" /> :
                   coverPreview ? <img src={coverPreview} alt="Cover" className="w-full h-full object-cover" /> :
                   <div className="flex flex-col items-center text-white/30"><ImageIcon className="w-6 h-6 mb-1" /><span className="text-xs">Cover</span></div>}
                  <input type="file" className="hidden" accept="image/*" onChange={handleCoverUpload} />
                </label>
              </div>
            </div>
            <div>
              <p className="text-white/50 text-xs mb-2">Screenshots (max 8)</p>
              <div className="flex flex-wrap gap-2">
                {screenshotPreviews.map((s, i) => (
                  <div key={i} className="relative w-16 sm:w-20 aspect-[9/16] rounded-lg overflow-hidden border border-white/10">
                    <img src={s} alt={`ss${i}`} className="w-full h-full object-cover" />
                    <button type="button" onClick={() => removeScreenshot(i)} className="absolute top-1 right-1 bg-black/60 rounded-full p-0.5 hover:bg-red-600">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                ))}
                {form.screenshots.length < 8 && (
                  <label className="w-16 sm:w-20 aspect-[9/16] flex flex-col items-center justify-center rounded-lg border-2 border-dashed border-white/20 cursor-pointer hover:border-green-400 transition-all">
                    {uploadingScreenshot ? <Loader2 className="w-5 h-5 text-white/40 animate-spin" /> : <Plus className="w-6 h-6 text-white/30" />}
                    <input type="file" className="hidden" accept="image/*" multiple onChange={handleScreenshotUpload} />
                  </label>
                )}
              </div>
            </div>
          </div>

          <div className="bg-white/5 rounded-2xl p-5 border border-white/10 space-y-3">
            <h2 className="font-semibold">App Permissions</h2>
            <div className="flex gap-2">
              <Input value={permissionInput} onChange={e => setPermissionInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && (e.preventDefault(), addPermission())} placeholder="e.g. INTERNET, CAMERA" className="bg-white/5 border-white/10 text-white placeholder:text-white/30 text-sm" />
              <Button type="button" onClick={addPermission} variant="outline" size="icon" className="border-white/20 hover:bg-white/10 flex-shrink-0"><Plus className="w-4 h-4" /></Button>
            </div>
            {form.permissions.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {form.permissions.map((p, i) => (
                  <span key={i} className="flex items-center gap-1 bg-yellow-500/10 text-yellow-400 text-xs px-2 py-1 rounded-full border border-yellow-500/20">
                    {p} <button type="button" onClick={() => setForm(f => ({ ...f, permissions: f.permissions.filter((_, j) => j !== i) }))}><X className="w-2.5 h-2.5" /></button>
                  </span>
                ))}
              </div>
            )}
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <Button type="submit" disabled={loading || uploadingApk} className="bg-green-600 hover:bg-green-700 flex-1 h-12 text-base">
              {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Submitting...</> : <><Upload className="w-4 h-4 mr-2" /> Submit App</>}
            </Button>
            <NextLink href="/apps" className="w-full sm:w-auto">
              <Button type="button" variant="outline" className="border-white/20 hover:bg-white/10 h-12 w-full">Cancel</Button>
            </NextLink>
          </div>
          <p className="text-xs text-white/30 text-center">App will be published after admin review</p>
        </form>
      </main>
      <Footer />
    </div>
  )
}
