'use client'

import { useState } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import { Loader2, Sparkles, Film, Download, RefreshCw } from 'lucide-react'

const ASPECTS: { id: '16:9' | '9:16' | '1:1'; label: string; box: string }[] = [
  { id: '16:9', label: 'Landscape 16:9', box: 'aspect-video' },
  { id: '9:16', label: 'Vertical 9:16', box: 'aspect-[9/16] max-w-[260px] mx-auto' },
  { id: '1:1',  label: 'Square 1:1',    box: 'aspect-square max-w-[420px] mx-auto' },
]

export default function AiVideoPage() {
  const { status } = useSession()
  const router = useRouter()

  const [prompt, setPrompt] = useState('')
  const [aspect, setAspect] = useState<'16:9' | '9:16' | '1:1'>('16:9')
  const [duration, setDuration] = useState(5)
  const [loading, setLoading] = useState(false)
  const [videoUrl, setVideoUrl] = useState('')
  const [attempts, setAttempts] = useState<{ provider: string; model: string; status: string; error?: string }[]>([])

  if (status === 'unauthenticated') {
    if (typeof window !== 'undefined') router.push('/auth/signin')
    return null
  }

  const generate = async () => {
    if (!prompt.trim()) { toast.error('Write your video prompt first'); return }
    setLoading(true); setVideoUrl(''); setAttempts([])
    try {
      const res = await fetch('/api/ai/generate/video', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: prompt.trim(), aspect, duration }),
      })
      const data = await res.json()
      if (data.attempts) setAttempts(data.attempts)
      if (!res.ok) {
        toast.error(data.error || 'Video generation failed')
        return
      }
      setVideoUrl(data.videoUrl)
      toast.success('Video generated!')
    } catch {
      toast.error('Connection error. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const downloadVideo = async () => {
    if (!videoUrl) return
    try {
      const r = await fetch(videoUrl)
      const blob = await r.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `gfx-ai-video-${Date.now()}.mp4`
      document.body.appendChild(a); a.click(); document.body.removeChild(a)
      URL.revokeObjectURL(url)
      toast.success('Video downloaded')
    } catch { window.open(videoUrl, '_blank') }
  }

  const aspectBox = ASPECTS.find(a => a.id === aspect)?.box || 'aspect-video'

  return (
    <div className="min-h-screen bg-[#0a0a12] text-white flex flex-col">
      <Navbar />
      <div className="flex-1 container mx-auto px-4 py-8 max-w-5xl">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-violet-500/10 border border-violet-500/20 rounded-full px-4 py-1.5 mb-4">
            <Film className="w-4 h-4 text-violet-400" />
            <span className="text-violet-300 text-sm font-medium">AI Video Generator</span>
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">AI Video Gen</h1>
          <p className="text-white/50 text-sm">
            Describe what you want — the system picks the cheapest configured AI video model and falls back automatically if any fail.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Input */}
          <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-5 space-y-4 h-fit">
            <div className="space-y-1.5">
              <Label className="text-sm text-white/70">Video prompt</Label>
              <Textarea
                placeholder="e.g. A neon-lit cyberpunk city at night, raining, camera glides through, cinematic"
                value={prompt}
                onChange={e => setPrompt(e.target.value)}
                rows={6}
                className="bg-black/40 border-white/10 text-white placeholder:text-white/30 resize-none rounded-xl"
              />
              <div className="text-xs text-white/30 text-right">{prompt.length}/1500</div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm text-white/70">Aspect ratio</Label>
              <div className="flex gap-1.5">
                {ASPECTS.map(a => (
                  <button key={a.id} onClick={() => setAspect(a.id)}
                    className={`flex-1 px-3 py-2 rounded-lg text-xs font-medium border transition ${
                      aspect === a.id
                        ? 'bg-violet-600 border-violet-500 text-white'
                        : 'bg-white/[0.03] border-white/10 text-white/60 hover:text-white hover:bg-white/[0.06]'
                    }`}>
                    {a.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm text-white/70">Duration: <span className="text-violet-300 font-semibold">{duration}s</span></Label>
              <input
                type="range" min={3} max={10} step={1}
                value={duration}
                onChange={e => setDuration(parseInt(e.target.value))}
                className="w-full accent-violet-500"
              />
              <p className="text-[11px] text-white/30">Shorter = much cheaper. Most providers cap at 10s per generation.</p>
            </div>

            <Button onClick={generate} disabled={loading || !prompt.trim()}
              className="w-full h-11 bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 border-0 rounded-xl text-white font-medium gap-2">
              {loading ? (<><Loader2 className="w-4 h-4 animate-spin" /> Generating…</>)
                       : (<><Sparkles className="w-4 h-4" /> Generate Video</>)}
            </Button>

            <p className="text-[11px] text-white/30 leading-relaxed">
              Default video model is set in Admin → AI API Keys. Add a FAL.ai key for the cheapest path.
            </p>
          </div>

          {/* Output */}
          <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-5 flex flex-col">
            <div className="text-sm font-semibold text-white/80 mb-3">Result</div>
            <div className="flex-1 min-h-[280px] flex items-center justify-center">
              {loading ? (
                <div className="text-center">
                  <Loader2 className="w-10 h-10 text-violet-400 animate-spin mx-auto mb-3" />
                  <p className="text-white/60 text-sm">Generating your video…</p>
                  <p className="text-white/30 text-xs mt-1">This usually takes 30s – 3 min</p>
                </div>
              ) : videoUrl ? (
                <div className="w-full space-y-3">
                  <div className={`relative rounded-xl overflow-hidden border border-white/10 bg-black ${aspectBox}`}>
                    <video src={videoUrl} controls autoPlay loop playsInline className="w-full h-full object-contain block" />
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={downloadVideo} className="flex-1 h-9 bg-emerald-600 hover:bg-emerald-500 border-0 text-white text-sm rounded-xl gap-2">
                      <Download className="w-3.5 h-3.5" /> Download MP4
                    </Button>
                    <Button onClick={generate} variant="outline" className="h-9 border-white/10 text-white hover:bg-white/5 text-sm rounded-xl gap-2">
                      <RefreshCw className="w-3.5 h-3.5" /> Regenerate
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="text-center">
                  <Film className="w-10 h-10 text-white/15 mx-auto mb-3" />
                  <p className="text-white/30 text-sm">Your generated video will appear here</p>
                </div>
              )}
            </div>

            {attempts.length > 0 && (
              <div className="mt-4 rounded-xl border border-white/[0.06] bg-black/30 p-3 text-[11px] space-y-1">
                <div className="text-white/40 uppercase tracking-wider">Provider attempts</div>
                {attempts.map((a, i) => (
                  <div key={i} className={`flex items-center gap-2 ${a.status === 'ok' ? 'text-emerald-300' : 'text-rose-300/80'}`}>
                    <span className="font-mono">{a.status === 'ok' ? '✓' : '✗'}</span>
                    <span>{a.provider}</span>
                    <span className="text-white/30 truncate flex-1">{a.model}</span>
                    {a.error && <span className="text-rose-300/60 truncate max-w-[160px]">{a.error}</span>}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )
}
