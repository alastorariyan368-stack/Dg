'use client'

import { useState, useRef, useEffect } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import { Loader2, Mic, Download, Volume2, RefreshCw, Wand2 } from 'lucide-react'

interface VoiceOption { id: string; label: string; provider: 'elevenlabs' | 'deepgram' | 'openai' | 'pollinations'; lang?: string }

const ELEVEN_VOICES: VoiceOption[] = [
  { id: '21m00Tcm4TlvDq8ikWAM', label: 'Rachel — calm female (EN)', provider: 'elevenlabs', lang: 'EN' },
  { id: 'AZnzlk1XvdvUeBnXmlld', label: 'Domi — confident female (EN)', provider: 'elevenlabs', lang: 'EN' },
  { id: 'EXAVITQu4vr4xnSDxMaL', label: 'Bella — soft female (EN)', provider: 'elevenlabs', lang: 'EN' },
  { id: 'ErXwobaYiN019PkySvjV', label: 'Antoni — warm male (EN)', provider: 'elevenlabs', lang: 'EN' },
  { id: 'VR6AewLTigWG4xSOukaG', label: 'Arnold — strong male (EN)', provider: 'elevenlabs', lang: 'EN' },
  { id: 'pNInz6obpgDQGcFmaJgB', label: 'Adam — deep male (EN)', provider: 'elevenlabs', lang: 'EN' },
  { id: 'yoZ06aMxZJJ28mfd3POQ', label: 'Sam — friendly male (EN)', provider: 'elevenlabs', lang: 'EN' },
]

const DEEPGRAM_VOICES: VoiceOption[] = [
  { id: 'aura-asteria-en', label: 'Aura Asteria — female US English (Deepgram)', provider: 'deepgram' },
  { id: 'aura-luna-en', label: 'Aura Luna — soft female (Deepgram)', provider: 'deepgram' },
  { id: 'aura-stella-en', label: 'Aura Stella — clear female (Deepgram)', provider: 'deepgram' },
  { id: 'aura-athena-en', label: 'Aura Athena — UK female (Deepgram)', provider: 'deepgram' },
  { id: 'aura-hera-en', label: 'Aura Hera — narrator female (Deepgram)', provider: 'deepgram' },
  { id: 'aura-orion-en', label: 'Aura Orion — male US English (Deepgram)', provider: 'deepgram' },
  { id: 'aura-arcas-en', label: 'Aura Arcas — narrator male (Deepgram)', provider: 'deepgram' },
  { id: 'aura-perseus-en', label: 'Aura Perseus — confident male (Deepgram)', provider: 'deepgram' },
  { id: 'aura-angus-en', label: 'Aura Angus — Irish male (Deepgram)', provider: 'deepgram' },
  { id: 'aura-orpheus-en', label: 'Aura Orpheus — deep male (Deepgram)', provider: 'deepgram' },
  { id: 'aura-helios-en', label: 'Aura Helios — UK male (Deepgram)', provider: 'deepgram' },
  { id: 'aura-zeus-en', label: 'Aura Zeus — bold male (Deepgram)', provider: 'deepgram' },
]

const OPENAI_VOICES: VoiceOption[] = [
  { id: 'alloy', label: 'Alloy — neutral (OpenAI / free fallback)', provider: 'openai' },
  { id: 'echo', label: 'Echo — male (OpenAI / free fallback)', provider: 'openai' },
  { id: 'fable', label: 'Fable — British male (OpenAI / free fallback)', provider: 'openai' },
  { id: 'onyx', label: 'Onyx — deep male (OpenAI / free fallback)', provider: 'openai' },
  { id: 'nova', label: 'Nova — friendly female (OpenAI / free fallback)', provider: 'openai' },
  { id: 'shimmer', label: 'Shimmer — soft female (OpenAI / free fallback)', provider: 'openai' },
]

const SAMPLE_PROMPTS = [
  'Welcome to GfxStore, your one-stop hub for digital goods, AI tools, and creator earnings. Let’s build something amazing today.',
  'In a world where speed matters, our platform delivers blazing-fast results — every single time.',
  'Hello everyone, and welcome back to the channel. In today’s video, we’re diving deep into the most underrated AI tools of the year.',
  'Breaking news: a major announcement is reshaping the technology landscape this week.',
]

export default function AiVoicePage() {
  const { status } = useSession()
  const router = useRouter()

  const [text, setText] = useState('')
  const [provider, setProvider] = useState<'auto' | 'elevenlabs' | 'deepgram' | 'openai' | 'pollinations'>('auto')
  const [elevenVoice, setElevenVoice] = useState(ELEVEN_VOICES[0].id)
  const [deepgramVoice, setDeepgramVoice] = useState(DEEPGRAM_VOICES[0].id)
  const [openaiVoice, setOpenaiVoice] = useState(OPENAI_VOICES[0].id)

  const [loading, setLoading] = useState(false)
  const [audioUrl, setAudioUrl] = useState('')
  const [usedProvider, setUsedProvider] = useState('')
  const [usedModel, setUsedModel] = useState('')
  const [attempts, setAttempts] = useState<{ provider: string; model: string; status: string; error?: string }[]>([])
  const audioRef = useRef<HTMLAudioElement>(null)

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin')
  }, [status, router])

  if (status === 'unauthenticated' || status === 'loading') {
    return (
      <div className="min-h-screen bg-[#0a0a12] text-white flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-amber-400" />
      </div>
    )
  }

  const generate = async () => {
    if (!text.trim()) { toast.error('Likho ki bolaite chao first'); return }
    setLoading(true); setAudioUrl(''); setAttempts([]); setUsedProvider(''); setUsedModel('')
    try {
      const payload: any = {
        text: text.trim(),
        voiceId: elevenVoice,
        deepgramVoice,
        openaiVoice,
      }
      // If user picks a specific provider, force-set keys to skip others by sending preference
      if (provider !== 'auto') payload.preferredProvider = provider

      const res = await fetch('/api/ai/generate/voice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      const data = await res.json()
      if (data.attempts) setAttempts(data.attempts)
      if (!res.ok) {
        toast.error(data.error || 'Voice generation failed')
        return
      }
      setAudioUrl(data.audioUrl)
      setUsedProvider(data.provider || '')
      setUsedModel(data.model || '')
      toast.success(`Voice ready (${data.provider})`)
      setTimeout(() => audioRef.current?.play().catch(() => {}), 200)
    } catch {
      toast.error('Connection error. Try again.')
    } finally {
      setLoading(false)
    }
  }

  const downloadAudio = async () => {
    if (!audioUrl) return
    try {
      const r = await fetch(audioUrl)
      const blob = await r.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `gfx-ai-voice-${Date.now()}.mp3`
      document.body.appendChild(a); a.click(); document.body.removeChild(a)
      URL.revokeObjectURL(url)
      toast.success('Audio downloaded')
    } catch { window.open(audioUrl, '_blank') }
  }

  return (
    <div className="min-h-screen bg-[#0a0a12] text-white flex flex-col">
      <Navbar />
      <div className="flex-1 container mx-auto px-4 py-8 max-w-5xl">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-amber-500/10 border border-amber-500/20 rounded-full px-4 py-1.5 mb-4">
            <Mic className="w-4 h-4 text-amber-400" />
            <span className="text-amber-300 text-sm font-medium">AI Voice Generator</span>
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">AI Voice / Text-to-Speech</h1>
          <p className="text-white/50 text-sm max-w-2xl mx-auto">
            Type any script and get a natural human voice in seconds. ElevenLabs &gt; Deepgram Aura &gt; OpenAI TTS &gt; free Pollinations fallback —
            the system picks whichever provider has a key configured, or always falls back to free.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Input */}
          <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-5 space-y-4 h-fit">
            <div className="space-y-1.5">
              <Label className="text-sm text-white/70">Script (max 5000 chars)</Label>
              <Textarea
                placeholder="Type or paste the script you want spoken aloud…"
                value={text}
                onChange={e => setText(e.target.value.slice(0, 5000))}
                className="min-h-[180px] bg-black/40 border-white/10 text-white text-sm"
              />
              <div className="flex items-center justify-between text-xs text-white/40">
                <span>{text.length} / 5000 characters</span>
                <button
                  type="button"
                  onClick={() => setText(SAMPLE_PROMPTS[Math.floor(Math.random() * SAMPLE_PROMPTS.length)])}
                  className="hover:text-amber-300 inline-flex items-center gap-1"
                >
                  <Wand2 className="w-3 h-3" /> Sample script
                </button>
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm text-white/70">Provider preference</Label>
              <select
                value={provider}
                onChange={e => setProvider(e.target.value as any)}
                className="w-full bg-black/40 border border-white/10 rounded-md px-3 py-2 text-sm text-white"
              >
                <option value="auto">Auto (best available — ElevenLabs first)</option>
                <option value="elevenlabs">ElevenLabs only</option>
                <option value="deepgram">Deepgram Aura only</option>
                <option value="openai">OpenAI TTS only</option>
                <option value="pollinations">Free Pollinations only</option>
              </select>
            </div>

            <div className="grid grid-cols-1 gap-3">
              <div className="space-y-1.5">
                <Label className="text-xs text-white/60">ElevenLabs voice</Label>
                <select
                  value={elevenVoice}
                  onChange={e => setElevenVoice(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 rounded-md px-3 py-2 text-sm text-white"
                >
                  {ELEVEN_VOICES.map(v => <option key={v.id} value={v.id}>{v.label}</option>)}
                </select>
                <Input
                  value={elevenVoice}
                  onChange={e => setElevenVoice(e.target.value)}
                  placeholder="…or paste a custom ElevenLabs voice ID"
                  className="bg-black/40 border-white/10 text-xs h-8"
                />
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs text-white/60">Deepgram Aura voice</Label>
                <select
                  value={deepgramVoice}
                  onChange={e => setDeepgramVoice(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 rounded-md px-3 py-2 text-sm text-white"
                >
                  {DEEPGRAM_VOICES.map(v => <option key={v.id} value={v.id}>{v.label}</option>)}
                </select>
              </div>

              <div className="space-y-1.5">
                <Label className="text-xs text-white/60">OpenAI / Pollinations voice</Label>
                <select
                  value={openaiVoice}
                  onChange={e => setOpenaiVoice(e.target.value)}
                  className="w-full bg-black/40 border border-white/10 rounded-md px-3 py-2 text-sm text-white"
                >
                  {OPENAI_VOICES.map(v => <option key={v.id} value={v.id}>{v.label}</option>)}
                </select>
              </div>
            </div>

            <Button
              onClick={generate}
              disabled={loading || !text.trim()}
              className="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white"
            >
              {loading ? (<><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Generating voice…</>) : (<><Volume2 className="w-4 h-4 mr-2" /> Generate Voice</>)}
            </Button>
          </div>

          {/* Output */}
          <div className="bg-white/[0.03] border border-white/10 rounded-2xl p-5 space-y-4 min-h-[300px]">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-medium text-white/80">Output</h3>
              {audioUrl && (
                <div className="flex items-center gap-2">
                  <Button size="sm" variant="ghost" onClick={generate} className="h-8 text-xs"><RefreshCw className="w-3 h-3 mr-1" /> Regenerate</Button>
                  <Button size="sm" onClick={downloadAudio} className="h-8 text-xs bg-amber-500 hover:bg-amber-600"><Download className="w-3 h-3 mr-1" /> Download MP3</Button>
                </div>
              )}
            </div>

            {!audioUrl && !loading && (
              <div className="border border-dashed border-white/10 rounded-xl p-10 text-center text-white/40">
                <Mic className="w-10 h-10 mx-auto mb-3 opacity-40" />
                <p className="text-sm">Your generated voice will appear here.</p>
              </div>
            )}

            {loading && (
              <div className="border border-dashed border-white/10 rounded-xl p-10 text-center text-white/40">
                <Loader2 className="w-10 h-10 mx-auto mb-3 animate-spin text-amber-400" />
                <p className="text-sm">Synthesising voice — usually 2-10 seconds…</p>
              </div>
            )}

            {audioUrl && (
              <div className="space-y-3">
                <audio ref={audioRef} controls src={audioUrl} className="w-full" />
                <div className="text-xs text-white/50">
                  Provider used: <span className="text-amber-300 font-medium">{usedProvider}</span>
                  {usedModel && <> · model <span className="text-white/70">{usedModel}</span></>}
                </div>
              </div>
            )}

            {attempts.length > 0 && (
              <div className="border-t border-white/5 pt-3 mt-3">
                <p className="text-xs text-white/40 mb-2">Provider attempts</p>
                <ul className="space-y-1">
                  {attempts.map((a, i) => (
                    <li key={i} className={`text-xs flex items-start gap-2 ${a.status === 'ok' ? 'text-emerald-300' : 'text-rose-300/70'}`}>
                      <span className="font-mono">{a.status === 'ok' ? '✓' : '✗'}</span>
                      <span><strong>{a.provider}</strong> · {a.model}{a.error ? ` — ${a.error}` : ''}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )
}
