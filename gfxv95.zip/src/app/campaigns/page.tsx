'use client'

import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Loader2, CalendarDays, Gift, ArrowRight, Clock } from 'lucide-react'
import { toast } from 'sonner'

type Campaign = {
  id: string
  name: string
  description?: string
  discountPercent: number
  bannerText?: string
  startDate: string
  endDate: string
  isActive: boolean
}

export default function CampaignsPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [campaigns, setCampaigns] = useState<Campaign[]>([])
  const [claimedCampaigns, setClaimedCampaigns] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const [claiming, setClaiming] = useState<string | null>(null)

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/signin')
    }
  }, [status, router])

  useEffect(() => {
    if (status !== 'authenticated') return

    const load = async () => {
      setLoading(true)
      try {
        const res = await fetch('/api/campaigns/user')
        if (res.ok) {
          const data = await res.json()
          setCampaigns(data.campaigns || [])
          setClaimedCampaigns(data.claimed || [])
        } else {
          toast.error('Failed to load campaigns')
        }
      } catch (error) {
        console.error('Failed to load campaigns:', error)
        toast.error('Failed to load campaigns')
      } finally {
        setLoading(false)
      }
    }

    load()
  }, [status])

  const claimCampaign = async (campaignId: string) => {
    setClaiming(campaignId)
    try {
      const res = await fetch('/api/campaigns/claim', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ campaignId })
      })

      if (res.ok) {
        toast.success('Campaign discount claimed!')
        setClaimedCampaigns(prev => [...prev, campaignId])
      } else {
        const error = await res.json().catch(() => ({}))
        toast.error(error.error || 'Failed to claim campaign')
      }
    } catch (error) {
      console.error('Error claiming campaign:', error)
      toast.error('Failed to claim campaign')
    } finally {
      setClaiming(null)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
        </div>
      </div>
    )
  }

  const now = new Date()
  const activeCampaigns = campaigns.filter(c => c.isActive && new Date(c.endDate) > now)
  const expiredCampaigns = campaigns.filter(c => new Date(c.endDate) <= now)

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />

      <div className="container mx-auto px-4 py-10 max-w-6xl">
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <Gift className="w-6 h-6 text-purple-400" />
            <h1 className="text-3xl font-bold">Active Campaigns</h1>
          </div>
          <p className="text-white/40">Claim discounts from current promotions and save on purchases</p>
        </div>

        {activeCampaigns.length === 0 ? (
          <div className="bg-white/[0.02] border border-white/5 rounded-2xl p-12 text-center mb-8">
            <CalendarDays className="w-12 h-12 text-white/10 mx-auto mb-3" />
            <p className="text-white/30">No active campaigns right now</p>
            <p className="text-white/40 text-sm mt-1">Check back soon for great deals!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
            {activeCampaigns.map(campaign => {
              const isClaimed = claimedCampaigns.includes(campaign.id)
              const endDate = new Date(campaign.endDate)
              const daysLeft = Math.ceil((endDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24))

              return (
                <div 
                  key={campaign.id} 
                  className="bg-gradient-to-br from-white/[0.05] to-white/[0.02] border border-white/8 rounded-xl p-6 hover:border-white/12 transition-colors"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="text-lg font-semibold text-white mb-1">{campaign.name}</h3>
                      {campaign.bannerText && (
                        <p className="text-sm text-purple-400 font-medium">{campaign.bannerText}</p>
                      )}
                    </div>
                    <Badge className="text-sm font-bold bg-gradient-to-r from-orange-500/20 to-red-500/20 text-orange-300 border-orange-500/30">
                      {campaign.discountPercent}% OFF
                    </Badge>
                  </div>

                  {campaign.description && (
                    <p className="text-sm text-white/60 mb-4">{campaign.description}</p>
                  )}

                  <div className="flex items-center gap-2 text-xs text-white/40 mb-4">
                    <Clock className="w-4 h-4" />
                    <span>{daysLeft} days left</span>
                    <span>•</span>
                    <span>Ends {endDate.toLocaleDateString()}</span>
                  </div>

                  <Button
                    onClick={() => claimCampaign(campaign.id)}
                    disabled={isClaimed || claiming === campaign.id}
                    className={`w-full text-[13px] h-9 rounded-lg gap-2 border-0 ${
                      isClaimed
                        ? 'bg-emerald-500/10 text-emerald-400 cursor-default'
                        : 'bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white'
                    }`}
                  >
                    {isClaimed ? (
                      <>
                        ✓ Claimed
                      </>
                    ) : claiming === campaign.id ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Claiming...
                      </>
                    ) : (
                      <>
                        <Gift className="w-4 h-4" />
                        Claim Discount
                      </>
                    )}
                  </Button>
                </div>
              )
            })}
          </div>
        )}

        {expiredCampaigns.length > 0 && (
          <div>
            <h2 className="text-lg font-semibold text-white mb-4">Expired Campaigns</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 opacity-60">
              {expiredCampaigns.map(campaign => (
                <div
                  key={campaign.id}
                  className="bg-white/[0.02] border border-white/5 rounded-xl p-4"
                >
                  <h3 className="text-sm font-semibold text-white/60 mb-1">{campaign.name}</h3>
                  <Badge className="text-[10px] bg-red-500/10 text-red-400 border-red-500/20">
                    Expired
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <Footer />
    </div>
  )
}
