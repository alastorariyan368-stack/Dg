'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Heart, Package, Download, Star, Trash2, ShoppingCart, ArrowRight, Loader2 } from 'lucide-react'
import { toast } from 'sonner'

interface WishlistItem {
  id: string; title: string; slug: string; logo?: string
  price: number; accessType: string; downloads: number; likes: number
  author: { username: string; avatar?: string }
  category: { name: string }
}

export default function WishlistPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [items, setItems] = useState<WishlistItem[]>([])
  const [loading, setLoading] = useState(true)
  const [removing, setRemoving] = useState<string | null>(null)

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin')
    if (status === 'authenticated') fetchWishlist()
  }, [status])

  const fetchWishlist = async () => {
    try {
      const res = await fetch('/api/wishlist')
      if (res.ok) { const data = await res.json(); setItems(data.wishlist || []) }
    } catch {} finally { setLoading(false) }
  }

  const removeFromWishlist = async (itemId: string) => {
    setRemoving(itemId)
    try {
      const res = await fetch('/api/wishlist', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ itemId }) })
      if (res.ok) { setItems(prev => prev.filter(i => i.id !== itemId)); toast.success('Removed from wishlist') }
    } catch { toast.error('Failed to remove') } finally { setRemoving(null) }
  }

  const addToCart = async (itemId: string) => {
    try {
      const res = await fetch('/api/cart', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ itemId }) })
      if (res.ok) toast.success('Added to cart!')
    } catch { toast.error('Failed to add to cart') }
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      <Navbar />
      <div className="container mx-auto px-4 py-12 max-w-5xl">
        <div className="flex items-center justify-between mb-8">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Heart className="h-5 w-5 text-pink-400" />
              <span className="text-sm font-medium text-pink-400 uppercase tracking-wider">Saved</span>
            </div>
            <h1 className="text-3xl font-bold text-white">My Wishlist</h1>
            <p className="text-white/40 mt-1">{items.length} item{items.length !== 1 ? 's' : ''} saved</p>
          </div>
          {items.length > 0 && (
            <Link href="/browse">
              <Button variant="outline" className="bg-white/5 border-white/10 text-white hover:bg-white/10 rounded-xl gap-2">
                Browse More <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          )}
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20">
            <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
          </div>
        ) : items.length === 0 ? (
          <div className="text-center py-20">
            <Heart className="w-16 h-16 mx-auto text-white/10 mb-4" />
            <h2 className="text-xl font-semibold text-white mb-2">Your wishlist is empty</h2>
            <p className="text-white/40 mb-6">Save items you love to find them later</p>
            <Link href="/browse">
              <Button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl">
                <Package className="mr-2 h-4 w-4" /> Browse Content
              </Button>
            </Link>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {items.map(item => (
              <div key={item.id} className="bg-white/[0.03] border border-white/8 hover:border-purple-500/30 rounded-2xl p-5 transition-all group">
                <div className="flex items-start gap-3 mb-4">
                  <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500/20 to-blue-500/20 border border-white/10 flex items-center justify-center flex-shrink-0">
                    {item.logo ? <img src={item.logo} alt={item.title} className="w-full h-full object-cover rounded-xl" /> : <Package className="w-5 h-5 text-white/30" />}
                  </div>
                  <div className="flex-1 min-w-0">
                    <Badge className="bg-white/5 text-white/40 border-white/10 text-[10px] mb-1">{item.category?.name}</Badge>
                    <h3 className="font-semibold text-white text-sm line-clamp-1 group-hover:text-purple-300 transition-colors">{item.title}</h3>
                    <p className="text-xs text-white/40">by {item.author?.username}</p>
                  </div>
                </div>
                <div className="flex items-center justify-between text-xs text-white/30 mb-4">
                  <div className="flex items-center gap-3">
                    <span className="flex items-center gap-1"><Star className="h-3 w-3 text-yellow-400" />{item.likes}</span>
                    <span className="flex items-center gap-1"><Download className="h-3 w-3" />{item.downloads}</span>
                  </div>
                  <span className={item.price > 0 ? 'text-green-400 font-semibold' : 'text-blue-400'}>{item.price > 0 ? `$${item.price}` : 'Free'}</span>
                </div>
                <div className="flex gap-2">
                  <Link href={`/items/${item.slug}`} className="flex-1">
                    <Button size="sm" className="w-full h-8 bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border-0 rounded-lg text-xs">View</Button>
                  </Link>
                  {item.price > 0 && (
                    <Button size="sm" onClick={() => addToCart(item.id)} className="h-8 bg-white/5 hover:bg-white/10 text-white/60 border-0 rounded-lg text-xs px-3">
                      <ShoppingCart className="h-3 w-3" />
                    </Button>
                  )}
                  <Button size="sm" variant="ghost" onClick={() => removeFromWishlist(item.id)} disabled={removing === item.id} className="h-8 text-red-400 hover:bg-red-500/10 rounded-lg px-3">
                    {removing === item.id ? <Loader2 className="h-3 w-3 animate-spin" /> : <Trash2 className="h-3 w-3" />}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      <Footer />
    </div>
  )
}
