'use client'

import { useState, useEffect } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Code2, Search, Upload, Download, Heart, Eye } from 'lucide-react'
import Link from 'next/link'
import { useSession } from 'next-auth/react'
import { formatDistanceToNow } from 'date-fns'

interface CodeProject {
  id: string
  title: string
  description?: string
  shortDesc?: string
  language: string
  type: string
  previewUrl?: string
  screenshots: any[]
  tags: any[]
  downloads: number
  likes: number
  createdAt: string
  author: { id: string; username: string; avatar?: string; isVerified: boolean }
  _count: { codeLikes: number }
}

const LANGUAGES = ['All', 'JavaScript', 'TypeScript', 'HTML', 'CSS', 'Python', 'PHP', 'Java', 'C#', 'Kotlin', 'Swift', 'Other']
const TYPES = ['All', 'Frontend', 'Backend', 'Fullstack', 'Mobile', 'Script', 'Component', 'Template', 'Other']

const LANGUAGE_COLORS: Record<string, string> = {
  JavaScript: 'bg-yellow-500/20 text-yellow-400',
  TypeScript: 'bg-blue-500/20 text-blue-400',
  HTML: 'bg-orange-500/20 text-orange-400',
  CSS: 'bg-purple-500/20 text-purple-400',
  Python: 'bg-green-500/20 text-green-400',
  PHP: 'bg-indigo-500/20 text-indigo-400',
  Java: 'bg-red-500/20 text-red-400',
  'C#': 'bg-pink-500/20 text-pink-400',
}

export default function CodePage() {
  const { data: session } = useSession()
  const [projects, setProjects] = useState<CodeProject[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [selectedLanguage, setSelectedLanguage] = useState('All')
  const [selectedType, setSelectedType] = useState('All')
  const [total, setTotal] = useState(0)

  useEffect(() => {
    fetchProjects()
  }, [selectedLanguage, selectedType])

  const fetchProjects = async (searchQuery = '') => {
    setLoading(true)
    try {
      const params = new URLSearchParams({ limit: '24' })
      if (selectedLanguage !== 'All') params.set('language', selectedLanguage)
      if (selectedType !== 'All') params.set('type', selectedType)
      if (searchQuery) params.set('search', searchQuery)
      const res = await fetch(`/api/code?${params}`)
      if (res.ok) {
        const data = await res.json()
        setProjects(data.projects || [])
        setTotal(data.total || 0)
      }
    } catch {}
    setLoading(false)
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    fetchProjects(search)
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-3">
              <span className="p-2 bg-yellow-600 rounded-lg"><Code2 className="w-6 h-6" /></span>
              Code Projects
            </h1>
            <p className="text-white/60 mt-1">{total.toLocaleString()} projects available</p>
          </div>
          {session && (
            <Link href="/code/upload">
              <Button className="bg-yellow-600 hover:bg-yellow-700 gap-2">
                <Upload className="w-4 h-4" /> Upload Code
              </Button>
            </Link>
          )}
        </div>

        {/* Search */}
        <form onSubmit={handleSearch} className="flex gap-2 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
            <Input placeholder="Search projects, languages, templates..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 bg-white/5 border-white/10 text-white placeholder:text-white/40" />
          </div>
          <Button type="submit" variant="outline" className="border-white/20 hover:bg-white/10">Search</Button>
        </form>

        {/* Language Filter */}
        <div className="flex flex-wrap gap-2 mb-4">
          {LANGUAGES.map(lang => (
            <button key={lang} onClick={() => setSelectedLanguage(lang)}
              className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all ${selectedLanguage === lang ? 'bg-yellow-600 text-white' : 'bg-white/5 text-white/60 hover:bg-white/10 hover:text-white'}`}>
              {lang}
            </button>
          ))}
        </div>

        {/* Type Filter */}
        <div className="flex flex-wrap gap-2 mb-8">
          {TYPES.map(t => (
            <button key={t} onClick={() => setSelectedType(t)}
              className={`px-2.5 py-1 rounded-full text-xs font-medium transition-all border ${selectedType === t ? 'border-yellow-500 bg-yellow-600/20 text-yellow-400' : 'border-white/10 text-white/40 hover:border-white/30 hover:text-white/70'}`}>
              {t}
            </button>
          ))}
        </div>

        {/* Projects Grid */}
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {Array.from({ length: 9 }).map((_, i) => (
              <div key={i} className="animate-pulse bg-white/5 rounded-xl p-5 space-y-3">
                <div className="h-5 bg-white/10 rounded w-3/4" />
                <div className="h-3 bg-white/10 rounded w-full" />
                <div className="h-3 bg-white/10 rounded w-2/3" />
              </div>
            ))}
          </div>
        ) : projects.length === 0 ? (
          <div className="text-center py-20">
            <Code2 className="w-16 h-16 text-white/20 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white/60 mb-2">No projects found</h3>
            <p className="text-white/40 mb-6">Share your code with the community!</p>
            {session && <Link href="/code/upload"><Button className="bg-yellow-600 hover:bg-yellow-700">Upload Code</Button></Link>}
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {projects.map(proj => (
              <Link key={proj.id} href={`/code/${proj.id}`} className="group block">
                <div className="bg-white/5 rounded-xl border border-white/5 hover:border-yellow-500/30 hover:bg-white/8 transition-all overflow-hidden">
                  {/* Screenshot or gradient header */}
                  {Array.isArray(proj.screenshots) && proj.screenshots.length > 0 ? (
                    <div className="aspect-video overflow-hidden">
                      <img src={proj.screenshots[0] as string} alt={proj.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                    </div>
                  ) : (
                    <div className="aspect-video flex items-center justify-center bg-gradient-to-br from-yellow-900/20 via-black to-orange-900/20">
                      <Code2 className="w-12 h-12 text-yellow-500/30" />
                    </div>
                  )}
                  <div className="p-4">
                    <div className="flex items-start justify-between gap-2 mb-2">
                      <h3 className="font-semibold text-white group-hover:text-yellow-400 transition-colors line-clamp-1">{proj.title}</h3>
                      <Badge className={`text-xs flex-shrink-0 ${LANGUAGE_COLORS[proj.language] || 'bg-white/10 text-white/60'}`}>{proj.language}</Badge>
                    </div>
                    <p className="text-sm text-white/50 line-clamp-2 mb-3">{proj.shortDesc || proj.description}</p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Avatar className="w-5 h-5"><AvatarImage src={proj.author.avatar} /><AvatarFallback className="text-xs bg-yellow-700">{proj.author.username[0].toUpperCase()}</AvatarFallback></Avatar>
                        <span className="text-xs text-white/50">{proj.author.username}</span>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-white/40">
                        <span className="flex items-center gap-1"><Download className="w-3 h-3" /> {proj.downloads}</span>
                        <span className="flex items-center gap-1"><Heart className="w-3 h-3" /> {proj._count.codeLikes}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge className="text-xs bg-white/5 text-white/40">{proj.type}</Badge>
                      <span className="text-xs text-white/30">{formatDistanceToNow(new Date(proj.createdAt), { addSuffix: true })}</span>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </main>
      <Footer />
    </div>
  )
}
