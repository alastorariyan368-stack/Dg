'use client'

import { useState, useEffect } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Code2, Upload, X, Image as ImageIcon, Loader2, CheckCircle, FileArchive, Star } from 'lucide-react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import Link from 'next/link'

const LANGUAGES = ['JavaScript', 'TypeScript', 'HTML', 'CSS', 'Python', 'PHP', 'Java', 'C#', 'Kotlin', 'Swift', 'Dart', 'Go', 'Rust', 'Other']
const TYPES = ['Frontend', 'Backend', 'Fullstack', 'Mobile', 'Script', 'Component', 'Template', 'API', 'Other']

export default function CodeUploadPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [screenshotPreviews, setScreenshotPreviews] = useState<string[]>([])
  const [uploadingScreenshot, setUploadingScreenshot] = useState(false)
  const [uploadingFile, setUploadingFile] = useState(false)
  const [uploadingCover, setUploadingCover] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [coverPreview, setCoverPreview] = useState<string>('')

  const [form, setForm] = useState({
    title: '', description: '', shortDesc: '',
    language: 'JavaScript', type: 'Frontend',
    fileUrl: '', previewUrl: '', screenshots: [] as string[], tags: '',
    coverImage: '',
  })

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin')
  }, [status])

  const handleCoverUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (!file.type.startsWith('image/')) { toast.error('Please select an image file'); return }
    setUploadingCover(true)
    toast.info('Uploading cover image...')
    try {
      const fd = new FormData()
      fd.append('file', file)
      fd.append('type', 'general')
      const res = await fetch('/api/upload', { method: 'POST', body: fd })
      if (res.ok) {
        const data = await res.json()
        setForm(f => ({ ...f, coverImage: data.url }))
        setCoverPreview(data.url)
        toast.success('Cover image uploaded!')
      } else {
        toast.error('Cover image upload failed')
      }
    } catch { toast.error('Upload error') }
    setUploadingCover(false)
  }

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    setUploadingFile(true)
    setUploadProgress(5)
    toast.info('Uploading file...')
    try {
      const fd = new FormData()
      fd.append('file', file)
      fd.append('type', 'general')
      await new Promise<void>((resolve, reject) => {
        const xhr = new XMLHttpRequest()
        xhr.upload.onprogress = (e) => { if (e.lengthComputable) setUploadProgress(Math.round((e.loaded / e.total) * 90)) }
        xhr.onload = () => {
          if (xhr.status === 200) {
            const data = JSON.parse(xhr.responseText)
            setForm(f => ({ ...f, fileUrl: data.url }))
            setUploadProgress(100)
            toast.success('File uploaded successfully!')
            resolve()
          } else { reject(new Error('Upload failed')) }
        }
        xhr.onerror = () => reject(new Error('Network error'))
        xhr.open('POST', '/api/upload')
        xhr.send(fd)
      })
    } catch (err: any) { toast.error(err.message); setUploadProgress(0) }
    setUploadingFile(false)
  }

  const handleScreenshotUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    if (!files.length) return
    setUploadingScreenshot(true)
    for (const file of files.slice(0, 6 - form.screenshots.length)) {
      try {
        const fd = new FormData()
        fd.append('file', file)
        fd.append('type', 'general')
        const res = await fetch('/api/upload', { method: 'POST', body: fd })
        if (res.ok) {
          const data = await res.json()
          setForm(f => ({ ...f, screenshots: [...f.screenshots, data.url] }))
          setScreenshotPreviews(p => [...p, data.url])
          toast.success('Screenshot uploaded!')
        }
      } catch {}
    }
    setUploadingScreenshot(false)
  }

  const removeScreenshot = (i: number) => {
    setForm(f => ({ ...f, screenshots: f.screenshots.filter((_, j) => j !== i) }))
    setScreenshotPreviews(p => p.filter((_, j) => j !== i))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.title.trim()) { toast.error('Project name is required'); return }
    setLoading(true)
    try {
      const tags = form.tags.split(',').map(t => t.trim()).filter(Boolean)
      const res = await fetch('/api/code', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, tags })
      })
      if (res.ok) { toast.success('Project submitted for review!'); router.push('/code') }
      else { const err = await res.json(); toast.error(err.error || 'Submission failed') }
    } catch { toast.error('Error submitting project') }
    setLoading(false)
  }

  if (status === 'loading') return null

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      <main className="container mx-auto px-4 py-6 max-w-2xl">
        <div className="mb-6">
          <h1 className="text-2xl sm:text-3xl font-bold flex items-center gap-3">
            <span className="p-2 bg-yellow-600 rounded-lg flex-shrink-0"><Code2 className="w-5 h-5 sm:w-6 sm:h-6" /></span>
            Upload Code Project
          </h1>
          <p className="text-white/50 mt-1 text-sm">Share your Frontend/Backend/Fullstack project. Published after admin review.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Cover Image */}
          <div className="bg-white/5 rounded-2xl p-5 border border-white/10 space-y-3">
            <div className="flex items-center gap-2">
              <Star className="w-4 h-4 text-yellow-400" />
              <h2 className="font-semibold">Cover / Profile Image</h2>
              <span className="text-xs text-white/30">(recommended)</span>
            </div>
            <p className="text-xs text-white/30">Upload a cover image that represents your project — shown on the project card.</p>
            {coverPreview ? (
              <div className="relative">
                <img src={coverPreview} alt="Cover" className="w-full h-40 object-cover rounded-xl border border-white/10" />
                <button type="button" onClick={() => { setCoverPreview(''); setForm(f => ({ ...f, coverImage: '' })) }}
                  className="absolute top-2 right-2 bg-black/60 rounded-full p-1 hover:bg-red-600 transition-colors">
                  <X className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <label className="flex flex-col items-center justify-center w-full h-36 rounded-xl border-2 border-dashed border-white/20 cursor-pointer hover:border-yellow-400 hover:bg-yellow-500/5 transition-all">
                {uploadingCover ? (
                  <><Loader2 className="w-8 h-8 text-yellow-400 animate-spin mb-2" /><span className="text-sm text-white/50">Uploading...</span></>
                ) : (
                  <><ImageIcon className="w-10 h-10 text-white/20 mb-2" />
                  <span className="text-white/50 font-medium text-sm">Click to upload cover image</span>
                  <span className="text-white/30 text-xs mt-1">JPG, PNG, WebP — any size</span></>
                )}
                <input type="file" className="hidden" accept="image/*" onChange={handleCoverUpload} disabled={uploadingCover} />
              </label>
            )}
          </div>

          {/* Project Details */}
          <div className="bg-white/5 rounded-2xl p-5 border border-white/10 space-y-4">
            <h2 className="font-semibold">Project Details</h2>
            <div>
              <Label className="text-white/70 mb-1.5 block text-sm">Project Name <span className="text-red-400">*</span></Label>
              <Input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} placeholder="My Awesome Project" className="bg-white/5 border-white/10 text-white placeholder:text-white/30 text-base" />
            </div>
            <div>
              <Label className="text-white/70 mb-1.5 block text-sm">Short Description</Label>
              <Input value={form.shortDesc} onChange={e => setForm(f => ({ ...f, shortDesc: e.target.value }))} placeholder="Describe your project in one line" maxLength={120} className="bg-white/5 border-white/10 text-white placeholder:text-white/30 text-base" />
            </div>
            <div>
              <Label className="text-white/70 mb-1.5 block text-sm">Full Description</Label>
              <Textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} placeholder="Features, installation guide, usage instructions..." className="bg-white/5 border-white/10 text-white placeholder:text-white/30 min-h-[100px] text-base" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-white/70 mb-1.5 block text-sm">Language</Label>
                <Select value={form.language} onValueChange={v => setForm(f => ({ ...f, language: v }))}>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-[#1a1a2e] border-white/10 text-white">
                    {LANGUAGES.map(l => <SelectItem key={l} value={l}>{l}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-white/70 mb-1.5 block text-sm">Project Type</Label>
                <Select value={form.type} onValueChange={v => setForm(f => ({ ...f, type: v }))}>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-[#1a1a2e] border-white/10 text-white">
                    {TYPES.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label className="text-white/70 mb-1.5 block text-sm">Live Preview URL (optional)</Label>
              <Input value={form.previewUrl} onChange={e => setForm(f => ({ ...f, previewUrl: e.target.value }))} placeholder="https://your-demo.com" className="bg-white/5 border-white/10 text-white placeholder:text-white/30 text-base" />
            </div>
            <div>
              <Label className="text-white/70 mb-1.5 block text-sm">Tags (comma separated)</Label>
              <Input value={form.tags} onChange={e => setForm(f => ({ ...f, tags: e.target.value }))} placeholder="react, tailwind, dark-mode, responsive" className="bg-white/5 border-white/10 text-white placeholder:text-white/30 text-base" />
            </div>
          </div>

          {/* Project File */}
          <div className="bg-white/5 rounded-2xl p-5 border border-white/10 space-y-4">
            <h2 className="font-semibold">Project File</h2>
            <div>
              <Label className="text-white/70 mb-2 block text-sm">Upload ZIP File</Label>
              {form.fileUrl && !uploadingFile ? (
                <div className="flex items-center gap-3 bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-3">
                  <CheckCircle className="w-5 h-5 text-yellow-400 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-yellow-400 font-medium">File uploaded successfully!</p>
                    <p className="text-xs text-white/40 truncate">{form.fileUrl}</p>
                  </div>
                  <button type="button" onClick={() => { setForm(f => ({ ...f, fileUrl: '' })); setUploadProgress(0) }} className="text-white/40 hover:text-white p-1"><X className="w-4 h-4" /></button>
                </div>
              ) : uploadingFile ? (
                <div className="bg-white/5 border border-white/10 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Loader2 className="w-4 h-4 text-yellow-400 animate-spin" />
                    <span className="text-sm text-white/70">Uploading... {uploadProgress}%</span>
                  </div>
                  <div className="w-full bg-white/10 rounded-full h-2">
                    <div className="bg-yellow-500 h-2 rounded-full transition-all" style={{ width: `${uploadProgress}%` }} />
                  </div>
                </div>
              ) : (
                <label className="flex flex-col items-center justify-center w-full py-8 rounded-xl border-2 border-dashed border-white/20 cursor-pointer hover:border-yellow-400 hover:bg-yellow-500/5 transition-all">
                  <FileArchive className="w-10 h-10 text-white/20 mb-2" />
                  <p className="text-white/50 font-medium">Choose ZIP File</p>
                  <p className="text-white/30 text-xs mt-1">ZIP, RAR, 7Z, TAR supported</p>
                  <input type="file" className="hidden" accept=".zip,.rar,.7z,.tar,.gz" onChange={handleFileUpload} />
                </label>
              )}
            </div>
            <div>
              <Label className="text-white/70 mb-1.5 block text-sm">Or enter file URL</Label>
              <Input value={form.fileUrl} onChange={e => setForm(f => ({ ...f, fileUrl: e.target.value }))} placeholder="https://github.com/user/repo/archive/main.zip" className="bg-white/5 border-white/10 text-white placeholder:text-white/30 text-sm" />
            </div>
          </div>

          {/* Screenshots */}
          <div className="bg-white/5 rounded-2xl p-5 border border-white/10 space-y-3">
            <h2 className="font-semibold">Screenshots (max 6)</h2>
            <p className="text-xs text-white/30">Add project screenshots — shown in the project gallery.</p>
            <div className="flex flex-wrap gap-2">
              {screenshotPreviews.map((s, i) => (
                <div key={i} className="relative w-24 sm:w-28 h-20 rounded-lg overflow-hidden border border-white/10">
                  <img src={s} alt={`ss${i}`} className="w-full h-full object-cover" />
                  <button type="button" onClick={() => removeScreenshot(i)} className="absolute top-1 right-1 bg-black/60 rounded-full p-0.5 hover:bg-red-600">
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ))}
              {form.screenshots.length < 6 && (
                <label className="w-24 sm:w-28 h-20 flex flex-col items-center justify-center rounded-lg border-2 border-dashed border-white/20 cursor-pointer hover:border-yellow-400 transition-all">
                  {uploadingScreenshot ? <Loader2 className="w-5 h-5 text-white/40 animate-spin" /> : <><ImageIcon className="w-5 h-5 text-white/30 mb-1" /><span className="text-xs text-white/30">Add</span></>}
                  <input type="file" className="hidden" accept="image/*" multiple onChange={handleScreenshotUpload} />
                </label>
              )}
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-3">
            <Button type="submit" disabled={loading} className="bg-yellow-600 hover:bg-yellow-700 flex-1 h-12 text-base">
              {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Submitting...</> : <><Upload className="w-4 h-4 mr-2" /> Submit Project</>}
            </Button>
            <Link href="/code" className="w-full sm:w-auto">
              <Button type="button" variant="outline" className="border-white/20 hover:bg-white/10 h-12 w-full">Cancel</Button>
            </Link>
          </div>
          <p className="text-xs text-white/30 text-center">Project will be published after admin review. Make sure the code is clean and original.</p>
        </form>
      </main>
      <Footer />
    </div>
  )
}
