'use client'

import { useState, useEffect } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Code2, Download, Heart, Share2, ExternalLink, AlertCircle, Globe, FileCode } from 'lucide-react'
import { useSession } from 'next-auth/react'
import { formatDistanceToNow } from 'date-fns'
import Link from 'next/link'
import { toast } from 'sonner'
import { useParams } from 'next/navigation'

interface CodeProject {
  id: string
  title: string
  description?: string
  shortDesc?: string
  language: string
  type: string
  fileUrl?: string
  previewUrl?: string
  screenshots: any[]
  tags: any[]
  downloads: number
  likes: number
  status: string
  createdAt: string
  author: { id: string; username: string; avatar?: string; isVerified: boolean; bio?: string }
  _count: { codeLikes: number }
}

const LANGUAGE_COLORS: Record<string, string> = {
  JavaScript: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
  TypeScript: 'bg-blue-500/20 text-blue-400 border-blue-500/30',
  HTML: 'bg-orange-500/20 text-orange-400 border-orange-500/30',
  CSS: 'bg-purple-500/20 text-purple-400 border-purple-500/30',
  Python: 'bg-green-500/20 text-green-400 border-green-500/30',
}

export default function CodeDetailPage() {
  const params = useParams()
  const id = params.id as string
  const { data: session } = useSession()
  const [project, setProject] = useState<CodeProject | null>(null)
  const [loading, setLoading] = useState(true)
  const [userLiked, setUserLiked] = useState(false)
  const [likesCount, setLikesCount] = useState(0)
  const [activeScreenshot, setActiveScreenshot] = useState(0)

  useEffect(() => {
    if (id) fetchProject()
  }, [id])

  const fetchProject = async () => {
    try {
      const res = await fetch(`/api/code/${id}`)
      if (res.ok) {
        const data = await res.json()
        setProject(data.project)
        setUserLiked(data.userLiked)
        setLikesCount(data.project.likes || 0)
      }
    } catch {}
    setLoading(false)
  }

  const handleLike = async () => {
    if (!session) { toast.error('Sign in to like projects'); return }
    try {
      const res = await fetch(`/api/code/${id}/like`, { method: 'POST' })
      if (res.ok) {
        const data = await res.json()
        setUserLiked(data.liked)
        setLikesCount(prev => data.liked ? prev + 1 : prev - 1)
      }
    } catch {}
  }

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href)
    toast.success('Link copied!')
  }

  const handleDownload = () => {
    if (project?.fileUrl) {
      window.open(project.fileUrl, '_blank')
    } else {
      toast.info('No download file available')
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] text-white">
        <Navbar />
        <div className="container mx-auto px-4 py-8 animate-pulse">
          <div className="h-8 bg-white/5 rounded w-1/2 mb-4" />
          <div className="h-4 bg-white/5 rounded w-3/4" />
        </div>
        <Footer />
      </div>
    )
  }

  if (!project) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] text-white">
        <Navbar />
        <div className="flex items-center justify-center min-h-[50vh]">
          <div className="text-center">
            <AlertCircle className="w-16 h-16 text-red-400 mx-auto mb-4" />
            <h2 className="text-2xl font-bold">Project not found</h2>
            <Link href="/code"><Button className="mt-4" variant="outline">Browse Code</Button></Link>
          </div>
        </div>
        <Footer />
      </div>
    )
  }

  const screenshots = Array.isArray(project.screenshots) ? project.screenshots as string[] : []

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
          {/* Main */}
          <div className="xl:col-span-2 space-y-6">
            {/* Title & badges */}
            <div>
              <div className="flex flex-wrap items-center gap-3 mb-2">
                <Badge className={`${LANGUAGE_COLORS[project.language] || 'bg-white/10 text-white/60'} border`}>{project.language}</Badge>
                <Badge className="bg-white/10 text-white/60 border-white/10">{project.type}</Badge>
              </div>
              <h1 className="text-3xl font-bold mb-2">{project.title}</h1>
              {project.shortDesc && <p className="text-white/60 text-lg">{project.shortDesc}</p>}
            </div>

            {/* Author */}
            <div className="flex items-center gap-3">
              <Link href={`/profile/${project.author.username}`}>
                <Avatar className="w-10 h-10"><AvatarImage src={project.author.avatar} /><AvatarFallback className="bg-yellow-700">{project.author.username[0].toUpperCase()}</AvatarFallback></Avatar>
              </Link>
              <div>
                <Link href={`/profile/${project.author.username}`} className="font-medium hover:text-yellow-400 flex items-center gap-1">
                  {project.author.username}
                  {project.author.isVerified && <Badge className="bg-blue-600 text-xs px-1">✓</Badge>}
                </Link>
                <p className="text-xs text-white/40">{formatDistanceToNow(new Date(project.createdAt), { addSuffix: true })}</p>
              </div>
            </div>

            {/* Actions */}
            <div className="flex flex-wrap gap-3">
              <Button onClick={handleDownload} className="bg-yellow-600 hover:bg-yellow-700 gap-2">
                <Download className="w-4 h-4" /> Download
              </Button>
              {project.previewUrl && (
                <a href={project.previewUrl} target="_blank" rel="noopener noreferrer">
                  <Button variant="outline" className="border-white/20 hover:bg-white/10 gap-2">
                    <Globe className="w-4 h-4" /> Live Preview
                  </Button>
                </a>
              )}
              <Button onClick={handleLike} variant="outline"
                className={`border-white/20 gap-2 ${userLiked ? 'bg-red-600/20 border-red-500 text-red-400' : 'hover:bg-white/10'}`}>
                <Heart className={`w-4 h-4 ${userLiked ? 'fill-red-400' : ''}`} /> {likesCount}
              </Button>
              <Button onClick={handleShare} variant="outline" className="border-white/20 hover:bg-white/10 gap-2">
                <Share2 className="w-4 h-4" /> Share
              </Button>
            </div>

            {/* Screenshots */}
            {screenshots.length > 0 && (
              <div>
                <h2 className="text-lg font-semibold mb-3">Screenshots</h2>
                <div className="rounded-xl overflow-hidden border border-white/10">
                  <img src={screenshots[activeScreenshot]} alt={`Screenshot ${activeScreenshot + 1}`} className="w-full max-h-96 object-contain bg-black" />
                </div>
                {screenshots.length > 1 && (
                  <div className="flex gap-2 mt-3 overflow-x-auto pb-1">
                    {screenshots.map((s, i) => (
                      <button key={i} onClick={() => setActiveScreenshot(i)}
                        className={`flex-shrink-0 w-20 h-14 rounded-lg overflow-hidden border-2 transition-all ${i === activeScreenshot ? 'border-yellow-500' : 'border-white/10 opacity-60 hover:opacity-100'}`}>
                        <img src={s} alt="" className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Description */}
            {project.description && (
              <div>
                <h2 className="text-lg font-semibold mb-3">About This Project</h2>
                <div className="bg-white/5 rounded-xl p-5 border border-white/10">
                  <p className="text-white/70 leading-relaxed whitespace-pre-wrap">{project.description}</p>
                </div>
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            {/* Project Info */}
            <div className="bg-white/5 rounded-xl p-4 border border-white/10">
              <h3 className="font-semibold mb-3 flex items-center gap-2"><FileCode className="w-4 h-4" /> Project Info</h3>
              <dl className="space-y-2 text-sm">
                <div className="flex justify-between"><dt className="text-white/50">Language</dt><dd className="text-white/80">{project.language}</dd></div>
                <div className="flex justify-between"><dt className="text-white/50">Type</dt><dd className="text-white/80">{project.type}</dd></div>
                <div className="flex justify-between"><dt className="text-white/50">Downloads</dt><dd className="text-white/80">{project.downloads.toLocaleString()}</dd></div>
                <div className="flex justify-between"><dt className="text-white/50">Likes</dt><dd className="text-white/80">{likesCount}</dd></div>
                <div className="flex justify-between"><dt className="text-white/50">Uploaded</dt><dd className="text-white/80">{formatDistanceToNow(new Date(project.createdAt), { addSuffix: true })}</dd></div>
              </dl>
            </div>

            {/* Tags */}
            {project.tags && Array.isArray(project.tags) && (project.tags as string[]).length > 0 && (
              <div className="bg-white/5 rounded-xl p-4 border border-white/10">
                <h3 className="font-semibold mb-3">Tags</h3>
                <div className="flex flex-wrap gap-1.5">
                  {(project.tags as string[]).map(tag => (
                    <Badge key={tag} className="bg-white/10 text-white/60 hover:bg-white/15">#{tag}</Badge>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}
