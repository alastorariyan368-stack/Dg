'use client'

import { useState, useEffect } from 'react'
import { use } from 'react'
import { useRouter } from 'next/navigation'
import { useSession } from 'next-auth/react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Badge } from '@/components/ui/badge'
import { AlertCircle, ArrowLeft, Bitcoin, Building2, CheckCircle2, Copy, Globe, HardDrive, Loader2, Server, Smartphone, Wallet } from 'lucide-react'
import Link from 'next/link'

interface Plan {
  id: string
  name: string
  description: string
  price: number
  features?: string[]
  specs?: Record<string, any>
  isActive: boolean
  sortOrder: number
}

interface CheckoutPageProps {
  params: Promise<{
    planId: string
  }>
}

const METHOD_STYLE: Record<string, any> = {
  nagad: { icon: Smartphone, border: 'border-orange-500/30', bg: 'bg-orange-500/10', text: 'text-orange-300', badge: 'bg-orange-500/20 text-orange-300 border-orange-500/30' },
  bkash: { icon: Smartphone, border: 'border-pink-500/30', bg: 'bg-pink-500/10', text: 'text-pink-300', badge: 'bg-pink-500/20 text-pink-300 border-pink-500/30' },
  binance: { icon: Bitcoin, border: 'border-yellow-500/30', bg: 'bg-yellow-500/10', text: 'text-yellow-300', badge: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30' },
  bank: { icon: Building2, border: 'border-blue-500/30', bg: 'bg-blue-500/10', text: 'text-blue-300', badge: 'bg-blue-500/20 text-blue-300 border-blue-500/30' },
  paypal: { icon: Globe, border: 'border-sky-500/30', bg: 'bg-sky-500/10', text: 'text-sky-300', badge: 'bg-sky-500/20 text-sky-300 border-sky-500/30' },
}

const formatMb = (value?: number | string) => {
  const numeric = Number(value || 0)
  if (!numeric) return '-'
  if (numeric >= 1024) return `${Number((numeric / 1024).toFixed(1))} GB`
  return `${numeric} MB`
}

export default function CheckoutPage({ params: paramsProm }: CheckoutPageProps) {
  const { planId } = use(paramsProm)
  const { data: session, status } = useSession()
  const router = useRouter()
  const [plan, setPlan] = useState<Plan | null>(null)
  const [step, setStep] = useState<'method' | 'payment' | 'success'>('method')
  const [methods, setMethods] = useState<any[]>([])
  const [methodsLoading, setMethodsLoading] = useState(true)
  const [selectedMethod, setSelectedMethod] = useState('')
  const [paymentInfo, setPaymentInfo] = useState<any>(null)
  const [transactionId, setTransactionId] = useState('')
  const [transactionType, setTransactionType] = useState('Send Money')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [createdOrderId, setCreatedOrderId] = useState('')

  useEffect(() => {
    if (status === 'authenticated') {
      fetchPlan()
      fetchMethods()
    } else if (status === 'unauthenticated') {
      router.push('/auth/signin')
    }
  }, [status])

  const fetchPlan = async () => {
    try {
      const res = await fetch('/api/admin/plans?public=true')
      const data = await res.json()
      const found = Array.isArray(data.plans)
        ? data.plans.find((p: Plan) => p.id === planId)
        : null
      setPlan(found || null)
    } catch (err) {
      console.error('Failed to load plan', err)
    }
  }

  const fetchMethods = async () => {
    setMethodsLoading(true)
    try {
      const res = await fetch('/api/payment/deposit-info')
      const data = await res.json()
      setMethods(data.methods || [])
    } catch (err) {
      console.error('Failed to load payment methods', err)
      setMethods([])
    } finally {
      setMethodsLoading(false)
    }
  }

  const selectMethod = async (method: string) => {
    setSelectedMethod(method)
    setLoading(true)
    setError('')
    try {
      const res = await fetch('/api/payment/deposit-info', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ method })
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed to load payment info')
      setPaymentInfo(data)
      setStep('payment')
    } catch (err: any) {
      setError(err.message || 'Something went wrong')
      setSelectedMethod('')
    } finally {
      setLoading(false)
    }
  }

  const submitOrderPayment = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!plan || !selectedMethod) return
    if (!transactionId.trim()) {
      setError('Please enter your transaction ID')
      return
    }

    setLoading(true)
    setError('')

    try {
      const res = await fetch('/api/vps-orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          planId: plan.id,
          paymentMethod: selectedMethod,
          amount: plan.price,
          osVersion: plan.specs?.osVersion
        })
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Unable to create order')

      const payRes = await fetch(`/api/vps-orders/${data.order.id}/payment`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          transactionRef: `${transactionId.trim()}${transactionType ? ` (${transactionType})` : ''}`
        })
      })
      const payData = await payRes.json().catch(() => ({}))
      if (!payRes.ok) throw new Error(payData.error || 'Payment submission failed')

      setCreatedOrderId(data.order.id)
      setStep('success')
    } catch (err: any) {
      setError(err.message || 'Something went wrong')
    } finally {
      setLoading(false)
    }
  }

  if (status === 'loading' || !plan) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
        <Footer />
      </div>
    )
  }

  const copy = (text: string) => navigator.clipboard.writeText(text).catch(() => {})
  const style = METHOD_STYLE[selectedMethod] || METHOD_STYLE.bank
  const isHost = plan.specs?.serverType === 'host'

  return (
    <div className="min-h-screen flex flex-col bg-[#060611] text-white">
      <Navbar />
      <div className="flex-1 container mx-auto px-4 py-10">
        <div className="mx-auto grid max-w-6xl gap-6 lg:grid-cols-[1fr_380px]">
          <div className="space-y-6">
            <div className="rounded-3xl border border-white/10 bg-gradient-to-br from-cyan-500/10 via-purple-500/10 to-transparent p-6">
              <Link href="/vps" className="mb-5 inline-flex items-center gap-2 text-sm text-white/45 hover:text-white">
                <ArrowLeft className="h-4 w-4" />
                Back to plans
              </Link>
              <div className="flex items-start gap-4">
                <div className={`flex h-14 w-14 items-center justify-center rounded-2xl border ${isHost ? 'border-purple-400/30 bg-purple-500/10' : 'border-cyan-400/30 bg-cyan-500/10'}`}>
                  {isHost ? <HardDrive className="h-7 w-7 text-purple-200" /> : <Server className="h-7 w-7 text-cyan-200" />}
                </div>
                <div>
                  <Badge variant="outline" className={isHost ? 'border-purple-400/30 bg-purple-500/10 text-purple-200' : 'border-cyan-400/30 bg-cyan-500/10 text-cyan-200'}>
                    {isHost ? 'Host / Pterodactyl' : 'VPS / GFX Panel'}
                  </Badge>
                  <h1 className="mt-3 text-4xl font-black">Checkout: {plan.name}</h1>
                  <p className="mt-2 text-white/55">Use the same new deposit payment system to pay for this order.</p>
                </div>
              </div>
            </div>

            {error && (
              <Alert className="border-red-500/30 bg-red-500/10">
                <AlertCircle className="h-4 w-4 text-red-300" />
                <AlertDescription className="text-red-200">{error}</AlertDescription>
              </Alert>
            )}

            {step === 'method' && (
              <div className="rounded-3xl border border-white/10 bg-white/[0.035] p-6">
                <div className="mb-5">
                  <h2 className="text-2xl font-black">Select payment method</h2>
                  <p className="text-sm text-white/45">Enabled methods are loaded from Admin Payment settings.</p>
                </div>

                {methodsLoading ? (
                  <div className="flex justify-center py-16"><Loader2 className="h-7 w-7 animate-spin text-cyan-300" /></div>
                ) : methods.length === 0 ? (
                  <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-8 text-center text-white/45">No payment methods configured. Contact support.</div>
                ) : (
                  <div className="grid gap-3 sm:grid-cols-2">
                    {methods.map((method) => {
                      const methodStyle = METHOD_STYLE[method.id] || METHOD_STYLE.bank
                      const Icon = methodStyle.icon
                      const activeLoading = loading && selectedMethod === method.id
                      return (
                        <button
                          key={method.id}
                          type="button"
                          disabled={loading}
                          onClick={() => selectMethod(method.id)}
                          className={`relative rounded-2xl border p-5 text-left transition hover:brightness-125 ${methodStyle.border} ${methodStyle.bg}`}
                        >
                          <div className="mb-4 flex items-center justify-between">
                            <Icon className={`h-6 w-6 ${methodStyle.text}`} />
                            <Badge className={methodStyle.badge}>{method.badge}</Badge>
                          </div>
                          <p className={`font-bold ${methodStyle.text}`}>{method.label}</p>
                          <p className="mt-1 text-xs text-white/40">Click to view payment details</p>
                          {activeLoading && <div className="absolute inset-0 flex items-center justify-center rounded-2xl bg-black/50"><Loader2 className="h-5 w-5 animate-spin" /></div>}
                        </button>
                      )
                    })}
                  </div>
                )}
              </div>
            )}

            {step === 'payment' && paymentInfo && (
              <form onSubmit={submitOrderPayment} className="rounded-3xl border border-white/10 bg-white/[0.035] p-6 space-y-5">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <h2 className="text-2xl font-black">Pay via {paymentInfo.methodName}</h2>
                    <p className="text-sm text-white/45">Send payment first, then submit your transaction ID.</p>
                  </div>
                  <Button type="button" variant="outline" onClick={() => setStep('method')} className="border-white/10 bg-white/5 text-white hover:bg-white/10">
                    Change
                  </Button>
                </div>

                {paymentInfo.instruction && (
                  <div className="rounded-2xl border border-emerald-500/20 bg-emerald-500/10 p-4 text-sm text-emerald-200">
                    {paymentInfo.instruction}
                  </div>
                )}

                <div className="rounded-2xl border border-white/10 bg-black/20 p-4 space-y-3">
                  {paymentInfo.type === 'mobile' && paymentInfo.phoneNumber && <PaymentCopyRow label="Send Money Number" value={paymentInfo.phoneNumber} onCopy={copy} />}
                  {paymentInfo.type === 'crypto' && paymentInfo.binanceId && <PaymentCopyRow label="Binance Pay ID" value={paymentInfo.binanceId} onCopy={copy} />}
                  {paymentInfo.type === 'paypal' && paymentInfo.email && <PaymentCopyRow label="PayPal Email" value={paymentInfo.email} onCopy={copy} />}
                  {paymentInfo.type === 'bank' && paymentInfo.bankDetails && Object.entries(paymentInfo.bankDetails).filter(([, value]) => value).map(([key, value]) => (
                    <PaymentCopyRow key={key} label={key.replace(/([A-Z])/g, ' $1')} value={String(value)} onCopy={copy} />
                  ))}
                </div>

                {paymentInfo.qr && (
                  <div className="flex justify-center rounded-2xl border border-white/10 bg-white p-4">
                    <img src={paymentInfo.qr} alt="Payment QR code" className="h-40 w-40 object-contain" />
                  </div>
                )}

                <div className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <Label>Transaction Type</Label>
                    <Input value={transactionType} onChange={(e) => setTransactionType(e.target.value)} placeholder="Send Money" className="bg-black/20 border-white/10" />
                  </div>
                  <div>
                    <Label>Transaction ID *</Label>
                    <Input value={transactionId} onChange={(e) => setTransactionId(e.target.value)} placeholder="Enter transaction ID" className="bg-black/20 border-white/10" />
                  </div>
                </div>

                <Button type="submit" disabled={loading} className="w-full bg-cyan-400 text-slate-950 hover:bg-cyan-300">
                  {loading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Submitting order...</> : 'Submit Payment & Create Order'}
                </Button>
              </form>
            )}

            {step === 'success' && (
              <div className="rounded-3xl border border-emerald-500/20 bg-emerald-500/10 p-8 text-center">
                <CheckCircle2 className="mx-auto mb-4 h-14 w-14 text-emerald-300" />
                <h2 className="text-3xl font-black">Order submitted successfully</h2>
                <p className="mt-2 text-white/55">Admin will review your payment and provision your service after approval.</p>
                <div className="mt-6 flex flex-wrap justify-center gap-3">
                  <Link href="/vps/orders"><Button className="bg-emerald-500 text-white hover:bg-emerald-400">View Orders</Button></Link>
                  {createdOrderId && <Link href="/services"><Button variant="outline" className="border-white/10 bg-white/5 text-white hover:bg-white/10">My Services</Button></Link>}
                </div>
              </div>
            )}
          </div>

          <aside className="lg:sticky lg:top-6 lg:self-start">
            <div className="rounded-3xl border border-white/10 bg-white/[0.04] p-6">
              <div className="mb-5 flex items-center gap-3">
                <Wallet className="h-5 w-5 text-cyan-300" />
                <h3 className="text-xl font-black">Order Summary</h3>
              </div>
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-white/40">Plan</p>
                  <p className="text-lg font-bold">{plan.name}</p>
                </div>
                <div className="grid grid-cols-3 gap-2">
                  <div className="rounded-2xl border border-white/10 bg-black/20 p-3">
                    <p className="text-[10px] text-white/40">RAM</p>
                    <p className="font-bold">{formatMb(plan.specs?.ram)}</p>
                  </div>
                  <div className="rounded-2xl border border-white/10 bg-black/20 p-3">
                    <p className="text-[10px] text-white/40">CPU</p>
                    <p className="font-bold">{plan.specs?.cpu || '-'}%</p>
                  </div>
                  <div className="rounded-2xl border border-white/10 bg-black/20 p-3">
                    <p className="text-[10px] text-white/40">Disk</p>
                    <p className="font-bold">{formatMb(plan.specs?.disk)}</p>
                  </div>
                </div>
                <div className="rounded-2xl border border-cyan-500/20 bg-cyan-500/10 p-4">
                  <p className="text-sm text-cyan-200">Total Payable</p>
                  <p className="text-4xl font-black">${plan.price}</p>
                </div>
              </div>
            </div>
          </aside>
        </div>
      </div>
      <Footer />
    </div>
  )
}

function PaymentCopyRow({ label, value, onCopy }: { label: string; value: string; onCopy: (text: string) => void }) {
  const [copied, setCopied] = useState(false)
  return (
    <div className="flex items-center justify-between gap-3 border-b border-white/[0.06] py-2 last:border-0">
      <div>
        <p className="text-[11px] uppercase tracking-widest text-white/35">{label}</p>
        <p className="break-all font-mono text-sm font-semibold text-white">{value}</p>
      </div>
      <button
        type="button"
        onClick={() => {
          onCopy(value)
          setCopied(true)
          setTimeout(() => setCopied(false), 1500)
        }}
        className="rounded-xl border border-white/10 bg-white/[0.06] px-3 py-2 text-xs text-white/60 hover:text-white"
      >
        {copied ? <CheckCircle2 className="h-4 w-4 text-emerald-300" /> : <Copy className="h-4 w-4" />}
      </button>
    </div>
  )
}
