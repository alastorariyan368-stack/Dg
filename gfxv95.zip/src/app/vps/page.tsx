'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Check, Cpu, Database, HardDrive, Loader2, MapPin, Server, ShieldCheck, Sparkles, Timer, Zap } from 'lucide-react'
import Link from 'next/link'

interface Plan {
  id: string
  name: string
  description: string
  price: number
  features?: string[]
  specs?: Record<string, any>
  isActive: boolean
  sortOrder: number
}

const formatMb = (value?: number | string) => {
  const numeric = Number(value || 0)
  if (!numeric) return '-'
  if (numeric >= 1024) return `${Number((numeric / 1024).toFixed(1))} GB`
  return `${numeric} MB`
}

const getProviderLabel = (plan: Plan) => plan.specs?.serverType === 'host' ? 'Game Host / Pterodactyl' : 'VPS / GFX Panel'

const getPanelTarget = (plan: Plan) => {
  if (plan.specs?.serverType === 'host') {
    return [
      plan.specs?.pteroLocationName || (plan.specs?.pteroLocationId ? `Location ${plan.specs.pteroLocationId}` : ''),
      plan.specs?.pteroNestName || (plan.specs?.pteroNestId ? `Nest ${plan.specs.pteroNestId}` : ''),
      plan.specs?.pteroEggName || (plan.specs?.pteroEggId ? `Egg ${plan.specs.pteroEggId}` : '')
    ].filter(Boolean).join(' / ') || 'Configured during provisioning'
  }

  return plan.specs?.gfxNodeName || (plan.specs?.gfxNodeId ? `Node ${plan.specs.gfxNodeId}` : 'Configured during provisioning')
}

export default function VPSPage() {
  const { data: session } = useSession()
  const [plans, setPlans] = useState<Plan[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedPlan, setSelectedPlan] = useState<Plan | null>(null)

  useEffect(() => {
    fetchPlans()
  }, [])

  const fetchPlans = async () => {
    try {
      const response = await fetch('/api/admin/plans?public=true')
      if (response.ok) {
        const data = await response.json()
        setPlans(Array.isArray(data.plans) ? data.plans : [])
      }
    } catch (error) {
      console.error('Failed to fetch plans:', error)
    } finally {
      setLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col bg-[#060611] text-white">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin text-cyan-300" />
        </div>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#060611] text-white">
      <Navbar />
      
      <main className="flex-1">
        <section className="relative overflow-hidden border-b border-white/10">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(34,211,238,0.22),transparent_34%),radial-gradient(circle_at_top_right,rgba(168,85,247,0.2),transparent_34%)]" />
          <div className="relative container mx-auto px-4 py-16 md:py-24">
            <div className="mx-auto max-w-4xl text-center">
              <Badge className="mb-5 rounded-full bg-cyan-500/10 text-cyan-200 border border-cyan-400/30 hover:bg-cyan-500/10">
                <Sparkles className="mr-2 h-3.5 w-3.5" />
                Premium VPS & Hosting Marketplace
              </Badge>
              <h1 className="text-4xl md:text-6xl font-black tracking-tight">
                Choose a server plan with full specs before checkout
              </h1>
              <p className="mt-5 text-lg text-white/60">
                Click any plan to view RAM, CPU, disk, OS, provider, panel target, expiry and all admin-configured features.
              </p>
              <div className="mt-8 flex flex-wrap justify-center gap-3">
                {session?.user && (
                  <Link href="/vps/orders">
                    <Button variant="outline" className="border-white/15 bg-white/5 text-white hover:bg-white/10">
                      My Orders
                    </Button>
                  </Link>
                )}
                <Link href="/services">
                  <Button className="bg-cyan-500 text-slate-950 hover:bg-cyan-400">
                    My Services
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        <section className="container mx-auto px-4 py-12">
          {plans.length === 0 ? (
            <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-12 text-center">
              <Server className="mx-auto mb-4 h-12 w-12 text-white/30" />
              <p className="text-white/60">No plans available at this time.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {plans.map((plan, idx) => {
                const planImage = plan.specs?.planGif || plan.specs?.planImage
                const isHost = plan.specs?.serverType === 'host'

                return (
                  <button
                    key={plan.id}
                    type="button"
                    onClick={() => setSelectedPlan(plan)}
                    className={`group relative text-left rounded-3xl border bg-white/[0.035] overflow-hidden transition duration-300 hover:-translate-y-1 hover:bg-white/[0.06] ${idx === 1 ? 'border-cyan-400/50 shadow-2xl shadow-cyan-500/10' : 'border-white/10'}`}
                  >
                    {idx === 1 && (
                      <Badge className="absolute right-5 top-5 z-20 bg-cyan-400 text-slate-950 hover:bg-cyan-400">
                        Popular
                      </Badge>
                    )}
                    <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition bg-gradient-to-br from-cyan-500/10 via-transparent to-purple-500/10" />
                    {planImage ? (
                      <div className="relative h-44 overflow-hidden bg-white/5">
                        <img
                          src={planImage}
                          alt={plan.name}
                          className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
                          onError={(e) => {
                            (e.target as HTMLImageElement).style.display = 'none'
                          }}
                        />
                      </div>
                    ) : (
                      <div className={`relative h-32 bg-gradient-to-br ${isHost ? 'from-purple-500/25 to-fuchsia-500/10' : 'from-cyan-500/25 to-blue-500/10'} flex items-center justify-center`}>
                        {isHost ? <HardDrive className="h-12 w-12 text-purple-200" /> : <Server className="h-12 w-12 text-cyan-200" />}
                      </div>
                    )}

                    <div className="relative p-6">
                      <div className="flex flex-wrap gap-2">
                        <Badge variant="outline" className={isHost ? 'border-purple-400/30 bg-purple-500/10 text-purple-200' : 'border-cyan-400/30 bg-cyan-500/10 text-cyan-200'}>
                          {getProviderLabel(plan)}
                        </Badge>
                        {plan.specs?.osVersion && <Badge variant="outline" className="border-white/15 text-white/70">{plan.specs.osVersion}</Badge>}
                      </div>

                      <div className="mt-5">
                        <h3 className="text-2xl font-black">{plan.name}</h3>
                        <p className="mt-2 line-clamp-2 text-sm text-white/55">{plan.description}</p>
                      </div>

                      <div className="mt-6 flex items-end justify-between">
                        <div>
                          <p className="text-4xl font-black">${plan.price}</p>
                          <p className="text-xs uppercase tracking-widest text-white/35">per month</p>
                        </div>
                        <span className="text-sm font-semibold text-cyan-200">View details</span>
                      </div>

                      <div className="mt-6 grid grid-cols-3 gap-2">
                        <div className="rounded-2xl border border-white/10 bg-black/20 p-3">
                          <Database className="mb-2 h-4 w-4 text-cyan-300" />
                          <p className="text-[11px] text-white/40">RAM</p>
                          <p className="font-bold">{formatMb(plan.specs?.ram)}</p>
                        </div>
                        <div className="rounded-2xl border border-white/10 bg-black/20 p-3">
                          <Cpu className="mb-2 h-4 w-4 text-purple-300" />
                          <p className="text-[11px] text-white/40">CPU</p>
                          <p className="font-bold">{plan.specs?.cpu || '-'}%</p>
                        </div>
                        <div className="rounded-2xl border border-white/10 bg-black/20 p-3">
                          <HardDrive className="mb-2 h-4 w-4 text-emerald-300" />
                          <p className="text-[11px] text-white/40">Disk</p>
                          <p className="font-bold">{formatMb(plan.specs?.disk)}</p>
                        </div>
                      </div>
                    </div>
                  </button>
                )
              })}
            </div>
          )}
        </section>
      </main>

      <Dialog open={!!selectedPlan} onOpenChange={(open) => !open && setSelectedPlan(null)}>
        <DialogContent className="max-h-[90vh] overflow-y-auto border-white/10 bg-[#080814] text-white sm:max-w-3xl">
          {selectedPlan && (
            <>
              <DialogHeader>
                <div className="flex flex-wrap gap-2 pr-8">
                  <Badge variant="outline" className={selectedPlan.specs?.serverType === 'host' ? 'border-purple-400/30 bg-purple-500/10 text-purple-200' : 'border-cyan-400/30 bg-cyan-500/10 text-cyan-200'}>
                    {getProviderLabel(selectedPlan)}
                  </Badge>
                  {selectedPlan.specs?.osVersion && <Badge variant="outline" className="border-white/15 text-white/70">{selectedPlan.specs.osVersion}</Badge>}
                </div>
                <DialogTitle className="text-3xl font-black">{selectedPlan.name}</DialogTitle>
                <DialogDescription className="text-white/60">{selectedPlan.description}</DialogDescription>
              </DialogHeader>

              <div className="grid gap-4 md:grid-cols-4">
                <div className="rounded-2xl border border-cyan-400/20 bg-cyan-500/10 p-4">
                  <Database className="mb-3 h-5 w-5 text-cyan-200" />
                  <p className="text-xs text-white/45">Memory</p>
                  <p className="text-xl font-black">{formatMb(selectedPlan.specs?.ram)}</p>
                </div>
                <div className="rounded-2xl border border-purple-400/20 bg-purple-500/10 p-4">
                  <Cpu className="mb-3 h-5 w-5 text-purple-200" />
                  <p className="text-xs text-white/45">CPU Limit</p>
                  <p className="text-xl font-black">{selectedPlan.specs?.cpu || '-'}%</p>
                </div>
                <div className="rounded-2xl border border-emerald-400/20 bg-emerald-500/10 p-4">
                  <HardDrive className="mb-3 h-5 w-5 text-emerald-200" />
                  <p className="text-xs text-white/45">Storage</p>
                  <p className="text-xl font-black">{formatMb(selectedPlan.specs?.disk)}</p>
                </div>
                <div className="rounded-2xl border border-amber-400/20 bg-amber-500/10 p-4">
                  <Timer className="mb-3 h-5 w-5 text-amber-200" />
                  <p className="text-xs text-white/45">Validity</p>
                  <p className="text-xl font-black">{selectedPlan.specs?.expiresInDays || 30} Days</p>
                </div>
              </div>

              <div className="grid gap-4 md:grid-cols-2">
                <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
                  <h4 className="mb-4 flex items-center gap-2 font-bold"><MapPin className="h-4 w-4 text-cyan-300" />Provisioning Target</h4>
                  <div className="space-y-3 text-sm">
                    <div className="flex justify-between gap-4"><span className="text-white/45">Provider</span><span className="text-right font-semibold">{getProviderLabel(selectedPlan)}</span></div>
                    <div className="flex justify-between gap-4"><span className="text-white/45">Panel Config</span><span className="text-right font-semibold">{getPanelTarget(selectedPlan)}</span></div>
                    <div className="flex justify-between gap-4"><span className="text-white/45">Default OS</span><span className="text-right font-semibold">{selectedPlan.specs?.osVersion || '-'}</span></div>
                  </div>
                </div>
                <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
                  <h4 className="mb-4 flex items-center gap-2 font-bold"><ShieldCheck className="h-4 w-4 text-emerald-300" />Included Features</h4>
                  <div className="space-y-3">
                    {selectedPlan.features?.length ? selectedPlan.features.map((feature, index) => (
                      <div key={index} className="flex items-start gap-3 text-sm">
                        <Check className="mt-0.5 h-4 w-4 flex-shrink-0 text-emerald-300" />
                        <span>{feature}</span>
                      </div>
                    )) : <p className="text-sm text-white/45">No features listed.</p>}
                  </div>
                </div>
              </div>

              {Array.isArray(selectedPlan.specs?.availableOs) && selectedPlan.specs.availableOs.length > 0 && (
                <div className="rounded-2xl border border-white/10 bg-white/[0.03] p-5">
                  <h4 className="mb-3 flex items-center gap-2 font-bold"><Zap className="h-4 w-4 text-cyan-300" />Available OS Images</h4>
                  <div className="flex flex-wrap gap-2">
                    {selectedPlan.specs.availableOs.map((os: string) => (
                      <Badge key={os} variant="outline" className="border-white/15 text-white/70">{os}</Badge>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex flex-col gap-3 rounded-2xl border border-white/10 bg-gradient-to-r from-cyan-500/10 to-purple-500/10 p-5 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="text-3xl font-black">${selectedPlan.price}<span className="text-sm font-medium text-white/45"> / month</span></p>
                  <p className="text-sm text-white/50">After checkout, admin approval will auto-provision using this plan config.</p>
                </div>
                <Link href={`/vps/checkout/${selectedPlan.id}`}>
                  <Button className="w-full bg-cyan-400 text-slate-950 hover:bg-cyan-300 sm:w-auto">
                    Get Started
                  </Button>
                </Link>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      <Footer />
    </div>
  )
}
