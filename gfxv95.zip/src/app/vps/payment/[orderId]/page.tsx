'use client'

import { useState, useEffect } from 'react'
import { use } from 'react'
import { useRouter } from 'next/navigation'
import { useSession } from 'next-auth/react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Loader2 } from 'lucide-react'

interface Order {
  id: string
  plan: {
    id: string
    name: string
    price: number
  }
  amount: number
  paymentMethod: string
  status: string
  transactionRef?: string | null
}

interface PaymentProps {
  params: Promise<{
    orderId: string
  }>
}

export default function PaymentPage({ params: paramsProm }: PaymentProps) {
  const { orderId } = use(paramsProm)
  const { data: session, status } = useSession()
  const router = useRouter()

  const [order, setOrder] = useState<Order | null>(null)
  const [ref, setRef] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [message, setMessage] = useState('')

  useEffect(() => {
    if (status === 'authenticated') {
      fetchOrder()
    } else if (status === 'unauthenticated') {
      router.push('/auth/signin')
    }
  }, [status])

  const fetchOrder = async () => {
    try {
      const res = await fetch(`/api/vps-orders/${orderId}`)
      if (!res.ok) throw new Error('Failed to fetch order')
      const data = await res.json()
      setOrder(data.order)
    } catch (err) {
      console.error(err)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!order) return

    // if payment method is wallet we don't need a ref
    if (order.paymentMethod !== 'wallet' && !ref) {
      setError('Please enter transaction reference')
      return
    }

    setLoading(true)
    setError('')

    try {
      const res = await fetch(`/api/vps-orders/${orderId}/payment`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ transactionRef: ref })
      })
      if (!res.ok) throw new Error('Payment submission failed')
      const data = await res.json()
      setMessage('Payment info submitted successfully. Admin will review shortly.')
    } catch (err: any) {
      setError(err.message)
    } finally {
      setLoading(false)
    }
  }

  if (status === 'loading' || !order) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <div className="flex-1 container mx-auto px-4 py-16">
        <div className="max-w-md mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>Payment for {order.plan.name}</CardTitle>
              <CardDescription>
                Order amount: ${order.amount}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {message ? (
                <Alert className="mb-4">
                  <AlertDescription>{message}</AlertDescription>
                </Alert>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  {order.paymentMethod !== 'wallet' && (
                    <div>
                      <Label>Transaction Reference</Label>
                      <Input
                        value={ref}
                        onChange={(e) => setRef(e.target.value)}
                        placeholder="Enter txn reference"
                      />
                    </div>
                  )}

                  {error && (
                    <Alert variant="destructive">
                      <AlertDescription>{error}</AlertDescription>
                    </Alert>
                  )}

                  <Button type="submit" disabled={loading} className="w-full">
                    {loading ? 'Submitting...' : 'Submit'}
                  </Button>
                </form>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
      <Footer />
    </div>
  )
}
