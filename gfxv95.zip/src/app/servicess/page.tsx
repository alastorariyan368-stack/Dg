import { redirect } from 'next/navigation'

export default function ServicessAliasPage() {
  redirect('/services')
}
