import { redirect } from 'next/navigation'

export default function SrvicessAliasPage() {
  redirect('/services')
}
