'use client'

import { useState, useEffect } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Trophy, Crown, Medal, Star, Download, TrendingUp, Users, Package } from 'lucide-react'
import Link from 'next/link'

interface TopSeller {
  id: string
  username: string
  avatar?: string
  totalSales: number
  _count: { items: number }
}

interface TopItem {
  id: string
  title: string
  slug: string
  downloads: number
  views: number
  likes?: number
  price: number
  logo?: string
  author: { username: string; avatar?: string }
}

function RankBadge({ rank }: { rank: number }) {
  if (rank === 1) return (
    <div className="w-9 h-9 rounded-full bg-gradient-to-br from-yellow-400 to-amber-500 flex items-center justify-center shadow-lg shadow-yellow-500/30 flex-shrink-0">
      <Crown className="w-5 h-5 text-white" />
    </div>
  )
  if (rank === 2) return (
    <div className="w-9 h-9 rounded-full bg-gradient-to-br from-gray-300 to-slate-400 flex items-center justify-center shadow-lg shadow-gray-400/30 flex-shrink-0">
      <Medal className="w-5 h-5 text-white" />
    </div>
  )
  if (rank === 3) return (
    <div className="w-9 h-9 rounded-full bg-gradient-to-br from-amber-600 to-orange-700 flex items-center justify-center shadow-lg shadow-amber-700/30 flex-shrink-0">
      <Medal className="w-5 h-5 text-white" />
    </div>
  )
  return (
    <div className="w-9 h-9 rounded-full bg-white/[0.06] border border-white/10 flex items-center justify-center flex-shrink-0">
      <span className="text-sm font-bold text-white/50">{rank}</span>
    </div>
  )
}

function formatNum(n: number) {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`
  return String(n || 0)
}

export default function LeaderboardPage() {
  const [topSellers, setTopSellers] = useState<TopSeller[]>([])
  const [topItems, setTopItems] = useState<TopItem[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/leaderboard')
      .then(r => r.ok ? r.json() : { topSellers: [], topItems: [] })
      .then(d => {
        setTopSellers(d.topSellers || [])
        setTopItems(d.topItems || [])
      })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  return (
    <div className="min-h-screen bg-[#07070f] text-white">
      <Navbar />

      <div className="container mx-auto px-4 py-10 max-w-3xl">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-gradient-to-br from-yellow-400/20 to-amber-500/20 border border-yellow-500/20 mb-4">
            <Trophy className="w-8 h-8 text-yellow-400" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">Leaderboard</h1>
          <p className="text-white/50 text-sm">Top sellers and most downloaded items on GfxStore</p>
        </div>

        {/* Top 3 Sellers Podium */}
        {!loading && topSellers.length >= 3 && (
          <div className="flex items-end justify-center gap-4 mb-10">
            {/* 2nd place */}
            <div className="flex flex-col items-center gap-2">
              <Avatar className="w-14 h-14 border-2 border-gray-400/50">
                <AvatarImage src={topSellers[1]?.avatar} />
                <AvatarFallback className="bg-gradient-to-br from-gray-500 to-slate-600 text-white font-bold text-lg">
                  {topSellers[1]?.username?.[0]?.toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="text-center">
                <div className="text-xs font-semibold text-white/80 truncate max-w-[70px]">{topSellers[1]?.username}</div>
                <div className="text-[10px] text-white/40">৳{formatNum(topSellers[1]?.totalSales || 0)}</div>
              </div>
              <div className="w-16 h-20 bg-gradient-to-t from-gray-500/30 to-gray-400/10 border border-gray-400/20 rounded-t-lg flex items-center justify-center">
                <span className="text-2xl font-black text-gray-400">2</span>
              </div>
            </div>
            {/* 1st place */}
            <div className="flex flex-col items-center gap-2">
              <div className="relative">
                <Crown className="w-6 h-6 text-yellow-400 absolute -top-3 left-1/2 -translate-x-1/2" />
                <Avatar className="w-20 h-20 border-2 border-yellow-400/60 shadow-lg shadow-yellow-500/20">
                  <AvatarImage src={topSellers[0]?.avatar} />
                  <AvatarFallback className="bg-gradient-to-br from-yellow-500 to-amber-600 text-white font-bold text-2xl">
                    {topSellers[0]?.username?.[0]?.toUpperCase()}
                  </AvatarFallback>
                </Avatar>
              </div>
              <div className="text-center">
                <div className="text-sm font-bold text-white truncate max-w-[90px]">{topSellers[0]?.username}</div>
                <div className="text-xs text-yellow-400/80">৳{formatNum(topSellers[0]?.totalSales || 0)}</div>
              </div>
              <div className="w-20 h-28 bg-gradient-to-t from-yellow-500/30 to-yellow-400/10 border border-yellow-400/20 rounded-t-lg flex items-center justify-center">
                <span className="text-3xl font-black text-yellow-400">1</span>
              </div>
            </div>
            {/* 3rd place */}
            <div className="flex flex-col items-center gap-2">
              <Avatar className="w-14 h-14 border-2 border-amber-700/50">
                <AvatarImage src={topSellers[2]?.avatar} />
                <AvatarFallback className="bg-gradient-to-br from-amber-700 to-orange-800 text-white font-bold text-lg">
                  {topSellers[2]?.username?.[0]?.toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="text-center">
                <div className="text-xs font-semibold text-white/80 truncate max-w-[70px]">{topSellers[2]?.username}</div>
                <div className="text-[10px] text-white/40">৳{formatNum(topSellers[2]?.totalSales || 0)}</div>
              </div>
              <div className="w-16 h-14 bg-gradient-to-t from-amber-700/30 to-amber-600/10 border border-amber-700/20 rounded-t-lg flex items-center justify-center">
                <span className="text-2xl font-black text-amber-600">3</span>
              </div>
            </div>
          </div>
        )}

        <Tabs defaultValue="sellers" className="w-full">
          <TabsList className="w-full bg-white/[0.04] border border-white/[0.08] mb-6 h-11">
            <TabsTrigger value="sellers" className="flex-1 data-[state=active]:bg-violet-600/40 data-[state=active]:text-white gap-2">
              <Users className="w-4 h-4" /> Top Sellers
            </TabsTrigger>
            <TabsTrigger value="items" className="flex-1 data-[state=active]:bg-violet-600/40 data-[state=active]:text-white gap-2">
              <Package className="w-4 h-4" /> Top Items
            </TabsTrigger>
          </TabsList>

          <TabsContent value="sellers">
            {loading ? (
              <div className="space-y-3">
                {[...Array(8)].map((_, i) => (
                  <div key={i} className="h-16 rounded-xl bg-white/[0.03] animate-pulse" />
                ))}
              </div>
            ) : topSellers.length === 0 ? (
              <div className="text-center py-16 text-white/40">
                <Trophy className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p>No sellers yet. Be the first!</p>
              </div>
            ) : (
              <div className="space-y-2">
                {topSellers.map((seller, i) => (
                  <Link key={seller.id} href={`/profile/${seller.username}`}>
                    <div className={`flex items-center gap-4 p-4 rounded-xl border transition hover:bg-white/[0.04] ${i === 0 ? 'bg-yellow-500/5 border-yellow-500/15' : i === 1 ? 'bg-gray-500/5 border-gray-500/15' : i === 2 ? 'bg-amber-700/5 border-amber-700/15' : 'bg-white/[0.02] border-white/[0.06]'}`}>
                      <RankBadge rank={i + 1} />
                      <Avatar className="w-10 h-10 flex-shrink-0">
                        <AvatarImage src={seller.avatar} />
                        <AvatarFallback className="bg-gradient-to-br from-violet-600 to-cyan-600 text-white font-semibold">
                          {seller.username?.[0]?.toUpperCase()}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-white truncate">@{seller.username}</div>
                        <div className="text-xs text-white/40">{seller._count.items} items listed</div>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <div className="font-bold text-white">৳{formatNum(seller.totalSales)}</div>
                        <div className="text-[10px] text-white/40">total sales</div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="items">
            {loading ? (
              <div className="space-y-3">
                {[...Array(8)].map((_, i) => (
                  <div key={i} className="h-16 rounded-xl bg-white/[0.03] animate-pulse" />
                ))}
              </div>
            ) : topItems.length === 0 ? (
              <div className="text-center py-16 text-white/40">
                <TrendingUp className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p>No items yet.</p>
              </div>
            ) : (
              <div className="space-y-2">
                {topItems.map((item, i) => (
                  <Link key={item.id} href={`/items/${item.slug}`}>
                    <div className={`flex items-center gap-4 p-4 rounded-xl border transition hover:bg-white/[0.04] ${i === 0 ? 'bg-yellow-500/5 border-yellow-500/15' : i === 1 ? 'bg-gray-500/5 border-gray-500/15' : i === 2 ? 'bg-amber-700/5 border-amber-700/15' : 'bg-white/[0.02] border-white/[0.06]'}`}>
                      <RankBadge rank={i + 1} />
                      <div className="w-10 h-10 rounded-lg overflow-hidden bg-white/[0.06] flex-shrink-0">
                        {item.logo ? (
                          <img src={item.logo} alt={item.title} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full bg-gradient-to-br from-violet-600 to-cyan-600 flex items-center justify-center">
                            <Star className="w-4 h-4 text-white" />
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-semibold text-white truncate text-sm">{item.title}</div>
                        <div className="text-xs text-white/40">by @{item.author.username}</div>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <div className="flex items-center gap-1 text-white/70 text-sm font-medium">
                          <Download className="w-3.5 h-3.5" />
                          {formatNum(item.downloads)}
                        </div>
                        <div className="text-[10px] text-white/40">{item.price === 0 ? 'Free' : `৳${item.price}`}</div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      <Footer />
    </div>
  )
}
