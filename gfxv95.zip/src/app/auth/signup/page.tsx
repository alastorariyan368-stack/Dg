'use client'

import { Suspense, useState, useEffect } from 'react'
import { useRouter, useSearchParams } from 'next/navigation'
import { getProviders, signIn } from 'next-auth/react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Logo } from '@/components/logo'
import { Eye, EyeOff, Loader2, Zap, UserPlus, Check, Gift, Mail, RefreshCw, ShieldCheck } from 'lucide-react'

function GoogleIcon() {
  return (
    <svg className="w-4 h-4" viewBox="0 0 24 24">
      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
      <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
    </svg>
  )
}

function DiscordIcon() {
  return (
    <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
      <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057.101 18.08.114 18.102.13 18.116a19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/>
    </svg>
  )
}

function SignUpForm() {
  const [formData, setFormData] = useState({ email: '', username: '', password: '', confirmPassword: '', referralCode: '' })
  const [showPass, setShowPass] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  const [step, setStep] = useState<'form' | 'otp'>('form')
  const [otp, setOtp] = useState('')
  const [otpEmail, setOtpEmail] = useState('')
  const [resending, setResending] = useState(false)
  const [success, setSuccess] = useState('')
  const [authConfig, setAuthConfig] = useState<{ discordEnabled: boolean; googleEnabled: boolean }>({
    discordEnabled: false,
    googleEnabled: false
  })
  const router = useRouter()
  const searchParams = useSearchParams()

  useEffect(() => {
    fetch('/api/auth/check-providers')
      .then((r) => r.ok ? r.json() : null)
      .then((d) => {
        if (d) {
          setAuthConfig({ discordEnabled: !!d.discordEnabled, googleEnabled: !!d.googleEnabled })
        } else {
          return getProviders().then((p) => {
            setAuthConfig({ discordEnabled: !!p?.discord, googleEnabled: !!p?.google })
          })
        }
      })
      .catch(() => {})
  }, [])

  useEffect(() => {
    const ref = searchParams.get('ref')
    if (ref) setFormData(prev => ({ ...prev, referralCode: ref }))
  }, [searchParams])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError('')
    setSuccess('')

    if (!formData.email || !formData.username || !formData.password || !formData.confirmPassword) {
      setError('Please fill in all fields'); setIsLoading(false); return
    }
    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters'); setIsLoading(false); return
    }
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match'); setIsLoading(false); return
    }
    if (formData.username.length < 3) {
      setError('Username must be at least 3 characters'); setIsLoading(false); return
    }

    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: formData.email,
          username: formData.username,
          password: formData.password,
          referralCode: formData.referralCode || undefined
        })
      })
      const data = await res.json()
      if (!res.ok) {
        setError(data.error || 'Registration failed')
      } else if (data.requiresVerification) {
        setOtpEmail(data.email || formData.email)
        setStep('otp')
        setSuccess(data.message || 'Verification code sent to your email!')
      } else {
        // Direct account creation (no verification required)
        const result = await signIn('credentials', { email: formData.email, password: formData.password, redirect: false })
        if (result?.ok) { router.push('/'); router.refresh() }
        else router.push('/auth/signin')
      }
    } catch {
      setError('An error occurred. Please try again.')
    } finally {
      setIsLoading(false)
    }
  }

  const handleOtpSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    setError('')

    if (!otp || otp.length !== 6) {
      setError('Please enter the 6-digit verification code'); setIsLoading(false); return
    }

    try {
      const res = await fetch('/api/auth/verify-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: otpEmail, otp })
      })
      const data = await res.json()
      if (!res.ok) {
        setError(data.error || 'Verification failed')
      } else {
        // Account created, sign in
        setSuccess('Account created! Signing you in...')
        const result = await signIn('credentials', { email: otpEmail, password: formData.password, redirect: false })
        if (result?.ok) { router.push('/'); router.refresh() }
        else router.push('/auth/signin')
      }
    } catch {
      setError('Verification failed. Please try again.')
    } finally {
      setIsLoading(false)
    }
  }

  const handleResendOtp = async () => {
    setResending(true)
    setError('')
    try {
      const res = await fetch('/api/auth/verify-otp', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: otpEmail })
      })
      const data = await res.json()
      if (res.ok) setSuccess('New code sent! Check your inbox.')
      else setError(data.error || 'Failed to resend code')
    } catch {
      setError('Failed to resend code')
    } finally {
      setResending(false)
    }
  }

  const perks = ['Free account forever', 'Upload & sell content', 'Join the community', 'Real-time messaging']

  if (step === 'otp') {
    return (
      <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center relative overflow-hidden px-4 py-8">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff08_1px,transparent_1px),linear-gradient(to_bottom,#ffffff08_1px,transparent_1px)] bg-[size:32px_32px]" />
        <div className="absolute top-1/3 left-1/4 w-80 h-80 bg-purple-600/20 rounded-full blur-3xl" />
        <div className="absolute bottom-1/3 right-1/4 w-80 h-80 bg-blue-600/20 rounded-full blur-3xl" />

        <div className="relative z-10 w-full max-w-md">
          <div className="text-center mb-8">
            <Logo size="lg" className="justify-center mb-6" />
            <div className="w-16 h-16 bg-gradient-to-br from-violet-500 to-cyan-500 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-lg shadow-violet-500/30">
              <Mail className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-white mb-2">Check your email</h1>
            <p className="text-white/50 text-sm">
              We sent a 6-digit code to{' '}
              <span className="text-violet-400 font-medium">{otpEmail}</span>
            </p>
          </div>

          <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 shadow-2xl">
            {error && (
              <div className="mb-4 p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-sm text-red-400 text-center">{error}</div>
            )}
            {success && (
              <div className="mb-4 p-3 bg-green-500/10 border border-green-500/30 rounded-xl text-sm text-green-400 text-center">{success}</div>
            )}

            <form onSubmit={handleOtpSubmit} className="space-y-5">
              <div className="space-y-2">
                <Label className="text-white/70 text-sm font-medium flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-violet-400" />
                  Verification Code
                </Label>
                <Input
                  type="text"
                  value={otp}
                  onChange={e => setOtp(e.target.value.replace(/\D/g, '').slice(0, 6))}
                  placeholder="000000"
                  maxLength={6}
                  className="h-14 bg-white/5 border-white/10 text-white text-center text-2xl font-mono font-bold placeholder:text-white/20 focus:border-violet-500 rounded-xl tracking-widest"
                  autoFocus
                  required
                />
                <p className="text-xs text-white/40 text-center">Enter the 6-digit code from your email</p>
              </div>

              <Button
                type="submit"
                className="w-full h-11 bg-gradient-to-r from-violet-600 to-cyan-600 hover:from-violet-500 hover:to-cyan-500 text-white font-semibold rounded-xl shadow-lg shadow-violet-500/25 transition-all duration-200"
                disabled={isLoading || otp.length !== 6}
              >
                {isLoading ? (
                  <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Verifying...</>
                ) : (
                  <><ShieldCheck className="w-4 h-4 mr-2" /> Verify & Create Account</>
                )}
              </Button>
            </form>

            <div className="mt-5 text-center space-y-3">
              <button
                onClick={handleResendOtp}
                disabled={resending}
                className="text-sm text-violet-400 hover:text-violet-300 flex items-center gap-1.5 mx-auto disabled:opacity-50"
              >
                {resending ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}
                Resend code
              </button>
              <button
                onClick={() => { setStep('form'); setError(''); setSuccess(''); setOtp('') }}
                className="text-sm text-white/30 hover:text-white/60"
              >
                ← Back to registration
              </button>
            </div>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center relative overflow-hidden px-4 py-8">
      <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff08_1px,transparent_1px),linear-gradient(to_bottom,#ffffff08_1px,transparent_1px)] bg-[size:32px_32px]" />
      <div className="absolute top-1/3 left-1/4 w-80 h-80 bg-purple-600/20 rounded-full blur-3xl" />
      <div className="absolute bottom-1/3 right-1/4 w-80 h-80 bg-blue-600/20 rounded-full blur-3xl" />

      <div className="relative z-10 w-full max-w-md">
        <div className="text-center mb-8">
          <Logo size="lg" className="justify-center mb-6" />
          <h1 className="text-3xl font-bold text-white mb-2">Create your account</h1>
          <p className="text-white/50 text-sm">Join thousands of digital creators</p>
        </div>

        <div className="grid grid-cols-2 gap-2 mb-6">
          {perks.map(perk => (
            <div key={perk} className="flex items-center gap-2 bg-white/5 rounded-lg px-3 py-2">
              <Check className="w-3 h-3 text-green-400 flex-shrink-0" />
              <span className="text-xs text-white/60">{perk}</span>
            </div>
          ))}
        </div>

        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-2xl p-8 shadow-2xl">
          {error && (
            <div className="mb-6 p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-sm text-red-400 text-center">{error}</div>
          )}
          {success && (
            <div className="mb-6 p-3 bg-green-500/10 border border-green-500/30 rounded-xl text-sm text-green-400 text-center">{success}</div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label className="text-white/70 text-sm font-medium">Email address</Label>
              <Input type="email" name="email" value={formData.email} onChange={handleChange}
                placeholder="you@example.com"
                className="h-11 bg-white/5 border-white/10 text-white placeholder:text-white/30 focus:border-purple-500 rounded-xl" required />
            </div>

            <div className="space-y-2">
              <Label className="text-white/70 text-sm font-medium">Username</Label>
              <Input type="text" name="username" value={formData.username} onChange={handleChange}
                placeholder="coolcreator"
                className="h-11 bg-white/5 border-white/10 text-white placeholder:text-white/30 focus:border-purple-500 rounded-xl" required />
            </div>

            <div className="space-y-2">
              <Label className="text-white/70 text-sm font-medium">Password</Label>
              <div className="relative">
                <Input type={showPass ? 'text' : 'password'} name="password" value={formData.password} onChange={handleChange}
                  placeholder="Min 6 characters"
                  className="h-11 bg-white/5 border-white/10 text-white placeholder:text-white/30 focus:border-purple-500 rounded-xl pr-10" required />
                <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/70">
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-white/70 text-sm font-medium">Confirm password</Label>
              <Input type="password" name="confirmPassword" value={formData.confirmPassword} onChange={handleChange}
                placeholder="••••••••"
                className="h-11 bg-white/5 border-white/10 text-white placeholder:text-white/30 focus:border-purple-500 rounded-xl" required />
            </div>

            <div className="space-y-2">
              <Label className="text-white/70 text-sm font-medium flex items-center gap-1.5">
                <Gift className="w-3.5 h-3.5 text-purple-400" />
                Referral Code <span className="text-white/30 text-xs">(optional)</span>
              </Label>
              <Input type="text" name="referralCode" value={formData.referralCode} onChange={handleChange}
                placeholder="Enter referral code for $2 bonus"
                className="h-11 bg-purple-500/5 border-purple-500/20 text-white placeholder:text-white/30 focus:border-purple-500 rounded-xl" />
              {formData.referralCode && (
                <p className="text-[10px] text-purple-400/70 flex items-center gap-1">
                  <Check className="w-3 h-3" /> You&apos;ll get a $2 welcome bonus!
                </p>
              )}
            </div>

            <Button type="submit"
              className="w-full h-11 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white font-semibold rounded-xl shadow-lg shadow-purple-500/25 transition-all duration-200 mt-2"
              disabled={isLoading}>
              {isLoading ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Creating account...</>
              ) : (
                <><UserPlus className="w-4 h-4 mr-2" /> Create Account</>
              )}
            </Button>
          </form>

          {/* Social Login */}
          {(authConfig.discordEnabled || authConfig.googleEnabled) && (
            <div className="mt-6">
              <div className="relative">
                <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-white/10" /></div>
                <div className="relative flex justify-center text-xs"><span className="bg-[#0a0a0f] px-3 py-0.5 rounded-full text-white/40">or continue with</span></div>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-3">
                {authConfig.discordEnabled && (
                  <Button
                    type="button"
                    variant="outline"
                    className="h-11 bg-[#5865F2]/10 border-[#5865F2]/30 text-[#5865F2] hover:bg-[#5865F2]/20 rounded-xl font-medium"
                    onClick={() => signIn('discord', { callbackUrl: '/' })}
                  >
                    <DiscordIcon />
                    <span className="ml-2">Discord</span>
                  </Button>
                )}
                {authConfig.googleEnabled && (
                  <Button
                    type="button"
                    variant="outline"
                    className="h-11 bg-white/5 border-white/10 text-white/70 hover:bg-white/10 rounded-xl font-medium"
                    onClick={() => signIn('google', { callbackUrl: '/' })}
                  >
                    <GoogleIcon />
                    <span className="ml-2">Google</span>
                  </Button>
                )}
              </div>
            </div>
          )}

          <div className="mt-6 text-center">
            <p className="text-white/40 text-sm">
              Already have an account?{' '}
              <Link href="/auth/signin" className="text-purple-400 hover:text-purple-300 font-medium">Sign in here</Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function SignUp() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
        <div className="text-white/50">Loading...</div>
      </div>
    }>
      <SignUpForm />
    </Suspense>
  )
}
