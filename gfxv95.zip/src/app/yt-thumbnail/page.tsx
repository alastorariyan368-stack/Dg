'use client'

import { useState } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { toast } from 'sonner'
import { Download, Image as ImageIcon, Search, X, ExternalLink } from 'lucide-react'
import Link from 'next/link'

interface Thumbnail {
  quality: string
  label: string
  url: string
  width: number
  height: number
}

function extractVideoId(input: string): string | null {
  const trimmed = input.trim()
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/,
    /^([a-zA-Z0-9_-]{11})$/,
  ]
  for (const p of patterns) {
    const m = trimmed.match(p)
    if (m) return m[1]
  }
  return null
}

function getThumbnails(videoId: string): Thumbnail[] {
  return [
    { quality: 'maxresdefault', label: 'Max Resolution (1280×720)', url: `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`, width: 1280, height: 720 },
    { quality: 'sddefault', label: 'Standard (640×480)', url: `https://img.youtube.com/vi/${videoId}/sddefault.jpg`, width: 640, height: 480 },
    { quality: 'hqdefault', label: 'High Quality (480×360)', url: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`, width: 480, height: 360 },
    { quality: 'mqdefault', label: 'Medium Quality (320×180)', url: `https://img.youtube.com/vi/${videoId}/mqdefault.jpg`, width: 320, height: 180 },
    { quality: 'default', label: 'Default (120×90)', url: `https://img.youtube.com/vi/${videoId}/default.jpg`, width: 120, height: 90 },
  ]
}

export default function YtThumbnailPage() {
  const [url, setUrl] = useState('')
  const [videoId, setVideoId] = useState<string | null>(null)
  const [thumbnails, setThumbnails] = useState<Thumbnail[]>([])
  const [downloading, setDownloading] = useState<string | null>(null)

  const handleSearch = () => {
    const id = extractVideoId(url)
    if (!id) {
      toast.error('Invalid YouTube URL or video ID')
      return
    }
    setVideoId(id)
    setThumbnails(getThumbnails(id))
  }

  const handleDownload = async (thumb: Thumbnail) => {
    setDownloading(thumb.quality)
    try {
      const res = await fetch(`/api/proxy-image?url=${encodeURIComponent(thumb.url)}`)
      if (!res.ok) throw new Error('Failed to fetch image')
      const blob = await res.blob()
      const objUrl = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = objUrl
      a.download = `yt-thumbnail-${videoId}-${thumb.quality}.jpg`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(objUrl)
      toast.success(`Downloaded ${thumb.label}`)
    } catch {
      // Fallback: open in new tab
      window.open(thumb.url, '_blank')
      toast.info('Opened thumbnail in new tab')
    } finally {
      setDownloading(null)
    }
  }

  const handleClear = () => {
    setUrl('')
    setVideoId(null)
    setThumbnails([])
  }

  return (
    <div className="min-h-screen bg-[#0a0a12] text-white flex flex-col">
      <Navbar />

      <div className="flex-1 container mx-auto px-4 py-10 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 bg-rose-500/10 border border-rose-500/20 rounded-full px-4 py-1.5 mb-4">
            <ImageIcon className="w-4 h-4 text-rose-400" />
            <span className="text-rose-300 text-sm font-medium">Free Tool</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-white mb-2">
            YouTube Thumbnail Downloader
          </h1>
          <p className="text-white/50 max-w-xl mx-auto">
            Download any YouTube video thumbnail in all available resolutions — instantly and for free.
          </p>
        </div>

        {/* Search bar */}
        <div className="flex gap-2 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
            <Input
              value={url}
              onChange={e => setUrl(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSearch()}
              placeholder="Paste YouTube URL or video ID…"
              className="pl-10 bg-white/[0.05] border-white/10 text-white placeholder:text-white/30 h-12 rounded-xl"
            />
            {url && (
              <button onClick={handleClear} className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60 transition">
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
          <Button
            onClick={handleSearch}
            disabled={!url.trim()}
            className="h-12 px-6 bg-rose-600 hover:bg-rose-500 border-0 rounded-xl text-white font-semibold"
          >
            Get Thumbnails
          </Button>
        </div>

        {/* Results */}
        {videoId && thumbnails.length > 0 && (
          <div className="space-y-6">
            {/* Video preview link */}
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-white/40 uppercase tracking-wider font-bold">Video ID</p>
                <p className="text-white font-mono text-sm">{videoId}</p>
              </div>
              <Link
                href={`https://youtube.com/watch?v=${videoId}`}
                target="_blank"
                className="flex items-center gap-1.5 text-xs text-white/50 hover:text-red-400 transition"
              >
                Open on YouTube <ExternalLink className="w-3 h-3" />
              </Link>
            </div>

            {/* Thumbnail grid */}
            <div className="grid gap-5">
              {thumbnails.map((thumb) => (
                <div
                  key={thumb.quality}
                  className="rounded-2xl border border-white/[0.07] bg-white/[0.03] overflow-hidden hover:border-white/20 transition-all"
                >
                  <div className="grid sm:grid-cols-[1fr_auto] gap-4 p-4 items-center">
                    {/* Preview */}
                    <div className="flex items-center gap-4">
                      <div className="w-28 h-16 rounded-xl overflow-hidden bg-black/40 flex-shrink-0">
                        <img
                          src={thumb.url}
                          alt={thumb.label}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            (e.target as HTMLImageElement).style.display = 'none'
                          }}
                        />
                      </div>
                      <div>
                        <p className="font-semibold text-white text-sm">{thumb.label}</p>
                        <p className="text-xs text-white/40 mt-0.5">{thumb.width}×{thumb.height} px · JPG</p>
                        <a
                          href={thumb.url}
                          target="_blank"
                          rel="noopener"
                          className="text-[11px] text-white/30 hover:text-white/60 transition flex items-center gap-1 mt-1"
                        >
                          Preview <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                    </div>

                    {/* Download button */}
                    <Button
                      onClick={() => handleDownload(thumb)}
                      disabled={downloading === thumb.quality}
                      className="bg-rose-600/20 hover:bg-rose-600 border border-rose-500/30 text-rose-300 hover:text-white transition-all rounded-xl h-10 px-5 gap-2 text-sm font-medium"
                    >
                      <Download className="w-4 h-4" />
                      {downloading === thumb.quality ? 'Downloading…' : 'Download'}
                    </Button>
                  </div>
                </div>
              ))}
            </div>

            {/* Full preview */}
            <div className="rounded-2xl border border-white/[0.07] overflow-hidden">
              <div className="px-4 py-3 border-b border-white/[0.06] flex items-center justify-between">
                <span className="text-sm font-semibold text-white/80">Max Resolution Preview</span>
                <Button
                  size="sm"
                  onClick={() => handleDownload(thumbnails[0])}
                  className="bg-rose-600 hover:bg-rose-500 border-0 text-white rounded-lg h-8 px-4 gap-1.5 text-xs"
                >
                  <Download className="w-3 h-3" /> Download Max
                </Button>
              </div>
              <img
                src={thumbnails[0].url}
                alt="Max resolution thumbnail"
                className="w-full object-cover"
                onError={(e) => {
                  const img = e.target as HTMLImageElement
                  img.src = thumbnails[1].url
                }}
              />
            </div>
          </div>
        )}

        {/* Empty state */}
        {!videoId && (
          <div className="text-center py-16">
            <div className="w-20 h-20 rounded-3xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center mx-auto mb-4">
              <ImageIcon className="w-9 h-9 text-rose-400/60" />
            </div>
            <p className="text-white/30 text-sm">Paste a YouTube URL above and click "Get Thumbnails"</p>
            <p className="text-white/20 text-xs mt-1">Supports youtube.com, youtu.be and direct video IDs</p>
          </div>
        )}
      </div>

      <Footer />
    </div>
  )
}
