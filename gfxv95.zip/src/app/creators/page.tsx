'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Loader2, Users, Search, Star, Package, CheckCircle, ArrowRight, TrendingUp } from 'lucide-react'

interface Creator {
  id: string; username: string; displayName?: string; avatar?: string; bio?: string
  isVerified: boolean; sellerLevel: number; totalSales: number
  _count?: { items: number }
}

export default function CreatorsPage() {
  const [creators, setCreators] = useState<Creator[]>([])
  const [filtered, setFiltered] = useState<Creator[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')

  useEffect(() => {
    fetch('/api/users/list?limit=50')
      .then(r => r.json())
      .then(d => {
        const list = Array.isArray(d) ? d : d.users || []
        setCreators(list)
        setFiltered(list)
      })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  useEffect(() => {
    if (search.trim()) {
      setFiltered(creators.filter(c => (c.username + (c.displayName || '')).toLowerCase().includes(search.toLowerCase())))
    } else {
      setFiltered(creators)
    }
  }, [search, creators])

  const levelColors: Record<number, string> = {
    1: 'text-gray-400',
    2: 'text-blue-400',
    3: 'text-purple-400',
    4: 'text-yellow-400',
    5: 'text-orange-400',
  }

  const levelLabels: Record<number, string> = {
    1: 'Starter', 2: 'Rising', 3: 'Pro', 4: 'Expert', 5: 'Elite'
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      <Navbar />
      <section className="relative py-16 px-4 text-center">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff06_1px,transparent_1px),linear-gradient(to_bottom,#ffffff06_1px,transparent_1px)] bg-[size:32px_32px]" />
        <div className="container mx-auto relative z-10">
          <Badge className="mb-4 px-4 py-1.5 bg-blue-500/10 text-blue-300 border-blue-500/30"><Users className="w-3.5 h-3.5 mr-1.5" />Creator Community</Badge>
          <h1 className="text-4xl font-bold text-white mb-3">Meet Our Creators</h1>
          <p className="text-white/50 text-lg mb-8 max-w-xl mx-auto">Talented digital builders, developers, and artists sharing their best work</p>
          <div className="max-w-md mx-auto relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-white/30" />
            <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search creators..." className="pl-10 h-12 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl" />
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 pb-20 max-w-5xl">
        <div className="flex items-center justify-between mb-6">
          <p className="text-white/40 text-sm">{filtered.length} creators</p>
          <Link href="/seller/apply">
            <Button variant="outline" size="sm" className="border-purple-500/20 text-purple-400 hover:bg-purple-500/10 rounded-xl gap-2 text-xs">
              <Star className="h-3.5 w-3.5" />Become a Creator
            </Button>
          </Link>
        </div>

        {loading ? (
          <div className="flex justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-blue-400" /></div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20"><Users className="w-16 h-16 mx-auto text-white/10 mb-4" /><p className="text-white/40">No creators found</p></div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map(creator => (
              <Link key={creator.id} href={`/profile/${creator.username}`}>
                <div className="group bg-white/[0.03] border border-white/8 hover:border-blue-500/20 rounded-2xl p-5 transition-all duration-300 cursor-pointer">
                  <div className="flex items-center gap-3 mb-3">
                    <Avatar className="h-12 w-12 border-2 border-white/10">
                      <AvatarImage src={creator.avatar || undefined} />
                      <AvatarFallback className="bg-gradient-to-br from-blue-500/20 to-purple-500/20 text-white font-semibold">{creator.username.slice(0, 2).toUpperCase()}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 mb-0.5">
                        <h3 className="font-semibold text-white text-sm truncate group-hover:text-blue-300 transition-colors">{creator.displayName || creator.username}</h3>
                        {creator.isVerified && <CheckCircle className="w-3.5 h-3.5 text-blue-400 flex-shrink-0" />}
                      </div>
                      <p className="text-white/40 text-xs">@{creator.username}</p>
                    </div>
                  </div>
                  {creator.bio && <p className="text-white/50 text-xs line-clamp-2 mb-3">{creator.bio}</p>}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 text-xs text-white/30">
                      {creator._count && <span className="flex items-center gap-1"><Package className="h-3 w-3" />{creator._count.items} items</span>}
                      <span className="flex items-center gap-1"><TrendingUp className="h-3 w-3" />{creator.totalSales} sales</span>
                    </div>
                    {creator.sellerLevel > 1 && (
                      <Badge className={`text-[10px] border-0 bg-white/5 ${levelColors[creator.sellerLevel] || 'text-white/40'}`}>
                        {levelLabels[creator.sellerLevel] || 'Creator'}
                      </Badge>
                    )}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
      <Footer />
    </div>
  )
}
