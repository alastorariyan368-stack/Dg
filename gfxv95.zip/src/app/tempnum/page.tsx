'use client'
import { useState, useEffect, useRef, useCallback } from 'react'
import { Phone, RefreshCw, Trash2, Copy, Check, Clock, MessageSquare, ChevronDown, Zap } from 'lucide-react'

interface SmsMessage { id: string; fromNumber: string; body: string; receivedAt: string }
interface PhoneData {
  id: string; number: string; countryCode: string; countryName: string
  token: string; expiresAt: string; expired: boolean; messageCount: number; messages: SmsMessage[]
}
interface CountryConfig { id: string; countryCode: string; countryName: string; numberPrefix: string; isActive: boolean }

function timeLeft(expiresAt: string) {
  const diff = new Date(expiresAt).getTime() - Date.now()
  if (diff <= 0) return 'Expired'
  const m = Math.floor(diff / 60000)
  const s = Math.floor((diff % 60000) / 1000)
  return m > 0 ? `${m}m ${s}s` : `${s}s`
}

function timeAgo(date: string) {
  const diff = Date.now() - new Date(date).getTime()
  if (diff < 60000) return 'just now'
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`
  return `${Math.floor(diff / 3600000)}h ago`
}

export default function TempNumPage() {
  const [phone, setPhone] = useState<PhoneData | null>(null)
  const [countries, setCountries] = useState<CountryConfig[]>([])
  const [selectedCountry, setSelectedCountry] = useState('')
  const [generating, setGenerating] = useState(false)
  const [refreshing, setRefreshing] = useState(false)
  const [copied, setCopied] = useState(false)
  const [timer, setTimer] = useState('')
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  // Load available countries
  useEffect(() => {
    fetch('/api/tempnum/countries')
      .then(r => r.json())
      .then(d => {
        const active = (d.configs || []).filter((c: CountryConfig) => c.isActive)
        setCountries(active)
        if (active.length > 0) setSelectedCountry(active[0].countryCode)
      })
      .catch(() => {})
  }, [])

  const loadPhone = useCallback(async (token: string, quiet = false) => {
    if (!quiet) setRefreshing(true)
    const r = await fetch(`/api/tempnum/inbox/${token}`)
    if (r.ok) setPhone(await r.json())
    setRefreshing(false)
  }, [])

  // Restore from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('tempnum_token')
    if (saved) loadPhone(saved)
  }, [loadPhone])

  // Auto-refresh
  useEffect(() => {
    if (!phone?.token || phone.expired) return
    intervalRef.current = setInterval(() => loadPhone(phone.token, true), 8000)
    return () => { if (intervalRef.current) clearInterval(intervalRef.current) }
  }, [phone?.token, phone?.expired, loadPhone])

  // Countdown
  useEffect(() => {
    if (!phone) return
    const t = setInterval(() => setTimer(timeLeft(phone.expiresAt)), 1000)
    return () => clearInterval(t)
  }, [phone?.expiresAt])

  const generate = async () => {
    setGenerating(true)
    const r = await fetch('/api/tempnum/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ countryCode: selectedCountry || undefined }),
    })
    const data = await r.json()
    if (!r.ok) { alert(data.error); setGenerating(false); return }
    setPhone({ ...data, messageCount: 0, messages: [], expired: false })
    localStorage.setItem('tempnum_token', data.token)
    setGenerating(false)
  }

  const deletePhone = async () => {
    if (!phone || !confirm('Delete this number?')) return
    await fetch(`/api/tempnum/inbox/${phone.token}`, { method: 'DELETE' })
    setPhone(null)
    localStorage.removeItem('tempnum_token')
    if (intervalRef.current) clearInterval(intervalRef.current)
  }

  const copyNumber = () => {
    if (!phone) return
    navigator.clipboard.writeText(phone.number)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      {/* Hero */}
      <div className="bg-gradient-to-b from-green-950/50 to-gray-950 py-12 px-4 text-center">
        <div className="inline-flex items-center gap-2 bg-green-500/10 border border-green-500/30 rounded-full px-4 py-1.5 text-green-400 text-sm mb-4">
          <Zap className="w-3.5 h-3.5" /> Disposable Number
        </div>
        <h1 className="text-4xl font-bold mb-3 bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
          Temp Number
        </h1>
        <p className="text-gray-400 max-w-md mx-auto text-sm">
          Get a temporary phone number instantly. Receive SMS for verifications without exposing your real number.
        </p>
      </div>

      <div className="max-w-2xl mx-auto px-4 pb-16">
        {!phone ? (
          <div className="flex flex-col items-center gap-6 py-12">
            {/* Country Selector */}
            {countries.length > 1 && (
              <div className="relative w-64">
                <select
                  value={selectedCountry}
                  onChange={e => setSelectedCountry(e.target.value)}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm appearance-none outline-none focus:border-green-500 transition cursor-pointer"
                >
                  {countries.map(c => (
                    <option key={c.countryCode} value={c.countryCode}>
                      {c.countryName} ({c.numberPrefix})
                    </option>
                  ))}
                </select>
                <ChevronDown className="absolute right-3 top-3.5 w-4 h-4 text-gray-400 pointer-events-none" />
              </div>
            )}
            {countries.length === 0 && (
              <p className="text-amber-400 text-sm bg-amber-500/10 border border-amber-500/20 rounded-xl px-4 py-3">
                No countries configured yet. Admin needs to add countries in Admin → Temp Number.
              </p>
            )}
            <button
              onClick={generate}
              disabled={generating || countries.length === 0}
              className="flex items-center gap-3 px-8 py-4 bg-green-600 hover:bg-green-500 disabled:opacity-50 rounded-2xl text-lg font-semibold transition-all shadow-lg shadow-green-500/20 hover:shadow-green-500/40"
            >
              <Phone className="w-5 h-5" />
              {generating ? 'Generating...' : 'Get Temp Number'}
            </button>
            <p className="text-gray-600 text-sm">Temporary · No registration required</p>
          </div>
        ) : (
          <div className="mt-6 space-y-4">
            {/* Number Card */}
            <div className={`rounded-2xl p-5 border ${phone.expired ? 'border-red-500/30 bg-red-950/20' : 'border-green-500/30 bg-green-950/20'}`}>
              <div className="flex items-start gap-4">
                <div className="flex-1 min-w-0">
                  <div className="text-xs text-gray-400 mb-1">Your temporary number · {phone.countryName}</div>
                  <div className="flex items-center gap-2">
                    <span className="text-2xl font-mono font-bold tracking-wider">{phone.number}</span>
                    <button onClick={copyNumber} className="shrink-0 p-1.5 rounded-lg bg-white/5 hover:bg-white/10 transition">
                      {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4 text-gray-400" />}
                    </button>
                  </div>
                  <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {phone.expired
                        ? <span className="text-red-400">Expired</span>
                        : <span className="text-green-400">{timer} left</span>}
                    </span>
                    <span className="flex items-center gap-1">
                      <MessageSquare className="w-3 h-3" />
                      {phone.messageCount} SMS received
                    </span>
                  </div>
                </div>
                <div className="flex gap-2 shrink-0">
                  <button onClick={() => loadPhone(phone.token)} disabled={refreshing}
                    className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition">
                    <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
                  </button>
                  <button onClick={generate} disabled={generating}
                    className="px-3 py-2 rounded-lg bg-green-600 hover:bg-green-500 text-xs font-medium transition">
                    New
                  </button>
                  <button onClick={deletePhone} className="p-2 rounded-lg hover:bg-red-500/20 text-red-400 transition">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            {/* SMS List */}
            <div className="bg-white/5 rounded-2xl border border-white/10 overflow-hidden">
              <div className="px-4 py-3 border-b border-white/10 flex items-center justify-between">
                <span className="font-semibold text-sm">SMS Messages</span>
                {refreshing && <RefreshCw className="w-3 h-3 animate-spin text-gray-500" />}
              </div>
              {phone.messages.length === 0 ? (
                <div className="flex flex-col items-center py-14 text-gray-600">
                  <MessageSquare className="w-8 h-8 mb-2 opacity-30" />
                  <p className="text-sm">Waiting for SMS...</p>
                  <p className="text-xs mt-1 text-gray-700">Auto-refreshes every 8 seconds</p>
                </div>
              ) : (
                <div className="divide-y divide-white/5">
                  {phone.messages.map(msg => (
                    <div key={msg.id} className="px-4 py-4">
                      <div className="flex items-start justify-between gap-2 mb-2">
                        <span className="text-xs font-mono text-green-400">{msg.fromNumber}</span>
                        <span className="text-xs text-gray-600 shrink-0">{timeAgo(msg.receivedAt)}</span>
                      </div>
                      <p className="text-sm text-gray-200 bg-white/3 rounded-lg px-3 py-2 break-words">{msg.body}</p>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Info */}
            <div className="bg-white/3 rounded-xl p-4 border border-white/5 text-xs text-gray-500 space-y-1">
              <p>• Use this number for OTP/verification codes only</p>
              <p>• Numbers are shared and public — do not use for private messages</p>
              <p>• Auto-refreshes every 8 seconds. Manual refresh available above.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
