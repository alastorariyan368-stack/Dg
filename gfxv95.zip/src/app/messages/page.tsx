'use client'

import { useState, useEffect, useRef, useCallback, Suspense } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter, useSearchParams } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { toast } from 'sonner'
import {
  MessageCircle, Search, Send, Paperclip, Image as ImageIcon, Mic, Phone, Video as VideoIcon,
  Users, Plus, ArrowLeft, X, Smile, Loader2, MoreVertical, UserPlus, Settings as SettingsIcon, LogOut,
  Square, Play, Pause, Download as DownloadIcon, Trash2,
} from 'lucide-react'
import { useMessagesSocket, getMessagesSocket } from '@/lib/messages-socket'
import { CallModal, type CallPeer } from '@/components/messaging/call-modal'

// ─── Types ───────────────────────────────────────────────────────────────
interface Conversation {
  userId: string; username: string; avatar?: string; isActive?: boolean
  lastMessage: string; lastMessageKind: string; lastMessageTime: string
  lastFromMe: boolean; unreadCount: number
}
interface GroupSummary {
  id: string; name: string; description?: string; avatar?: string
  ownerId: string; role: string; memberCount: number; messageCount: number
  lastMessage?: { content: string; kind: string; createdAt: string; senderName: string } | null
  createdAt: string
}
interface MessageRow {
  id: string; senderId: string; receiverId?: string; groupId?: string
  content: string; kind: string
  mediaUrl?: string; mediaName?: string; mimeType?: string; durationSec?: number
  thumbnailUrl?: string; callId?: string
  isRead?: boolean; createdAt: string
  sender?: { id: string; username: string; avatar?: string }
  receiver?: { id: string; username: string; avatar?: string }
}
interface Friend { id: string; username: string; avatar?: string; isActive?: boolean }
interface UserHit { id: string; username: string; avatar?: string }

type Selected =
  | { type: 'dm'; userId: string; username: string; avatar?: string; isActive?: boolean }
  | { type: 'group'; groupId: string; name: string; avatar?: string; memberIds: string[] }
  | null

// ─── Helpers ─────────────────────────────────────────────────────────────
function fmtSec(s: number) { return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}` }

function MediaPreview({ msg }: { msg: MessageRow }) {
  if (msg.kind === 'IMAGE' && msg.mediaUrl) {
    return <img src={msg.mediaUrl} alt={msg.mediaName || 'image'} className="max-w-[260px] max-h-[260px] rounded-xl border border-white/10 object-cover cursor-pointer" onClick={() => window.open(msg.mediaUrl, '_blank')} />
  }
  if (msg.kind === 'VIDEO' && msg.mediaUrl) {
    return <video src={msg.mediaUrl} controls className="max-w-[320px] max-h-[280px] rounded-xl border border-white/10" />
  }
  if (msg.kind === 'VOICE' && msg.mediaUrl) {
    return (
      <div className="flex items-center gap-2 bg-black/30 rounded-xl px-3 py-2 min-w-[200px]">
        <Mic className="w-4 h-4 text-violet-300" />
        <audio src={msg.mediaUrl} controls className="h-8 flex-1" />
        {msg.durationSec ? <span className="text-[11px] text-white/50">{fmtSec(msg.durationSec)}</span> : null}
      </div>
    )
  }
  if (msg.kind === 'FILE' && msg.mediaUrl) {
    return (
      <a href={msg.mediaUrl} download={msg.mediaName || 'file'} target="_blank" rel="noopener" className="inline-flex items-center gap-2 bg-black/30 rounded-xl px-3 py-2 hover:bg-black/40">
        <DownloadIcon className="w-4 h-4 text-cyan-300" />
        <div className="text-sm">
          <div className="text-white truncate max-w-[200px]">{msg.mediaName || 'File'}</div>
          <div className="text-[10px] text-white/40 uppercase">{msg.mimeType?.split('/')[1] || 'file'}</div>
        </div>
      </a>
    )
  }
  if (msg.kind === 'CALL') {
    return <div className="text-sm italic text-white/70">{msg.content || '📞 Call'}</div>
  }
  return <p className="text-sm whitespace-pre-wrap break-words">{msg.content}</p>
}

// Voice recorder hook
function useVoiceRecorder() {
  const [recording, setRecording] = useState(false)
  const [seconds, setSeconds] = useState(0)
  const recRef = useRef<MediaRecorder | null>(null)
  const chunksRef = useRef<Blob[]>([])
  const streamRef = useRef<MediaStream | null>(null)
  const startTsRef = useRef(0)
  const tickRef = useRef<NodeJS.Timeout | null>(null)

  const start = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      streamRef.current = stream
      chunksRef.current = []
      const mime = MediaRecorder.isTypeSupported('audio/webm;codecs=opus') ? 'audio/webm;codecs=opus'
                  : MediaRecorder.isTypeSupported('audio/webm') ? 'audio/webm' : ''
      const rec = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined)
      recRef.current = rec
      rec.ondataavailable = e => { if (e.data.size > 0) chunksRef.current.push(e.data) }
      rec.start(250)
      setRecording(true); setSeconds(0); startTsRef.current = Date.now()
      tickRef.current = setInterval(() => setSeconds(Math.floor((Date.now() - startTsRef.current) / 1000)), 250)
    } catch (e: any) { toast.error(e?.message || 'Mic permission denied') }
  }, [])

  const stop = useCallback(async (): Promise<{ blob: Blob; seconds: number; mime: string } | null> => {
    return new Promise(resolve => {
      const rec = recRef.current
      if (!rec) return resolve(null)
      rec.onstop = () => {
        const mime = rec.mimeType || 'audio/webm'
        const blob = new Blob(chunksRef.current, { type: mime })
        const dur = Math.max(1, Math.floor((Date.now() - startTsRef.current) / 1000))
        streamRef.current?.getTracks().forEach(t => t.stop())
        streamRef.current = null
        recRef.current = null
        if (tickRef.current) clearInterval(tickRef.current)
        setRecording(false); setSeconds(0)
        resolve({ blob, seconds: dur, mime })
      }
      rec.stop()
    })
  }, [])

  const cancel = useCallback(() => {
    const rec = recRef.current
    if (!rec) return
    rec.onstop = null
    try { rec.stop() } catch {}
    streamRef.current?.getTracks().forEach(t => t.stop())
    streamRef.current = null
    recRef.current = null
    if (tickRef.current) clearInterval(tickRef.current)
    setRecording(false); setSeconds(0)
  }, [])

  return { recording, seconds, start, stop, cancel }
}

// ─── Page ────────────────────────────────────────────────────────────────
function MessagesPageInner() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const myId = (session?.user as any)?.id || ''
  const { socket } = useMessagesSocket(myId)

  const [conversations, setConversations] = useState<Conversation[]>([])
  const [groups, setGroups] = useState<GroupSummary[]>([])
  const [friends, setFriends] = useState<Friend[]>([])
  const [tab, setTab] = useState<'chats' | 'groups' | 'friends'>('chats')
  const [selected, setSelected] = useState<Selected>(null)
  const [messages, setMessages] = useState<MessageRow[]>([])
  const [loading, setLoading] = useState(false)
  const [draft, setDraft] = useState('')
  const [searchQ, setSearchQ] = useState('')
  const [peerTyping, setPeerTyping] = useState(false)
  const [showNewGroup, setShowNewGroup] = useState(false)
  const [newGroupName, setNewGroupName] = useState('')
  const [newGroupMembers, setNewGroupMembers] = useState<string[]>([])

  // Search users for friend tab
  const [userQuery, setUserQuery] = useState('')
  const [userHits, setUserHits] = useState<UserHit[]>([])
  const [allUsers, setAllUsers] = useState<UserHit[]>([])
  const [pendingRequests, setPendingRequests] = useState<any[]>([])
  const [sentRequestIds, setSentRequestIds] = useState<Set<string>>(new Set())

  // Calls (outgoing only — incoming calls are handled globally by GlobalCallHandler)
  const [activeCall, setActiveCall] = useState<{ callId: string; peer: CallPeer; type: 'AUDIO' | 'VIDEO'; isInitiator: boolean; initialAccepted: boolean } | null>(null)

  const messagesEndRef = useRef<HTMLDivElement>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const imageInputRef = useRef<HTMLInputElement>(null)
  const recorder = useVoiceRecorder()

  // ─── Auth gate
  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin')
  }, [status, router])

  const searchParams = useSearchParams()

  // ─── Initial loads + restore URL state
  useEffect(() => {
    if (status !== 'authenticated') return
    fetchAll().then(({ convs, grps }) => {
      const dmId = searchParams.get('dm')
      const grpId = searchParams.get('group')
      if (dmId) {
        const conv = convs.find((c: any) => c.userId === dmId)
        if (conv) openDM({ id: conv.userId, username: conv.username, avatar: conv.avatar, isActive: conv.isActive })
      } else if (grpId) {
        const grp = grps.find((g: any) => g.id === grpId)
        if (grp) openGroup(grp)
      }
    })
  }, [status])

  const fetchAll = async () => {
    const [convs, grps] = await Promise.all([loadConversations(), loadGroups(), loadFriends()])
    return { convs: convs || [], grps: grps || [] }
  }
  const loadConversations = async () => {
    try {
      const r = await fetch('/api/messages/conversations', { cache: 'no-store' })
      if (r.ok) { const d = await r.json(); const convs = d.conversations || []; setConversations(convs); return convs }
    } catch {}
    return []
  }
  const loadGroups = async () => {
    try {
      const r = await fetch('/api/groups', { cache: 'no-store' })
      if (r.ok) { const d = await r.json(); const grps = d.groups || []; setGroups(grps); return grps }
    } catch {}
    return []
  }
  const loadFriends = async () => {
    try {
      const r = await fetch('/api/friends/list', { cache: 'no-store' })
      if (r.ok) { const d = await r.json(); setFriends(d.friends || d || []) }
    } catch {}
  }

  // Load all users + pending requests when friends tab is opened
  useEffect(() => {
    if (tab !== 'friends' || status !== 'authenticated') return
    const loadFriendsTabData = async () => {
      try {
        const [usersRes, reqsRes] = await Promise.all([
          fetch('/api/users/search?limit=200'),
          fetch('/api/friends/requests')
        ])
        if (usersRes.ok) {
          const d = await usersRes.json()
          setAllUsers((d.users || []).slice(0, 200))
        }
        if (reqsRes.ok) {
          const d = await reqsRes.json()
          setPendingRequests(d.received || [])
          const sentIds = new Set<string>((d.sent || []).map((r: any) => r.receiverId))
          setSentRequestIds(sentIds)
        }
      } catch {}
    }
    loadFriendsTabData()
  }, [tab, status])

  // User search (only when query has text)
  useEffect(() => {
    if (!userQuery.trim()) { setUserHits([]); return }
    const t = setTimeout(async () => {
      try {
        const r = await fetch(`/api/users/search?q=${encodeURIComponent(userQuery.trim())}&limit=15`)
        if (r.ok) { const d = await r.json(); setUserHits((d.users || []).slice(0, 15)) }
      } catch {}
    }, 250)
    return () => clearTimeout(t)
  }, [userQuery])

  // ─── Socket subscriptions
  useEffect(() => {
    if (!socket || !myId) return
    const onNewPM = (msg: MessageRow) => {
      if (selected?.type === 'dm' && (msg.senderId === selected.userId || msg.receiverId === selected.userId)) {
        setMessages(prev => prev.some(m => m.id === msg.id) ? prev : [...prev, msg])
      }
      loadConversations()
    }
    const onNewGM = ({ groupId, message }: { groupId: string; message: MessageRow }) => {
      if (selected?.type === 'group' && selected.groupId === groupId) {
        setMessages(prev => prev.some(m => m.id === message.id) ? prev : [...prev, message])
      }
      loadGroups()
    }
    const onTyping = ({ userId, isTyping }: any) => {
      if (selected?.type === 'dm' && selected.userId === userId) setPeerTyping(!!isTyping)
    }
    socket.on('newPrivateMessage', onNewPM)
    socket.on('newMessage', onNewPM) // legacy alias
    socket.on('messageSent', onNewPM)
    socket.on('newGroupMessage', onNewGM)
    socket.on('groupAdded', loadGroups)
    socket.on('peerTyping', onTyping)
    return () => {
      socket.off('newPrivateMessage', onNewPM)
      socket.off('newMessage', onNewPM)
      socket.off('messageSent', onNewPM)
      socket.off('newGroupMessage', onNewGM)
      socket.off('groupAdded', loadGroups)
      socket.off('peerTyping', onTyping)
    }
  }, [socket, myId, selected])

  // Auto-scroll
  useEffect(() => { messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [messages])

  // ─── Open chat / group
  async function openDM(c: { id: string; username: string; avatar?: string; isActive?: boolean }) {
    setSelected({ type: 'dm', userId: c.id, username: c.username, avatar: c.avatar, isActive: c.isActive })
    router.replace(`/messages?dm=${c.id}`, { scroll: false })
    setLoading(true); setMessages([]); setPeerTyping(false)
    try {
      const r = await fetch(`/api/messages/${c.id}`, { cache: 'no-store' })
      if (r.ok) { const d = await r.json(); setMessages(d.messages || []) }
    } finally { setLoading(false); loadConversations() }
  }

  async function openGroup(g: GroupSummary) {
    router.replace(`/messages?group=${g.id}`, { scroll: false })
    setLoading(true); setMessages([]); setPeerTyping(false)
    try {
      const r = await fetch(`/api/groups/${g.id}`, { cache: 'no-store' })
      const detail = r.ok ? await r.json() : null
      const memberIds = (detail?.group?.members || []).map((m: any) => m.userId)
      setSelected({ type: 'group', groupId: g.id, name: g.name, avatar: g.avatar, memberIds })
      const m = await fetch(`/api/groups/${g.id}/messages`, { cache: 'no-store' })
      if (m.ok) { const d = await m.json(); setMessages(d.messages || []) }
    } finally { setLoading(false); loadGroups() }
  }

  // ─── Sending
  async function sendText() {
    if (!draft.trim() || !selected) return
    const text = draft.trim()
    setDraft('')
    if (selected.type === 'dm') {
      const r = await fetch('/api/messages/send', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ receiverId: selected.userId, content: text }),
      })
      if (!r.ok) {
        const e = await r.json().catch(() => ({}))
        toast.error(e.error || 'Send failed')
        setDraft(text)
      } else {
        const msg = await r.json().catch(() => null)
        if (msg && msg.id) setMessages(prev => prev.some(m => m.id === msg.id) ? prev : [...prev, msg])
        loadConversations()
      }
    } else {
      const r = await fetch(`/api/groups/${selected.groupId}/messages`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: text }),
      })
      if (!r.ok) {
        const e = await r.json().catch(() => ({}))
        toast.error(e.error || 'Send failed')
        setDraft(text)
      } else {
        const msg = await r.json().catch(() => null)
        if (msg && msg.id) setMessages(prev => prev.some(m => m.id === msg.id) ? prev : [...prev, msg])
        loadGroups()
      }
    }
  }

  async function sendAttachment(file: File, kind?: string, durationSec?: number) {
    if (!selected) return
    const fd = new FormData()
    fd.append('file', file)
    const up = await fetch('/api/messages/upload', { method: 'POST', body: fd })
    if (!up.ok) { const e = await up.json().catch(() => ({})); toast.error(e.error || 'Upload failed'); return }
    const j = await up.json()
    const payload: any = { kind: kind || j.kind, mediaUrl: j.mediaUrl, mediaName: j.mediaName, mimeType: j.mimeType, durationSec }
    if (selected.type === 'dm') {
      const r = await fetch('/api/messages/send', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ receiverId: selected.userId, content: '', ...payload }),
      })
      if (!r.ok) { toast.error('Send failed'); return }
      const msg = await r.json().catch(() => null)
      if (msg && msg.id) setMessages(prev => prev.some(m => m.id === msg.id) ? prev : [...prev, msg])
      loadConversations()
    } else {
      const r = await fetch(`/api/groups/${selected.groupId}/messages`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: '', ...payload }),
      })
      if (!r.ok) { toast.error('Send failed'); return }
      const msg = await r.json().catch(() => null)
      if (msg && msg.id) setMessages(prev => prev.some(m => m.id === msg.id) ? prev : [...prev, msg])
      loadGroups()
    }
  }

  function onPickImage(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0]; if (f) sendAttachment(f, 'IMAGE')
    e.target.value = ''
  }
  function onPickFile(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0]; if (f) sendAttachment(f)
    e.target.value = ''
  }
  async function toggleVoiceRecord() {
    if (recorder.recording) {
      const out = await recorder.stop()
      if (out) {
        const ext = out.mime.includes('webm') ? 'webm' : out.mime.includes('mp4') ? 'm4a' : 'ogg'
        const file = new File([out.blob], `voice-${Date.now()}.${ext}`, { type: out.mime })
        await sendAttachment(file, 'VOICE', out.seconds)
      }
    } else { recorder.start() }
  }

  // ─── Typing notification
  function onDraftChange(v: string) {
    setDraft(v)
    if (!selected || !socket) return
    if (selected.type === 'dm') socket.emit('typing', { receiverId: selected.userId, isTyping: !!v.trim() })
    if (selected.type === 'group') socket.emit('groupTyping', { groupId: selected.groupId, memberIds: selected.memberIds, isTyping: !!v.trim() })
  }

  // ─── Calls
  async function startCall(type: 'AUDIO' | 'VIDEO') {
    if (selected?.type !== 'dm') { toast.info('Group calls coming soon'); return }
    try {
      const r = await fetch('/api/calls', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ receiverId: selected.userId, type }),
      })
      const d = await r.json()
      if (!r.ok) { toast.error(d.error || 'Call failed'); return }
      const callId = d.call.id
      // Use getMessagesSocket directly so we always have a live socket reference,
      // not a potentially-stale closure over the useState socket value.
      const liveSocket = getMessagesSocket(myId)
      liveSocket.emit('call:invite', {
        callId,
        targetUserIds: [selected.userId],
        type,
        from: { id: myId, username: (session?.user as any)?.username || session?.user?.name || '', avatar: (session?.user as any)?.image || '' },
      })
      setActiveCall({ callId, peer: { id: selected.userId, username: selected.username, avatar: selected.avatar }, type, isInitiator: true, initialAccepted: false })
    } catch (e: any) { toast.error(e?.message || 'Call failed') }
  }

  // ─── Group create
  async function createGroup() {
    const name = newGroupName.trim()
    if (!name) { toast.error('Group name required'); return }
    if (newGroupMembers.length === 0) { toast.error('Add at least one friend'); return }
    const r = await fetch('/api/groups', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, memberIds: newGroupMembers }),
    })
    const d = await r.json()
    if (!r.ok) { toast.error(d.error || 'Create failed'); return }
    toast.success(`Group "${name}" created`)
    setShowNewGroup(false); setNewGroupName(''); setNewGroupMembers([])
    loadGroups()
  }

  if (status === 'loading') {
    return <div className="min-h-screen bg-[#0a0a12] flex items-center justify-center"><Loader2 className="w-6 h-6 animate-spin text-violet-400" /></div>
  }

  // ─── Render lists ───
  const filteredConvs = conversations.filter(c => !searchQ || c.username.toLowerCase().includes(searchQ.toLowerCase()))
  const filteredGroups = groups.filter(g => !searchQ || g.name.toLowerCase().includes(searchQ.toLowerCase()))

  return (
    <div className="min-h-screen bg-[#0a0a12] text-white flex flex-col">
      <Navbar />
      <div className="flex-1 container mx-auto px-2 sm:px-4 py-4 max-w-7xl">
        <div className="grid grid-cols-1 lg:grid-cols-[340px_1fr] gap-3 h-[calc(100dvh-130px)]">
          {/* ── Sidebar */}
          <aside className={`${selected ? 'hidden lg:flex' : 'flex'} flex-col bg-white/[0.02] border border-white/[0.08] rounded-2xl overflow-hidden`}>
            <div className="p-3 border-b border-white/[0.06] space-y-2">
              <div className="flex items-center justify-between">
                <h1 className="text-lg font-bold text-white flex items-center gap-2">
                  <MessageCircle className="w-5 h-5 text-violet-400" /> Messages
                </h1>
                <button onClick={() => setShowNewGroup(true)} className="p-2 rounded-lg hover:bg-white/[0.06] text-white/60 hover:text-white" title="New group">
                  <Users className="w-4 h-4" />
                </button>
              </div>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-white/30" />
                <Input value={searchQ} onChange={e => setSearchQ(e.target.value)} placeholder="Search…" className="pl-9 h-9 bg-black/30 border-white/[0.08] text-sm" />
              </div>
              <div className="flex gap-1 text-xs">
                {(['chats', 'groups', 'friends'] as const).map(t => (
                  <button key={t} onClick={() => setTab(t)}
                    className={`flex-1 px-2 py-1.5 rounded-lg capitalize transition ${tab === t ? 'bg-violet-600 text-white' : 'bg-white/[0.04] text-white/60 hover:text-white'}`}>{t}</button>
                ))}
              </div>
            </div>

            <div className="flex-1 overflow-y-auto">
              {tab === 'chats' && (
                filteredConvs.length === 0 ? (
                  <Empty icon={<MessageCircle className="w-8 h-8" />} title="No chats yet" sub="Start a conversation from Friends tab" />
                ) : filteredConvs.map(c => (
                  <button key={c.userId} onClick={() => openDM({ id: c.userId, username: c.username, avatar: c.avatar, isActive: c.isActive })}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 hover:bg-white/[0.04] border-b border-white/[0.04] text-left transition ${selected?.type === 'dm' && selected.userId === c.userId ? 'bg-white/[0.05]' : ''}`}>
                    <div className="relative">
                      <Avatar className="w-11 h-11">
                        {c.avatar && <AvatarImage src={c.avatar} />}
                        <AvatarFallback className="bg-violet-600 text-white text-sm">{c.username.slice(0, 2).toUpperCase()}</AvatarFallback>
                      </Avatar>
                      {c.isActive && <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 rounded-full border-2 border-[#0a0a12]" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-white text-sm truncate">{c.username}</span>
                        <span className="text-[10px] text-white/30 flex-shrink-0">{new Date(c.lastMessageTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                      </div>
                      <div className="flex items-center justify-between gap-2">
                        <span className={`text-xs truncate ${c.unreadCount > 0 ? 'text-white' : 'text-white/40'}`}>{c.lastFromMe ? 'You: ' : ''}{c.lastMessage}</span>
                        {c.unreadCount > 0 && <Badge className="bg-violet-500 text-white text-[10px] h-4 px-1.5">{c.unreadCount}</Badge>}
                      </div>
                    </div>
                  </button>
                ))
              )}

              {tab === 'groups' && (
                filteredGroups.length === 0 ? (
                  <Empty icon={<Users className="w-8 h-8" />} title="No groups yet" sub="Create one with the + button" />
                ) : filteredGroups.map(g => (
                  <button key={g.id} onClick={() => openGroup(g)}
                    className={`w-full flex items-center gap-3 px-3 py-2.5 hover:bg-white/[0.04] border-b border-white/[0.04] text-left transition ${selected?.type === 'group' && selected.groupId === g.id ? 'bg-white/[0.05]' : ''}`}>
                    <Avatar className="w-11 h-11">
                      {g.avatar && <AvatarImage src={g.avatar} />}
                      <AvatarFallback className="bg-cyan-600 text-white"><Users className="w-5 h-5" /></AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-white text-sm truncate">{g.name}</div>
                      <div className="text-xs text-white/40 truncate">
                        {g.memberCount} members{g.lastMessage ? ` · ${g.lastMessage.senderName}: ${g.lastMessage.content || g.lastMessage.kind.toLowerCase()}` : ''}
                      </div>
                    </div>
                  </button>
                ))
              )}

              {tab === 'friends' && (
                <div className="p-3 space-y-3">
                  {/* Search box */}
                  <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-white/30" />
                    <Input value={userQuery} onChange={e => setUserQuery(e.target.value)} placeholder="Search people…" className="pl-9 h-9 bg-black/30 border-white/[0.08] text-sm" />
                  </div>

                  {/* Pending friend requests */}
                  {pendingRequests.length > 0 && (
                    <div>
                      <div className="text-[11px] uppercase text-amber-400/80 tracking-wider px-1 mb-1">Pending Requests ({pendingRequests.length})</div>
                      <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-1 space-y-0.5">
                        {pendingRequests.map((req: any) => (
                          <div key={req.id} className="flex items-center gap-2 px-2 py-1.5">
                            <Avatar className="w-8 h-8 shrink-0"><AvatarImage src={req.sender?.avatar} /><AvatarFallback className="bg-amber-600 text-white text-xs">{req.sender?.username?.slice(0, 2).toUpperCase()}</AvatarFallback></Avatar>
                            <span className="text-sm flex-1 truncate">{req.sender?.username}</span>
                            <Button size="sm" className="h-6 text-[10px] bg-emerald-600 hover:bg-emerald-500 px-2" onClick={async () => {
                              const r = await fetch('/api/friends/accept-request', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ requestId: req.id }) })
                              if (r.ok) { toast.success('Friend added!'); setPendingRequests(p => p.filter(x => x.id !== req.id)); loadFriends() }
                              else { const e = await r.json().catch(() => ({})); toast.error(e.error || 'Failed') }
                            }}>✓</Button>
                            <Button size="sm" variant="ghost" className="h-6 text-[10px] text-white/50 hover:text-red-400 px-2" onClick={async () => {
                              const r = await fetch('/api/friends/reject-request', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ requestId: req.id }) })
                              if (r.ok) setPendingRequests(p => p.filter(x => x.id !== req.id))
                            }}>✕</Button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* User list (all or searched) — 🔍 Find Friends */}
                  {(() => {
                    const displayUsers = userQuery.trim() ? userHits : allUsers
                    const friendIds = new Set(friends.map(f => f.id))
                    const pendingFromIds = new Set(pendingRequests.map((r: any) => r.senderId))
                    const usersToShow = displayUsers.filter(u => !friendIds.has(u.id))
                    return (
                      <div>
                        <div className="text-[11px] uppercase text-violet-300 tracking-wider px-1 mb-1 flex items-center gap-1">
                          <UserPlus className="w-3 h-3" /> {userQuery.trim() ? 'Search Results' : `Find Friends (${usersToShow.length})`}
                        </div>
                        <div className="rounded-xl border border-white/[0.06] bg-black/20 p-1 space-y-0.5">
                          {usersToShow.length === 0 ? (
                            <p className="text-xs text-white/30 px-2 py-2">No users found</p>
                          ) : usersToShow.map(u => {
                            const isFriend = friendIds.has(u.id)
                            const isPendingFrom = pendingFromIds.has(u.id)
                            const hasSent = sentRequestIds.has(u.id)
                            return (
                              <div key={u.id} className="flex items-center gap-2 px-2 py-1.5">
                                <Avatar className="w-8 h-8 shrink-0"><AvatarImage src={u.avatar} /><AvatarFallback className="bg-violet-600 text-white text-xs">{u.username.slice(0, 2).toUpperCase()}</AvatarFallback></Avatar>
                                <span className="text-sm flex-1 truncate">{u.username}</span>
                                {isFriend ? (
                                  <span className="text-[10px] text-emerald-400">Friends</span>
                                ) : isPendingFrom ? (
                                  <Button size="sm" className="h-6 text-[10px] bg-emerald-600 hover:bg-emerald-500 px-2" onClick={async () => {
                                    const req = pendingRequests.find((r: any) => r.senderId === u.id)
                                    if (!req) return
                                    const r = await fetch('/api/friends/accept-request', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ requestId: req.id }) })
                                    if (r.ok) { toast.success('Friend added!'); setPendingRequests(p => p.filter(x => x.senderId !== u.id)); loadFriends() }
                                  }}>Accept</Button>
                                ) : hasSent ? (
                                  <span className="text-[10px] text-white/40">Sent</span>
                                ) : (
                                  <Button size="sm" className="h-6 text-[10px] bg-violet-600 hover:bg-violet-500 px-2" onClick={async () => {
                                    const r = await fetch('/api/friends/send-request', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ receiverId: u.id }) })
                                    if (r.ok) { toast.success('Request sent!'); setSentRequestIds(prev => new Set([...prev, u.id])) }
                                    else { const e = await r.json().catch(() => ({})); toast.error(e.error || 'Failed') }
                                  }}><UserPlus className="w-3 h-3 mr-1" />Add</Button>
                                )}
                              </div>
                            )
                          })}
                        </div>
                      </div>
                    )
                  })()}

                  {/* Confirmed friends */}
                  <div className="text-[11px] uppercase text-white/40 tracking-wider px-1">Your Friends ({friends.length})</div>
                  {friends.length === 0 ? (
                    <p className="text-sm text-white/40 px-1">No friends yet. Add someone above.</p>
                  ) : friends.map(f => (
                    <button key={f.id} onClick={() => openDM(f)} className="w-full flex items-center gap-3 px-2 py-2 rounded-lg hover:bg-white/[0.04] text-left">
                      <Avatar className="w-9 h-9"><AvatarImage src={f.avatar} /><AvatarFallback className="bg-violet-600 text-white text-xs">{f.username.slice(0, 2).toUpperCase()}</AvatarFallback></Avatar>
                      <span className="text-sm flex-1 truncate">{f.username}</span>
                      {f.isActive && <span className="w-2 h-2 bg-emerald-500 rounded-full" />}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </aside>

          {/* ── Chat panel */}
          <section className={`${!selected ? 'hidden lg:flex' : 'flex'} flex-col bg-white/[0.02] border border-white/[0.08] rounded-2xl overflow-hidden min-h-0`}>
            {!selected ? (
              <div className="flex-1 flex items-center justify-center text-center text-white/40 p-8">
                <div>
                  <MessageCircle className="w-14 h-14 mx-auto text-white/15 mb-3" />
                  <p className="text-sm">Pick a chat or group to start messaging</p>
                </div>
              </div>
            ) : (
              <>
                {/* Header */}
                <div className="flex items-center gap-3 px-4 py-3 border-b border-white/[0.06]">
                  <button onClick={() => setSelected(null)} className="lg:hidden p-1 text-white/60 hover:text-white"><ArrowLeft className="w-5 h-5" /></button>
                  <Avatar className="w-9 h-9">
                    {(selected.type === 'dm' ? selected.avatar : selected.avatar) && <AvatarImage src={selected.type === 'dm' ? selected.avatar : selected.avatar} />}
                    <AvatarFallback className="bg-violet-600 text-white text-xs">{(selected.type === 'dm' ? selected.username : selected.name).slice(0, 2).toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-white text-sm truncate">{selected.type === 'dm' ? selected.username : selected.name}</div>
                    <div className="text-[11px] text-white/50">
                      {selected.type === 'dm' ? (peerTyping ? 'Typing…' : (selected.isActive ? 'Online' : 'Offline')) : `${selected.memberIds.length} members`}
                    </div>
                  </div>
                  {selected.type === 'dm' && (
                    <>
                      <button onClick={() => startCall('AUDIO')} className="p-2 rounded-lg hover:bg-white/[0.06] text-white/70 hover:text-emerald-400" title="Voice call"><Phone className="w-4 h-4" /></button>
                      <button onClick={() => startCall('VIDEO')} className="p-2 rounded-lg hover:bg-white/[0.06] text-white/70 hover:text-violet-400" title="Video call"><VideoIcon className="w-4 h-4" /></button>
                    </>
                  )}
                </div>

                {/* Messages */}
                <div className="flex-1 overflow-y-auto px-3 sm:px-5 py-4 space-y-2">
                  {loading ? (
                    <div className="flex items-center justify-center py-12"><Loader2 className="w-5 h-5 animate-spin text-violet-400" /></div>
                  ) : messages.length === 0 ? (
                    <div className="text-center py-16 text-white/30 text-sm">No messages yet — send the first one!</div>
                  ) : messages.map((m, i) => {
                    const isOwn = m.senderId === myId
                    const prev = messages[i - 1]
                    const showAvatar = !isOwn && (!prev || prev.senderId !== m.senderId)
                    return (
                      <div key={m.id} className={`flex ${isOwn ? 'justify-end' : 'justify-start'} gap-2`}>
                        {!isOwn && (
                          <div className="w-7 flex-shrink-0">
                            {showAvatar && (
                              <Avatar className="w-7 h-7 mt-1">
                                {m.sender?.avatar && <AvatarImage src={m.sender.avatar} />}
                                <AvatarFallback className="bg-violet-600 text-white text-[10px]">{(m.sender?.username || '?').slice(0, 2).toUpperCase()}</AvatarFallback>
                              </Avatar>
                            )}
                          </div>
                        )}
                        <div className={`max-w-[75%] ${isOwn ? 'items-end' : 'items-start'} flex flex-col`}>
                          {selected.type === 'group' && !isOwn && showAvatar && (
                            <span className="text-[10px] text-white/40 mb-0.5 px-2">{m.sender?.username}</span>
                          )}
                          <div className={`px-3.5 py-2 rounded-2xl text-sm ${
                            m.kind === 'CALL'
                              ? 'bg-white/[0.04] border border-white/[0.06] text-white/70 italic'
                              : isOwn
                                ? 'bg-gradient-to-br from-violet-600 to-cyan-600 text-white rounded-br-md'
                                : 'bg-white/[0.06] text-white/90 border border-white/[0.04] rounded-bl-md'
                          }`}>
                            <MediaPreview msg={m} />
                          </div>
                          <span className="text-[10px] text-white/30 mt-0.5 px-2">{new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                        </div>
                      </div>
                    )
                  })}
                  {peerTyping && (
                    <div className="flex justify-start gap-2"><div className="px-3 py-2 rounded-2xl bg-white/[0.06] text-white/60 text-xs">typing…</div></div>
                  )}
                  <div ref={messagesEndRef} />
                </div>

                {/* Composer */}
                <div className="border-t border-white/[0.06] p-3">
                  {recorder.recording ? (
                    <div className="flex items-center gap-3 bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2.5">
                      <span className="w-2.5 h-2.5 bg-red-500 rounded-full animate-pulse" />
                      <span className="text-sm text-red-200">Recording… {fmtSec(recorder.seconds)}</span>
                      <div className="flex-1" />
                      <button onClick={recorder.cancel} className="p-2 rounded-lg hover:bg-white/[0.06] text-white/60 hover:text-red-400" title="Cancel"><Trash2 className="w-4 h-4" /></button>
                      <button onClick={toggleVoiceRecord} className="p-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white" title="Send"><Send className="w-4 h-4" /></button>
                    </div>
                  ) : (
                    <form onSubmit={e => { e.preventDefault(); sendText() }} className="flex items-end gap-2">
                      <input ref={imageInputRef} type="file" accept="image/*,video/*" hidden onChange={onPickImage} />
                      <input ref={fileInputRef} type="file" hidden onChange={onPickFile} />
                      <button type="button" onClick={() => imageInputRef.current?.click()} className="p-2.5 rounded-xl hover:bg-white/[0.06] text-white/60 hover:text-violet-400" title="Photo or video"><ImageIcon className="w-4 h-4" /></button>
                      <button type="button" onClick={() => fileInputRef.current?.click()} className="p-2.5 rounded-xl hover:bg-white/[0.06] text-white/60 hover:text-cyan-400" title="File"><Paperclip className="w-4 h-4" /></button>
                      <button type="button" onClick={toggleVoiceRecord} className="p-2.5 rounded-xl hover:bg-white/[0.06] text-white/60 hover:text-fuchsia-400" title="Voice note"><Mic className="w-4 h-4" /></button>
                      <Input value={draft} onChange={e => onDraftChange(e.target.value)} placeholder="Type a message…" className="flex-1 h-10 bg-black/30 border-white/[0.08] text-sm rounded-xl" />
                      <Button type="submit" disabled={!draft.trim()} className="h-10 px-4 bg-gradient-to-r from-violet-600 to-cyan-600 hover:from-violet-500 hover:to-cyan-500 rounded-xl"><Send className="w-4 h-4" /></Button>
                    </form>
                  )}
                </div>
              </>
            )}
          </section>
        </div>
      </div>

      {/* New group modal */}
      {showNewGroup && (
        <div className="fixed inset-0 z-[90] bg-black/70 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-md rounded-2xl border border-white/[0.08] bg-[#0f0f1a] p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-white flex items-center gap-2"><Users className="w-4 h-4 text-cyan-400" /> New group</h3>
              <button onClick={() => setShowNewGroup(false)} className="p-1 text-white/60 hover:text-white"><X className="w-4 h-4" /></button>
            </div>
            <Input value={newGroupName} onChange={e => setNewGroupName(e.target.value)} placeholder="Group name" className="bg-black/30 border-white/[0.08]" />
            <div className="space-y-1.5">
              <div className="text-xs text-white/50 uppercase tracking-wider">Add friends</div>
              <div className="max-h-56 overflow-y-auto rounded-xl border border-white/[0.06] divide-y divide-white/[0.04]">
                {friends.length === 0 && <p className="text-sm text-white/40 p-3">Add friends first to create a group.</p>}
                {friends.map(f => {
                  const checked = newGroupMembers.includes(f.id)
                  return (
                    <label key={f.id} className="flex items-center gap-2 px-3 py-2 cursor-pointer hover:bg-white/[0.03]">
                      <input type="checkbox" checked={checked} onChange={e => setNewGroupMembers(prev => e.target.checked ? [...prev, f.id] : prev.filter(x => x !== f.id))} className="accent-violet-600" />
                      <Avatar className="w-7 h-7"><AvatarImage src={f.avatar} /><AvatarFallback className="bg-violet-600 text-white text-[10px]">{f.username.slice(0, 2).toUpperCase()}</AvatarFallback></Avatar>
                      <span className="text-sm">{f.username}</span>
                    </label>
                  )
                })}
              </div>
            </div>
            <Button onClick={createGroup} className="w-full bg-gradient-to-r from-violet-600 to-cyan-600">Create group</Button>
          </div>
        </div>
      )}

      {/* Active call modal */}
      {activeCall && (
        <CallModal
          open={!!activeCall} onClose={() => setActiveCall(null)}
          callId={activeCall.callId} peer={activeCall.peer} type={activeCall.type}
          isInitiator={activeCall.isInitiator} myUserId={myId} initialAccepted={activeCall.initialAccepted}
        />
      )}
    </div>
  )
}

function Empty({ icon, title, sub }: { icon: React.ReactNode; title: string; sub?: string }) {
  return (
    <div className="text-center py-16 px-4">
      <div className="text-white/15 inline-block mb-3">{icon}</div>
      <p className="text-sm text-white/50 mb-1">{title}</p>
      {sub && <p className="text-xs text-white/30">{sub}</p>}
    </div>
  )
}

export default function MessagesPage() {
  return (
    <Suspense fallback={null}>
      <MessagesPageInner />
    </Suspense>
  )
}
