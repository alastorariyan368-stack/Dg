'use client'

import { useState } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import {
  Loader2, Download, Play, RefreshCw, Wand2, Film,
  FileText, Lightbulb, MonitorPlay, Smartphone, Square,
  ChevronRight, Sparkles, Video, Globe, CheckCircle2
} from 'lucide-react'

type Mode = 'text-to-video' | 'script' | 'topic'
type Aspect = '16:9' | '9:16' | '1:1'

const ASPECTS = [
  { id: '16:9' as Aspect, label: 'Landscape', icon: MonitorPlay, box: 'aspect-video' },
  { id: '9:16' as Aspect, label: 'Vertical', icon: Smartphone, box: 'aspect-[9/16] max-w-[240px] mx-auto' },
  { id: '1:1' as Aspect, label: 'Square', icon: Square, box: 'aspect-square max-w-[400px] mx-auto' },
]

const DURATIONS = [4, 6, 8, 10, 12, 16]

const TEMPLATES = [
  { label: 'Product Demo', topic: 'A sleek product demo showcasing a modern smartphone with cinematic camera movements and professional studio lighting' },
  { label: 'Nature Scene', topic: 'A breathtaking aerial view of mountains at golden hour with flowing rivers and lush forests below' },
  { label: 'City Life', topic: 'Timelapse of a bustling metropolitan city from dawn to dusk with vibrant street life and glowing neon signs' },
  { label: 'Food Ad', topic: 'A mouthwatering close-up of gourmet food being plated by a chef in a professional kitchen' },
  { label: 'Tech Future', topic: 'Futuristic holographic interfaces and AI robots working alongside humans in a high-tech lab' },
  { label: 'Travel', topic: 'Drone footage of tropical beach paradise with turquoise water, white sand, and swaying palm trees' },
]

export default function GoogleVidsPage() {
  const { status } = useSession()
  const router = useRouter()

  const [mode, setMode] = useState<Mode>('text-to-video')
  const [prompt, setPrompt] = useState('')
  const [script, setScript] = useState('')
  const [topic, setTopic] = useState('')
  const [aspect, setAspect] = useState<Aspect>('16:9')
  const [duration, setDuration] = useState(8)
  const [loading, setLoading] = useState(false)
  const [videoUrl, setVideoUrl] = useState('')
  const [error, setError] = useState('')

  if (status === 'unauthenticated') {
    if (typeof window !== 'undefined') router.push('/auth/signin')
    return null
  }

  const generate = async () => {
    setError('')
    setVideoUrl('')
    setLoading(true)
    try {
      const res = await fetch('/api/google-vids', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          mode,
          prompt: mode === 'text-to-video' ? prompt : undefined,
          script: mode === 'script' ? script : undefined,
          topic: mode === 'topic' ? topic : undefined,
          aspectRatio: aspect,
          durationSeconds: duration,
        }),
      })
      const data = await res.json()
      if (!res.ok) { setError(data.error || 'Generation failed'); return }
      setVideoUrl(data.videoUrl)
      toast.success('Video generated with Google Veo!')
    } catch {
      setError('Connection error. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const downloadVideo = async () => {
    if (!videoUrl) return
    try {
      const r = await fetch(videoUrl)
      const blob = await r.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `google-vids-${Date.now()}.mp4`
      document.body.appendChild(a); a.click(); document.body.removeChild(a)
      URL.revokeObjectURL(url)
      toast.success('Video downloaded')
    } catch { window.open(videoUrl, '_blank') }
  }

  const aspectObj = ASPECTS.find(a => a.id === aspect) || ASPECTS[0]

  return (
    <div className="min-h-screen bg-[#0a0a12] text-white flex flex-col">
      <Navbar />

      <div className="flex-1 container mx-auto px-4 py-10 max-w-6xl">

        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 mb-4 px-4 py-1.5 rounded-full bg-blue-500/10 border border-blue-500/20 text-blue-400 text-sm font-medium">
            <Video className="w-4 h-4" />
            Powered by Google Veo
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            <span className="bg-gradient-to-r from-blue-400 via-cyan-400 to-green-400 bg-clip-text text-transparent">
              Google Vids
            </span>
          </h1>
          <p className="text-white/50 text-lg max-w-2xl mx-auto">
            Create stunning AI-generated videos using Google's Veo model — text to video, scripts, topics, and more
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-8">

          {/* Left: Controls */}
          <div className="lg:col-span-2 space-y-5">

            {/* Mode tabs */}
            <div>
              <Label className="text-white/50 text-xs uppercase tracking-wider mb-2 block">Creation Mode</Label>
              <div className="grid grid-cols-3 gap-1.5 bg-white/5 p-1.5 rounded-xl">
                {[
                  { id: 'text-to-video' as Mode, icon: Wand2, label: 'Prompt' },
                  { id: 'script' as Mode, icon: FileText, label: 'Script' },
                  { id: 'topic' as Mode, icon: Lightbulb, label: 'Topic' },
                ].map(m => (
                  <button key={m.id} onClick={() => setMode(m.id)}
                    className={`flex flex-col items-center gap-1 py-2.5 rounded-lg text-xs font-medium transition-all ${
                      mode === m.id ? 'bg-white/10 text-white' : 'text-white/40 hover:text-white/60'
                    }`}
                  >
                    <m.icon className="w-4 h-4" />
                    {m.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Input based on mode */}
            {mode === 'text-to-video' && (
              <div>
                <Label className="text-white/50 text-xs uppercase tracking-wider mb-2 block">Video Prompt</Label>
                <Textarea
                  value={prompt}
                  onChange={e => setPrompt(e.target.value)}
                  placeholder="Describe the video you want to create... e.g. 'A majestic eagle soaring over mountain peaks at sunrise with dramatic clouds'"
                  rows={5}
                  className="bg-white/5 border-white/10 text-white placeholder:text-white/25 resize-none focus:border-blue-500"
                />
              </div>
            )}

            {mode === 'script' && (
              <div>
                <Label className="text-white/50 text-xs uppercase tracking-wider mb-2 block">Video Script</Label>
                <Textarea
                  value={script}
                  onChange={e => setScript(e.target.value)}
                  placeholder="Write your video script here... Each paragraph will become a scene. The AI will create visuals that match your narrative."
                  rows={6}
                  className="bg-white/5 border-white/10 text-white placeholder:text-white/25 resize-none focus:border-blue-500"
                />
                <p className="text-xs text-white/30 mt-1.5">The AI will create visuals matching your script's narrative</p>
              </div>
            )}

            {mode === 'topic' && (
              <div>
                <Label className="text-white/50 text-xs uppercase tracking-wider mb-2 block">Topic or Title</Label>
                <Input
                  value={topic}
                  onChange={e => setTopic(e.target.value)}
                  placeholder="e.g. Climate Change, Product Launch, Travel Vlog..."
                  className="bg-white/5 border-white/10 text-white placeholder:text-white/30 focus:border-blue-500"
                />
                <div className="grid grid-cols-2 gap-1.5 mt-2">
                  {TEMPLATES.map(t => (
                    <button key={t.label} onClick={() => { setTopic(t.topic); setMode('text-to-video'); setPrompt(t.topic) }}
                      className="text-left px-3 py-2 rounded-lg bg-white/5 border border-white/8 hover:border-blue-500/40 hover:bg-white/8 transition-all text-xs text-white/60 hover:text-white">
                      {t.label} →
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Aspect ratio */}
            <div>
              <Label className="text-white/50 text-xs uppercase tracking-wider mb-2 block">Aspect Ratio</Label>
              <div className="grid grid-cols-3 gap-2">
                {ASPECTS.map(a => (
                  <button key={a.id} onClick={() => setAspect(a.id)}
                    className={`flex flex-col items-center gap-1.5 py-3 rounded-xl border transition-all text-xs font-medium ${
                      aspect === a.id
                        ? 'border-blue-500 bg-blue-500/15 text-blue-300'
                        : 'border-white/10 bg-white/3 text-white/50 hover:border-white/20'
                    }`}
                  >
                    <a.icon className="w-4 h-4" />
                    {a.id}
                    <span className="text-[10px] opacity-60">{a.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Duration */}
            <div>
              <Label className="text-white/50 text-xs uppercase tracking-wider mb-2 block">
                Duration — {duration}s
              </Label>
              <div className="flex gap-1.5 flex-wrap">
                {DURATIONS.map(d => (
                  <button key={d} onClick={() => setDuration(d)}
                    className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all border ${
                      duration === d
                        ? 'border-blue-500 bg-blue-500/20 text-blue-300'
                        : 'border-white/10 text-white/40 hover:border-white/20 hover:text-white/60'
                    }`}
                  >
                    {d}s
                  </button>
                ))}
              </div>
            </div>

            {/* Generate button */}
            <Button
              onClick={generate}
              disabled={loading || (!prompt.trim() && !script.trim() && !topic.trim())}
              className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-500 hover:to-cyan-500 text-white font-semibold h-12 rounded-xl text-base"
            >
              {loading
                ? <><Loader2 className="w-5 h-5 mr-2 animate-spin" /> Generating with Google Veo...</>
                : <><Sparkles className="w-5 h-5 mr-2" /> Generate Video</>
              }
            </Button>

            {loading && (
              <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-4 text-sm text-blue-300">
                <div className="flex items-start gap-2">
                  <RefreshCw className="w-4 h-4 animate-spin mt-0.5 shrink-0" />
                  <div>
                    <div className="font-medium mb-1">Google Veo is working...</div>
                    <div className="text-blue-300/60 text-xs">This usually takes 1–3 minutes. High-quality videos take longer.</div>
                  </div>
                </div>
              </div>
            )}

            {error && (
              <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 text-sm text-red-300">
                {error}
                {error.includes('API key') && (
                  <a href="/admin/api-keys" className="ml-2 text-red-400 underline hover:text-red-300">
                    Configure in Admin
                  </a>
                )}
              </div>
            )}

            {/* Features */}
            <div className="bg-white/3 border border-white/8 rounded-xl p-4 space-y-2">
              <div className="text-xs font-semibold text-white/40 uppercase tracking-wider mb-3">Google Veo Features</div>
              {[
                { label: 'Cinematic quality', desc: 'Professional-grade video output' },
                { label: 'Prompt enhancement', desc: 'AI auto-improves your descriptions' },
                { label: 'Multiple aspects', desc: '16:9, 9:16, and 1:1 formats' },
                { label: 'Duration control', desc: '4–16 second clips' },
                { label: 'Person generation', desc: 'Realistic people in scenes' },
              ].map(f => (
                <div key={f.label} className="flex items-start gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-green-400 mt-0.5 shrink-0" />
                  <div>
                    <span className="text-xs text-white/70 font-medium">{f.label}</span>
                    <span className="text-xs text-white/35"> — {f.desc}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Preview */}
          <div className="lg:col-span-3">
            <div className="sticky top-6">
              <Label className="text-white/50 text-xs uppercase tracking-wider mb-3 block">Preview</Label>

              {videoUrl ? (
                <div className="space-y-4">
                  <div className={`w-full overflow-hidden rounded-2xl bg-black border border-white/10 ${aspectObj.box}`}>
                    <video
                      key={videoUrl}
                      src={videoUrl}
                      autoPlay
                      loop
                      muted
                      playsInline
                      controls
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex gap-3">
                    <Button onClick={downloadVideo} className="flex-1 bg-white/10 hover:bg-white/15 text-white border border-white/10">
                      <Download className="w-4 h-4 mr-2" /> Download MP4
                    </Button>
                    <Button onClick={generate} disabled={loading} className="bg-blue-600 hover:bg-blue-500 text-white px-5">
                      <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} /> Regenerate
                    </Button>
                  </div>
                </div>
              ) : (
                <div className={`w-full overflow-hidden rounded-2xl bg-white/3 border border-dashed border-white/10 flex flex-col items-center justify-center text-center p-12 ${aspectObj.box}`}>
                  {loading ? (
                    <div className="space-y-3">
                      <div className="relative">
                        <div className="w-16 h-16 rounded-full border-2 border-blue-500/30 border-t-blue-500 animate-spin mx-auto" />
                        <Globe className="w-6 h-6 text-blue-400 absolute inset-0 m-auto" />
                      </div>
                      <div className="text-sm text-white/50">Google Veo is generating your video...</div>
                    </div>
                  ) : (
                    <>
                      <Film className="w-12 h-12 text-white/15 mb-4" />
                      <div className="text-white/30 text-sm">Your video will appear here</div>
                      <div className="text-white/20 text-xs mt-1">Powered by Google Veo AI</div>
                    </>
                  )}
                </div>
              )}

              {/* How it works */}
              {!videoUrl && !loading && (
                <div className="mt-6 space-y-3">
                  <div className="text-xs font-semibold text-white/40 uppercase tracking-wider">How it works</div>
                  {[
                    { step: '1', text: 'Write a prompt, script, or choose a topic above' },
                    { step: '2', text: 'Select your aspect ratio and video duration' },
                    { step: '3', text: 'Click Generate — Google Veo creates your video in 1–3 min' },
                    { step: '4', text: 'Preview, download or regenerate until perfect' },
                  ].map(s => (
                    <div key={s.step} className="flex items-center gap-3 text-sm text-white/40">
                      <div className="w-6 h-6 rounded-full bg-blue-500/15 border border-blue-500/20 text-blue-400 text-xs font-bold flex items-center justify-center shrink-0">
                        {s.step}
                      </div>
                      {s.text}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  )
}
