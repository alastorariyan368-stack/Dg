'use client'

import { useState } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import {
  Loader2, Sparkles, Youtube, Copy, Check, Download,
  RefreshCw, Hash, Tag, FileText, Image as ImageIcon, ListTree, Megaphone,
} from 'lucide-react'

const STYLES = [
  { id: 'tech', label: 'Tech' },
  { id: 'gaming', label: 'Gaming' },
  { id: 'vlog', label: 'Vlog' },
  { id: 'cinematic', label: 'Cinematic' },
  { id: 'tutorial', label: 'Tutorial' },
  { id: 'music', label: 'Music' },
  { id: 'shorts', label: 'Shorts' },
  { id: 'podcast', label: 'Podcast' },
  { id: 'news', label: 'News' },
  { id: 'review', label: 'Review' },
]

interface YtResult {
  title: string
  description: string
  tags: string[]
  hashtags: string[]
  shortDescription: string
  thumbnailPrompt: string
  thumbnailUrl?: string | null
  thumbnailError?: string | null
  chapters?: { time: string; label: string }[]
  callToAction?: string
}

export default function YouTubeGenPage() {
  const { status } = useSession()
  const router = useRouter()

  const [prompt, setPrompt] = useState('')
  const [style, setStyle] = useState('tech')
  const [language, setLanguage] = useState<'en' | 'bn'>('en')
  const [tone, setTone] = useState('engaging, friendly, professional')
  const [includeChapters, setIncludeChapters] = useState(true)
  const [generateThumbnail, setGenerateThumbnail] = useState(true)
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState<YtResult | null>(null)
  const [copiedKey, setCopiedKey] = useState<string | null>(null)

  if (status === 'unauthenticated') {
    if (typeof window !== 'undefined') router.push('/auth/signin')
    return null
  }

  const generate = async () => {
    if (!prompt.trim()) { toast.error('Write your video idea first'); return }
    setLoading(true); setResult(null)
    try {
      const res = await fetch('/api/ai/generate/youtube', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: prompt.trim(),
          style, language, tone,
          includeChapters,
          generateThumbnail,
        }),
      })
      const data = await res.json()
      if (!res.ok) {
        toast.error(data.error || 'Generation failed')
        return
      }
      setResult(data)
      if (data.thumbnailError) toast.warning(`Thumbnail: ${data.thumbnailError}`)
      else toast.success('YouTube package ready!')
    } catch {
      toast.error('Connection error. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const copy = async (key: string, text: string) => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedKey(key)
      setTimeout(() => setCopiedKey(null), 1400)
    } catch { toast.error('Copy failed') }
  }

  const downloadThumbnail = async () => {
    if (!result?.thumbnailUrl) return
    try {
      const r = await fetch(result.thumbnailUrl)
      const blob = await r.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `yt-thumbnail-${Date.now()}.png`
      document.body.appendChild(a); a.click(); document.body.removeChild(a)
      URL.revokeObjectURL(url)
      toast.success('Thumbnail downloaded')
    } catch { window.open(result.thumbnailUrl!, '_blank') }
  }

  const fullDescriptionWithMeta = (() => {
    if (!result) return ''
    const parts = [result.description]
    if (result.callToAction) parts.push('', result.callToAction)
    if (result.chapters?.length) {
      parts.push('', '⏱ Chapters:')
      result.chapters.forEach(c => parts.push(`${c.time} — ${c.label}`))
    }
    if (result.hashtags?.length) parts.push('', result.hashtags.join(' '))
    return parts.join('\n')
  })()

  return (
    <div className="min-h-screen bg-[#0a0a12] text-white flex flex-col">
      <Navbar />
      <div className="flex-1 container mx-auto px-4 py-8 max-w-6xl">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-red-500/10 border border-red-500/20 rounded-full px-4 py-1.5 mb-4">
            <Youtube className="w-4 h-4 text-red-400" />
            <span className="text-red-300 text-sm font-medium">AI YouTube Studio</span>
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">YouTube Gen</h1>
          <p className="text-white/50 text-sm">
            Give one prompt — get a click-worthy title, SEO description, tags, hashtags, chapters, and a custom thumbnail.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
          {/* Input panel */}
          <div className="lg:col-span-2 bg-white/[0.03] border border-white/10 rounded-2xl p-5 space-y-4 h-fit">
            <div className="space-y-1.5">
              <Label className="text-sm text-white/70">Your video idea</Label>
              <Textarea
                placeholder="e.g. Top 10 free AI tools every developer should know in 2026"
                value={prompt}
                onChange={e => setPrompt(e.target.value)}
                rows={5}
                className="bg-black/40 border-white/10 text-white placeholder:text-white/30 resize-none rounded-xl"
              />
              <div className="text-xs text-white/30 text-right">{prompt.length}/2000</div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-sm text-white/70">Style</Label>
              <div className="flex flex-wrap gap-1.5">
                {STYLES.map(s => (
                  <button key={s.id} onClick={() => setStyle(s.id)}
                    className={`px-3 py-1 rounded-lg text-xs font-medium border transition ${
                      style === s.id
                        ? 'bg-violet-600 border-violet-500 text-white'
                        : 'bg-white/[0.03] border-white/10 text-white/60 hover:text-white hover:bg-white/[0.06]'
                    }`}>
                    {s.label}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label className="text-sm text-white/70">Language</Label>
                <div className="flex gap-1.5">
                  {(['en', 'bn'] as const).map(l => (
                    <button key={l} onClick={() => setLanguage(l)}
                      className={`flex-1 px-3 py-1.5 rounded-lg text-xs font-medium border transition ${
                        language === l
                          ? 'bg-cyan-600 border-cyan-500 text-white'
                          : 'bg-white/[0.03] border-white/10 text-white/60 hover:text-white'
                      }`}>
                      {l === 'en' ? 'English' : 'বাংলা'}
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-sm text-white/70">Tone</Label>
                <Input
                  value={tone}
                  onChange={e => setTone(e.target.value)}
                  placeholder="engaging, friendly"
                  className="bg-black/40 border-white/10 text-white text-sm"
                />
              </div>
            </div>

            <div className="space-y-2 pt-1">
              <div className="flex items-center justify-between">
                <Label className="text-sm text-white/70">Include chapters</Label>
                <Switch checked={includeChapters} onCheckedChange={setIncludeChapters} />
              </div>
              <div className="flex items-center justify-between">
                <Label className="text-sm text-white/70">Generate thumbnail</Label>
                <Switch checked={generateThumbnail} onCheckedChange={setGenerateThumbnail} />
              </div>
            </div>

            <Button onClick={generate} disabled={loading || !prompt.trim()}
              className="w-full h-11 bg-gradient-to-r from-red-600 to-violet-600 hover:from-red-500 hover:to-violet-500 border-0 rounded-xl text-white font-medium gap-2">
              {loading ? (<><Loader2 className="w-4 h-4 animate-spin" /> Generating…</>)
                       : (<><Sparkles className="w-4 h-4" /> Generate Full Package</>)}
            </Button>

            <p className="text-[11px] text-white/30 leading-relaxed">
              Tip: Add a key in Admin → AI API Keys for stronger results. Falls back automatically across all configured providers.
            </p>
          </div>

          {/* Output panel */}
          <div className="lg:col-span-3 space-y-4">
            {!result && !loading && (
              <div className="rounded-2xl border border-dashed border-white/10 p-12 text-center text-white/40 text-sm">
                <Youtube className="w-10 h-10 text-white/15 mx-auto mb-3" />
                Your generated package will appear here.
              </div>
            )}

            {loading && (
              <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-12 text-center">
                <Loader2 className="w-10 h-10 text-violet-400 animate-spin mx-auto mb-3" />
                <p className="text-white/60 text-sm">Generating title, description, tags & thumbnail…</p>
                <p className="text-white/30 text-xs mt-1">This may take 15–60 seconds</p>
              </div>
            )}

            {result && (
              <>
                {/* Thumbnail */}
                {result.thumbnailUrl && (
                  <div className="rounded-2xl border border-white/10 bg-white/[0.02] overflow-hidden">
                    <div className="flex items-center justify-between px-4 py-2.5 border-b border-white/[0.06]">
                      <div className="flex items-center gap-2 text-sm font-semibold text-white/80">
                        <ImageIcon className="w-4 h-4 text-cyan-400" /> Thumbnail
                      </div>
                      <div className="flex gap-2">
                        <button onClick={downloadThumbnail} className="text-xs text-white/60 hover:text-white inline-flex items-center gap-1"><Download className="w-3.5 h-3.5" /> Download</button>
                        <button onClick={generate} className="text-xs text-white/60 hover:text-white inline-flex items-center gap-1"><RefreshCw className="w-3.5 h-3.5" /> Regenerate</button>
                      </div>
                    </div>
                    <img src={result.thumbnailUrl} alt="thumbnail" className="w-full block" />
                  </div>
                )}
                {result.thumbnailError && !result.thumbnailUrl && (
                  <div className="rounded-2xl border border-amber-500/20 bg-amber-500/5 p-4 text-xs text-amber-200/80">
                    Thumbnail couldn't be generated: {result.thumbnailError}
                  </div>
                )}

                {/* Title */}
                <FieldCard label="Title" icon={<FileText className="w-4 h-4 text-violet-400" />}
                  copyKey="title" copiedKey={copiedKey} onCopy={() => copy('title', result.title)} text={result.title}>
                  <p className="text-base font-semibold text-white leading-snug">{result.title}</p>
                  <p className="text-[11px] text-white/30 mt-1">{result.title.length} chars</p>
                </FieldCard>

                {/* Short description */}
                <FieldCard label="Short description (social)" icon={<Megaphone className="w-4 h-4 text-amber-400" />}
                  copyKey="short" copiedKey={copiedKey} onCopy={() => copy('short', result.shortDescription)} text={result.shortDescription}>
                  <p className="text-sm text-white/80">{result.shortDescription}</p>
                </FieldCard>

                {/* Description */}
                <FieldCard label="Description (full)" icon={<FileText className="w-4 h-4 text-cyan-400" />}
                  copyKey="desc" copiedKey={copiedKey} onCopy={() => copy('desc', fullDescriptionWithMeta)} text={fullDescriptionWithMeta}>
                  <pre className="text-sm text-white/80 whitespace-pre-wrap font-sans leading-relaxed">{fullDescriptionWithMeta}</pre>
                </FieldCard>

                {/* Tags */}
                <FieldCard label="Tags" icon={<Tag className="w-4 h-4 text-emerald-400" />}
                  copyKey="tags" copiedKey={copiedKey} onCopy={() => copy('tags', result.tags.join(', '))} text={result.tags.join(', ')}>
                  <div className="flex flex-wrap gap-1.5">
                    {result.tags.map((t, i) => (
                      <span key={i} className="px-2 py-0.5 rounded-md bg-emerald-500/10 border border-emerald-500/20 text-emerald-200 text-xs">{t}</span>
                    ))}
                  </div>
                  <p className="text-[11px] text-white/30 mt-2">{result.tags.length} tags · {result.tags.join(', ').length} chars (YouTube limit 500)</p>
                </FieldCard>

                {/* Hashtags */}
                {result.hashtags?.length > 0 && (
                  <FieldCard label="Hashtags" icon={<Hash className="w-4 h-4 text-fuchsia-400" />}
                    copyKey="hashtags" copiedKey={copiedKey} onCopy={() => copy('hashtags', result.hashtags.join(' '))} text={result.hashtags.join(' ')}>
                    <div className="flex flex-wrap gap-1.5">
                      {result.hashtags.map((h, i) => (
                        <span key={i} className="px-2 py-0.5 rounded-md bg-fuchsia-500/10 border border-fuchsia-500/20 text-fuchsia-200 text-xs">{h}</span>
                      ))}
                    </div>
                  </FieldCard>
                )}

                {/* Chapters */}
                {result.chapters && result.chapters.length > 0 && (
                  <FieldCard label="Chapters" icon={<ListTree className="w-4 h-4 text-sky-400" />}
                    copyKey="chapters" copiedKey={copiedKey}
                    onCopy={() => copy('chapters', result.chapters!.map(c => `${c.time} ${c.label}`).join('\n'))}
                    text={result.chapters!.map(c => `${c.time} ${c.label}`).join('\n')}>
                    <ul className="space-y-1 text-sm">
                      {result.chapters.map((c, i) => (
                        <li key={i} className="flex gap-3 text-white/80">
                          <span className="text-sky-300 font-mono text-xs w-12 flex-shrink-0">{c.time}</span>
                          <span>{c.label}</span>
                        </li>
                      ))}
                    </ul>
                  </FieldCard>
                )}
              </>
            )}
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )
}

function FieldCard({
  label, icon, copyKey, copiedKey, onCopy, children,
}: {
  label: string
  icon: React.ReactNode
  copyKey: string
  copiedKey: string | null
  onCopy: () => void
  text: string
  children: React.ReactNode
}) {
  const copied = copiedKey === copyKey
  return (
    <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-4">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2 text-sm font-semibold text-white/80">{icon} {label}</div>
        <button onClick={onCopy} className={`inline-flex items-center gap-1 text-xs transition ${copied ? 'text-emerald-400' : 'text-white/50 hover:text-white'}`}>
          {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />} {copied ? 'Copied' : 'Copy'}
        </button>
      </div>
      {children}
    </div>
  )
}
