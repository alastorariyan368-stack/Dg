'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Package, Download, TrendingUp, Eye, Star, DollarSign, Upload, ExternalLink, Edit, Loader2, ArrowUpRight, Users, Clock, CheckCircle, XCircle, AlertCircle, Award, Wallet, Gift, Copy, Share2 } from 'lucide-react'
import Link from 'next/link'
import { toast } from 'sonner'

interface Item { id: string; title: string; slug: string; logo?: string; downloads: number; likes: number; views: number; price: number; status: string; createdAt: string; category: { name: string }; _count?: { reviews: number } }
interface Order { id: string; itemId: string; buyerId?: string; sellerId?: string; amount: number; status: string; createdAt: string; item: { title: string; slug: string }; buyer?: { username: string; avatar?: string }; seller?: { username: string } }
interface Stats { totalItems: number; totalDownloads: number; totalRevenue: number; totalViews: number; totalLikes: number; totalReviews: number; avgRating: number; pendingItems: number }
interface Ad {
  id: string
  title: string
  description?: string | null
  imageUrl?: string | null
  linkUrl?: string | null
}

interface CollaborationPreview {
  id: string
  revenueShare: number
  status: string
  createdAt: string
  item: {
    title: string
    slug: string
    logo?: string | null
    author: { username: string }
  }
}

const STATUS_CONFIG: Record<string, { color: string; icon: any; label: string }> = {
  APPROVED: { color: 'text-green-400 bg-green-500/10 border-green-500/20', icon: CheckCircle, label: 'Approved' },
  PENDING: { color: 'text-yellow-400 bg-yellow-500/10 border-yellow-500/20', icon: Clock, label: 'Pending' },
  REJECTED: { color: 'text-red-400 bg-red-500/10 border-red-500/20', icon: XCircle, label: 'Rejected' },
  DRAFT: { color: 'text-gray-400 bg-gray-500/10 border-gray-500/20', icon: AlertCircle, label: 'Draft' },
  DELIVERED: { color: 'text-blue-400 bg-blue-500/10 border-blue-500/20', icon: CheckCircle, label: 'Delivered' },
  IN_PROGRESS: { color: 'text-purple-400 bg-purple-500/10 border-purple-500/20', icon: Clock, label: 'In Progress' },
}

const LEVEL_NAMES = ['', 'Starter', 'Rising', 'Pro', 'Elite', 'Legend']
const LEVEL_COLORS = ['', 'from-gray-500 to-gray-600', 'from-blue-500 to-cyan-500', 'from-purple-500 to-pink-500', 'from-orange-500 to-red-500', 'from-yellow-400 to-orange-500']

function StatCard({ icon: Icon, label, value, sub, color = 'text-purple-400' }: any) {
  return (
    <div className="bg-white/[0.03] border border-white/8 rounded-2xl p-5">
      <div className="flex items-start justify-between mb-3">
        <div className={`w-9 h-9 rounded-xl bg-white/5 flex items-center justify-center`}><Icon className={`w-4 h-4 ${color}`} /></div>
      </div>
      <p className="text-2xl font-bold text-white mb-0.5">{value}</p>
      <p className="text-xs text-white/40">{label}</p>
      {sub && <p className="text-xs text-white/25 mt-0.5">{sub}</p>}
    </div>
  )
}

export default function DashboardPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [items, setItems] = useState<Item[]>([])
  const [orders, setOrders] = useState<Order[]>([])
  const [stats, setStats] = useState<Stats>({ totalItems: 0, totalDownloads: 0, totalRevenue: 0, totalViews: 0, totalLikes: 0, totalReviews: 0, avgRating: 0, pendingItems: 0 })
  const [walletBalance, setWalletBalance] = useState(0)
  const [sellerLevel, setSellerLevel] = useState(1)
  const [dashboardAds, setDashboardAds] = useState<Ad[]>([])
  const [collaborationsPreview, setCollaborationsPreview] = useState<CollaborationPreview[]>([])
  const [collaborationCount, setCollaborationCount] = useState(0)
  const [loading, setLoading] = useState(true)
  const [referralCode, setReferralCode] = useState('')
  const [referralEarnings, setReferralEarnings] = useState(0)
  const [referralCount, setReferralCount] = useState(0)
  const [referralLoading, setReferralLoading] = useState(false)
  const [showShareLink, setShowShareLink] = useState(false)

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin')
    if (status === 'authenticated') { loadAll(); loadReferralData() }
  }, [status])

  const loadReferralData = async () => {
    try {
      const res = await fetch('/api/referrals')
      if (res.ok) {
        const data = await res.json()
        setReferralCode(data.referralCode || '')
        setReferralEarnings(data.referralEarnings || 0)
        setReferralCount(data.referralCount || 0)
      }
    } catch {}
  }

  const generateReferralCode = async () => {
    setReferralLoading(true)
    try {
      const res = await fetch('/api/referrals', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'generate' })
      })
      if (res.ok) {
        const data = await res.json()
        setReferralCode(data.referralCode)
        toast.success('Referral code generated!')
      }
    } catch { toast.error('Failed to generate') } finally { setReferralLoading(false) }
  }

  const copyReferralCode = () => {
    navigator.clipboard.writeText(referralCode)
    toast.success('Copied to clipboard!')
  }

  const loadAll = async () => {
    setLoading(true)
    try {
      const [itemsRes, ordersRes, userRes, adsRes, collabsRes] = await Promise.all([
        fetch('/api/items?authorId=me&limit=50').then(r => r.ok ? r.json() : { items: [] }),
        fetch('/api/orders?type=seller&limit=20').then(r => r.ok ? r.json() : { orders: [] }),
        fetch('/api/users/me').then(r => r.ok ? r.json() : {}),
        fetch('/api/ads?position=dashboard&limit=3').then(r => r.ok ? r.json() : { ads: [] }),
        fetch('/api/collaborations').then(r => r.ok ? r.json() : { collaborations: [] }),
      ])

      const myItems: Item[] = itemsRes.items || []
      setItems(myItems)
      setWalletBalance((userRes as any)?.walletBalance || 0)
      setSellerLevel((userRes as any)?.sellerLevel || 1)
      setDashboardAds(Array.isArray(adsRes?.ads) ? adsRes.ads : [])
      const collabs: CollaborationPreview[] = Array.isArray(collabsRes?.collaborations) ? collabsRes.collaborations : []
      setCollaborationCount(collabs.length)
      setCollaborationsPreview(collabs.slice(0, 4))

      const approved = myItems.filter(i => i.status === 'APPROVED')
      setStats({
        totalItems: myItems.length,
        pendingItems: myItems.filter(i => i.status === 'PENDING').length,
        totalDownloads: approved.reduce((s, i) => s + (i.downloads || 0), 0),
        totalRevenue: (userRes as any)?.totalSales || 0,
        totalViews: approved.reduce((s, i) => s + (i.views || 0), 0),
        totalLikes: approved.reduce((s, i) => s + (i.likes || 0), 0),
        totalReviews: approved.reduce((s, i) => s + (i._count?.reviews || 0), 0),
        avgRating: 0
      })

      const ordersData = ordersRes.orders || []
      setOrders(ordersData)
    } catch { toast.error('Failed to load dashboard') } finally { setLoading(false) }
  }

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    try {
      const res = await fetch(`/api/orders/${orderId}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status: newStatus }) })
      if (res.ok) { toast.success('Order updated!'); loadAll() }
      else { const d = await res.json(); toast.error(d.error || 'Failed') }
    } catch { toast.error('Failed') }
  }

  if (loading) return (
    <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
      <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
    </div>
  )

  const level = sellerLevel || 1
  const isCreator = ['CREATOR', 'ADMIN', 'SUPER_ADMIN', 'MODERATOR'].includes(session?.user?.role || '')

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Header */}
        <div className="flex items-start justify-between mb-8 flex-wrap gap-4">
          <div>
            <h1 className="text-2xl font-bold text-white">Dashboard</h1>
            <p className="text-white/40 text-sm mt-1">Welcome back, {session?.user?.username || 'Creator'}</p>
          </div>
          <div className="flex items-center gap-3 flex-wrap">
            {/* Seller Level */}
            <div className={`flex items-center gap-2 px-3 py-1.5 rounded-xl border bg-gradient-to-r ${LEVEL_COLORS[level]} bg-opacity-10 border-white/10`}>
              <Award className="w-4 h-4 text-white/70" />
              <span className="text-xs font-medium text-white/80">Level {level} · {LEVEL_NAMES[level]}</span>
            </div>
            {/* Wallet */}
            <Link href="/wallet">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl border border-white/10 bg-white/5 hover:bg-white/10 transition-colors cursor-pointer">
                <Wallet className="w-4 h-4 text-green-400" />
                <span className="text-sm font-bold text-green-400">${walletBalance.toFixed(2)}</span>
              </div>
            </Link>
            {isCreator && (
              <Link href="/upload">
                <Button size="sm" className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs">
                  <Upload className="h-3.5 w-3.5" />Upload Item
                </Button>
              </Link>
            )}
          </div>
        </div>

        {dashboardAds.length > 0 && (
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <DollarSign className="h-4 w-4 text-yellow-400" />
                <span className="text-sm font-medium text-yellow-400 uppercase tracking-wider">Sponsored</span>
              </div>
            </div>
            <div className="grid md:grid-cols-3 gap-4">
              {dashboardAds.map(ad => (
                <div key={ad.id} className="bg-white/[0.03] hover:bg-white/[0.06] border border-white/8 rounded-2xl overflow-hidden">
                  {ad.imageUrl ? (
                    <a href={ad.linkUrl || '#'} target={ad.linkUrl?.startsWith('http') ? '_blank' : undefined} rel="noreferrer" className="block">
                      <img src={ad.imageUrl} alt={ad.title} className="w-full h-32 object-cover" />
                    </a>
                  ) : (
                    <div className="w-full h-32 bg-white/[0.02] flex items-center justify-center text-white/40">No Image</div>
                  )}
                  <div className="p-3">
                    {ad.linkUrl ? (
                      <a href={ad.linkUrl} target={ad.linkUrl.startsWith('http') ? '_blank' : undefined} rel="noreferrer" className="block">
                        <h3 className="text-sm font-semibold text-white/90 truncate">{ad.title}</h3>
                      </a>
                    ) : (
                      <h3 className="text-sm font-semibold text-white/90 truncate">{ad.title}</h3>
                    )}
                    {ad.description && <p className="text-xs text-white/40 mt-1 line-clamp-2">{ad.description}</p>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {collaborationCount > 0 && (
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-purple-400" />
                <span className="text-sm font-medium text-purple-400 uppercase tracking-wider">Collaborations</span>
              </div>
              <Link href="/collaborations">
                <Button variant="ghost" size="sm" className="text-white/60 hover:bg-white/5 rounded-xl">
                  View all
                </Button>
              </Link>
            </div>
            <div className="grid md:grid-cols-2 gap-4">
              {collaborationsPreview.map((c) => (
                <div key={c.id} className="bg-white/[0.03] hover:bg-white/[0.06] border border-white/8 rounded-2xl p-4">
                  <Link href={`/items/${c.item.slug}`}>
                    <p className="text-sm font-semibold text-white/90 truncate hover:text-purple-300 transition-colors">
                      {c.item.title}
                    </p>
                  </Link>
                  <p className="text-xs text-white/40 mt-1">
                    by {c.item.author.username}
                  </p>
                  <div className="flex items-center gap-2 flex-wrap mt-3">
                    <Badge className="bg-purple-500/10 text-purple-300 border-purple-500/20 text-[10px] h-6 flex items-center">
                      Revenue: {c.revenueShare}%
                    </Badge>
                    <Badge
                      className={`text-[10px] h-6 ${
                        c.status === 'APPROVED'
                          ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                          : c.status === 'PENDING'
                            ? 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20'
                            : 'bg-white/5 text-white/40 border-white/10'
                      }`}
                    >
                      {c.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <StatCard icon={Package} label="Total Items" value={stats.totalItems} sub={`${stats.pendingItems} pending`} color="text-purple-400" />
          <StatCard icon={Download} label="Downloads" value={stats.totalDownloads >= 1000 ? (stats.totalDownloads / 1000).toFixed(1) + 'K' : stats.totalDownloads} color="text-blue-400" />
          <StatCard icon={Eye} label="Views" value={stats.totalViews >= 1000 ? (stats.totalViews / 1000).toFixed(1) + 'K' : stats.totalViews} color="text-cyan-400" />
          <StatCard icon={DollarSign} label="Balance" value={`$${walletBalance.toFixed(2)}`} color="text-green-400" />
        </div>

        {/* Referral Program */}
        <div className="bg-gradient-to-r from-purple-900/20 via-blue-900/10 to-purple-900/20 border border-purple-500/10 rounded-2xl p-5 mb-8">
          <div className="flex items-start justify-between flex-wrap gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center">
                <Gift className="w-5 h-5 text-purple-400" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Referral Program</h3>
                <p className="text-[11px] text-white/40">Earn $5 for every friend you invite. They get $2 bonus!</p>
              </div>
            </div>
            <div className="flex items-center gap-4 text-center">
              <div>
                <p className="text-lg font-bold text-purple-400">{referralCount}</p>
                <p className="text-[10px] text-white/30">Referrals</p>
              </div>
              <div>
                <p className="text-lg font-bold text-green-400">${referralEarnings.toFixed(2)}</p>
                <p className="text-[10px] text-white/30">Earned</p>
              </div>
            </div>
          </div>
          <div className="mt-4">
            {referralCode ? (
              <div className="space-y-2">
                <div className="flex items-center gap-2 flex-wrap">
                  <div className="flex-1 min-w-0 bg-white/5 border border-white/10 rounded-xl px-4 py-2.5 flex items-center gap-2">
                    <span className="text-sm font-mono text-purple-300 truncate">{referralCode}</span>
                  </div>
                  <Button onClick={copyReferralCode} size="sm" className="bg-white/10 hover:bg-white/15 text-white/70 border-0 rounded-xl gap-1.5 text-xs h-10">
                    <Copy className="h-3.5 w-3.5" /> Copy Code
                  </Button>
                  <Button onClick={() => {
                    setShowShareLink(!showShareLink)
                    const url = `${window.location.origin}/auth/signup?ref=${referralCode}`
                    navigator.clipboard.writeText(url)
                    toast.success('Referral link copied!')
                  }} size="sm" className="bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border-0 rounded-xl gap-1.5 text-xs h-10">
                    <Share2 className="h-3.5 w-3.5" /> Share Link
                  </Button>
                </div>
                {showShareLink && (
                  <div className="bg-purple-500/10 border border-purple-500/20 rounded-xl px-4 py-3">
                    <p className="text-[10px] text-white/40 mb-1">Your referral link (copied!):</p>
                    <p className="text-xs font-mono text-purple-300 break-all select-text">{`${typeof window !== 'undefined' ? window.location.origin : ''}/auth/signup?ref=${referralCode}`}</p>
                  </div>
                )}
              </div>
            ) : (
              <Button onClick={generateReferralCode} disabled={referralLoading} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-2 text-xs">
                {referralLoading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Gift className="h-3.5 w-3.5" />}
                Generate Referral Code
              </Button>
            )}
          </div>
        </div>

        {/* Main content tabs */}
        <Tabs defaultValue="items">
          <TabsList className="bg-white/5 border border-white/10 rounded-xl p-1 gap-1 h-auto mb-6">
            {[['items', 'My Items'], ['orders', `Orders (${orders.length})`]].map(([v, l]) => (
              <TabsTrigger key={v} value={v} className="rounded-lg text-white/50 data-[state=active]:bg-white/10 data-[state=active]:text-white text-xs px-4 py-2">{l}</TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value="items">
            {items.length === 0 ? (
              <div className="text-center py-20 bg-white/[0.02] border border-white/5 rounded-2xl">
                <Package className="w-14 h-14 mx-auto text-white/10 mb-4" />
                <h3 className="text-white font-semibold mb-2">No items yet</h3>
                <p className="text-white/40 text-sm mb-5">Upload your first digital content to start earning</p>
                {isCreator ? (
                  <Link href="/upload"><Button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl">Upload Now</Button></Link>
                ) : (
                  <Link href="/seller/apply"><Button className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl">Become a Seller</Button></Link>
                )}
              </div>
            ) : (
              <div className="space-y-2">
                {items.map(item => {
                  const sc = STATUS_CONFIG[item.status] || STATUS_CONFIG['DRAFT']
                  const StatusIcon = sc.icon
                  return (
                    <div key={item.id} className="bg-white/[0.03] hover:bg-white/[0.06] border border-white/[0.06] rounded-xl p-3 sm:p-4 transition-all group">
                      <div className="flex items-start gap-3">
                        <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-xl bg-gradient-to-br from-purple-900/30 to-blue-900/20 border border-white/10 flex-shrink-0 overflow-hidden">
                          {item.logo ? <img src={item.logo} alt={item.title} className="w-full h-full object-cover" /> : <Package className="w-5 h-5 text-white/20 m-auto mt-3" />}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <h3 className="text-sm font-medium text-white/90 truncate">{item.title}</h3>
                            <Badge className={`text-[9px] h-4 border ${sc.color}`}><StatusIcon className="w-2.5 h-2.5 mr-0.5" />{sc.label}</Badge>
                          </div>
                          <div className="flex items-center gap-3 mt-1 text-[11px] text-white/30 flex-wrap">
                            <span className="flex items-center gap-1"><Download className="h-3 w-3" />{item.downloads || 0}</span>
                            <span className="flex items-center gap-1"><Eye className="h-3 w-3" />{item.views || 0}</span>
                            <span className={`font-bold ${item.price === 0 ? 'text-green-400' : 'text-white/50'}`}>{item.price === 0 ? 'Free' : `$${item.price.toFixed(2)}`}</span>
                          </div>
                        </div>
                        <div className="flex items-center gap-1 flex-shrink-0">
                          <Link href={`/items/${item.slug}`}>
                            <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-white/30 hover:text-white rounded-lg"><ExternalLink className="h-3.5 w-3.5" /></Button>
                          </Link>
                          <Link href={`/upload?edit=${item.id}`}>
                            <Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-white/30 hover:text-purple-400 rounded-lg"><Edit className="h-3.5 w-3.5" /></Button>
                          </Link>
                        </div>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </TabsContent>

          <TabsContent value="orders">
            {orders.length === 0 ? (
              <div className="text-center py-20 bg-white/[0.02] border border-white/5 rounded-2xl">
                <TrendingUp className="w-14 h-14 mx-auto text-white/10 mb-4" />
                <h3 className="text-white font-semibold mb-2">No orders yet</h3>
                <p className="text-white/40 text-sm">Orders from buyers will appear here</p>
              </div>
            ) : (
              <div className="space-y-2">
                {orders.map(order => {
                  const sc = STATUS_CONFIG[order.status] || STATUS_CONFIG['PENDING']
                  const StatusIcon = sc.icon
                  return (
                    <div key={order.id} className="bg-white/[0.03] border border-white/[0.06] rounded-xl p-3 sm:p-4">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 flex-wrap">
                            <h3 className="text-sm font-medium text-white/90 truncate">{order.item.title}</h3>
                            <Badge className={`text-[9px] h-4 border ${sc.color}`}><StatusIcon className="w-2.5 h-2.5 mr-0.5" />{sc.label}</Badge>
                          </div>
                          <div className="flex items-center gap-3 mt-1 text-[11px] text-white/30">
                            {order.buyer && <span>by {order.buyer.username}</span>}
                            <span>{new Date(order.createdAt).toLocaleDateString()}</span>
                          </div>
                        </div>
                        <span className="text-sm font-bold text-green-400 flex-shrink-0">+${order.amount.toFixed(2)}</span>
                      </div>
                      {(order.status === 'PENDING' || order.status === 'IN_PROGRESS') && (
                        <div className="flex items-center gap-2 mt-2.5 pt-2.5 border-t border-white/[0.04]">
                          {order.status === 'PENDING' && <>
                            <Button onClick={() => updateOrderStatus(order.id, 'IN_PROGRESS')} size="sm" className="h-7 text-[10px] bg-blue-500/20 hover:bg-blue-500/30 text-blue-400 border-0 rounded-lg px-3 flex-1 sm:flex-none">Accept</Button>
                            <Button onClick={() => updateOrderStatus(order.id, 'DELIVERED')} size="sm" className="h-7 text-[10px] bg-green-500/20 hover:bg-green-500/30 text-green-400 border-0 rounded-lg px-3 flex-1 sm:flex-none">Deliver</Button>
                          </>}
                          {order.status === 'IN_PROGRESS' && (
                            <Button onClick={() => updateOrderStatus(order.id, 'DELIVERED')} size="sm" className="h-7 text-[10px] bg-green-500/20 hover:bg-green-500/30 text-green-400 border-0 rounded-lg px-3">Mark Delivered</Button>
                          )}
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
      <Footer />
    </div>
  )
}
