import { MetadataRoute } from 'next'
import { db } from '@/lib/db'

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const baseUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'

  let items: Array<{ slug: string; updatedAt: Date }> = []
  let categories: Array<{ slug: string }> = []
  try {
    // Keep sitemap generation resilient even when DB is temporarily unavailable.
    ;[items, categories] = await Promise.all([
      db.item.findMany({
        where: { status: 'APPROVED' },
        select: {
          slug: true,
          updatedAt: true,
        },
      }),
      db.category.findMany({
        where: { isActive: true },
        select: {
          slug: true,
        },
      }),
    ])
  } catch {
    items = []
    categories = []
  }

  const itemEntries = items.map((item) => ({
    url: `${baseUrl}/items/${item.slug}`,
    lastModified: item.updatedAt,
    changeFrequency: 'weekly' as const,
    priority: 0.8,
  }))

  const categoryEntries = categories.map((category) => ({
    url: `${baseUrl}/browse?category=${category.slug}`,
    lastModified: new Date(),
    changeFrequency: 'monthly' as const,
    priority: 0.6,
  }))

  // Static pages
  const staticPages = [
    {
      url: baseUrl,
      lastModified: new Date(),
      changeFrequency: 'daily' as const,
      priority: 1.0,
    },
    {
      url: `${baseUrl}/browse`,
      lastModified: new Date(),
      changeFrequency: 'daily' as const,
      priority: 0.9,
    },
    {
      url: `${baseUrl}/categories`,
      lastModified: new Date(),
      changeFrequency: 'weekly' as const,
      priority: 0.7,
    },
    {
      url: `${baseUrl}/creators`,
      lastModified: new Date(),
      changeFrequency: 'weekly' as const,
      priority: 0.7,
    },
    {
      url: `${baseUrl}/auth/signin`,
      lastModified: new Date(),
      changeFrequency: 'monthly' as const,
      priority: 0.5,
    },
    {
      url: `${baseUrl}/auth/signup`,
      lastModified: new Date(),
      changeFrequency: 'monthly' as const,
      priority: 0.5,
    },
  ]

  return [...staticPages, ...categoryEntries, ...itemEntries]
}