'use client'

import { useState, useRef, useEffect } from 'react'
import { Navbar } from '@/components/navbar'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Send, Bot, User, Loader2, Sparkles, RotateCcw, Copy, Check } from 'lucide-react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'

interface Message {
  role: 'user' | 'assistant'
  content: string
  timestamp: Date
}

const SUGGESTED = [
  'How do I upload a video?',
  'What are the membership benefits?',
  'How to get badges?',
  'Best plugins for survival servers?',
  'How to install a texture pack?',
]

export default function AIChatPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null)
  const bottomRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin')
  }, [status, router])

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight
    }
  }, [messages, isLoading])

  const sendMessage = async (content: string) => {
    if (!content.trim() || isLoading) return
    const userMsg: Message = { role: 'user', content: content.trim(), timestamp: new Date() }
    setMessages(prev => [...prev, userMsg])
    setInput('')
    setIsLoading(true)
    try {
      const history = [...messages, userMsg].slice(-20).map(m => ({ role: m.role, content: m.content }))
      const res = await fetch('/api/ai-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: history }),
      })
      const data = await res.json()
      if (res.ok) {
        setMessages(prev => [...prev, { role: 'assistant', content: data.reply, timestamp: new Date() }])
      } else {
        toast.error(data.error || 'Failed to get response')
        setMessages(prev => [...prev, { role: 'assistant', content: `⚠️ ${data.error || 'Something went wrong.'}`, timestamp: new Date() }])
      }
    } catch {
      toast.error('Connection error. Please try again.')
    } finally {
      setIsLoading(false)
      setTimeout(() => inputRef.current?.focus(), 100)
    }
  }

  const copyMessage = async (content: string, i: number) => {
    await navigator.clipboard.writeText(content)
    setCopiedIdx(i)
    setTimeout(() => setCopiedIdx(null), 2000)
  }

  if (status === 'loading') {
    return (
      <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-purple-400 animate-spin" />
      </div>
    )
  }

  return (
    <div className="bg-[#0a0a0f] text-white flex flex-col overflow-hidden fixed inset-0" style={{ height: '100dvh' }}>
      <Navbar />

      <div className="flex-1 min-h-0 flex flex-col container mx-auto px-3 sm:px-4 pt-2 sm:pt-4 pb-2 sm:pb-4 max-w-3xl w-full">
        {/* Header */}
        <div className="flex items-center justify-between mb-3 flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-gradient-to-br from-purple-600 to-blue-600 rounded-xl shadow-lg shadow-purple-500/30">
              <Bot className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-white flex items-center gap-2">
                GfxStore AI
                <Badge className="bg-purple-500/20 text-purple-300 border-purple-500/30 text-xs">Beta</Badge>
              </h1>
              <p className="text-white/40 text-xs">GFX AI Beta — your marketplace assistant</p>
            </div>
          </div>
          {messages.length > 0 && (
            <Button
              variant="ghost" size="sm"
              onClick={() => setMessages([])}
              className="text-white/40 hover:text-white hover:bg-white/10 gap-1.5 text-xs"
            >
              <RotateCcw className="w-3 h-3" /> Clear
            </Button>
          )}
        </div>

        {/* Chat container — flex-1 min-h-0 ensures it fills space without overflow */}
        <div className="flex-1 min-h-0 bg-white/[0.02] border border-white/10 rounded-2xl overflow-hidden flex flex-col">

          {/* Scrollable messages area */}
          <div
            ref={scrollRef}
            className="flex-1 min-h-0 overflow-y-auto p-4 scroll-smooth"
          >
            {messages.length === 0 ? (
              <div className="flex flex-col items-center justify-center h-full py-10 text-center">
                <div className="p-4 bg-purple-600/10 rounded-2xl mb-4 border border-purple-500/20">
                  <Sparkles className="w-8 h-8 text-purple-400" />
                </div>
                <h3 className="text-base font-semibold text-white mb-1">How can I help?</h3>
                <p className="text-white/40 text-sm max-w-sm mb-5">Ask me anything about GfxStore, digital content, uploads, memberships, or anything else!</p>
                <div className="flex flex-wrap gap-2 justify-center">
                  {SUGGESTED.map((q, i) => (
                    <button
                      key={i}
                      onClick={() => sendMessage(q)}
                      className="px-3 py-1.5 text-xs bg-white/5 hover:bg-purple-500/20 border border-white/10 hover:border-purple-500/30 text-white/60 hover:text-white rounded-full transition-all"
                    >
                      {q}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {messages.map((msg, i) => (
                  <div key={i} className={`flex gap-2.5 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                    <div className={`flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center ${
                      msg.role === 'user' ? 'bg-purple-600' : 'bg-gradient-to-br from-purple-600 to-blue-600'
                    }`}>
                      {msg.role === 'user' ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5" />}
                    </div>
                    <div className={`group max-w-[78%] flex flex-col gap-1 ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                      <div className={`px-3.5 py-2.5 rounded-2xl text-sm leading-relaxed whitespace-pre-wrap break-words ${
                        msg.role === 'user'
                          ? 'bg-purple-600 text-white rounded-tr-sm'
                          : 'bg-white/[0.06] border border-white/10 text-white/90 rounded-tl-sm'
                      }`}>
                        {msg.content}
                      </div>
                      <div className={`flex items-center gap-1.5 opacity-0 group-hover:opacity-100 transition-opacity ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                        <span className="text-[10px] text-white/20">
                          {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                        {msg.role === 'assistant' && (
                          <button onClick={() => copyMessage(msg.content, i)} className="p-0.5 text-white/30 hover:text-white/70 transition-colors">
                            {copiedIdx === i ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
                {isLoading && (
                  <div className="flex gap-2.5">
                    <div className="w-7 h-7 rounded-full bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center flex-shrink-0">
                      <Bot className="w-3.5 h-3.5" />
                    </div>
                    <div className="px-3.5 py-2.5 bg-white/[0.06] border border-white/10 rounded-2xl rounded-tl-sm flex items-center gap-2">
                      <span className="flex gap-1">
                        <span className="w-1.5 h-1.5 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                        <span className="w-1.5 h-1.5 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                        <span className="w-1.5 h-1.5 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                      </span>
                    </div>
                  </div>
                )}
                <div ref={bottomRef} />
              </div>
            )}
          </div>

          {/* Input — always stays at the bottom */}
          <div className="flex-shrink-0 p-3 border-t border-white/10 bg-white/[0.02]">
            <form
              onSubmit={e => { e.preventDefault(); sendMessage(input) }}
              className="flex gap-2"
            >
              <input
                ref={inputRef}
                value={input}
                onChange={e => setInput(e.target.value)}
                placeholder="Ask me anything…"
                disabled={isLoading}
                maxLength={1000}
                className="flex-1 h-10 px-4 bg-white/5 border border-white/10 text-white placeholder:text-white/30 rounded-xl text-sm outline-none focus:border-purple-500/60 transition disabled:opacity-50"
              />
              <button
                type="submit"
                disabled={!input.trim() || isLoading}
                className="h-10 w-10 flex-shrink-0 flex items-center justify-center bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 disabled:opacity-40 rounded-xl shadow-lg shadow-purple-500/20 transition"
              >
                <Send className="w-4 h-4 text-white" />
              </button>
            </form>
            <p className="text-[10px] text-white/20 mt-1.5 text-center">AI can make mistakes. Verify important information.</p>
          </div>
        </div>
      </div>
    </div>
  )
}
