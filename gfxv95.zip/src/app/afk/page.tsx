'use client'

import { useEffect, useState, useRef } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useSession } from 'next-auth/react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Clock, Coins, ShieldCheck, Zap, History, TrendingUp, AlertCircle, Loader2 } from 'lucide-react'
import { toast } from 'sonner'

export default function AfkPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  
  const [sessionTime, setSessionTime] = useState(0)
  const [earnedThisSession, setEarnedThisSession] = useState(0)
  const [totalEarnedToday, setTotalEarnedToday] = useState(0)
  const [isGracePeriod, setIsGracePeriod] = useState(true)
  const [graceLeft, setGraceLeft] = useState(0)
  const [isMaxReached, setIsMaxReached] = useState(false)
  const [maxPerDay, setMaxPerDay] = useState(10)
  const [history, setHistory] = useState<any[]>([])
  const [loadingHistory, setLoadingHistory] = useState(true)
  const [mounted, setMounted] = useState(false)

  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null)

  useEffect(() => {
    setMounted(true)
    if (status === 'unauthenticated') {
      router.push('/auth/signin?callbackUrl=/afk')
    }
  }, [router, status])

  // Heartbeat function
  const sendHeartbeat = async () => {
    if (status !== 'authenticated') return
    try {
      const res = await fetch('/api/afk/heartbeat', { method: 'POST' })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const data = await res.json()
      
      if (data.enabled) {
        setTotalEarnedToday(data.total || 0)
        setIsMaxReached(!!data.maxReached)
        if (data.maxPerDay) setMaxPerDay(data.maxPerDay)
        
        if (data.earned > 0) {
          setEarnedThisSession(p => p + data.earned)
          toast.success(`+৳${data.earned.toFixed(3)} AFK earning added!`, {
            icon: '💰',
            duration: 3000
          })
        }

        if (data.inGrace) {
          setIsGracePeriod(true)
          setGraceLeft(data.graceLeft || 0)
        } else {
          setIsGracePeriod(false)
        }
      }
    } catch (err) {
      console.error('Heartbeat failed:', err)
    }
  }

  // Fetch history
  const fetchHistory = async () => {
    try {
      const res = await fetch('/api/users/me')
      if (res.ok) {
        const data = await res.json()
        // Filter transactions for AFK earnings
        const res2 = await fetch('/api/transactions?method=afk_earning&limit=10')
        if (res2.ok) {
          const tData = await res2.json()
          setHistory(tData.transactions || [])
        }
      }
    } catch (err) {
      console.error('Failed to fetch history:', err)
    } finally {
      setLoadingHistory(false)
    }
  }

  useEffect(() => {
    if (status === 'authenticated') {
      sendHeartbeat() // Initial beat
      fetchHistory()
      
      // Heartbeat every 60s
      const beatInterval = setInterval(sendHeartbeat, 60000)
      
      // Local timer for UI only (every 1s)
      const uiTimer = setInterval(() => {
        setSessionTime(p => p + 1)
      }, 1000)

      return () => {
        clearInterval(beatInterval)
        clearInterval(uiTimer)
      }
    }
  }, [status])

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}m ${secs}s`
  }

  if (!mounted || status === 'loading' || status === 'unauthenticated') {
    return (
      <div className="min-h-screen bg-[#07070d] text-white">
        <Navbar />
        <div className="container mx-auto px-4 py-16 flex justify-center">
          <div className="w-10 h-10 border-2 border-violet-500 border-t-transparent rounded-full animate-spin" />
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#07070d] text-white flex flex-col overflow-x-hidden">
      <Navbar />
      <main className="flex-1 container mx-auto px-4 py-10 max-w-4xl relative z-10">
        <div className="mb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <h1 className="text-4xl font-black tracking-tight text-white flex items-center gap-3">
              AFK Earning <Zap className="w-8 h-8 text-amber-400 fill-amber-400/20" />
            </h1>
            <p className="text-white/50 mt-2 text-lg">
              Earn rewards automatically by keeping this page open.
            </p>
          </div>
          <div className="flex gap-2">
             <Link href="/wallet">
              <Button variant="outline" className="border-white/10 hover:bg-white/5 text-white gap-2">
                <Coins className="w-4 h-4 text-emerald-400" /> Wallet
              </Button>
            </Link>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-8">
          {/* Status Card */}
          <Card className="md:col-span-2 bg-gradient-to-br from-violet-600/10 via-transparent to-cyan-600/10 border-white/10 p-8 relative overflow-hidden group">
            <div className="absolute top-0 right-0 p-8 opacity-5 group-hover:opacity-10 transition-opacity">
              <TrendingUp className="w-32 h-32 text-white" />
            </div>
            
            <div className="relative z-10 flex flex-col h-full">
              <div className="flex items-center gap-2 mb-6">
                <div className={`w-3 h-3 rounded-full ${isMaxReached ? 'bg-red-500' : 'bg-emerald-500 animate-pulse'}`} />
                <span className="text-sm font-bold uppercase tracking-wider text-white/60">
                  {isMaxReached ? 'Daily Limit Reached' : 'System Active & Tracking'}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-8 mb-8">
                <div>
                  <p className="text-white/40 text-sm font-medium mb-1">Session Duration</p>
                  <p className="text-3xl font-mono font-bold text-white">{formatTime(sessionTime)}</p>
                </div>
                <div>
                  <p className="text-white/40 text-sm font-medium mb-1">Earned This Session</p>
                  <p className="text-3xl font-mono font-bold text-emerald-400">৳{earnedThisSession.toFixed(3)}</p>
                </div>
              </div>

              {isGracePeriod && !isMaxReached && (
                <div className="mt-auto p-4 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center gap-3">
                  <AlertCircle className="w-5 h-5 text-amber-400 flex-shrink-0" />
                  <p className="text-sm text-amber-200/80">
                    <span className="font-bold">Grace Period Active:</span> You will start earning in approximately <span className="text-white font-mono">{graceLeft} minutes</span>.
                  </p>
                </div>
              )}

              {isMaxReached && (
                <div className="mt-auto p-4 rounded-2xl bg-red-500/10 border border-red-500/20 flex items-center gap-3">
                  <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0" />
                  <p className="text-sm text-red-200/80">
                    You have reached the maximum AFK earnings for today. Come back tomorrow!
                  </p>
                </div>
              )}

              {!isGracePeriod && !isMaxReached && (
                <div className="mt-auto p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center gap-3">
                  <Zap className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                  <p className="text-sm text-emerald-200/80">
                    You are currently earning coins! Every minute adds rewards to your wallet.
                  </p>
                </div>
              )}
            </div>
          </Card>

          {/* Daily Stats */}
          <Card className="bg-white/[0.03] border-white/10 p-6 flex flex-col">
            <h3 className="text-lg font-bold mb-6 flex items-center gap-2">
              <History className="w-5 h-5 text-violet-400" /> Daily Stats
            </h3>
            
            <div className="space-y-6 flex-1">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-white/40">Daily Progress</span>
                  <span className="text-white font-bold">{((totalEarnedToday / maxPerDay) * 100).toFixed(0)}%</span>
                </div>
                <div className="h-2 w-full bg-white/5 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-violet-500 to-cyan-500 transition-all duration-1000"
                    style={{ width: `${Math.min(100, (totalEarnedToday / maxPerDay) * 100)}%` }}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 gap-4">
                <div className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.05]">
                  <p className="text-white/30 text-xs font-bold uppercase tracking-widest mb-1">Today's Total</p>
                  <p className="text-2xl font-black text-white">৳{totalEarnedToday.toFixed(2)}</p>
                </div>
                <div className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.05]">
                  <p className="text-white/30 text-xs font-bold uppercase tracking-widest mb-1">Daily Cap</p>
                  <p className="text-2xl font-black text-white/50">৳{maxPerDay.toFixed(2)}</p>
                </div>
              </div>
            </div>
          </Card>
        </div>

        {/* History Table */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <History className="w-5 h-5 text-violet-400" /> Recent Earnings
            </h2>
            <Button variant="ghost" size="sm" onClick={fetchHistory} className="text-white/40 hover:text-white">
              <RefreshCw className="w-4 h-4" />
            </Button>
          </div>

          <Card className="bg-white/[0.02] border-white/10 overflow-hidden">
            {loadingHistory ? (
              <div className="py-12 flex justify-center"><Loader2 className="w-6 h-6 animate-spin text-white/20" /></div>
            ) : history.length === 0 ? (
              <div className="py-12 text-center text-white/30">No recent AFK earnings found.</div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-left">
                  <thead>
                      <tr className="border-b border-white/5 bg-white/[0.02]">
                        <th className="px-6 py-4 text-xs font-bold text-white/40 uppercase tracking-widest">Date & Time</th>
                        <th className="px-6 py-4 text-xs font-bold text-white/40 uppercase tracking-widest text-center">Duration</th>
                        <th className="px-6 py-4 text-xs font-bold text-white/40 uppercase tracking-widest text-center">Amount</th>
                        <th className="px-6 py-4 text-xs font-bold text-white/40 uppercase tracking-widest text-right">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {history.map((t) => (
                        <tr key={t.id} className="hover:bg-white/[0.02] transition-colors">
                          <td className="px-6 py-4">
                            <p className="text-sm text-white font-medium">
                              {mounted ? new Date(t.createdAt).toLocaleDateString() : '...'}
                            </p>
                            <p className="text-xs text-white/30">
                              {mounted ? new Date(t.createdAt).toLocaleTimeString() : '...'}
                            </p>
                          </td>
                          <td className="px-6 py-4 text-center">
                            <span className="text-sm text-white/60 font-mono">
                              {t.reference?.split('—')[1] || '1.0 min'}
                            </span>
                          </td>
                          <td className="px-6 py-4 text-center">
                            <span className="text-sm font-bold text-emerald-400">+৳{t.amount.toFixed(3)}</span>
                          </td>
                          <td className="px-6 py-4 text-right">
                            <span className="px-2 py-1 rounded-md bg-emerald-500/10 text-emerald-400 text-[10px] font-bold border border-emerald-500/20">
                              CREDITED
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                </table>
              </div>
            )}
          </Card>
        </div>

        {/* How it works */}
        <div className="mt-12 grid md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl border border-white/5 bg-white/[0.01]">
            <div className="w-10 h-10 rounded-xl bg-violet-500/10 flex items-center justify-center mb-4">
              <Clock className="w-5 h-5 text-violet-400" />
            </div>
            <h4 className="font-bold text-white mb-2">Stay Active</h4>
            <p className="text-sm text-white/40 leading-relaxed">
              Keep this tab open in your browser. Our system checks your activity every minute.
            </p>
          </div>
          <div className="p-6 rounded-2xl border border-white/5 bg-white/[0.01]">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center mb-4">
              <Zap className="w-5 h-5 text-emerald-400" />
            </div>
            <h4 className="font-bold text-white mb-2">Auto Credit</h4>
            <p className="text-sm text-white/40 leading-relaxed">
              Earnings are added directly to your wallet balance every minute after the grace period.
            </p>
          </div>
          <div className="p-6 rounded-2xl border border-white/5 bg-white/[0.01]">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 flex items-center justify-center mb-4">
              <ShieldCheck className="w-5 h-5 text-cyan-400" />
            </div>
            <h4 className="font-bold text-white mb-2">Anti-Abuse</h4>
            <p className="text-sm text-white/40 leading-relaxed">
              Daily limits and system checks are in place to ensure fair usage for everyone.
            </p>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}

function RefreshCw({ className }: { className?: string }) {
  return (
    <svg 
      className={className} 
      xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"
    >
      <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
      <path d="M21 3v5h-5" />
      <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" />
      <path d="M3 21v-5h5" />
    </svg>
  )
}
