import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { getCache, setCache, CACHE_KEYS } from '@/lib/cache'
import { generateGfxResponse } from '@/lib/gfx-ai-engine'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 60

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const body = await req.json()
    const {
      prompt,
      mode = 'chat',
      messages = [],
      style = 'general',
      modelName = 'GFXV1',
      sessionId,
    } = body

    if (!prompt?.trim()) return NextResponse.json({ error: 'Prompt is required' }, { status: 400 })

    // Cached settings
    let settings = getCache(CACHE_KEYS.SETTINGS) as any
    if (!settings) {
      settings = await db.siteSettings.findFirst()
      if (settings) setCache(CACHE_KEYS.SETTINGS, settings, 300)
    }

    const normalizedModelName = (modelName || 'GFXV1').toUpperCase()

    // Cached model record
    let model = getCache<any>(`ai:model:${normalizedModelName}`)
    if (!model) {
      model = await db.aIModel.findUnique({ where: { name: normalizedModelName } })
      if (!model) {
        model = await db.aIModel.create({
          data: {
            name: normalizedModelName,
            description: 'GfxV1 AI Agent',
            type: 'MULTIMODAL',
            dailyLimit: 50,
            monthlyLimit: 1000,
          },
        })
      }
      setCache(`ai:model:${normalizedModelName}`, model, 600)
    }

    if (!model.isActive) {
      return NextResponse.json({ error: `${normalizedModelName} is currently offline` }, { status: 503 })
    }

    // Daily limit check (skip for admins)
    const userRole = (session.user as any).role
    const isAdmin = userRole === 'ADMIN' || userRole === 'SUPER_ADMIN'
    if (!isAdmin) {
      const today = new Date()
      today.setHours(0, 0, 0, 0)
      const usedToday = await db.aIUsage.count({
        where: { userId: session.user.id, modelId: model.id, createdAt: { gte: today } },
      })
      if (usedToday >= model.dailyLimit) {
        return NextResponse.json(
          { error: `Daily limit reached (${model.dailyLimit}/day). Upgrade your plan for more access.` },
          { status: 429 }
        )
      }
    }

    const userSessionId = sessionId || `${session.user.id}-${new Date().toISOString().slice(0, 10)}`

    let response = ''
    let mediaUrl = ''
    let type = 'text'

    // ── CHAT / CODE mode ─────────────────────────────────────────────────
    if (mode === 'chat') {
      type = style === 'code' ? 'code' : 'text'

      const result = await generateGfxResponse({
        prompt,
        messages: messages.slice(-12).filter((m: any) => m?.content?.trim()),
        userId: session.user.id,
        sessionId: userSessionId,
        settings,
        modelName: normalizedModelName,
        style,
      })

      response = result.response
    }

    // ── PHOTO mode ────────────────────────────────────────────────────────
    else if (mode === 'photo') {
      type = 'image'
      const safeSeed = Math.floor(Math.random() * 1000000)
      const styleHint = prompt.toLowerCase().includes('realistic') ? 'photorealistic, ultra detailed' : 'digital art, high quality'
      mediaUrl = `https://pollinations.ai/p/${encodeURIComponent(prompt + ', ' + styleHint)}?width=1024&height=1024&seed=${safeSeed}&model=flux&nologo=true&enhance=true`
      response = `${normalizedModelName} Image Engine rendered your prompt. Generating: "${prompt.slice(0, 80)}"`
    }

    // ── VIDEO mode ────────────────────────────────────────────────────────
    else if (mode === 'video') {
      type = 'image'
      const safeSeed = Math.floor(Math.random() * 1000000)
      mediaUrl = `https://pollinations.ai/p/${encodeURIComponent(prompt + ', cinematic shot, 4k, film quality')}?width=1280&height=720&seed=${safeSeed}&model=flux&nologo=true`
      response = `${normalizedModelName} Video Engine rendered a cinematic frame for: "${prompt.slice(0, 80)}". Connect a video API in Admin → AI Config for full video output.`
    }

    // ── AUDIO / VOICE mode ────────────────────────────────────────────────
    else if (mode === 'audio') {
      type = 'audio'
      const isBengali = /[\u0980-\u09FF]/.test(prompt)
      const langCode = isBengali ? 'bn' : 'en'
      mediaUrl = `https://translate.google.com/translate_tts?ie=UTF-8&q=${encodeURIComponent(prompt.slice(0, 200))}&tl=${langCode}&client=tw-ob`
      response = `${normalizedModelName} Voice Engine synthesized audio in ${isBengali ? 'Bengali' : 'English'}.`
    }

    // ── Log usage ─────────────────────────────────────────────────────────
    await db.aIUsage.create({
      data: {
        userId: session.user.id,
        modelId: model.id,
        prompt: prompt.slice(0, 500),
        response: response.slice(0, 1000),
        type: mode.toUpperCase(),
      },
    }).catch(() => {})

    return NextResponse.json({ response, mediaUrl, type, model: normalizedModelName })
  } catch (error: any) {
    console.error('[GfxV1]', error?.message || error)
    return NextResponse.json(
      { error: 'GfxV1 internal error: ' + (error?.message || 'Unknown') },
      { status: 500 }
    )
  }
}
