import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { title, category, type } = await req.json()
  if (!title) return NextResponse.json({ error: 'Title required' }, { status: 400 })

  // Generate SEO content without external API - smart template-based approach
  const categoryContext: Record<string, string> = {
    plugins: 'Server plugin',
    mods: 'Game mod',
    'texture-packs': 'Texture/resource pack',
    maps: 'Game map',
    shaders: 'Shader pack',
    'server-setups': 'Server setup',
    default: 'Digital content'
  }

  const ctx = categoryContext[category?.toLowerCase()] || categoryContext.default

  const descriptions = [
    `Transform your gaming experience with ${title}! This premium ${ctx} brings stunning new features and gameplay enhancements that every player needs. Carefully crafted for compatibility and performance, it integrates seamlessly with your existing setup.`,
    `Elevate your server with ${title} — the ultimate ${ctx} that your community will love. Built with precision and optimized for all platforms, this resource delivers an exceptional experience from day one.`,
    `Discover the power of ${title}, a professionally designed ${ctx} that takes your world to the next level. Features smooth performance, regular updates, and dedicated community support.`
  ]

  const tagSuggestions: Record<string, string[]> = {
    plugins: ['plugin', 'server', 'extension', 'addon', 'tool', 'gameplay'],
    mods: ['mod', 'modification', 'gameplay', 'adventure', 'enhancement'],
    'texture-packs': ['texture', 'resource-pack', 'visual', 'hd', 'realistic', 'design'],
    maps: ['map', 'world', 'adventure', 'survival', 'creative', 'level'],
    shaders: ['shader', 'graphics', 'visual', 'realistic', 'lighting', 'effects'],
    'server-setups': ['server', 'setup', 'bundle', 'config', 'ready-to-use', 'starter'],
    default: ['download', 'free', 'content', 'marketplace', 'creator', 'digital']
  }

  const baseTags = tagSuggestions[category?.toLowerCase()] || tagSuggestions.default
  const titleWords = title.toLowerCase().split(' ').filter((w: string) => w.length > 3)
  const tags = [...new Set([...baseTags, ...titleWords])].slice(0, 12)

  const description = descriptions[Math.floor(Math.random() * descriptions.length)]

  const shortDescs = [
    `Premium ${ctx} — ${title.split(' ').slice(0, 3).join(' ')} for ultimate gameplay`,
    `The best ${ctx} for your community — ${title}`,
    `Download ${title} — Top-rated ${ctx}`
  ]

  return NextResponse.json({
    description,
    shortDesc: shortDescs[Math.floor(Math.random() * shortDescs.length)],
    tags,
    seoTitle: `${title} | Best ${category || 'Content'} Download`,
  })
}
