import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const model = await db.aIModel.findUnique({ where: { name: 'GFXV1' } })
    if (!model) {
      // Create default GFXV1 model if it doesn't exist
      const newModel = await db.aIModel.create({
        data: {
          name: 'GFXV1',
          description: 'Multimodal AI for GfxStore',
          type: 'MULTIMODAL',
          dailyLimit: 50,
          monthlyLimit: 1000
        }
      })
      return NextResponse.json({
        daily: newModel.dailyLimit,
        monthly: newModel.monthlyLimit,
        usedToday: 0
      })
    }

    const today = new Date()
    today.setHours(0, 0, 0, 0)

    const usedToday = await db.aIUsage.count({
      where: {
        userId: session.user.id,
        modelId: model.id,
        createdAt: { gte: today }
      }
    })

    return NextResponse.json({
      daily: model.dailyLimit,
      monthly: model.monthlyLimit,
      usedToday
    })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch limits' }, { status: 500 })
  }
}
