import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { getCache, setCache } from '@/lib/cache'
import { callAiImage, ImagePurpose } from '@/lib/ai-image'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 120

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Please sign in to generate images.' }, { status: 401 })
    }

    const { prompt, size, purpose = 'image' } = await request.json() as {
      prompt: string; size?: string; purpose?: ImagePurpose
    }
    if (!prompt?.trim()) return NextResponse.json({ error: 'Prompt is required' }, { status: 400 })

    // Use cache for settings (5 min TTL)
    let settings = getCache<any>('site:settings')
    if (!settings) {
      settings = await db.siteSettings.findFirst()
      if (settings) setCache('site:settings', settings, 300)
    }

    try {
      const result = await callAiImage({
        prompt,
        size,
        purpose,
        settings
      })
      return NextResponse.json(result)
    } catch (e: any) {
      return NextResponse.json({
        error: e.message || 'Image generation failed',
      }, { status: 500 })
    }
  } catch (error: any) {
    return NextResponse.json({ error: error?.message || 'Internal server error' }, { status: 500 })
  }
}
