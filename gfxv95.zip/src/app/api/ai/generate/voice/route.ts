import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { writeFile, mkdir } from 'fs/promises'
import { existsSync } from 'fs'
import { join } from 'path'
import crypto from 'crypto'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 120

type VoiceProvider = 'elevenlabs' | 'deepgram' | 'openai' | 'pollinations'

interface AttemptLog {
  provider: VoiceProvider
  model: string
  status: 'ok' | 'fail'
  error?: string
}

interface VoiceResult {
  ok: boolean
  bytes?: Buffer
  contentType?: string
  ext?: string
  error?: string
  provider?: VoiceProvider
  model?: string
}

async function persistAudio(buffer: Buffer, ext = 'mp3'): Promise<string> {
  const dir = join(process.cwd(), 'public', 'uploads', 'ai-voice')
  if (!existsSync(dir)) await mkdir(dir, { recursive: true })
  const name = `${crypto.randomUUID()}.${ext}`
  await writeFile(join(dir, name), buffer)
  return `/uploads/ai-voice/${name}`
}

// ---------- ElevenLabs ----------
// Docs: https://api.elevenlabs.io/v1/text-to-speech/{voice_id}
async function tryElevenLabs(apiKey: string, text: string, voiceId: string, modelId: string): Promise<VoiceResult> {
  try {
    const r = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${voiceId}?output_format=mp3_44100_128`, {
      method: 'POST',
      headers: {
        'xi-api-key': apiKey,
        'Content-Type': 'application/json',
        'Accept': 'audio/mpeg',
      },
      body: JSON.stringify({
        text,
        model_id: modelId || 'eleven_multilingual_v2',
        voice_settings: { stability: 0.45, similarity_boost: 0.75, style: 0.15, use_speaker_boost: true },
      }),
    })
    if (!r.ok) {
      const errTxt = await r.text().catch(() => '')
      return { ok: false, error: `HTTP ${r.status}: ${errTxt.slice(0, 200)}`, provider: 'elevenlabs', model: modelId }
    }
    const buf = Buffer.from(await r.arrayBuffer())
    return { ok: true, bytes: buf, contentType: 'audio/mpeg', ext: 'mp3', provider: 'elevenlabs', model: modelId }
  } catch (e: any) {
    return { ok: false, error: e?.message || 'elevenlabs network error', provider: 'elevenlabs', model: modelId }
  }
}

// ---------- Deepgram Aura TTS ----------
// Docs: https://developers.deepgram.com/docs/text-to-speech
// POST https://api.deepgram.com/v1/speak?model=aura-asteria-en
async function tryDeepgram(apiKey: string, text: string, voiceModel: string): Promise<VoiceResult> {
  try {
    const r = await fetch(`https://api.deepgram.com/v1/speak?model=${encodeURIComponent(voiceModel)}&encoding=mp3`, {
      method: 'POST',
      headers: {
        Authorization: `Token ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ text }),
    })
    if (!r.ok) {
      const errTxt = await r.text().catch(() => '')
      return { ok: false, error: `HTTP ${r.status}: ${errTxt.slice(0, 200)}`, provider: 'deepgram', model: voiceModel }
    }
    const buf = Buffer.from(await r.arrayBuffer())
    return { ok: true, bytes: buf, contentType: 'audio/mpeg', ext: 'mp3', provider: 'deepgram', model: voiceModel }
  } catch (e: any) {
    return { ok: false, error: e?.message || 'deepgram network error', provider: 'deepgram', model: voiceModel }
  }
}

// ---------- OpenAI TTS ----------
// Docs: https://platform.openai.com/docs/guides/text-to-speech
async function tryOpenAi(apiKey: string, text: string, voice: string, model: string): Promise<VoiceResult> {
  try {
    const r = await fetch('https://api.openai.com/v1/audio/speech', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: model || 'tts-1',
        voice: voice || 'alloy',
        input: text,
        response_format: 'mp3',
      }),
    })
    if (!r.ok) {
      const errTxt = await r.text().catch(() => '')
      return { ok: false, error: `HTTP ${r.status}: ${errTxt.slice(0, 200)}`, provider: 'openai', model }
    }
    const buf = Buffer.from(await r.arrayBuffer())
    return { ok: true, bytes: buf, contentType: 'audio/mpeg', ext: 'mp3', provider: 'openai', model }
  } catch (e: any) {
    return { ok: false, error: e?.message || 'openai network error', provider: 'openai', model }
  }
}

// ---------- Pollinations Free TTS (no key) ----------
// https://text.pollinations.ai/{prompt}?model=openai-audio&voice={voice}
async function tryPollinations(text: string, voice: string): Promise<VoiceResult> {
  try {
    const url = `https://text.pollinations.ai/${encodeURIComponent(text)}?model=openai-audio&voice=${encodeURIComponent(voice || 'alloy')}`
    const r = await fetch(url)
    if (!r.ok) {
      const errTxt = await r.text().catch(() => '')
      return { ok: false, error: `HTTP ${r.status}: ${errTxt.slice(0, 200)}`, provider: 'pollinations', model: 'openai-audio' }
    }
    const ct = r.headers.get('content-type') || 'audio/mpeg'
    const buf = Buffer.from(await r.arrayBuffer())
    if (buf.byteLength < 1000) {
      return { ok: false, error: 'pollinations returned empty audio', provider: 'pollinations', model: 'openai-audio' }
    }
    return { ok: true, bytes: buf, contentType: ct, ext: ct.includes('wav') ? 'wav' : 'mp3', provider: 'pollinations', model: 'openai-audio' }
  } catch (e: any) {
    return { ok: false, error: e?.message || 'pollinations network error', provider: 'pollinations', model: 'openai-audio' }
  }
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.email) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json().catch(() => ({} as any))
  const text = String(body.text || body.prompt || '').trim()
  const voiceId = String(body.voiceId || '').trim()       // ElevenLabs voice id
  const deepgramVoice = String(body.deepgramVoice || 'aura-asteria-en').trim()
  const openaiVoice = String(body.openaiVoice || 'alloy').trim()

  if (!text) return NextResponse.json({ error: 'Text is required' }, { status: 400 })
  if (text.length > 5000) return NextResponse.json({ error: 'Text too long (max 5000 chars)' }, { status: 400 })

  const settings: any = await db.siteSettings.findFirst().catch(() => null) || {}

  const elevenKey = settings.elevenlabsApiKey || process.env.ELEVENLABS_API_KEY || ''
  const deepgramKey = settings.deepgramApiKey || process.env.DEEPGRAM_API_KEY || ''
  const openaiKey = settings.openaiApiKey || settings.aiApiKey || process.env.OPENAI_API_KEY || ''

  const attempts: AttemptLog[] = []
  let result: VoiceResult | null = null

  // 1. ElevenLabs (highest quality, voice cloning)
  if (elevenKey) {
    const eleVoice = voiceId || '21m00Tcm4TlvDq8ikWAM' // Rachel default
    const r = await tryElevenLabs(elevenKey, text, eleVoice, 'eleven_multilingual_v2')
    attempts.push({ provider: 'elevenlabs', model: 'eleven_multilingual_v2', status: r.ok ? 'ok' : 'fail', error: r.error })
    if (r.ok) result = r
  }

  // 2. Deepgram Aura
  if (!result && deepgramKey) {
    const r = await tryDeepgram(deepgramKey, text, deepgramVoice)
    attempts.push({ provider: 'deepgram', model: deepgramVoice, status: r.ok ? 'ok' : 'fail', error: r.error })
    if (r.ok) result = r
  }

  // 3. OpenAI TTS
  if (!result && openaiKey) {
    const r = await tryOpenAi(openaiKey, text, openaiVoice, 'tts-1')
    attempts.push({ provider: 'openai', model: 'tts-1', status: r.ok ? 'ok' : 'fail', error: r.error })
    if (r.ok) result = r
  }

  // 4. Pollinations free fallback (no key required)
  if (!result) {
    const r = await tryPollinations(text, openaiVoice)
    attempts.push({ provider: 'pollinations', model: 'openai-audio', status: r.ok ? 'ok' : 'fail', error: r.error })
    if (r.ok) result = r
  }

  if (!result || !result.bytes) {
    return NextResponse.json({
      error: 'All voice providers failed. Please add an ElevenLabs / Deepgram / OpenAI key in admin settings.',
      attempts,
    }, { status: 502 })
  }

  const audioUrl = await persistAudio(result.bytes, result.ext || 'mp3')

  return NextResponse.json({
    audioUrl,
    provider: result.provider,
    model: result.model,
    attempts,
    chars: text.length,
  })
}

export async function GET() {
  return NextResponse.json({ error: 'Use POST' }, { status: 405 })
}
