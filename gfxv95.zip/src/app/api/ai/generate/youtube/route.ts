import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { callAiText, extractJson } from '@/lib/ai-text'
import { callAiImage } from '@/lib/ai-image'
import { db } from '@/lib/db'
import { getCache, setCache } from '@/lib/cache'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 120

const STYLE_HINTS: Record<string, string> = {
  gaming: 'vibrant gaming style, bold neon accents, dramatic lighting, action energy',
  vlog: 'clean lifestyle vlog, warm tones, natural lighting, friendly mood',
  tech: 'sleek modern tech style, futuristic gradients, clean typography',
  cinematic: 'cinematic film look, moody color grade, dramatic composition, anamorphic',
  tutorial: 'clean educational layout, clear focal point, large bold typography area',
  music: 'glowing music visualizer, audio reactive, neon vibes',
  shorts: 'high-energy vertical short, eye-catching, big bold elements',
  podcast: 'studio podcast vibe, microphone focus, premium dark background',
  news: 'professional news style, clean modern broadcast layout',
  review: 'product review hero, clean studio backdrop, high detail',
}

interface GeneratedYouTube {
  title: string
  description: string
  tags: string[]
  hashtags: string[]
  shortDescription: string
  thumbnailPrompt: string
  chapters?: { time: string; label: string }[]
  callToAction?: string
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Please sign in to use YouTube Gen.' }, { status: 401 })
    }

    const body = await req.json().catch(() => ({})) as {
      prompt?: string
      language?: 'en' | 'bn'
      style?: string
      tone?: string
      includeChapters?: boolean
      generateThumbnail?: boolean
    }

    const prompt = (body.prompt || '').trim()
    if (!prompt) {
      return NextResponse.json({ error: 'A video idea / prompt is required.' }, { status: 400 })
    }
    if (prompt.length > 2000) {
      return NextResponse.json({ error: 'Prompt is too long (max 2000 characters).' }, { status: 400 })
    }

    const language = body.language === 'bn' ? 'bn' : 'en'
    const style = (body.style || 'tech').toLowerCase()
    const tone = (body.tone || 'engaging, friendly, professional').slice(0, 120)
    const includeChapters = !!body.includeChapters
    const generateThumbnail = body.generateThumbnail !== false

    const langInstruction = language === 'bn'
      ? 'Write the title, description, shortDescription, hashtags and chapter labels in BENGALI (Bangla). Tags must still be lowercase English search keywords.'
      : 'Write all output in ENGLISH.'

    const systemPrompt = `You are GFX YouTube Studio AI — a professional YouTube SEO + scriptwriting assistant.
You ONLY output valid JSON, nothing else. No prose, no code fences, no commentary.

The user gives a video idea and you produce a complete, click-worthy YouTube package optimized for:
- Strong CTR (curiosity, benefit, specificity, emotion in the title — NEVER clickbait lies)
- High retention (description hook in first 2 lines)
- YouTube SEO (relevant searchable tags + hashtags)
- A high-impact thumbnail prompt

Rules:
- Title: 60–70 characters max, must include the main keyword early.
- Description: 600–1500 characters, structured. First 2 lines = hook the viewer (this is what shows above the fold).
- Tags: 12–20 single-word or short-phrase lowercase SEO tags, no leading #, no quotes.
- Hashtags: exactly 5, each starts with #, mix of broad and niche.
- shortDescription: 1 punchy sentence (under 140 chars) for social shares.
- thumbnailPrompt: a vivid, single-paragraph image-generation prompt that produces a 16:9 YouTube thumbnail. Mention bold focal subject, dramatic lighting, clear composition, ZERO text/letters in the image (text will be added later). Style hint: ${STYLE_HINTS[style] || STYLE_HINTS.tech}.
- ${includeChapters ? 'chapters: array of 5–8 timestamped chapters like {"time":"0:00","label":"Intro"}.' : 'chapters: empty array [].'}
- callToAction: short single-line CTA for the description (subscribe / like / comment).

Tone: ${tone}.
${langInstruction}

Return ONLY this exact JSON shape:
{
  "title": "string",
  "description": "string",
  "tags": ["string", ...],
  "hashtags": ["#string", ...],
  "shortDescription": "string",
  "thumbnailPrompt": "string",
  "chapters": [{"time":"0:00","label":"string"}],
  "callToAction": "string"
}`

    let aiResult: { reply: string; provider: string; model: string }
    try {
      aiResult = await callAiText({
        systemPrompt,
        messages: [{ role: 'user', content: `Video idea: ${prompt}` }],
        maxTokens: 1500,
      })
    } catch (e: any) {
      return NextResponse.json({
        error: `AI text generation failed: ${e?.message || 'unknown'}. Add an AI key in Admin → AI API Keys.`,
      }, { status: 502 })
    }

    const parsed = extractJson<GeneratedYouTube>(aiResult.reply)
    if (!parsed || !parsed.title) {
      return NextResponse.json({
        error: 'AI returned an unparseable response. Try again or switch the default model.',
        rawPreview: aiResult.reply.slice(0, 400),
      }, { status: 502 })
    }

    // Defensive normalization
    const normalized: GeneratedYouTube = {
      title: String(parsed.title || '').slice(0, 100).trim(),
      description: String(parsed.description || '').slice(0, 5000).trim(),
      tags: Array.isArray(parsed.tags)
        ? parsed.tags.map(t => String(t).replace(/^#/, '').toLowerCase().trim()).filter(Boolean).slice(0, 25)
        : [],
      hashtags: Array.isArray(parsed.hashtags)
        ? parsed.hashtags.map(t => {
            const s = String(t).trim()
            return s.startsWith('#') ? s : `#${s.replace(/\s+/g, '')}`
          }).filter(t => t.length > 1).slice(0, 8)
        : [],
      shortDescription: String(parsed.shortDescription || '').slice(0, 200).trim(),
      thumbnailPrompt: String(parsed.thumbnailPrompt || prompt).slice(0, 800).trim(),
      chapters: Array.isArray(parsed.chapters)
        ? parsed.chapters
            .map(c => ({ time: String(c?.time || '0:00').trim(), label: String(c?.label || '').slice(0, 80).trim() }))
            .filter(c => c.label)
            .slice(0, 12)
        : [],
      callToAction: String(parsed.callToAction || '').slice(0, 200).trim(),
    }

    let thumbnailUrl: string | null = null
    let thumbnailError: string | null = null

    if (generateThumbnail) {
      try {
        // Use cache for settings (5 min TTL)
        let settings = getCache<any>('site:settings')
        if (!settings) {
          settings = await db.siteSettings.findFirst()
          if (settings) setCache('site:settings', settings, 300)
        }

        const imgData = await callAiImage({
          prompt: `${normalized.thumbnailPrompt}. Composition for a YouTube thumbnail, 16:9, ultra-detailed, vibrant, sharp focus, ${STYLE_HINTS[style] || STYLE_HINTS.tech}. NO TEXT, NO WORDS, NO LETTERS in image.`,
          purpose: 'video-thumbnail',
          size: '1536x1024',
          settings
        })
        
        if (imgData.imageUrl) {
          thumbnailUrl = imgData.imageUrl
        } else {
          thumbnailError = 'Image generation failed'
        }
      } catch (e: any) {
        thumbnailError = e?.message || 'Thumbnail generation failed'
      }
    }

    return NextResponse.json({
      ...normalized,
      thumbnailUrl,
      thumbnailError,
      meta: {
        provider: 'gfx',
        textProvider: aiResult.provider,
        textModel: aiResult.model,
        language,
        style,
      },
    })
  } catch (error: any) {
    return NextResponse.json({ error: error?.message || 'Internal server error.' }, { status: 500 })
  }
}
