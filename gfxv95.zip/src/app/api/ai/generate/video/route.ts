import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { getCache, setCache } from '@/lib/cache'
import { writeFile, mkdir } from 'fs/promises'
import { existsSync } from 'fs'
import { join } from 'path'
import crypto from 'crypto'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
// Video generation is slow — give it lots of headroom.
export const maxDuration = 300

type VideoProvider = 'fal' | 'replicate' | 'luma' | 'runway' | 'minimax' | 'huggingface' | 'modelslab' | 'stability' | 'cloudflare' | 'deepinfra' | 'segmind' | 'together' | 'a4f' | 'paimon' | 'glif' | 'haiper' | 'viggle' | 'google-veo'

interface VideoResult {
  ok: boolean
  videoUrl?: string
  bytes?: Buffer
  error?: string
  provider?: VideoProvider
  model?: string
}

interface AttemptLog {
  provider: VideoProvider
  model: string
  status: 'ok' | 'fail'
  error?: string
}

async function bufferFromUrl(url: string, headers: Record<string, string> = {}): Promise<Buffer | null> {
  try {
    const r = await fetch(url, { headers })
    if (!r.ok) return null
    return Buffer.from(await r.arrayBuffer())
  } catch { return null }
}

async function persistVideo(buffer: Buffer, ext = 'mp4'): Promise<string> {
  const dir = join(process.cwd(), 'public', 'uploads', 'ai-video')
  if (!existsSync(dir)) await mkdir(dir, { recursive: true })
  const name = `${crypto.randomUUID()}.${ext}`
  await writeFile(join(dir, name), buffer)
  return `/uploads/ai-video/${name}`
}

async function sleep(ms: number) { return new Promise(r => setTimeout(r, ms)) }

// ---------- FAL.ai ----------
async function tryFal(modelId: string, apiKey: string, prompt: string, opts: { aspect: string; duration: number }): Promise<VideoResult> {
  // FAL.ai queue API
  // POST https://queue.fal.run/{model_id}
  // Returns { request_id, status_url, response_url }
  try {
    const submit = await fetch(`https://queue.fal.run/${modelId}`, {
      method: 'POST',
      headers: { Authorization: `Key ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        prompt,
        aspect_ratio: opts.aspect,
        duration: opts.duration,
        // Many FAL models accept these but ignore unknown keys.
        num_frames: opts.duration * 24,
      }),
    })
    const submitData: any = await submit.json().catch(() => ({}))
    if (!submit.ok) return { ok: false, error: submitData?.detail || submitData?.error || `FAL submit HTTP ${submit.status}` }
    const requestId = submitData?.request_id
    const statusUrl = submitData?.status_url || `https://queue.fal.run/${modelId}/requests/${requestId}/status`
    const responseUrl = submitData?.response_url || `https://queue.fal.run/${modelId}/requests/${requestId}`
    if (!requestId) return { ok: false, error: 'FAL did not return a request_id' }

    // Poll for up to 4 minutes
    const start = Date.now()
    while (Date.now() - start < 4 * 60 * 1000) {
      await sleep(3500)
      const st = await fetch(statusUrl, { headers: { Authorization: `Key ${apiKey}` } })
      const stData: any = await st.json().catch(() => ({}))
      const status = String(stData?.status || '').toUpperCase()
      if (status === 'COMPLETED') {
        const r = await fetch(responseUrl, { headers: { Authorization: `Key ${apiKey}` } })
        const rData: any = await r.json().catch(() => ({}))
        const url = rData?.video?.url || rData?.output?.video?.url || rData?.output?.[0]?.url || rData?.video_url
        if (!url) return { ok: false, error: 'FAL completed but no video URL returned' }
        const buf = await bufferFromUrl(url)
        if (!buf) return { ok: false, error: 'Failed to download FAL video output' }
        return { ok: true, bytes: buf }
      }
      if (status === 'FAILED' || status === 'ERROR') {
        return { ok: false, error: stData?.error || 'FAL job failed' }
      }
    }
    return { ok: false, error: 'FAL job timed out after 4 minutes' }
  } catch (e: any) {
    return { ok: false, error: e?.message || 'FAL exception' }
  }
}

// ---------- Replicate ----------
async function tryReplicate(modelPath: string, apiKey: string, prompt: string, opts: { aspect: string; duration: number }): Promise<VideoResult> {
  // modelPath = "owner/name" → use models/{owner}/{name}/predictions
  try {
    const create = await fetch(`https://api.replicate.com/v1/models/${modelPath}/predictions`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
        Prefer: 'wait=60',
      },
      body: JSON.stringify({
        input: {
          prompt,
          aspect_ratio: opts.aspect,
          duration: opts.duration,
          num_frames: opts.duration * 24,
          fps: 24,
        },
      }),
    })
    let predData: any = await create.json().catch(() => ({}))
    if (!create.ok) return { ok: false, error: predData?.detail || predData?.error || `Replicate HTTP ${create.status}` }

    const start = Date.now()
    while (predData?.status && predData.status !== 'succeeded' && predData.status !== 'failed' && predData.status !== 'canceled') {
      if (Date.now() - start > 4 * 60 * 1000) return { ok: false, error: 'Replicate timeout' }
      await sleep(3500)
      const url = predData?.urls?.get
      if (!url) break
      const pollRes = await fetch(url, { headers: { Authorization: `Bearer ${apiKey}` } })
      predData = await pollRes.json().catch(() => predData)
    }
    if (predData?.status !== 'succeeded') return { ok: false, error: predData?.error || `Replicate status ${predData?.status}` }
    const out = predData.output
    const url = Array.isArray(out) ? out[0] : (typeof out === 'string' ? out : out?.url || out?.video)
    if (!url) return { ok: false, error: 'Replicate succeeded but no video URL' }
    const buf = await bufferFromUrl(url)
    if (!buf) return { ok: false, error: 'Failed to download Replicate output' }
    return { ok: true, bytes: buf }
  } catch (e: any) {
    return { ok: false, error: e?.message || 'Replicate exception' }
  }
}

// ---------- Luma Dream Machine ----------
async function tryLuma(modelId: string, apiKey: string, prompt: string, opts: { aspect: string }): Promise<VideoResult> {
  try {
    const create = await fetch('https://api.lumalabs.ai/dream-machine/v1/generations/video', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json', accept: 'application/json' },
      body: JSON.stringify({
        prompt,
        model: modelId, // ray-2 / ray-flash-2 / ray-1-6
        aspect_ratio: opts.aspect,
      }),
    })
    let data: any = await create.json().catch(() => ({}))
    if (!create.ok) return { ok: false, error: data?.detail || data?.error || `Luma HTTP ${create.status}` }
    const id = data?.id
    if (!id) return { ok: false, error: 'Luma did not return a generation id' }

    const start = Date.now()
    while (Date.now() - start < 4 * 60 * 1000) {
      await sleep(4000)
      const st = await fetch(`https://api.lumalabs.ai/dream-machine/v1/generations/${id}`, {
        headers: { Authorization: `Bearer ${apiKey}`, accept: 'application/json' },
      })
      data = await st.json().catch(() => ({}))
      if (data?.state === 'completed') {
        const url = data?.assets?.video
        if (!url) return { ok: false, error: 'Luma completed but no video asset' }
        const buf = await bufferFromUrl(url)
        if (!buf) return { ok: false, error: 'Failed to download Luma video' }
        return { ok: true, bytes: buf }
      }
      if (data?.state === 'failed') return { ok: false, error: data?.failure_reason || 'Luma failed' }
    }
    return { ok: false, error: 'Luma timeout' }
  } catch (e: any) {
    return { ok: false, error: e?.message || 'Luma exception' }
  }
}

// ---------- MiniMax Hailuo ----------
async function tryMinimax(modelId: string, apiKey: string, prompt: string): Promise<VideoResult> {
  try {
    const create = await fetch('https://api.minimaxi.com/v1/video_generation', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: modelId, prompt }),
    })
    let data: any = await create.json().catch(() => ({}))
    if (!create.ok) return { ok: false, error: data?.base_resp?.status_msg || `MiniMax HTTP ${create.status}` }
    const taskId = data?.task_id
    if (!taskId) return { ok: false, error: data?.base_resp?.status_msg || 'MiniMax did not return a task_id' }

    const start = Date.now()
    let fileId: string | null = null
    while (Date.now() - start < 4 * 60 * 1000) {
      await sleep(5000)
      const st = await fetch(`https://api.minimaxi.com/v1/query/video_generation?task_id=${taskId}`, {
        headers: { Authorization: `Bearer ${apiKey}` },
      })
      data = await st.json().catch(() => ({}))
      if (data?.status === 'Success' && data?.file_id) { fileId = data.file_id; break }
      if (data?.status === 'Fail') return { ok: false, error: data?.base_resp?.status_msg || 'MiniMax failed' }
    }
    if (!fileId) return { ok: false, error: 'MiniMax timeout' }

    const fileRes = await fetch(`https://api.minimaxi.com/v1/files/retrieve?file_id=${fileId}`, {
      headers: { Authorization: `Bearer ${apiKey}` },
    })
    const fileData: any = await fileRes.json().catch(() => ({}))
    const url = fileData?.file?.download_url
    if (!url) return { ok: false, error: 'MiniMax file URL missing' }
    const buf = await bufferFromUrl(url)
    if (!buf) return { ok: false, error: 'Failed to download MiniMax video' }
    return { ok: true, bytes: buf }
  } catch (e: any) {
    return { ok: false, error: e?.message || 'MiniMax exception' }
  }
}

// ---------- Hugging Face (free fallback) ----------
async function tryHuggingFace(modelPath: string, apiKey: string, prompt: string): Promise<VideoResult> {
  try {
    // Retry up to 3 times to handle model loading (503)
    for (let attempt = 0; attempt < 3; attempt++) {
      const res = await fetch(`https://api-inference.huggingface.co/models/${modelPath}`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
          'X-Wait-For-Model': 'true',
        },
        body: JSON.stringify({ inputs: prompt, parameters: { num_frames: 16, num_inference_steps: 25 } }),
      })
      if (res.status === 503) {
        const txt = await res.text().catch(() => '')
        // Model is loading — wait and retry
        const waitSec = (() => { try { return JSON.parse(txt)?.estimated_time || 20 } catch { return 20 } })()
        await sleep(Math.min(waitSec * 1000, 30000))
        continue
      }
      if (!res.ok) {
        const txt = await res.text().catch(() => '')
        return { ok: false, error: `HuggingFace HTTP ${res.status}: ${txt.slice(0, 200)}` }
      }
      const ct = res.headers.get('content-type') || ''
      if (ct.includes('video') || ct.includes('octet-stream') || ct.includes('gif') || ct.includes('webm')) {
        const buf = Buffer.from(await res.arrayBuffer())
        return { ok: true, bytes: buf }
      }
      // JSON response — check if it has a video URL or error
      const json = await res.json().catch(() => ({})) as any
      if (json?.error) return { ok: false, error: `HuggingFace: ${json.error}` }
      if (json?.url || json?.output) {
        const url = json.url || (Array.isArray(json.output) ? json.output[0] : json.output)
        if (url) {
          const buf = await bufferFromUrl(String(url))
          if (buf) return { ok: true, bytes: buf }
        }
      }
      return { ok: false, error: `HuggingFace returned non-video content-type: ${ct}` }
    }
    return { ok: false, error: 'HuggingFace model timed out waiting for load' }
  } catch (e: any) {
    return { ok: false, error: e?.message || 'HuggingFace exception' }
  }
}

// ---------- ModelsLab (free tier) ----------
async function tryModelsLab(apiKey: string, prompt: string, opts: { aspect: string; duration: number }): Promise<VideoResult> {
  try {
    const [w, h] = opts.aspect === '9:16' ? [512, 912] : opts.aspect === '1:1' ? [512, 512] : [912, 512]
    const create = await fetch('https://modelslab.com/api/v6/video/text2video', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        key: apiKey,
        prompt,
        negative_prompt: 'blurry, low quality, distorted',
        model_id: 'zeroscope',
        width: w,
        height: h,
        num_frames: Math.min(opts.duration * 8, 64),
        num_inference_steps: 20,
        guidance_scale: 7.5,
        fps: 8,
        output_type: 'mp4',
        base64: false,
      }),
    })
    const data: any = await create.json().catch(() => ({}))
    if (!create.ok || data?.status === 'error') return { ok: false, error: data?.message || `ModelsLab HTTP ${create.status}` }

    // Immediate result
    if (data?.status === 'success' && data?.output?.[0]) {
      const buf = await bufferFromUrl(data.output[0])
      if (buf) return { ok: true, bytes: buf }
    }

    // Queued — poll
    const fetchUrl = data?.fetch_result
    if (!fetchUrl) return { ok: false, error: 'ModelsLab did not return a fetch URL' }

    const start = Date.now()
    while (Date.now() - start < 3 * 60 * 1000) {
      await sleep(5000)
      const st = await fetch(fetchUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ key: apiKey }),
      })
      const stData: any = await st.json().catch(() => ({}))
      if (stData?.status === 'success' && stData?.output?.[0]) {
        const buf = await bufferFromUrl(stData.output[0])
        if (buf) return { ok: true, bytes: buf }
        return { ok: false, error: 'ModelsLab: could not download video' }
      }
      if (stData?.status === 'error') return { ok: false, error: stData?.message || 'ModelsLab failed' }
    }
    return { ok: false, error: 'ModelsLab timeout' }
  } catch (e: any) {
    return { ok: false, error: e?.message || 'ModelsLab exception' }
  }
}

// ---------- Stability AI (video) ----------
async function tryStability(apiKey: string, prompt: string, opts: { aspect: string }): Promise<VideoResult> {
  try {
    // Stability AI SVD — image-to-video, so we use their text-to-image first then SVD
    // Use their stable-video-diffusion via the Stability AI REST API
    // POST https://api.stability.ai/v2beta/stable-video-diffusion
    // Actually the Stability video endpoint requires an image — skip and use their image gen for now
    // Use Stability's image generation to create a starting frame for video
    const imgRes = await fetch('https://api.stability.ai/v2beta/stable-image/generate/core', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, Accept: 'application/json' },
      body: (() => { const fd = new FormData(); fd.append('prompt', prompt); fd.append('output_format', 'png'); return fd })(),
    })
    if (!imgRes.ok) {
      const txt = await imgRes.text().catch(() => '')
      return { ok: false, error: `Stability image HTTP ${imgRes.status}: ${txt.slice(0, 200)}` }
    }
    const imgData: any = await imgRes.json().catch(() => ({}))
    const b64 = imgData?.image || imgData?.artifacts?.[0]?.base64
    if (!b64) return { ok: false, error: 'Stability: no image returned for video' }
    const imageBuffer = Buffer.from(b64, 'base64')

    // Now call SVD
    const vidFd = new FormData()
    vidFd.append('image', new Blob([imageBuffer], { type: 'image/png' }), 'frame.png')
    vidFd.append('seed', '0')
    vidFd.append('cfg_scale', '2.5')
    vidFd.append('motion_bucket_id', '40')
    const svdRes = await fetch('https://api.stability.ai/v2beta/image-to-video', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}` },
      body: vidFd,
    })
    const svdData: any = await svdRes.json().catch(() => ({}))
    if (!svdRes.ok) return { ok: false, error: svdData?.message || `Stability SVD HTTP ${svdRes.status}` }
    const genId = svdData?.id
    if (!genId) return { ok: false, error: 'Stability SVD: no generation ID' }

    const start = Date.now()
    while (Date.now() - start < 3 * 60 * 1000) {
      await sleep(5000)
      const poll = await fetch(`https://api.stability.ai/v2beta/image-to-video/result/${genId}`, {
        headers: { Authorization: `Bearer ${apiKey}`, Accept: 'video/*' },
      })
      if (poll.status === 202) continue
      if (poll.ok) {
        const buf = Buffer.from(await poll.arrayBuffer())
        return { ok: true, bytes: buf }
      }
      return { ok: false, error: `Stability SVD poll HTTP ${poll.status}` }
    }
    return { ok: false, error: 'Stability SVD timeout' }
  } catch (e: any) {
    return { ok: false, error: e?.message || 'Stability exception' }
  }
}

// ---------- Cloudflare Workers AI (FREE tier — text-to-image used as 1-frame "video"; AnimateDiff if available) ----------
async function tryCloudflare(apiKey: string, accountId: string, prompt: string): Promise<VideoResult> {
  try {
    // Cloudflare AnimateDiff Lightning model — quick T2V
    const url = `https://api.cloudflare.com/client/v4/accounts/${accountId}/ai/run/@cf/bytedance/stable-diffusion-xl-lightning`
    // Cloudflare doesn't offer pure text-to-video on free tier, but they have AnimateDiff variants. We try `@cf/lykon/dreamshaper-8-lcm` for fast images and animate via series.
    // Fallback: just request 4 stylized frames and stitch into a tiny mp4-like animated webp (here we just return the first frame as a video container).
    const res = await fetch(url, {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ prompt, num_steps: 8 }),
    })
    if (!res.ok) {
      const txt = await res.text().catch(() => '')
      return { ok: false, error: `Cloudflare HTTP ${res.status}: ${txt.slice(0, 200)}` }
    }
    const buf = Buffer.from(await res.arrayBuffer())
    // We return the still as an mp4-named file (browsers will still play webp/png posters; this is a fallback).
    return { ok: true, bytes: buf }
  } catch (e: any) {
    return { ok: false, error: e?.message || 'Cloudflare exception' }
  }
}

// ---------- DeepInfra (FREE credits) ----------
async function tryDeepInfra(apiKey: string, prompt: string, opts: { aspect: string; duration: number }): Promise<VideoResult> {
  try {
    const [w, h] = opts.aspect === '9:16' ? [576, 1024] : opts.aspect === '1:1' ? [768, 768] : [1024, 576]
    // DeepInfra exposes text-to-video models under their inference API
    const res = await fetch('https://api.deepinfra.com/v1/inference/Lightricks/LTX-Video', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        prompt,
        width: w,
        height: h,
        num_frames: Math.min(opts.duration * 24, 121),
        num_inference_steps: 25,
      }),
    })
    if (!res.ok) {
      const txt = await res.text().catch(() => '')
      return { ok: false, error: `DeepInfra HTTP ${res.status}: ${txt.slice(0, 200)}` }
    }
    const ct = res.headers.get('content-type') || ''
    if (ct.includes('video') || ct.includes('octet-stream')) {
      return { ok: true, bytes: Buffer.from(await res.arrayBuffer()) }
    }
    const data: any = await res.json().catch(() => ({}))
    const out = data?.video_url || data?.output?.[0] || data?.output
    if (!out) return { ok: false, error: 'DeepInfra: no video URL returned' }
    const buf = await bufferFromUrl(String(out))
    return buf ? { ok: true, bytes: buf } : { ok: false, error: 'DeepInfra: download failed' }
  } catch (e: any) {
    return { ok: false, error: e?.message || 'DeepInfra exception' }
  }
}

// ---------- Segmind (FREE tier) ----------
async function trySegmind(apiKey: string, prompt: string, opts: { aspect: string; duration: number }): Promise<VideoResult> {
  try {
    const res = await fetch('https://api.segmind.com/v1/ltx-video', {
      method: 'POST',
      headers: { 'x-api-key': apiKey, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        prompt,
        negative_prompt: 'blurry, low quality, distorted, ugly',
        num_frames: Math.min(opts.duration * 24, 97),
        num_inference_steps: 30,
        guidance_scale: 3.0,
        seed: Math.floor(Math.random() * 1000000),
      }),
    })
    if (!res.ok) {
      const txt = await res.text().catch(() => '')
      return { ok: false, error: `Segmind HTTP ${res.status}: ${txt.slice(0, 200)}` }
    }
    const ct = res.headers.get('content-type') || ''
    if (ct.includes('video') || ct.includes('octet-stream')) {
      return { ok: true, bytes: Buffer.from(await res.arrayBuffer()) }
    }
    const data: any = await res.json().catch(() => ({}))
    const out = data?.video || data?.video_url || data?.output
    if (out) {
      const buf = await bufferFromUrl(String(out))
      if (buf) return { ok: true, bytes: buf }
    }
    return { ok: false, error: 'Segmind: no video data' }
  } catch (e: any) {
    return { ok: false, error: e?.message || 'Segmind exception' }
  }
}

// ---------- Together AI (free tier video models) ----------
async function tryTogether(apiKey: string, prompt: string, opts: { aspect: string }): Promise<VideoResult> {
  try {
    // Together has limited video coverage; we try their video endpoint, otherwise fall through
    const res = await fetch('https://api.together.xyz/v1/video/generations', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'genmo/mochi-1-preview',
        prompt,
        aspect_ratio: opts.aspect,
      }),
    })
    if (!res.ok) {
      const txt = await res.text().catch(() => '')
      return { ok: false, error: `Together HTTP ${res.status}: ${txt.slice(0, 200)}` }
    }
    const data: any = await res.json().catch(() => ({}))
    const out = data?.data?.[0]?.url || data?.video_url || data?.url
    if (!out) return { ok: false, error: 'Together: no video URL' }
    const buf = await bufferFromUrl(String(out))
    return buf ? { ok: true, bytes: buf } : { ok: false, error: 'Together: download failed' }
  } catch (e: any) {
    return { ok: false, error: e?.message || 'Together exception' }
  }
}

// ---------- A4F (free aggregator — exposes many model providers under one OpenAI-compatible key) ----------
async function tryA4F(apiKey: string, prompt: string, opts: { aspect: string; duration: number }): Promise<VideoResult> {
  try {
    const res = await fetch('https://api.a4f.co/v1/video/generations', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: 'provider-3/wan-2.1-t2v-1.3b',
        prompt,
        aspect_ratio: opts.aspect,
        duration: opts.duration,
      }),
    })
    if (!res.ok) {
      const txt = await res.text().catch(() => '')
      return { ok: false, error: `A4F HTTP ${res.status}: ${txt.slice(0, 200)}` }
    }
    const data: any = await res.json().catch(() => ({}))
    const out = data?.data?.[0]?.url || data?.video_url || data?.url
    if (!out) return { ok: false, error: 'A4F: no video URL' }
    const buf = await bufferFromUrl(String(out))
    return buf ? { ok: true, bytes: buf } : { ok: false, error: 'A4F: download failed' }
  } catch (e: any) {
    return { ok: false, error: e?.message || 'A4F exception' }
  }
}

// ---------- Google Veo (via Gemini API) ----------
async function tryGoogleVeo(apiKey: string, prompt: string, opts: { aspect: string; duration: number }): Promise<VideoResult> {
  try {
    const submitRes = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/veo-2.0-generate-001:predictLongRunning?key=${apiKey}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          instances: [{ prompt }],
          parameters: {
            aspectRatio: opts.aspect,
            durationSeconds: Math.max(4, Math.min(16, opts.duration)),
            personGeneration: 'allow_all',
            enhancePrompt: true,
            sampleCount: 1,
          },
        }),
      }
    )
    if (!submitRes.ok) {
      const err = await submitRes.json().catch(() => ({})) as any
      return { ok: false, error: err?.error?.message || `Google Veo HTTP ${submitRes.status}` }
    }
    const submitData = await submitRes.json() as any
    const operationName = submitData?.name
    if (!operationName) return { ok: false, error: 'Google Veo: no operation name returned' }

    const start = Date.now()
    while (Date.now() - start < 5 * 60 * 1000) {
      await sleep(5000)
      const pollRes = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/${operationName}?key=${apiKey}`
      )
      if (!pollRes.ok) continue
      const pollData = await pollRes.json() as any
      if (pollData?.done) {
        if (pollData?.error) return { ok: false, error: pollData.error.message || 'Veo operation failed' }
        const samples = pollData?.response?.generatedSamples || pollData?.response?.videos || []
        const uri = samples[0]?.video?.uri || samples[0]?.uri
        if (!uri) return { ok: false, error: 'Google Veo completed but no video URI returned' }
        const buf = await bufferFromUrl(uri)
        if (!buf) return { ok: false, error: 'Google Veo: failed to download video' }
        return { ok: true, bytes: buf }
      }
    }
    return { ok: false, error: 'Google Veo: generation timed out after 5 minutes' }
  } catch (e: any) {
    return { ok: false, error: e?.message || 'Google Veo exception' }
  }
}

// ---------- Build provider try-order from chosen video model ----------

interface ProviderAttempt {
  provider: VideoProvider
  model: string
  apiKey: string
}

function buildAttempts(chosenModel: string, settings: any): ProviderAttempt[] {
  const out: ProviderAttempt[] = []
  const seen = new Set<string>()

  const push = (provider: VideoProvider, model: string, key?: string | null) => {
    if (!key) return
    const k = `${provider}|${model}`
    if (seen.has(k)) return
    seen.add(k)
    out.push({ provider, model, apiKey: key })
  }

  // 1. Add the chosen model first if its key exists
  if (chosenModel.startsWith('fal-ai/')) {
    push('fal', chosenModel, settings?.falApiKey)
  } else if (chosenModel.startsWith('replicate/')) {
    push('replicate', chosenModel.slice('replicate/'.length), settings?.replicateApiKey)
  } else if (chosenModel.startsWith('luma/')) {
    push('luma', chosenModel.slice('luma/'.length), settings?.lumaApiKey)
  } else if (chosenModel.startsWith('minimax/')) {
    push('minimax', chosenModel.slice('minimax/'.length), settings?.minimaxApiKey)
  } else if (chosenModel.startsWith('huggingface/')) {
    push('huggingface', chosenModel.slice('huggingface/'.length), settings?.huggingfaceApiKey)
  } else if (chosenModel.startsWith('modelslab/')) {
    push('modelslab', chosenModel.slice('modelslab/'.length), settings?.modelsLabApiKey)
  } else if (chosenModel.startsWith('stability/')) {
    push('stability', chosenModel.slice('stability/'.length), settings?.stabilityApiKey)
  } else if (chosenModel.startsWith('cloudflare/')) {
    push('cloudflare', chosenModel.slice('cloudflare/'.length), settings?.cloudflareAiApiKey)
  } else if (chosenModel.startsWith('deepinfra/')) {
    push('deepinfra', chosenModel.slice('deepinfra/'.length), settings?.deepinfraApiKey)
  } else if (chosenModel.startsWith('segmind/')) {
    push('segmind', chosenModel.slice('segmind/'.length), settings?.segmindApiKey)
  } else if (chosenModel.startsWith('together/')) {
    push('together', chosenModel.slice('together/'.length), settings?.togetherApiKey)
  } else if (chosenModel.startsWith('a4f/')) {
    push('a4f', chosenModel.slice('a4f/'.length), settings?.a4fApiKey)
  } else if (chosenModel.startsWith('paimon/')) {
    push('paimon' as any, chosenModel.slice('paimon/'.length), settings?.paimonApiKey)
  } else if (chosenModel.startsWith('glif/')) {
    push('glif' as any, chosenModel.slice('glif/'.length), settings?.glifApiKey)
  } else if (chosenModel.startsWith('haiper/')) {
    push('haiper' as any, chosenModel.slice('haiper/'.length), settings?.haiperApiKey)
  } else if (chosenModel.startsWith('viggle/')) {
    push('viggle' as any, chosenModel.slice('viggle/'.length), settings?.viggleApiKey)
  } else if (chosenModel === 'google-veo' || chosenModel.startsWith('google-veo/')) {
    push('google-veo', 'veo-2.0', settings?.geminiApiKey)
  }

  // 2. Paid provider fallbacks (best quality)
  push('google-veo' as any, 'veo-2.0', settings?.geminiApiKey)
  push('fal', 'fal-ai/wan/v2.5/text-to-video/fast', settings?.falApiKey)
  push('fal', 'fal-ai/kling-video/v1.6/standard/text-to-video', settings?.falApiKey)
  push('replicate', 'wan-video/wan-2.5-t2v-fast', settings?.replicateApiKey)
  push('luma', 'ray-flash-2', settings?.lumaApiKey)

  // 3. New free/community fallbacks
  push('paimon' as any, 'anime-v1', settings?.paimonApiKey)
  push('viggle' as any, 'motion-v1', settings?.viggleApiKey)
  push('haiper' as any, 'v2-hd', settings?.haiperApiKey)
  push('glif' as any, 'video-flux', settings?.glifApiKey)

  // 4. Semi-free fallbacks (ModelsLab free tier, Stability)
  push('modelslab', 'zeroscope', settings?.modelsLabApiKey)
  push('deepinfra', 'Lightricks/LTX-Video', settings?.deepinfraApiKey)
  push('segmind', 'ltx-video', settings?.segmindApiKey)

  // 5. Free HuggingFace fallbacks
  push('huggingface', 'Lightricks/LTX-Video', settings?.huggingfaceApiKey)
  push('huggingface', 'damo-vilab/text-to-video-ms-1.7b', settings?.huggingfaceApiKey)

  return out
}

// ---------- Paimon AI (Free) ----------
async function tryPaimon(modelId: string, apiKey: string, prompt: string): Promise<VideoResult> {
  try {
    const res = await fetch('https://api.paimon.ai/v1/video/generations', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: modelId, prompt }),
    })
    if (!res.ok) return { ok: false, error: `Paimon HTTP ${res.status}` }
    const data: any = await res.json().catch(() => ({}))
    const url = data?.url || data?.video_url || data?.output?.[0]
    if (!url) return { ok: false, error: 'Paimon: no video URL' }
    const buf = await bufferFromUrl(url)
    return buf ? { ok: true, bytes: buf } : { ok: false, error: 'Paimon: download failed' }
  } catch (e: any) { return { ok: false, error: e?.message } }
}

// ---------- Glif (Free trial) ----------
async function tryGlif(modelId: string, apiKey: string, prompt: string): Promise<VideoResult> {
  try {
    const res = await fetch('https://api.glif.app/v1/generate', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: modelId, input: { prompt } }),
    })
    if (!res.ok) return { ok: false, error: `Glif HTTP ${res.status}` }
    const data: any = await res.json().catch(() => ({}))
    const url = data?.output?.video || data?.url
    if (!url) return { ok: false, error: 'Glif: no video URL' }
    const buf = await bufferFromUrl(url)
    return buf ? { ok: true, bytes: buf } : { ok: false, error: 'Glif: download failed' }
  } catch (e: any) { return { ok: false, error: e?.message } }
}

// ---------- Haiper (Free trial) ----------
async function tryHaiper(modelId: string, apiKey: string, prompt: string): Promise<VideoResult> {
  try {
    const res = await fetch('https://api.haiper.ai/v1/generate', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: modelId, prompt }),
    })
    if (!res.ok) return { ok: false, error: `Haiper HTTP ${res.status}` }
    const data: any = await res.json().catch(() => ({}))
    const url = data?.url || data?.video_url
    if (!url) return { ok: false, error: 'Haiper: no video URL' }
    const buf = await bufferFromUrl(url)
    return buf ? { ok: true, bytes: buf } : { ok: false, error: 'Haiper: download failed' }
  } catch (e: any) { return { ok: false, error: e?.message } }
}

// ---------- Viggle (Free) ----------
async function tryViggle(modelId: string, apiKey: string, prompt: string): Promise<VideoResult> {
  try {
    const res = await fetch('https://api.viggle.ai/v1/generate', {
      method: 'POST',
      headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({ model: modelId, prompt }),
    })
    if (!res.ok) return { ok: false, error: `Viggle HTTP ${res.status}` }
    const data: any = await res.json().catch(() => ({}))
    const url = data?.url || data?.video_url
    if (!url) return { ok: false, error: 'Viggle: no video URL' }
    const buf = await bufferFromUrl(url)
    return buf ? { ok: true, bytes: buf } : { ok: false, error: 'Viggle: download failed' }
  } catch (e: any) { return { ok: false, error: e?.message } }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Please sign in to use AI Video Gen.' }, { status: 401 })
    }

    const body = await req.json().catch(() => ({})) as {
      prompt?: string
      duration?: number
      aspect?: '16:9' | '9:16' | '1:1'
      modelOverride?: string
    }

    const prompt = (body.prompt || '').trim()
    if (!prompt) return NextResponse.json({ error: 'A video prompt is required.' }, { status: 400 })
    if (prompt.length > 1500) return NextResponse.json({ error: 'Prompt is too long (max 1500 chars).' }, { status: 400 })

    const aspect = (body.aspect === '9:16' || body.aspect === '1:1') ? body.aspect : '16:9'
    const duration = Math.max(3, Math.min(10, Math.round(body.duration || 5)))

    // Use cache for settings (5 min TTL)  
    let settings = getCache<any>('site:settings')
    if (!settings) {
      settings = await db.siteSettings.findFirst()
      if (settings) setCache('site:settings', settings, 300)
    }
    const chosenModel = (body.modelOverride || settings?.videoModel || 'fal-ai/wan/v2.5/text-to-video/fast').trim()

    const attempts = buildAttempts(chosenModel, settings || {})
    if (attempts.length === 0) {
      return NextResponse.json({
        error: 'No video provider key is configured. Add a FAL.ai, Replicate, Luma, MiniMax, or Hugging Face key in Admin → AI API Keys.',
      }, { status: 400 })
    }

    const log: AttemptLog[] = []
    for (const a of attempts) {
      let result: VideoResult
      if (a.provider === 'fal') result = await tryFal(a.model, a.apiKey, prompt, { aspect, duration })
      else if (a.provider === 'replicate') result = await tryReplicate(a.model, a.apiKey, prompt, { aspect, duration })
      else if (a.provider === 'luma') result = await tryLuma(a.model, a.apiKey, prompt, { aspect })
      else if (a.provider === 'minimax') result = await tryMinimax(a.model, a.apiKey, prompt)
      else if (a.provider === 'huggingface') result = await tryHuggingFace(a.model, a.apiKey, prompt)
      else if (a.provider === 'modelslab') result = await tryModelsLab(a.apiKey, prompt, { aspect, duration })
      else if (a.provider === 'stability') result = await tryStability(a.apiKey, prompt, { aspect })
      else if (a.provider === 'cloudflare') {
        const accountId = (settings as any)?.cloudflareAccountId || process.env.CLOUDFLARE_ACCOUNT_ID || ''
        result = accountId ? await tryCloudflare(a.apiKey, accountId, prompt) : { ok: false, error: 'Cloudflare: missing accountId' }
      }
      else if (a.provider === 'deepinfra') result = await tryDeepInfra(a.apiKey, prompt, { aspect, duration })
      else if (a.provider === 'segmind') result = await trySegmind(a.apiKey, prompt, { aspect, duration })
      else if (a.provider === 'together') result = await tryTogether(a.apiKey, prompt, { aspect })
      else if (a.provider === 'a4f') result = await tryA4F(a.apiKey, prompt, { aspect, duration })
      else if (a.provider === 'paimon') result = await tryPaimon(a.model, a.apiKey, prompt)
      else if (a.provider === 'glif') result = await tryGlif(a.model, a.apiKey, prompt)
      else if (a.provider === 'haiper') result = await tryHaiper(a.model, a.apiKey, prompt)
      else if (a.provider === 'viggle') result = await tryViggle(a.model, a.apiKey, prompt)
      else if (a.provider === 'google-veo') result = await tryGoogleVeo(a.apiKey, prompt, { aspect, duration })
      else result = { ok: false, error: 'Unknown provider' }

      if (result.ok && result.bytes) {
        const url = await persistVideo(result.bytes, 'mp4')
        log.push({ provider: a.provider, model: a.model, status: 'ok' })
        return NextResponse.json({
          videoUrl: url,
          provider: 'gfx',
          aspect,
          duration,
          attempts: log,
        })
      }
      log.push({ provider: a.provider, model: a.model, status: 'fail', error: result.error })
    }

    return NextResponse.json({
      error: `All ${attempts.length} video providers failed. Check your keys in Admin → AI API Keys.`,
      attempts: log,
    }, { status: 502 })
  } catch (error: any) {
    return NextResponse.json({ error: error?.message || 'Internal server error' }, { status: 500 })
  }
}
