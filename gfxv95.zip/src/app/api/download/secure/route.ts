import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { readFile } from 'fs/promises'
import path from 'path'
import { maybeAwardBadges } from '@/lib/badge-awarder'

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const token = searchParams.get('token')

  if (!token) return NextResponse.json({ error: 'Token required' }, { status: 400 })

  const downloadToken = await db.downloadToken.findUnique({
    where: { token },
    include: {
      item: {
        include: {
          versions: { where: { isActive: true }, orderBy: { createdAt: 'desc' }, take: 1 }
        }
      }
    }
  })

  if (!downloadToken) return NextResponse.json({ error: 'Invalid download token' }, { status: 404 })
  if (downloadToken.expiresAt < new Date()) return NextResponse.json({ error: 'Download link has expired. Please generate a new one.' }, { status: 410 })
  if (downloadToken.usedAt) return NextResponse.json({ error: 'This download link has already been used' }, { status: 410 })

  // Mark token as used
  await db.downloadToken.update({ where: { token }, data: { usedAt: new Date() } })

  // Track download
  await db.download.create({
    data: { itemId: downloadToken.itemId, userId: downloadToken.userId, ipAddress: downloadToken.ipAddress || undefined }
  }).catch(() => {})

  // Increment download count
  await db.item.update({ where: { id: downloadToken.itemId }, data: { downloads: { increment: 1 } } })

  if (downloadToken.userId) {
    await maybeAwardBadges(downloadToken.userId)
  }

  const version = downloadToken.item.versions[0]
  if (!version) return NextResponse.json({ error: 'No file found for this item' }, { status: 404 })

  const cleanPath = version.filePath.replace(/^\/uploads\//, '')

  // Try multiple possible paths where the file could be stored
  const possiblePaths = [
    path.join(process.cwd(), 'public', 'uploads', cleanPath),
    path.join(process.cwd(), 'uploads', cleanPath),
    path.join(process.cwd(), 'public', 'uploads', 'items', downloadToken.itemId, version.fileName),
    path.join(process.cwd(), 'uploads', 'items', downloadToken.itemId, version.fileName),
  ]

  for (const filePath of possiblePaths) {
    try {
      const fileBuffer = await readFile(filePath)
      return new NextResponse(fileBuffer, {
        headers: {
          'Content-Type': 'application/octet-stream',
          'Content-Disposition': `attachment; filename="${version.fileName}"`,
          'Content-Length': String(fileBuffer.length),
          'Cache-Control': 'no-store, no-cache'
        }
      })
    } catch {
      // Try next path
    }
  }

  // If downloadUrl is an external http URL, redirect to it
  if (version.downloadUrl && version.downloadUrl.startsWith('http')) {
    return NextResponse.redirect(version.downloadUrl)
  }

  // Fall back to the public uploads URL (served by Next.js static files)
  const publicUrl = version.filePath.startsWith('/uploads/')
    ? `${req.nextUrl.origin}${version.filePath}`
    : `${req.nextUrl.origin}/uploads/${cleanPath}`

  return NextResponse.redirect(publicUrl)
}
