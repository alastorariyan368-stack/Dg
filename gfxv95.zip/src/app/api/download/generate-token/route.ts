import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

const PRIVILEGED_ROLES = ['ADMIN', 'SUPER_ADMIN', 'MODERATOR']

// Role hierarchy: higher index = higher tier
const ROLE_HIERARCHY: Record<string, number> = {
  USER: 1,
  BASIC: 1,
  PRO: 2,
  PREMIUM: 3,
  MODERATOR: 4,
  ADMIN: 5,
  SUPER_ADMIN: 6,
}

function getRoleLevel(role: string): number {
  return ROLE_HIERARCHY[role?.toUpperCase()] ?? 0
}

function hasRoleAccess(userRole: string, requiredRole: string): boolean {
  if (PRIVILEGED_ROLES.includes(userRole)) return true
  return getRoleLevel(userRole) >= getRoleLevel(requiredRole)
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { itemId, orderId } = await req.json()
  if (!itemId) return NextResponse.json({ error: 'Item ID required' }, { status: 400 })

  const item = await db.item.findUnique({
    where: { id: itemId },
    select: { id: true, price: true, authorId: true, status: true, accessType: true, requiredRole: true }
  })
  if (!item || item.status !== 'APPROVED') return NextResponse.json({ error: 'Item not found' }, { status: 404 })

  const isOwner = item.authorId === session.user.id
  const isFree = item.accessType === 'FREE'
  const isPrivileged = PRIVILEGED_ROLES.includes(session.user.role || '')

  if (!isOwner && !isFree && !isPrivileged) {
    if (item.accessType === 'PAID') {
      const order = await db.order.findFirst({
        where: { buyerId: session.user.id, itemId, status: 'DELIVERED' }
      })
      if (!order) return NextResponse.json({ error: 'Purchase required to download this item' }, { status: 403 })
    } else if (item.accessType === 'ROLE') {
      const dbUser = await db.user.findUnique({ where: { id: session.user.id }, select: { role: true } })
      const userRole = dbUser?.role || ''

      let hasAccess: boolean
      if (item.requiredRole) {
        hasAccess = hasRoleAccess(userRole, item.requiredRole)
      } else {
        hasAccess = userRole !== 'USER' && userRole !== 'BASIC'
      }

      if (!hasAccess) {
        const roleLabel = item.requiredRole || 'a membership'
        return NextResponse.json({ error: `${roleLabel} membership or higher required to download this item` }, { status: 403 })
      }
    }
  }

  const expiresAt = new Date(Date.now() + 30 * 60 * 1000)
  const ipAddress = req.headers.get('x-forwarded-for') || req.headers.get('x-real-ip') || 'unknown'

  const token = await db.downloadToken.create({
    data: { itemId, userId: session.user.id, orderId, expiresAt, ipAddress }
  })

  return NextResponse.json({ token: token.token, expiresAt: expiresAt.toISOString() })
}
