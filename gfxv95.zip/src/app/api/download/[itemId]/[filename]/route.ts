import { NextRequest, NextResponse } from 'next/server'
import { join } from 'path'
import { existsSync, readFileSync } from 'fs'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ itemId: string; filename: string }> }
) {
  try {
    const { itemId, filename } = await params
    
    if (!itemId || !filename) {
      return NextResponse.json({ error: 'Missing parameters' }, { status: 400 })
    }

    const baseUploadsDir = join(process.cwd(), 'public', 'uploads')

    // Try multiple possible paths
    const possiblePaths = [
      join(process.cwd(), 'public', 'uploads', 'items', itemId, filename),
      join(process.cwd(), 'public', 'uploads', itemId, filename),
      join(process.cwd(), 'uploads', 'items', itemId, filename),
      join(process.cwd(), 'uploads', itemId, filename),
    ]

    let foundPath: string | null = null
    for (const p of possiblePaths) {
      if (existsSync(p)) {
        foundPath = p
        break
      }
    }

    if (!foundPath) {
      return NextResponse.json({ error: 'File not found' }, { status: 404 })
    }

    const ext = filename.split('.').pop()?.toLowerCase() || ''
    const contentTypeMap: { [key: string]: string } = {
      zip: 'application/zip',
      rar: 'application/x-rar-compressed',
      jar: 'application/java-archive',
      mcaddon: 'application/octet-stream',
      mcpack: 'application/octet-stream',
      mcworld: 'application/octet-stream',
      mctemplate: 'application/octet-stream',
      gz: 'application/gzip',
      '7z': 'application/x-7z-compressed',
      png: 'image/png',
      jpg: 'image/jpeg',
      jpeg: 'image/jpeg',
      gif: 'image/gif',
    }
    const contentType = contentTypeMap[ext] || 'application/octet-stream'

    const fileData = readFileSync(foundPath)
    return new NextResponse(fileData, {
      headers: {
        'Content-Type': contentType,
        'Content-Length': fileData.length.toString(),
        'Content-Disposition': `attachment; filename="${filename}"`,
        'Cache-Control': 'no-store, no-cache',
      }
    })
  } catch (error) {
    console.error('File download error:', error)
    return NextResponse.json({ error: 'Failed to download file' }, { status: 500 })
  }
}
