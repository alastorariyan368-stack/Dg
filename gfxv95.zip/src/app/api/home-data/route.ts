import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { getCache, setCache } from '@/lib/cache'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const PUBLIC_CACHE_KEY = 'home:public:v2'
const PUBLIC_CACHE_TTL = 300 // 5 minutes

async function fetchPublicData() {
  const [
    totalUsers,
    totalItemsAgg,
    featuredItems,
    memberships,
    latestApps,
    latestCodes,
    latestVideos,
    latestReels,
    latestItems,
    announcements,
  ] = await Promise.all([
    db.user.count(),
    db.item.aggregate({ _sum: { downloads: true }, _count: { id: true } }),
    db.item.findMany({
      where: { featured: true, status: 'APPROVED' },
      take: 8,
      orderBy: [{ likes: 'desc' }, { downloads: 'desc' }],
      select: {
        id: true, title: true, slug: true, shortDesc: true,
        downloads: true, likes: true, logo: true, accessType: true,
        category: { select: { name: true } },
        author: { select: { username: true, avatar: true } },
      },
    }),
    db.membership.findMany({
      where: { isActive: true }, orderBy: { sortOrder: 'asc' }, take: 3,
      select: { id: true, name: true, roleName: true, description: true, price: true, features: true, color: true, isActive: true, sortOrder: true },
    }),
    db.mobileApp.findMany({
      where: { status: 'PUBLISHED' }, take: 6, orderBy: { createdAt: 'desc' },
      select: {
        id: true, title: true, icon: true, shortDesc: true, category: true,
        downloads: true, author: { select: { username: true } },
      },
    }).catch(() => []),
    db.codeProject.findMany({
      where: { status: 'PUBLISHED' }, take: 6, orderBy: { createdAt: 'desc' },
      select: {
        id: true, title: true, shortDesc: true, language: true, type: true,
        downloads: true, likes: true, author: { select: { username: true } },
      },
    }).catch(() => []),
    db.video.findMany({
      where: { status: 'APPROVED', type: 'video' }, take: 6, orderBy: { createdAt: 'desc' },
      select: {
        id: true, title: true, description: true, thumbnail: true, category: true,
        views: true, likes: true, author: { select: { username: true } },
      },
    }).catch(() => []),
    db.video.findMany({
      where: { status: 'APPROVED', type: 'reel' }, take: 10, orderBy: { views: 'desc' },
      select: { id: true, title: true, thumbnail: true, views: true },
    }).catch(() => []),
    db.item.findMany({
      where: { status: 'APPROVED' }, take: 12, orderBy: { createdAt: 'desc' },
      select: {
        id: true, title: true, slug: true, logo: true, accessType: true, likes: true,
        category: { select: { name: true } }, author: { select: { username: true } },
      },
    }),
    db.announcement.findMany({
      where: { active: true }, take: 5, orderBy: { createdAt: 'desc' },
      select: { id: true, title: true, content: true, createdAt: true },
    }),
  ])

  return {
    stats: {
      totalUsers,
      totalItems: totalItemsAgg._count.id,
      totalDownloads: totalItemsAgg._sum.downloads || 0,
    },
    featuredItems,
    memberships,
    latestApps,
    latestCodes,
    latestVideos,
    latestReels,
    latestItems,
    announcements,
  }
}

export async function GET() {
  try {
    const session = await getServerSession(authOptions)

    // Public data: serve from cache for unauthenticated requests or as base
    let cached = getCache<ReturnType<typeof fetchPublicData> extends Promise<infer T> ? T : never>(PUBLIC_CACHE_KEY)
    if (!cached) {
      const fresh = await fetchPublicData()
      setCache(PUBLIC_CACHE_KEY, fresh, PUBLIC_CACHE_TTL)
      cached = fresh as any
    }

    // User-specific data is always fresh
    let userData = null
    if (session?.user?.id) {
      userData = await db.user.findUnique({
        where: { id: session.user.id },
        select: { walletBalance: true, sellerLevel: true, totalSales: true },
      }).catch(() => null)
    }

    return NextResponse.json({
      ...(cached as any),
      user: userData,
    }, {
      headers: {
        'Cache-Control': 'private, no-cache',
        'X-Cache': cached ? 'HIT' : 'MISS',
      },
    })
  } catch (e: any) {
    console.error('home-data error:', e)
    return NextResponse.json({ error: 'Failed to load home data' }, { status: 500 })
  }
}
