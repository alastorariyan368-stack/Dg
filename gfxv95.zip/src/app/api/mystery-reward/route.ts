import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { maybeAwardBadges } from '@/lib/badge-awarder'

export async function POST() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const rewards = await db.mysteryReward.findMany({ where: { isActive: true } })
    if (rewards.length === 0) {
      return NextResponse.json({ reward: null, message: 'No rewards available' })
    }

    const roll = Math.random()
    let cumulative = 0
    let wonReward = null

    for (const reward of rewards) {
      cumulative += reward.probability
      if (roll <= cumulative) {
        wonReward = reward
        break
      }
    }

    if (!wonReward) {
      return NextResponse.json({ reward: null, message: 'Better luck next time!' })
    }

    if (wonReward.type === 'COINS') {
      await db.user.update({
        where: { id: session.user.id },
        data: { walletBalance: { increment: wonReward.value } }
      })
    }

    await db.mysteryRewardLog.create({
      data: {
        userId: session.user.id,
        rewardId: wonReward.id,
        value: wonReward.value,
        type: wonReward.type
      }
    })

    await maybeAwardBadges(session.user.id)

    return NextResponse.json({
      reward: {
        name: wonReward.name,
        type: wonReward.type,
        value: wonReward.value
      },
      message: `You won ${wonReward.name}!`
    })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to spin reward' }, { status: 500 })
  }
}
