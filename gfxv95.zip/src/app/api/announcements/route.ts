import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getCache, setCache } from '@/lib/cache'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET() {
  const cacheKey = 'announcements:active'
  const cached = getCache<any[]>(cacheKey)
  if (cached) return NextResponse.json({ announcements: cached }, { headers: { 'X-Cache': 'HIT' } })

  try {
    const items = await db.announcement.findMany({
      where: { active: true },
      orderBy: { createdAt: 'desc' },
      take: 5,
      select: { id: true, title: true, content: true, createdAt: true },
    })
    setCache(cacheKey, items, 120)
    return NextResponse.json({ announcements: items }, {
      headers: { 'Cache-Control': 'public, s-maxage=60, stale-while-revalidate=120' },
    })
  } catch {
    return NextResponse.json({ announcements: [] })
  }
}
