import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

// List my groups
export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.email) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const me = await db.user.findUnique({ where: { email: session.user.email }, select: { id: true } })
  if (!me) return NextResponse.json({ error: 'User not found' }, { status: 404 })

  const memberships = await db.groupMember.findMany({
    where: { userId: me.id },
    include: {
      group: {
        include: {
          _count: { select: { members: true, messages: true } },
          messages: { orderBy: { createdAt: 'desc' }, take: 1, include: { sender: { select: { username: true } } } },
        },
      },
    },
    orderBy: { joinedAt: 'desc' },
  })

  const groups = memberships.map(m => {
    const last = m.group.messages[0]
    return {
      id: m.group.id,
      name: m.group.name,
      description: m.group.description,
      avatar: m.group.avatar,
      ownerId: m.group.ownerId,
      role: m.role,
      memberCount: m.group._count.members,
      messageCount: m.group._count.messages,
      lastMessage: last
        ? { content: last.content, kind: last.kind, createdAt: last.createdAt, senderName: last.sender.username }
        : null,
      createdAt: m.group.createdAt,
    }
  })

  return NextResponse.json({ groups, count: groups.length })
}

// Create a group
export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.email) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const me = await db.user.findUnique({ where: { email: session.user.email }, select: { id: true, username: true } })
  if (!me) return NextResponse.json({ error: 'User not found' }, { status: 404 })

  const { name, description, avatar, memberIds = [] } = await req.json().catch(() => ({}))
  if (!name || typeof name !== 'string') return NextResponse.json({ error: 'Group name is required' }, { status: 400 })

  const cleanName = name.trim().slice(0, 80)
  if (!cleanName) return NextResponse.json({ error: 'Group name is required' }, { status: 400 })

  const memberIdList: string[] = Array.from(new Set([
    me.id,
    ...(Array.isArray(memberIds) ? memberIds.filter((x: any) => typeof x === 'string') : []),
  ])).slice(0, 100)

  const group = await db.group.create({
    data: {
      name: cleanName,
      description: description ? String(description).slice(0, 300) : null,
      avatar: avatar ? String(avatar).slice(0, 500) : null,
      ownerId: me.id,
      members: {
        create: memberIdList.map(uid => ({
          userId: uid,
          role: uid === me.id ? 'OWNER' : 'MEMBER',
        })),
      },
    },
    include: { _count: { select: { members: true } } },
  })

  // Notify added members
  for (const uid of memberIdList) {
    if (uid === me.id) continue
    await db.notification.create({
      data: {
        userId: uid,
        title: 'Added to a group',
        content: `${me.username} added you to "${cleanName}"`,
        type: 'NEW_MESSAGE',
      },
    }).catch(() => {})
    if ((global as any).io) {
      (global as any).io.to(`user:${uid}`).emit('groupAdded', { groupId: group.id, name: cleanName })
    }
  }

  return NextResponse.json({ group }, { status: 201 })
}
