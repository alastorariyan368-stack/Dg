import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

const ALLOWED_KINDS = new Set(['TEXT', 'IMAGE', 'VOICE', 'VIDEO', 'FILE', 'CALL'])

async function getMe() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.email) return null
  return db.user.findUnique({ where: { email: session.user.email }, select: { id: true, username: true } })
}

export async function GET(req: NextRequest, { params }: { params: Promise<{ groupId: string }> }) {
  const { groupId } = await params
  const me = await getMe()
  if (!me) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const member = await db.groupMember.findUnique({ where: { groupId_userId: { groupId, userId: me.id } } }).catch(() => null)
  if (!member) return NextResponse.json({ error: 'Not a member' }, { status: 403 })

  const { searchParams } = new URL(req.url)
  const limit = Math.min(parseInt(searchParams.get('limit') || '100', 10) || 100, 200)

  const rows = await db.groupMessage.findMany({
    where: { groupId, deletedAt: null },
    orderBy: { createdAt: 'desc' },
    take: limit,
    include: { sender: { select: { id: true, username: true, avatar: true } } },
  })

  // Update lastReadAt
  await db.groupMember.update({
    where: { groupId_userId: { groupId, userId: me.id } },
    data: { lastReadAt: new Date() },
  }).catch(() => {})

  return NextResponse.json({ messages: rows.reverse() })
}

export async function POST(req: NextRequest, { params }: { params: Promise<{ groupId: string }> }) {
  const { groupId } = await params
  const me = await getMe()
  if (!me) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const member = await db.groupMember.findUnique({ where: { groupId_userId: { groupId, userId: me.id } } }).catch(() => null)
  if (!member) return NextResponse.json({ error: 'Not a member' }, { status: 403 })

  const body = await req.json().catch(() => ({} as any))
  const { content = '', kind = 'TEXT', mediaUrl, mediaName, mimeType, durationSec, thumbnailUrl, callId } = body || {}

  if (!ALLOWED_KINDS.has(kind)) return NextResponse.json({ error: 'Invalid kind' }, { status: 400 })
  const trimmed = String(content || '').trim().slice(0, 4000)
  if (kind === 'TEXT' && !trimmed) return NextResponse.json({ error: 'Empty message' }, { status: 400 })
  if (kind !== 'TEXT' && kind !== 'CALL' && !mediaUrl) return NextResponse.json({ error: 'mediaUrl required' }, { status: 400 })

  const msg = await db.groupMessage.create({
    data: {
      groupId, senderId: me.id, content: trimmed, kind,
      mediaUrl: mediaUrl || null,
      mediaName: mediaName ? String(mediaName).slice(0, 200) : null,
      mimeType: mimeType ? String(mimeType).slice(0, 100) : null,
      durationSec: typeof durationSec === 'number' ? Math.max(0, Math.floor(durationSec)) : null,
      thumbnailUrl: thumbnailUrl || null,
      callId: callId || null,
    },
    include: { sender: { select: { id: true, username: true, avatar: true } } },
  })

  // Broadcast to all members via socket
  const members = await db.groupMember.findMany({ where: { groupId }, select: { userId: true } })
  if ((global as any).io) {
    for (const m of members) {
      (global as any).io.to(`user:${m.userId}`).emit('newGroupMessage', { groupId, message: msg })
    }
  }
  return NextResponse.json(msg, { status: 201 })
}
