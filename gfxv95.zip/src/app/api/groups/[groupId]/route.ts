import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

async function getMe() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.email) return null
  return db.user.findUnique({ where: { email: session.user.email }, select: { id: true, username: true } })
}

export async function GET(_req: NextRequest, { params }: { params: Promise<{ groupId: string }> }) {
  const { groupId } = await params
  const me = await getMe()
  if (!me) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const member = await db.groupMember.findUnique({
    where: { groupId_userId: { groupId, userId: me.id } },
  }).catch(() => null)
  if (!member) return NextResponse.json({ error: 'Not a member' }, { status: 403 })

  const group = await db.group.findUnique({
    where: { id: groupId },
    include: {
      members: {
        include: { user: { select: { id: true, username: true, avatar: true, isActive: true } } },
        orderBy: { joinedAt: 'asc' },
      },
    },
  })
  if (!group) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  return NextResponse.json({
    group: {
      id: group.id, name: group.name, description: group.description, avatar: group.avatar,
      ownerId: group.ownerId, createdAt: group.createdAt,
      myRole: member.role,
      members: group.members.map(m => ({
        userId: m.userId, role: m.role, joinedAt: m.joinedAt,
        username: m.user.username, avatar: m.user.avatar, isActive: m.user.isActive,
      })),
    },
  })
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ groupId: string }> }) {
  const { groupId } = await params
  const me = await getMe()
  if (!me) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const member = await db.groupMember.findUnique({ where: { groupId_userId: { groupId, userId: me.id } } }).catch(() => null)
  if (!member || (member.role !== 'OWNER' && member.role !== 'ADMIN')) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  const { name, description, avatar } = await req.json().catch(() => ({}))
  const updated = await db.group.update({
    where: { id: groupId },
    data: {
      ...(name !== undefined ? { name: String(name).trim().slice(0, 80) } : {}),
      ...(description !== undefined ? { description: description ? String(description).slice(0, 300) : null } : {}),
      ...(avatar !== undefined ? { avatar: avatar ? String(avatar).slice(0, 500) : null } : {}),
    },
  })
  return NextResponse.json({ group: updated })
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ groupId: string }> }) {
  const { groupId } = await params
  const me = await getMe()
  if (!me) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const group = await db.group.findUnique({ where: { id: groupId }, select: { ownerId: true } })
  if (!group) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  if (group.ownerId !== me.id) return NextResponse.json({ error: 'Only the owner can delete this group' }, { status: 403 })

  await db.group.delete({ where: { id: groupId } })
  return NextResponse.json({ ok: true })
}
