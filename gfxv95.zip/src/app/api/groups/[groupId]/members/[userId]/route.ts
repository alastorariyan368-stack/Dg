import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

async function getMe() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.email) return null
  return db.user.findUnique({ where: { email: session.user.email } })
}

// DELETE — remove a member (kick by owner/admin, or leave if it's yourself)
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ groupId: string; userId: string }> }) {
  const me = await getMe()
  if (!me) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { groupId, userId } = await params

  const group = await db.group.findUnique({ where: { id: groupId } })
  if (!group) return NextResponse.json({ error: 'Group not found' }, { status: 404 })

  const myMembership = await db.groupMember.findUnique({ where: { groupId_userId: { groupId, userId: me.id } } }).catch(() => null)
  if (!myMembership) return NextResponse.json({ error: 'Not a member' }, { status: 403 })

  const isSelf = userId === me.id
  const isOwner = group.ownerId === me.id
  const isGroupAdmin = myMembership.role === 'ADMIN' || isOwner

  if (!isSelf && !isGroupAdmin) return NextResponse.json({ error: 'Only group admin can kick members' }, { status: 403 })
  if (userId === group.ownerId && !isSelf) return NextResponse.json({ error: 'Cannot kick the owner' }, { status: 400 })

  await db.groupMember.delete({ where: { groupId_userId: { groupId, userId } } }).catch(() => null)

  // Notify the kicked user + the rest of the group via socket
  try {
    const io = (global as any).io
    if (io) {
      io.to(`user:${userId}`).emit('group:kicked', { groupId, by: me.username })
      io.to(`group:${groupId}`).emit('group:memberLeft', { groupId, userId })
    }
  } catch {}

  // System message
  try {
    await db.groupMessage.create({
      data: {
        groupId,
        senderId: me.id,
        content: isSelf ? `${me.username} left the group` : `${me.username} removed a member`,
        kind: 'SYSTEM',
      },
    })
  } catch {}

  return NextResponse.json({ ok: true })
}

// PATCH — change role (owner only)
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ groupId: string; userId: string }> }) {
  const me = await getMe()
  if (!me) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { groupId, userId } = await params
  const { role } = await req.json().catch(() => ({} as any))
  if (!['ADMIN', 'MEMBER'].includes(role)) return NextResponse.json({ error: 'role must be ADMIN or MEMBER' }, { status: 400 })

  const group = await db.group.findUnique({ where: { id: groupId } })
  if (!group) return NextResponse.json({ error: 'Group not found' }, { status: 404 })
  if (group.ownerId !== me.id) return NextResponse.json({ error: 'Only the owner can change roles' }, { status: 403 })

  const updated = await db.groupMember.update({ where: { groupId_userId: { groupId, userId } }, data: { role } })
  return NextResponse.json({ member: updated })
}
