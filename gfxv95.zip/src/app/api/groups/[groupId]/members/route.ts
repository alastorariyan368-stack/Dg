import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

async function getMe() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.email) return null
  return db.user.findUnique({ where: { email: session.user.email }, select: { id: true, username: true } })
}

// Add a member
export async function POST(req: NextRequest, { params }: { params: Promise<{ groupId: string }> }) {
  const { groupId } = await params
  const me = await getMe()
  if (!me) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const myMembership = await db.groupMember.findUnique({ where: { groupId_userId: { groupId, userId: me.id } } }).catch(() => null)
  if (!myMembership || (myMembership.role !== 'OWNER' && myMembership.role !== 'ADMIN')) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  const { userId } = await req.json().catch(() => ({}))
  if (!userId) return NextResponse.json({ error: 'userId required' }, { status: 400 })

  const exists = await db.groupMember.findUnique({ where: { groupId_userId: { groupId, userId } } }).catch(() => null)
  if (exists) return NextResponse.json({ error: 'Already a member' }, { status: 409 })

  const m = await db.groupMember.create({
    data: { groupId, userId, role: 'MEMBER' },
    include: { user: { select: { username: true } }, group: { select: { name: true } } },
  })

  await db.notification.create({
    data: {
      userId,
      title: 'Added to a group',
      content: `${me.username} added you to "${m.group.name}"`,
      type: 'NEW_MESSAGE',
    },
  }).catch(() => {})
  if ((global as any).io) (global as any).io.to(`user:${userId}`).emit('groupAdded', { groupId, name: m.group.name })

  return NextResponse.json({ ok: true })
}

// Remove a member  (?userId=...)
export async function DELETE(req: NextRequest, { params }: { params: Promise<{ groupId: string }> }) {
  const { groupId } = await params
  const me = await getMe()
  if (!me) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const targetUserId = searchParams.get('userId') || me.id

  const myMembership = await db.groupMember.findUnique({ where: { groupId_userId: { groupId, userId: me.id } } }).catch(() => null)
  if (!myMembership) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  // Self-leave is always allowed (unless you're the owner — owner must transfer/delete first)
  if (targetUserId === me.id) {
    if (myMembership.role === 'OWNER') {
      return NextResponse.json({ error: 'Owner must delete the group instead of leaving' }, { status: 400 })
    }
    await db.groupMember.delete({ where: { groupId_userId: { groupId, userId: me.id } } })
    return NextResponse.json({ ok: true })
  }

  // Removing someone else needs admin/owner
  if (myMembership.role !== 'OWNER' && myMembership.role !== 'ADMIN') {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }
  await db.groupMember.delete({ where: { groupId_userId: { groupId, userId: targetUserId } } }).catch(() => {})
  return NextResponse.json({ ok: true })
}
