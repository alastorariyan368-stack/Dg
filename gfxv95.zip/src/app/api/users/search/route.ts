import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'
import { checkFeature } from '@/lib/feature-toggles'
import { parseBadgeIds, getBadgeDetailsByIds } from '@/lib/badge-utils'

export async function GET(request: NextRequest) {
  try {
    const blocked = await checkFeature('friends', 'Friends System')
    if (blocked) return blocked
    
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    const searchQuery = request.nextUrl.searchParams.get('q')
    const page = Math.max(1, parseInt(request.nextUrl.searchParams.get('page') || '1'))
    const limit = Math.min(100, parseInt(request.nextUrl.searchParams.get('limit') || '20'))
    const skip = (page - 1) * limit

    const baseWhere: any = {
      AND: [
        { NOT: { id: user.id } },
        { isBanned: false },
      ]
    }

    if (searchQuery && searchQuery.length >= 1) {
      baseWhere.AND.push({ username: { contains: searchQuery, mode: 'insensitive' } })
    }

    // Count total matching users
    const total = await db.user.count({ where: baseWhere })

    // Search for users by username with pagination
    const users = await db.user.findMany({
      where: baseWhere,
      select: {
        id: true,
        username: true,
        avatar: true,
        bio: true,
        badges: true,
        isActive: true
      },
      skip: skip,
      take: limit,
      orderBy: { username: 'asc' }
    })

    const totalPages = Math.ceil(total / limit)

    // Fetch badge details for all users
    const usersWithBadges = await Promise.all(
      users.map(async (u) => {
        const badgeIds = parseBadgeIds((u as any).badges)
        const badgeDetails = badgeIds.length > 0 ? await getBadgeDetailsByIds(badgeIds) : []
        return {
          ...u,
          badges: badgeIds,
          badgeDetails
        }
      })
    )

    return NextResponse.json({
      users: usersWithBadges,
      total: total,
      count: users.length,
      page: page,
      limit: limit,
      totalPages: totalPages,
      hasNextPage: page < totalPages,
      hasPreviousPage: page > 1
    })
  } catch (error) {
    console.error('Error searching users:', error)
    return NextResponse.json(
      { error: 'Failed to search users' },
      { status: 500 }
    )
  }
}
