import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ balance: 0, cartCount: 0, wishlistCount: 0 })
    }

    const [user, cartCount, wishlistCount] = await Promise.all([
      db.user.findUnique({
        where: { id: session.user.id },
        select: { walletBalance: true },
      }),
      db.cartItem.count({ where: { userId: session.user.id } }).catch(() => 0),
      db.wishlist.count({ where: { userId: session.user.id } }).catch(() => 0),
    ])

    return NextResponse.json({
      balance: user?.walletBalance ?? 0,
      cartCount,
      wishlistCount,
    }, {
      headers: { 'Cache-Control': 'private, max-age=60' },
    })
  } catch {
    return NextResponse.json({ balance: 0, cartCount: 0, wishlistCount: 0 })
  }
}
