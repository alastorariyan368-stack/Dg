import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { getBadgeDetailsByIds, parseBadgeIds } from '@/lib/badge-utils'

export async function GET(req: NextRequest, { params }: { params: Promise<{ username: string }> }) {
  const session = await getServerSession(authOptions)
  const { username } = await params

  const user = await db.user.findUnique({
    where: { username },
    select: {
      id: true, username: true, role: true, avatar: true, bio: true,
      badges: true, socialLinks: true, isVerified: true, sellerLevel: true, totalSales: true, createdAt: true,
      _count: {
        select: {
          items: true,
          followers: true,
          following: true,
          reviews: true
        }
      }
    }
  })

  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })

  const badgeIds = parseBadgeIds((user as any).badges)
  const badgeDetails = await getBadgeDetailsByIds(badgeIds)

  // Check if current user follows this profile
  let isFollowing = false
  if (session?.user?.id && session.user.id !== user.id) {
    const follow = await db.follow.findUnique({
      where: { followerId_followingId: { followerId: session.user.id, followingId: user.id } }
    })
    isFollowing = !!follow
  }

  return NextResponse.json({ ...user, isFollowing, badges: badgeIds, badgeDetails })
}
