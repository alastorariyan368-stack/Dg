import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import crypto from 'crypto'

// Public payment gateway API — requires X-API-Key header
// Usage: POST /api/v1/payment/deposit
// Body: { userId, amount, method, reference?, metadata? }
export async function POST(req: NextRequest) {
  try {
    const apiKey = req.headers.get('x-api-key') || req.headers.get('authorization')?.replace('Bearer ', '')
    if (!apiKey) return NextResponse.json({ error: 'API key required. Send X-API-Key header.' }, { status: 401 })

    const keyRecord = await db.externalApiKey.findUnique({ where: { key: apiKey } })
    if (!keyRecord || !keyRecord.isActive) return NextResponse.json({ error: 'Invalid or inactive API key' }, { status: 401 })

    const perms: string[] = (keyRecord.permissions as string[]) || []
    if (!perms.includes('payment:deposit')) return NextResponse.json({ error: 'This key does not have payment:deposit permission' }, { status: 403 })

    const body = await req.json()
    const { userId, amount, method, reference, metadata } = body

    if (!userId || !amount || !method) {
      return NextResponse.json({ error: 'userId, amount and method are required' }, { status: 400 })
    }
    if (amount <= 0) return NextResponse.json({ error: 'Amount must be > 0' }, { status: 400 })

    const user = await db.user.findUnique({ where: { id: userId }, select: { id: true, username: true } })
    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })

    const settings = await db.siteSettings.findFirst()
    const methodMap: Record<string, string | null> = {
      nagad: settings?.nagadNumber || null,
      bkash: settings?.bkashNumber || null,
      binance: settings?.binanceId || null,
      paypal: (settings as any)?.paypalEmail || null,
    }

    const txId = crypto.randomBytes(8).toString('hex').toUpperCase()

    const tx = await db.transaction.create({
      data: {
        userId,
        amount: parseFloat(amount),
        method,
        type: 'DEPOSIT',
        status: 'PENDING',
        reference: reference || txId,
        externalKeyId: keyRecord.id,
      },
    })

    // Update key stats
    await db.externalApiKey.update({
      where: { id: keyRecord.id },
      data: { requestCount: { increment: 1 }, lastUsedAt: new Date() },
    })

    // Fire webhook if configured
    if (keyRecord.webhookUrl) {
      fetch(keyRecord.webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-GfxStore-Event': 'payment.created' },
        body: JSON.stringify({ event: 'payment.created', transactionId: tx.id, userId, amount, method, status: 'PENDING', metadata }),
      }).catch(() => {})
    }

    return NextResponse.json({
      success: true,
      transactionId: tx.id,
      reference: tx.reference,
      status: 'PENDING',
      paymentTarget: methodMap[method] || null,
      instructions: `Send ৳${amount} via ${method}. Use reference "${tx.reference}" as note/memo. The deposit will be approved within 30 minutes.`,
      approveUrl: `${process.env.NEXTAUTH_URL || ''}/admin/transactions`,
    })
  } catch (e) {
    console.error('[v1/payment/deposit]', e)
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}
