import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET /api/v1/payment/status?txId=xxx
export async function GET(req: NextRequest) {
  try {
    const apiKey = req.headers.get('x-api-key') || req.headers.get('authorization')?.replace('Bearer ', '')
    if (!apiKey) return NextResponse.json({ error: 'API key required' }, { status: 401 })

    const keyRecord = await db.externalApiKey.findUnique({ where: { key: apiKey } })
    if (!keyRecord || !keyRecord.isActive) return NextResponse.json({ error: 'Invalid or inactive API key' }, { status: 401 })

    const txId = req.nextUrl.searchParams.get('txId')
    if (!txId) return NextResponse.json({ error: 'txId query param required' }, { status: 400 })

    const tx = await db.transaction.findUnique({ where: { id: txId }, select: { id: true, amount: true, method: true, status: true, reference: true, createdAt: true } })
    if (!tx) return NextResponse.json({ error: 'Transaction not found' }, { status: 404 })

    return NextResponse.json({ transactionId: tx.id, status: tx.status, amount: tx.amount, method: tx.method, reference: tx.reference, createdAt: tx.createdAt })
  } catch {
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}
