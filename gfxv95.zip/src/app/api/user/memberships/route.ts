import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { withRetry } from '@/lib/db-retry'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json([], { status: 200 })
    }

    const [user, allMemberships] = await withRetry(
      () => Promise.all([
        db.user.findUnique({
          where: { id: session.user.id },
          select: { role: true }
        }),
        db.membership.findMany({
          where: { isActive: true },
          orderBy: { sortOrder: 'asc' }
        })
      ]),
      'Fetch user memberships'
    )

    if (!user || !allMemberships) {
      return NextResponse.json([], { status: 200 })
    }

    const withStatus = allMemberships.map(m => ({
      ...m,
      owned: user.role === m.roleName
    }))

    return NextResponse.json(withStatus || [])
  } catch (error) {
    console.error('User memberships error:', error)
    return NextResponse.json([], { status: 200 })
  }
}
