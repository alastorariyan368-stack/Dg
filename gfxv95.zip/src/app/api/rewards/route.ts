import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const rewards = await db.mysteryReward.findMany({
      where: { isActive: true },
      orderBy: { probability: 'desc' }
    })
    return NextResponse.json({ rewards })
  } catch {
    return NextResponse.json({ rewards: [] })
  }
}
