import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const user = await db.user.findUnique({
    where: { id: session.user.id },
    select: { id: true, walletBalance: true, lastRewardClaim: true }
  })
  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })

  const now = new Date()
  if (user.lastRewardClaim) {
    const lastClaim = new Date(user.lastRewardClaim)
    const hoursSince = (now.getTime() - lastClaim.getTime()) / (1000 * 60 * 60)
    if (hoursSince < 24) {
      const nextClaim = new Date(lastClaim.getTime() + 24 * 60 * 60 * 1000)
      return NextResponse.json({
        error: 'Already claimed today',
        nextClaimAt: nextClaim.toISOString(),
        hoursRemaining: Math.ceil(24 - hoursSince)
      }, { status: 429 })
    }
  }

  const rewards = await db.mysteryReward.findMany({ where: { isActive: true } })
  if (rewards.length === 0) return NextResponse.json({ error: 'No rewards available' }, { status: 404 })

  const totalProb = rewards.reduce((sum, r) => sum + r.probability, 0)
  let rand = Math.random() * totalProb
  let chosen = rewards[rewards.length - 1]
  for (const r of rewards) {
    rand -= r.probability
    if (rand <= 0) { chosen = r; break }
  }

  if (chosen.type === 'COINS') {
    await db.user.update({
      where: { id: user.id },
      data: { walletBalance: { increment: chosen.value }, lastRewardClaim: now }
    })
  } else {
    await db.user.update({
      where: { id: user.id },
      data: { lastRewardClaim: now }
    })
  }

  await db.mysteryRewardLog.create({
    data: { userId: user.id, rewardId: chosen.id, value: chosen.value, type: chosen.type }
  }).catch(() => {})

  return NextResponse.json({
    success: true,
    reward: {
      id: chosen.id,
      name: chosen.name,
      type: chosen.type,
      value: chosen.value
    },
    newBalance: chosen.type === 'COINS' ? user.walletBalance + chosen.value : user.walletBalance,
    nextClaimAt: new Date(now.getTime() + 24 * 60 * 60 * 1000).toISOString()
  })
}
