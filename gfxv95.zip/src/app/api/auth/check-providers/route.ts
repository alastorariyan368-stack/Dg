import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET() {
  try {
    const s = await db.siteSettings.findFirst({
      select: {
        oauthEnabled: true,
        discordClientId: true,
        discordClientSecret: true,
        googleClientId: true,
        googleClientSecret: true,
      }
    })

    const oauthEnabled = s?.oauthEnabled !== false
    const discordEnabled = !!(oauthEnabled && s?.discordClientId?.trim() && s?.discordClientSecret?.trim())
    const googleEnabled = !!(oauthEnabled && s?.googleClientId?.trim() && s?.googleClientSecret?.trim())

    return NextResponse.json({ discordEnabled, googleEnabled }, {
      headers: { 'Cache-Control': 'public, max-age=30' },
    })
  } catch {
    return NextResponse.json({ discordEnabled: false, googleEnabled: false })
  }
}
