import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: Request) {
  try {
    const { email, otp } = await request.json()

    if (!email || !otp) {
      return NextResponse.json({ error: 'Email and OTP are required' }, { status: 400 })
    }

    const record = await db.emailOtpVerification.findFirst({
      where: { email: email.toLowerCase() },
      orderBy: { createdAt: 'desc' }
    })

    if (!record) {
      return NextResponse.json({ error: 'No verification request found. Please register again.' }, { status: 404 })
    }

    if (new Date() > record.expiresAt) {
      await db.emailOtpVerification.delete({ where: { id: record.id } })
      return NextResponse.json({ error: 'Verification code has expired. Please register again.' }, { status: 400 })
    }

    if (record.otp !== otp.trim()) {
      return NextResponse.json({ error: 'Invalid verification code. Please try again.' }, { status: 400 })
    }

    // OTP is valid — create the user
    let referrerId: string | undefined
    if (record.referralCode) {
      const referrer = await db.user.findFirst({ where: { referralCode: record.referralCode.trim() } })
      if (referrer) referrerId = referrer.id
    }

    const user = await db.user.create({
      data: {
        email: record.email,
        username: record.username,
        password: record.password,
        role: 'USER',
        emailVerified: new Date(),
        ...(referrerId ? { referredById: referrerId } : {})
      }
    })

    if (referrerId) {
      try {
        await db.user.update({ where: { id: referrerId }, data: { walletBalance: { increment: 5.0 }, referralEarnings: { increment: 5.0 } } })
        await db.user.update({ where: { id: user.id }, data: { walletBalance: { increment: 2.0 } } })
        await db.notification.create({
          data: { userId: referrerId, title: 'New Referral!', content: `${user.username} signed up with your referral code! You earned $5.00`, type: 'REFERRAL_BONUS' as any }
        })
      } catch {}
    }

    // Clean up OTP record
    await db.emailOtpVerification.delete({ where: { id: record.id } }).catch(() => {})

    return NextResponse.json({
      message: 'Email verified successfully! Account created.',
      user: { id: user.id, email: user.email, username: user.username, role: user.role }
    }, { status: 201 })
  } catch (error) {
    console.error('OTP verification error:', error)
    return NextResponse.json({ error: 'Verification failed. Please try again.' }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  // Resend OTP
  try {
    const { email } = await request.json()
    if (!email) return NextResponse.json({ error: 'Email required' }, { status: 400 })

    const record = await db.emailOtpVerification.findFirst({
      where: { email: email.toLowerCase() },
      orderBy: { createdAt: 'desc' }
    })

    if (!record) {
      return NextResponse.json({ error: 'No verification request found' }, { status: 404 })
    }

    const newOtp = String(Math.floor(100000 + Math.random() * 900000))
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000)

    await db.emailOtpVerification.update({
      where: { id: record.id },
      data: { otp: newOtp, expiresAt }
    })

    const { sendMail } = await import('@/lib/email')
    await sendMail({
      to: email.toLowerCase(),
      subject: 'GfxStore — New Verification Code',
      html: `<div style="font-family:sans-serif;background:#0a0a12;color:#fff;padding:32px;text-align:center;">
        <h2 style="color:#a78bfa;">New Verification Code</h2>
        <div style="font-size:48px;font-weight:900;letter-spacing:16px;color:#a78bfa;font-family:monospace;">${newOtp}</div>
        <p style="color:#64748b;">Expires in 10 minutes.</p>
      </div>`,
      text: `Your new GfxStore verification code is: ${newOtp}`,
    })

    return NextResponse.json({ message: 'New code sent' })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to resend code' }, { status: 500 })
  }
}
