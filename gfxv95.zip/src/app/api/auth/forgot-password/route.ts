import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import crypto from 'crypto'
import { sendMail, buildResetEmailHtml } from '@/lib/mailer'

export async function POST(req: NextRequest) {
  try {
    const { email } = await req.json()

    if (!email) {
      return NextResponse.json({ error: 'Email is required' }, { status: 400 })
    }

    const user = await db.user.findUnique({
      where: { email: email.toLowerCase().trim() },
      select: { id: true, email: true, username: true }
    })

    // Always return success to avoid email enumeration
    if (!user) {
      return NextResponse.json({ success: true })
    }

    const token = crypto.randomBytes(32).toString('hex')
    const expiresAt = new Date(Date.now() + 60 * 60 * 1000)

    await db.user.update({
      where: { email: user.email },
      data: {
        passwordResetToken: token,
        passwordResetTokenExpiry: expiresAt
      }
    })

    const replitDomain = process.env.REPLIT_DOMAINS?.split(',')[0]?.trim() ||
      process.env.REPLIT_DEV_DOMAIN?.trim()
    const appUrl =
      process.env.NEXT_PUBLIC_APP_URL ||
      (replitDomain ? `https://${replitDomain}` : null) ||
      process.env.NEXTAUTH_URL ||
      'http://localhost:5000'

    const resetLink = `${appUrl}/auth/reset-password?token=${token}`

    const html = buildResetEmailHtml({
      username: user.username || 'there',
      resetLink
    })

    const result = await sendMail({
      to: user.email,
      subject: 'GfxStore — Reset your password',
      html
    })

    if (!result.success) {
      console.error('[forgot-password] Failed to send email:', result.error)
      return NextResponse.json(
        { error: 'Failed to send email. Please try again later.' },
        { status: 500 }
      )
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Forgot password error:', error)
    return NextResponse.json({ error: 'Failed to process request' }, { status: 500 })
  }
}
