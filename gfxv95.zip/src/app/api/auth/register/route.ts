import { NextResponse, NextRequest } from 'next/server'
import { db } from '@/lib/db'
import bcrypt from 'bcryptjs'
import { sendMail } from '@/lib/email'
import { logActivity } from '@/lib/log-activity'

function generateOtp(): string {
  return String(Math.floor(100000 + Math.random() * 900000))
}

function otpEmailHtml(otp: string, username: string): string {
  return `<!doctype html><html><body style="font-family:Inter,Arial,sans-serif;background:#0a0a12;color:#fff;padding:0;margin:0;">
  <div style="max-width:480px;margin:0 auto;padding:32px 16px;">
    <div style="background:linear-gradient(135deg,#7c3aed,#06b6d4);padding:1px;border-radius:18px;">
      <div style="background:#0f0f1a;border-radius:17px;padding:28px;text-align:center;">
        <div style="font-size:14px;letter-spacing:2px;color:#a78bfa;text-transform:uppercase;margin-bottom:8px;">⚡ GfxStore</div>
        <h1 style="color:#fff;font-size:22px;margin:0 0 8px;">Verify your email</h1>
        <p style="color:#94a3b8;font-size:14px;margin:0 0 24px;">Hi <strong style="color:#fff;">${username}</strong>, use this 6-digit code to complete your registration:</p>
        <div style="background:linear-gradient(135deg,rgba(124,58,237,0.15),rgba(6,182,212,0.15));border:2px solid #7c3aed;border-radius:16px;padding:20px;margin:0 0 24px;">
          <div style="font-size:48px;font-weight:900;letter-spacing:16px;color:#a78bfa;font-family:monospace;">${otp}</div>
        </div>
        <p style="color:#64748b;font-size:13px;">This code expires in <strong style="color:#94a3b8;">10 minutes</strong>. Do not share it with anyone.</p>
        <p style="color:#64748b;font-size:11px;margin-top:20px;">— The GfxStore Team</p>
      </div>
    </div>
  </div>
</body></html>`
}

export async function POST(request: NextRequest) {
  try {
    const { email, password, username, referralCode } = await request.json()

    if (!email || !password || !username) {
      return NextResponse.json({ error: 'Email, password, and username are required' }, { status: 400 })
    }
    if (password.length < 6) {
      return NextResponse.json({ error: 'Password must be at least 6 characters' }, { status: 400 })
    }
    if (!email.includes('@')) {
      return NextResponse.json({ error: 'Please enter a valid email address' }, { status: 400 })
    }
    if (username.length < 3) {
      return NextResponse.json({ error: 'Username must be at least 3 characters' }, { status: 400 })
    }

    const existingUser = await db.user.findFirst({
      where: { OR: [{ email: email.toLowerCase() }, { username }] }
    })
    if (existingUser) {
      return NextResponse.json({ error: 'User with this email or username already exists' }, { status: 400 })
    }

    // Check if email verification is enabled
    const settings = await db.siteSettings.findFirst()
    const verificationEnabled = settings?.emailVerificationEnabled ?? false

    if (verificationEnabled) {
      const otp = generateOtp()
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000)
      const hashedPassword = await bcrypt.hash(password, 12)

      await db.emailOtpVerification.deleteMany({ where: { email: email.toLowerCase() } })
      await db.emailOtpVerification.create({
        data: {
          email: email.toLowerCase(),
          username,
          password: hashedPassword,
          otp,
          expiresAt,
          referralCode: referralCode || null,
        }
      })

      const mailResult = await sendMail({
        to: email.toLowerCase(),
        subject: 'GfxStore — Email Verification Code',
        html: otpEmailHtml(otp, username),
        text: `Your GfxStore verification code is: ${otp}\n\nThis code expires in 10 minutes.`,
      })

      if (!mailResult.ok) {
        await db.emailOtpVerification.deleteMany({ where: { email: email.toLowerCase() } })
        return NextResponse.json(
          { error: `Failed to send verification email: ${mailResult.error || 'Check Admin → Email settings'}` },
          { status: 500 }
        )
      }

      return NextResponse.json({
        requiresVerification: true,
        message: `Verification code sent to ${email}. Please check your inbox.`,
        email: email.toLowerCase(),
      })
    }

    // No verification — create account directly
    const hashedPassword = await bcrypt.hash(password, 12)
    let referrerId: string | undefined
    if (referralCode) {
      const referrer = await db.user.findFirst({ where: { referralCode: referralCode.trim() } })
      if (referrer) referrerId = referrer.id
    }

    const user = await db.user.create({
      data: {
        email: email.toLowerCase(),
        username,
        password: hashedPassword,
        role: 'USER',
        ...(referrerId ? { referredById: referrerId } : {})
      }
    })

    if (referrerId) {
      try {
        await db.user.update({ where: { id: referrerId }, data: { walletBalance: { increment: 5.0 }, referralEarnings: { increment: 5.0 } } })
        await db.user.update({ where: { id: user.id }, data: { walletBalance: { increment: 2.0 } } })
        await db.notification.create({
          data: { userId: referrerId, title: 'New Referral!', content: `${username} signed up with your referral code! You earned $5.00`, type: 'REFERRAL_BONUS' as any }
        })
      } catch (refError) { console.error('Referral bonus error:', refError) }
    }

    // Send welcome email (non-blocking)
    sendMail({
      to: user.email,
      subject: 'Welcome to GfxStore!',
      html: `<!doctype html><html><body style="font-family:Inter,Arial,sans-serif;background:#0a0a12;color:#fff;padding:32px;">
        <div style="max-width:480px;margin:0 auto;background:#0f0f1a;border-radius:18px;padding:28px;border:1px solid #ffffff15;">
          <h1 style="color:#a78bfa;">Welcome, ${username}! 🎉</h1>
          <p style="color:#94a3b8;">Your GfxStore account has been created successfully.</p>
          <p style="color:#94a3b8;"><strong>Email:</strong> ${user.email}</p>
          <p style="color:#94a3b8;"><strong>Username:</strong> ${user.username}</p>
          <p style="color:#64748b;margin-top:24px;">Start browsing, uploading, and connecting with creators!</p>
          <p style="color:#64748b;">— The GfxStore Team</p>
        </div></body></html>`,
      text: `Welcome to GfxStore, ${username}!\nEmail: ${user.email}\nUsername: ${user.username}`,
    }).catch(() => {})

    logActivity({
      userId: user.id,
      username: user.username,
      action: 'REGISTER',
      details: `New user registered: ${user.email}`,
      request,
      status: 201,
      path: '/api/auth/register',
      method: 'POST',
    }).catch(() => {})

    return NextResponse.json({
      message: 'User created successfully',
      user: { id: user.id, email: user.email, username: user.username, role: user.role }
    }, { status: 201 })
  } catch (error) {
    console.error('Registration error:', error instanceof Error ? error.message : error)
    return NextResponse.json({ error: 'Failed to create user. Please try again.' }, { status: 500 })
  }
}
