import NextAuth from 'next-auth'
import { getAuthOptions } from '@/lib/auth'
import type { NextRequest } from 'next/server'

// Dynamic per-request handler so OAuth credentials saved in the
// admin panel (Discord/Google client ID + secret) are picked up at runtime
// without needing a server restart.
async function handler(req: NextRequest, ctx: any) {
  const opts = await getAuthOptions()
  return (NextAuth(opts) as any)(req, ctx)
}

export { handler as GET, handler as POST }
