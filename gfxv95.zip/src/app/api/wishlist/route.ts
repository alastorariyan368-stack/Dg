import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { checkFeature } from '@/lib/feature-toggles'

export async function GET() {
  const blocked = await checkFeature('wishlist', 'Wishlist')
  if (blocked) return blocked
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const wishlist = await db.wishlist.findMany({
    where: { userId: session.user.id },
    include: {
      item: {
        select: { id: true, title: true, slug: true, logo: true, price: true, accessType: true, downloads: true, likes: true,
          author: { select: { username: true, avatar: true } },
          category: { select: { name: true } }
        }
      }
    },
    orderBy: { createdAt: 'desc' }
  })

  return NextResponse.json({ wishlist: wishlist.map(w => w.item) })
}

export async function POST(req: NextRequest) {
  const blocked = await checkFeature('wishlist', 'Wishlist')
  if (blocked) return blocked
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { itemId } = await req.json()
  if (!itemId) return NextResponse.json({ error: 'Item ID required' }, { status: 400 })

  const existing = await db.wishlist.findUnique({ where: { userId_itemId: { userId: session.user.id, itemId } } })
  if (existing) {
    await db.wishlist.delete({ where: { userId_itemId: { userId: session.user.id, itemId } } })
    return NextResponse.json({ wishlisted: false })
  }

  await db.wishlist.create({ data: { userId: session.user.id, itemId } })
  return NextResponse.json({ wishlisted: true })
}

export async function DELETE(req: NextRequest) {
  const blocked = await checkFeature('wishlist', 'Wishlist')
  if (blocked) return blocked
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { itemId } = await req.json()
  if (!itemId) return NextResponse.json({ error: 'Item ID required' }, { status: 400 })
  await db.wishlist.deleteMany({ where: { userId: session.user.id, itemId } })
  return NextResponse.json({ success: true })
}
