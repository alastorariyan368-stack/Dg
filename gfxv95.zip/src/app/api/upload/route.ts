import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { NextRequest, NextResponse } from 'next/server'
import { createWriteStream } from 'fs'
import { mkdir } from 'fs/promises'
import { join } from 'path'
import { existsSync } from 'fs'
import crypto from 'crypto'
import { pipeline } from 'stream/promises'
import { Readable } from 'stream'
import { checkFeature } from '@/lib/feature-toggles'
import { FileStorageService } from '@/lib/storage'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 300

const ALLOWED_IMAGES = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'ico', 'bmp', 'heic', 'heif', 'jfif', 'avif', 'tif', 'tiff']
const ALLOWED_DOCS = ['pdf', 'doc', 'docx', 'txt', 'md', 'json', 'csv', 'zip', 'rar', '7z', 'tar', 'gz', 'tgz']
const ALLOWED_VIDEOS = ['mp4', 'mov', 'avi', 'webm', 'mkv', 'flv', 'm4v', '3gp', '3g2', 'wmv', 'mpeg', 'mpg', 'ts']
const ALLOWED_AUDIO = ['mp3', 'wav', 'ogg', 'm4a', 'aac', 'flac', 'opus']
const ALLOWED_APPS = ['apk', 'aab', 'ipa', 'xapk', 'apks']
const ALLOWED_CODE = ['js', 'ts', 'jsx', 'tsx', 'java', 'kt', 'py', 'rb', 'go', 'rs', 'c', 'cpp', 'h', 'hpp', 'cs', 'php', 'html', 'css', 'scss', 'yaml', 'yml', 'toml', 'xml']

function detectExt(file: File): string {
  const fromName = file.name?.split('.').pop()?.toLowerCase().replace(/[^a-z0-9]/g, '') || ''
  if (fromName) return fromName
  const mime = (file.type || '').toLowerCase()
  if (mime.startsWith('image/')) return mime.split('/')[1]?.split(';')[0] || 'jpg'
  if (mime.startsWith('video/')) return mime.split('/')[1]?.split(';')[0] || 'mp4'
  if (mime.startsWith('audio/')) return mime.split('/')[1]?.split(';')[0] || 'mp3'
  if (mime === 'application/pdf') return 'pdf'
  if (mime === 'application/zip' || mime === 'application/x-zip-compressed') return 'zip'
  if (mime === 'application/vnd.android.package-archive') return 'apk'
  return 'bin'
}

export async function POST(request: NextRequest) {
  try {
    const blocked = await checkFeature('upload', 'Upload System')
    if (blocked) return blocked
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Please sign in to upload files.' }, { status: 401 })
    }

    let formData: FormData
    try {
      formData = await request.formData()
    } catch (e: any) {
      console.error('FormData parse error:', e?.message)
      return NextResponse.json({ error: 'Could not read uploaded file. Please try again.' }, { status: 400 })
    }

    const file = formData.get('file') as File | null
    const type = (formData.get('type') as string) || 'general'

    if (!file || typeof file === 'string') {
      return NextResponse.json({ error: 'No file provided' }, { status: 400 })
    }

    const minSize = 1024 // 1KB
    const maxSize = 10 * 1024 * 1024 * 1024 // 10GB
    if (file.size < minSize) return NextResponse.json({ error: 'File too small (min 1KB)' }, { status: 400 })
    if (file.size > maxSize) return NextResponse.json({ error: 'File too large (max 10GB)' }, { status: 400 })

    const ext = detectExt(file) || 'bin'
    const allAllowed = [...ALLOWED_IMAGES, ...ALLOWED_DOCS, ...ALLOWED_VIDEOS, ...ALLOWED_AUDIO, ...ALLOWED_APPS, ...ALLOWED_CODE]
    if (!allAllowed.includes(ext)) {
      return NextResponse.json({
        error: `Unsupported file type ".${ext}". Try image, video, audio, document, app or code file.`
      }, { status: 400 })
    }

    let subDir = 'general'
    if (type === 'avatar') subDir = 'avatars'
    else if (ALLOWED_VIDEOS.includes(ext)) subDir = 'videos'
    else if (ALLOWED_APPS.includes(ext)) subDir = 'apps'
    else if (ALLOWED_IMAGES.includes(ext)) subDir = 'images'
    else if (ALLOWED_AUDIO.includes(ext)) subDir = 'audio'
    else if (ALLOWED_CODE.includes(ext)) subDir = 'code'

    const uniqueName = `${crypto.randomUUID()}.${ext}`
    let url = ''

    const useS3 = !!(process.env.S3_BUCKET && process.env.S3_ACCESS_KEY && process.env.S3_SECRET_KEY)

    // Stream file to local disk to support large files (up to 5GB) without loading into memory
    const writeLocal = async () => {
      const uploadDir = join(process.cwd(), 'public', 'uploads', subDir)
      if (!existsSync(uploadDir)) await mkdir(uploadDir, { recursive: true })
      const filePath = join(uploadDir, uniqueName)
      const writeStream = createWriteStream(filePath)
      const nodeReadable = Readable.fromWeb(file.stream() as any)
      await pipeline(nodeReadable, writeStream)
      return `/uploads/${subDir}/${uniqueName}`
    }

    if (useS3) {
      try {
        const storage = new FileStorageService()
        const key = storage.generateFileKey(subDir, uniqueName, session.user.id)
        // For S3, use streaming via arrayBuffer only for files under 500MB to avoid OOM
        // Large files fall back to local storage
        if (file.size <= 500 * 1024 * 1024) {
          const bytes = await file.arrayBuffer()
          const contentType = file.type || 'application/octet-stream'
          url = await storage.uploadFile(key, Buffer.from(bytes), contentType)
        } else {
          url = await writeLocal()
        }
      } catch (s3Error) {
        console.warn('S3 upload failed, using local storage:', s3Error)
        url = await writeLocal()
      }
    } else {
      url = await writeLocal()
    }

    return NextResponse.json({ url, fileName: file.name, size: file.size, type: subDir })
  } catch (error: any) {
    console.error('Upload error:', error?.message || error)
    return NextResponse.json({ error: error?.message || 'Upload failed' }, { status: 500 })
  }
}
