import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'
import { checkFeature } from '@/lib/feature-toggles'

const ALLOWED_KINDS = new Set(['TEXT', 'IMAGE', 'VOICE', 'VIDEO', 'FILE', 'CALL'])

export async function POST(request: NextRequest) {
  try {
    const blocked = await checkFeature('chat', 'Chat System')
    if (blocked) return blocked
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const user = await db.user.findUnique({ where: { email: session.user.email } })
    if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })

    const body = await request.json().catch(() => ({} as any))
    const {
      receiverId, content = '', vpsOrderInfo,
      kind = 'TEXT', mediaUrl, mediaName, mimeType, durationSec, thumbnailUrl, callId,
    } = body || {}

    if (!receiverId) return NextResponse.json({ error: 'Receiver ID is required' }, { status: 400 })
    if (!ALLOWED_KINDS.has(kind)) return NextResponse.json({ error: 'Invalid kind' }, { status: 400 })

    const trimmed = String(content || '').trim().slice(0, 4000)
    if (kind === 'TEXT' && !trimmed) return NextResponse.json({ error: 'Empty message' }, { status: 400 })
    if (kind !== 'TEXT' && kind !== 'CALL' && !mediaUrl) {
      return NextResponse.json({ error: 'mediaUrl required for media messages' }, { status: 400 })
    }

    const receiver = await db.user.findUnique({ where: { id: receiverId } })
    if (!receiver) return NextResponse.json({ error: 'Receiver not found' }, { status: 404 })

    // Privacy check: receiver may have blocked or restricted DMs.
    // Friendship is no longer required — anyone can DM by default so the chat,
    // voice, photo and call features work without an extra friend-request step.
    if (user.id === receiverId) {
      return NextResponse.json({ error: "You can't message yourself" }, { status: 400 })
    }
    try {
      const blocked = await (db as any).userBlock?.findFirst?.({
        where: {
          OR: [
            { blockerId: receiverId, blockedId: user.id },
            { blockerId: user.id, blockedId: receiverId },
          ],
        },
      })
      if (blocked) {
        return NextResponse.json({ error: 'You cannot message this user.' }, { status: 403 })
      }
    } catch {}

    const message = await db.privateMessage.create({
      data: {
        senderId: user.id,
        receiverId,
        content: trimmed,
        kind,
        mediaUrl: mediaUrl || null,
        mediaName: mediaName ? String(mediaName).slice(0, 200) : null,
        mimeType: mimeType ? String(mimeType).slice(0, 100) : null,
        durationSec: typeof durationSec === 'number' ? Math.max(0, Math.floor(durationSec)) : null,
        thumbnailUrl: thumbnailUrl || null,
        callId: callId || null,
        vpsOrderInfo: vpsOrderInfo ? vpsOrderInfo : null,
      },
      include: {
        sender:   { select: { id: true, username: true, avatar: true } },
        receiver: { select: { id: true, username: true, avatar: true } },
      },
    })

    // Notification (skip for CALL system events to avoid spam)
    if (kind !== 'CALL') {
      const previewMap: Record<string, string> = {
        TEXT:  trimmed.slice(0, 80),
        IMAGE: '📷 Photo',
        VOICE: '🎙 Voice message',
        VIDEO: '🎬 Video',
        FILE:  '📎 File',
      }
      const preview = previewMap[kind] || trimmed.slice(0, 80)
      await db.notification.create({
        data: {
          userId: receiverId,
          title: 'New Message',
          content: `${user.username}: ${preview}`,
          type: 'NEW_MESSAGE',
        },
      })
      if ((global as any).sendNotification) {
        await (global as any).sendNotification(receiverId, {
          title: 'New Message',
          content: `${user.username}: ${preview}`,
          type: 'NEW_MESSAGE',
        })
      }
    }

    const msgio = (global as any).messagesIo
    if (msgio) {
      msgio.to(`user:${receiverId}`).emit('newPrivateMessage', message)
      msgio.to(`user:${user.id}`).emit('newPrivateMessage', message)
    }

    // Also notify via notification namespace
    const notifio = (global as any).io?.of?.('/notifications')
    if (notifio) {
      notifio.to(`user:${receiverId}`).emit('notification', {
        id: message.id,
        title: 'New Message',
        content: `${user.username}: ${message.content.slice(0, 50)}`,
        type: 'NEW_MESSAGE',
        createdAt: new Date(),
        isRead: false
      })
    }

    return NextResponse.json(message, { status: 201 })
  } catch (error) {
    console.error('Error sending message:', error)
    return NextResponse.json({ error: 'Failed to send message' }, { status: 500 })
  }
}
