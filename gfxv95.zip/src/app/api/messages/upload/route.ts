import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { mkdir, writeFile } from 'fs/promises'
import { existsSync } from 'fs'
import path from 'path'
import { randomBytes } from 'crypto'

export const dynamic = 'force-dynamic'
export const runtime = 'nodejs'

const MAX_BYTES = 50 * 1024 * 1024 // 50MB hard cap per file
const ALLOWED_PREFIXES = ['image/', 'audio/', 'video/']
const ALLOWED_EXACT = new Set([
  'application/pdf',
  'application/zip',
  'application/x-zip-compressed',
  'application/x-rar-compressed',
  'application/octet-stream',
  'text/plain',
])

function kindFor(mime: string): 'IMAGE' | 'VOICE' | 'VIDEO' | 'FILE' {
  if (mime.startsWith('image/')) return 'IMAGE'
  if (mime.startsWith('video/')) return 'VIDEO'
  if (mime.startsWith('audio/')) return 'VOICE'
  return 'FILE'
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const form = await req.formData()
    const file = form.get('file') as File | null
    if (!file) return NextResponse.json({ error: 'No file' }, { status: 400 })
    if (file.size > MAX_BYTES) return NextResponse.json({ error: 'File too large (max 50 MB)' }, { status: 400 })

    const mime = file.type || 'application/octet-stream'
    const okPrefix = ALLOWED_PREFIXES.some(p => mime.startsWith(p))
    if (!okPrefix && !ALLOWED_EXACT.has(mime)) {
      return NextResponse.json({ error: `File type not allowed: ${mime}` }, { status: 400 })
    }

    const ext = (file.name.split('.').pop() || 'bin').toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 8) || 'bin'
    const id = randomBytes(10).toString('hex')
    const fname = `${Date.now()}_${id}.${ext}`

    const dir = path.join(process.cwd(), 'public', 'uploads', 'chat')
    if (!existsSync(dir)) await mkdir(dir, { recursive: true })

    const buf = Buffer.from(await file.arrayBuffer())
    await writeFile(path.join(dir, fname), buf)

    const url = `/uploads/chat/${fname}`
    const kind = kindFor(mime)

    return NextResponse.json({
      url,
      mediaUrl: url,
      mediaName: file.name.slice(0, 200),
      mimeType: mime,
      size: file.size,
      kind,
    })
  } catch (e: any) {
    console.error('chat upload error', e)
    return NextResponse.json({ error: e?.message || 'Upload failed' }, { status: 500 })
  }
}
