import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'
import { checkFeature } from '@/lib/feature-toggles'

function previewFor(kind: string, content: string) {
  switch (kind) {
    case 'IMAGE': return '📷 Photo'
    case 'VOICE': return '🎙 Voice message'
    case 'VIDEO': return '🎬 Video'
    case 'FILE':  return '📎 File'
    case 'CALL':  return content || '📞 Call'
    default:      return content
  }
}

export async function GET(_request: NextRequest) {
  try {
    const blocked = await checkFeature('chat', 'Chat System')
    if (blocked) return blocked
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const me = await db.user.findUnique({ where: { email: session.user.email }, select: { id: true } })
    if (!me) return NextResponse.json({ error: 'User not found' }, { status: 404 })

    // Pull last 500 messages either side, then reduce by partner.
    const recent = await db.privateMessage.findMany({
      where: { OR: [{ senderId: me.id }, { receiverId: me.id }] },
      orderBy: { createdAt: 'desc' },
      take: 500,
      include: {
        sender:   { select: { id: true, username: true, avatar: true, isActive: true } },
        receiver: { select: { id: true, username: true, avatar: true, isActive: true } },
      },
    })

    const map = new Map<string, any>()
    for (const m of recent) {
      const partner = m.senderId === me.id ? m.receiver : m.sender
      const key = partner.id
      if (!map.has(key)) {
        map.set(key, {
          userId: partner.id,
          username: partner.username,
          avatar: partner.avatar,
          isActive: (partner as any).isActive ?? false,
          lastMessage: previewFor(m.kind, m.content),
          lastMessageKind: m.kind,
          lastMessageTime: m.createdAt,
          lastFromMe: m.senderId === me.id,
          unreadCount: 0,
        })
      }
      const conv = map.get(key)
      if (!m.isRead && m.receiverId === me.id) conv.unreadCount++
    }

    const conversations = Array.from(map.values()).sort(
      (a, b) => new Date(b.lastMessageTime).getTime() - new Date(a.lastMessageTime).getTime()
    )

    return NextResponse.json({ conversations, count: conversations.length })
  } catch (error) {
    console.error('Error fetching conversations:', error)
    return NextResponse.json({ error: 'Failed to fetch conversations' }, { status: 500 })
  }
}
