import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { maybeAwardBadges } from '@/lib/badge-awarder'

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { id } = await params
  const { status } = await req.json()

  const order = await db.order.findUnique({ where: { id } })
  if (!order) return NextResponse.json({ error: 'Order not found' }, { status: 404 })

  // Only seller can update order status (or buyer can cancel)
  if (order.sellerId !== session.user.id && order.buyerId !== session.user.id) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  const allowedTransitions: Record<string, string[]> = {
    PENDING: ['IN_PROGRESS', 'CANCELLED'],
    IN_PROGRESS: ['DELIVERED'],
    DELIVERED: [],
    CANCELLED: [],
    REFUNDED: []
  }

  if (!allowedTransitions[order.status]?.includes(status)) {
    return NextResponse.json({ error: `Cannot transition from ${order.status} to ${status}` }, { status: 400 })
  }

  const updated = await db.$transaction(async (tx) => {
    const upd = await tx.order.update({
      where: { id },
      data: {
        status,
        deliveredAt: status === 'DELIVERED' ? new Date() : undefined
      }
    })

    if (status === 'DELIVERED') {
      // Credit seller wallet (95% after 5% platform fee)
      const sellerEarning = order.amount * 0.95
      const seller = await tx.user.update({
        where: { id: order.sellerId },
        data: {
          walletBalance: { increment: sellerEarning },
          totalSales: { increment: 1 }
        }
      })

      // Auto-update seller level
      let newLevel = 1
      if (seller.totalSales >= 100) newLevel = 5
      else if (seller.totalSales >= 50) newLevel = 4
      else if (seller.totalSales >= 20) newLevel = 3
      else if (seller.totalSales >= 5) newLevel = 2

      if (newLevel !== seller.sellerLevel) {
        await tx.user.update({ where: { id: order.sellerId }, data: { sellerLevel: newLevel } })
        // Notify seller of level up
        await tx.notification.create({
          data: {
            userId: order.sellerId,
            type: 'SELLER_VERIFIED' as any,
            title: `You reached Seller Level ${newLevel}! 🎉`,
            content: `Congratulations! You've leveled up to Level ${newLevel}. Keep growing!`
          }
        })
      }

      // Notify seller of earnings
      await tx.notification.create({
        data: {
          userId: order.sellerId,
          type: 'TRANSACTION_APPROVED' as any,
          title: 'Order delivered — earnings credited',
          content: `$${sellerEarning.toFixed(2)} has been credited to your wallet`
        }
      })
    }

    // Notify the buyer
    const notifType = status === 'IN_PROGRESS' ? 'ORDER_ACCEPTED' : status === 'DELIVERED' ? 'ORDER_DELIVERED' : 'ORDER_CANCELLED'
    await tx.notification.create({
      data: {
        userId: order.buyerId,
        type: notifType as any,
        title: `Order ${status.toLowerCase().replace(/_/g, ' ')}`,
        content: `Your order status has been updated to ${status}`
      }
    })

    return upd
  })

  if (status === 'DELIVERED') {
    // Buyer and seller completed an order milestone.
    await maybeAwardBadges(order.buyerId)
    await maybeAwardBadges(order.sellerId)
  }

  return NextResponse.json({ order: updated })
}

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { id } = await params
  const order = await db.order.findUnique({
    where: { id },
    include: {
      item: { select: { id: true, title: true, slug: true, logo: true, price: true, description: true } },
      buyer: { select: { id: true, username: true, avatar: true } },
      seller: { select: { id: true, username: true, avatar: true, isVerified: true } },
      coupon: { select: { code: true, discountValue: true, discountType: true } }
    }
  })
  if (!order) return NextResponse.json({ error: 'Order not found' }, { status: 404 })
  if (order.buyerId !== session.user.id && order.sellerId !== session.user.id) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  return NextResponse.json({ order })
}
