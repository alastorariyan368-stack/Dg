import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

function randomString(len: number) {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789'
  return Array.from({ length: len }, () => chars[Math.floor(Math.random() * chars.length)]).join('')
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)

    // Get active domains
    const domains = await db.tempMailDomain.findMany({ where: { isActive: true } })
    if (domains.length === 0) {
      return NextResponse.json({ error: 'No email domains configured. Ask admin to add domains.' }, { status: 503 })
    }

    // Pick random domain
    const domain = domains[Math.floor(Math.random() * domains.length)]

    // Generate unique address
    let address = ''
    let attempts = 0
    do {
      address = `${randomString(8)}@${domain.domain}`
      attempts++
      if (attempts > 10) return NextResponse.json({ error: 'Could not generate unique address' }, { status: 500 })
    } while (await db.tempMailInbox.findUnique({ where: { address } }))

    const expiresAt = new Date(Date.now() + 60 * 60 * 1000) // 1 hour

    const inbox = await db.tempMailInbox.create({
      data: {
        address,
        domain: domain.domain,
        expiresAt,
        userId: session?.user?.id ?? null,
      },
    })

    return NextResponse.json({
      id: inbox.id,
      address: inbox.address,
      token: inbox.token,
      expiresAt: inbox.expiresAt,
      createdAt: inbox.createdAt,
    })
  } catch (err: any) {
    console.error('[tempmail/generate]', err)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
