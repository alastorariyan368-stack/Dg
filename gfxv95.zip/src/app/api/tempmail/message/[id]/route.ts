import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const token = req.nextUrl.searchParams.get('token')
    const msg = await db.tempMailMessage.findUnique({
      where: { id },
      include: { inbox: true },
    })
    if (!msg) return NextResponse.json({ error: 'Message not found' }, { status: 404 })
    if (token && msg.inbox.token !== token) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

    // Mark as read
    await db.tempMailMessage.update({ where: { id }, data: { isRead: true } })

    return NextResponse.json(msg)
  } catch (err: any) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const token = req.nextUrl.searchParams.get('token')
    const msg = await db.tempMailMessage.findUnique({
      where: { id },
      include: { inbox: { select: { token: true } } },
    })
    if (!msg) return NextResponse.json({ error: 'Not found' }, { status: 404 })
    if (token && msg.inbox.token !== token) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    await db.tempMailMessage.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (err: any) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
