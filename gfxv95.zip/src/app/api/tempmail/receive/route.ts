import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Webhook endpoint — called by mail server (e.g. Postfix, Mailgun, SendGrid inbound)
// POST /api/tempmail/receive
// Body: { to, from, fromName?, subject?, text?, html?, secret }
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { to, from, fromName, subject, text, html, secret } = body

    // Simple shared secret check to prevent spam
    const expectedSecret = process.env.TEMPMAIL_WEBHOOK_SECRET || 'gfx-tempmail-secret'
    if (secret !== expectedSecret) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    if (!to || !from) {
      return NextResponse.json({ error: 'Missing to/from' }, { status: 400 })
    }

    const inbox = await db.tempMailInbox.findUnique({ where: { address: to.toLowerCase() } })
    if (!inbox) return NextResponse.json({ error: 'Inbox not found', to }, { status: 404 })

    if (inbox.expiresAt < new Date()) {
      return NextResponse.json({ error: 'Inbox expired' }, { status: 410 })
    }

    const msg = await db.tempMailMessage.create({
      data: {
        inboxId: inbox.id,
        fromAddress: from.toLowerCase(),
        fromName: fromName || null,
        subject: subject || '(no subject)',
        bodyText: text || '',
        bodyHtml: html || '',
      },
    })

    // Send real-time notification to the user who owns this inbox
    if (inbox.userId) {
      try {
        await db.notification.create({
          data: {
            userId: inbox.userId,
            title: 'New Email Received',
            content: `From: ${fromName || from} — ${subject || '(no subject)'}`,
            type: 'SYSTEM_ANNOUNCEMENT',
          },
        })

        // Emit real-time socket notification if available
        if ((global as any).sendNotification) {
          (global as any).sendNotification(inbox.userId, {
            title: 'New Temp Mail',
            content: `From: ${fromName || from} — ${subject || '(no subject)'}`,
            type: 'SYSTEM_ANNOUNCEMENT',
          })
        }
      } catch (notifErr) {
        console.warn('[tempmail/receive] Could not create notification:', notifErr)
      }
    }

    return NextResponse.json({ success: true, messageId: msg.id })
  } catch (err: any) {
    console.error('[tempmail/receive]', err)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
