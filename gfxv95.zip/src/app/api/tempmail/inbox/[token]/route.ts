import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest, { params }: { params: Promise<{ token: string }> }) {
  try {
    const { token } = await params
    const inbox = await db.tempMailInbox.findUnique({
      where: { token },
      include: {
        messages: {
          orderBy: { receivedAt: 'desc' },
          select: {
            id: true,
            fromAddress: true,
            fromName: true,
            subject: true,
            isRead: true,
            receivedAt: true,
          },
        },
      },
    })

    if (!inbox) return NextResponse.json({ error: 'Inbox not found' }, { status: 404 })

    const now = new Date()
    const expired = inbox.expiresAt < now

    return NextResponse.json({
      id: inbox.id,
      address: inbox.address,
      token: inbox.token,
      expiresAt: inbox.expiresAt,
      expired,
      messageCount: inbox.messages.length,
      unreadCount: inbox.messages.filter(m => !m.isRead).length,
      messages: inbox.messages,
    })
  } catch (err: any) {
    console.error('[tempmail/inbox]', err)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ token: string }> }) {
  try {
    const { token } = await params
    const inbox = await db.tempMailInbox.findUnique({ where: { token } })
    if (!inbox) return NextResponse.json({ error: 'Not found' }, { status: 404 })
    await db.tempMailInbox.delete({ where: { id: inbox.id } })
    return NextResponse.json({ success: true })
  } catch (err: any) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
