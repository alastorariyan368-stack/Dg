import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { checkFeature } from '@/lib/feature-toggles'

export async function GET(req: NextRequest) {
  const blocked = await checkFeature('custom_orders', 'Custom Orders')
  if (blocked) return blocked
  const { searchParams } = new URL(req.url)
  const my = searchParams.get('my')
  const session = await getServerSession(authOptions)

  if (my === 'true') {
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    const orders = await db.customOrder.findMany({
      where: { buyerId: session.user.id },
      include: {
        bids: { include: { seller: { select: { id: true, username: true, avatar: true, isVerified: true, sellerLevel: true, totalSales: true } } } },
        buyer: { select: { id: true, username: true, avatar: true } }
      },
      orderBy: { createdAt: 'desc' }
    })
    return NextResponse.json({ orders })
  }

  const orders = await db.customOrder.findMany({
    where: { status: 'OPEN' },
    include: {
      buyer: { select: { id: true, username: true, avatar: true } },
      bids: { include: { seller: { select: { id: true, username: true, avatar: true, isVerified: true, sellerLevel: true, totalSales: true } } } }
    },
    orderBy: { createdAt: 'desc' },
    take: 50
  })

  return NextResponse.json({ orders })
}

export async function POST(req: NextRequest) {
  const blocked = await checkFeature('custom_orders', 'Custom Orders')
  if (blocked) return blocked
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { title, description, budget, deadline, category } = await req.json()
  if (!title || !description) return NextResponse.json({ error: 'Title and description required' }, { status: 400 })

  const order = await db.customOrder.create({
    data: { buyerId: session.user.id, title, description, budget: budget ? parseFloat(budget) : null, deadline, category }
  })

  return NextResponse.json({ order })
}
