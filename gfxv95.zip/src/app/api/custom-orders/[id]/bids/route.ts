import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { id } = await params
  const { price, deliveryDays, message } = await req.json()
  if (!price || !deliveryDays || !message) return NextResponse.json({ error: 'All fields required' }, { status: 400 })

  const customOrder = await db.customOrder.findUnique({ where: { id } })
  if (!customOrder) return NextResponse.json({ error: 'Order not found' }, { status: 404 })
  if (customOrder.buyerId === session.user.id) return NextResponse.json({ error: 'Cannot bid on your own order' }, { status: 400 })
  if (customOrder.status !== 'OPEN') return NextResponse.json({ error: 'Order is not open for bids' }, { status: 400 })

  const existing = await db.customOrderBid.findUnique({
    where: { customOrderId_sellerId: { customOrderId: id, sellerId: session.user.id } }
  })
  if (existing) return NextResponse.json({ error: 'You already bid on this order' }, { status: 400 })

  const bid = await db.customOrderBid.create({
    data: { customOrderId: id, sellerId: session.user.id, price, deliveryDays, message }
  })

  // Notify buyer
  await db.notification.create({
    data: {
      userId: customOrder.buyerId,
      type: 'CUSTOM_ORDER_BID' as any,
      title: 'New bid on your request',
      content: `Someone placed a bid on your custom order: ${customOrder.title}`
    }
  })

  return NextResponse.json({ bid })
}

// Select a winning bid
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { id } = await params
  const { bidId } = await req.json()

  const customOrder = await db.customOrder.findUnique({ where: { id }, include: { bids: true } })
  if (!customOrder) return NextResponse.json({ error: 'Order not found' }, { status: 404 })
  if (customOrder.buyerId !== session.user.id) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const bid = customOrder.bids.find(b => b.id === bidId)
  if (!bid) return NextResponse.json({ error: 'Bid not found' }, { status: 404 })

  await db.customOrder.update({ where: { id }, data: { selectedBidId: bidId, status: 'IN_PROGRESS' } })

  // Notify winning seller
  await db.notification.create({
    data: {
      userId: bid.sellerId,
      type: 'CUSTOM_ORDER_SELECTED' as any,
      title: 'Your bid was selected!',
      content: `Your bid on "${customOrder.title}" was accepted. Get started!`
    }
  })

  return NextResponse.json({ success: true })
}
