import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

async function getMe() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.email) return null
  return db.user.findUnique({ where: { email: session.user.email }, select: { id: true, username: true, avatar: true } })
}

// Create a new call session (1:1 or group). Caller informs the system; signaling happens over sockets.
export async function POST(req: NextRequest) {
  const me = await getMe()
  if (!me) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { receiverId, groupId, type = 'AUDIO' } = await req.json().catch(() => ({}))
  if (!['AUDIO', 'VIDEO'].includes(type)) return NextResponse.json({ error: 'type must be AUDIO or VIDEO' }, { status: 400 })
  if (!receiverId && !groupId) return NextResponse.json({ error: 'receiverId or groupId required' }, { status: 400 })

  // Friendship requirement removed — anyone can call (block list still respected via DMs).
  // This matches the messaging behaviour and prevents the "can't reach friend" complaint.

  // Validate group membership
  if (groupId) {
    const m = await db.groupMember.findUnique({ where: { groupId_userId: { groupId, userId: me.id } } }).catch(() => null)
    if (!m) return NextResponse.json({ error: 'Not a member of this group' }, { status: 403 })
  }

  const call = await db.callSession.create({
    data: { initiatorId: me.id, receiverId: receiverId || null, groupId: groupId || null, type, status: 'RINGING' },
  })

  // 🔔 Ring the receiver (or every group member) over socket so their browser shows the incoming-call UI.
  try {
      const messagesIo = (global as any).messagesIo || (global as any).io?.of?.('/messages') || (global as any).io
      const notificationsIo = (global as any).io?.of?.('/notifications') || (global as any).io
      const payload = {
        callId: call.id,
        type,
        groupId: groupId || null,
        from: { id: me.id, username: me.username, avatar: me.avatar || null },
      }

      if (receiverId && !groupId) {
        messagesIo?.to(`user:${receiverId}`).emit('call:incoming', payload)
        notificationsIo?.to(`user:${receiverId}`).emit('call:incoming', payload)
      } else if (groupId) {
        const members = await db.groupMember.findMany({ where: { groupId }, select: { userId: true } })
        for (const m of members) {
          if (m.userId !== me.id) {
            messagesIo?.to(`user:${m.userId}`).emit('call:incoming', payload)
            notificationsIo?.to(`user:${m.userId}`).emit('call:incoming', payload)
          }
        }
      }
    } catch (e) { console.error('call ringing emit failed:', e) }

  // Also create a Notification record so the receiver sees a pending alert if they reload.
  try {
    if (receiverId && !groupId) {
      await db.notification.create({
        data: {
          userId: receiverId,
          title: type === 'VIDEO' ? '🎥 Incoming video call' : '📞 Incoming call',
          content: `${me.username} is calling you…`,
          type: 'NEW_MESSAGE',
        },
      })
    }
  } catch {}

  return NextResponse.json({ call })
}

// Update call status (accept / reject / end / cancel). Body: { status, durationSec? }
export async function PATCH(req: NextRequest) {
  const me = await getMe()
  if (!me) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { callId, status, durationSec } = await req.json().catch(() => ({}))
  if (!callId || !status) return NextResponse.json({ error: 'callId and status required' }, { status: 400 })
  if (!['ACCEPTED', 'REJECTED', 'ENDED', 'CANCELLED', 'MISSED'].includes(status)) {
    return NextResponse.json({ error: 'invalid status' }, { status: 400 })
  }

  const call = await db.callSession.findUnique({ where: { id: callId } })
  if (!call) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  // Authorization: initiator, receiver, or group member can update
  let allowed = call.initiatorId === me.id || call.receiverId === me.id
  if (!allowed && call.groupId) {
    const m = await db.groupMember.findUnique({ where: { groupId_userId: { groupId: call.groupId, userId: me.id } } }).catch(() => null)
    allowed = !!m
  }
  if (!allowed) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const data: any = { status }
  if (status === 'ACCEPTED') data.acceptedAt = new Date()
  if (['ENDED', 'REJECTED', 'CANCELLED', 'MISSED'].includes(status)) {
    data.endedAt = new Date()
    if (typeof durationSec === 'number') data.durationSec = Math.max(0, Math.floor(durationSec))
  }

  const updated = await db.callSession.update({ where: { id: callId }, data })

  // Log a CALL message into the conversation history
  if (['ENDED', 'REJECTED', 'CANCELLED', 'MISSED'].includes(status)) {
    const labelMap: Record<string, string> = {
      ENDED: updated.type === 'VIDEO' ? '🎥 Video call' : '📞 Voice call',
      MISSED: '📞 Missed call',
      REJECTED: '📞 Call declined',
      CANCELLED: '📞 Call cancelled',
    }
    const dur = updated.durationSec ? ` · ${Math.floor(updated.durationSec / 60)}:${String(updated.durationSec % 60).padStart(2, '0')}` : ''
    const text = (labelMap[status] || '📞 Call') + dur

    if (call.receiverId && !call.groupId) {
      await db.privateMessage.create({
        data: {
          senderId: call.initiatorId,
          receiverId: call.receiverId,
          content: text,
          kind: 'CALL',
          callId: call.id,
        },
      }).catch(() => {})
    } else if (call.groupId) {
      await db.groupMessage.create({
        data: { groupId: call.groupId, senderId: call.initiatorId, content: text, kind: 'CALL', callId: call.id },
      }).catch(() => {})
    }
  }

  return NextResponse.json({ call: updated })
}
