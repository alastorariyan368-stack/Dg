import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { id } = await params

    const post = await db.communityPost.findUnique({ where: { id }, select: { id: true } })
    if (!post) {
      return NextResponse.json({ error: 'Post not found' }, { status: 404 })
    }

    const existing = await db.communityPostLike.findUnique({
      where: { postId_userId: { postId: id, userId: session.user.id } },
    })

    if (existing) {
      await db.communityPostLike.delete({ where: { id: existing.id } })
      return NextResponse.json({ liked: false })
    }

    await db.communityPostLike.create({
      data: { postId: id, userId: session.user.id },
    })

    return NextResponse.json({ liked: true })
  } catch (error: any) {
    console.error('like toggle error:', error)
    return NextResponse.json({ error: error.message || 'Failed to toggle like' }, { status: 500 })
  }
}
