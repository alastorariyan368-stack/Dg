import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const page = Math.max(1, parseInt(searchParams.get('page') || '1'))
    const limit = Math.min(50, Math.max(1, parseInt(searchParams.get('limit') || '20')))
    const userId = searchParams.get('userId')
    const skip = (page - 1) * limit

    const where = userId ? { userId } : {}

    const [posts, total] = await Promise.all([
      db.communityPost.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
        include: {
          user: { select: { id: true, username: true, avatar: true, role: true } },
          _count: { select: { likes: true, comments: true, shares: true } },
        },
      }),
      db.communityPost.count({ where }),
    ])

    let userLikes: string[] = []
    const session = await getServerSession(authOptions)
    if (session?.user?.id) {
      const likes = await db.communityPostLike.findMany({
        where: {
          userId: session.user.id,
          postId: { in: posts.map(p => p.id) },
        },
        select: { postId: true },
      })
      userLikes = likes.map(l => l.postId)
    }

    const data = posts.map(p => ({
      ...p,
      images: (p.images as string[]) || [],
      tags: (p.tags as string[]) || [],
      isLiked: userLikes.includes(p.id),
    }))

    return NextResponse.json({
      posts: data,
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
    })
  } catch (error: any) {
    console.error('community posts error:', error)
    return NextResponse.json({ error: error.message || 'Failed to fetch posts' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { content, images, tags } = body

    if (!content || typeof content !== 'string' || !content.trim()) {
      return NextResponse.json({ error: 'Content is required' }, { status: 400 })
    }

    if (content.length > 5000) {
      return NextResponse.json({ error: 'Content too long (max 5000 chars)' }, { status: 400 })
    }

    const post = await db.communityPost.create({
      data: {
        userId: session.user.id,
        content: content.trim(),
        images: images || [],
        tags: tags || [],
      },
      include: {
        user: { select: { id: true, username: true, avatar: true, role: true } },
        _count: { select: { likes: true, comments: true, shares: true } },
      },
    })

    return NextResponse.json({ ...post, images: (post.images as string[]) || [], tags: (post.tags as string[]) || [], isLiked: false }, { status: 201 })
  } catch (error: any) {
    console.error('create post error:', error)
    return NextResponse.json({ error: error.message || 'Failed to create post' }, { status: 500 })
  }
}
