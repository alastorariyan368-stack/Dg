import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

const LOGO_SOURCES = [
  (name: string) => `https://img.logo.dev/${encodeURIComponent(name)}?token=`,
  (name: string) => `https://raw.githubusercontent.com/tv-logo/tv-logos/main/country/sa/${encodeURIComponent(name.toLowerCase().replace(/\s+/g, '-'))}.png`,
  (name: string) => `https://raw.githubusercontent.com/benmoose/tv-logos/main/logos/${encodeURIComponent(name.toLowerCase().replace(/\s+/g, '-'))}.png`,
  (name: string) => `https://cdn.jsdelivr.net/gh/benmoose/tv-logos@main/logos/${encodeURIComponent(name.toLowerCase().replace(/\s+/g, '-'))}.png`,
]

export async function POST() {
  try {
    const channels = await db.tVChannel.findMany({
      where: { logo: null, tvgLogo: null },
      take: 50,
    })

    let updated = 0
    for (const ch of channels) {
      for (const source of LOGO_SOURCES) {
        const url = source(ch.name)
        try {
          const res = await fetch(url, { method: 'HEAD', signal: AbortSignal.timeout(5000) })
          if (res.ok) {
            await db.tVChannel.update({ where: { id: ch.id }, data: { logo: url } })
            updated++
            break
          }
        } catch {}
      }
    }

    return NextResponse.json({ updated, total: channels.length })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
