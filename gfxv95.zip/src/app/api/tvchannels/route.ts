import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const channels = await db.tVChannel.findMany({
      where: { isActive: true },
      orderBy: [{ groupTitle: 'asc' }, { sortOrder: 'asc' }],
    })
    return NextResponse.json({ channels })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
