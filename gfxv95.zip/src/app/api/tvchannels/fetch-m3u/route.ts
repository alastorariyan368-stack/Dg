import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function POST() {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !['ADMIN', 'SUPER_ADMIN'].includes(session.user?.role as string)) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const m3uUrl = 'https://raw.githubusercontent.com/olkite/olkitetv/refs/heads/main/olkitetv.m3u'
    const res = await fetch(m3uUrl, { signal: AbortSignal.timeout(30000) })
    if (!res.ok) return NextResponse.json({ error: 'Failed to fetch M3U' }, { status: 502 })
    const text = await res.text()

    const lines = text.split('\n')
    let imported = 0
    let current: any = {}

    for (const line of lines) {
      const trimmed = line.trim()
      if (trimmed.startsWith('#EXTINF:')) {
        const match = trimmed.match(/tvg-id="([^"]*)".*tvg-name="([^"]*)".*tvg-logo="([^"]*)".*tvg-country="([^"]*)".*group-title="([^"]*)"/)
        current = {
          tvgId: match?.[1] || '',
          tvgName: match?.[2] || '',
          tvgLogo: match?.[3] || '',
          tvgCountry: match?.[4] || '',
          groupTitle: match?.[5] || 'General',
        }
        const nameMatch = trimmed.match(/,([^,]+)$/)
        if (nameMatch) current.name = nameMatch[1].trim()
      } else if (trimmed.startsWith('http') && current.name) {
        current.url = trimmed
        const existing = await db.tVChannel.findFirst({ where: { url: current.url } })
        if (!existing) {
          await db.tVChannel.create({
            data: {
              name: current.name,
              url: current.url,
              logo: current.tvgLogo || null,
              groupTitle: current.groupTitle || 'General',
              tvgId: current.tvgId || null,
              tvgName: current.tvgName || null,
              tvgLogo: current.tvgLogo || null,
              tvgCountry: current.tvgCountry || null,
              isActive: true,
            },
          })
          imported++
        }
        current = {}
      }
    }

    return NextResponse.json({ imported, total: await db.tVChannel.count() })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
