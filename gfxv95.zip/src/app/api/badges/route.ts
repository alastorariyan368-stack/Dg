import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { parseBadgeIds } from '@/lib/badge-utils'

export async function GET() {
  try {
    const session = await getServerSession(authOptions)

    const allBadges = await db.badge.findMany({
      where: { isActive: true },
      select: { id: true, name: true, description: true, icon: true, color: true, criteria: true, isAutomatic: true }
    })

    if (!session?.user?.id) {
      return NextResponse.json({ badges: allBadges, userBadgeIds: [] })
    }

    const user = await db.user.findUnique({
      where: { id: session.user.id },
      select: {
        badges: true,
        userBadges: { select: { badgeId: true } }
      }
    })

    const jsonBadgeIds = parseBadgeIds(user?.badges)
    const tableBadgeIds = user?.userBadges?.map(ub => ub.badgeId) || []
    const allUserBadgeIds = [...new Set([...jsonBadgeIds, ...tableBadgeIds])]

    return NextResponse.json({ badges: allBadges, userBadgeIds: allUserBadgeIds })
  } catch {
    return NextResponse.json({ badges: [], userBadgeIds: [] })
  }
}
