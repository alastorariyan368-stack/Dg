import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id)  return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { badgeId } = await req.json()
  if (!badgeId) return NextResponse.json({ error: 'Badge ID required' }, { status: 400 })

  // Check if badge exists
  const badge = await (db as any).badge.findUnique({
    where: { id: badgeId }
  })
  if (!badge) return NextResponse.json({ error: 'Badge not found' }, { status: 404 })

  // Check if user already has this badge
  const existing = await (db as any).userBadge?.findUnique?.({
    where: { userId_badgeId: { userId: session.user.id, badgeId } }
  }).catch(() => null)

  if (existing) return NextResponse.json({ error: 'Badge already claimed' }, { status: 400 })

  // Claim the badge
  try {
    const userBadge = await (db as any).userBadge?.create?.({
      data: {
        userId: session.user.id,
        badgeId,
        isEquipped: true
      }
    })

    return NextResponse.json({ success: true, userBadge })
  } catch (error) {
    console.error('Badge claim error:', error)
    return NextResponse.json({ error: 'Failed to claim badge' }, { status: 500 })
  }
}

