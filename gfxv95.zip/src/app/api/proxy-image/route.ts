import { NextRequest, NextResponse } from 'next/server'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const url = searchParams.get('url')
    if (!url) return NextResponse.json({ error: 'Missing url' }, { status: 400 })

    // Only allow YouTube thumbnail URLs for safety
    const decoded = decodeURIComponent(url)
    if (!decoded.includes('img.youtube.com') && !decoded.includes('i.ytimg.com')) {
      return NextResponse.json({ error: 'Only YouTube image URLs are allowed' }, { status: 403 })
    }

    const res = await fetch(decoded, {
      headers: { 'User-Agent': 'Mozilla/5.0 (compatible; GFXStore/1.0)' },
    })
    if (!res.ok) return NextResponse.json({ error: 'Failed to fetch image' }, { status: res.status })

    const buffer = await res.arrayBuffer()
    const contentType = res.headers.get('content-type') || 'image/jpeg'

    return new NextResponse(buffer, {
      headers: {
        'Content-Type': contentType,
        'Content-Disposition': 'attachment',
        'Cache-Control': 'public, max-age=3600',
      },
    })
  } catch (err: any) {
    return NextResponse.json({ error: err?.message || 'Internal server error' }, { status: 500 })
  }
}
