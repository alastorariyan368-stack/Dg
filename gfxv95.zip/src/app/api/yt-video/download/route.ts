import { NextRequest, NextResponse } from 'next/server'
import ytdl from '@distube/ytdl-core'
import { getAgent } from '@/lib/yt-video/config'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const videoUrl = url.searchParams.get('url')
    const format = url.searchParams.get('format') || 'mp4'
    const quality = url.searchParams.get('quality') || 'medium'

    if (!videoUrl) {
      return NextResponse.json({ error: 'Missing video URL' }, { status: 400 })
    }

    const videoIdMatch = videoUrl.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/)
    const idDirectMatch = videoUrl.match(/^([a-zA-Z0-9_-]{11})$/)
    const videoId = videoIdMatch?.[1] || idDirectMatch?.[1]

    if (!videoId) {
      return NextResponse.json({ error: 'Invalid YouTube URL' }, { status: 400 })
    }

    const fullUrl = `https://www.youtube.com/watch?v=${videoId}`
    const info = await ytdl.getInfo(fullUrl, { agent: getAgent() })
    const title = info.videoDetails.title.replace(/[^\w\s-]/g, '').trim()

    if (format === 'mp3') {
      const audioStream = ytdl(fullUrl, {
        quality: 'highestaudio',
        filter: 'audioonly',
        agent: getAgent(),
      })

      const headers = new Headers({
        'Content-Type': 'audio/mpeg',
        'Content-Disposition': `attachment; filename="${title || videoId}.mp3"`,
        'Accept-Ranges': 'bytes',
      })

      return new NextResponse(audioStream as any, { headers })
    }

    const options: any = { filter: 'audioandvideo', agent: getAgent() }

    if (quality === 'lowest') {
      options.quality = 'lowest'
    } else if (quality === 'highest') {
      options.quality = 'highest'
    } else {
      const itagMap: Record<string, number> = {
        '144p': 160, '240p': 133, '360p': 18, '480p': 135,
        '720p': 22, '720p60': 298, '1080p': 137, '1080p60': 299,
      }
      if (itagMap[quality]) {
        options.quality = itagMap[quality]
      }
    }

    const videoStream = ytdl(fullUrl, options)

    const formatLabel = quality === 'highest' ? '1080p' : quality === 'lowest' ? '144p' : quality

    const headers = new Headers({
      'Content-Type': 'video/mp4',
      'Content-Disposition': `attachment; filename="${title || videoId}-${formatLabel}.mp4"`,
      'Accept-Ranges': 'bytes',
    })

    return new NextResponse(videoStream as any, { headers })
  } catch (error: any) {
    console.error('ytdl download error:', error.message)
    return NextResponse.json(
      { error: error.message || 'Download failed' },
      { status: 500 }
    )
  }
}

export async function HEAD() {
  return NextResponse.json({ ok: true })
}

export async function OPTIONS() {
  return new NextResponse(null, {
    headers: {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, OPTIONS',
      'Access-Control-Allow-Headers': '*',
    },
  })
}
