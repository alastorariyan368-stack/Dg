import { NextRequest, NextResponse } from 'next/server'
import ytdl from '@distube/ytdl-core'
import { getAgent } from '@/lib/yt-video/config'
import { fetchVideoInfo } from '@/lib/yt-video/invidious'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(request: NextRequest) {
  try {
    const url = new URL(request.url)
    const videoUrl = url.searchParams.get('url')

    if (!videoUrl) {
      return NextResponse.json({ error: 'Missing video URL' }, { status: 400 })
    }

    const videoIdMatch = videoUrl.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/)
    const idDirectMatch = videoUrl.match(/^([a-zA-Z0-9_-]{11})$/)
    const videoId = videoIdMatch?.[1] || idDirectMatch?.[1]

    if (!videoId) {
      return NextResponse.json({ error: 'Invalid YouTube URL' }, { status: 400 })
    }

    try {
      const fullUrl = `https://www.youtube.com/watch?v=${videoId}`
      const info = await ytdl.getInfo(fullUrl, { agent: getAgent() })
      const details = info.videoDetails

      const formats = info.formats
        .filter(f => f.hasVideo && f.hasAudio && f.container === 'mp4')
        .map(f => ({
          itag: f.itag,
          quality: f.qualityLabel || f.quality,
          container: f.container,
          codecs: f.codecs,
          fps: f.fps,
          contentLength: f.contentLength,
          hasVideo: f.hasVideo,
          hasAudio: f.hasAudio,
        }))

      const audioFormats = info.formats
        .filter(f => f.hasAudio && !f.hasVideo)
        .map(f => ({
          itag: f.itag,
          audioBitrate: f.audioBitrate,
          audioCodec: f.audioCodec,
          container: f.container,
          contentLength: f.contentLength,
        }))

      const videoInfo = {
        id: videoId,
        title: details.title,
        description: details.description?.slice(0, 500),
        thumbnail: `https://img.youtube.com/vi/${videoId}/maxresdefault.jpg`,
        thumbnailHQ: `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`,
        duration: Number(details.lengthSeconds),
        durationLabel: formatDuration(Number(details.lengthSeconds)),
        viewCount: Number(details.viewCount || 0),
        viewCountLabel: formatNumber(Number(details.viewCount || 0)),
        channel: details.ownerChannelName || details.author?.name || 'Unknown',
        channelUrl: details.author?.channel_url || `https://youtube.com/channel/${details.author?.id || ''}`,
        channelSubs: details.author?.subscriber_count
          ? formatNumber(Number(details.author.subscriber_count))
          : 'N/A',
        publishedAt: details.publishDate,
        publishedLabel: formatDate(details.publishDate),
        ageRestricted: details.age_restricted,
        likes: Number(details.likes || 0),
        category: details.category,
        tags: details.keywords?.slice(0, 5) || [],
        formats: formats.slice(0, 8),
        audioFormats: audioFormats.slice(0, 4),
      }

      return NextResponse.json(videoInfo, {
        headers: { 'Cache-Control': 'public, max-age=300' },
      })
    } catch (ytErr: any) {
      console.error('ytdl-core failed, trying Invidious:', ytErr.message)

      const fallback = await fetchVideoInfo(videoId)

      return NextResponse.json(fallback, {
        headers: { 'Cache-Control': 'public, max-age=300' },
      })
    }
  } catch (error: any) {
    console.error('yt video info error:', error.message)
    return NextResponse.json(
      { error: error.message || 'Failed to fetch video info' },
      { status: 500 }
    )
  }
}

function formatDuration(seconds: number): string {
  if (!seconds || seconds <= 0) return '0:00'
  const h = Math.floor(seconds / 3600)
  const m = Math.floor((seconds % 3600) / 60)
  const s = Math.floor(seconds % 60)
  if (h > 0) return `${h}:${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`
  return `${m}:${s.toString().padStart(2, '0')}`
}

function formatNumber(num: number): string {
  if (num >= 10000000) return (num / 10000000).toFixed(1) + 'Cr'
  if (num >= 100000) return (num / 100000).toFixed(1) + 'L'
  if (num >= 1000) return (num / 1000).toFixed(1) + 'K'
  return num.toString()
}

function formatDate(dateString: string | undefined): string {
  if (!dateString) return 'Unknown'
  const date = new Date(dateString)
  const now = new Date()
  const diffDays = Math.ceil(Math.abs(now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24))
  if (diffDays === 0) return 'Today'
  if (diffDays === 1) return 'Yesterday'
  if (diffDays < 7) return `${diffDays} days ago`
  if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`
  if (diffDays < 365) return `${Math.floor(diffDays / 30)} months ago`
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
}
