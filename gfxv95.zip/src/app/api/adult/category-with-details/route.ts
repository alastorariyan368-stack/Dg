import { NextRequest, NextResponse } from 'next/server'

const API_BASE = 'http://localhost:3099/api'

export async function GET(request: NextRequest) {
  try {
    const name = request.nextUrl.searchParams.get('name')
    const page = request.nextUrl.searchParams.get('page') || '1'
    const limit = request.nextUrl.searchParams.get('limit') || '100'
    if (!name) return NextResponse.json({ error: 'Missing name' }, { status: 400 })

    const catRes = await fetch(`${API_BASE}/category/${encodeURIComponent(name)}?page=${page}&limit=${limit}&puppeteer=true`, { signal: AbortSignal.timeout(60000) })
    if (!catRes.ok) return NextResponse.json({ error: 'Category not found' }, { status: 404 })
    const catData = await catRes.json()
    const videoIds = catData?.videos || []
    if (!videoIds.length) return NextResponse.json({ videos: [] })

    const details = await Promise.allSettled(
      videoIds.map((id: string) =>
        fetch(`${API_BASE}/video/${id}?puppeteer=false`, { signal: AbortSignal.timeout(15000) }).then(r => r.json())
      )
    )

    const videos = details
      .filter(r => r.status === 'fulfilled' && r.value?.title)
      .map(r => (r as PromiseFulfilledResult<any>).value)
      .map((v: any) => ({
        id: v.video_id,
        title: v.title,
        thumbnail: v.thumbnail,
        duration: v.length,
        url: v.url,
      }))

    return NextResponse.json({ videos })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
