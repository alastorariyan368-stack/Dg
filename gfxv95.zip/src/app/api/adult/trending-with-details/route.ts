import { NextRequest, NextResponse } from 'next/server'

const API_BASE = 'http://localhost:3099/api'

export async function GET(request: NextRequest) {
  try {
    const page = request.nextUrl.searchParams.get('page') || '1'
    const limit = request.nextUrl.searchParams.get('limit') || '100'
    const trendRes = await fetch(`${API_BASE}/trending?page=${page}&limit=${limit}&puppeteer=true`, { signal: AbortSignal.timeout(60000) })
    if (!trendRes.ok) return NextResponse.json({ error: 'Failed' }, { status: 502 })
    const { trending } = await trendRes.json()
    if (!trending?.length) return NextResponse.json({ videos: [] })

    const details = await Promise.allSettled(
      trending.map((id: string) =>
        fetch(`${API_BASE}/video/${id}?puppeteer=false`, { signal: AbortSignal.timeout(15000) }).then(r => r.json())
      )
    )

    const videos = details
      .filter(r => r.status === 'fulfilled' && r.value?.title)
      .map(r => (r as PromiseFulfilledResult<any>).value)
      .map((v: any) => ({
        id: v.video_id,
        title: v.title,
        thumbnail: v.thumbnail,
        duration: v.length,
        url: v.url,
      }))

    return NextResponse.json({ videos })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
