import { NextRequest, NextResponse } from 'next/server'

const API_BASE = 'http://localhost:3099/api'

export async function GET(request: NextRequest, { params }: { params: { path: string[] } }) {
  try {
    const path = params.path.join('/')
    const search = request.nextUrl.search
    const isVideoDetail = path.startsWith('video/')
    const hasPuppeteer = search.includes('puppeteer=')
    const sep = search ? '&' : '?'
    const puppeteerParam = isVideoDetail ? 'puppeteer=false' : 'puppeteer=true'
    const url = `${API_BASE}/${path}${search}${hasPuppeteer ? '' : `${sep}${puppeteerParam}`}`
    const timeout = isVideoDetail ? 30000 : 60000
    const res = await fetch(url, { signal: AbortSignal.timeout(timeout) })
    if (!res.ok) return NextResponse.json({ error: 'Upstream failed' }, { status: res.status })
    const data = await res.json()
    return NextResponse.json(data)
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
