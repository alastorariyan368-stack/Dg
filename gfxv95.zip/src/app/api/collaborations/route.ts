import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const collaborations = await db.itemCollaborator.findMany({
      where: { userId: session.user.id },
      include: {
        item: { select: { id: true, title: true, slug: true, price: true, downloads: true, logo: true, author: { select: { username: true } } } }
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json({ collaborations })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch collaborations' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const { itemId, collaboratorUsername, revenueShare } = await req.json()

    const item = await db.item.findUnique({ where: { id: itemId } })
    if (!item || item.authorId !== session.user.id) {
      return NextResponse.json({ error: 'You can only add collaborators to your own items' }, { status: 403 })
    }

    const collaborator = await db.user.findUnique({ where: { username: collaboratorUsername } })
    if (!collaborator) return NextResponse.json({ error: 'User not found' }, { status: 404 })
    if (collaborator.id === session.user.id) return NextResponse.json({ error: 'Cannot collaborate with yourself' }, { status: 400 })

    const existing = await db.itemCollaborator.findUnique({
      where: { itemId_userId: { itemId, userId: collaborator.id } }
    })
    if (existing) return NextResponse.json({ error: 'Already a collaborator' }, { status: 400 })

    const collab = await db.itemCollaborator.create({
      data: {
        itemId,
        userId: collaborator.id,
        revenueShare: Math.min(Math.max(parseFloat(revenueShare) || 50, 1), 99),
        status: 'PENDING'
      }
    })

    return NextResponse.json({ collaboration: collab })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to add collaborator' }, { status: 500 })
  }
}
