import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { itemId, reportedUserId, reason, description } = await req.json()
  if (!reason) return NextResponse.json({ error: 'Reason required' }, { status: 400 })
  if (!itemId && !reportedUserId) return NextResponse.json({ error: 'Must report an item or user' }, { status: 400 })

  // Check if already reported
  const existing = await db.report.findFirst({
    where: { reporterId: session.user.id, ...(itemId ? { itemId } : { reportedUserId }) }
  })
  if (existing) return NextResponse.json({ error: 'You already reported this' }, { status: 400 })

  const report = await db.report.create({
    data: { reporterId: session.user.id, itemId, reportedUserId, reason, description }
  })

  // Increment report count on item
  if (itemId) {
    await db.item.update({ where: { id: itemId }, data: { reportCount: { increment: 1 } } })
  }

  return NextResponse.json({ report, message: 'Report submitted successfully' })
}

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const isAdmin = ['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')
  if (!isAdmin) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const reports = await db.report.findMany({
    include: {
      reporter: { select: { id: true, username: true, avatar: true } },
      reportedUser: { select: { id: true, username: true } },
      item: { select: { id: true, title: true, slug: true } }
    },
    orderBy: { createdAt: 'desc' }
  })
  return NextResponse.json({ reports })
}

export async function PATCH(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const isAdmin = ['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')
  if (!isAdmin) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const { id, status, adminNote } = await req.json()
  const report = await db.report.update({ where: { id }, data: { status, adminNote } })
  return NextResponse.json({ report })
}
