import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    // Lenient referer check — allow /afk path anywhere (full URL or relative)
    const referer = req.headers.get('referer') || ''
    if (referer) {
      try {
        const url = new URL(referer)
        if (!url.pathname.endsWith('/afk') && url.pathname !== '/afk') {
          return NextResponse.json({ error: 'AFK earning only works on the AFK page.' }, { status: 403 })
        }
      } catch {
        // If URL parsing fails, allow it (don't block)
      }
    }

    const settings = await db.siteSettings.findFirst()
    const s = settings as any
    const afkSettings = (s?.themeConfig?.afk) || {}

    // Check top-level fields first, fallback to themeConfig
    const isEnabled = s?.afkEarningEnabled ?? afkSettings.enabled ?? false
    if (!isEnabled) {
      return NextResponse.json({ enabled: false, message: 'AFK earning is disabled. Enable it in Admin → AFK Settings.' })
    }

    const ratePerMinute: number = Number(s?.afkRatePerMinute ?? afkSettings.ratePerMinute ?? 0.01)
    const minMinutes: number = Number(s?.afkMinMinutes ?? afkSettings.minMinutes ?? 0)
    const maxPerDay: number = Number(s?.afkMaxPerDay ?? afkSettings.maxPerDay ?? 10)

    const today = new Date().toISOString().slice(0, 10)
    const userId = session.user.id
    const now = new Date()

    // Use a transaction for atomicity
    const result = await db.$transaction(async (tx) => {
      // 1. Get today's total earnings
      const aggResult: any = await tx.$queryRawUnsafe(
        `SELECT COALESCE(SUM("amountEarned"), 0) as total FROM "afk_sessions" WHERE "userId" = $1 AND "date" = $2`,
        userId, today
      )
      const earnedToday = Number(aggResult[0]?.total || 0)

      if (earnedToday >= maxPerDay) {
        return { maxReached: true, earnedToday }
      }

      // 2. Find today's open session
      const sessions: any = await tx.$queryRawUnsafe(
        `SELECT * FROM "afk_sessions" WHERE "userId" = $1 AND "date" = $2 AND "endedAt" IS NULL ORDER BY "startedAt" DESC LIMIT 1`,
        userId, today
      )
      const openSession = sessions[0]

      if (!openSession) {
        const id = Math.random().toString(36).slice(2) + Date.now().toString(36)
        await tx.$executeRawUnsafe(
          `INSERT INTO "afk_sessions" ("id", "userId", "date", "startedAt", "lastHeartbeatAt", "minutesEarned", "amountEarned") 
           VALUES ($1, $2, $3, $4, $4, 0, 0)`,
          id, userId, today, now
        )
        return { sessionCreated: true, id, earnedToday, enabled: true, total: earnedToday, maxPerDay }
      }

      // Process heartbeat
      const lastHeartbeat = new Date(openSession.lastHeartbeatAt)
      const elapsedMs = now.getTime() - lastHeartbeat.getTime()
      const elapsedMin = elapsedMs / 60000

      const sessionDurationMs = now.getTime() - new Date(openSession.startedAt).getTime()
      const sessionDurationMin = sessionDurationMs / 60000

      // Grace period check
      if (minMinutes > 0 && sessionDurationMin < minMinutes) {
        const graceLeft = Math.ceil(minMinutes - sessionDurationMin)
        return {
          heartbeated: true,
          enabled: true,
          earned: 0,
          total: earnedToday,
          sessionDurationMin,
          inGrace: true,
          graceLeft,
          maxPerDay,
          message: `Grace period active. ${graceLeft} min left.`,
        }
      }

      // Not enough time since last heartbeat
      if (elapsedMin < 0.5) {
        return { heartbeated: true, enabled: true, earned: 0, total: earnedToday, sessionDurationMin, maxPerDay }
      }

      // Update last heartbeat timestamp
      await tx.$executeRawUnsafe(
        `UPDATE "afk_sessions" SET "lastHeartbeatAt" = $1 WHERE "id" = $2`,
        now, openSession.id
      )

      // Calculate and cap earnings
      const rawEarn = elapsedMin * ratePerMinute
      let actualEarn = rawEarn

      if (earnedToday + rawEarn > maxPerDay) {
        actualEarn = Math.max(0, maxPerDay - earnedToday)
      }

      if (actualEarn > 0) {
        await tx.$executeRawUnsafe(
          `UPDATE "afk_sessions" SET "minutesEarned" = "minutesEarned" + $1, "amountEarned" = "amountEarned" + $2 WHERE "id" = $3`,
          elapsedMin, actualEarn, openSession.id
        )

        await tx.user.update({
          where: { id: userId },
          data: { walletBalance: { increment: actualEarn } },
        })

        await tx.transaction.create({
          data: {
            userId,
            amount: actualEarn,
            method: 'afk_earning',
            type: 'EARN',
            status: 'APPROVED',
            reference: `AFK earn — ${elapsedMin.toFixed(1)} min`,
          },
        })

        return {
          enabled: true,
          earned: actualEarn,
          total: earnedToday + actualEarn,
          sessionDurationMin,
          maxPerDay,
          maxReached: earnedToday + actualEarn >= maxPerDay,
        }
      }

      return { heartbeated: true, enabled: true, earned: 0, total: earnedToday, sessionDurationMin, maxPerDay }
    })

    return NextResponse.json({
      enabled: true,
      earned: (result as any).earned || 0,
      total: (result as any).total || 0,
      maxReached: (result as any).maxReached || false,
      inGrace: (result as any).inGrace || false,
      graceLeft: (result as any).graceLeft || 0,
      sessionDurationMin: (result as any).sessionDurationMin || 0,
      maxPerDay,
      ...(result as any),
    })

  } catch (e: any) {
    console.error('AFK Heartbeat Error:', e)
    return NextResponse.json({ error: e.message || 'Server error' }, { status: 500 })
  }
}
