import { NextRequest, NextResponse } from 'next/server'
import { readFileSync, existsSync } from 'fs'
import { join } from 'path'
import { FileStorageService } from '@/lib/storage'

/**
 * Serve uploaded files - handles both local storage and S3
 * GET /api/uploads/:category/:filename
 */
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ category: string; filename: string }> }
) {
  try {
    const { category, filename } = await params

    // Security: prevent directory traversal attacks
    if (filename.includes('..') || category.includes('..')) {
      return NextResponse.json({ error: 'Invalid path' }, { status: 400 })
    }

    // Try local storage first
    const localPath = join(process.cwd(), 'public', 'uploads', category, filename)
    const uploadsPath = join(process.cwd(), 'uploads', category, filename)

    let fileBuffer: Buffer | null = null
    let contentType = 'application/octet-stream'

    // Try public/uploads first
    if (existsSync(localPath)) {
      try {
        fileBuffer = readFileSync(localPath)
        // Determine content type
        const ext = filename.split('.').pop()?.toLowerCase()
        const contentTypeMap: { [key: string]: string } = {
          jpg: 'image/jpeg',
          jpeg: 'image/jpeg',
          png: 'image/png',
          gif: 'image/gif',
          webp: 'image/webp',
          svg: 'image/svg+xml',
          pdf: 'application/pdf',
          zip: 'application/zip',
          rar: 'application/x-rar-compressed',
        }
        contentType = contentTypeMap[ext || ''] || 'application/octet-stream'
      } catch (err) {
        console.warn('Error reading local file:', err)
      }
    }

    // Try uploads dir if not found in public
    if (!fileBuffer && existsSync(uploadsPath)) {
      try {
        fileBuffer = readFileSync(uploadsPath)
      } catch (err) {
        console.warn('Error reading uploads file:', err)
      }
    }

    // Try S3 if local storage failed
    if (!fileBuffer && process.env.S3_BUCKET && process.env.S3_ACCESS_KEY) {
      try {
        const storage = new FileStorageService()
        const key = `${category}/${filename}`
        const presignedUrl = await storage.getFileUrl(key)
        // Redirect to S3
        return NextResponse.redirect(presignedUrl)
      } catch (s3Error) {
        console.warn('Error fetching from S3:', s3Error)
      }
    }

    if (!fileBuffer) {
      return NextResponse.json(
        { error: 'File not found' },
        { status: 404, headers: { 'Cache-Control': 'no-cache' } }
      )
    }

    return new NextResponse(new Uint8Array(fileBuffer), {
      status: 200,
      headers: {
        'Content-Type': contentType,
        'Content-Disposition': `inline; filename="${filename}"`,
        'Cache-Control': 'public, max-age=31536000, immutable',
        'Access-Control-Allow-Origin': '*',
      },
    })
  } catch (error) {
    console.error('File serving error:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
