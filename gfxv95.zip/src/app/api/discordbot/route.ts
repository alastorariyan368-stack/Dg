import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { createBotFiles } from '@/lib/discordbot/template'
import { installDeps } from '@/lib/discordbot/manager'

async function getUserId(): Promise<string | null> {
  const session = await getServerSession(authOptions)
  return session?.user?.id || null
}

export async function GET(request: NextRequest) {
  try {
    const userId = await getUserId()
    if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const bots = await db.discordBot.findMany({
      where: { userId },
      orderBy: { createdAt: 'desc' },
      include: {
        _count: { select: { logs: true } },
      },
    })

    return NextResponse.json(bots)
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to fetch bots' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const userId = await getUserId()
    if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const body = await request.json()
    const { name, description, prefix, language } = body

    if (!name) {
      return NextResponse.json({ error: 'Name is required' }, { status: 400 })
    }

    const config = await db.adminDiscordBotConfig.findUnique({ where: { id: 'default' } })
    if (config) {
      const botCount = await db.discordBot.count({ where: { userId } })
      if (botCount >= config.maxBotsPerUser) {
        return NextResponse.json({ error: `Maximum ${config.maxBotsPerUser} bots per user reached` }, { status: 400 })
      }
    }

    const bot = await db.discordBot.create({
      data: {
        userId,
        name,
        description,
        prefix: prefix || config?.defaultPrefix || '!',
        language: language || 'en',
      },
    })

    createBotFiles(bot.id, bot.name, bot.prefix)
    installDeps(bot.id)

    return NextResponse.json(bot, { status: 201 })
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to create bot' }, { status: 500 })
  }
}


