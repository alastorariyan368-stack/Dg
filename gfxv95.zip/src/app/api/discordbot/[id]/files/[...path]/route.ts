import { NextRequest, NextResponse } from 'next/server'
import { readFileSync, writeFileSync, unlinkSync, mkdirSync, rmdirSync, statSync, existsSync } from 'fs'
import { join, posix } from 'path'
import { getBotDir } from '@/lib/discordbot/template'

const extensionMap: Record<string, string> = {
  '.js': 'javascript',
  '.json': 'json',
  '.ts': 'typescript',
  '.py': 'python',
  '.env': 'plaintext',
  '.txt': 'plaintext',
  '.md': 'markdown',
  '.yml': 'yaml',
  '.yaml': 'yaml',
  '.html': 'html',
  '.css': 'css',
  '.env.example': 'plaintext',
}

function resolvePath(paramsPath: string[], botId: string): { resolved: string; error?: string } {
  const botDir = getBotDir(botId)
  const relative = paramsPath.join(posix.sep)
  const resolved = join(botDir, relative)

  if (!resolved.startsWith(botDir)) {
    return { resolved, error: 'Invalid path' }
  }

  return { resolved }
}

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string; path: string[] }> }
) {
  try {
    const { id, path: pathSegments } = await params
    const { resolved, error } = resolvePath(pathSegments, id)
    if (error) return NextResponse.json({ error }, { status: 400 })

    if (!existsSync(resolved)) {
      return NextResponse.json({ error: 'File not found' }, { status: 404 })
    }

    const stat = statSync(resolved)
    if (stat.isDirectory()) {
      return NextResponse.json({ error: 'Path is a directory' }, { status: 400 })
    }

    const content = readFileSync(resolved, 'utf-8')
    const ext = Object.keys(extensionMap).find(k => resolved.endsWith(k))
    const language = ext ? extensionMap[ext] : 'plaintext'

    return NextResponse.json({ content, language, size: stat.size })
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to read file' }, { status: 500 })
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; path: string[] }> }
) {
  try {
    const { id, path: pathSegments } = await params
    const { resolved, error } = resolvePath(pathSegments, id)
    if (error) return NextResponse.json({ error }, { status: 400 })

    const body = await request.json()
    const { content } = body

    if (content === undefined) {
      return NextResponse.json({ error: 'Content is required' }, { status: 400 })
    }

    mkdirSync(join(resolved, '..'), { recursive: true })
    writeFileSync(resolved, content, 'utf-8')

    return NextResponse.json({ success: true })
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to write file' }, { status: 500 })
  }
}

export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string; path: string[] }> }
) {
  try {
    const { id, path: pathSegments } = await params
    const { resolved, error } = resolvePath(pathSegments, id)
    if (error) return NextResponse.json({ error }, { status: 400 })

    if (!existsSync(resolved)) {
      return NextResponse.json({ error: 'File not found' }, { status: 404 })
    }

    const stat = statSync(resolved)
    if (stat.isDirectory()) {
      rmdirSync(resolved)
    } else {
      unlinkSync(resolved)
    }

    return NextResponse.json({ success: true })
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to delete file' }, { status: 500 })
  }
}


