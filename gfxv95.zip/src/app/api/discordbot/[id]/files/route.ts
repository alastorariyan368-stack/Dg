import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { readdirSync, statSync } from 'fs'
import { join } from 'path'
import { getBotDir } from '@/lib/discordbot/template'

async function getUserId(): Promise<string | null> {
  const session = await getServerSession(authOptions)
  return session?.user?.id || null
}

function buildTree(dirPath: string, basePath: string): any[] {
  const entries: any[] = []
  const names = readdirSync(dirPath, { withFileTypes: true })

  for (const entry of names) {
    if (entry.name === 'node_modules' || entry.name === '.git') continue

    const fullPath = join(dirPath, entry.name)
    const stat = statSync(fullPath)

    if (entry.isDirectory()) {
      entries.push({
        name: entry.name,
        path: join(basePath, entry.name),
        type: 'dir',
        size: 0,
        children: buildTree(fullPath, join(basePath, entry.name)),
      })
    } else {
      entries.push({
        name: entry.name,
        path: join(basePath, entry.name),
        type: 'file',
        size: stat.size,
      })
    }
  }

  return entries
}

export async function POST(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const userId = await getUserId()
    if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { id } = await params
    const bot = await db.discordBot.findUnique({ where: { id } })
    if (!bot) return NextResponse.json({ error: 'Bot not found' }, { status: 404 })
    if (bot.userId !== userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 })

    const dir = getBotDir(id)
    const tree = buildTree(dir, '')
    return NextResponse.json(tree)
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to list files' }, { status: 500 })
  }
}


