import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { restartBot } from '@/lib/discordbot/manager'

async function getUserId(): Promise<string | null> {
  const session = await getServerSession(authOptions)
  return session?.user?.id || null
}

export async function POST(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const userId = await getUserId()
    if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { id } = await params
    const bot = await db.discordBot.findUnique({ where: { id } })
    if (!bot) return NextResponse.json({ error: 'Bot not found' }, { status: 404 })
    if (bot.userId !== userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 })

    const result = await restartBot(id)
    if (!result.success) return NextResponse.json({ error: result.error }, { status: 500 })

    return NextResponse.json({ success: true })
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to restart bot' }, { status: 500 })
  }
}


