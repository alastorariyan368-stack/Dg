import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { executeCommand } from '@/lib/discordbot/manager'

async function getUserId(): Promise<string | null> {
  const session = await getServerSession(authOptions)
  return session?.user?.id || null
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const userId = await getUserId()
    if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { id } = await params
    const bot = await db.discordBot.findUnique({ where: { id } })
    if (!bot) return NextResponse.json({ error: 'Bot not found' }, { status: 404 })
    if (bot.userId !== userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 403 })

    const body = await request.json()
    const { command } = body

    if (!command) {
      return NextResponse.json({ error: 'Command is required' }, { status: 400 })
    }

    const result = await executeCommand(id, command)
    const isNpm = command.startsWith('npm ')
    const outputText = result.output
    const errorText = result.error

    if (!isNpm && outputText.trim()) {
      try {
        await db.discordBotLog.create({
          data: { botId: id, content: outputText.slice(0, 2000), type: errorText ? 'error' : 'info' },
        })
      } catch {}
    }

    return NextResponse.json({ output: outputText, error: errorText || null })
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to execute command' }, { status: 500 })
  }
}


