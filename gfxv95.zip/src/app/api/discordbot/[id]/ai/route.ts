import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { askAI, generateCommand, fixCode } from '@/lib/discordbot/ai'

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: _id } = await params
    const body = await request.json()
    const { type, prompt, code, errorLog, apiKey } = body

    let apiKeyToUse = apiKey

    if (!apiKeyToUse) {
      const settings = await db.siteSettings.findFirst()
      apiKeyToUse = (settings as any)?.openaiApiKey || (settings as any)?.aiApiKey || undefined
    }

    let response: string

    switch (type) {
      case 'ask':
        response = await askAI(prompt || '', code || '', apiKeyToUse)
        break
      case 'command':
        response = await generateCommand(prompt || '', apiKeyToUse)
        break
      case 'fix':
        response = await fixCode(errorLog || '', code || '', apiKeyToUse)
        break
      default:
        return NextResponse.json({ error: 'Invalid type. Must be "ask", "command", or "fix"' }, { status: 400 })
    }

    return NextResponse.json({ response })
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'AI request failed' }, { status: 500 })
  }
}


