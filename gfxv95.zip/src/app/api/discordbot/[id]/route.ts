import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { getBotDir } from '@/lib/discordbot/template'
import { stopBot } from '@/lib/discordbot/manager'
import { rmSync, existsSync } from 'fs'

async function getUserId(): Promise<string | null> {
  const session = await getServerSession(authOptions)
  return session?.user?.id || null
}

async function checkBotOwnership(id: string, userId: string) {
  const bot = await db.discordBot.findUnique({ where: { id } })
  if (!bot) return { bot: null, error: 'Bot not found' }
  if (bot.userId !== userId) return { bot: null, error: 'Unauthorized' }
  return { bot, error: null }
}

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const userId = await getUserId()
    if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { id } = await params
    const { bot, error } = await checkBotOwnership(id, userId)
    if (error) return NextResponse.json({ error }, { status: error === 'Bot not found' ? 404 : 403 })

    const fullBot = await db.discordBot.findUnique({
      where: { id },
      include: {
        logs: {
          orderBy: { createdAt: 'desc' },
          take: 50,
        },
      },
    })

    return NextResponse.json(fullBot)
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to fetch bot' }, { status: 500 })
  }
}

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const userId = await getUserId()
    if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { id } = await params
    const { bot, error } = await checkBotOwnership(id, userId)
    if (error) return NextResponse.json({ error }, { status: error === 'Bot not found' ? 404 : 403 })

    const body = await request.json()

    const allowed = ['name', 'description', 'token', 'clientId', 'prefix', 'language', 'autoRestart', 'mainFile']
    const data: Record<string, any> = {}
    for (const key of allowed) {
      if (body[key] !== undefined) data[key] = body[key]
    }

    const updatedBot = await db.discordBot.update({
      where: { id },
      data,
    })

    return NextResponse.json(updatedBot)
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to update bot' }, { status: 500 })
  }
}

export async function DELETE(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const userId = await getUserId()
    if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { id } = await params
    const { bot, error } = await checkBotOwnership(id, userId)
    if (error) return NextResponse.json({ error }, { status: error === 'Bot not found' ? 404 : 403 })

    await stopBot(id)

    const dir = getBotDir(id)
    if (existsSync(dir)) {
      rmSync(dir, { recursive: true, force: true })
    }

    await db.discordBot.delete({ where: { id } })

    return NextResponse.json({ success: true })
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to delete bot' }, { status: 500 })
  }
}


