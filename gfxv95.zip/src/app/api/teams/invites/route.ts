import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const invites = await db.teamInvite.findMany({
    where: { inviteeId: session.user.id, status: 'PENDING' },
    include: {
      team: {
        include: {
          owner: { select: { id: true, username: true, avatar: true } },
          members: { select: { userId: true } }
        }
      },
      inviter: { select: { id: true, username: true, avatar: true } }
    },
    orderBy: { createdAt: 'desc' }
  })

  return NextResponse.json({ invites })
}

export async function PATCH(request: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { inviteId, action } = await request.json()
  if (!inviteId || !['accept', 'reject'].includes(action)) {
    return NextResponse.json({ error: 'inviteId and action (accept/reject) required' }, { status: 400 })
  }

  const invite = await db.teamInvite.findUnique({
    where: { id: inviteId },
    include: { team: true }
  })

  if (!invite || invite.inviteeId !== session.user.id) {
    return NextResponse.json({ error: 'Invite not found' }, { status: 404 })
  }

  if (invite.status !== 'PENDING') {
    return NextResponse.json({ error: 'Invite already processed' }, { status: 400 })
  }

  await db.teamInvite.update({ where: { id: inviteId }, data: { status: action === 'accept' ? 'ACCEPTED' : 'REJECTED' } })

  if (action === 'accept') {
    const alreadyMember = await db.teamMember.findUnique({
      where: { teamId_userId: { teamId: invite.teamId, userId: session.user.id } }
    })
    if (!alreadyMember) {
      await db.teamMember.create({
        data: { teamId: invite.teamId, userId: session.user.id, role: 'MEMBER' }
      })
    }
    return NextResponse.json({ success: true, message: `Joined team "${invite.team.name}"!` })
  }

  return NextResponse.json({ success: true, message: 'Invite declined' })
}
