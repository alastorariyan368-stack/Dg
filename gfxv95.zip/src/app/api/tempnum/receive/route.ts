import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Webhook — called by SMS gateway (e.g. Twilio, Vonage, custom SMS server)
// POST /api/tempnum/receive
// Body: { to, from, body, secret }
export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { to, from, body: smsBody, secret } = body

    const expectedSecret = process.env.TEMPNUM_WEBHOOK_SECRET || 'gfx-tempnum-secret'
    if (secret !== expectedSecret) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    if (!to || !from || !smsBody) {
      return NextResponse.json({ error: 'Missing to/from/body' }, { status: 400 })
    }

    // Normalize number (strip spaces/dashes)
    const normalizedTo = to.replace(/[\s\-\(\)]/g, '')
    const phone = await db.tempPhone.findUnique({ where: { number: normalizedTo } })
    if (!phone) return NextResponse.json({ error: 'Number not found', to: normalizedTo }, { status: 404 })

    if (phone.expiresAt < new Date()) {
      return NextResponse.json({ error: 'Number expired' }, { status: 410 })
    }

    const msg = await db.tempSmsMessage.create({
      data: {
        phoneId: phone.id,
        fromNumber: from,
        body: smsBody,
      },
    })

    return NextResponse.json({ success: true, messageId: msg.id })
  } catch (err: any) {
    console.error('[tempnum/receive]', err)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
