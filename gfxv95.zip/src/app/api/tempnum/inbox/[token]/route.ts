import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(req: NextRequest, { params }: { params: Promise<{ token: string }> }) {
  try {
    const { token } = await params
    const phone = await db.tempPhone.findUnique({
      where: { token },
      include: {
        messages: { orderBy: { receivedAt: 'desc' } },
        config: { select: { countryName: true } },
      },
    })

    if (!phone) return NextResponse.json({ error: 'Number not found' }, { status: 404 })

    const expired = phone.expiresAt < new Date()

    return NextResponse.json({
      id: phone.id,
      number: phone.number,
      countryCode: phone.countryCode,
      countryName: phone.config.countryName,
      token: phone.token,
      expiresAt: phone.expiresAt,
      expired,
      messageCount: phone.messages.length,
      messages: phone.messages,
    })
  } catch (err: any) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ token: string }> }) {
  try {
    const { token } = await params
    const phone = await db.tempPhone.findUnique({ where: { token } })
    if (!phone) return NextResponse.json({ error: 'Not found' }, { status: 404 })
    await db.tempPhone.delete({ where: { id: phone.id } })
    return NextResponse.json({ success: true })
  } catch (err: any) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
