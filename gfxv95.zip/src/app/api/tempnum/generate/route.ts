import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

function randomDigits(len: number) {
  return Array.from({ length: len }, () => Math.floor(Math.random() * 10)).join('')
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    const { countryCode } = await req.json().catch(() => ({}))

    // Get available configs
    const whereClause = countryCode ? { countryCode, isActive: true } : { isActive: true }
    const configs = await db.tempPhoneConfig.findMany({ where: whereClause })
    if (configs.length === 0) {
      return NextResponse.json({ error: 'No phone number configs available for this country.' }, { status: 503 })
    }

    const config = configs[Math.floor(Math.random() * configs.length)]

    // Check user limit
    if (session?.user?.id) {
      const existing = await db.tempPhone.count({
        where: { userId: session.user.id, expiresAt: { gt: new Date() } },
      })
      if (existing >= config.maxPerUser) {
        return NextResponse.json({ error: `You already have ${config.maxPerUser} active numbers. Delete one first.` }, { status: 429 })
      }
    }

    // Generate unique number
    let number = ''
    let attempts = 0
    do {
      number = `${config.numberPrefix}${randomDigits(7)}`
      attempts++
      if (attempts > 20) return NextResponse.json({ error: 'Could not generate unique number' }, { status: 500 })
    } while (await db.tempPhone.findUnique({ where: { number } }))

    const expiresAt = new Date(Date.now() + config.expiryMinutes * 60 * 1000)

    const phone = await db.tempPhone.create({
      data: {
        number,
        countryCode: config.countryCode,
        expiresAt,
        userId: session?.user?.id ?? null,
      },
    })

    return NextResponse.json({
      id: phone.id,
      number: phone.number,
      countryCode: phone.countryCode,
      countryName: config.countryName,
      token: phone.token,
      expiresAt: phone.expiresAt,
      createdAt: phone.createdAt,
    })
  } catch (err: any) {
    console.error('[tempnum/generate]', err)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
