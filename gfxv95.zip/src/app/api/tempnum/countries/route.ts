import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET(_req: NextRequest) {
  try {
    const configs = await db.tempPhoneConfig.findMany({
      where: { isActive: true },
      select: {
        id: true,
        countryCode: true,
        countryName: true,
        numberPrefix: true,
        isActive: true,
      },
      orderBy: { countryName: 'asc' },
    })
    return NextResponse.json({ configs })
  } catch (err: any) {
    console.error('[tempnum/countries]', err)
    return NextResponse.json({ configs: [] }, { status: 200 })
  }
}
