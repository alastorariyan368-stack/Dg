import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getServerSession } from 'next-auth/next'
import { authOptions } from '@/lib/auth'

export async function GET() {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const userItems = await db.item.findMany({
      where: { authorId: session.user.id },
      include: {
        category: { select: { name: true } },
        _count: { select: { downloadRecords: true, reviews: true } }
      },
      orderBy: { createdAt: 'desc' },
      take: 50
    })

    return NextResponse.json(userItems)
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch user items' }, { status: 500 })
  }
}
