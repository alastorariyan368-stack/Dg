import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { withRetry } from '@/lib/db-retry'
import { sendMail, buildNotificationEmailHtml } from '@/lib/mailer'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { amount, method, transactionId, transactionType } = body

    if (!amount || !method || amount <= 0) {
      return NextResponse.json({ error: 'Invalid amount or method' }, { status: 400 })
    }

    // Verify user exists to prevent foreign key constraint violation (P2003)
    const userExists = await db.user.findUnique({
      where: { id: session.user.id },
      select: { id: true }
    })

    if (!userExists) {
      return NextResponse.json(
        { error: 'User account not found in database. Please logout and login again to refresh your session.' },
        { status: 404 }
      )
    }

    const transaction = await withRetry(
      async () => {
        const settings = await db.siteSettings.findFirst()
        const phoneNumber = method === 'nagad' ? settings?.nagadNumber : settings?.bkashNumber

        if (!phoneNumber && (method === 'nagad' || method === 'bkash')) {
          throw new Error('Payment method not configured')
        }

        const tx = await db.transaction.create({
          data: {
            userId: session.user.id,
            amount: parseFloat(amount),
            method,
            type: 'DEPOSIT',
            transactionType: transactionType || null,
            status: 'PENDING',
            reference: transactionId || null
          }
        })

        return { transaction: tx, phoneNumber }
      },
      'Create deposit transaction'
    )

    // Notify Admins
    const admins = await db.user.findMany({
      where: { role: { in: ['ADMIN', 'SUPER_ADMIN'] } },
      select: { email: true, username: true }
    })

    if (admins.length > 0) {
      const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'
      const html = buildNotificationEmailHtml({
        username: 'Admin',
        title: '🔔 New Deposit Submitted!',
        message: `A new deposit of <strong>৳${amount}</strong> via <strong>${method}</strong> (${transactionType}) has been submitted by <strong>${session.user.name || session.user.email}</strong>. Please review and approve it from the admin panel.`,
        color: '#f59e0b',
        ctaText: 'Review Transaction',
        ctaLink: `${appUrl}/admin/transactions`
      })

      for (const admin of admins) {
        if (admin.email) {
          sendMail({
            to: admin.email,
            subject: 'GfxStore — New Deposit Notification 🔔',
            html
          }).catch(err => console.error(`Failed to notify admin ${admin.email}:`, err))
        }
      }
    }

    const userReference = session.user.username || session.user.name || session.user.email || 'User'

    return NextResponse.json({
      success: true,
      transaction: transaction.transaction,
      phoneNumber: transaction.phoneNumber,
      userReference,
      message: `Send ৳${amount} to ${transaction.phoneNumber} with reference: ${userReference}`
    })
  } catch (error) {
    console.error('Payment error:', error)
    const errorMessage = error instanceof Error ? error.message : 'Payment failed'
    return NextResponse.json({ error: errorMessage }, { status: 500 })
  }
}
