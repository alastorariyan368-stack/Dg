import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

const VALID_METHODS = ['nagad', 'bkash', 'binance', 'bank', 'paypal']

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { method } = body

    if (!method || !VALID_METHODS.includes(method)) {
      return NextResponse.json({ error: 'Invalid payment method' }, { status: 400 })
    }

    const settings = await db.siteSettings.findFirst()
    if (!settings) return NextResponse.json({ error: 'Payment not configured. Contact support.' }, { status: 400 })

    const s = settings as any
    const themeConfig = (s.themeConfig as any) || {}
    const p = themeConfig.payments || {}

    if (method === 'nagad') {
      const isEnabled = s.nagadEnabled ?? p.nagadEnabled ?? true
      if (!isEnabled) return NextResponse.json({ error: 'Nagad is disabled.' }, { status: 400 })
      if (!settings.nagadNumber?.trim()) return NextResponse.json({ error: 'Nagad not configured. Contact support.' }, { status: 400 })
      return NextResponse.json({ 
        method, 
        methodName: 'Nagad', 
        type: 'mobile', 
        phoneNumber: settings.nagadNumber.trim(), 
        qr: s.nagadQr || p.nagadQr || null, 
        instruction: s.nagadInstruction || p.nagadInstruction || 'Send money and use the transaction ID as reference.' 
      })
    }
    if (method === 'bkash') {
      const isEnabled = s.bkashEnabled ?? p.bkashEnabled ?? true
      if (!isEnabled) return NextResponse.json({ error: 'bKash is disabled.' }, { status: 400 })
      if (!settings.bkashNumber?.trim()) return NextResponse.json({ error: 'bKash not configured. Contact support.' }, { status: 400 })
      return NextResponse.json({ 
        method, 
        methodName: 'bKash', 
        type: 'mobile', 
        phoneNumber: settings.bkashNumber.trim(), 
        qr: s.bkashQr || p.bkashQr || null, 
        instruction: s.bkashInstruction || p.bkashInstruction || 'Send money and use the transaction ID as reference.' 
      })
    }
    if (method === 'binance') {
      const isEnabled = s.binanceEnabled ?? p.binanceEnabled ?? false
      if (!isEnabled) return NextResponse.json({ error: 'Binance Pay is disabled.' }, { status: 400 })
      if (!settings.binanceId?.trim()) return NextResponse.json({ error: 'Binance Pay not configured. Contact support.' }, { status: 400 })
      return NextResponse.json({ 
        method, 
        methodName: 'Binance Pay', 
        type: 'crypto', 
        binanceId: settings.binanceId.trim(), 
        qr: s.binanceQr || p.binanceQr || null, 
        instruction: s.binanceInstruction || p.binanceInstruction || 'Send USDT and use transaction ID as memo.' 
      })
    }
    if (method === 'bank') {
      const isEnabled = s.bankEnabled ?? p.bankEnabled ?? false
      if (!isEnabled) return NextResponse.json({ error: 'Bank Transfer is disabled.' }, { status: 400 })
      const bd = settings.bankDetails as any
      if (!bd || !bd.accountNumber) return NextResponse.json({ error: 'Bank transfer not configured. Contact support.' }, { status: 400 })
      return NextResponse.json({ 
        method, 
        methodName: 'Bank Transfer', 
        type: 'bank', 
        bankDetails: bd, 
        instruction: s.bankInstruction || p.bankInstruction || 'Transfer to the account below and use transaction ID as reference.' 
      })
    }
    if (method === 'paypal') {
      const isEnabled = s.paypalEnabled ?? p.paypalEnabled ?? false
      if (!isEnabled) return NextResponse.json({ error: 'PayPal is disabled.' }, { status: 400 })
      const email = s.paypalEmail || p.paypalEmail
      if (!email) return NextResponse.json({ error: 'PayPal not configured. Contact support.' }, { status: 400 })
      return NextResponse.json({ 
        method, 
        methodName: 'PayPal', 
        type: 'paypal', 
        email: email, 
        instruction: s.paypalInstruction || p.paypalInstruction || 'Send payment to the PayPal email below and use transaction ID as note.' 
      })
    }

    return NextResponse.json({ error: 'Invalid method' }, { status: 400 })
  } catch (e) {
    return NextResponse.json({ error: 'Server error' }, { status: 500 })
  }
}

export async function GET() {
  try {
    const settings = await db.siteSettings.findFirst()
    if (!settings) return NextResponse.json({ methods: [] })
    const s = settings as any
    const themeConfig = (s.themeConfig as any) || {}
    const p = themeConfig.payments || {}
    const methods = []
    
    // Check top-level field or themeConfig fallback
    const isNagad = s.nagadEnabled ?? p.nagadEnabled ?? true
    const isBkash = s.bkashEnabled ?? p.bkashEnabled ?? true
    const isBinance = s.binanceEnabled ?? p.binanceEnabled ?? false
    const isBank = s.bankEnabled ?? p.bankEnabled ?? false
    const isPaypal = s.paypalEnabled ?? p.paypalEnabled ?? false

    if (isNagad && settings.nagadNumber?.trim()) {
      methods.push({ id: 'nagad', label: 'Nagad', badge: 'Popular', color: 'orange' })
    }
    if (isBkash && settings.bkashNumber?.trim()) {
      methods.push({ id: 'bkash', label: 'bKash', badge: 'Available', color: 'pink' })
    }
    if (isBinance && settings.binanceId?.trim()) {
      methods.push({ id: 'binance', label: 'Binance Pay', badge: 'Crypto', color: 'yellow' })
    }
    if (isBank && settings.bankDetails) {
      methods.push({ id: 'bank', label: 'Bank Transfer', badge: 'Global', color: 'blue' })
    }
    if (isPaypal && (s.paypalEmail?.trim() || p.paypalEmail?.trim())) {
      methods.push({ id: 'paypal', label: 'PayPal', badge: 'Global', color: 'sky' })
    }
    
    return NextResponse.json({ methods })
  } catch (err) { 
    console.error('Error fetching payment methods:', err)
    return NextResponse.json({ methods: [] }) 
  }
}
