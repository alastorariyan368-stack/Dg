import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { gfxPanelRequest, isGfxConfigured } from '@/lib/gfx-panel'

export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { id } = await params
    const body = await request.json()
    const action = String(body.action || '')
    if (!['start', 'stop', 'restart'].includes(action)) {
      return NextResponse.json({ error: 'Invalid action' }, { status: 400 })
    }

    const order = await db.vPSOrder.findUnique({ where: { id }, include: { plan: true } })
    if (!order || order.userId !== session.user.id) {
      return NextResponse.json({ error: 'Service not found' }, { status: 404 })
    }
    if (order.status !== 'APPROVED') {
      return NextResponse.json({ error: 'Service is not active' }, { status: 400 })
    }

    const info: any = order.serverInfo || {}
    const gfxVpsId = info.gfxVpsId || info.vps_id || info.id
    if (!gfxVpsId) {
      return NextResponse.json({ error: 'No GFX VPS is linked to this service' }, { status: 400 })
    }

    const cfg = await db.siteSettings.findFirst()
    if (!isGfxConfigured(cfg)) {
      return NextResponse.json({ error: 'GFX Panel is not configured' }, { status: 400 })
    }

    const result = await gfxPanelRequest(cfg!, `/vps/${gfxVpsId}/${action}`, { method: 'POST' })
    if (!result.ok || result.data?.success === false) {
      return NextResponse.json({ error: result.data?.error || `Failed to ${action} VPS`, details: result.data }, { status: result.status || 500 })
    }

    return NextResponse.json({ success: true, action, data: result.data })
  } catch (error) {
    console.error('Service power action failed:', error)
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Service action failed' }, { status: 500 })
  }
}
