import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const application = await db.sellerApplication.findUnique({ where: { userId: session.user.id } })
  return NextResponse.json({ application })
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { displayName, portfolioUrl, experience, sampleWorks, socialLinks } = await req.json()
  if (!displayName || !experience) return NextResponse.json({ error: 'Display name and experience required' }, { status: 400 })

  const existing = await db.sellerApplication.findUnique({ where: { userId: session.user.id } })
  if (existing) return NextResponse.json({ error: 'Application already submitted', application: existing }, { status: 400 })

  const application = await db.sellerApplication.create({
    data: { userId: session.user.id, displayName, portfolioUrl, experience, sampleWorks, socialLinks }
  })

  return NextResponse.json({ application, message: 'Application submitted! We will review it shortly.' })
}
