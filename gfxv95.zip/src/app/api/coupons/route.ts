import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { checkFeature } from '@/lib/feature-toggles'

export async function GET() {
  const blocked = await checkFeature('coupons', 'Coupon System')
  if (blocked) return blocked
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const isAdmin = ['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')
  if (!isAdmin) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const coupons = await db.coupon.findMany({
    include: { createdBy: { select: { username: true } }, _count: { select: { usages: true } } },
    orderBy: { createdAt: 'desc' }
  })
  return NextResponse.json({ coupons })
}

export async function POST(req: NextRequest) {
  const blocked = await checkFeature('coupons', 'Coupon System')
  if (blocked) return blocked
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const isAdmin = ['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')
  if (!isAdmin) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const { code, description, discountType, discountValue, minOrderAmount, maxUsage, expiresAt } = await req.json()
  if (!code || !discountValue) return NextResponse.json({ error: 'Code and discount value required' }, { status: 400 })

  const coupon = await db.coupon.create({
    data: {
      code: code.toUpperCase(),
      description,
      discountType: discountType || 'PERCENTAGE',
      discountValue: parseFloat(discountValue),
      minOrderAmount: minOrderAmount ? parseFloat(minOrderAmount) : null,
      maxUsage: maxUsage ? parseInt(maxUsage) : null,
      expiresAt: expiresAt ? new Date(expiresAt) : null,
      createdById: session.user.id
    }
  })
  return NextResponse.json({ coupon })
}

export async function DELETE(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const isAdmin = ['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')
  if (!isAdmin) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const { id } = await req.json()
  await db.coupon.delete({ where: { id } })
  return NextResponse.json({ success: true })
}
