import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { checkFeature } from '@/lib/feature-toggles'
import { maybeAwardBadges } from '@/lib/badge-awarder'

export async function GET(req: NextRequest) {
  const blocked = await checkFeature('reviews', 'Reviews & Ratings')
  if (blocked) return blocked
  const { searchParams } = new URL(req.url)
  const itemId = searchParams.get('itemId')
  const userId = searchParams.get('userId')

  const where: any = {}
  if (itemId) where.itemId = itemId
  if (userId) where.userId = userId

  const reviews = await db.review.findMany({
    where,
    include: {
      user: { select: { id: true, username: true, avatar: true } },
      item: { select: { id: true, title: true, slug: true } }
    },
    orderBy: { createdAt: 'desc' },
    take: 50
  })

  // Calculate average rating
  const avgRating = reviews.length ? reviews.reduce((s, r) => s + r.rating, 0) / reviews.length : 0

  return NextResponse.json({ reviews, avgRating: Math.round(avgRating * 10) / 10, total: reviews.length })
}

export async function POST(req: NextRequest) {
  const blocked = await checkFeature('reviews', 'Reviews & Ratings')
  if (blocked) return blocked
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { itemId, rating, comment } = await req.json()
  if (!itemId || !rating) return NextResponse.json({ error: 'Item ID and rating required' }, { status: 400 })
  if (rating < 1 || rating > 5) return NextResponse.json({ error: 'Rating must be 1-5' }, { status: 400 })

  const item = await db.item.findUnique({ where: { id: itemId }, select: { id: true, authorId: true, title: true, price: true } })
  if (!item) return NextResponse.json({ error: 'Item not found' }, { status: 404 })

  if (item.authorId === session.user.id) {
    return NextResponse.json({ error: 'You cannot review your own item' }, { status: 403 })
  }

  const existing = await db.review.findUnique({
    where: { itemId_userId: { itemId, userId: session.user.id } }
  })
  if (existing) return NextResponse.json({ error: 'You already reviewed this item' }, { status: 400 })

  const review = await db.review.create({
    data: { itemId, userId: session.user.id, rating: parseInt(rating), comment },
    include: { user: { select: { id: true, username: true, avatar: true } } }
  })

  // Notify seller
  await db.notification.create({
    data: {
      userId: item.authorId,
      type: 'NEW_REVIEW' as any,
      title: 'New review received',
      content: `Someone left a ${rating}-star review on "${item.title}"`
    }
  }).catch(() => {})

  // Update seller level based on total sales and reviews
  await updateSellerLevel(session.user.id)

  // Automatic badges for the reviewer
  await maybeAwardBadges(session.user.id)

  return NextResponse.json({ review })
}

export async function PATCH(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { reviewId, rating, comment } = await req.json()
  const review = await db.review.findUnique({ where: { id: reviewId } })
  if (!review || review.userId !== session.user.id) return NextResponse.json({ error: 'Not found or forbidden' }, { status: 403 })

  const updated = await db.review.update({
    where: { id: reviewId },
    data: { rating: parseInt(rating), comment },
    include: { user: { select: { id: true, username: true, avatar: true } } }
  })

  return NextResponse.json({ review: updated })
}

export async function DELETE(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { reviewId } = await req.json()
  const review = await db.review.findUnique({ where: { id: reviewId } })
  if (!review) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  const isAdmin = ['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')
  if (review.userId !== session.user.id && !isAdmin) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  await db.review.delete({ where: { id: reviewId } })
  return NextResponse.json({ success: true })
}

async function updateSellerLevel(userId: string) {
  const user = await db.user.findUnique({ where: { id: userId }, select: { totalSales: true } })
  if (!user) return
  let level = 1
  if (user.totalSales >= 100) level = 5
  else if (user.totalSales >= 50) level = 4
  else if (user.totalSales >= 20) level = 3
  else if (user.totalSales >= 5) level = 2
  await db.user.update({ where: { id: userId }, data: { sellerLevel: level } })
}
