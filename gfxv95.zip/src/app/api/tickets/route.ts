import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { sendMail } from '@/lib/email'

export const dynamic = 'force-dynamic'

const CATEGORIES = ['GENERAL', 'BILLING', 'BUG', 'FEATURE', 'ACCOUNT', 'OTHER']
const PRIORITIES = ['LOW', 'NORMAL', 'HIGH', 'URGENT']

async function getMe() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.email) return null
  return db.user.findUnique({ where: { email: session.user.email } })
}

// GET — list my tickets
export async function GET() {
  const me = await getMe()
  if (!me) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const tickets = await db.ticket.findMany({
    where: { userId: me.id },
    orderBy: [{ status: 'asc' }, { updatedAt: 'desc' }],
    include: {
      _count: { select: { messages: true } },
    },
  })
  return NextResponse.json({ tickets })
}

// POST — create new ticket
export async function POST(req: NextRequest) {
  const me = await getMe()
  if (!me) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json().catch(() => ({} as any))
  const subject = String(body.subject || '').trim().slice(0, 200)
  const description = String(body.description || '').trim().slice(0, 4000)
  const category = CATEGORIES.includes(body.category) ? body.category : 'GENERAL'
  const priority = PRIORITIES.includes(body.priority) ? body.priority : 'NORMAL'

  if (!subject) return NextResponse.json({ error: 'Subject is required' }, { status: 400 })
  if (!description) return NextResponse.json({ error: 'Description is required' }, { status: 400 })

  const ticket = await db.ticket.create({
    data: { userId: me.id, subject, description, category, priority, status: 'OPEN' },
  })

  // Initial system message from the user (mirrors description so admin sees full chat)
  await db.ticketMessage.create({
    data: { ticketId: ticket.id, senderId: me.id, isAdmin: false, content: description, kind: 'TEXT' },
  })

  // Notify all admins by socket + DB notification + email
  try {
    const admins = await db.user.findMany({
      where: { OR: [{ role: 'ADMIN' }, { role: 'SUPER_ADMIN' }] },
      select: { id: true, email: true, username: true },
    })
    for (const a of admins) {
      await db.notification.create({
        data: {
          userId: a.id,
          title: `🎫 New ticket #${ticket.ticketNumber}`,
          content: `${me.username}: ${subject}`,
          type: 'ADMIN_ANNOUNCEMENT',
        },
      }).catch(() => {})
      if ((global as any).io) {
        (global as any).io.to(`user:${a.id}`).emit('ticket:new', { ticketId: ticket.id, ticketNumber: ticket.ticketNumber, from: me.username, subject })
      }
      if (a.email) {
        sendMail({
          to: a.email,
          subject: `[GfxStore] New ticket #${ticket.ticketNumber} — ${subject}`,
          html: `<div style="font-family:system-ui,sans-serif;background:#f8fafc;padding:20px"><div style="max-width:600px;margin:0 auto;background:white;border-radius:12px;padding:24px"><h2 style="color:#7c3aed;margin:0 0 8px">🎫 New support ticket</h2><p style="color:#64748b;margin:0 0 16px">Ticket <strong>#${ticket.ticketNumber}</strong> opened by ${me.username}</p><div style="background:#f1f5f9;border-radius:8px;padding:16px;margin:16px 0"><div style="font-weight:600;color:#0f172a;margin-bottom:8px">${subject}</div><div style="color:#475569;font-size:14px;white-space:pre-wrap">${description.replace(/</g, '&lt;')}</div></div><div style="display:flex;gap:8px;margin:12px 0;font-size:13px;color:#64748b"><span style="background:#fef3c7;color:#92400e;padding:4px 10px;border-radius:6px">${category}</span><span style="background:#dbeafe;color:#1e40af;padding:4px 10px;border-radius:6px">${priority}</span></div><a href="${process.env.NEXTAUTH_URL || ''}/admin/tickets/${ticket.id}" style="display:inline-block;background:#7c3aed;color:white;padding:10px 20px;border-radius:8px;text-decoration:none;margin-top:8px">Open ticket →</a></div></div>`,
        }).catch(() => {})
      }
    }
  } catch (e) { console.error('ticket notify admin failed:', e) }

  // Confirm to user via email
  if (me.email) {
    sendMail({
      to: me.email,
      subject: `[GfxStore] Ticket #${ticket.ticketNumber} received — ${subject}`,
      html: `<div style="font-family:system-ui,sans-serif;background:#f8fafc;padding:20px"><div style="max-width:600px;margin:0 auto;background:white;border-radius:12px;padding:24px"><h2 style="color:#10b981;margin:0 0 8px">✅ Ticket received</h2><p style="color:#64748b;margin:0 0 16px">Hi ${me.username}, we got your support request. Our team will reply soon.</p><div style="background:#f1f5f9;border-radius:8px;padding:16px;margin:16px 0"><div style="color:#94a3b8;font-size:12px;margin-bottom:6px">TICKET #${ticket.ticketNumber}</div><div style="font-weight:600;color:#0f172a;margin-bottom:8px">${subject}</div><div style="color:#475569;font-size:14px;white-space:pre-wrap">${description.replace(/</g, '&lt;')}</div></div><a href="${process.env.NEXTAUTH_URL || ''}/tickets/${ticket.id}" style="display:inline-block;background:#10b981;color:white;padding:10px 20px;border-radius:8px;text-decoration:none;margin-top:8px">View ticket →</a></div></div>`,
    }).catch(() => {})
  }

  return NextResponse.json({ ticket }, { status: 201 })
}
