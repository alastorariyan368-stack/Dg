import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { sendMail } from '@/lib/email'

export const dynamic = 'force-dynamic'

async function getMe() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.email) return null
  return db.user.findUnique({ where: { email: session.user.email } })
}
function isAdmin(u: any) { return u && (u.role === 'ADMIN' || u.role === 'SUPER_ADMIN') }

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const me = await getMe()
  if (!me) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { id } = await params
  const ticket = await db.ticket.findUnique({
    where: { id },
    include: { user: { select: { id: true, username: true, avatar: true, email: true } } },
  })
  if (!ticket) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  if (ticket.userId !== me.id && !isAdmin(me)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  return NextResponse.json({ ticket })
}

// PATCH — rename, change status, change priority/category
export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const me = await getMe()
  if (!me) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { id } = await params
  const ticket = await db.ticket.findUnique({ where: { id } })
  if (!ticket) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  const body = await req.json().catch(() => ({} as any))
  const data: any = {}
  const isOwner = ticket.userId === me.id
  const admin = isAdmin(me)
  if (!isOwner && !admin) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  if (typeof body.subject === 'string') data.subject = body.subject.trim().slice(0, 200)
  if (admin) {
    if (['LOW', 'NORMAL', 'HIGH', 'URGENT'].includes(body.priority)) data.priority = body.priority
    if (['GENERAL', 'BILLING', 'BUG', 'FEATURE', 'ACCOUNT', 'OTHER'].includes(body.category)) data.category = body.category
  }
  if (['OPEN', 'PENDING', 'RESOLVED', 'CLOSED'].includes(body.status)) {
    data.status = body.status
    if (body.status === 'CLOSED' || body.status === 'RESOLVED') data.closedAt = new Date()
    else data.closedAt = null
  }

  const updated = await db.ticket.update({ where: { id }, data })
  return NextResponse.json({ ticket: updated })
}

// DELETE — owner can delete their own, admin can delete any
export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const me = await getMe()
  if (!me) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { id } = await params
  const ticket = await db.ticket.findUnique({
    where: { id },
    include: { user: { select: { email: true, username: true } } },
  })
  if (!ticket) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  if (ticket.userId !== me.id && !isAdmin(me)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  await db.ticket.delete({ where: { id } })

  if (isAdmin(me) && ticket.user?.email) {
    sendMail({
      to: ticket.user.email,
      subject: `[GfxStore] Ticket #${ticket.ticketNumber} closed by admin`,
      html: `<p>Hi ${ticket.user.username}, your support ticket <strong>#${ticket.ticketNumber} — ${ticket.subject}</strong> has been removed by an admin. If you still need help, please open a new ticket.</p>`,
    }).catch(() => {})
  }
  return NextResponse.json({ ok: true })
}
