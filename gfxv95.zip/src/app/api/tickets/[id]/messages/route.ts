import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { sendMail } from '@/lib/email'
import { writeFile, mkdir } from 'fs/promises'
import path from 'path'

export const dynamic = 'force-dynamic'

async function getMe() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.email) return null
  return db.user.findUnique({ where: { email: session.user.email } })
}
function isAdmin(u: any) { return u && (u.role === 'ADMIN' || u.role === 'SUPER_ADMIN') }

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const me = await getMe()
  if (!me) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { id } = await params
  const ticket = await db.ticket.findUnique({ where: { id } })
  if (!ticket) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  if (ticket.userId !== me.id && !isAdmin(me)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const messages = await db.ticketMessage.findMany({
    where: { ticketId: id },
    orderBy: { createdAt: 'asc' },
    include: { sender: { select: { id: true, username: true, avatar: true, role: true } } },
  })
  return NextResponse.json({ messages })
}

// POST — supports JSON (text) and multipart/form-data (with file)
export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const me = await getMe()
  if (!me) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { id } = await params

  const ticket = await db.ticket.findUnique({
    where: { id },
    include: { user: { select: { id: true, email: true, username: true } } },
  })
  if (!ticket) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  const fromAdmin = isAdmin(me)
  if (ticket.userId !== me.id && !fromAdmin) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const ct = req.headers.get('content-type') || ''
  let content = '', kind = 'TEXT', mediaUrl: string | null = null, mediaName: string | null = null, mimeType: string | null = null, durationSec: number | null = null

  if (ct.includes('multipart/form-data')) {
    const fd = await req.formData()
    content = String(fd.get('content') || '')
    kind = String(fd.get('kind') || 'TEXT')
    const dur = fd.get('durationSec'); if (dur) durationSec = parseInt(String(dur), 10) || null
    const file = fd.get('file') as File | null
    if (file && file.size) {
      if (file.size > 25 * 1024 * 1024) return NextResponse.json({ error: 'Max file size is 25MB' }, { status: 400 })
      const buf = Buffer.from(await file.arrayBuffer())
      const ext = (file.name.split('.').pop() || 'bin').toLowerCase().slice(0, 8)
      const safeName = `${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${ext}`
      const dir = path.join(process.cwd(), 'public', 'uploads', 'tickets')
      await mkdir(dir, { recursive: true })
      await writeFile(path.join(dir, safeName), buf)
      mediaUrl = `/uploads/tickets/${safeName}`
      mediaName = file.name
      mimeType = file.type || null
      if (!kind || kind === 'TEXT') {
        if (mimeType?.startsWith('image/')) kind = 'IMAGE'
        else if (mimeType?.startsWith('audio/')) kind = 'VOICE'
        else kind = 'FILE'
      }
    }
  } else {
    const body = await req.json().catch(() => ({} as any))
    content = String(body.content || '')
    kind = body.kind || 'TEXT'
    mediaUrl = body.mediaUrl || null
    mediaName = body.mediaName || null
    mimeType = body.mimeType || null
    durationSec = body.durationSec || null
  }

  if (!content.trim() && !mediaUrl) return NextResponse.json({ error: 'Empty message' }, { status: 400 })

  const msg = await db.ticketMessage.create({
    data: { ticketId: id, senderId: me.id, isAdmin: fromAdmin, content: content.slice(0, 4000), kind, mediaUrl, mediaName, mimeType, durationSec },
    include: { sender: { select: { id: true, username: true, avatar: true, role: true } } },
  })

  // Bump ticket: update timestamp + status
  await db.ticket.update({
    where: { id },
    data: { updatedAt: new Date(), status: fromAdmin ? 'PENDING' : 'OPEN' },
  })

  // Live socket push to whichever room is watching
  try {
    if ((global as any).io) {
      (global as any).io.to(`ticket:${id}`).emit('ticket:message', msg)
      const recipientId = fromAdmin ? ticket.userId : null
      if (recipientId) (global as any).io.to(`user:${recipientId}`).emit('ticket:reply', { ticketId: id, ticketNumber: ticket.ticketNumber, from: me.username })
    }
  } catch {}

  // Email notification: admin reply -> user; user reply -> all admins
  try {
    if (fromAdmin && ticket.user?.email) {
      sendMail({
        to: ticket.user.email,
        subject: `[GfxStore] Reply on ticket #${ticket.ticketNumber} — ${ticket.subject}`,
        html: `<div style="font-family:system-ui,sans-serif;background:#f8fafc;padding:20px"><div style="max-width:600px;margin:0 auto;background:white;border-radius:12px;padding:24px"><h2 style="color:#7c3aed;margin:0 0 8px">💬 Admin replied</h2><p style="color:#64748b">Ticket <strong>#${ticket.ticketNumber}</strong></p><div style="background:#f1f5f9;border-radius:8px;padding:16px;margin:12px 0;white-space:pre-wrap;color:#0f172a">${(content || '[attachment]').replace(/</g, '&lt;')}</div>${mediaUrl ? `<p style="color:#64748b;font-size:13px">📎 Attachment: ${mediaName}</p>` : ''}<a href="${process.env.NEXTAUTH_URL || ''}/tickets/${id}" style="display:inline-block;background:#7c3aed;color:white;padding:10px 20px;border-radius:8px;text-decoration:none">Open ticket →</a></div></div>`,
      }).catch(() => {})
    } else if (!fromAdmin) {
      const admins = await db.user.findMany({
        where: { OR: [{ role: 'ADMIN' }, { role: 'SUPER_ADMIN' }] },
        select: { email: true },
      })
      for (const a of admins) {
        if (a.email) sendMail({
          to: a.email,
          subject: `[GfxStore] User reply on ticket #${ticket.ticketNumber}`,
          html: `<p>${me.username} replied on ticket <strong>#${ticket.ticketNumber} — ${ticket.subject}</strong>:</p><blockquote style="background:#f1f5f9;padding:12px;border-radius:8px;white-space:pre-wrap">${(content || '[attachment]').replace(/</g, '&lt;')}</blockquote>${mediaUrl ? `<p>📎 ${mediaName}</p>` : ''}<p><a href="${process.env.NEXTAUTH_URL || ''}/admin/tickets/${id}">Open in admin panel</a></p>`,
        }).catch(() => {})
      }
    }
  } catch {}

  return NextResponse.json(msg, { status: 201 })
}
