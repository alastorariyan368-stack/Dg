import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  if (!['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  try {
    const campaigns = await db.campaign.findMany({ orderBy: { createdAt: 'desc' } })
    return NextResponse.json({ campaigns })
  } catch (error) {
    return NextResponse.json({ campaigns: [] })
  }
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  if (!['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  try {
    const data = await req.json()
    const campaign = await db.campaign.create({
      data: {
        name: data.name,
        description: data.description || '',
        discountPercent: parseFloat(data.discountPercent) || 0,
        bannerImage: data.bannerImage || null,
        bannerText: data.bannerText || null,
        startDate: new Date(data.startDate),
        endDate: new Date(data.endDate),
        isActive: data.isActive ?? true,
        targetCategories: data.targetCategories || null
      }
    })
    return NextResponse.json({ campaign })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create campaign' }, { status: 500 })
  }
}
