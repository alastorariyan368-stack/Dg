import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { sendMail, buildNotificationEmailHtml } from '@/lib/mailer'

function isAdmin(role?: string) { return ['ADMIN', 'SUPER_ADMIN'].includes(role || '') }

async function resolveItem(slug: string) {
  const byId = await db.item.findUnique({ where: { id: slug } }).catch(() => null)
  if (byId) return byId
  return db.item.findUnique({ where: { slug } })
}

export async function GET(req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id || !isAdmin(session.user.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const { slug } = await params
  const item = await resolveItem(slug)
  if (!item) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  return NextResponse.json({ item })
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id || !isAdmin(session.user.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const { slug } = await params
  const existing = await resolveItem(slug)
  if (!existing) return NextResponse.json({ error: 'Item not found' }, { status: 404 })

  const data = await req.json()
  const updateData: any = {}
  if (data.status) updateData.status = data.status
  if (typeof data.featured === 'boolean') updateData.featured = data.featured
  if (typeof data.isBoosted === 'boolean') updateData.isBoosted = data.isBoosted

  const item = await db.item.update({ where: { id: existing.id }, data: updateData })

  // Notify author if status changed
  if (data.status && ['APPROVED', 'REJECTED'].includes(data.status)) {
    await db.notification.create({
      data: {
        userId: existing.authorId,
        type: (data.status === 'APPROVED' ? 'ITEM_APPROVED' : 'ITEM_REJECTED') as any,
        title: `Item ${data.status.toLowerCase()}`,
        content: `Your item "${existing.title}" has been ${data.status.toLowerCase()}${data.adminNote ? ': ' + data.adminNote : ''}`
      }
    }).catch(() => {})

    // Send email to author
    const author = await db.user.findUnique({
      where: { id: existing.authorId },
      select: { email: true, username: true }
    }).catch(() => null)

    if (author?.email) {
      const isApproved = data.status === 'APPROVED'
      const appUrl = process.env.NEXT_PUBLIC_APP_URL ||
        (process.env.REPLIT_DOMAINS ? `https://${process.env.REPLIT_DOMAINS.split(',')[0]}` : 'http://localhost:5000')
      const html = buildNotificationEmailHtml({
        username: author.username || 'there',
        title: isApproved ? '🎉 Item Approved!' : '❌ Item Rejected',
        message: isApproved
          ? `Great news! Your item <strong>"${existing.title}"</strong> has been <strong style="color:#22c55e;">approved</strong> and is now live on GfxStore. Users can discover and download it right away.`
          : `Your item <strong>"${existing.title}"</strong> has been <strong style="color:#ef4444;">rejected</strong>.${data.adminNote ? `<br/><br/>Reason: ${data.adminNote}` : '<br/><br/>Please review our guidelines and resubmit with the necessary changes.'}`,
        color: isApproved ? '#059669' : '#dc2626',
        ctaText: isApproved ? 'View Your Item' : 'Edit & Resubmit',
        ctaLink: isApproved ? `${appUrl}/items/${existing.slug}` : `${appUrl}/dashboard`
      })
      sendMail({
        to: author.email,
        subject: isApproved ? `GfxStore — "${existing.title}" has been approved!` : `GfxStore — "${existing.title}" needs changes`,
        html
      }).catch(console.error)
    }
  }

  return NextResponse.json({ item })
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ slug: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id || !isAdmin(session.user.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const { slug } = await params
  const existing = await resolveItem(slug)
  if (!existing) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  await db.item.delete({ where: { id: existing.id } })
  return NextResponse.json({ success: true })
}
