import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

async function requireAdmin() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.email) return null
  const user = await db.user.findUnique({ where: { email: session.user.email } })
  if (!user || !['ADMIN', 'SUPER_ADMIN'].includes(user.role)) return null
  return user
}

export async function PATCH(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const admin = await requireAdmin()
    if (!admin) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    const { id } = await params
    const body = await request.json()

    const provider = await db.aiProvider.update({
      where: { id },
      data: {
        ...(body.name !== undefined && { name: body.name }),
        ...(body.description !== undefined && { description: body.description }),
        ...(body.apiKey !== undefined && { apiKey: body.apiKey }),
        ...(body.apiBase !== undefined && { apiBase: body.apiBase }),
        ...(body.models !== undefined && { models: body.models }),
        ...(body.features !== undefined && { features: body.features }),
        ...(body.enabled !== undefined && { enabled: body.enabled }),
        ...(body.isFree !== undefined && { isFree: body.isFree }),
        ...(body.priority !== undefined && { priority: body.priority }),
        ...(body.logoUrl !== undefined && { logoUrl: body.logoUrl }),
      }
    })
    return NextResponse.json({ provider })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to update provider' }, { status: 500 })
  }
}

export async function DELETE(_: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const admin = await requireAdmin()
    if (!admin) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    const { id } = await params
    await db.aiProvider.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to delete provider' }, { status: 500 })
  }
}
