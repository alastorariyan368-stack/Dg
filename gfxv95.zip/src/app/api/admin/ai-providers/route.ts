import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

async function requireAdmin() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.email) return null
  const user = await db.user.findUnique({ where: { email: session.user.email } })
  if (!user || !['ADMIN', 'SUPER_ADMIN'].includes(user.role)) return null
  return user
}

export async function GET() {
  try {
    const admin = await requireAdmin()
    if (!admin) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const providers = await db.aiProvider.findMany({
      orderBy: [{ priority: 'desc' }, { name: 'asc' }]
    })
    return NextResponse.json({ providers })
  } catch (error) {
    console.error('Error fetching AI providers:', error)
    return NextResponse.json({ error: 'Failed to fetch providers' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const admin = await requireAdmin()
    if (!admin) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const body = await request.json()
    const { name, slug, description, apiKey, apiBase, models, features, enabled, isFree, priority, logoUrl } = body

    if (!name || !slug) return NextResponse.json({ error: 'Name and slug required' }, { status: 400 })

    const provider = await db.aiProvider.upsert({
      where: { slug },
      create: {
        name, slug, description, apiKey, apiBase,
        models: models || [],
        features: features || [],
        enabled: enabled !== false,
        isFree: isFree || false,
        priority: priority || 0,
        logoUrl
      },
      update: {
        name, description, apiKey, apiBase,
        models: models || [],
        features: features || [],
        enabled: enabled !== false,
        isFree: isFree || false,
        priority: priority || 0,
        logoUrl
      }
    })
    return NextResponse.json({ provider }, { status: 201 })
  } catch (error) {
    console.error('Error creating AI provider:', error)
    return NextResponse.json({ error: 'Failed to create provider' }, { status: 500 })
  }
}
