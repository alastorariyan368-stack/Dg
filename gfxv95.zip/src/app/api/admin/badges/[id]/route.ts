import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function PUT(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  if (!['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  try {
    const { id } = await params
    const data = await req.json()
    const badge = await db.badge.update({
      where: { id },
      data: {
        name: data.name,
        description: data.description,
        icon: data.icon,
        color: data.color,
        criteria: data.criteria,
        isAutomatic: data.isAutomatic,
        isActive: data.isActive
      }
    })
    return NextResponse.json({ badge })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to update badge' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  if (!['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  try {
    const { id } = await params
    await db.badge.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to delete badge' }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  if (!['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  try {
    const { id } = await params
    const { userId, action } = await req.json()

    if (action === 'assign') {
      const badge = await db.badge.findUnique({ where: { id } })
      if (!badge) return NextResponse.json({ error: 'Badge not found' }, { status: 404 })

      const user = await db.user.findUnique({ where: { id: userId }, select: { badges: true } })
      if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })

      // Import parseBadgeIds from lib
      const parsedBadges = Array.isArray(user.badges) 
        ? (user.badges as string[]).filter((x) => typeof x === 'string')
        : []
      
      if (!parsedBadges.includes(id)) {
        await db.user.update({
          where: { id: userId },
          data: { badges: [...parsedBadges, id] }
        })
      }
      return NextResponse.json({ success: true })
    }

    if (action === 'remove') {
      const badge = await db.badge.findUnique({ where: { id } })
      if (!badge) return NextResponse.json({ error: 'Badge not found' }, { status: 404 })

      const user = await db.user.findUnique({ where: { id: userId }, select: { badges: true } })
      if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 })

      // Parse badges consistently
      const parsedBadges = Array.isArray(user.badges) 
        ? (user.badges as string[]).filter((x) => typeof x === 'string')
        : []
      
      const updatedBadges = parsedBadges.filter((b: string) => b !== id)
      await db.user.update({ where: { id: userId }, data: { badges: updatedBadges } })
      return NextResponse.json({ success: true })
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to manage badge' }, { status: 500 })
  }
}
