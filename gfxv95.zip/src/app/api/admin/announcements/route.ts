import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { announcementEmailHtml, sendMail } from '@/lib/email'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

function isAdmin(role?: string) { return ['ADMIN', 'SUPER_ADMIN'].includes(role || '') }

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id || !isAdmin(session.user.role)) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }
  const items = await db.announcement.findMany({ orderBy: { createdAt: 'desc' }, take: 100 })
  return NextResponse.json({ announcements: items })
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id || !isAdmin(session.user.role)) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  const { message, title, sendEmail = true, pinToBanner = true } = await req.json()
  const finalTitle = (title || 'Announcement').trim().slice(0, 200)
  const finalContent = (message || '').trim()
  if (!finalContent) return NextResponse.json({ error: 'Message required' }, { status: 400 })

  // 1. Persist as Announcement so it shows on top of website
  const announcement = await db.announcement.create({
    data: { title: finalTitle, content: finalContent.slice(0, 4000), active: true },
  })

  // 2. Optionally update SiteSettings.announcement (used by older banner code)
  if (pinToBanner) {
    try {
      const existing = await db.siteSettings.findFirst()
      if (existing) {
        await db.siteSettings.update({ where: { id: existing.id }, data: { announcement: finalContent.slice(0, 500) } })
      } else {
        await db.siteSettings.create({ data: { announcement: finalContent.slice(0, 500) } })
      }
    } catch {}
  }

  // 3. Notify all users in their notification inbox
  let notifiedCount = 0
  try {
    const users = await db.user.findMany({ select: { id: true } })
    notifiedCount = users.length
    if (users.length > 0) {
      await db.notification.createMany({
        data: users.map(u => ({
          userId: u.id,
          type: 'ADMIN_ANNOUNCEMENT' as any,
          title: finalTitle,
          content: finalContent.slice(0, 500),
        })),
        skipDuplicates: true,
      })
    }
  } catch (e) { console.error('Notification fanout failed', e) }

  // 4. Email blast to all users (best effort, non-blocking)
  let emailResult: any = { ok: false, skipped: true }
  if (sendEmail) {
    try {
      const settings = await db.siteSettings.findFirst()
      const siteName = settings?.siteName || 'GfxStore'
      const usersWithEmail = await db.user.findMany({
        where: { email: { not: '' as any } },
        select: { email: true },
      })
      const recipients = usersWithEmail.map(u => u.email).filter(Boolean)
      if (recipients.length > 0) {
        emailResult = await sendMail({
          to: recipients,
          subject: `📢 ${siteName}: ${finalTitle}`,
          html: announcementEmailHtml(finalTitle, finalContent, siteName),
          text: `${finalTitle}\n\n${finalContent}`,
        })
        if (emailResult.ok) {
          await db.announcement.update({ where: { id: announcement.id }, data: { emailSent: true } })
        }
      } else {
        emailResult = { ok: false, error: 'No users with email addresses' }
      }
    } catch (e: any) {
      emailResult = { ok: false, error: e?.message || 'Email blast failed' }
    }
  }

  return NextResponse.json({
    success: true,
    announcement,
    notifiedUsers: notifiedCount,
    email: emailResult,
  })
}

export async function PATCH(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id || !isAdmin(session.user.role)) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }
  const { id, active } = await req.json()
  if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 })
  const updated = await db.announcement.update({ where: { id }, data: { active: !!active } })
  return NextResponse.json({ announcement: updated })
}

export async function DELETE(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id || !isAdmin(session.user.role)) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }
  const { id } = await req.json()
  if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 })
  await db.announcement.delete({ where: { id } })
  return NextResponse.json({ success: true })
}
