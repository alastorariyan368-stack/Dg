import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const settings = await db.siteSettings.findFirst()
    return NextResponse.json({ maintenance: settings?.maintenance || false })
  } catch {
    return NextResponse.json({ maintenance: false })
  }
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  if (!['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  try {
    const { maintenance } = await req.json()
    let settings = await db.siteSettings.findFirst()
    if (!settings) {
      settings = await db.siteSettings.create({ data: { maintenance: !!maintenance } })
    } else {
      settings = await db.siteSettings.update({ where: { id: settings.id }, data: { maintenance: !!maintenance } })
    }
    return NextResponse.json({ success: true, maintenance: settings.maintenance })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to update maintenance mode' }, { status: 500 })
  }
}
