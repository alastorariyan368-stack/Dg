import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function GET() {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !['ADMIN', 'SUPER_ADMIN'].includes(session.user?.role as string)) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    const channels = await db.tVChannel.findMany({ orderBy: { sortOrder: 'asc' } })
    return NextResponse.json({ channels })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !['ADMIN', 'SUPER_ADMIN'].includes(session.user?.role as string)) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    const body = await request.json()
    const channel = await db.tVChannel.create({
      data: {
        name: body.name,
        url: body.url,
        logo: body.logo || null,
        groupTitle: body.groupTitle || 'General',
        tvgId: body.tvgId || null,
        tvgName: body.tvgName || null,
        tvgLogo: body.tvgLogo || null,
        tvgCountry: body.tvgCountry || null,
        isActive: body.isActive !== false,
        sortOrder: body.sortOrder || 0,
      },
    })
    return NextResponse.json({ channel })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !['ADMIN', 'SUPER_ADMIN'].includes(session.user?.role as string)) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    const body = await request.json()
    const { id, ...data } = body
    if (!id) return NextResponse.json({ error: 'id required' }, { status: 400 })
    const channel = await db.tVChannel.update({ where: { id }, data })
    return NextResponse.json({ channel })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
