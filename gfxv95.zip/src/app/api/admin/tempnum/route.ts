import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

async function requireAdmin() {
  const session = await getServerSession(authOptions)
  if (!session?.user || !['ADMIN', 'SUPER_ADMIN'].includes(session.user.role)) return null
  return session
}

// GET /api/admin/tempnum — list country configs + stats
export async function GET(req: NextRequest) {
  if (!await requireAdmin()) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const [configs, phoneCount, msgCount] = await Promise.all([
    db.tempPhoneConfig.findMany({ orderBy: { createdAt: 'desc' } }),
    db.tempPhone.count(),
    db.tempSmsMessage.count(),
  ])

  return NextResponse.json({ configs, stats: { phoneCount, msgCount } })
}

// POST /api/admin/tempnum — add country config
export async function POST(req: NextRequest) {
  if (!await requireAdmin()) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { countryCode, countryName, numberPrefix, expiryMinutes, maxPerUser } = await req.json()
  if (!countryCode || !countryName || !numberPrefix) {
    return NextResponse.json({ error: 'countryCode, countryName, numberPrefix are required' }, { status: 400 })
  }
  try {
    const created = await db.tempPhoneConfig.create({
      data: {
        countryCode: countryCode.toUpperCase(),
        countryName,
        numberPrefix,
        expiryMinutes: expiryMinutes || 30,
        maxPerUser: maxPerUser || 3,
      },
    })
    return NextResponse.json(created, { status: 201 })
  } catch {
    return NextResponse.json({ error: 'Country code already exists' }, { status: 409 })
  }
}

// PATCH /api/admin/tempnum — update config
export async function PATCH(req: NextRequest) {
  if (!await requireAdmin()) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { id, ...data } = await req.json()
  const updated = await db.tempPhoneConfig.update({ where: { id }, data })
  return NextResponse.json(updated)
}

// DELETE /api/admin/tempnum — delete config
export async function DELETE(req: NextRequest) {
  if (!await requireAdmin()) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { id } = await req.json()
  await db.tempPhoneConfig.delete({ where: { id } })
  return NextResponse.json({ success: true })
}
