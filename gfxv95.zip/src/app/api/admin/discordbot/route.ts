import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    let config = await db.adminDiscordBotConfig.findUnique({ where: { id: 'default' } })

    if (!config) {
      config = await db.adminDiscordBotConfig.create({
        data: {
          id: 'default',
          maxBotsPerUser: 5,
          maxRamPerBot: 512,
          aiEnabled: true,
          defaultPrefix: '!',
        },
      })
    }

    return NextResponse.json(config)
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to fetch config' }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const body = await request.json()

    const allowed = ['maxBotsPerUser', 'maxRamPerBot', 'aiEnabled', 'defaultPrefix']
    const data: Record<string, any> = {}
    for (const key of allowed) {
      if (body[key] !== undefined) data[key] = body[key]
    }

    const config = await db.adminDiscordBotConfig.upsert({
      where: { id: 'default' },
      update: data,
      create: {
        id: 'default',
        maxBotsPerUser: body.maxBotsPerUser ?? 5,
        maxRamPerBot: body.maxRamPerBot ?? 512,
        aiEnabled: body.aiEnabled ?? true,
        defaultPrefix: body.defaultPrefix ?? '!',
      },
    })

    return NextResponse.json(config)
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Failed to update config' }, { status: 500 })
  }
}


