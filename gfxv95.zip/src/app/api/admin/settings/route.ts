import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET() {
  try {
    // Get or create default settings
    let settings = await db.siteSettings.findFirst()
    
    if (!settings) {
      // Create default settings if none exist
      settings = await db.siteSettings.create({
        data: {
          siteName: 'GfxStore'
        }
      })
    }
    
    // Mask API keys for security
    const safeSettings = settings ? {
      ...settings,
      aiApiKey: settings.aiApiKey ? '****' + settings.aiApiKey.slice(-4) : null,
      openaiApiKey: settings.openaiApiKey ? '****' + settings.openaiApiKey.slice(-4) : null,
      anthropicApiKey: settings.anthropicApiKey ? '****' + settings.anthropicApiKey.slice(-4) : null,
      geminiApiKey: settings.geminiApiKey ? '****' + settings.geminiApiKey.slice(-4) : null,
      deepseekApiKey: settings.deepseekApiKey ? '****' + settings.deepseekApiKey.slice(-4) : null,
      openrouterApiKey: settings.openrouterApiKey ? '****' + settings.openrouterApiKey.slice(-4) : null,
      xaiApiKey: settings.xaiApiKey ? '****' + settings.xaiApiKey.slice(-4) : null,
      groqApiKey: settings.groqApiKey ? '****' + settings.groqApiKey.slice(-4) : null,
      bananaApiKey: settings.bananaApiKey ? '****' + settings.bananaApiKey.slice(-4) : null,
      mistralApiKey: (settings as any).mistralApiKey ? '****' + (settings as any).mistralApiKey.slice(-4) : null,
      cohereApiKey: (settings as any).cohereApiKey ? '****' + (settings as any).cohereApiKey.slice(-4) : null,
      cloudflareAiApiKey: (settings as any).cloudflareAiApiKey ? '****' + (settings as any).cloudflareAiApiKey.slice(-4) : null,
      pollinationsApiKey: (settings as any).pollinationsApiKey ? '****' + (settings as any).pollinationsApiKey.slice(-4) : null,
      stabilityApiKey: settings.stabilityApiKey ? '****' + settings.stabilityApiKey.slice(-4) : null,
      replicateApiKey: settings.replicateApiKey ? '****' + settings.replicateApiKey.slice(-4) : null,
      huggingfaceApiKey: settings.huggingfaceApiKey ? '****' + settings.huggingfaceApiKey.slice(-4) : null,
      togetherApiKey: settings.togetherApiKey ? '****' + settings.togetherApiKey.slice(-4) : null,
      pixabayApiKey: settings.pixabayApiKey ? '****' + settings.pixabayApiKey.slice(-4) : null,
      unsplashApiKey: settings.unsplashApiKey ? '****' + settings.unsplashApiKey.slice(-4) : null,
      resendApiKey: settings.resendApiKey ? '****' + settings.resendApiKey.slice(-4) : null,
      falApiKey: settings.falApiKey ? '****' + settings.falApiKey.slice(-4) : null,
      runwayApiKey: settings.runwayApiKey ? '****' + settings.runwayApiKey.slice(-4) : null,
      lumaApiKey: settings.lumaApiKey ? '****' + settings.lumaApiKey.slice(-4) : null,
      klingApiKey: settings.klingApiKey ? '****' + settings.klingApiKey.slice(-4) : null,
      minimaxApiKey: settings.minimaxApiKey ? '****' + settings.minimaxApiKey.slice(-4) : null,
      // Extra chat / text providers
      perplexityApiKey: (settings as any).perplexityApiKey ? '****' + (settings as any).perplexityApiKey.slice(-4) : null,
      fireworksApiKey:  (settings as any).fireworksApiKey  ? '****' + (settings as any).fireworksApiKey.slice(-4)  : null,
      ai21ApiKey:       (settings as any).ai21ApiKey       ? '****' + (settings as any).ai21ApiKey.slice(-4)       : null,
      nvidiaApiKey:     (settings as any).nvidiaApiKey     ? '****' + (settings as any).nvidiaApiKey.slice(-4)     : null,
      sambanovaApiKey:  (settings as any).sambanovaApiKey  ? '****' + (settings as any).sambanovaApiKey.slice(-4)  : null,
      novitaApiKey:     (settings as any).novitaApiKey     ? '****' + (settings as any).novitaApiKey.slice(-4)     : null,
      // Extra image-gen providers
      ideogramApiKey: (settings as any).ideogramApiKey ? '****' + (settings as any).ideogramApiKey.slice(-4) : null,
      recraftApiKey:  (settings as any).recraftApiKey  ? '****' + (settings as any).recraftApiKey.slice(-4)  : null,
      leonardoApiKey: (settings as any).leonardoApiKey ? '****' + (settings as any).leonardoApiKey.slice(-4) : null,
      bflApiKey:      (settings as any).bflApiKey      ? '****' + (settings as any).bflApiKey.slice(-4)      : null,
      getimgApiKey:   (settings as any).getimgApiKey   ? '****' + (settings as any).getimgApiKey.slice(-4)   : null,
      // Extra video-gen providers
      pikaApiKey:      (settings as any).pikaApiKey      ? '****' + (settings as any).pikaApiKey.slice(-4)      : null,
      viduApiKey:      (settings as any).viduApiKey      ? '****' + (settings as any).viduApiKey.slice(-4)      : null,
      hedraApiKey:     (settings as any).hedraApiKey     ? '****' + (settings as any).hedraApiKey.slice(-4)     : null,
      hotshotApiKey:   (settings as any).hotshotApiKey   ? '****' + (settings as any).hotshotApiKey.slice(-4)   : null,
      ltxStudioApiKey: (settings as any).ltxStudioApiKey ? '****' + (settings as any).ltxStudioApiKey.slice(-4) : null,
      // Voice / audio providers
      elevenlabsApiKey: (settings as any).elevenlabsApiKey ? '****' + (settings as any).elevenlabsApiKey.slice(-4) : null,
      deepgramApiKey:   (settings as any).deepgramApiKey   ? '****' + (settings as any).deepgramApiKey.slice(-4)   : null,
      assemblyaiApiKey: (settings as any).assemblyaiApiKey ? '****' + (settings as any).assemblyaiApiKey.slice(-4) : null,
      // OAuth (Login Config)
      discordClientId: (settings as any).discordClientId || null,
      discordClientSecret: (settings as any).discordClientSecret ? '****' + (settings as any).discordClientSecret.slice(-4) : null,
      googleClientId: (settings as any).googleClientId || null,
      googleClientSecret: (settings as any).googleClientSecret ? '****' + (settings as any).googleClientSecret.slice(-4) : null,
      oauthEnabled: (settings as any).oauthEnabled !== false,
      // Pterodactyl
      pteroUrl: (settings as any).pteroUrl || null,
      pteroAdminApiKey: (settings as any).pteroAdminApiKey ? '****' + (settings as any).pteroAdminApiKey.slice(-4) : null,
      pteroLocationId: (settings as any).pteroLocationId || '1',
      pteroNestId: (settings as any).pteroNestId || '1',
      pteroEggId: (settings as any).pteroEggId || '1',
      pteroDockerImage: (settings as any).pteroDockerImage || '',
      pteroStartupCommand: (settings as any).pteroStartupCommand || '',
      pteroDbPassword: (settings as any).pteroDbPassword || 'pterodactyl',
      // Cloudflare Zero Trust
      cfAccountId: (settings as any).cfAccountId || null,
      cfApiToken: (settings as any).cfApiToken ? '****' + (settings as any).cfApiToken.slice(-4) : null,
      cfAllowedZones: (settings as any).cfAllowedZones || [],
      maxTunnelsPerUser: (settings as any).maxTunnelsPerUser ?? 2,
    } : {}
    return NextResponse.json(safeSettings)
  } catch (error) {
    console.error('Error fetching settings:', error)
    return NextResponse.json({ 
      siteName: 'GfxStore',
      nagadNumber: '',
      bkashNumber: '',
      announcement: ''
    }, { status: 200 })
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    if (!['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    const body = await request.json()
    const {
      nagadNumber, bkashNumber, binanceId, bankDetails,
      siteName, announcement,
      privacyUrl, helpCenterUrl, documentationUrl, contactUsUrl,
      statusPageUrl, discordUrl, githubUrl, twitterUrl,
      privacyPolicy, termsOfService, guidelines, dmcaUrl,
      aiApiKey, aiModel, openaiApiKey, anthropicApiKey, geminiApiKey,
      deepseekApiKey, openrouterApiKey, xaiApiKey, groqApiKey, bananaApiKey,
      mistralApiKey, cohereApiKey, cloudflareAiApiKey, pollinationsApiKey,
      stabilityApiKey, replicateApiKey, huggingfaceApiKey, togetherApiKey,
      pixabayApiKey, unsplashApiKey, resendApiKey, fromEmail,
      lowTokenMode,
      falApiKey, runwayApiKey, lumaApiKey, klingApiKey, minimaxApiKey, videoModel,
      gmailUser, gmailClientId, gmailClientSecret, gmailRefreshToken, gmailAppPassword,
      modelsLabApiKey, emailVerificationEnabled,
      discordClientId, discordClientSecret, googleClientId, googleClientSecret, oauthEnabled,
      // extra chat
      perplexityApiKey, fireworksApiKey, ai21ApiKey, nvidiaApiKey, sambanovaApiKey, novitaApiKey,
      // extra image
      ideogramApiKey, recraftApiKey, leonardoApiKey, bflApiKey, getimgApiKey,
      // extra video
      pikaApiKey, viduApiKey, hedraApiKey, hotshotApiKey, ltxStudioApiKey,
      // voice / audio
      elevenlabsApiKey, deepgramApiKey, assemblyaiApiKey,
      // free-tier video provider extras (already in schema, accept in PATCH)
      deepinfraApiKey, segmindApiKey, a4fApiKey,
      // Pterodactyl panel
      pteroUrl, pteroAdminApiKey, pteroLocationId, pteroNestId, pteroEggId,
      pteroDockerImage, pteroStartupCommand, pteroDbPassword,
    } = body

    let settings = await db.siteSettings.findFirst()

    const updateData: any = {}
    if (nagadNumber !== undefined) updateData.nagadNumber = nagadNumber?.trim() || ''
    if (bkashNumber !== undefined) updateData.bkashNumber = bkashNumber?.trim() || ''
    if (binanceId !== undefined) updateData.binanceId = binanceId?.trim() || ''
    if (bankDetails !== undefined) updateData.bankDetails = bankDetails || null
    if (siteName !== undefined) updateData.siteName = siteName?.trim() || 'GfxStore'
    if (announcement !== undefined) updateData.announcement = announcement?.trim() || ''
    if (privacyUrl !== undefined) updateData.privacyUrl = privacyUrl?.trim() || ''
    if (helpCenterUrl !== undefined) updateData.helpCenterUrl = helpCenterUrl?.trim() || ''
    if (documentationUrl !== undefined) updateData.documentationUrl = documentationUrl?.trim() || ''
    if (contactUsUrl !== undefined) updateData.contactUsUrl = contactUsUrl?.trim() || ''
    if (statusPageUrl !== undefined) updateData.statusPageUrl = statusPageUrl?.trim() || ''
    if (discordUrl !== undefined) updateData.discordUrl = discordUrl?.trim() || ''
    if (githubUrl !== undefined) updateData.githubUrl = githubUrl?.trim() || ''
    if (twitterUrl !== undefined) updateData.twitterUrl = twitterUrl?.trim() || ''
    if (privacyPolicy !== undefined) updateData.privacyPolicy = privacyPolicy?.trim() || ''
    if (termsOfService !== undefined) updateData.termsOfService = termsOfService?.trim() || ''
    if (guidelines !== undefined) updateData.guidelines = guidelines?.trim() || ''
    if (dmcaUrl !== undefined) updateData.dmcaUrl = dmcaUrl?.trim() || ''
    if (aiApiKey !== undefined) updateData.aiApiKey = aiApiKey?.trim() || null
    if (aiModel !== undefined) updateData.aiModel = aiModel?.trim() || 'gpt-4o-mini'
    if (openaiApiKey !== undefined) updateData.openaiApiKey = openaiApiKey?.trim() || null
    if (anthropicApiKey !== undefined) updateData.anthropicApiKey = anthropicApiKey?.trim() || null
    if (geminiApiKey !== undefined) updateData.geminiApiKey = geminiApiKey?.trim() || null
    if (deepseekApiKey !== undefined) updateData.deepseekApiKey = deepseekApiKey?.trim() || null
    if (openrouterApiKey !== undefined) updateData.openrouterApiKey = openrouterApiKey?.trim() || null
    if (xaiApiKey !== undefined) updateData.xaiApiKey = xaiApiKey?.trim() || null
    if (groqApiKey !== undefined) updateData.groqApiKey = groqApiKey?.trim() || null
    if (bananaApiKey !== undefined) updateData.bananaApiKey = bananaApiKey?.trim() || null
    if (mistralApiKey !== undefined) updateData.mistralApiKey = mistralApiKey?.trim() || null
    if (cohereApiKey !== undefined) updateData.cohereApiKey = cohereApiKey?.trim() || null
    if (cloudflareAiApiKey !== undefined) updateData.cloudflareAiApiKey = cloudflareAiApiKey?.trim() || null
    if (pollinationsApiKey !== undefined) updateData.pollinationsApiKey = pollinationsApiKey?.trim() || null
    if (stabilityApiKey !== undefined) updateData.stabilityApiKey = stabilityApiKey?.trim() || null
    if (replicateApiKey !== undefined) updateData.replicateApiKey = replicateApiKey?.trim() || null
    if (huggingfaceApiKey !== undefined) updateData.huggingfaceApiKey = huggingfaceApiKey?.trim() || null
    if (togetherApiKey !== undefined) updateData.togetherApiKey = togetherApiKey?.trim() || null
    if (pixabayApiKey !== undefined) updateData.pixabayApiKey = pixabayApiKey?.trim() || null
    if (unsplashApiKey !== undefined) updateData.unsplashApiKey = unsplashApiKey?.trim() || null
    if (resendApiKey !== undefined) updateData.resendApiKey = resendApiKey?.trim() || null
    if (fromEmail !== undefined) updateData.fromEmail = fromEmail?.trim() || null
    if (lowTokenMode !== undefined) updateData.lowTokenMode = lowTokenMode
    if (falApiKey !== undefined) updateData.falApiKey = falApiKey?.trim() || null
    if (runwayApiKey !== undefined) updateData.runwayApiKey = runwayApiKey?.trim() || null
    if (lumaApiKey !== undefined) updateData.lumaApiKey = lumaApiKey?.trim() || null
    if (klingApiKey !== undefined) updateData.klingApiKey = klingApiKey?.trim() || null
    if (minimaxApiKey !== undefined) updateData.minimaxApiKey = minimaxApiKey?.trim() || null
    if (videoModel !== undefined) updateData.videoModel = videoModel?.trim() || 'fal-ai/wan/v2.5/text-to-video/fast'
    if (gmailUser !== undefined) updateData.gmailUser = gmailUser?.trim() || null
    if (gmailClientId !== undefined) updateData.gmailClientId = gmailClientId?.trim() || null
    if (gmailClientSecret !== undefined) updateData.gmailClientSecret = gmailClientSecret?.trim() || null
    if (gmailRefreshToken !== undefined) updateData.gmailRefreshToken = gmailRefreshToken?.trim() || null
    if (gmailAppPassword !== undefined) updateData.gmailAppPassword = gmailAppPassword?.trim() || null
    if (modelsLabApiKey !== undefined) updateData.modelsLabApiKey = modelsLabApiKey?.trim() || null
    if (emailVerificationEnabled !== undefined) updateData.emailVerificationEnabled = !!emailVerificationEnabled
    // OAuth (Login Config) — accept literal new value; ignore masked placeholder values
    if (discordClientId !== undefined) updateData.discordClientId = discordClientId?.trim() || null
    if (discordClientSecret !== undefined && !String(discordClientSecret).startsWith('****')) {
      updateData.discordClientSecret = discordClientSecret?.trim() || null
    }
    if (googleClientId !== undefined) updateData.googleClientId = googleClientId?.trim() || null
    if (googleClientSecret !== undefined && !String(googleClientSecret).startsWith('****')) {
      updateData.googleClientSecret = googleClientSecret?.trim() || null
    }
    if (oauthEnabled !== undefined) updateData.oauthEnabled = !!oauthEnabled

    // Cloudflare Zero Trust
    const { cfAccountId, cfApiToken, maxTunnelsPerUser } = body
    if (cfAccountId !== undefined) updateData.cfAccountId = cfAccountId?.trim() || null
    if (cfApiToken !== undefined && !String(cfApiToken).startsWith('****')) updateData.cfApiToken = cfApiToken?.trim() || null
    if (maxTunnelsPerUser !== undefined) updateData.maxTunnelsPerUser = parseInt(String(maxTunnelsPerUser)) || 2

    // Pterodactyl
    if (pteroUrl !== undefined) updateData.pteroUrl = pteroUrl?.trim() || null
    if (pteroAdminApiKey !== undefined && !String(pteroAdminApiKey).startsWith('****')) updateData.pteroAdminApiKey = pteroAdminApiKey?.trim() || null
    if (pteroLocationId !== undefined) updateData.pteroLocationId = pteroLocationId?.trim() || '1'
    if (pteroNestId !== undefined) updateData.pteroNestId = pteroNestId?.trim() || '1'
    if (pteroEggId !== undefined) updateData.pteroEggId = pteroEggId?.trim() || '1'
    if (pteroDockerImage !== undefined) updateData.pteroDockerImage = pteroDockerImage?.trim() || null
    if (pteroStartupCommand !== undefined) updateData.pteroStartupCommand = pteroStartupCommand?.trim() || null
    if (pteroDbPassword !== undefined) updateData.pteroDbPassword = pteroDbPassword?.trim() || 'pterodactyl'

    // Extra chat / text providers
    if (perplexityApiKey !== undefined) updateData.perplexityApiKey = perplexityApiKey?.trim() || null
    if (fireworksApiKey  !== undefined) updateData.fireworksApiKey  = fireworksApiKey?.trim()  || null
    if (ai21ApiKey       !== undefined) updateData.ai21ApiKey       = ai21ApiKey?.trim()       || null
    if (nvidiaApiKey     !== undefined) updateData.nvidiaApiKey     = nvidiaApiKey?.trim()     || null
    if (sambanovaApiKey  !== undefined) updateData.sambanovaApiKey  = sambanovaApiKey?.trim()  || null
    if (novitaApiKey     !== undefined) updateData.novitaApiKey     = novitaApiKey?.trim()     || null
    // Extra image-gen providers
    if (ideogramApiKey !== undefined) updateData.ideogramApiKey = ideogramApiKey?.trim() || null
    if (recraftApiKey  !== undefined) updateData.recraftApiKey  = recraftApiKey?.trim()  || null
    if (leonardoApiKey !== undefined) updateData.leonardoApiKey = leonardoApiKey?.trim() || null
    if (bflApiKey      !== undefined) updateData.bflApiKey      = bflApiKey?.trim()      || null
    if (getimgApiKey   !== undefined) updateData.getimgApiKey   = getimgApiKey?.trim()   || null
    // Extra video-gen providers
    if (pikaApiKey      !== undefined) updateData.pikaApiKey      = pikaApiKey?.trim()      || null
    if (viduApiKey      !== undefined) updateData.viduApiKey      = viduApiKey?.trim()      || null
    if (hedraApiKey     !== undefined) updateData.hedraApiKey     = hedraApiKey?.trim()     || null
    if (hotshotApiKey   !== undefined) updateData.hotshotApiKey   = hotshotApiKey?.trim()   || null
    if (ltxStudioApiKey !== undefined) updateData.ltxStudioApiKey = ltxStudioApiKey?.trim() || null
    // Voice / audio providers
    if (elevenlabsApiKey !== undefined) updateData.elevenlabsApiKey = elevenlabsApiKey?.trim() || null
    if (deepgramApiKey   !== undefined) updateData.deepgramApiKey   = deepgramApiKey?.trim()   || null
    if (assemblyaiApiKey !== undefined) updateData.assemblyaiApiKey = assemblyaiApiKey?.trim() || null
    // Free-tier video provider extras
    if (deepinfraApiKey !== undefined) updateData.deepinfraApiKey = deepinfraApiKey?.trim() || null
    if (segmindApiKey   !== undefined) updateData.segmindApiKey   = segmindApiKey?.trim()   || null
    if (a4fApiKey       !== undefined) updateData.a4fApiKey       = a4fApiKey?.trim()       || null

    if (!settings) {
      settings = await db.siteSettings.create({
        data: {
          nagadNumber: nagadNumber?.trim() || '',
          bkashNumber: bkashNumber?.trim() || '',
          siteName: siteName?.trim() || 'GfxStore',
          announcement: announcement?.trim() || '',
          privacyUrl: privacyUrl?.trim() || '',
          helpCenterUrl: helpCenterUrl?.trim() || '',
          documentationUrl: documentationUrl?.trim() || '',
          contactUsUrl: contactUsUrl?.trim() || '',
          statusPageUrl: statusPageUrl?.trim() || '',
          discordUrl: discordUrl?.trim() || '',
          githubUrl: githubUrl?.trim() || '',
          twitterUrl: twitterUrl?.trim() || '',
          privacyPolicy: privacyPolicy?.trim() || '',
          termsOfService: termsOfService?.trim() || '',
          guidelines: guidelines?.trim() || '',
          dmcaUrl: dmcaUrl?.trim() || ''
        }
      })
      return NextResponse.json({ success: true, data: settings })
    }

    const updated = await db.siteSettings.update({
      where: { id: settings.id },
      data: updateData
    })

    return NextResponse.json({ success: true, data: updated })
  } catch (error) {
    console.error('Error updating settings:', error)
    return NextResponse.json({ error: 'Failed to save settings. Please try again.' }, { status: 500 })
  }
}
