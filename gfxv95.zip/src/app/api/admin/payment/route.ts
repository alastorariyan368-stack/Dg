import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

function isAdmin(session: any) {
  return ['ADMIN', 'SUPER_ADMIN'].includes(session?.user?.role || '')
}

export async function GET() {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !isAdmin(session)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

    let s = await db.siteSettings.findFirst()
    if (!s) {
      s = await db.siteSettings.create({ data: {} })
    }

    const themeConfig = (s.themeConfig as any) || {}
    const payments = themeConfig.payments || {}
    const afk = themeConfig.afk || {}

    return NextResponse.json({
      nagadEnabled: s.nagadEnabled ?? payments.nagadEnabled ?? true,
      bkashEnabled: s.bkashEnabled ?? payments.bkashEnabled ?? true,
      binanceEnabled: s.binanceEnabled ?? payments.binanceEnabled ?? false,
      bankEnabled: s.bankEnabled ?? payments.bankEnabled ?? false,
      paypalEnabled: s.paypalEnabled ?? payments.paypalEnabled ?? false,
      nagadNumber: s.nagadNumber || '',
      bkashNumber: s.bkashNumber || '',
      binanceId: s.binanceId || '',
      nagadQr: s.nagadQr || payments.nagadQr || '',
      bkashQr: s.bkashQr || payments.bkashQr || '',
      binanceQr: s.binanceQr || payments.binanceQr || '',
      nagadInstruction: s.nagadInstruction || payments.nagadInstruction || 'Send to the number below using "Send Money". Put the transaction ID as reference.',
      bkashInstruction: s.bkashInstruction || payments.bkashInstruction || 'Send to the number below using "Send Money". Put the transaction ID as reference.',
      binanceInstruction: s.binanceInstruction || payments.binanceInstruction || 'Send USDT to the Binance Pay ID below. Use reference code as memo.',
      bankInstruction: s.bankInstruction || payments.bankInstruction || '',
      paypalInstruction: s.paypalInstruction || payments.paypalInstruction || '',
      paypalEmail: s.paypalEmail || payments.paypalEmail || '',
      bankDetails: s.bankDetails || {},
      afkEarningEnabled: s.afkEarningEnabled ?? afk.enabled ?? false,
      afkRatePerMinute: s.afkRatePerMinute ?? afk.ratePerMinute ?? 0.01,
      afkMinMinutes: s.afkMinMinutes ?? afk.minMinutes ?? 5,
      afkMaxPerDay: s.afkMaxPerDay ?? afk.maxPerDay ?? 10.0,
    })
  } catch (e: any) {
    console.error('[Payment GET]', e?.message)
    return NextResponse.json({ error: 'Server error: ' + (e?.message || 'unknown') }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !isAdmin(session)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

    let body: any
    try {
      body = await req.json()
    } catch {
      return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 })
    }

    let s = await db.siteSettings.findFirst()
    if (!s) {
      s = await db.siteSettings.create({ data: {} })
    }

    const themeConfig = (s.themeConfig as any) || {}
    const payments = { ...(themeConfig.payments || {}) }
    const afk = { ...(themeConfig.afk || {}) }

    const data: any = {}

    const directFields = [
      'nagadNumber', 'bkashNumber', 'binanceId', 'bankDetails',
      'nagadEnabled', 'bkashEnabled', 'binanceEnabled', 'bankEnabled', 'paypalEnabled',
      'nagadQr', 'bkashQr', 'binanceQr',
      'nagadInstruction', 'bkashInstruction', 'binanceInstruction', 'bankInstruction', 'paypalInstruction',
      'paypalEmail',
    ]
    const afkFields = ['afkEarningEnabled', 'afkRatePerMinute', 'afkMinMinutes', 'afkMaxPerDay']

    for (const k of directFields) {
      if (k in body && body[k] !== undefined) data[k] = body[k]
    }
    for (const k of afkFields) {
      if (k in body && body[k] !== undefined) data[k] = body[k]
    }

    const paymentSyncFields = [
      'nagadEnabled', 'bkashEnabled', 'binanceEnabled', 'bankEnabled', 'paypalEnabled',
      'nagadQr', 'bkashQr', 'binanceQr',
      'nagadInstruction', 'bkashInstruction', 'binanceInstruction', 'bankInstruction', 'paypalInstruction', 'paypalEmail',
    ]
    for (const k of paymentSyncFields) {
      if (k in body && body[k] !== undefined) payments[k] = body[k]
    }

    if (body.afkEarningEnabled !== undefined) afk.enabled = body.afkEarningEnabled
    if (body.afkRatePerMinute !== undefined) afk.ratePerMinute = body.afkRatePerMinute
    if (body.afkMinMinutes !== undefined) afk.minMinutes = body.afkMinMinutes
    if (body.afkMaxPerDay !== undefined) afk.maxPerDay = body.afkMaxPerDay

    themeConfig.payments = payments
    themeConfig.afk = afk
    data.themeConfig = themeConfig

    await db.siteSettings.update({ where: { id: s.id }, data })

    return NextResponse.json({ success: true, message: 'Payment settings saved successfully' })
  } catch (e: any) {
    console.error('[Payment PATCH]', e?.message, e?.code)
    return NextResponse.json({
      error: 'Save failed: ' + (e?.message || 'Database error'),
      code: e?.code,
    }, { status: 500 })
  }
}
