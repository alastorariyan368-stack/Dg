import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import os from 'os'
import { exec } from 'child_process'
import { promisify } from 'util'
import fs from 'fs'

const execAsync = promisify(exec)
export const dynamic = 'force-dynamic'

// Lightweight in-process counters that record traffic seen by the App Router.
const g: any = global as any
if (!g.__healthCounters) {
  g.__healthCounters = {
    bootedAt: Date.now(),
    requests: 0,
    requests1m: [] as number[],   // timestamps of last 60s of requests
    errors: 0,
    errors1m: [] as number[],
    threats: [] as Array<{ at: number; ip: string; reason: string; path: string }>,
    activeSockets: 0,
  }
}

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.email) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const me = await db.user.findUnique({ where: { email: session.user.email } })
  if (!me || (me.role !== 'ADMIN' && me.role !== 'SUPER_ADMIN')) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  // System metrics
  const cpus = os.cpus()
  const load = os.loadavg()
  const totalMem = os.totalmem()
  const freeMem = os.freemem()
  const usedMem = totalMem - freeMem
  const memProc = process.memoryUsage()
  const upSec = process.uptime()
  const sysUpSec = os.uptime()

  // CPU usage % over a 100ms sample
  const startCpu = process.cpuUsage()
  await new Promise(r => setTimeout(r, 100))
  const endCpu = process.cpuUsage(startCpu)
  const cpuPercent = ((endCpu.user + endCpu.system) / 1000 / 100) * 100 / cpus.length

  // Disk usage
  let disk: any = { total: 0, used: 0, free: 0, percent: 0 }
  try {
    if (os.platform() === 'win32') {
      const { stdout } = await execAsync(`wmic logicaldisk where "Caption='${process.cwd().split(':')[0]}:'" get size,freespace /value`)
      const lines = stdout.trim().split('\n')
      let free = 0, total = 0
      lines.forEach(line => {
        if (line.startsWith('FreeSpace=')) free = parseInt(line.split('=')[1])
        if (line.startsWith('Size=')) total = parseInt(line.split('=')[1])
      })
      if (total > 0) {
        disk = { total, used: total - free, free, percent: Math.round(((total - free) / total) * 100) }
      }
    } else {
      const { stdout } = await execAsync(`df -k "${process.cwd()}" | tail -1`)
      const parts = stdout.trim().split(/\s+/)
      const total = parseInt(parts[1] || '0') * 1024
      const used = parseInt(parts[2] || '0') * 1024
      const free = parseInt(parts[3] || '0') * 1024
      disk = { total, used, free, percent: total ? Math.round((used / total) * 100) : 0 }
    }
  } catch (e) {
    console.error('Health check disk error:', e)
  }

  // DB metrics
  let db_users = 0, db_orders = 0, db_tickets = 0, db_messages = 0
  try {
    [db_users, db_orders, db_tickets, db_messages] = await Promise.all([
      db.user.count(),
      db.order.count(),
      db.ticket.count(),
      db.privateMessage.count(),
    ])
  } catch {}

  // Trim 1m windows
  const now = Date.now()
  const c = g.__healthCounters
  c.requests1m = c.requests1m.filter((t: number) => now - t < 60_000)
  c.errors1m = c.errors1m.filter((t: number) => now - t < 60_000)
  c.threats = c.threats.filter((t: any) => now - t.at < 24 * 60 * 60 * 1000) // keep 24h

  // Active sockets (best effort)
  try {
    const io = (global as any).io
    if (io) {
      const sockets = await io.fetchSockets()
      c.activeSockets = sockets.length
    }
  } catch {}

  const res = {
    process: {
      pid: process.pid,
      node: process.version,
      uptimeSec: Math.round(upSec),
      bootedAt: c.bootedAt,
      cwd: process.cwd(),
      env: process.env.NODE_ENV || 'development',
    },
    system: {
      hostname: os.hostname(),
      platform: os.platform(),
      arch: os.arch(),
      uptimeSec: Math.round(sysUpSec),
      cpuModel: cpus[0]?.model || 'unknown',
      cpuCount: cpus.length,
      load1: load[0], load5: load[1], load15: load[2],
      cpuPercent: Math.min(100, Math.max(0, cpuPercent)),
    },
    memory: {
      total: totalMem, free: freeMem, used: usedMem,
      percent: Math.round((usedMem / totalMem) * 100),
      proc: memProc,
    },
    disk,
    traffic: {
      totalRequests: c.requests,
      requestsPerMinute: c.requests1m.length,
      totalErrors: c.errors,
      errorsPerMinute: c.errors1m.length,
      activeSockets: c.activeSockets,
    },
    threats: {
      last24h: c.threats.length,
      recent: c.threats.slice(-25).reverse(),
    },
    db: { users: db_users, orders: db_orders, tickets: db_tickets, messages: db_messages },
    timestamp: now,
  }

  return NextResponse.json(res)
}

// POST — log a synthetic threat or clear (admin uses this for testing)
export async function POST(req: Request) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.email) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const me = await db.user.findUnique({ where: { email: session.user.email } })
  if (!me || (me.role !== 'ADMIN' && me.role !== 'SUPER_ADMIN')) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }
  const body = await req.json().catch(() => ({} as any))
  if (body.action === 'clear') {
    g.__healthCounters.threats = []
    g.__healthCounters.errors = 0
    g.__healthCounters.requests = 0
    return NextResponse.json({ ok: true })
  }
  return NextResponse.json({ ok: true })
}
