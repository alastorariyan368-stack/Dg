import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { sendMail, buildNotificationEmailHtml } from '@/lib/mailer'

import { withRetry } from '@/lib/db-retry'

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: rawId } = await params
    const id = rawId.trim()
    console.log(`[REJECT API] Start processing transaction ID: ${id}`)
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      console.log(`[REJECT API] Unauthorized: No session or user ID`)
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Check for admin role - more robust check
    let userRole = (session.user as any).role
    if (!userRole) {
      const dbUser = await db.user.findUnique({ where: { id: session.user.id }, select: { role: true } })
      userRole = dbUser?.role
    }

    console.log(`[REJECT API] User role: ${userRole}`)
    if (!userRole || !['ADMIN', 'SUPER_ADMIN'].includes(userRole.toUpperCase())) {
      console.log(`[REJECT API] Forbidden: User role ${userRole} not allowed`)
      return NextResponse.json({ error: 'Forbidden: Admin only' }, { status: 403 })
    }

    const transaction = await db.transaction.findUnique({
      where: { id },
      include: { 
        user: { select: { id: true, email: true, username: true } },
        externalKey: true 
      }
    })

    if (!transaction) {
      console.log(`[REJECT API] Transaction not found for ID: ${id}`)
      return NextResponse.json({ error: 'Transaction not found' }, { status: 404 })
    }

    console.log(`[REJECT API] Transaction found: status=${transaction.status}`)

    if (transaction.status !== 'PENDING') {
      console.log(`[REJECT API] Transaction is not pending: status=${transaction.status}`)
      return NextResponse.json({ error: 'Transaction is not pending' }, { status: 400 })
    }

    // Update transaction status to rejected with retry
    const updatedTx = await withRetry(async () => {
      return await db.transaction.update({
        where: { id },
        data: { status: 'REJECTED' }
      })
    }, 'Reject Transaction')

    // Email notification to user
    if (transaction.user?.email) {
      const user = transaction.user
      const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'
      const html = buildNotificationEmailHtml({
        username: user.username || 'there',
        title: '❌ Deposit Rejected',
        message: `Your deposit of <strong>৳${transaction.amount}</strong> via <strong>${transaction.method}</strong> has been rejected. This could be due to an incorrect TrxID or mismatched amount. Please contact support if you think this is a mistake.`,
        color: '#ef4444',
        ctaText: 'View Transactions',
        ctaLink: `${appUrl}/deposit`
      })

      sendMail({
        to: user.email,
        subject: 'GfxStore — Deposit Rejected ❌',
        html
      }).catch(console.error)
    }

    // Fire webhook if transaction was created via API key
    if (transaction.externalKey?.webhookUrl) {
      fetch(transaction.externalKey.webhookUrl, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json', 
          'X-GfxStore-Event': 'payment.rejected',
          'X-API-Key': transaction.externalKey.key 
        },
        body: JSON.stringify({ 
          event: 'payment.rejected', 
          transactionId: transaction.id, 
          userId: transaction.userId, 
          amount: transaction.amount, 
          method: transaction.method, 
          status: 'REJECTED',
          reference: transaction.reference
        }),
      }).catch(err => console.error('Webhook failed:', err))
    }

    return NextResponse.json({ success: true, transaction: updatedTx })
  } catch (error) {
    console.error('Error rejecting transaction:', error)
    return NextResponse.json({ error: 'Failed to reject transaction' }, { status: 500 })
  }
}
