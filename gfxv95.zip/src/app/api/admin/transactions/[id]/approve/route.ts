import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { sendMail, buildNotificationEmailHtml } from '@/lib/mailer'

import { withRetry } from '@/lib/db-retry'

const BDT_TO_USD_RATE = 120

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id: rawId } = await params
    const id = rawId.trim()
    console.log(`[APPROVE API] Start processing transaction ID: ${id}`)
    const session = await getServerSession(authOptions)
    
    if (!session?.user?.id) {
      console.log(`[APPROVE API] Unauthorized: No session or user ID`)
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    // Check for admin role - more robust check
    let userRole = (session.user as any).role
    if (!userRole) {
      const dbUser = await db.user.findUnique({ where: { id: session.user.id }, select: { role: true } })
      userRole = dbUser?.role
    }

    console.log(`[APPROVE API] User role: ${userRole}`)
    if (!userRole || !['ADMIN', 'SUPER_ADMIN'].includes(userRole.toUpperCase())) {
      console.log(`[APPROVE API] Forbidden: User role ${userRole} not allowed`)
      return NextResponse.json({ error: 'Forbidden: Admin only' }, { status: 403 })
    }

    const transaction = await db.transaction.findUnique({
      where: { id },
      include: { 
        user: { select: { id: true, email: true, username: true } },
        externalKey: true 
      }
    })

    if (!transaction) {
      console.log(`[APPROVE API] Transaction not found for ID: ${id}`)
      return NextResponse.json({ error: 'Transaction not found' }, { status: 404 })
    }

    console.log(`[APPROVE API] Transaction found: status=${transaction.status}, amount=${transaction.amount}, method=${transaction.method}`)

    if (transaction.status !== 'PENDING') {
      console.log(`[APPROVE API] Transaction is not pending: status=${transaction.status}`)
      return NextResponse.json({ error: 'Transaction is not pending' }, { status: 400 })
    }

    let creditAmount = transaction.amount
    if (['NAGAD', 'BKASH'].includes(transaction.method.toUpperCase())) {
      creditAmount = parseFloat((transaction.amount / BDT_TO_USD_RATE).toFixed(2))
    }

    console.log(`[APPROVE API] Updating transaction ${id} and user ${transaction.userId} balance by ${creditAmount}`)

    // Execute updates sequentially with retry logic for better reliability
    const updatedTx = await withRetry(async () => {
      return await db.transaction.update({
        where: { id },
        data: { status: 'COMPLETED' }
      })
    }, 'Approve Transaction - Status Update')

    const updatedUser = await withRetry(async () => {
      return await db.user.update({
        where: { id: transaction.userId },
        data: { walletBalance: { increment: creditAmount } }
      })
    }, 'Approve Transaction - Balance Update')

    console.log(`[APPROVE API] Success! New balance for ${transaction.userId}: ${updatedUser.walletBalance}`)

    // In-app notification
    if ((global as any).sendNotification) {
      try {
        await (global as any).sendNotification(transaction.userId, {
          title: '💰 Deposit Approved!',
          content: `Your deposit of ${transaction.amount} ${transaction.method} has been approved! You received ${creditAmount} USD to your wallet.`,
          type: 'DEPOSIT_APPROVED'
        })
      } catch (notifError) {
        console.error('Failed to send notification:', notifError)
      }
    }

    // Email notification
    if (transaction.user?.email) {
      const user = transaction.user
      const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'
      const html = buildNotificationEmailHtml({
        username: user.username || 'there',
        title: '💰 Deposit Approved!',
        message: `Your deposit of <strong>৳${transaction.amount}</strong> via <strong>${transaction.method}</strong> has been approved. <strong style="color:#22c55e;">$${creditAmount} USD</strong> has been added to your wallet instantly.`,
        color: '#059669',
        ctaText: 'View Wallet',
        ctaLink: `${appUrl}/wallet`
      })
      sendMail({
        to: user.email,
        subject: 'GfxStore — Deposit Approved 💰',
        html
      }).catch(console.error)
    }

    // Fire webhook if transaction was created via API key
    if (transaction.externalKey?.webhookUrl) {
      fetch(transaction.externalKey.webhookUrl, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json', 
          'X-GfxStore-Event': 'payment.approved',
          'X-API-Key': transaction.externalKey.key 
        },
        body: JSON.stringify({ 
          event: 'payment.approved', 
          transactionId: transaction.id, 
          userId: transaction.userId, 
          amount: transaction.amount, 
          creditedAmount: creditAmount,
          method: transaction.method, 
          status: 'COMPLETED',
          reference: transaction.reference
        }),
      }).catch(err => console.error('Webhook failed:', err))
    }

    return NextResponse.json({
      success: true,
      transaction: updatedTx,
      conversionInfo: {
        originalAmount: transaction.amount,
        method: transaction.method,
        creditedAmount: creditAmount,
        exchangeRate: `1 USD = ${BDT_TO_USD_RATE} BDT`
      }
    })
  } catch (error) {
    console.error('Error approving transaction:', error)
    return NextResponse.json({ error: 'Failed to approve transaction' }, { status: 500 })
  }
}
