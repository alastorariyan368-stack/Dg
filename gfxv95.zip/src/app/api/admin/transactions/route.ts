import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

function isAdmin(session: any) {
  return ['ADMIN', 'SUPER_ADMIN'].includes(session?.user?.role || '')
}

export async function GET() {
  try {
    const session = await getServerSession(authOptions)
    if (!session || !isAdmin(session)) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const transactions = await db.transaction.findMany({
      include: { 
        user: { 
          select: { 
            id: true,
            username: true, 
            email: true,
            walletBalance: true
          } 
        } 
      },
      orderBy: { createdAt: 'desc' }
    })

    return NextResponse.json(transactions)
  } catch (error) {
    console.error('Error fetching transactions:', error)
    return NextResponse.json({ error: 'Failed to fetch transactions' }, { status: 500 })
  }
}
