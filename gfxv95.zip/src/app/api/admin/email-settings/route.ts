import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { testEmailConfig } from '@/lib/mailer'

function isAdmin(session: any) {
  return ['ADMIN', 'SUPER_ADMIN'].includes(session?.user?.role || '')
}

export async function GET() {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id || !isAdmin(session)) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    const settings = await db.siteSettings.findFirst({ select: { smtpConfig: true } })
    const cfg: any = settings?.smtpConfig || {}

    // Mask password/apiKey
    const safe = { ...cfg }
    if (safe.pass) safe.pass = '****' + String(safe.pass).slice(-4)
    if (safe.resendKey) safe.resendKey = 're_****' + String(safe.resendKey).slice(-6)

    return NextResponse.json({ config: safe })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id || !isAdmin(session)) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    const body = await request.json()
    const { provider, host, port, secure, user, pass, resendKey, fromName, fromAddress } = body

    const existing = await db.siteSettings.findFirst({ select: { id: true, smtpConfig: true } })
    const existingCfg: any = existing?.smtpConfig || {}

    const newCfg: any = { provider, fromName, fromAddress }

    if (provider === 'smtp' || provider === 'gmail') {
      newCfg.host = host || (provider === 'gmail' ? 'smtp.gmail.com' : '')
      newCfg.port = Number(port) || 587
      newCfg.secure = !!secure
      newCfg.user = user || ''
      // Keep existing pass if not provided
      if (pass && !pass.startsWith('****')) {
        newCfg.pass = pass
      } else {
        newCfg.pass = existingCfg.pass || ''
      }
    }

    if (provider === 'resend') {
      if (resendKey && !resendKey.startsWith('re_****')) {
        newCfg.resendKey = resendKey
      } else {
        newCfg.resendKey = existingCfg.resendKey || ''
      }
    }

    if (existing) {
      await db.siteSettings.update({
        where: { id: existing.id },
        data: { smtpConfig: newCfg },
      })
    } else {
      await db.siteSettings.create({ data: { smtpConfig: newCfg } })
    }

    return NextResponse.json({ success: true })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id || !isAdmin(session)) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    const body = await request.json()
    const { testTo } = body

    if (!testTo) return NextResponse.json({ error: 'testTo required' }, { status: 400 })

    const settings = await db.siteSettings.findFirst({ select: { smtpConfig: true } })
    const cfg: any = settings?.smtpConfig

    if (!cfg?.provider) {
      return NextResponse.json({ error: 'No email config saved yet' }, { status: 400 })
    }

    const result = await testEmailConfig(cfg, testTo)
    return NextResponse.json(result)
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}
