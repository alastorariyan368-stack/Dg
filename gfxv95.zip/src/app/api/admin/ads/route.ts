import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  if (!['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  try {
    const ads = await db.ad.findMany({ orderBy: { sortOrder: 'asc' } })
    return NextResponse.json({ ads })
  } catch (error) {
    return NextResponse.json({ ads: [] })
  }
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  if (!['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  try {
    const body = await req.json()
    const { title, description, imageUrl, linkUrl, position, isActive, sortOrder, startDate, endDate } = body
    if (!title) return NextResponse.json({ error: 'Title is required' }, { status: 400 })

    const ad = await db.ad.create({
      data: {
        title,
        description: description || null,
        imageUrl: imageUrl || null,
        linkUrl: linkUrl || null,
        position: position || 'homepage',
        isActive: isActive !== false,
        sortOrder: sortOrder || 0,
        startDate: startDate ? new Date(startDate) : null,
        endDate: endDate ? new Date(endDate) : null,
      }
    })
    return NextResponse.json({ ad })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create ad' }, { status: 500 })
  }
}
