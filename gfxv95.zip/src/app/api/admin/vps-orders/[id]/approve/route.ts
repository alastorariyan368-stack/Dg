import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { createGfxVps, ensureGfxUser, isGfxConfigured } from '@/lib/gfx-panel'

async function pteroAdminReq(panelUrl: string, apiKey: string, path: string, method = 'GET', body?: any) {
  const url = `${panelUrl.replace(/\/$/, '')}/api/application${path}`
  const res = await fetch(url, {
    method,
    headers: { 'Authorization': `Bearer ${apiKey}`, 'Accept': 'application/json', 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  })
  const data = await res.json().catch(() => ({}))
  return { ok: res.ok, status: res.status, data }
}

async function ensurePteroUser(pteroUrl: string, adminKey: string, email: string, username: string) {
  const listRes = await pteroAdminReq(pteroUrl, adminKey, `/users?filter[email]=${encodeURIComponent(email)}`)
  const existing = listRes.data?.data?.[0]
  if (existing) return { pteroUserId: existing.attributes.id, password: null }

  const password = Math.random().toString(36).slice(-10) + '!A1'
  const createRes = await pteroAdminReq(pteroUrl, adminKey, '/users', 'POST', {
    email, username: username.replace(/[^a-z0-9_]/gi, '_').toLowerCase().slice(0, 20),
    first_name: username, last_name: 'User', password,
  })
  if (!createRes.ok) throw new Error(`Failed to create Pterodactyl user: ${JSON.stringify(createRes.data)}`)
  return { pteroUserId: createRes.data.attributes.id, password }
}

async function createPteroServer(pteroUrl: string, adminKey: string, cfg: any, pteroUserId: number, specs: any, serverName: string) {
  const nestId = parseInt(specs?.pteroNestId || cfg.pteroNestId || '1')
  const eggId = parseInt(specs?.pteroEggId || cfg.pteroEggId || '1')
  const eggRes = await pteroAdminReq(pteroUrl, adminKey, `/nests/${nestId}/eggs/${eggId}?include=variables`)
  const egg = eggRes.data?.attributes || {}
  const environment = egg.relationships?.variables?.data?.reduce((acc: any, v: any) => {
    acc[v.attributes.env_variable] = v.attributes.default_value || ''
    return acc
  }, {}) || {}

  const memory = parseInt(specs?.ram) || 1024
  const disk = parseInt(specs?.disk) || 10240
  const cpu = parseInt(specs?.cpu) || 100

  const r = await pteroAdminReq(pteroUrl, adminKey, '/servers', 'POST', {
    name: serverName,
    user: pteroUserId,
    egg: eggId,
    docker_image: specs?.pteroDockerImage || egg.docker_image || cfg.pteroDockerImage || 'ghcr.io/pterodactyl/yolks:java_21',
    startup: specs?.pteroStartupCommand || egg.startup || cfg.pteroStartupCommand || 'java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}',
    environment,
    limits: { memory, swap: 0, disk, io: 500, cpu },
    feature_limits: { databases: 1, backups: 2, allocations: 1 },
    deploy: { locations: [parseInt(specs?.pteroLocationId || cfg.pteroLocationId || '1')], dedicated_ip: false, port_range: [] },
    start_on_completion: false,
    skip_scripts: false,
  })
  return r
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id || (session.user.role !== 'ADMIN' && session.user.role !== 'SUPER_ADMIN')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { id } = await params
    const body = await request.json()
    const { serverInfo, autoPtero, autoGfx, durationDays, expiresAt: expiresAtRaw } = body

    const order = await db.vPSOrder.findUnique({
      where: { id },
      include: { plan: true, user: { select: { id: true, username: true, email: true } } }
    })
    if (!order) return NextResponse.json({ error: 'Order not found' }, { status: 404 })
    if (order.status === 'APPROVED') return NextResponse.json({ error: 'Order already approved' }, { status: 400 })

    const cfg = await db.siteSettings.findFirst()
    const pteroUrl = cfg?.pteroUrl || ''
    const pteroAdminApiKey = cfg?.pteroAdminApiKey || ''
    const pteroEnabled = !!(pteroUrl && pteroAdminApiKey)

    let pteroServerId: string | null = null
    let pteroServerUuid: string | null = null
    let pteroServerIdentifier: string | null = null
    let pteroPassword: string | null = null
    let finalServerInfo = serverInfo || {}
    let gfxProvisioned = false
    let gfxVpsId: string | null = null
    let gfxContainerName: string | null = null
    let gfxUserId: string | number | null = null
    let gfxPassword: string | null = null
    const planSpecs = (order.plan.specs as any) || {}
    const serverType = planSpecs.serverType || 'vps'
    const provisioningErrors: string[] = []

    // Auto-provision on Pterodactyl if enabled
    if (serverType === 'host' && autoPtero) {
      if (!pteroEnabled) {
        return NextResponse.json({ error: 'Pterodactyl is not configured. Set Panel URL and Admin API Key first.' }, { status: 400 })
      }
      try {
        const { pteroUserId, password } = await ensurePteroUser(
          pteroUrl, pteroAdminApiKey, order.user.email, order.user.username
        )
        pteroPassword = password

        const specs = planSpecs
        const serverName = `${order.user.username}-${order.plan.name.replace(/\s+/g, '-').toLowerCase()}`
        const createRes = await createPteroServer(pteroUrl, pteroAdminApiKey, cfg, pteroUserId, specs, serverName)

        if (createRes.ok && createRes.data?.attributes) {
          const srv = createRes.data.attributes
          pteroServerId = String(srv.id)
          pteroServerUuid = srv.uuid
          pteroServerIdentifier = srv.identifier
          finalServerInfo = {
            ...finalServerInfo,
            pteroPanel: pteroUrl,
            pteroIdentifier: srv.identifier,
            pteroUuid: srv.uuid,
            pteroPassword: pteroPassword || '(existing panel account)',
            serverName,
            note: 'Log into the panel to manage your server',
          }
        } else {
          finalServerInfo = { ...finalServerInfo, pteroError: JSON.stringify(createRes.data) }
          provisioningErrors.push(`Pterodactyl server creation failed: ${JSON.stringify(createRes.data)}`)
        }
      } catch (pteroErr: any) {
        finalServerInfo = { ...finalServerInfo, pteroError: pteroErr.message }
        provisioningErrors.push(`Pterodactyl server creation failed: ${pteroErr.message}`)
      }
    }

    if (serverType === 'vps' && autoGfx) {
      if (!isGfxConfigured(cfg)) {
        return NextResponse.json({ error: 'GFX Panel is not configured. Set GFX Panel URL and API Key first.' }, { status: 400 })
      }
      try {
        const specs = planSpecs
        // Sanitize hostname: only lowercase letters, numbers, hyphens
        const hostname = `${order.user.username}-${order.plan.name.replace(/\s+/g, '-').toLowerCase()}`
          .replace(/[^a-z0-9-]/g, '')
          .replace(/-+/g, '-')
          .slice(0, 60) || `vps-${Date.now()}`
        const gfxConfig = cfg!

        // Try to find/create the user in GFX Panel — but don't block VPS creation if it fails
        try {
          const gfxUser = await ensureGfxUser(gfxConfig, {
            username: order.user.username,
            email: order.user.email,
          })
          gfxUserId = gfxUser.userId
          gfxPassword = gfxUser.password
        } catch (userErr: any) {
          console.warn('GFX user find/create failed, falling back to default userId:', userErr.message)
          gfxUserId = specs.gfxUserId || gfxConfig.gfxDefaultUserId || 1
        }

        const createRes = await createGfxVps(gfxConfig, {
          hostname,
          userId: gfxUserId || specs.gfxUserId || gfxConfig.gfxDefaultUserId || 1,
          nodeId: specs.gfxNodeId || gfxConfig.gfxDefaultNodeId || 1,
          osVersion: finalServerInfo?.selectedOs || specs.osVersion || gfxConfig.gfxDefaultOs || 'ubuntu:22.04',
          cpu: specs.cpu || 1,
          ram: specs.ram || 1024,
          // disk in specs is MB; GFX Panel expects GB
          storage: specs.disk ? Math.max(1, Math.ceil(Number(specs.disk) / 1024)) : 10,
        })

        if (createRes.ok && createRes.data?.success !== false) {
          gfxProvisioned = true
          gfxVpsId = String(createRes.data?.vps_id || createRes.data?.vps?.id || createRes.data?.id || '')
          gfxContainerName = createRes.data?.container_name || createRes.data?.vps?.container_name || hostname
          finalServerInfo = {
            ...finalServerInfo,
            gfxPanel: gfxConfig.gfxPanelUrl,
            gfxLoginEmail: order.user.email,
            gfxPassword: gfxPassword || '(existing GFX Panel account password)',
            gfxUserId,
            gfxVpsId,
            gfxContainerName,
            gfxResponse: createRes.data,
            note: 'Your VPS has been provisioned through GFX Panel.',
          }
        } else {
          finalServerInfo = { ...finalServerInfo, gfxError: JSON.stringify(createRes.data) }
          provisioningErrors.push(`GFX VPS creation failed: ${JSON.stringify(createRes.data)}`)
        }
      } catch (gfxErr: any) {
        finalServerInfo = { ...finalServerInfo, gfxError: gfxErr.message }
        provisioningErrors.push(`GFX VPS creation failed: ${gfxErr.message}`)
      }
    }

    // NOTE: Don't block approval if auto-provisioning failed.
    // Still approve the order but include provisioning errors in the server info and response.
    if (provisioningErrors.length > 0) {
      finalServerInfo = {
        ...finalServerInfo,
        provisioningWarnings: provisioningErrors,
        note: (finalServerInfo.note ? finalServerInfo.note + '\n' : '') + 
          'Auto-provisioning encountered issues: ' + provisioningErrors.join('; ') + 
          '. Order still approved — review server info and provision manually if needed.',
      }
    }

    // Calculate expiry
    let expiresAt: Date | null = null
    if (expiresAtRaw) {
      expiresAt = new Date(expiresAtRaw)
    } else if (durationDays && durationDays > 0) {
      expiresAt = new Date(Date.now() + durationDays * 24 * 60 * 60 * 1000)
    } else if (planSpecs.expiresInDays && Number(planSpecs.expiresInDays) > 0) {
      expiresAt = new Date(Date.now() + Number(planSpecs.expiresInDays) * 24 * 60 * 60 * 1000)
    }

    const updated = await db.vPSOrder.update({
      where: { id },
      data: {
        status: 'APPROVED',
        serverInfo: finalServerInfo,
        expiresAt,
        ...(pteroServerId && { pteroServerId, pteroServerUuid, pteroServerIdentifier }),
      }
    })

    // Notification
    await db.notification.create({
      data: {
        userId: order.userId,
        title: '✅ VPS Order Approved',
        content: `Your order for ${order.plan.name} has been approved! ${pteroServerId || gfxProvisioned ? 'Your server has been created on the panel.' : 'Check your messages for server details.'}`,
        type: 'VPS_ORDER_APPROVED',
        vpsOrderId: order.id
      }
    }).catch(() => {})

    if ((global as any).sendNotification) {
      (global as any).sendNotification(order.userId, {
        title: '✅ VPS Order Approved',
        content: `Your ${order.plan.name} server is ready!`,
        type: 'VPS_ORDER_APPROVED'
      }).catch(() => {})
    }

    // DM with server details
    try {
      const adminUser = await db.user.findUnique({ where: { email: session.user.email || '' }, select: { id: true } })
      if (adminUser) {
        let msg = `📦 **Order Approved — ${order.plan.name}**\n\n`
        if (serverType === 'invite') {
          const discordLink = planSpecs.discordLink || finalServerInfo?.discordLink || ''
          msg += `🎮 **Discord Invite Plan**\n`
          if (discordLink) {
            msg += `🔗 **Discord Invite Link:** ${discordLink}\n`
            msg += `\nClick the link above to join the Discord server.`
          } else {
            msg += `\nPlease contact support for your Discord invite link.`
          }
          if (expiresAt) msg += `\n\n⏰ **Expires:** ${expiresAt.toDateString()}`
          // Also update finalServerInfo with discordLink
          finalServerInfo = { ...finalServerInfo, discordLink, note: discordLink ? `Join Discord: ${discordLink}` : 'Contact support for your Discord invite.' }
        } else if (gfxProvisioned) {
          msg += `🖥️ **GFX Panel:** ${cfg?.gfxPanelUrl || ''}\n`
          msg += `📧 **Login Email:** ${order.user.email}\n`
          msg += `🔐 **Panel Password:** \`${gfxPassword || 'Use your existing GFX Panel password'}\`\n`
          if (gfxContainerName) msg += `🔑 **VPS:** ${gfxContainerName}\n`
          if (gfxVpsId) msg += `🆔 **VPS ID:** ${gfxVpsId}\n`
          msg += `\nGo to your Services page to view and manage your VPS.`
          if (expiresAt) msg += `\n\n⏰ **Expires:** ${expiresAt.toDateString()}`
        } else if (pteroServerId) {
          msg += `🖥️ **Panel:** ${pteroUrl}\n`
          msg += `🔑 **Server ID:** ${pteroServerIdentifier}\n`
          if (pteroPassword) msg += `🔐 **Panel Password:** \`${pteroPassword}\`\n`
          msg += `\nLog in at the panel URL above to start and manage your server.`
          if (expiresAt) msg += `\n\n⏰ **Expires:** ${expiresAt.toDateString()}`
        } else if (serverInfo) {
          msg += typeof serverInfo === 'string' ? serverInfo : JSON.stringify(serverInfo, null, 2)
        }

        const message = await db.privateMessage.create({
          data: { senderId: adminUser.id, receiverId: order.userId, content: msg, vpsOrderInfo: finalServerInfo }
        })
        const msgio = (global as any).messagesIo || (global as any).io
        if (msgio) {
          msgio.to(`user:${order.userId}`).emit('newPrivateMessage', message)
        }
      }
    } catch {}

    return NextResponse.json({ success: true, order: updated, pteroProvisioned: !!pteroServerId, gfxProvisioned })
  } catch (error) {
    console.error('Error approving VPS order:', error)
    return NextResponse.json({ error: 'Failed to approve order' }, { status: 500 })
  }
}
