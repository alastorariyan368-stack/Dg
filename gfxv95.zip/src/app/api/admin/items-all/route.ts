import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { withRetry } from '@/lib/db-retry'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user || (session.user.role !== 'ADMIN' && session.user.role !== 'SUPER_ADMIN')) {
      return NextResponse.json([], { status: 200 })
    }

    const searchParams = request.nextUrl.searchParams
    const status = searchParams.get('status')
    const search = searchParams.get('search')
    const categoryId = searchParams.get('categoryId')
    const limit = parseInt(searchParams.get('limit') || '50')
    const offset = parseInt(searchParams.get('offset') || '0')

    const where: any = {}
    if (status) where.status = status
    if (categoryId) where.categoryId = categoryId
    if (search) {
      where.title = { contains: search, mode: 'insensitive' }
    }

    const items = await withRetry(
      () => db.item.findMany({
        where,
        include: {
          author: { select: { id: true, username: true } },
          category: { select: { id: true, name: true } }
        },
        orderBy: { createdAt: 'desc' },
        take: limit,
        skip: offset
      }),
      'Fetch all items for admin'
    )

    return NextResponse.json(items || [])
  } catch (error) {
    console.error('Error fetching admin items:', error)
    return NextResponse.json([], { status: 200 })
  }
}
