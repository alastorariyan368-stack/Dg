import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  
  const userRole = session.user.role || ''
  if (!['ADMIN', 'SUPER_ADMIN'].includes(userRole)) {
    console.error(`Referrals access denied for user ${session.user.id} with role: ${userRole}`)
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  try {
    const totalReferrals = await db.user.count({ where: { referredById: { not: null } } })
    const totalEarnings = await db.user.aggregate({ _sum: { referralEarnings: true } })

    const topReferrers = await db.user.findMany({
      where: { referralCode: { not: null } },
      select: {
        id: true,
        username: true,
        avatar: true,
        referralCode: true,
        referralEarnings: true,
        _count: { select: { referrals: true } }
      },
      orderBy: { referralEarnings: 'desc' },
      take: 20
    })

    const recentReferrals = await db.user.findMany({
      where: { referredById: { not: null } },
      select: {
        id: true,
        username: true,
        avatar: true,
        createdAt: true,
        referredBy: { select: { username: true, referralCode: true } }
      },
      orderBy: { createdAt: 'desc' },
      take: 20
    })

    return NextResponse.json({
      totalReferrals,
      totalEarnings: totalEarnings._sum.referralEarnings || 0,
      topReferrers,
      recentReferrals
    })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch referral stats' }, { status: 500 })
  }
}
