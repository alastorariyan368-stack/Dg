import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { sendMail, buildNotificationEmailHtml } from '@/lib/mailer'

function isAdmin(role?: string) { return ['ADMIN', 'SUPER_ADMIN'].includes(role || '') }

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id || !isAdmin(session.user.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const requests = await db.withdrawRequest.findMany({
    include: { user: { select: { id: true, username: true, email: true, avatar: true, walletBalance: true } } },
    orderBy: { createdAt: 'desc' }
  })

  return NextResponse.json({ requests })
}

export async function PATCH(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id || !isAdmin(session.user.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const { id, status, adminNote } = await req.json()
  if (!id || !status) return NextResponse.json({ error: 'ID and status required' }, { status: 400 })

  const request = await db.withdrawRequest.findUnique({
    where: { id },
    include: { user: { select: { email: true, username: true } } }
  })
  if (!request) return NextResponse.json({ error: 'Request not found' }, { status: 404 })

  const updated = await db.$transaction(async (tx) => {
    const upd = await tx.withdrawRequest.update({
      where: { id },
      data: { status, adminNote, processedAt: new Date() }
    })

    if (status === 'REJECTED') {
      await tx.user.update({ where: { id: request.userId }, data: { walletBalance: { increment: request.amount } } })
    }

    await tx.notification.create({
      data: {
        userId: request.userId,
        type: 'TRANSACTION_APPROVED' as any,
        title: `Withdrawal ${status.toLowerCase()}`,
        content: status === 'APPROVED'
          ? `Your withdrawal of $${request.amount} has been approved and will be sent to your ${request.method} account.`
          : `Your withdrawal of $${request.amount} was rejected. ${adminNote || ''} The amount has been refunded.`
      }
    })

    return upd
  })

  // Send email notification
  if (request.user?.email) {
    const isApproved = status === 'APPROVED'
    const html = buildNotificationEmailHtml({
      username: request.user.username || 'there',
      title: isApproved ? '✅ Withdrawal Approved' : '❌ Withdrawal Rejected',
      message: isApproved
        ? `Your withdrawal request of <strong>$${request.amount}</strong> via <strong>${request.method}</strong> has been <strong style="color:#22c55e;">approved</strong>. The funds will be sent to your account shortly.`
        : `Your withdrawal request of <strong>$${request.amount}</strong> via <strong>${request.method}</strong> has been <strong style="color:#ef4444;">rejected</strong>.${adminNote ? `<br/><br/>Reason: ${adminNote}` : ''}<br/><br/>The amount has been refunded to your wallet.`,
      color: isApproved ? '#059669' : '#dc2626',
      ctaText: 'View Wallet',
      ctaLink: `${process.env.NEXT_PUBLIC_APP_URL || (process.env.REPLIT_DOMAINS ? `https://${process.env.REPLIT_DOMAINS.split(',')[0]}` : 'http://localhost:5000')}/wallet`
    })
    sendMail({
      to: request.user.email,
      subject: isApproved ? 'GfxStore — Withdrawal Approved' : 'GfxStore — Withdrawal Rejected',
      html
    }).catch(console.error)
  }

  return NextResponse.json({ request: updated })
}
