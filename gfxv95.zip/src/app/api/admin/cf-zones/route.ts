import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

async function requireAdmin() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.email) return null
  const user = await db.user.findUnique({ where: { email: session.user.email } })
  if (!user || !['ADMIN', 'SUPER_ADMIN'].includes(user.role)) return null
  return user
}

// GET — fetch all zones from Cloudflare using stored credentials
export async function GET() {
  try {
    const admin = await requireAdmin()
    if (!admin) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const settings = await db.siteSettings.findFirst()
    if (!settings?.cfAccountId || !settings?.cfApiToken) {
      return NextResponse.json({ error: 'Cloudflare credentials not configured' }, { status: 400 })
    }

    // Fetch all zones from Cloudflare
    const res = await fetch(
      `https://api.cloudflare.com/client/v4/zones?account.id=${settings.cfAccountId}&per_page=50&status=active`,
      {
        headers: {
          'Authorization': `Bearer ${settings.cfApiToken}`,
          'Content-Type': 'application/json'
        }
      }
    )

    const data = await res.json()
    if (!data.success) {
      return NextResponse.json({ error: data.errors?.[0]?.message || 'Cloudflare API error' }, { status: 400 })
    }

    const zones = (data.result || []).map((z: any) => ({
      id: z.id,
      name: z.name,
      status: z.status,
      plan: z.plan?.name || 'Free'
    }))

    // Also return currently allowed zones from settings
    const allowedZones = (settings.cfAllowedZones as any[]) || []

    return NextResponse.json({ zones, allowedZones })
  } catch (error: any) {
    return NextResponse.json({ error: error?.message || 'Failed to fetch zones' }, { status: 500 })
  }
}

// POST — save which zones are allowed for user tunnels
export async function POST(request: NextRequest) {
  try {
    const admin = await requireAdmin()
    if (!admin) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { allowedZones, cfAccountId, cfApiToken, maxTunnelsPerUser } = await request.json()

    const updateData: any = {}
    if (allowedZones !== undefined) updateData.cfAllowedZones = allowedZones
    if (cfAccountId !== undefined) updateData.cfAccountId = cfAccountId?.trim() || null
    if (cfApiToken !== undefined && !String(cfApiToken).startsWith('****')) {
      updateData.cfApiToken = cfApiToken?.trim() || null
    }
    if (maxTunnelsPerUser !== undefined) updateData.maxTunnelsPerUser = parseInt(String(maxTunnelsPerUser)) || 2

    const settings = await db.siteSettings.findFirst()
    if (settings) {
      await db.siteSettings.update({ where: { id: settings.id }, data: updateData })
    } else {
      await db.siteSettings.create({ data: updateData })
    }

    return NextResponse.json({ success: true })
  } catch (error: any) {
    return NextResponse.json({ error: error?.message || 'Failed to save' }, { status: 500 })
  }
}
