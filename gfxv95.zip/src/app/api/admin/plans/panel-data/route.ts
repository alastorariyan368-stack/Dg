import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { getGfxInfo, isGfxConfigured } from '@/lib/gfx-panel'

async function requireAdmin() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id || (session.user.role !== 'ADMIN' && session.user.role !== 'SUPER_ADMIN')) return null
  return session
}

async function pteroReq(panelUrl: string, apiKey: string, path: string) {
  const res = await fetch(`${panelUrl.replace(/\/$/, '')}/api/application${path}`, {
    headers: {
      Accept: 'Application/vnd.pterodactyl.v1+json',
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
    },
    cache: 'no-store',
  })
  const data = await res.json().catch(() => ({}))
  return res.ok ? data?.data || [] : []
}

export async function GET() {
  try {
    const session = await requireAdmin()
    if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const settings = await db.siteSettings.findFirst()
    const pteroConfigured = !!(settings?.pteroUrl && settings?.pteroAdminApiKey)
    const gfxConfigured = isGfxConfigured(settings)

    const [locations, nodes, nests, gfxInfo] = await Promise.all([
      pteroConfigured ? pteroReq(settings!.pteroUrl!, settings!.pteroAdminApiKey!, '/locations') : Promise.resolve([]),
      pteroConfigured ? pteroReq(settings!.pteroUrl!, settings!.pteroAdminApiKey!, '/nodes') : Promise.resolve([]),
      pteroConfigured ? pteroReq(settings!.pteroUrl!, settings!.pteroAdminApiKey!, '/nests') : Promise.resolve([]),
      gfxConfigured ? getGfxInfo(settings!).catch(() => null) : Promise.resolve(null),
    ])

    const nestEggs = await Promise.all((Array.isArray(nests) ? nests : []).map(async (nest: any) => {
      const id = nest?.attributes?.id
      if (!id || !pteroConfigured) return { nestId: id, eggs: [] }
      return { nestId: String(id), eggs: await pteroReq(settings!.pteroUrl!, settings!.pteroAdminApiKey!, `/nests/${id}/eggs`) }
    }))

    return NextResponse.json({
      pterodactyl: {
        configured: pteroConfigured,
        panelUrl: settings?.pteroUrl || '',
        locations,
        nodes,
        nests,
        eggsByNest: Object.fromEntries(nestEggs.map((item) => [item.nestId, item.eggs])),
        defaults: {
          locationId: settings?.pteroLocationId || '1',
          nestId: settings?.pteroNestId || '1',
          eggId: settings?.pteroEggId || '1',
          dockerImage: settings?.pteroDockerImage || '',
          startupCommand: settings?.pteroStartupCommand || '',
        },
      },
      gfx: {
        configured: gfxConfigured,
        panelUrl: settings?.gfxPanelUrl || '',
        nodes: gfxInfo?.nodes?.data?.nodes || gfxInfo?.nodes?.data?.data || [],
        vps: gfxInfo?.vps?.data?.vps || gfxInfo?.vps?.data?.data || [],
        defaults: {
          nodeId: settings?.gfxDefaultNodeId || '1',
          userId: settings?.gfxDefaultUserId || '1',
          os: settings?.gfxDefaultOs || 'ubuntu:22.04',
        },
      },
    })
  } catch (error) {
    console.error('Error loading plan panel data:', error)
    return NextResponse.json({ error: 'Failed to load panel data' }, { status: 500 })
  }
}
