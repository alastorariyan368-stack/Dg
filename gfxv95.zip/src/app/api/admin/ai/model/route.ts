import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function GET() {
  const session = await getServerSession(authOptions)
  const role = (session?.user as any)?.role
  if (!session || !['ADMIN', 'SUPER_ADMIN'].includes(role)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    let model = await db.aIModel.findUnique({ where: { name: 'GFXV1' } })
    if (!model) {
      model = await db.aIModel.create({
        data: {
          name: 'GFXV1',
          description: 'GFXV1 Multimodal AI',
          dailyLimit: 50,
          monthlyLimit: 1000
        }
      })
    }
    return NextResponse.json(model)
  } catch (error) {
    return NextResponse.json({ error: 'Failed' }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest) {
  const session = await getServerSession(authOptions)
  const role = (session?.user as any)?.role
  if (!session || !['ADMIN', 'SUPER_ADMIN'].includes(role)) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const { isActive, dailyLimit, monthlyLimit, description, trainingData } = await req.json()
    
    const updated = await db.aIModel.update({
      where: { name: 'GFXV1' },
      data: {
        isActive,
        dailyLimit,
        monthlyLimit,
        description,
        trainingData
      }
    })

    return NextResponse.json(updated)
  } catch (error) {
    return NextResponse.json({ error: 'Failed' }, { status: 500 })
  }
}
