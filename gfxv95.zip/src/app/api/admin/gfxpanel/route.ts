import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { getGfxInfo, gfxPanelRequest, isGfxConfigured } from '@/lib/gfx-panel'

async function requireAdmin() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id || (session.user.role !== 'ADMIN' && session.user.role !== 'SUPER_ADMIN')) {
    return null
  }
  return session
}

async function getSettings() {
  let settings = await db.siteSettings.findFirst()
  if (!settings) {
    settings = await db.siteSettings.create({ data: {} })
  }
  return settings
}

export async function GET() {
  try {
    const session = await requireAdmin()
    if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const settings = await getSettings()
    const configured = isGfxConfigured(settings)
    let panelInfo: any = null

    if (configured) {
      panelInfo = await getGfxInfo(settings).catch((error: unknown) => ({ error: error instanceof Error ? error.message : 'Failed to load panel info' }))
    }

    return NextResponse.json({
      configured,
      config: {
        gfxPanelUrl: settings.gfxPanelUrl || '',
        gfxDefaultNodeId: settings.gfxDefaultNodeId || '1',
        gfxDefaultOs: settings.gfxDefaultOs || 'ubuntu:22.04',
        gfxDefaultUserId: settings.gfxDefaultUserId || '1',
        hasApiKey: !!settings.gfxPanelApiKey,
      },
      panelInfo,
    })
  } catch (error) {
    console.error('Error loading GFX Panel config:', error)
    return NextResponse.json({ error: 'Failed to load GFX Panel config' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await requireAdmin()
    if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const body = await request.json()
    const action = body.action || 'save'
    const settings = await getSettings()

    if (action === 'test') {
      const cfg = {
        gfxPanelUrl: body.gfxPanelUrl || settings.gfxPanelUrl,
        gfxPanelApiKey: body.gfxPanelApiKey || settings.gfxPanelApiKey,
      }
      const [info, nodes] = await Promise.all([
        gfxPanelRequest(cfg, '/info'),
        gfxPanelRequest(cfg, '/nodes'),
      ])
      return NextResponse.json({
        ok: info.ok && nodes.ok && nodes.data?.success !== false,
        status: nodes.status,
        data: {
          info: info.data,
          nodes: nodes.data,
        },
      })
    }

    const updated = await db.siteSettings.update({
      where: { id: settings.id },
      data: {
        gfxPanelUrl: String(body.gfxPanelUrl || '').trim() || null,
        gfxPanelApiKey: body.gfxPanelApiKey ? String(body.gfxPanelApiKey).trim() : settings.gfxPanelApiKey,
        gfxDefaultNodeId: String(body.gfxDefaultNodeId || '1'),
        gfxDefaultOs: String(body.gfxDefaultOs || 'ubuntu:22.04'),
        gfxDefaultUserId: String(body.gfxDefaultUserId || '1'),
      },
    })

    return NextResponse.json({
      success: true,
      config: {
        gfxPanelUrl: updated.gfxPanelUrl || '',
        gfxDefaultNodeId: updated.gfxDefaultNodeId || '1',
        gfxDefaultOs: updated.gfxDefaultOs || 'ubuntu:22.04',
        gfxDefaultUserId: updated.gfxDefaultUserId || '1',
        hasApiKey: !!updated.gfxPanelApiKey,
      },
    })
  } catch (error) {
    console.error('Error saving GFX Panel config:', error)
    return NextResponse.json({ error: error instanceof Error ? error.message : 'Failed to save GFX Panel config' }, { status: 500 })
  }
}
