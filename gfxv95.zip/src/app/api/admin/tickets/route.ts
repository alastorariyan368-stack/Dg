import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.email) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const me = await db.user.findUnique({ where: { email: session.user.email } })
  if (!me || (me.role !== 'ADMIN' && me.role !== 'SUPER_ADMIN')) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const status = req.nextUrl.searchParams.get('status') || ''
  const q = req.nextUrl.searchParams.get('q') || ''
  const where: any = {}
  if (status) where.status = status
  if (q) where.OR = [
    { subject: { contains: q, mode: 'insensitive' } },
    { description: { contains: q, mode: 'insensitive' } },
    { user: { username: { contains: q, mode: 'insensitive' } } },
    { user: { email: { contains: q, mode: 'insensitive' } } },
  ]

  const tickets = await db.ticket.findMany({
    where,
    orderBy: [{ status: 'asc' }, { updatedAt: 'desc' }],
    include: {
      user: { select: { id: true, username: true, avatar: true, email: true } },
      _count: { select: { messages: true } },
    },
    take: 200,
  })
  const counts = await db.ticket.groupBy({ by: ['status'], _count: true })
  return NextResponse.json({ tickets, counts })
}
