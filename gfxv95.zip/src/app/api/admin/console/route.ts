import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'
import { exec } from 'child_process'
import { promisify } from 'util'

const execAsync = promisify(exec)

async function requireAdmin() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.email) return null
  const user = await db.user.findUnique({ where: { email: session.user.email } })
  if (!user || !['ADMIN', 'SUPER_ADMIN'].includes(user.role)) return null
  return user
}

export async function POST(request: NextRequest) {
  try {
    const admin = await requireAdmin()
    if (!admin) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { command, cwd } = await request.json()
    if (!command) return NextResponse.json({ error: 'Command required' }, { status: 400 })

    const BLOCKED = ['rm -rf /', 'mkfs', ':(){:|:&};:', 'dd if=', 'shutdown', 'reboot', 'halt', 'poweroff']
    if (BLOCKED.some(b => command.includes(b))) {
      return NextResponse.json({ stdout: '', stderr: 'Command blocked for safety', exitCode: 1 })
    }

    try {
      const { stdout, stderr } = await execAsync(command, {
        cwd: cwd || process.cwd(),
        timeout: 30000,
        maxBuffer: 1024 * 1024 * 5,
        env: { ...process.env, TERM: 'xterm-256color' }
      })
      return NextResponse.json({ stdout: stdout || '', stderr: stderr || '', exitCode: 0 })
    } catch (err: any) {
      return NextResponse.json({
        stdout: err.stdout || '',
        stderr: err.stderr || err.message || 'Command failed',
        exitCode: err.code || 1
      })
    }
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }
}
