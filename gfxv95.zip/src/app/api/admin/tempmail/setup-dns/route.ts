import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import * as net from 'net'

async function requireAdmin() {
  const session = await getServerSession(authOptions)
  if (!session?.user || !['ADMIN', 'SUPER_ADMIN'].includes(session.user.role as string)) return null
  return session
}

async function getPublicIp(): Promise<string> {
  for (const url of ['https://api.ipify.org?format=json', 'https://ipinfo.io/json']) {
    try {
      const r = await fetch(url, { signal: AbortSignal.timeout(3000) })
      const j = await r.json() as any
      const ip = j.ip || j.IPv4
      if (ip && net.isIPv4(ip)) return ip
    } catch {}
  }
  return ''
}

// POST /api/admin/tempmail/setup-dns — manually trigger DNS auto-setup
export async function POST() {
  if (!await requireAdmin()) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const settings = await db.siteSettings.findFirst({ select: { cfApiToken: true, cfAccountId: true } })
  if (!settings?.cfApiToken || !settings?.cfAccountId) {
    return NextResponse.json({ error: 'Cloudflare credentials not set. Go to Admin → Zero Trust → add CF Account ID + API Token.' }, { status: 400 })
  }

  const domains = await db.tempMailDomain.findMany({ where: { isActive: true } })
  if (domains.length === 0) {
    return NextResponse.json({ error: 'No active mail domains. Add one first.' }, { status: 400 })
  }

  const serverIp = await getPublicIp()
  if (!serverIp) return NextResponse.json({ error: 'Could not detect server public IP' }, { status: 500 })

  const results: any[] = []

  for (const domain of domains) {
    const token = settings.cfApiToken!
    const accountId = settings.cfAccountId!
    const cfHeaders = { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }

    // Find zone
    const zonesRes = await fetch(
      `https://api.cloudflare.com/client/v4/zones?account.id=${accountId}&per_page=50&status=active`,
      { headers: cfHeaders }
    )
    const zonesData = await zonesRes.json() as any
    const zone = (zonesData.result || []).find((z: any) => domain.domain.endsWith(z.name))
    if (!zone) { results.push({ domain: domain.domain, error: 'Zone not found in Cloudflare' }); continue }

    const zoneId = zone.id
    const existingRes = await fetch(
      `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records?name=${domain.domain}&per_page=20`,
      { headers: cfHeaders }
    )
    const existingData = await existingRes.json() as any
    const existing: any[] = existingData.result || []
    const hasA = existing.some((r: any) => r.type === 'A')
    const hasMX = existing.some((r: any) => r.type === 'MX')
    const created: string[] = []

    if (!hasA) {
      const r = await fetch(`https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`, {
        method: 'POST', headers: cfHeaders,
        body: JSON.stringify({ type: 'A', name: domain.domain, content: serverIp, ttl: 1, proxied: false }),
      })
      const d = await r.json() as any
      if (d.success) created.push(`A → ${serverIp}`)
    }
    if (!hasMX) {
      const r = await fetch(`https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`, {
        method: 'POST', headers: cfHeaders,
        body: JSON.stringify({ type: 'MX', name: domain.domain, content: domain.domain, priority: 10, ttl: 1 }),
      })
      const d = await r.json() as any
      if (d.success) created.push(`MX → ${domain.domain}`)
    }

    results.push({
      domain: domain.domain,
      serverIp,
      alreadyHadA: hasA,
      alreadyHadMX: hasMX,
      created,
    })
  }

  return NextResponse.json({ success: true, serverIp, results })
}
