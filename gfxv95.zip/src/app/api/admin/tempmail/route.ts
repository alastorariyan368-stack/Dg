import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

async function requireAdmin() {
  const session = await getServerSession(authOptions)
  if (!session?.user || !['ADMIN', 'SUPER_ADMIN'].includes(session.user.role)) return null
  return session
}

// GET /api/admin/tempmail — list domains + stats
export async function GET(req: NextRequest) {
  if (!await requireAdmin()) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const [domains, inboxCount, msgCount] = await Promise.all([
    db.tempMailDomain.findMany({ orderBy: { createdAt: 'desc' } }),
    db.tempMailInbox.count(),
    db.tempMailMessage.count(),
  ])

  return NextResponse.json({ domains, stats: { inboxCount, msgCount } })
}

// POST /api/admin/tempmail — add domain
export async function POST(req: NextRequest) {
  if (!await requireAdmin()) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { domain } = await req.json()
  if (!domain || !/^[a-z0-9.-]+\.[a-z]{2,}$/.test(domain.toLowerCase())) {
    return NextResponse.json({ error: 'Invalid domain format' }, { status: 400 })
  }
  try {
    const created = await db.tempMailDomain.create({ data: { domain: domain.toLowerCase() } })
    return NextResponse.json(created, { status: 201 })
  } catch {
    return NextResponse.json({ error: 'Domain already exists' }, { status: 409 })
  }
}

// PATCH /api/admin/tempmail — toggle domain
export async function PATCH(req: NextRequest) {
  if (!await requireAdmin()) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { id, isActive } = await req.json()
  const updated = await db.tempMailDomain.update({ where: { id }, data: { isActive } })
  return NextResponse.json(updated)
}

// DELETE /api/admin/tempmail — delete domain
export async function DELETE(req: NextRequest) {
  if (!await requireAdmin()) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  const { id } = await req.json()
  await db.tempMailDomain.delete({ where: { id } })
  return NextResponse.json({ success: true })
}
