import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

async function requireAdmin() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.email) return null
  const user = await db.user.findUnique({ where: { email: session.user.email } })
  if (!user || !['ADMIN', 'SUPER_ADMIN'].includes(user.role)) return null
  return user
}

export async function GET(request: NextRequest) {
  try {
    const admin = await requireAdmin()
    if (!admin) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { searchParams } = new URL(request.url)
    const page = parseInt(searchParams.get('page') || '1')
    const limit = 50
    const skip = (page - 1) * limit

    const [tunnels, total] = await Promise.all([
      db.zeroTrustTunnel.findMany({
        include: { user: { select: { id: true, username: true, email: true, avatar: true } } },
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit
      }),
      db.zeroTrustTunnel.count()
    ])

    return NextResponse.json({ tunnels, total, page, pages: Math.ceil(total / limit) })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch tunnels' }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const admin = await requireAdmin()
    if (!admin) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { id } = await request.json()
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 })

    const tunnel = await db.zeroTrustTunnel.findUnique({ where: { id } })
    if (!tunnel) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    const settings = await db.siteSettings.findFirst()
    if (settings?.cfApiToken && settings?.cfAccountId && tunnel.cfTunnelId) {
      try {
        await fetch(`https://api.cloudflare.com/client/v4/accounts/${settings.cfAccountId}/cfd_tunnel/${tunnel.cfTunnelId}`, {
          method: 'DELETE',
          headers: { 'Authorization': `Bearer ${settings.cfApiToken}`, 'Content-Type': 'application/json' }
        })
      } catch {}
    }

    await db.zeroTrustTunnel.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to delete tunnel' }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest) {
  try {
    const admin = await requireAdmin()
    if (!admin) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { id, status, subdomain } = await request.json()
    if (!id) return NextResponse.json({ error: 'ID required' }, { status: 400 })

    const tunnel = await db.zeroTrustTunnel.update({
      where: { id },
      data: {
        ...(status !== undefined && { status }),
        ...(subdomain !== undefined && { subdomain }),
      }
    })
    return NextResponse.json({ tunnel })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to update tunnel' }, { status: 500 })
  }
}
