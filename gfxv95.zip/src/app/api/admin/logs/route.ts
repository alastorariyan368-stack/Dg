import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    const role = (session?.user as any)?.role || ''
    if (!session?.user || !['ADMIN', 'SUPER_ADMIN'].includes(role)) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const url = req.nextUrl
    const page = Math.max(1, parseInt(url.searchParams.get('page') || '1'))
    const limit = Math.min(100, parseInt(url.searchParams.get('limit') || '50'))
    const skip = (page - 1) * limit
    const search = url.searchParams.get('search') || ''
    const userId = url.searchParams.get('userId') || ''

    const where: any = {}
    if (search) {
      where.OR = [
        { action: { contains: search, mode: 'insensitive' } },
        { username: { contains: search, mode: 'insensitive' } },
        { path: { contains: search, mode: 'insensitive' } },
        { ipAddress: { contains: search } },
        { details: { contains: search, mode: 'insensitive' } },
      ]
    }
    if (userId) where.userId = userId

    const [logs, total] = await Promise.all([
      db.activityLog.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip,
        take: limit,
      }),
      db.activityLog.count({ where }),
    ])

    return NextResponse.json({ logs, total, page, limit, totalPages: Math.ceil(total / limit) })
  } catch (error) {
    console.error('Admin logs error:', error)
    return NextResponse.json({ error: 'Failed to fetch logs' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    const role = (session?.user as any)?.role || ''
    if (!session?.user || !['ADMIN', 'SUPER_ADMIN'].includes(role)) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const url = req.nextUrl
    const all = url.searchParams.get('all') === '1' || url.searchParams.get('all') === 'true'
    const days = Math.max(0, parseInt(url.searchParams.get('days') || '30'))

    let result
    if (all) {
      result = await db.activityLog.deleteMany({})
      return NextResponse.json({ message: `All logs cleared (${result.count} removed)`, deleted: result.count })
    }

    result = await db.activityLog.deleteMany({
      where: { createdAt: { lt: new Date(Date.now() - days * 24 * 60 * 60 * 1000) } }
    })

    return NextResponse.json({
      message: `Logs older than ${days} days cleared (${result.count} removed)`,
      deleted: result.count,
    })
  } catch (err) {
    console.error('Clear logs error:', err)
    return NextResponse.json({ error: 'Failed to clear logs' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest) {
  // Convenience alias for clearing all logs.
  return POST(req)
}
