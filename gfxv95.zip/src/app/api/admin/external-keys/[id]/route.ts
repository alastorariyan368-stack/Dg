import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

function isAdmin(session: any) {
  return ['ADMIN', 'SUPER_ADMIN'].includes(session?.user?.role || '')
}

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session || !isAdmin(session)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  const { id } = await params
  const body = await req.json()
  const data: any = {}
  if ('isActive' in body) data.isActive = body.isActive
  if ('webhookUrl' in body) data.webhookUrl = body.webhookUrl
  if ('name' in body) data.name = body.name
  const updated = await db.externalApiKey.update({ where: { id }, data })
  return NextResponse.json({ key: updated })
}

export async function DELETE(_: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const session = await getServerSession(authOptions)
  if (!session || !isAdmin(session)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  const { id } = await params
  await db.externalApiKey.delete({ where: { id } })
  return NextResponse.json({ success: true })
}
