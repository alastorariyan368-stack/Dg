import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import crypto from 'crypto'

function isAdmin(session: any) {
  return ['ADMIN', 'SUPER_ADMIN'].includes(session?.user?.role || '')
}

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session || !isAdmin(session)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  try {
    const keys = await db.externalApiKey.findMany({
      orderBy: { createdAt: 'desc' },
      include: { owner: { select: { username: true, email: true } } },
    })
    return NextResponse.json({ keys })
  } catch (error: any) {
    console.error('Error fetching API keys:', error)
    return NextResponse.json({ 
      keys: [], 
      error: 'Database table missing or connection failed.',
      note: 'Run prisma db push to enable API keys' 
    })
  }
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session || !isAdmin(session)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const { name, webhookUrl, permissions } = await req.json()
  if (!name) return NextResponse.json({ error: 'Name required' }, { status: 400 })

  const trimmedWebhook = webhookUrl?.trim()
  if (trimmedWebhook && !trimmedWebhook.startsWith('http')) {
    return NextResponse.json({ 
      error: 'Invalid Webhook URL. If you provide a link, it must start with http:// or https://. Leave it blank if you don\'t need a webhook.' 
    }, { status: 400 })
  }

  try {
    const key = 'gfx_' + crypto.randomBytes(24).toString('hex')
    const created = await db.externalApiKey.create({
      data: {
        name,
        key,
        ownerId: (session.user as any).id,
        webhookUrl: trimmedWebhook || null,
        permissions: permissions || ['payment:deposit', 'payment:status'],
      },
    })
    return NextResponse.json({ key: created })
  } catch (error: any) {
    console.error('Error creating API key:', error)
    return NextResponse.json({ 
      error: 'Failed to create API key. The database table might be missing. Try running prisma db push.',
      details: error.message 
    }, { status: 500 })
  }
}
