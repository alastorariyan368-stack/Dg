import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { sendMail, buildNotificationEmailHtml } from '@/lib/mailer'

function isAdmin(role?: string) { return ['ADMIN', 'SUPER_ADMIN'].includes(role || '') }

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id || !isAdmin(session.user.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const applications = await db.sellerApplication.findMany({
    include: { user: { select: { id: true, username: true, email: true, avatar: true, totalSales: true, sellerLevel: true, isVerified: true } } },
    orderBy: { createdAt: 'desc' }
  })

  return NextResponse.json({ applications })
}

export async function PATCH(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id || !isAdmin(session.user.role)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const { id, status, adminNote } = await req.json()

  const application = await db.sellerApplication.update({
    where: { id },
    data: { status, adminNote },
    include: { user: { select: { email: true, username: true } } }
  })

  const appUrl = process.env.NEXT_PUBLIC_APP_URL ||
    (process.env.REPLIT_DOMAINS ? `https://${process.env.REPLIT_DOMAINS.split(',')[0]}` : 'http://localhost:5000')

  if (status === 'APPROVED') {
    await db.user.update({ where: { id: application.userId }, data: { isVerified: true, role: 'CREATOR' } })
    await db.notification.create({
      data: {
        userId: application.userId,
        type: 'SELLER_VERIFIED' as any,
        title: 'Seller Application Approved! 🎉',
        content: 'Congratulations! You are now a verified seller on GfxStore. Start uploading your content!'
      }
    })

    if (application.user?.email) {
      const html = buildNotificationEmailHtml({
        username: application.user.username || 'there',
        title: '🎉 You\'re now a Verified Seller!',
        message: 'Congratulations! Your seller application has been <strong style="color:#22c55e;">approved</strong>. You can now upload and sell your content on GfxStore. Start building your store today!',
        color: '#059669',
        ctaText: 'Go to Dashboard',
        ctaLink: `${appUrl}/dashboard`
      })
      sendMail({
        to: application.user.email,
        subject: 'GfxStore — Seller Application Approved! 🎉',
        html
      }).catch(console.error)
    }
  } else if (status === 'REJECTED') {
    await db.notification.create({
      data: {
        userId: application.userId,
        type: 'SYSTEM_ANNOUNCEMENT' as any,
        title: 'Seller Application Status',
        content: adminNote || 'Your seller application was not approved at this time.'
      }
    })

    if (application.user?.email) {
      const html = buildNotificationEmailHtml({
        username: application.user.username || 'there',
        title: 'Seller Application Update',
        message: `Thank you for applying to become a seller on GfxStore. Unfortunately, your application was <strong style="color:#ef4444;">not approved</strong> at this time.${adminNote ? `<br/><br/>Reason: ${adminNote}` : '<br/><br/>You are welcome to apply again once you meet our requirements.'}`,
        color: '#7c3aed',
        ctaText: 'Learn More',
        ctaLink: `${appUrl}/guidelines`
      })
      sendMail({
        to: application.user.email,
        subject: 'GfxStore — Seller Application Update',
        html
      }).catch(console.error)
    }
  }

  return NextResponse.json({ application })
}
