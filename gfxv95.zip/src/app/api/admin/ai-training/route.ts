import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { invalidateBrainCache } from '@/lib/gfx-ai-engine'

async function requireAdmin() {
  const session = await getServerSession(authOptions)
  if (!session?.user) return null
  const role = (session.user as any).role
  if (role !== 'ADMIN' && role !== 'SUPER_ADMIN') return null
  return session
}

// GET — list brain entries / stats / config / memories
export async function GET(req: NextRequest) {
  const session = await requireAdmin()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { searchParams } = new URL(req.url)
  const action = searchParams.get('action') || 'list'
  const page = parseInt(searchParams.get('page') || '1')
  const limit = parseInt(searchParams.get('limit') || '25')
  const search = searchParams.get('search') || ''
  const category = searchParams.get('category') || ''

  try {
    if (action === 'stats') {
      const [total, manual, learned, api, memories, config] = await Promise.all([
        (db as any).gfxAiBrain.count({ where: { isActive: true } }),
        (db as any).gfxAiBrain.count({ where: { source: 'manual', isActive: true } }),
        (db as any).gfxAiBrain.count({ where: { source: 'learned', isActive: true } }),
        (db as any).gfxAiBrain.count({ where: { source: 'api', isActive: true } }),
        (db as any).gfxAiMemory.count(),
        (db as any).gfxAiConfig.findFirst({ where: { name: 'GFXV1' } }),
      ])
      const aiUsages = await db.aIUsage.count()
      return NextResponse.json({ total, manual, learned, api, memories, aiUsages, config })
    }

    if (action === 'config') {
      let cfg = await (db as any).gfxAiConfig.findFirst({ where: { name: 'GFXV1' } })
      if (!cfg) {
        cfg = await (db as any).gfxAiConfig.create({
          data: { name: 'GFXV1', systemPrompt: '', personality: 'professional', version: '5.0.0' },
        })
      }
      return NextResponse.json({ config: cfg })
    }

    if (action === 'memories') {
      const userId = searchParams.get('userId') || ''
      const where: any = {}
      if (userId) where.userId = userId
      const rows = await (db as any).gfxAiMemory.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: 50,
        select: { id: true, userId: true, sessionId: true, role: true, content: true, createdAt: true },
      })
      return NextResponse.json({ memories: rows })
    }

    // Default: list brain entries
    const where: any = {}
    if (search) {
      where.OR = [
        { question: { contains: search, mode: 'insensitive' } },
        { answer: { contains: search, mode: 'insensitive' } },
        { keywords: { contains: search, mode: 'insensitive' } },
      ]
    }
    if (category) where.category = category

    const [entries, total] = await Promise.all([
      (db as any).gfxAiBrain.findMany({
        where,
        orderBy: { usageCount: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      (db as any).gfxAiBrain.count({ where }),
    ])

    const categories = await (db as any).gfxAiBrain.groupBy({
      by: ['category'],
      _count: { id: true },
      orderBy: { _count: { id: 'desc' } },
    })

    return NextResponse.json({ entries, total, page, limit, categories })
  } catch (err: any) {
    console.error('[AI Training GET]', err)
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}

// POST — add entry / update config / bulk import / delete memory
export async function POST(req: NextRequest) {
  const session = await requireAdmin()
  if (!session) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const body = await req.json()
    const { action } = body

    if (action === 'add') {
      const { question, answer, category = 'general', keywords = '' } = body
      if (!question?.trim() || !answer?.trim()) {
        return NextResponse.json({ error: 'Question and answer are required' }, { status: 400 })
      }
      const autoKeywords = keywords || [...new Set(
        (question + ' ' + category).toLowerCase().replace(/[^\w\s\u0980-\u09FF]/g, ' ').split(/\s+/).filter((t: string) => t.length > 1)
      )].slice(0, 20).join(' ')

      const entry = await (db as any).gfxAiBrain.create({
        data: {
          question: question.trim().slice(0, 500),
          answer: answer.trim().slice(0, 5000),
          category: category.trim().toLowerCase() || 'general',
          keywords: autoKeywords.slice(0, 300),
          confidence: 1.0,
          source: 'manual',
        },
      })
      await invalidateBrainCache()
      return NextResponse.json({ success: true, entry })
    }

    if (action === 'update') {
      const { id, question, answer, category, keywords, isActive, confidence } = body
      const updated = await (db as any).gfxAiBrain.update({
        where: { id },
        data: {
          ...(question !== undefined && { question: question.slice(0, 500) }),
          ...(answer !== undefined && { answer: answer.slice(0, 5000) }),
          ...(category !== undefined && { category }),
          ...(keywords !== undefined && { keywords }),
          ...(isActive !== undefined && { isActive }),
          ...(confidence !== undefined && { confidence: parseFloat(confidence) }),
        },
      })
      await invalidateBrainCache()
      return NextResponse.json({ success: true, entry: updated })
    }

    if (action === 'delete') {
      const { id } = body
      await (db as any).gfxAiBrain.delete({ where: { id } })
      await invalidateBrainCache()
      return NextResponse.json({ success: true })
    }

    if (action === 'bulk-import') {
      const { data } = body // array of {question, answer, category, keywords}
      if (!Array.isArray(data) || data.length === 0) {
        return NextResponse.json({ error: 'No data to import' }, { status: 400 })
      }
      const rows = data.slice(0, 500).map((item: any) => ({
        question: String(item.question || item.q || '').trim().slice(0, 500),
        answer: String(item.answer || item.a || '').trim().slice(0, 5000),
        category: String(item.category || 'imported').toLowerCase(),
        keywords: String(item.keywords || ''),
        confidence: 1.0,
        source: 'manual',
        usageCount: 0,
        isActive: true,
      })).filter((r: any) => r.question && r.answer)

      await (db as any).gfxAiBrain.createMany({ data: rows, skipDuplicates: true })
      await invalidateBrainCache()
      return NextResponse.json({ success: true, imported: rows.length })
    }

    if (action === 'update-config') {
      const { systemPrompt, personality, version } = body
      const cfg = await (db as any).gfxAiConfig.upsert({
        where: { name: 'GFXV1' },
        create: { name: 'GFXV1', systemPrompt: systemPrompt || '', personality: personality || 'professional', version: version || '5.0.0' },
        update: {
          ...(systemPrompt !== undefined && { systemPrompt }),
          ...(personality !== undefined && { personality }),
          ...(version !== undefined && { version }),
        },
      })
      await invalidateBrainCache()
      return NextResponse.json({ success: true, config: cfg })
    }

    if (action === 'clear-memories') {
      const { userId } = body
      const where: any = {}
      if (userId) where.userId = userId
      const { count } = await (db as any).gfxAiMemory.deleteMany({ where })
      return NextResponse.json({ success: true, deleted: count })
    }

    if (action === 'clear-all') {
      const { count } = await (db as any).gfxAiBrain.deleteMany({ where: { source: { not: 'manual' } } })
      await invalidateBrainCache()
      return NextResponse.json({ success: true, deleted: count })
    }

    return NextResponse.json({ error: 'Unknown action' }, { status: 400 })
  } catch (err: any) {
    console.error('[AI Training POST]', err)
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}
