import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

function isAdmin(session: any) {
  return session?.user?.role === 'ADMIN' || session?.user?.role === 'SUPER_ADMIN'
}

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!isAdmin(session)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type') || 'all'
    const status = searchParams.get('status') || 'PENDING'
    const limit = Math.min(parseInt(searchParams.get('limit') || '20'), 100)
    const offset = parseInt(searchParams.get('offset') || '0')

    const results: any = {}

    if (type === 'all' || type === 'videos') {
      results.videos = await db.video.findMany({
        where: { status },
        take: limit,
        skip: offset,
        orderBy: { createdAt: 'desc' },
        include: { author: { select: { id: true, username: true, avatar: true } } }
      })
      results.videosTotal = await db.video.count({ where: { status } })
    }

    if (type === 'all' || type === 'apps') {
      results.apps = await db.mobileApp.findMany({
        where: { status },
        take: limit,
        skip: offset,
        orderBy: { createdAt: 'desc' },
        include: { author: { select: { id: true, username: true, avatar: true } } }
      })
      results.appsTotal = await db.mobileApp.count({ where: { status } })
    }

    if (type === 'all' || type === 'code') {
      results.code = await db.codeProject.findMany({
        where: { status },
        take: limit,
        skip: offset,
        orderBy: { createdAt: 'desc' },
        include: { author: { select: { id: true, username: true, avatar: true } } }
      })
      results.codeTotal = await db.codeProject.count({ where: { status } })
    }

    return NextResponse.json(results)
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!isAdmin(session)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

    const body = await request.json()
    const { id, contentType, action, reason } = body

    if (!id || !contentType || !action) {
      return NextResponse.json({ error: 'id, contentType, and action are required' }, { status: 400 })
    }

    const newStatus = action === 'approve' ? 'APPROVED' : 'REJECTED'

    let updated: any = null

    if (contentType === 'video') {
      updated = await db.video.update({ where: { id }, data: { status: newStatus } })
    } else if (contentType === 'app') {
      updated = await db.mobileApp.update({ where: { id }, data: { status: newStatus } })
    } else if (contentType === 'code') {
      updated = await db.codeProject.update({ where: { id }, data: { status: newStatus } })
    } else {
      return NextResponse.json({ error: 'Invalid content type' }, { status: 400 })
    }

    return NextResponse.json({ success: true, status: newStatus, item: updated })
  } catch (error) {
    console.error('Error updating content status:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
