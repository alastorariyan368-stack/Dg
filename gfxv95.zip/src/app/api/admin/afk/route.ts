import { NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

function isAdmin(session: any) {
  return ['ADMIN', 'SUPER_ADMIN'].includes(session?.user?.role || '')
}

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session || !isAdmin(session)) return NextResponse.json({ error: 'Forbidden' }, { status: 403 })

  const today = new Date().toISOString().slice(0, 10)

  try {
    // Using raw queries because Prisma Client generation might be outdated in node_modules
    const countResult: any = await db.$queryRawUnsafe(
      `SELECT COUNT(*)::int as count FROM "afk_sessions" WHERE "date" = $1`,
      today
    )
    const todaySessions = countResult[0]?.count || 0

    const sumResult: any = await db.$queryRawUnsafe(
      `SELECT SUM("amountEarned") as total FROM "afk_sessions"`
    )
    const totalPaid = Number(sumResult[0]?.total || 0)

    const recentSessions: any = await db.$queryRawUnsafe(
      `SELECT s.*, u.username, u.avatar 
       FROM "afk_sessions" s
       JOIN "User" u ON s."userId" = u.id
       ORDER BY s."startedAt" DESC 
       LIMIT 20`
    )

    // Format recentSessions to match expected structure with nested user object
    const formattedSessions = recentSessions.map((s: any) => ({
      ...s,
      user: { username: s.username, avatar: s.avatar }
    }))

    return NextResponse.json({
      todaySessions,
      totalPaid,
      recentSessions: formattedSessions,
    })
  } catch (e: any) {
    console.error('Admin AFK API Error:', e)
    return NextResponse.json({
      todaySessions: 0,
      totalPaid: 0,
      recentSessions: [],
      error: e.message,
      note: 'Run prisma generate if error persists',
    })
  }
}
