import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id || (session.user.role !== 'ADMIN' && session.user.role !== 'SUPER_ADMIN')) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { searchParams } = new URL(req.url)
    const status = searchParams.get('status')

    const where: any = {}
    if (status && status !== 'all') where.status = status

    const deployments = await db.appDeployment.findMany({
      where,
      include: { user: { select: { id: true, username: true, email: true, avatar: true } } },
      orderBy: { createdAt: 'desc' },
    })

    const stats = {
      total: await db.appDeployment.count(),
      running: await db.appDeployment.count({ where: { status: 'running' } }),
      stopped: await db.appDeployment.count({ where: { status: 'stopped' } }),
      error: await db.appDeployment.count({ where: { status: 'error' } }),
    }

    return NextResponse.json({ deployments, stats })
  } catch (error) {
    console.error('Admin deployments GET error:', error)
    return NextResponse.json({ error: 'Failed to fetch deployments' }, { status: 500 })
  }
}
