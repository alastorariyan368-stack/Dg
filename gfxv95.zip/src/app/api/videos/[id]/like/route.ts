import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const existing = await db.videoLike.findUnique({
      where: { videoId_userId: { videoId: id, userId: session.user.id } }
    })

    if (existing) {
      await db.videoLike.delete({ where: { id: existing.id } })
      await db.video.update({ where: { id }, data: { likes: { decrement: 1 } } })
      return NextResponse.json({ liked: false })
    } else {
      await db.videoLike.create({ data: { videoId: id, userId: session.user.id } })
      await db.video.update({ where: { id }, data: { likes: { increment: 1 } } })
      return NextResponse.json({ liked: true })
    }
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
