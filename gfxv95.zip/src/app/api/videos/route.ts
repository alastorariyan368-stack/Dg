import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const limit = Math.min(parseInt(searchParams.get('limit') || '20'), 100)
    const offset = parseInt(searchParams.get('offset') || '0')
    const status = searchParams.get('status') || 'APPROVED'
    const category = searchParams.get('category')
    const search = searchParams.get('search')
    const authorId = searchParams.get('authorId')
    const type = searchParams.get('type') // 'video' or 'reel'
    const session = await getServerSession(authOptions)

    const whereClause: any = {}

    if (authorId === 'me' && session?.user?.id) {
      whereClause.authorId = session.user.id
    } else if (authorId) {
      whereClause.authorId = authorId
      whereClause.status = 'APPROVED'
    } else {
      whereClause.status = status
    }

    if (category) whereClause.category = category
    if (type) whereClause.type = type
    if (search) {
      whereClause.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ]
    }

    const [videos, total] = await Promise.all([
      db.video.findMany({
        where: whereClause,
        take: limit,
        skip: offset,
        orderBy: { createdAt: 'desc' },
        include: {
          author: { select: { id: true, username: true, avatar: true, isVerified: true } },
          _count: { select: { comments: true, videoLikes: true } }
        }
      }),
      db.video.count({ where: whereClause })
    ])

    return NextResponse.json({ videos, total, limit, offset })
  } catch (error) {
    console.error('Error fetching videos:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { title, description, thumbnail, videoUrl, duration, tags, category, type = 'video' } = body

    if (!title || !videoUrl) {
      return NextResponse.json({ error: 'Title and video URL are required' }, { status: 400 })
    }

    // Reels are auto-approved, videos require admin review
    const status = type === 'reel' ? 'APPROVED' : 'PENDING'

    const video = await db.video.create({
      data: {
        title,
        description,
        thumbnail,
        videoUrl,
        duration: duration ? parseInt(duration) : null,
        tags: tags || [],
        category: category || 'General',
        type: type || 'video',
        authorId: session.user.id,
        status,
      },
      include: {
        author: { select: { id: true, username: true, avatar: true } }
      }
    })

    return NextResponse.json({ video, message: type === 'reel' ? 'Reel published successfully!' : 'Video submitted for review' }, { status: 201 })
  } catch (error) {
    console.error('Error creating video:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
