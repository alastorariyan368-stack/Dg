import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { NextResponse } from 'next/server'

export async function GET() {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    const user = await db.user.findUnique({ where: { email: session.user.email } })
    if (!user) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    const settings = await db.siteSettings.findFirst()
    const allowedZones = (settings?.cfAllowedZones as any[]) || []
    const cfConfigured = !!(settings?.cfAccountId && settings?.cfApiToken)
    const maxTunnelsPerUser = settings?.maxTunnelsPerUser || 2

    // Fetch all used subdomains for this user so UI can warn about conflicts
    const userTunnels = await db.zeroTrustTunnel.findMany({
      where: { userId: user.id, status: { not: 'DELETED' } },
      select: { id: true, subdomain: true, zoneId: true, zoneDomain: true }
    })
    const usedSubdomains = userTunnels
      .filter(t => t.subdomain && t.zoneId)
      .map(t => ({ tunnelId: t.id, subdomain: t.subdomain, zoneId: t.zoneId, zoneDomain: t.zoneDomain }))

    return NextResponse.json({ allowedZones, cfConfigured, maxTunnelsPerUser, usedSubdomains })
  } catch (error: any) {
    return NextResponse.json({ error: error?.message || 'Failed to fetch domains' }, { status: 500 })
  }
}
