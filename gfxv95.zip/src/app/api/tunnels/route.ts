import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function GET() {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    const user = await db.user.findUnique({ where: { email: session.user.email } })
    if (!user) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    const tunnels = await db.zeroTrustTunnel.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' }
    })

    const settings = await db.siteSettings.findFirst()
    if (!settings?.cfApiToken || !settings?.cfAccountId) {
      return NextResponse.json({ tunnels })
    }

    const refreshed = await Promise.all(tunnels.map(async (t) => {
      if (!t.cfTunnelId || t.status === 'ERROR' || t.status === 'DELETED') return t
      try {
        const cfRes = await fetch(
          `https://api.cloudflare.com/client/v4/accounts/${settings.cfAccountId}/cfd_tunnel/${t.cfTunnelId}`,
          { headers: { Authorization: `Bearer ${settings.cfApiToken}` } }
        )
        const cfData = await cfRes.json()
        if (!cfData?.success) return t
        const connections = Array.isArray(cfData?.result?.connections) ? cfData.result.connections : []
        const nextStatus = connections.length > 0 ? 'ACTIVE' : 'PENDING'
        if (nextStatus !== t.status) {
          return await db.zeroTrustTunnel.update({
            where: { id: t.id },
            data: { status: nextStatus }
          })
        }
      } catch {
        return t
      }
      return t
    }))

    return NextResponse.json({ tunnels: refreshed })
  } catch {
    return NextResponse.json({ error: 'Failed to fetch tunnels' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    const user = await db.user.findUnique({ where: { email: session.user.email } })
    if (!user) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    const settings = await db.siteSettings.findFirst()
    const maxTunnels = settings?.maxTunnelsPerUser || 2

    const existingCount = await db.zeroTrustTunnel.count({
      where: { userId: user.id, status: { notIn: ['DELETED', 'ERROR'] } }
    })
    if (existingCount >= maxTunnels) {
      return NextResponse.json({ error: `Maximum ${maxTunnels} active tunnels allowed` }, { status: 403 })
    }

    const { name } = await request.json()
    if (!name?.trim()) return NextResponse.json({ error: 'Tunnel name required' }, { status: 400 })

    if (!settings?.cfApiToken || !settings?.cfAccountId) {
      return NextResponse.json({ error: 'Cloudflare not configured by admin' }, { status: 503 })
    }

    let cfTunnelId: string | undefined
    let cfTunnelToken: string | undefined
    let status = 'PENDING'
    let errorMsg: string | undefined

    try {
      const tunnelSecret = Buffer.from(
        Array.from({ length: 32 }, () => Math.floor(Math.random() * 256))
      ).toString('base64')

      const createRes = await fetch(
        `https://api.cloudflare.com/client/v4/accounts/${settings.cfAccountId}/cfd_tunnel`,
        {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${settings.cfApiToken}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ name: `gfx-${name.trim().toLowerCase().replace(/[^a-z0-9-]/g, '-')}-${Date.now()}`, tunnel_secret: tunnelSecret })
        }
      )
      const createData = await createRes.json()
      if (!createData.success || !createData.result) {
        throw new Error(createData.errors?.[0]?.message || 'Failed to create Cloudflare tunnel')
      }
      cfTunnelId = createData.result.id
      cfTunnelToken = createData.result.token
    } catch (err: any) {
      errorMsg = err?.message || 'Failed to create tunnel'
      status = 'ERROR'
    }

    const tunnel = await db.zeroTrustTunnel.create({
      data: {
        userId: user.id,
        name: name.trim(),
        cfTunnelId,
        cfTunnelToken,
        targetPort: 3000,
        targetHost: 'localhost',
        protocol: 'http',
        status,
        errorMsg
      }
    })

    return NextResponse.json({ tunnel }, { status: 201 })
  } catch (error: any) {
    return NextResponse.json({ error: 'Failed to create tunnel' }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    const user = await db.user.findUnique({ where: { email: session.user.email } })
    if (!user) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    const { id } = await request.json()
    const tunnel = await db.zeroTrustTunnel.findFirst({ where: { id, userId: user.id } })
    if (!tunnel) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    const settings = await db.siteSettings.findFirst()

    if (settings?.cfApiToken && settings?.cfAccountId && tunnel.cfTunnelId) {
      try {
        if (tunnel.zoneId && tunnel.subdomain && tunnel.zoneDomain) {
          const listRes = await fetch(
            `https://api.cloudflare.com/client/v4/zones/${tunnel.zoneId}/dns_records?name=${tunnel.subdomain}.${tunnel.zoneDomain}&type=CNAME`,
            { headers: { 'Authorization': `Bearer ${settings.cfApiToken}` } }
          )
          const listData = await listRes.json()
          for (const record of listData.result || []) {
            await fetch(
              `https://api.cloudflare.com/client/v4/zones/${tunnel.zoneId}/dns_records/${record.id}`,
              { method: 'DELETE', headers: { 'Authorization': `Bearer ${settings.cfApiToken}` } }
            )
          }
        }
        await fetch(
          `https://api.cloudflare.com/client/v4/accounts/${settings.cfAccountId}/cfd_tunnel/${tunnel.cfTunnelId}`,
          { method: 'DELETE', headers: { 'Authorization': `Bearer ${settings.cfApiToken}` } }
        )
      } catch {}
    }

    await db.zeroTrustTunnel.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch {
    return NextResponse.json({ error: 'Failed to delete tunnel' }, { status: 500 })
  }
}
