import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

async function refreshTunnelStatusForUser(params: {
  userId: string
  tunnelId: string
}) {
  const tunnel = await db.zeroTrustTunnel.findFirst({
    where: { id: params.tunnelId, userId: params.userId }
  })
  if (!tunnel) return null
  if (!tunnel.cfTunnelId) return tunnel

  const settings = await db.siteSettings.findFirst()
  if (!settings?.cfApiToken || !settings?.cfAccountId) return tunnel

  try {
    const cfRes = await fetch(
      `https://api.cloudflare.com/client/v4/accounts/${settings.cfAccountId}/cfd_tunnel/${tunnel.cfTunnelId}`,
      { headers: { Authorization: `Bearer ${settings.cfApiToken}` } }
    )
    const cfData = await cfRes.json()
    if (!cfData?.success) return tunnel

    const connections = Array.isArray(cfData?.result?.connections) ? cfData.result.connections : []
    const nextStatus = connections.length > 0 ? 'ACTIVE' : 'PENDING'
    if (tunnel.status !== 'ERROR' && tunnel.status !== 'DELETED' && tunnel.status !== nextStatus) {
      return await db.zeroTrustTunnel.update({
        where: { id: tunnel.id },
        data: { status: nextStatus }
      })
    }
  } catch {
    // best-effort sync only
  }
  return tunnel
}

export async function GET(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    const user = await db.user.findUnique({ where: { email: session.user.email } })
    if (!user) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    const url = new URL(_req.url)
    const refreshStatus = url.searchParams.get('refreshStatus') === '1'
    const tunnel = refreshStatus
      ? await refreshTunnelStatusForUser({ userId: user.id, tunnelId: id })
      : await db.zeroTrustTunnel.findFirst({ where: { id, userId: user.id } })
    if (!tunnel) return NextResponse.json({ error: 'Tunnel not found' }, { status: 404 })

    return NextResponse.json({ tunnel })
  } catch (error: any) {
    return NextResponse.json({ error: error?.message || 'Failed to fetch tunnel' }, { status: 500 })
  }
}

export async function PATCH(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    const user = await db.user.findUnique({ where: { email: session.user.email } })
    if (!user) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    const tunnel = await db.zeroTrustTunnel.findFirst({ where: { id, userId: user.id } })
    if (!tunnel) return NextResponse.json({ error: 'Tunnel not found' }, { status: 404 })
    if (!tunnel.cfTunnelId) return NextResponse.json({ error: 'Tunnel has no Cloudflare ID — it may still be setting up' }, { status: 400 })

    const body = await request.json()
    const { 
      subdomain, zoneId, targetPort, targetHost, protocol, 
      noTlsVerify, originHostHeader, advancedConfig 
    } = body

    if (!subdomain?.trim()) return NextResponse.json({ error: 'Subdomain required' }, { status: 400 })
    if (!zoneId) return NextResponse.json({ error: 'Domain required' }, { status: 400 })

    const subdomainClean = subdomain.trim().toLowerCase().replace(/[^a-z0-9-]/g, '')
    if (!subdomainClean) return NextResponse.json({ error: 'Invalid subdomain' }, { status: 400 })

    const settings = await db.siteSettings.findFirst()
    if (!settings?.cfApiToken || !settings?.cfAccountId) {
      return NextResponse.json({ error: 'Cloudflare not configured by admin' }, { status: 503 })
    }

    const allowedZones = (settings?.cfAllowedZones as any[]) || []
    const selectedZone = allowedZones.find((z: any) => z.id === zoneId)
    if (!selectedZone) return NextResponse.json({ error: 'Domain not available' }, { status: 400 })

    // Check if subdomain already used by another tunnel
    const conflict = await db.zeroTrustTunnel.findFirst({
      where: {
        subdomain: subdomainClean,
        zoneId,
        userId: user.id,
        id: { not: id },
        status: { not: 'DELETED' },
      }
    })
    if (conflict) {
      return NextResponse.json({ error: `Subdomain "${subdomainClean}.${selectedZone.name}" is already used by tunnel "${conflict.name}"` }, { status: 409 })
    }

    const zoneDomain = selectedZone.name
    const fullHostname = `${subdomainClean}.${zoneDomain}`
    const proto = protocol || 'http'
    const port = parseInt(String(targetPort)) || 3000
    const host = targetHost || 'localhost'

    // 1. Update ingress config on Cloudflare
    const ingressRule: any = { hostname: fullHostname, service: `${proto}://${host}:${port}` }
    
    // Add advanced options if provided
    const originRequest: any = {}
    if (noTlsVerify) originRequest.noTLSVerify = true
    if (originHostHeader) originRequest.httpHostHeader = originHostHeader
    
    // Add new advanced options from advancedConfig
    if (advancedConfig) {
      if (advancedConfig.originServerName) originRequest.originServerName = advancedConfig.originServerName
      if (advancedConfig.httpConnectTimeout) originRequest.httpConnectTimeout = parseInt(advancedConfig.httpConnectTimeout)
      if (advancedConfig.httpTLSHandshakeTimeout) originRequest.httpTLSHandshakeTimeout = parseInt(advancedConfig.httpTLSHandshakeTimeout)
      if (advancedConfig.noHappyEyeballs !== undefined) originRequest.noHappyEyeballs = !!advancedConfig.noHappyEyeballs
      if (advancedConfig.proxyType) originRequest.proxyType = advancedConfig.proxyType
    }

    if (Object.keys(originRequest).length > 0) {
      ingressRule.originRequest = originRequest
    }

    const configRes = await fetch(
      `https://api.cloudflare.com/client/v4/accounts/${settings.cfAccountId}/cfd_tunnel/${tunnel.cfTunnelId}/configurations`,
      {
        method: 'PUT',
        headers: { 'Authorization': `Bearer ${settings.cfApiToken}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          config: {
            ingress: [
              ingressRule,
              { service: 'http_status:404' }
            ]
          }
        })
      }
    )
    const configData = await configRes.json()
    if (!configData.success) {
      return NextResponse.json({ error: configData.errors?.[0]?.message || 'Failed to configure hostname on Cloudflare' }, { status: 500 })
    }

    // 2. Delete old DNS record if hostname changed
    if (tunnel.subdomain && tunnel.zoneId && tunnel.zoneDomain &&
        (tunnel.subdomain !== subdomainClean || tunnel.zoneId !== zoneId)) {
      try {
        const oldFull = `${tunnel.subdomain}.${tunnel.zoneDomain}`
        const listRes = await fetch(
          `https://api.cloudflare.com/client/v4/zones/${tunnel.zoneId}/dns_records?name=${oldFull}&type=CNAME`,
          { headers: { 'Authorization': `Bearer ${settings.cfApiToken}` } }
        )
        const listData = await listRes.json()
        for (const record of listData.result || []) {
          await fetch(
            `https://api.cloudflare.com/client/v4/zones/${tunnel.zoneId}/dns_records/${record.id}`,
            { method: 'DELETE', headers: { 'Authorization': `Bearer ${settings.cfApiToken}` } }
          )
        }
      } catch { /* ignore DNS cleanup failures */ }
    }

    // 3. Create new DNS CNAME record (upsert — ignore if exists)
    const dnsCheckRes = await fetch(
      `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records?name=${fullHostname}&type=CNAME`,
      { headers: { 'Authorization': `Bearer ${settings.cfApiToken}` } }
    )
    const dnsCheckData = await dnsCheckRes.json()
    const existingDns = dnsCheckData.result?.[0]

    if (existingDns) {
      // Update existing record
      await fetch(
        `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records/${existingDns.id}`,
        {
          method: 'PUT',
          headers: { 'Authorization': `Bearer ${settings.cfApiToken}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({
            type: 'CNAME',
            name: fullHostname,
            content: `${tunnel.cfTunnelId}.cfargotunnel.com`,
            proxied: true,
          })
        }
      )
    } else {
      // Create new record
      const dnsRes = await fetch(
        `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`,
        {
          method: 'POST',
          headers: { 'Authorization': `Bearer ${settings.cfApiToken}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({
            type: 'CNAME',
            name: fullHostname,
            content: `${tunnel.cfTunnelId}.cfargotunnel.com`,
            proxied: true,
            comment: `GfxStore tunnel for ${user.email}`
          })
        }
      )
      const dnsData = await dnsRes.json()
      if (!dnsData.success) {
        // Non-fatal — DNS might already exist with different ID
        console.error('DNS record error:', JSON.stringify(dnsData.errors))
      }
    }

    // 4. Update DB record
    const updated = await db.zeroTrustTunnel.update({
      where: { id },
      data: {
        subdomain: subdomainClean,
        zoneId,
        zoneDomain,
        targetPort: port,
        targetHost: host,
        protocol: proto,
        noTlsVerify: !!noTlsVerify,
        originHostHeader: originHostHeader || null,
        advancedConfig: advancedConfig || {},
        // Hostname creation does not guarantee connector is online yet.
        status: tunnel.status === 'ERROR' ? 'ERROR' : 'PENDING',
        errorMsg: null
      }
    })

    return NextResponse.json({ tunnel: updated, fullHostname: `https://${fullHostname}` })
  } catch (error: any) {
    return NextResponse.json({ error: error?.message || 'Failed to update tunnel' }, { status: 500 })
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    const user = await db.user.findUnique({ where: { email: session.user.email } })
    if (!user) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    const tunnel = await db.zeroTrustTunnel.findFirst({ where: { id, userId: user.id } })
    if (!tunnel) return NextResponse.json({ error: 'Tunnel not found' }, { status: 404 })

    const settings = await db.siteSettings.findFirst()

    if (settings?.cfApiToken && settings?.cfAccountId && tunnel.cfTunnelId) {
      try {
        // Delete DNS record
        if (tunnel.zoneId && tunnel.subdomain && tunnel.zoneDomain) {
          const listRes = await fetch(
            `https://api.cloudflare.com/client/v4/zones/${tunnel.zoneId}/dns_records?name=${tunnel.subdomain}.${tunnel.zoneDomain}&type=CNAME`,
            { headers: { 'Authorization': `Bearer ${settings.cfApiToken}` } }
          )
          const listData = await listRes.json()
          for (const record of listData.result || []) {
            await fetch(
              `https://api.cloudflare.com/client/v4/zones/${tunnel.zoneId}/dns_records/${record.id}`,
              { method: 'DELETE', headers: { 'Authorization': `Bearer ${settings.cfApiToken}` } }
            )
          }
        }
        // Delete CF tunnel
        await fetch(
          `https://api.cloudflare.com/client/v4/accounts/${settings.cfAccountId}/cfd_tunnel/${tunnel.cfTunnelId}`,
          { method: 'DELETE', headers: { 'Authorization': `Bearer ${settings.cfApiToken}` } }
        )
      } catch { /* ignore CF cleanup failures */ }
    }

    await db.zeroTrustTunnel.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error: any) {
    return NextResponse.json({ error: error?.message || 'Failed to delete tunnel' }, { status: 500 })
  }
}
