import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    const { searchParams } = new URL(request.url)
    const featured = searchParams.get('featured')
    const limit = Math.min(parseInt(searchParams.get('limit') || '50'), 200)
    const offset = parseInt(searchParams.get('offset') || '0')
    const category = searchParams.get('category')
    const status = searchParams.get('status')
    const search = searchParams.get('search')
    const sortBy = searchParams.get('sortBy') || 'createdAt'
    const order = (searchParams.get('order') || 'desc') as 'asc' | 'desc'
    const accessType = searchParams.get('accessType')
    const authorId = searchParams.get('authorId')
    const username = searchParams.get('username')

    const whereClause: any = {}

    if (featured === 'true') {
      whereClause.featured = true
      whereClause.status = 'APPROVED'
    } else if (status) {
      whereClause.status = status
    } else {
      whereClause.status = 'APPROVED'
    }

    if (category) whereClause.category = { slug: category }

    if (search) {
      whereClause.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { shortDesc: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
        { tags: { has: search } },
      ]
    }

    if (accessType) {
      if (accessType === 'FREE') whereClause.accessType = 'FREE'
      else if (accessType === 'PAID') whereClause.accessType = 'PAID'
      else if (accessType === 'ROLE') whereClause.accessType = 'ROLE'
    }

    if (authorId) {
      if (authorId === 'me' && session?.user?.id) {
        whereClause.authorId = session.user.id
        // Show all statuses for own items
        delete whereClause.status
      } else if (authorId !== 'me') {
        whereClause.authorId = authorId
      }
    }

    if (username) {
      const user = await db.user.findUnique({ where: { username }, select: { id: true } })
      if (user) whereClause.authorId = user.id
    }

    let orderByClause: any = {}
    if (sortBy === 'price') orderByClause = { price: order }
    else if (sortBy === 'downloads') orderByClause = { downloads: 'desc' }
    else if (sortBy === 'likes') orderByClause = { likes: 'desc' }
    else if (sortBy === 'views') orderByClause = { views: 'desc' }
    else orderByClause = { createdAt: 'desc' }

    const [items, total] = await Promise.all([
      db.item.findMany({
        where: whereClause,
        take: limit,
        skip: offset,
        include: {
          author: {
            select: { id: true, username: true, avatar: true, isVerified: true, sellerLevel: true }
          },
          category: { select: { name: true, slug: true } },
          versions: {
            where: { isActive: true },
            orderBy: { createdAt: 'desc' },
            take: 1
          },
          screenshots: { orderBy: { sortOrder: 'asc' }, take: 1 },
          _count: { select: { reviews: true } }
        },
        orderBy: orderByClause
      }),
      db.item.count({ where: whereClause })
    ])

    const processedItems = items.map(item => {
      const latestVersion = item.versions[0]
      let logo = item.logo
      if (!logo && item.screenshots.length > 0) logo = item.screenshots[0].url
      if (!logo) logo = '/placeholder-item.png'
      return {
        ...item,
        logo,
        latestVersion,
        hasFiles: !!latestVersion,
        downloadUrl: latestVersion?.downloadUrl || null
      }
    })

    return NextResponse.json({ items: processedItems, total })
  } catch (error) {
    console.error('Items fetch error:', error)
    return NextResponse.json({ error: 'Failed to fetch items', items: [], total: 0 }, { status: 500 })
  }
}
