import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    let item = await db.item.findUnique({ where: { slug }, select: { id: true, authorId: true } })
    if (!item) {
      item = await db.item.findUnique({ where: { id: slug }, select: { id: true, authorId: true } }).catch(() => null)
    }
    if (!item) return NextResponse.json({ error: 'Item not found' }, { status: 404 })

    const isAdmin = ['ADMIN', 'SUPER_ADMIN', 'MODERATOR'].includes(session.user.role || '')
    const isOwner = session.user.id === item.authorId

    if (!isAdmin && !isOwner) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    let body: any
    const contentType = request.headers.get('content-type') || ''
    if (contentType.includes('multipart/form-data')) {
      const formData = await request.formData()
      body = {
        title: formData.get('title') as string,
        description: formData.get('description') as string,
        shortDesc: formData.get('shortDesc') as string,
        categoryId: formData.get('categoryId') as string,
        price: parseFloat(formData.get('price') as string || '0'),
        tags: formData.get('tags') as string,
        accessType: formData.get('accessType') as string,
        requiredRole: formData.get('requiredRole') as string,
      }
    } else {
      body = await request.json()
    }

    const { status: itemStatus, featured, title, description, shortDesc, categoryId, price, tags, accessType, requiredRole } = body
    const updateData: any = {}

    if (isAdmin) {
      if (itemStatus) updateData.status = itemStatus
      if (typeof featured === 'boolean') updateData.featured = featured
    }

    if (isOwner || isAdmin) {
      if (title) updateData.title = title
      if (description) updateData.description = description
      if (shortDesc !== undefined) updateData.shortDesc = shortDesc
      if (categoryId) updateData.categoryId = categoryId
      if (price !== undefined) updateData.price = price
      if (tags) updateData.tags = typeof tags === 'string' ? tags.split(',').map((t: string) => t.trim()).filter(Boolean) : tags
      if (accessType) updateData.accessType = accessType
      if (requiredRole !== undefined) updateData.requiredRole = requiredRole || null
    }

    const updatedItem = await db.item.update({
      where: { id: item.id },
      data: updateData,
      include: {
        author: { select: { username: true } },
        category: { select: { name: true } }
      }
    })

    return NextResponse.json(updatedItem)
  } catch (error) {
    console.error('Error updating item:', error)
    return NextResponse.json({ error: 'Failed to update item' }, { status: 500 })
  }
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ slug: string }> }
) {
  try {
    const { slug } = await params

    const session = await getServerSession(authOptions)
    const includeObj = {
      author: { select: { id: true, username: true, avatar: true } },
      category: { select: { name: true, slug: true } },
      subcategory: { select: { name: true, slug: true } },
      versions: { where: { isActive: true }, orderBy: { createdAt: 'desc' as const } },
      screenshots: { orderBy: { sortOrder: 'asc' as const } },
      _count: { select: { reviews: true } },
    }

    let item = await db.item.findUnique({ where: { slug }, include: includeObj })
    if (!item) {
      item = await db.item.findUnique({ where: { id: slug }, include: includeObj }).catch(() => null)
    }

    if (!item) {
      return NextResponse.json({ error: 'Item not found' }, { status: 404 })
    }

    const isOwner = session?.user?.id === item.authorId
    const isAdmin = ['ADMIN', 'SUPER_ADMIN'].includes(session?.user?.role || '')
    if (item.status !== 'APPROVED' && !isOwner && !isAdmin) {
      return NextResponse.json({ error: 'Item not available' }, { status: 403 })
    }

    // Increment view count
    await db.item.update({
      where: { id: item.id },
      data: {
        views: {
          increment: 1,
        },
      },
    })

    return NextResponse.json(item)
  } catch (error) {
    console.error('Error fetching item:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}