import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

/**
 * POST: Claim a campaign discount (applies to user's wallet or next purchase)
 */
export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
  }

  try {
    const { campaignId } = await req.json()
    if (!campaignId) {
      return NextResponse.json({ error: 'Campaign ID required' }, { status: 400 })
    }

    // Check if campaign exists and is active
    const campaign = await db.campaign.findUnique({
      where: { id: campaignId }
    })

    if (!campaign || !campaign.isActive) {
      return NextResponse.json({ error: 'Campaign not found or inactive' }, { status: 404 })
    }

    const now = new Date()
    if (now < campaign.startDate || now > campaign.endDate) {
      return NextResponse.json({ error: 'Campaign is not active' }, { status: 400 })
    }

    // Create or update user's claimed campaign list
    const user = await db.user.findUnique({
      where: { id: session.user.id },
      select: { claimedCampaigns: true }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    let claimedCampaigns = Array.isArray(user.claimedCampaigns) ? user.claimedCampaigns as string[] : []
    
    if (claimedCampaigns.includes(campaignId)) {
      return NextResponse.json({ error: 'Campaign already claimed' }, { status: 400 })
    }

    claimedCampaigns = [...claimedCampaigns, campaignId]

    await db.user.update({
      where: { id: session.user.id },
      data: { claimedCampaigns }
    })

    return NextResponse.json({ 
      success: true, 
      message: `You claimed ${campaign.discountPercent}% discount!`,
      discount: campaign.discountPercent
    })
  } catch (error) {
    console.error('Error claiming campaign:', error)
    return NextResponse.json({ error: 'Failed to claim campaign' }, { status: 500 })
  }
}
