import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

// GET /api/tasks?mine=created|submitted&status=OPEN&category=
export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  const url = new URL(req.url)
  const mine = url.searchParams.get('mine')
  const status = url.searchParams.get('status')
  const category = url.searchParams.get('category')

  const where: any = {}
  if (mine === 'created') {
    if (!session?.user?.id) return NextResponse.json({ error: 'Sign in' }, { status: 401 })
    where.creatorId = session.user.id
  } else {
    where.status = status || 'OPEN'
  }
  if (category) where.category = category

  const tasks = await db.earnTask.findMany({
    where,
    orderBy: { createdAt: 'desc' },
    take: 100,
    include: {
      creator: { select: { id: true, username: true, avatar: true } },
      _count: { select: { submissions: true } },
    },
  })

  return NextResponse.json({ tasks })
}

// POST /api/tasks  — create task, lock budget = rewardAmount * totalSlots
export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Sign in to create a task' }, { status: 401 })

  const body = await req.json()
  const title = String(body.title || '').trim().slice(0, 200)
  const description = String(body.description || '').trim().slice(0, 1000)
  const instructions = String(body.instructions || '').trim().slice(0, 4000)
  const proofType = String(body.proofType || 'SCREENSHOT').slice(0, 32)
  const url = body.url ? String(body.url).trim().slice(0, 500) : null
  const category = body.category ? String(body.category).trim().slice(0, 64) : null
  const rewardAmount = Number(body.rewardAmount) || 0
  const totalSlots = Math.max(1, Math.floor(Number(body.totalSlots) || 1))
  const deadline = body.deadline ? new Date(body.deadline) : null
  const videoTutorialUrl = body.videoTutorialUrl ? String(body.videoTutorialUrl).trim().slice(0, 500) : null
  const maxPerUser = Math.max(1, Math.min(50, Math.floor(Number(body.maxPerUser) || 1)))
  const requiresLink = !!body.requiresLink
  const difficulty = body.difficulty ? String(body.difficulty).slice(0, 32) : null
  const estimatedMinutes = body.estimatedMinutes ? Math.max(1, Math.floor(Number(body.estimatedMinutes))) : null
  const bannerImage = body.bannerImage ? String(body.bannerImage).trim().slice(0, 500) : null

  if (!title || !description || !instructions) {
    return NextResponse.json({ error: 'Title, description, and instructions are required' }, { status: 400 })
  }
  if (rewardAmount < 0.01) {
    return NextResponse.json({ error: 'Reward must be at least 0.01' }, { status: 400 })
  }

  const totalCost = rewardAmount * totalSlots
  const creator = await db.user.findUnique({ where: { id: session.user.id }, select: { walletBalance: true } })
  if (!creator || creator.walletBalance < totalCost) {
    return NextResponse.json({ error: `Insufficient balance. Need ${totalCost.toFixed(2)}, have ${(creator?.walletBalance || 0).toFixed(2)}` }, { status: 400 })
  }

  const task = await db.$transaction(async (tx) => {
    await tx.user.update({
      where: { id: session.user.id },
      data: { walletBalance: { decrement: totalCost } },
    })
    await tx.transaction.create({
      data: {
        userId: session.user.id,
        amount: totalCost,
        method: 'wallet',
        type: 'TASK_BUDGET_LOCK',
        status: 'COMPLETED',
        reference: `task:${title.slice(0, 60)}`,
      },
    }).catch(() => null)
    return tx.earnTask.create({
      data: {
        creatorId: session.user.id,
        title, description, instructions, proofType,
        url, category,
        rewardAmount, totalSlots,
        budgetLocked: totalCost,
        status: 'OPEN',
        deadline,
        videoTutorialUrl,
        maxPerUser,
        requiresLink,
        difficulty,
        estimatedMinutes,
        bannerImage,
      },
    })
  })

  return NextResponse.json({ task })
}
