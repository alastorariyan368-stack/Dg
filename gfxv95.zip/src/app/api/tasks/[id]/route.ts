import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

export async function GET(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params
  const session = await getServerSession(authOptions)

  const task = await db.earnTask.findUnique({
    where: { id },
    include: {
      creator: { select: { id: true, username: true, avatar: true } },
      submissions: {
        orderBy: { createdAt: 'desc' },
        include: { worker: { select: { id: true, username: true, avatar: true } } },
      },
    },
  })
  if (!task) return NextResponse.json({ error: 'Not found' }, { status: 404 })

  const isOwner = session?.user?.id === task.creatorId
  const mySubmission = session?.user?.id ? task.submissions.find(s => s.workerId === session.user.id) : null

  return NextResponse.json({
    task: {
      ...task,
      submissions: isOwner ? task.submissions : [], // only owner sees all submissions
    },
    isOwner,
    mySubmission,
  })
}

export async function DELETE(_req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Sign in' }, { status: 401 })

  const task = await db.earnTask.findUnique({ where: { id } })
  if (!task) return NextResponse.json({ error: 'Not found' }, { status: 404 })
  const isAdmin = ['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')
  if (task.creatorId !== session.user.id && !isAdmin) {
    return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
  }

  // Refund unspent budget back to creator
  const refund = Math.max(0, task.budgetLocked - task.filledSlots * task.rewardAmount)
  await db.$transaction(async (tx) => {
    if (refund > 0) {
      await tx.user.update({ where: { id: task.creatorId }, data: { walletBalance: { increment: refund } } })
      await tx.transaction.create({
        data: {
          userId: task.creatorId, amount: refund, method: 'wallet',
          type: 'TASK_REFUND', status: 'COMPLETED', reference: `task:${task.title.slice(0,60)}`,
        },
      }).catch(() => null)
    }
    await tx.earnTask.delete({ where: { id } })
  })

  return NextResponse.json({ success: true, refunded: refund })
}
