import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

// Owner approves or rejects a submission. On approve, transfer reward from
// the locked budget to the worker.
export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Sign in' }, { status: 401 })

  const body = await req.json()
  const submissionId = String(body.submissionId || '')
  const action = String(body.action || '') // 'approve' | 'reject'
  const reason = body.reason ? String(body.reason).slice(0, 500) : null

  const task = await db.earnTask.findUnique({ where: { id } })
  if (!task) return NextResponse.json({ error: 'Task not found' }, { status: 404 })
  const isAdmin = ['ADMIN', 'SUPER_ADMIN'].includes(session.user.role || '')
  if (task.creatorId !== session.user.id && !isAdmin) {
    return NextResponse.json({ error: 'Only the task owner can review' }, { status: 403 })
  }

  const submission = await db.earnTaskSubmission.findUnique({ where: { id: submissionId } })
  if (!submission || submission.taskId !== id) return NextResponse.json({ error: 'Submission not found' }, { status: 404 })
  if (submission.status !== 'PENDING') return NextResponse.json({ error: 'Already reviewed' }, { status: 400 })

  if (action === 'approve') {
    if (task.filledSlots >= task.totalSlots) {
      return NextResponse.json({ error: 'All slots are already filled' }, { status: 400 })
    }
    await db.$transaction(async (tx) => {
      // Transfer reward from locked budget to worker wallet
      await tx.user.update({
        where: { id: submission.workerId },
        data: { walletBalance: { increment: task.rewardAmount } },
      })
      await tx.earnTask.update({
        where: { id: task.id },
        data: {
          filledSlots: { increment: 1 },
          budgetLocked: { decrement: task.rewardAmount },
          status: task.filledSlots + 1 >= task.totalSlots ? 'COMPLETED' : 'OPEN',
        },
      })
      await tx.earnTaskSubmission.update({
        where: { id: submissionId },
        data: { status: 'APPROVED', reviewedAt: new Date() },
      })
      await tx.transaction.create({
        data: {
          userId: submission.workerId,
          amount: task.rewardAmount,
          method: 'wallet',
          type: 'TASK_EARN',
          status: 'COMPLETED',
          reference: `task:${task.title.slice(0, 60)}`,
        },
      }).catch(() => null)
      await tx.notification.create({
        data: {
          userId: submission.workerId,
          type: 'ITEM_APPROVED' as any,
          title: '✅ Task approved!',
          content: `You earned ${task.rewardAmount.toFixed(2)} for completing "${task.title}".`,
        },
      }).catch(() => null)
    })
    return NextResponse.json({ success: true, status: 'APPROVED' })
  }

  if (action === 'reject') {
    await db.$transaction(async (tx) => {
      await tx.earnTaskSubmission.update({
        where: { id: submissionId },
        data: { status: 'REJECTED', rejectReason: reason, reviewedAt: new Date() },
      })
      await tx.notification.create({
        data: {
          userId: submission.workerId,
          type: 'ITEM_REJECTED' as any,
          title: 'Task submission rejected',
          content: `Your submission for "${task.title}" was rejected. ${reason ? 'Reason: ' + reason : ''}`,
        },
      }).catch(() => null)
    })
    return NextResponse.json({ success: true, status: 'REJECTED' })
  }

  return NextResponse.json({ error: 'Invalid action' }, { status: 400 })
}
