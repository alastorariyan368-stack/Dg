import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

// Worker submits proof of completion
export async function POST(req: NextRequest, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params
  const session = await getServerSession(authOptions)
  if (!session?.user?.id) return NextResponse.json({ error: 'Sign in to complete tasks' }, { status: 401 })

  const task = await db.earnTask.findUnique({ where: { id } })
  if (!task) return NextResponse.json({ error: 'Task not found' }, { status: 404 })
  if (task.status !== 'OPEN') return NextResponse.json({ error: 'Task is closed' }, { status: 400 })
  if (task.creatorId === session.user.id) return NextResponse.json({ error: 'You cannot complete your own task' }, { status: 400 })
  if (task.filledSlots >= task.totalSlots) return NextResponse.json({ error: 'No slots remaining' }, { status: 400 })

  const maxPerUser = (task as any).maxPerUser || 1
  const myCount = await db.earnTaskSubmission.count({
    where: { taskId: id, workerId: session.user.id },
  })
  if (myCount >= maxPerUser) {
    return NextResponse.json({ error: `You already submitted this task ${myCount} time(s) (max ${maxPerUser}).` }, { status: 400 })
  }

  const body = await req.json().catch(() => ({}))
  const proofText = body.proofText ? String(body.proofText).trim().slice(0, 4000) : null
  const proofImage = body.proofImage ? String(body.proofImage).trim().slice(0, 1000) : null
  const proofUrl = body.proofUrl ? String(body.proofUrl).trim().slice(0, 1000) : null
  const proofImagesArr: string[] = Array.isArray(body.proofImages)
    ? body.proofImages.filter((s: any) => typeof s === 'string').slice(0, 10).map((s: string) => s.slice(0, 1000))
    : []
  const proofExtra = body.proofExtra && typeof body.proofExtra === 'object' ? body.proofExtra : null

  if (!proofText && !proofImage && !proofUrl && proofImagesArr.length === 0) {
    return NextResponse.json({ error: 'Provide proof text, image URL, screenshot, or link.' }, { status: 400 })
  }

  if ((task as any).requiresLink && !proofUrl) {
    return NextResponse.json({ error: 'This task requires a verification link in the "Proof URL" field.' }, { status: 400 })
  }

  const submission = await db.earnTaskSubmission.create({
    data: {
      taskId: id,
      workerId: session.user.id,
      proofText,
      proofImage: proofImage || (proofImagesArr[0] ?? null),
      proofImages: proofImagesArr,
      proofUrl,
      proofExtra: proofExtra as any,
      status: 'PENDING',
    },
  })

  // Notify the task creator
  try {
    await db.notification.create({
      data: {
        userId: task.creatorId,
        type: 'ITEM_APPROVED' as any,
        title: 'New task submission',
        content: `Someone submitted proof for your task "${task.title}". Review it in Tasks.`,
      },
    })
  } catch {}

  return NextResponse.json({ submission })
}
