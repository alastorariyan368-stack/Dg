import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { withRetry } from '@/lib/db-retry'

export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ transactions: [] }, { status: 200 })
    }

    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type')
    const method = searchParams.get('method')
    const limit = parseInt(searchParams.get('limit') || '100')

    const where: any = { userId: session.user.id }
    if (type) where.type = type
    if (method) where.method = method

    const transactions = await withRetry(
      () => db.transaction.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: limit
      }),
      'Fetch transactions'
    )

    return NextResponse.json({ transactions: transactions || [] }, { status: 200 })
  } catch (error) {
    console.error('Transactions fetch error:', error)
    return NextResponse.json({ transactions: [] }, { status: 200 })
  }
}
