import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const limit = Math.min(parseInt(searchParams.get('limit') || '20'), 100)
    const offset = parseInt(searchParams.get('offset') || '0')
    const status = searchParams.get('status') || 'APPROVED'
    const language = searchParams.get('language')
    const type = searchParams.get('type')
    const search = searchParams.get('search')
    const authorId = searchParams.get('authorId')
    const session = await getServerSession(authOptions)

    const whereClause: any = {}

    if (authorId === 'me' && session?.user?.id) {
      whereClause.authorId = session.user.id
    } else if (authorId) {
      whereClause.authorId = authorId
      whereClause.status = 'APPROVED'
    } else {
      whereClause.status = status
    }

    if (language) whereClause.language = language
    if (type) whereClause.type = type
    if (search) {
      whereClause.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
      ]
    }

    const [projects, total] = await Promise.all([
      db.codeProject.findMany({
        where: whereClause,
        take: limit,
        skip: offset,
        orderBy: { createdAt: 'desc' },
        include: {
          author: { select: { id: true, username: true, avatar: true, isVerified: true } },
          _count: { select: { codeLikes: true } }
        }
      }),
      db.codeProject.count({ where: whereClause })
    ])

    return NextResponse.json({ projects, total, limit, offset })
  } catch (error) {
    console.error('Error fetching code projects:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { title, description, shortDesc, language, type, fileUrl, previewUrl, screenshots, tags, coverImage } = body

    if (!title) {
      return NextResponse.json({ error: 'Title is required' }, { status: 400 })
    }

    const project = await db.codeProject.create({
      data: {
        title,
        description,
        shortDesc,
        language: language || 'JavaScript',
        type: type || 'Frontend',
        fileUrl,
        previewUrl,
        coverImage: coverImage || null,
        screenshots: screenshots || [],
        tags: tags || [],
        authorId: session.user.id,
        status: 'PENDING',
      },
      include: {
        author: { select: { id: true, username: true, avatar: true } }
      }
    })

    return NextResponse.json({ project }, { status: 201 })
  } catch (error) {
    console.error('Error creating code project:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
