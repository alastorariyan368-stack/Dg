import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import crypto from 'crypto'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  try {
    const keys = await db.externalApiKey.findMany({
      where: { ownerId: (session.user as any).id },
      orderBy: { createdAt: 'desc' },
      select: {
        id: true, name: true, key: true, permissions: true,
        webhookUrl: true, isActive: true, requestCount: true,
        lastUsedAt: true, createdAt: true,
      },
    })
    return NextResponse.json({ keys })
  } catch (error: any) {
    console.error('[developer/keys GET]', error)
    return NextResponse.json({ keys: [], error: 'Failed to load keys' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const body = await req.json().catch(() => ({}))
  const { name, webhookUrl, permissions } = body

  if (!name?.trim()) return NextResponse.json({ error: 'Name is required' }, { status: 400 })

  const trimmedWebhook = webhookUrl?.trim()
  if (trimmedWebhook && !trimmedWebhook.startsWith('http')) {
    return NextResponse.json({ error: 'Webhook URL must start with http:// or https://' }, { status: 400 })
  }

  try {
    const key = 'gfx_' + crypto.randomBytes(28).toString('hex')
    const created = await db.externalApiKey.create({
      data: {
        name: name.trim(),
        key,
        ownerId: (session.user as any).id,
        webhookUrl: trimmedWebhook || null,
        permissions: permissions || ['payment:deposit', 'payment:status'],
      },
    })
    return NextResponse.json({ key: created })
  } catch (error: any) {
    console.error('[developer/keys POST]', error)
    return NextResponse.json({ error: 'Failed to create API key' }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { id } = await req.json().catch(() => ({}))
  if (!id) return NextResponse.json({ error: 'Key ID required' }, { status: 400 })

  try {
    const existing = await db.externalApiKey.findFirst({
      where: { id, ownerId: (session.user as any).id },
    })
    if (!existing) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    await db.externalApiKey.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error: any) {
    console.error('[developer/keys DELETE]', error)
    return NextResponse.json({ error: 'Failed to delete key' }, { status: 500 })
  }
}

export async function PATCH(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

  const { id, isActive } = await req.json().catch(() => ({}))
  if (!id) return NextResponse.json({ error: 'Key ID required' }, { status: 400 })

  try {
    const existing = await db.externalApiKey.findFirst({
      where: { id, ownerId: (session.user as any).id },
    })
    if (!existing) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    const updated = await db.externalApiKey.update({
      where: { id },
      data: { isActive: Boolean(isActive) },
    })
    return NextResponse.json({ key: updated })
  } catch (error: any) {
    console.error('[developer/keys PATCH]', error)
    return NextResponse.json({ error: 'Failed to update key' }, { status: 500 })
  }
}
