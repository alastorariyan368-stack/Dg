import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

const MAX_FILE_SIZE = 200 * 1024 * 1024 // 200MB per file
const BINARY_EXTENSIONS = ['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'ico', 'woff', 'woff2', 'ttf', 'eot', 'pdf', 'zip']
const TEXT_EXTENSIONS = ['html', 'css', 'js', 'ts', 'jsx', 'tsx', 'json', 'md', 'txt', 'py', 'sh', 'env', 'yml', 'yaml', 'xml', 'php', 'rb', 'go', 'rs', 'java', 'c', 'cpp', 'h', 'cs', 'swift']

function getLanguage(ext: string): string {
  const map: Record<string, string> = {
    html: 'html', css: 'css', js: 'javascript', jsx: 'javascript',
    ts: 'typescript', tsx: 'typescript', json: 'json', md: 'markdown',
    py: 'python', sh: 'shell', yml: 'yaml', yaml: 'yaml', xml: 'xml',
    php: 'php', rb: 'ruby', go: 'go', rs: 'rust', java: 'java',
    c: 'c', cpp: 'cpp', h: 'c', cs: 'csharp', swift: 'swift',
    txt: 'text', env: 'text',
  }
  return map[ext] || 'text'
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const formData = await req.formData()
    const deployId = formData.get('deployId') as string
    const existingFilesRaw = formData.get('existingFiles') as string
    const mode = (formData.get('mode') as string) || 'merge' // 'merge' | 'replace'

    if (!deployId) return NextResponse.json({ error: 'deployId required' }, { status: 400 })

    const deployment = await db.appDeployment.findFirst({
      where: { id: deployId, userId: session.user.id },
    })
    if (!deployment) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    const uploadedFiles = formData.getAll('files') as File[]
    if (!uploadedFiles || uploadedFiles.length === 0) return NextResponse.json({ error: 'No files provided' }, { status: 400 })

    const existingFiles: any[] = existingFilesRaw ? JSON.parse(existingFilesRaw) : (Array.isArray(deployment.files) ? deployment.files : [])

    const newFiles: any[] = []
    const errors: string[] = []

    for (const file of uploadedFiles) {
      if (file.size > MAX_FILE_SIZE) { errors.push(`${file.name}: too large (max 200MB)`); continue }

      const ext = file.name.split('.').pop()?.toLowerCase() || ''
      const isBinary = BINARY_EXTENSIONS.includes(ext)
      const relativeName = (file as any).webkitRelativePath || file.name

      try {
        if (isBinary) {
          const buffer = await file.arrayBuffer()
          const base64 = Buffer.from(buffer).toString('base64')
          newFiles.push({
            name: relativeName,
            language: 'binary',
            content: `data:${file.type || 'application/octet-stream'};base64,${base64}`,
            size: file.size,
            binary: true,
          })
        } else {
          const text = await file.text()
          newFiles.push({
            name: relativeName,
            language: getLanguage(ext),
            content: text,
            size: file.size,
            binary: false,
          })
        }
      } catch (e) {
        errors.push(`${file.name}: failed to read`)
      }
    }

    let mergedFiles: any[]
    if (mode === 'replace') {
      mergedFiles = newFiles
    } else {
      // merge: new files override existing by name
      const map = new Map(existingFiles.map(f => [f.name, f]))
      for (const f of newFiles) map.set(f.name, f)
      mergedFiles = Array.from(map.values())
    }

    const timestamp = new Date().toISOString()
    const logLine = `[${timestamp}] Uploaded ${newFiles.length} file(s): ${newFiles.map(f => f.name).join(', ')}\n`

    const updated = await db.appDeployment.update({
      where: { id: deployId },
      data: { files: mergedFiles as any, logs: (deployment.logs || '') + logLine },
    })

    return NextResponse.json({ deployment: updated, uploaded: newFiles.length, errors })
  } catch (error) {
    console.error('Upload error:', error)
    return NextResponse.json({ error: 'Upload failed' }, { status: 500 })
  }
}
