import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const deployments = await db.appDeployment.findMany({
      where: { userId: session.user.id },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json(deployments)
  } catch (error) {
    console.error('Deploy GET error:', error)
    return NextResponse.json({ error: 'Failed to fetch deployments' }, { status: 500 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const body = await req.json()
    const { name, type = 'html', files = [] } = body

    if (!name?.trim()) return NextResponse.json({ error: 'App name required' }, { status: 400 })

    const existing = await db.appDeployment.count({ where: { userId: session.user.id } })
    if (existing >= 5) return NextResponse.json({ error: 'Max 5 deployments per user' }, { status: 400 })

    const deployment = await db.appDeployment.create({
      data: {
        userId: session.user.id,
        name: name.trim(),
        type,
        status: 'stopped',
        files,
        logs: `[${new Date().toISOString()}] App "${name}" created.\n`,
      },
    })

    return NextResponse.json(deployment, { status: 201 })
  } catch (error) {
    console.error('Deploy POST error:', error)
    return NextResponse.json({ error: 'Failed to create deployment' }, { status: 500 })
  }
}
