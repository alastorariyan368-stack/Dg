import { NextRequest } from 'next/server'
import { runDeployment, DeployRequest } from '@/lib/deploy/installer'

export async function POST(request: NextRequest) {
  try {
    const body: DeployRequest = await request.json()
    const encoder = new TextEncoder()

    const stream = new ReadableStream({
      async start(controller) {
        const send = (event: string, data: string) => {
          controller.enqueue(encoder.encode(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`))
        }

        await runDeployment(body, (event) => {
          send(event.type, event.message)
        })

        controller.close()
      },
    })

    return new Response(stream, {
      headers: {
        'Content-Type': 'text/event-stream',
        'Cache-Control': 'no-cache',
        Connection: 'keep-alive',
      },
    })
  } catch (e: any) {
    return new Response(
      `event: error\ndata: ${JSON.stringify(e.message)}\n\n`,
      { headers: { 'Content-Type': 'text/event-stream' } }
    )
  }
}
