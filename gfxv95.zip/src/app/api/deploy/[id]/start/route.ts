import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { startApp } from '@/lib/app-runner'

export const dynamic = 'force-dynamic'

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const deployment = await db.appDeployment.findFirst({
      where: { id, userId: session.user.id },
    })
    if (!deployment) return NextResponse.json({ error: 'Not found' }, { status: 404 })
    if (deployment.status === 'running') return NextResponse.json({ error: 'Already running' }, { status: 400 })

    const files = Array.isArray(deployment.files) ? deployment.files as any[] : []
    const { port, url, logs } = await startApp(id, deployment.type, files)

    const fullLogs = (deployment.logs || '') + logs

    const updated = await db.appDeployment.update({
      where: { id },
      data: {
        status: 'running',
        logs: fullLogs.slice(-20000),
        url,
      },
    })

    return NextResponse.json(updated)
  } catch (error: any) {
    console.error('[deploy/start] error:', error?.message || error)
    return NextResponse.json({ error: 'Failed to start' }, { status: 500 })
  }
}
