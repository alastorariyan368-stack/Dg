import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { getAppInfo } from '@/lib/app-runner'

export const dynamic = 'force-dynamic'

export async function GET(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const deployment = await db.appDeployment.findFirst({
      where: { id, userId: session.user.id },
      select: { id: true, status: true, logs: true },
    })
    if (!deployment) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    const live = getAppInfo(id)
    const logs = live?.logs || deployment.logs || ''

    return NextResponse.json({ logs, running: live?.running ?? (deployment.status === 'running') })
  } catch (error: any) {
    return NextResponse.json({ error: 'Failed' }, { status: 500 })
  }
}
