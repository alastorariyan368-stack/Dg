import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { stopApp } from '@/lib/app-runner'

export const dynamic = 'force-dynamic'

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const deployment = await db.appDeployment.findFirst({
      where: { id, userId: session.user.id },
    })
    if (!deployment) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    const processLogs = await stopApp(id)

    const timestamp = new Date().toISOString()
    const stopLog = `${processLogs ? processLogs + '\n' : ''}[${timestamp}] App stopped.\n`
    const fullLogs = ((deployment.logs || '') + stopLog).slice(-20000)

    const updated = await db.appDeployment.update({
      where: { id },
      data: { status: 'stopped', logs: fullLogs, url: null },
    })

    return NextResponse.json(updated)
  } catch (error: any) {
    console.error('[deploy/stop] error:', error?.message || error)
    return NextResponse.json({ error: 'Failed to stop' }, { status: 500 })
  }
}
