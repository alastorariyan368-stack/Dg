import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    const { requestId } = await request.json()

    if (!requestId) {
      return NextResponse.json(
        { error: 'Request ID is required' },
        { status: 400 }
      )
    }

    // Find the friend request
    const friendRequest = await db.friendRequest.findUnique({
      where: { id: requestId },
      include: { sender: true, receiver: true }
    })

    if (!friendRequest) {
      return NextResponse.json(
        { error: 'Friend request not found' },
        { status: 404 }
      )
    }

    if (friendRequest.receiverId !== user.id) {
      return NextResponse.json(
        { error: 'Unauthorized' },
        { status: 403 }
      )
    }

    if (friendRequest.status !== 'PENDING') {
      return NextResponse.json(
        { error: 'Friend request already processed' },
        { status: 400 }
      )
    }

    // Update request status
    await db.friendRequest.update({
      where: { id: requestId },
      data: { status: 'ACCEPTED' }
    })

    // Create friend relationship
    const user1Id = friendRequest.senderId < friendRequest.receiverId ? friendRequest.senderId : friendRequest.receiverId
    const user2Id = friendRequest.senderId < friendRequest.receiverId ? friendRequest.receiverId : friendRequest.senderId

    await db.friend.create({
      data: {
        user1Id,
        user2Id
      }
    })

    // Create notification for sender
    await db.notification.create({
      data: {
        userId: friendRequest.senderId,
        title: 'Friend Request Accepted',
        content: `${user.username} accepted your friend request`,
        type: 'FRIEND_REQUEST_RECEIVED'
      }
    })

    // Emit socket notification if available
    if ((global as any).sendNotification) {
      await (global as any).sendNotification(friendRequest.senderId, {
        title: 'Friend Request Accepted',
        content: `${user.username} accepted your friend request`,
        type: 'FRIEND_REQUEST_RECEIVED'
      })
    }

    return NextResponse.json({
      success: true,
      message: 'Friend request accepted'
    })
  } catch (error) {
    console.error('Error accepting friend request:', error)
    return NextResponse.json(
      { error: 'Failed to accept friend request' },
      { status: 500 }
    )
  }
}
