import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { NextRequest, NextResponse } from 'next/server'
import { checkFeature } from '@/lib/feature-toggles'

export async function GET(request: NextRequest) {
  try {
    const blocked = await checkFeature('friends', 'Friends System')
    if (blocked) return blocked
    const session = await getServerSession(authOptions)
    if (!session?.user?.email) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const user = await db.user.findUnique({
      where: { email: session.user.email }
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Get pagination parameters
    const page = Math.max(1, parseInt(request.nextUrl.searchParams.get('page') || '1'))
    const limit = Math.min(100, parseInt(request.nextUrl.searchParams.get('limit') || '50'))
    const skip = (page - 1) * limit
    const sortBy = request.nextUrl.searchParams.get('sortBy') || 'username' // username or recent

    // Count total friends
    const totalFriends = await db.friend.count({
      where: {
        OR: [
          { user1Id: user.id },
          { user2Id: user.id }
        ]
      }
    })

    // Determine sort order
    const orderBy: any = sortBy === 'recent' ? { createdAt: 'desc' } : { user1: { user2: { username: 'asc' } } }

    // Get paginated friends
    const friends = await db.friend.findMany({
      where: {
        OR: [
          { user1Id: user.id },
          { user2Id: user.id }
        ]
      },
      include: {
        user1: {
          select: {
            id: true,
            username: true,
            avatar: true,
            bio: true,
            isActive: true
          }
        },
        user2: {
          select: {
            id: true,
            username: true,
            avatar: true,
            bio: true,
            isActive: true
          }
        }
      },
      skip: skip,
      take: limit,
      orderBy: { createdAt: 'desc' }
    })

    // Format response - extract the friend that is not the current user
    const friendList = friends.map(friend => {
      const isFriend1CurrentUser = friend.user1Id === user.id
      return isFriend1CurrentUser ? friend.user2 : friend.user1
    })

    const totalPages = Math.ceil(totalFriends / limit)

    return NextResponse.json({
      friends: friendList,
      total: totalFriends,
      count: friendList.length,
      page: page,
      limit: limit,
      totalPages: totalPages,
      hasNextPage: page < totalPages,
      hasPreviousPage: page > 1
    })
  } catch (error) {
    console.error('Error fetching friends:', error)
    return NextResponse.json(
      { error: 'Failed to fetch friends' },
      { status: 500 }
    )
  }
}
