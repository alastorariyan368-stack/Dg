import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { db } from '@/lib/db'
import { writeFile, mkdir } from 'fs/promises'
import { existsSync } from 'fs'
import { join } from 'path'
import crypto from 'crypto'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'
export const maxDuration = 300

async function sleep(ms: number) { return new Promise(r => setTimeout(r, ms)) }

async function persistVideo(buffer: Buffer): Promise<string> {
  const dir = join(process.cwd(), 'public', 'uploads', 'google-vids')
  if (!existsSync(dir)) await mkdir(dir, { recursive: true })
  const name = `${crypto.randomUUID()}.mp4`
  await writeFile(join(dir, name), buffer)
  return `/uploads/google-vids/${name}`
}

async function generateWithVeo(apiKey: string, prompt: string, aspectRatio: string, durationSeconds: number) {
  // Submit generation job
  const submitRes = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/veo-2.0-generate-001:predictLongRunning?key=${apiKey}`,
    {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        instances: [{ prompt }],
        parameters: {
          aspectRatio,
          durationSeconds,
          personGeneration: 'allow_all',
          enhancePrompt: true,
          sampleCount: 1,
        },
      }),
    }
  )

  if (!submitRes.ok) {
    const err = await submitRes.json().catch(() => ({})) as any
    throw new Error(err?.error?.message || `Veo submit failed: HTTP ${submitRes.status}`)
  }

  const submitData = await submitRes.json() as any
  const operationName = submitData?.name
  if (!operationName) throw new Error('Veo did not return an operation name')

  // Poll for completion (up to 5 min)
  const start = Date.now()
  while (Date.now() - start < 5 * 60 * 1000) {
    await sleep(5000)
    const pollRes = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/${operationName}?key=${apiKey}`
    )
    if (!pollRes.ok) continue

    const pollData = await pollRes.json() as any
    if (pollData?.done) {
      const videos = pollData?.response?.generatedSamples || pollData?.response?.videos || []
      const video = videos[0]
      const uri = video?.video?.uri || video?.uri
      if (!uri) throw new Error('Veo completed but returned no video URI')

      // Download the video bytes
      const videoRes = await fetch(uri)
      if (!videoRes.ok) throw new Error(`Failed to download Veo video: HTTP ${videoRes.status}`)
      const buf = Buffer.from(await videoRes.arrayBuffer())
      return buf
    }
    // Check for error in operation
    if (pollData?.error) throw new Error(pollData.error.message || 'Veo operation failed')
  }
  throw new Error('Veo video generation timed out after 5 minutes')
}

export async function POST(req: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Please sign in.' }, { status: 401 })
    }

    const body = await req.json().catch(() => ({})) as any
    const { prompt, aspectRatio = '16:9', durationSeconds = 8, mode = 'text-to-video', script, topic } = body

    const finalPrompt = mode === 'script'
      ? `${script || prompt}`
      : mode === 'topic'
      ? `Create a professional video about: ${topic || prompt}. Make it visually engaging with smooth camera movements, professional lighting, and high production quality.`
      : (prompt || '').trim()

    if (!finalPrompt) {
      return NextResponse.json({ error: 'A prompt or topic is required.' }, { status: 400 })
    }

    const settings = await db.siteSettings.findFirst()
    const apiKey = settings?.geminiApiKey?.trim()
    if (!apiKey) {
      return NextResponse.json({
        error: 'Google Gemini API key is not configured. Add it in Admin → AI API Keys.',
      }, { status: 400 })
    }

    const buf = await generateWithVeo(apiKey, finalPrompt, aspectRatio, durationSeconds)
    const url = await persistVideo(buf)

    return NextResponse.json({ videoUrl: url, prompt: finalPrompt, aspectRatio, durationSeconds })
  } catch (error: any) {
    return NextResponse.json({ error: error?.message || 'Video generation failed' }, { status: 500 })
  }
}
