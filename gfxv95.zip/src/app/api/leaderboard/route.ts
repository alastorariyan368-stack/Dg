import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const topSellers = await db.user.findMany({
      where: { role: { in: ['SELLER', 'ADMIN', 'SUPER_ADMIN'] }, totalSales: { gt: 0 } },
      select: {
        id: true,
        username: true,
        avatar: true,
        totalSales: true,
        _count: { select: { items: true } }
      },
      orderBy: { totalSales: 'desc' },
      take: 10
    })

    const topItems = await db.item.findMany({
      where: { status: 'APPROVED' },
      select: {
        id: true,
        title: true,
        slug: true,
        downloads: true,
        views: true,
        likes: true,
        price: true,
        logo: true,
        author: { select: { username: true, avatar: true } }
      },
      orderBy: { downloads: 'desc' },
      take: 10
    })

    return NextResponse.json({ topSellers, topItems })
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch leaderboard' }, { status: 500 })
  }
}
