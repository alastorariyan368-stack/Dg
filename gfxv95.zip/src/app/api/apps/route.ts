import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const limit = Math.min(parseInt(searchParams.get('limit') || '20'), 100)
    const offset = parseInt(searchParams.get('offset') || '0')
    const status = searchParams.get('status') || 'APPROVED'
    const category = searchParams.get('category')
    const platform = searchParams.get('platform')
    const search = searchParams.get('search')
    const authorId = searchParams.get('authorId')
    const session = await getServerSession(authOptions)

    const whereClause: any = {}

    if (authorId === 'me' && session?.user?.id) {
      whereClause.authorId = session.user.id
    } else if (authorId) {
      whereClause.authorId = authorId
      whereClause.status = 'APPROVED'
    } else {
      whereClause.status = status
    }

    if (category) whereClause.category = category
    if (platform) whereClause.platform = platform
    if (search) {
      whereClause.OR = [
        { title: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } },
        { shortDesc: { contains: search, mode: 'insensitive' } },
      ]
    }

    const [apps, total] = await Promise.all([
      db.mobileApp.findMany({
        where: whereClause,
        take: limit,
        skip: offset,
        orderBy: { createdAt: 'desc' },
        include: {
          author: { select: { id: true, username: true, avatar: true, isVerified: true } },
          _count: { select: { appReviews: true } }
        }
      }),
      db.mobileApp.count({ where: whereClause })
    ])

    return NextResponse.json({ apps, total, limit, offset })
  } catch (error) {
    console.error('Error fetching apps:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { title, description, shortDesc, packageName, version, icon, coverImage, screenshots, apkUrl, category, tags, platform, size, minSdk, permissions, changelog } = body

    if (!title || !packageName) {
      return NextResponse.json({ error: 'Title and package name are required' }, { status: 400 })
    }

    const app = await db.mobileApp.create({
      data: {
        title,
        description,
        shortDesc,
        packageName,
        version: version || '1.0.0',
        icon,
        coverImage,
        screenshots: screenshots || [],
        apkUrl,
        category: category || 'General',
        tags: tags || [],
        platform: platform || 'Android',
        size,
        minSdk,
        permissions: permissions || [],
        changelog,
        authorId: session.user.id,
        status: 'PENDING',
      },
      include: {
        author: { select: { id: true, username: true, avatar: true } }
      }
    })

    return NextResponse.json({ app }, { status: 201 })
  } catch (error: any) {
    if (error.code === 'P2002') {
      return NextResponse.json({ error: 'Package name already exists' }, { status: 409 })
    }
    console.error('Error creating app:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
