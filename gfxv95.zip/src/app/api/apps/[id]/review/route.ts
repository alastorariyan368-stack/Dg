import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function POST(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const body = await request.json()
    const { rating, content } = body

    if (!rating || rating < 1 || rating > 5) {
      return NextResponse.json({ error: 'Rating must be between 1 and 5' }, { status: 400 })
    }

    const review = await db.appReview.upsert({
      where: { appId_authorId: { appId: id, authorId: session.user.id } },
      create: { content, rating, appId: id, authorId: session.user.id },
      update: { content, rating },
      include: { author: { select: { id: true, username: true, avatar: true } } }
    })

    // Update average rating
    const reviews = await db.appReview.findMany({ where: { appId: id }, select: { rating: true } })
    const avgRating = reviews.reduce((acc, r) => acc + r.rating, 0) / reviews.length
    await db.mobileApp.update({ where: { id }, data: { rating: avgRating } })

    return NextResponse.json({ review })
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
