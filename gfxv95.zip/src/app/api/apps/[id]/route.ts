import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'

export async function GET(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params

    const app = await db.mobileApp.findUnique({
      where: { id },
      include: {
        author: { select: { id: true, username: true, avatar: true, isVerified: true, bio: true } },
        appReviews: {
          include: { author: { select: { id: true, username: true, avatar: true } } },
          orderBy: { createdAt: 'desc' },
          take: 20
        },
        _count: { select: { appReviews: true } }
      }
    })

    if (!app) {
      return NextResponse.json({ error: 'App not found' }, { status: 404 })
    }

    // Increment downloads when app detail is viewed
    await db.mobileApp.update({ where: { id }, data: { downloads: { increment: 1 } } })

    return NextResponse.json({ app })
  } catch (error) {
    console.error('Error fetching app:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const app = await db.mobileApp.findUnique({ where: { id } })
    if (!app) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    const isAdmin = session.user.role === 'ADMIN' || session.user.role === 'SUPER_ADMIN'
    if (app.authorId !== session.user.id && !isAdmin) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    const body = await request.json()
    const updated = await db.mobileApp.update({
      where: { id },
      data: isAdmin ? body : {
        title: body.title,
        description: body.description,
        shortDesc: body.shortDesc,
        version: body.version,
        icon: body.icon,
        coverImage: body.coverImage,
        screenshots: body.screenshots,
        apkUrl: body.apkUrl,
        category: body.category,
        tags: body.tags,
        changelog: body.changelog,
      }
    })
    return NextResponse.json({ app: updated })
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}

export async function DELETE(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const session = await getServerSession(authOptions)
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const app = await db.mobileApp.findUnique({ where: { id } })
    if (!app) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    const isAdmin = session.user.role === 'ADMIN' || session.user.role === 'SUPER_ADMIN'
    if (app.authorId !== session.user.id && !isAdmin) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 })
    }

    await db.mobileApp.delete({ where: { id } })
    return NextResponse.json({ success: true })
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
