'use client'

import { useState, useEffect, useRef, useCallback, DragEvent, ChangeEvent } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import {
  Server, Plus, Play, Square, Trash2, RefreshCw, Globe, Terminal,
  Loader2, Code2, AlertCircle, CheckCircle, Clock, ExternalLink,
  FileText, X, ArrowLeft, Save, ChevronRight, Eye,
  Copy, Upload, FileCode, FileJson, FileCog, Image as ImageIcon,
  FolderOpen, Folder, ChevronDown, MoreHorizontal, Download, Pencil,
  File, Search, Filter, ZapIcon, Cpu, PlayCircle, StopCircle
} from 'lucide-react'
import { toast } from 'sonner'

/* ─────────── Types ─────────── */
interface DeployFile {
  name: string
  content: string
  language: string
  size?: number
  binary?: boolean
}

interface Deployment {
  id: string
  name: string
  type: string
  status: string
  port?: number
  url?: string
  files?: DeployFile[]
  logs: string
  createdAt: string
  updatedAt: string
}

/* ─────────── Constants ─────────── */
const DEFAULT_FILES: Record<string, DeployFile[]> = {
  html: [{
    name: 'index.html', language: 'html',
    content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" /><meta name="viewport" content="width=device-width,initial-scale=1.0" />
  <title>My App</title>
  <style>
    *{margin:0;padding:0;box-sizing:border-box}
    body{font-family:system-ui,sans-serif;background:#0f0f0f;color:#fff;display:flex;align-items:center;justify-content:center;min-height:100vh}
    .card{text-align:center;padding:2.5rem}
    h1{font-size:2.8rem;background:linear-gradient(135deg,#a855f7,#6366f1);-webkit-background-clip:text;-webkit-text-fill-color:transparent;margin-bottom:.8rem}
    p{color:#888;font-size:1.1rem}
    .badge{display:inline-block;background:#7c3aed20;border:1px solid #7c3aed40;color:#a78bfa;padding:.35rem 1rem;border-radius:9999px;font-size:.8rem;margin-top:1.5rem}
  </style>
</head>
<body>
  <div class="card">
    <h1>🚀 My App</h1>
    <p>Deployed on GfxStore Cloud</p>
    <span class="badge">✓ Live</span>
  </div>
</body>
</html>`,
  }],
  nodejs: [
    { name: 'index.js', language: 'javascript', content: `const http = require('http')
const PORT = process.env.PORT || 3000
http.createServer((req, res) => {
  res.writeHead(200, { 'Content-Type': 'application/json' })
  res.end(JSON.stringify({ message: 'Hello from GfxStore!', path: req.url, time: new Date().toISOString() }))
}).listen(PORT, () => console.log('Server on port ' + PORT))` },
    { name: 'package.json', language: 'json', content: `{\n  "name": "my-app",\n  "version": "1.0.0",\n  "scripts": { "start": "node index.js" }\n}` },
  ],
  react: [{ name: 'index.html', language: 'html', content: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" /><title>React App</title>
  <script src="https://unpkg.com/react@18/umd/react.production.min.js"></script>
  <script src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js"></script>
  <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
  <style>*{margin:0;padding:0;box-sizing:border-box}body{font-family:system-ui;background:#0f0f0f;color:#fff;display:flex;align-items:center;justify-content:center;min-height:100vh}button{background:#7c3aed;color:#fff;border:none;padding:.6rem 1.5rem;border-radius:8px;cursor:pointer}</style>
</head>
<body>
  <div id="root"></div>
  <script type="text/babel">
    function App(){const[c,setC]=React.useState(0);return(<div style={{textAlign:'center'}}><h1 style={{fontSize:'2rem',marginBottom:'1rem'}}>React App ⚛️</h1><p style={{color:'#888',marginBottom:'1.5rem'}}>Count: {c}</p><button onClick={()=>setC(x=>x+1)}>Click!</button></div>)}
    ReactDOM.createRoot(document.getElementById('root')).render(<App/>)
  </script>
</body>
</html>` }],
  python: [{ name: 'app.py', language: 'python', content: `from http.server import HTTPServer, BaseHTTPRequestHandler
import json, os
PORT = int(os.environ.get('PORT', 3000))
class H(BaseHTTPRequestHandler):
    def do_GET(self):
        self.send_response(200)
        self.send_header('Content-Type','application/json')
        self.end_headers()
        self.wfile.write(json.dumps({'message':'Hello from GfxStore!','path':self.path}).encode())
    def log_message(self,f,*a): print(f%a)
HTTPServer(('0.0.0.0',PORT),H).serve_forever()` }],
}

const STATUS_CFG: Record<string, { label: string; color: string; dot: string; border: string }> = {
  running: { label: 'Running', color: 'text-emerald-400', dot: 'bg-emerald-400', border: 'border-emerald-500/30' },
  stopped: { label: 'Stopped', color: 'text-zinc-400', dot: 'bg-zinc-500', border: 'border-white/10' },
  building: { label: 'Building', color: 'text-amber-400', dot: 'bg-amber-400', border: 'border-amber-500/30' },
  error: { label: 'Error', color: 'text-red-400', dot: 'bg-red-400', border: 'border-red-500/30' },
}

function getFileIcon(name: string, binary?: boolean) {
  const ext = name.split('.').pop()?.toLowerCase() || ''
  if (binary || ['png','jpg','jpeg','gif','webp','svg','ico'].includes(ext)) return <ImageIcon className="w-3.5 h-3.5 text-pink-400" />
  if (['json'].includes(ext)) return <FileJson className="w-3.5 h-3.5 text-yellow-400" />
  if (['html'].includes(ext)) return <FileCode className="w-3.5 h-3.5 text-orange-400" />
  if (['css', 'scss', 'sass'].includes(ext)) return <FileCog className="w-3.5 h-3.5 text-blue-400" />
  if (['js','jsx','ts','tsx'].includes(ext)) return <FileCode className="w-3.5 h-3.5 text-yellow-300" />
  if (['py'].includes(ext)) return <FileCode className="w-3.5 h-3.5 text-green-400" />
  if (['md'].includes(ext)) return <FileText className="w-3.5 h-3.5 text-violet-400" />
  return <File className="w-3.5 h-3.5 text-white/40" />
}

function formatBytes(b: number) {
  if (b < 1024) return b + ' B'
  if (b < 1024 * 1024) return (b / 1024).toFixed(1) + ' KB'
  return (b / 1024 / 1024).toFixed(1) + ' MB'
}

/* ══════════════ MAIN PAGE ══════════════ */
export default function AppDeployPage() {
  const { data: session, status } = useSession()
  const router = useRouter()

  const [deployments, setDeployments] = useState<Deployment[]>([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState<Deployment | null>(null)

  // editor state
  const [files, setFiles] = useState<DeployFile[]>([])
  const [activeFile, setActiveFile] = useState<DeployFile | null>(null)
  const [editContent, setEditContent] = useState('')
  const [unsaved, setUnsaved] = useState(false)
  const [saving, setSaving] = useState(false)
  const [actionLoading, setActionLoading] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState<'editor' | 'console' | 'preview'>('editor')
  const [consoleLogs, setConsoleLogs] = useState('')
  const [fileSearch, setFileSearch] = useState('')
  const [renaming, setRenaming] = useState<string | null>(null)
  const [renameVal, setRenameVal] = useState('')
  const [ctxMenu, setCtxMenu] = useState<{ x: number; y: number; file: DeployFile } | null>(null)

  // upload
  const [isDragging, setIsDragging] = useState(false)
  const [uploading, setUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const folderInputRef = useRef<HTMLInputElement>(null)
  const dropZoneRef = useRef<HTMLDivElement>(null)

  // create
  const [createOpen, setCreateOpen] = useState(false)
  const [creating, setCreating] = useState(false)
  const [form, setForm] = useState({ name: '', type: 'html' })
  const [newFileName, setNewFileName] = useState('')
  const [addFileOpen, setAddFileOpen] = useState(false)

  const logsRef = useRef<HTMLPreElement>(null)
  const pollRef = useRef<NodeJS.Timeout | null>(null)

  /* ── Auth ── */
  useEffect(() => {
    if (status === 'loading') return
    if (!session?.user) { router.push('/auth/signin'); return }
    fetchDeployments()
  }, [session, status])

  useEffect(() => {
    if (logsRef.current) logsRef.current.scrollTop = logsRef.current.scrollHeight
  }, [consoleLogs])

  /* ── Poll when running ── */
  useEffect(() => {
    if (pollRef.current) clearInterval(pollRef.current)
    if (selected?.status === 'running') {
      pollRef.current = setInterval(() => refreshDeployment(selected.id), 6000)
    }
    return () => { if (pollRef.current) clearInterval(pollRef.current) }
  }, [selected?.id, selected?.status])

  /* ── Close context menu ── */
  useEffect(() => {
    const handler = () => setCtxMenu(null)
    window.addEventListener('click', handler)
    return () => window.removeEventListener('click', handler)
  }, [])

  /* ─────────── API ─────────── */
  async function fetchDeployments() {
    try {
      const res = await fetch('/api/deploy')
      if (res.ok) {
        const data = await res.json()
        setDeployments(data)
      }
    } catch { toast.error('Failed to load') }
    finally { setLoading(false) }
  }

  function syncSelected(dep: Deployment) {
    setSelected(dep)
    const depFiles = Array.isArray(dep.files) && dep.files.length > 0
      ? (dep.files as DeployFile[])
      : (DEFAULT_FILES[dep.type] || DEFAULT_FILES.html)
    setFiles(depFiles)
    setConsoleLogs(dep.logs || '')
    setActiveFile(depFiles[0] || null)
    setEditContent(depFiles[0]?.content || '')
    setUnsaved(false)
  }

  async function refreshDeployment(id: string) {
    try {
      const [depRes, logsRes] = await Promise.all([
        fetch(`/api/deploy/${id}`),
        fetch(`/api/deploy/${id}/logs`),
      ])
      if (depRes.ok) {
        const data = await depRes.json()
        setDeployments(prev => prev.map(d => d.id === id ? data : d))
        if (selected?.id === id) {
          setSelected(data)
          if (logsRes.ok) {
            const logsData = await logsRes.json()
            setConsoleLogs(logsData.logs || data.logs || '')
          } else {
            setConsoleLogs(data.logs || '')
          }
        }
      }
    } catch {}
  }

  /* ─────────── File actions ─────────── */
  function selectFile(file: DeployFile) {
    if (activeFile && unsaved) {
      setFiles(prev => prev.map(f => f.name === activeFile.name ? { ...f, content: editContent } : f))
    }
    setActiveFile(file)
    setEditContent(file.content)
    setUnsaved(false)
  }

  async function saveFiles(filesToSave?: DeployFile[]) {
    if (!selected) return
    setSaving(true)
    const current = filesToSave || files.map(f => f.name === activeFile?.name ? { ...f, content: editContent } : f)
    try {
      const res = await fetch(`/api/deploy/${selected.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ files: current }),
      })
      if (!res.ok) return toast.error('Save failed')
      setFiles(current)
      setUnsaved(false)
      toast.success('Saved')
    } catch { toast.error('Save failed') }
    finally { setSaving(false) }
  }

  function addNewFile() {
    if (!newFileName.trim()) return
    const name = newFileName.trim()
    if (files.find(f => f.name === name)) { toast.error('File already exists'); return }
    const ext = name.split('.').pop()?.toLowerCase() || ''
    const langMap: Record<string, string> = { js: 'javascript', ts: 'typescript', html: 'html', css: 'css', json: 'json', py: 'python', md: 'markdown', txt: 'text' }
    const newFile: DeployFile = { name, language: langMap[ext] || 'text', content: '' }
    const updated = [...files, newFile]
    setFiles(updated)
    setActiveFile(newFile)
    setEditContent('')
    setUnsaved(false)
    setNewFileName('')
    setAddFileOpen(false)
  }

  function deleteFile(name: string) {
    if (files.length <= 1) { toast.error('Keep at least one file'); return }
    const updated = files.filter(f => f.name !== name)
    setFiles(updated)
    if (activeFile?.name === name) { setActiveFile(updated[0]); setEditContent(updated[0]?.content || '') }
    setCtxMenu(null)
  }

  function startRename(file: DeployFile) {
    setRenaming(file.name)
    setRenameVal(file.name)
    setCtxMenu(null)
  }

  function commitRename(oldName: string) {
    const newName = renameVal.trim()
    if (!newName || newName === oldName) { setRenaming(null); return }
    if (files.find(f => f.name === newName)) { toast.error('Name taken'); return }
    const updated = files.map(f => f.name === oldName ? { ...f, name: newName } : f)
    setFiles(updated)
    if (activeFile?.name === oldName) setActiveFile({ ...activeFile, name: newName })
    setRenaming(null)
  }

  function downloadFile(file: DeployFile) {
    const blob = new Blob([file.content], { type: 'text/plain' })
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = file.name; a.click()
    setCtxMenu(null)
  }

  /* ─────────── Upload ─────────── */
  async function uploadFiles(fileList: FileList, mode: 'merge' | 'replace' = 'merge') {
    if (!selected || !fileList.length) return
    setUploading(true)
    setUploadProgress(10)
    const formData = new FormData()
    formData.append('deployId', selected.id)
    formData.append('mode', mode)
    formData.append('existingFiles', JSON.stringify(files))
    Array.from(fileList).forEach(f => formData.append('files', f))
    setUploadProgress(40)
    try {
      const res = await fetch('/api/deploy/upload', { method: 'POST', body: formData })
      setUploadProgress(80)
      const data = await res.json()
      if (!res.ok) { toast.error(data.error || 'Upload failed'); return }
      const newFiles = Array.isArray(data.deployment.files) ? data.deployment.files as DeployFile[] : files
      setFiles(newFiles)
      setDeployments(prev => prev.map(d => d.id === selected.id ? { ...d, files: newFiles } : d))
      if (data.errors?.length) toast.error(`${data.errors.length} file(s) failed: ${data.errors[0]}`)
      else toast.success(`${data.uploaded} file(s) uploaded!`)
      setUploadProgress(100)
      setTimeout(() => setUploadProgress(0), 800)
      // select first new file
      if (newFiles.length > 0 && !activeFile) { setActiveFile(newFiles[0]); setEditContent(newFiles[0].content) }
    } catch { toast.error('Upload failed') }
    finally { setUploading(false) }
  }

  /* ── Drag & Drop ── */
  function onDragOver(e: DragEvent) { e.preventDefault(); setIsDragging(true) }
  function onDragLeave(e: DragEvent) {
    if (!dropZoneRef.current?.contains(e.relatedTarget as Node)) setIsDragging(false)
  }
  async function onDrop(e: DragEvent) {
    e.preventDefault(); setIsDragging(false)
    const dt = e.dataTransfer
    if (dt?.files?.length) await uploadFiles(dt.files)
  }

  /* ─────────── App actions ─────────── */
  async function startApp() {
    if (!selected) return
    setActionLoading('start')
    setActiveTab('console')
    try {
      await saveFiles()
      const res = await fetch(`/api/deploy/${selected.id}/start`, { method: 'POST' })
      const data = await res.json()
      if (!res.ok) { toast.error(data.error || 'Failed'); return }
      setSelected(data)
      setDeployments(prev => prev.map(d => d.id === selected.id ? data : d))
      setConsoleLogs(data.logs || '')
      toast.success('App started!')
    } catch { toast.error('Failed to start') }
    finally { setActionLoading(null) }
  }

  async function stopApp() {
    if (!selected) return
    setActionLoading('stop')
    try {
      const res = await fetch(`/api/deploy/${selected.id}/stop`, { method: 'POST' })
      const data = await res.json()
      if (!res.ok) { toast.error(data.error || 'Failed'); return }
      setSelected(data); setDeployments(prev => prev.map(d => d.id === selected.id ? data : d)); setConsoleLogs(data.logs || '')
      toast.success('Stopped')
    } catch { toast.error('Failed') }
    finally { setActionLoading(null) }
  }

  async function deleteApp(id: string) {
    if (!confirm('Delete app?')) return
    try {
      const res = await fetch(`/api/deploy/${id}`, { method: 'DELETE' })
      if (!res.ok) { toast.error('Failed'); return }
      setDeployments(prev => prev.filter(d => d.id !== id))
      if (selected?.id === id) setSelected(null)
      toast.success('Deleted')
    } catch { toast.error('Failed') }
  }

  async function createDeployment() {
    if (!form.name.trim()) return toast.error('Name required')
    setCreating(true)
    try {
      const defaultFiles = DEFAULT_FILES[form.type] || DEFAULT_FILES.html
      const res = await fetch('/api/deploy', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, files: defaultFiles }),
      })
      const data = await res.json()
      if (!res.ok) { toast.error(data.error || 'Failed'); return }
      const withFiles = { ...data, files: defaultFiles }
      setDeployments(prev => [withFiles, ...prev])
      setCreateOpen(false); setForm({ name: '', type: 'html' })
      syncSelected(withFiles)
      toast.success('App created!')
    } catch { toast.error('Failed') }
    finally { setCreating(false) }
  }

  /* ─────────── UI ─────────── */
  if (status === 'loading' || loading) return (
    <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
      <Loader2 className="w-8 h-8 animate-spin text-violet-400" />
    </div>
  )

  const cfg = selected ? (STATUS_CFG[selected.status] || STATUS_CFG.stopped) : null
  const filteredFiles = files.filter(f => f.name.toLowerCase().includes(fileSearch.toLowerCase()))

  /* ════ PROJECT LIST ════ */
  if (!selected) return (
    <div className="min-h-screen bg-[#0a0a0f] text-white flex flex-col">
      <Navbar />
      <main className="max-w-5xl mx-auto px-4 py-10 w-full flex-1">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-violet-500/20 border border-violet-500/30 flex items-center justify-center">
              <Server className="w-5 h-5 text-violet-400" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">App Deploy</h1>
              <p className="text-white/40 text-xs">Deploy HTML, Node.js, React or Python apps</p>
            </div>
          </div>
          <Button onClick={() => setCreateOpen(true)} disabled={deployments.length >= 5} className="bg-violet-600 hover:bg-violet-700 gap-2">
            <Plus className="w-4 h-4" /> New App
          </Button>
        </div>

        <div className="grid grid-cols-4 gap-3 mb-8">
          {[
            { label: 'Total', value: deployments.length, color: 'text-violet-400' },
            { label: 'Running', value: deployments.filter(d => d.status === 'running').length, color: 'text-emerald-400' },
            { label: 'Stopped', value: deployments.filter(d => d.status === 'stopped').length, color: 'text-zinc-400' },
            { label: 'Limit', value: `${deployments.length}/5`, color: 'text-amber-400' },
          ].map(s => (
            <div key={s.label} className="bg-white/[0.03] border border-white/[0.06] rounded-xl p-4 text-center">
              <p className={`text-xl font-bold ${s.color}`}>{s.value}</p>
              <p className="text-xs text-white/40 mt-0.5">{s.label}</p>
            </div>
          ))}
        </div>

        {deployments.length === 0 ? (
          <div className="text-center py-24 border border-dashed border-white/10 rounded-2xl">
            <Server className="w-14 h-14 text-white/10 mx-auto mb-4" />
            <p className="text-white/40 text-lg mb-1">No apps yet</p>
            <p className="text-white/25 text-sm mb-6">Create your first app to get started</p>
            <Button onClick={() => setCreateOpen(true)} className="bg-violet-600 hover:bg-violet-700 gap-2">
              <Plus className="w-4 h-4" /> Create First App
            </Button>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-3">
            {deployments.map(dep => {
              const c = STATUS_CFG[dep.status] || STATUS_CFG.stopped
              return (
                <div key={dep.id} onClick={() => syncSelected(dep)}
                  className={`bg-white/[0.03] border ${c.border} rounded-xl p-5 hover:bg-white/[0.06] cursor-pointer transition group`}>
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-violet-500/10 border border-violet-500/20 flex items-center justify-center">
                        <Code2 className="w-5 h-5 text-violet-400" />
                      </div>
                      <div>
                        <h3 className="font-semibold">{dep.name}</h3>
                        <span className="text-[11px] text-white/30 uppercase tracking-wider">{dep.type}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <span className={`w-2 h-2 rounded-full ${c.dot} ${dep.status === 'running' ? 'animate-pulse' : ''}`} />
                      <span className={`text-xs font-medium ${c.color}`}>{c.label}</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between text-xs text-white/30">
                    <div className="flex items-center gap-3">
                      <span className="flex items-center gap-1"><FileText className="w-3.5 h-3.5" />{Array.isArray(dep.files) ? dep.files.length : 0} files</span>
                      <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" />{new Date(dep.updatedAt).toLocaleDateString()}</span>
                    </div>
                    <span className="text-violet-400/60 group-hover:text-violet-400 transition flex items-center gap-1">
                      Open IDE <ChevronRight className="w-3.5 h-3.5" />
                    </span>
                  </div>
                  {dep.url && dep.status === 'running' && (
                    <div className="mt-3 pt-3 border-t border-emerald-500/10 flex items-center gap-2 text-xs text-emerald-400">
                      <Globe className="w-3.5 h-3.5 flex-shrink-0" />
                      <a href={dep.url} target="_blank" rel="noopener noreferrer" onClick={e => e.stopPropagation()} className="hover:underline truncate">{dep.url}</a>
                      <ExternalLink className="w-3 h-3 flex-shrink-0" />
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        )}
      </main>
      <Footer />

      {/* Create Dialog */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="bg-zinc-950 border border-white/10 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><Plus className="w-5 h-5 text-violet-400" /> New App</DialogTitle>
            <DialogDescription className="text-white/50">Starter code auto-generated by type.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <div>
              <Label className="text-sm text-white/60 mb-1.5 block">App Name</Label>
              <Input value={form.name} onChange={e => setForm(p => ({ ...p, name: e.target.value }))}
                placeholder="my-app" className="bg-white/5 border-white/10 text-white placeholder:text-white/30"
                onKeyDown={e => e.key === 'Enter' && createDeployment()} />
            </div>
            <div>
              <Label className="text-sm text-white/60 mb-1.5 block">Type</Label>
              <Select value={form.type} onValueChange={v => setForm(p => ({ ...p, type: v }))}>
                <SelectTrigger className="bg-white/5 border-white/10 text-white"><SelectValue /></SelectTrigger>
                <SelectContent className="bg-zinc-900 border-white/10 text-white">
                  <SelectItem value="html">HTML / Static</SelectItem>
                  <SelectItem value="nodejs">Node.js</SelectItem>
                  <SelectItem value="react">React (CDN)</SelectItem>
                  <SelectItem value="python">Python</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="bg-violet-500/5 border border-violet-500/15 rounded-lg p-3 text-xs text-violet-400/80">
              {deployments.length}/5 slots used
            </div>
            <div className="flex gap-2 pt-1">
              <Button variant="ghost" onClick={() => setCreateOpen(false)} className="flex-1 text-white/60">Cancel</Button>
              <Button onClick={createDeployment} disabled={creating} className="flex-1 bg-violet-600 hover:bg-violet-700 gap-2">
                {creating ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plus className="w-4 h-4" />} Create
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )

  /* ════ IDE VIEW ════ */
  return (
    <div className="h-screen bg-[#0a0a0f] text-white flex flex-col overflow-hidden">
      {/* ── Top Bar ── */}
      <div className="flex items-center gap-2 px-3 py-2 bg-[#111118] border-b border-white/[0.06] flex-shrink-0 z-10">
        <button onClick={() => setSelected(null)} className="text-white/40 hover:text-white transition p-1 rounded-md hover:bg-white/5">
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div className="w-px h-4 bg-white/10" />
        <Code2 className="w-4 h-4 text-violet-400 flex-shrink-0" />
        <span className="font-semibold text-sm">{selected.name}</span>
        <Badge variant="outline" className="text-[10px] border-white/10 text-white/30 py-0 px-1.5">{selected.type.toUpperCase()}</Badge>
        {cfg && (
          <div className="flex items-center gap-1.5 ml-1">
            <span className={`w-2 h-2 rounded-full ${cfg.dot} ${selected.status === 'running' ? 'animate-pulse' : ''}`} />
            <span className={`text-xs font-medium ${cfg.color}`}>{cfg.label}</span>
          </div>
        )}
        {selected.url && selected.status === 'running' && (
          <a href={selected.url} target="_blank" rel="noopener noreferrer"
            className="flex items-center gap-1.5 text-xs text-emerald-400 hover:text-emerald-300 bg-emerald-500/10 border border-emerald-500/20 px-2.5 py-1 rounded-lg ml-1 transition max-w-[220px]">
            <Globe className="w-3.5 h-3.5 flex-shrink-0" />
            <span className="truncate">{selected.url}</span>
            <ExternalLink className="w-3 h-3 flex-shrink-0" />
          </a>
        )}
        <div className="ml-auto flex items-center gap-1.5">
          {unsaved && <span className="text-[10px] text-amber-400 bg-amber-400/10 px-2 py-0.5 rounded-full border border-amber-400/20">Unsaved</span>}
          <Button size="sm" variant="ghost" onClick={() => saveFiles()} disabled={saving}
            className="h-7 px-3 text-xs text-white/50 hover:text-white gap-1.5">
            {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">Save</span>
          </Button>
          {selected.status !== 'running' ? (
            <Button size="sm" onClick={startApp} disabled={!!actionLoading}
              className="h-7 px-3 text-xs bg-emerald-600 hover:bg-emerald-700 gap-1.5">
              {actionLoading === 'start' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <PlayCircle className="w-3.5 h-3.5" />}
              Start
            </Button>
          ) : (
            <Button size="sm" onClick={stopApp} disabled={!!actionLoading}
              className="h-7 px-3 text-xs bg-amber-600 hover:bg-amber-700 gap-1.5">
              {actionLoading === 'stop' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <StopCircle className="w-3.5 h-3.5" />}
              Stop
            </Button>
          )}
          <Button size="sm" variant="ghost" onClick={() => deleteApp(selected.id)}
            className="h-7 w-7 p-0 text-red-400/40 hover:text-red-400 hover:bg-red-500/10">
            <Trash2 className="w-3.5 h-3.5" />
          </Button>
        </div>
      </div>

      {/* ── Upload Progress Bar ── */}
      {uploading && (
        <div className="h-0.5 bg-white/5 flex-shrink-0">
          <div className="h-full bg-violet-500 transition-all duration-300" style={{ width: `${uploadProgress}%` }} />
        </div>
      )}

      {/* ── Main Layout ── */}
      <div className="flex flex-1 overflow-hidden" ref={dropZoneRef} onDragOver={onDragOver} onDragLeave={onDragLeave} onDrop={onDrop}>

        {/* ── File Sidebar ── */}
        <div className="w-52 bg-[#0d0d14] border-r border-white/[0.06] flex flex-col flex-shrink-0">
          {/* Sidebar header */}
          <div className="px-3 py-2 border-b border-white/[0.04] flex-shrink-0">
            <div className="flex items-center justify-between mb-2">
              <span className="text-[10px] font-semibold text-white/25 uppercase tracking-wider">Explorer</span>
              <div className="flex items-center gap-1">
                <button onClick={() => setAddFileOpen(true)} title="New File" className="text-white/30 hover:text-violet-400 transition p-0.5 rounded">
                  <Plus className="w-3.5 h-3.5" />
                </button>
                <button onClick={() => fileInputRef.current?.click()} title="Upload Files" className="text-white/30 hover:text-violet-400 transition p-0.5 rounded">
                  <Upload className="w-3.5 h-3.5" />
                </button>
                <button onClick={() => folderInputRef.current?.click()} title="Upload Folder" className="text-white/30 hover:text-violet-400 transition p-0.5 rounded">
                  <FolderOpen className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            <div className="relative">
              <Search className="absolute left-2 top-1/2 -translate-y-1/2 w-3 h-3 text-white/20" />
              <input value={fileSearch} onChange={e => setFileSearch(e.target.value)}
                placeholder="Filter files..."
                className="w-full bg-white/5 border border-white/8 rounded text-[11px] text-white/70 placeholder:text-white/20 pl-6 pr-2 py-1 outline-none focus:border-violet-500/40" />
            </div>
          </div>

          {/* File list */}
          <div className="flex-1 overflow-y-auto py-1">
            <div className="flex items-center gap-1.5 px-2 py-1">
              <FolderOpen className="w-3.5 h-3.5 text-violet-400/70" />
              <span className="text-[11px] text-white/40 font-medium">{selected.name}</span>
            </div>
            {filteredFiles.map(file => (
              <div key={file.name} onContextMenu={e => { e.preventDefault(); setCtxMenu({ x: e.clientX, y: e.clientY, file }) }}>
                {renaming === file.name ? (
                  <div className="px-2 py-1">
                    <input autoFocus value={renameVal} onChange={e => setRenameVal(e.target.value)}
                      onBlur={() => commitRename(file.name)}
                      onKeyDown={e => { if (e.key === 'Enter') commitRename(file.name); if (e.key === 'Escape') setRenaming(null) }}
                      className="w-full bg-[#1e1e2e] border border-violet-500/50 rounded text-xs text-white px-1.5 py-0.5 outline-none" />
                  </div>
                ) : (
                  <div onClick={() => selectFile(file)}
                    className={`group flex items-center gap-2 px-3 py-1.5 cursor-pointer transition ${activeFile?.name === file.name ? 'bg-violet-500/15 text-white border-l-2 border-violet-400' : 'text-white/50 hover:text-white/80 hover:bg-white/[0.04] border-l-2 border-transparent'}`}>
                    {getFileIcon(file.name, file.binary)}
                    <span className="text-[12px] truncate flex-1">{file.name}</span>
                    {activeFile?.name === file.name && unsaved && <span className="w-1.5 h-1.5 rounded-full bg-amber-400 flex-shrink-0" />}
                    <button onClick={e => { e.stopPropagation(); deleteFile(file.name) }}
                      className="opacity-0 group-hover:opacity-100 text-red-400/50 hover:text-red-400 transition flex-shrink-0">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                )}
              </div>
            ))}

            {/* Drop zone hint */}
            {files.length < 30 && (
              <div onClick={() => fileInputRef.current?.click()}
                className={`mx-2 mt-2 rounded-lg border border-dashed p-3 text-center cursor-pointer transition ${isDragging ? 'border-violet-400 bg-violet-500/10' : 'border-white/10 hover:border-violet-500/30 hover:bg-white/[0.02]'}`}>
                <Upload className="w-4 h-4 text-white/20 mx-auto mb-1" />
                <p className="text-[10px] text-white/25">{isDragging ? 'Drop here' : 'Drop or click to upload'}</p>
              </div>
            )}
          </div>

          {/* File count */}
          <div className="px-3 py-2 border-t border-white/[0.04] flex items-center justify-between">
            <span className="text-[10px] text-white/25">{files.length} file{files.length !== 1 ? 's' : ''}</span>
            {files.length > 0 && (
              <span className="text-[10px] text-white/20">
                {formatBytes(files.reduce((a, f) => a + (f.size || new TextEncoder().encode(f.content).length), 0))}
              </span>
            )}
          </div>
        </div>

        {/* ── Editor + Console ── */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Tabs */}
          <div className="flex items-center border-b border-white/[0.06] bg-[#0d0d14] flex-shrink-0">
            {[
              { id: 'editor', label: 'Editor', icon: Code2 },
              { id: 'console', label: 'Console', icon: Terminal },
              { id: 'preview', label: 'Preview', icon: Eye },
            ].map(tab => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-5 py-2.5 text-xs transition border-b-2 ${activeTab === tab.id ? 'border-violet-500 text-white bg-violet-500/5' : 'border-transparent text-white/35 hover:text-white hover:bg-white/[0.03]'}`}>
                <tab.icon className="w-3.5 h-3.5" />
                {tab.label}
                {tab.id === 'console' && selected.status === 'running' && (
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                )}
              </button>
            ))}
            {activeFile && activeTab === 'editor' && (
              <span className="ml-auto pr-4 text-xs text-white/20 flex items-center gap-2">
                {getFileIcon(activeFile.name, activeFile.binary)}
                {activeFile.name}
                <span className="text-white/15">·</span>
                <span>{editContent.split('\n').length} lines</span>
              </span>
            )}
          </div>

          {/* Content */}
          <div className={`flex-1 overflow-hidden ${isDragging ? 'ring-2 ring-inset ring-violet-500/40' : ''}`}>
            {/* ── Editor ── */}
            {activeTab === 'editor' && (
              activeFile?.binary ? (
                <div className="h-full flex items-center justify-center flex-col gap-3 text-white/20">
                  <ImageIcon className="w-12 h-12" />
                  <p className="text-sm">Binary file — preview not available</p>
                  {activeFile.content.startsWith('data:image') && (
                    <img src={activeFile.content} alt={activeFile.name} className="max-w-xs max-h-48 rounded-lg mt-2 border border-white/10" />
                  )}
                </div>
              ) : (
                <div className="h-full flex flex-col">
                  {/* Editor toolbar */}
                  {activeFile && (
                    <div className="flex items-center justify-between px-4 py-1.5 border-b border-white/[0.04] bg-[#0d0d14] flex-shrink-0">
                      <div className="flex items-center gap-2 text-[11px] text-white/25">
                        <span>{activeFile.language?.toUpperCase() || 'TEXT'}</span>
                        <span>·</span>
                        <span>{formatBytes(new TextEncoder().encode(editContent).length)}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <button onClick={() => { navigator.clipboard.writeText(editContent); toast.success('Copied!') }}
                          className="text-white/25 hover:text-white transition text-[11px] flex items-center gap-1">
                          <Copy className="w-3.5 h-3.5" /> Copy
                        </button>
                        <span className="text-white/10">·</span>
                        <span className="text-[11px] text-white/20">Ctrl+S to save</span>
                      </div>
                    </div>
                  )}
                  <div className="flex flex-1 overflow-hidden">
                    {/* Line numbers */}
                    <div className="bg-[#080810] px-3 pt-4 pb-4 text-right select-none overflow-hidden flex-shrink-0 min-w-[3rem]">
                      {editContent.split('\n').map((_, i) => (
                        <div key={i} className="text-[12px] text-white/15 font-mono leading-[1.6] h-[20.8px]">{i + 1}</div>
                      ))}
                    </div>
                    {/* Code area */}
                    <textarea
                      value={editContent}
                      onChange={e => { setEditContent(e.target.value); setUnsaved(true) }}
                      spellCheck={false}
                      placeholder="// Write your code here..."
                      onKeyDown={e => {
                        if (e.key === 'Tab') {
                          e.preventDefault()
                          const s = e.currentTarget.selectionStart, end = e.currentTarget.selectionEnd
                          const v = editContent.substring(0, s) + '  ' + editContent.substring(end)
                          setEditContent(v); setUnsaved(true)
                          requestAnimationFrame(() => { e.currentTarget.selectionStart = e.currentTarget.selectionEnd = s + 2 })
                        }
                        if ((e.ctrlKey || e.metaKey) && e.key === 's') { e.preventDefault(); saveFiles() }
                      }}
                      className="flex-1 bg-[#0a0a10] text-[13px] font-mono text-[#d4d4d4] placeholder:text-white/10 pt-4 pb-4 pr-4 pl-2 resize-none outline-none leading-[1.6] overflow-auto"
                    />
                  </div>
                </div>
              )
            )}

            {/* ── Console ── */}
            {activeTab === 'console' && (
              <div className="h-full flex flex-col bg-[#080810]">
                <div className="flex items-center justify-between px-4 py-2 border-b border-white/[0.04] bg-[#0d0d14] flex-shrink-0">
                  <div className="flex items-center gap-2">
                    <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-xs text-white/40">Console Output</span>
                    {selected.status === 'running' && (
                      <span className="flex items-center gap-1 text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> Live
                      </span>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => refreshDeployment(selected.id)} className="text-white/30 hover:text-white transition">
                      <RefreshCw className="w-3.5 h-3.5" />
                    </button>
                    <button onClick={() => setConsoleLogs('')} className="text-white/30 hover:text-white transition">
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
                <pre ref={logsRef} className="flex-1 overflow-y-auto p-4 text-[12px] font-mono text-emerald-300 whitespace-pre-wrap leading-relaxed">
                  {consoleLogs || '// No output yet. Start your app to see logs here.\n'}
                </pre>
              </div>
            )}

            {/* ── Preview ── */}
            {activeTab === 'preview' && (
              <div className="h-full flex flex-col">
                {selected.status === 'running' ? (() => {
                  // Build preview HTML from uploaded files
                  const allFiles: DeployFile[] = selected.files || []
                  const htmlFile = allFiles.find(f => f.name === 'index.html' || f.name.endsWith('.html'))
                  const cssFiles = allFiles.filter(f => f.name.endsWith('.css') && !f.binary)
                  const jsFiles = allFiles.filter(f => (f.name.endsWith('.js') || f.name.endsWith('.mjs')) && !f.binary)

                  let previewHtml = htmlFile?.content || ''
                  // Inline CSS files not already referenced
                  for (const css of cssFiles) {
                    if (!previewHtml.includes(css.name)) {
                      previewHtml = previewHtml.replace('</head>', `<style>${css.content}</style></head>`)
                    }
                  }
                  // Inline JS files not already referenced
                  for (const js of jsFiles) {
                    if (!previewHtml.includes(js.name) && js.name !== 'index.js') {
                      previewHtml = previewHtml.replace('</body>', `<script>${js.content}</script></body>`)
                    }
                  }
                  const hasHtmlPreview = !!previewHtml
                  const displayUrl = selected.url || `app-${selected.id.slice(0, 8)}.gfxstore.app`

                  return (
                    <>
                      <div className="flex items-center gap-2 px-4 py-2 bg-[#0d0d14] border-b border-white/[0.04] flex-shrink-0">
                        <div className="flex gap-1.5">
                          <span className="w-2.5 h-2.5 rounded-full bg-red-500/70" />
                          <span className="w-2.5 h-2.5 rounded-full bg-amber-500/70" />
                          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/70" />
                        </div>
                        <div className="flex-1 bg-black/30 border border-white/10 rounded px-3 py-1 flex items-center gap-2">
                          <Globe className="w-3 h-3 text-white/30" />
                          <span className="text-xs text-white/50 truncate flex-1">{displayUrl}</span>
                        </div>
                        {selected.url && (
                          <a href={selected.url} target="_blank" rel="noopener noreferrer" className="text-white/30 hover:text-white transition">
                            <ExternalLink className="w-3.5 h-3.5" />
                          </a>
                        )}
                      </div>
                      {hasHtmlPreview ? (
                        <iframe srcDoc={previewHtml} className="flex-1 w-full border-0 bg-white" title="App Preview" sandbox="allow-scripts allow-same-origin allow-forms allow-popups" />
                      ) : (
                        <div className="flex-1 flex items-center justify-center flex-col gap-3 text-white/20">
                          <Globe className="w-10 h-10" />
                          <p className="text-sm text-center max-w-xs">App is running. Add an <code className="text-violet-400">index.html</code> file to see a live preview here.</p>
                        </div>
                      )}
                    </>
                  )
                })() : (
                  <div className="flex-1 flex items-center justify-center flex-col gap-3 text-white/20">
                    <Eye className="w-10 h-10" />
                    <p className="text-sm">Start your app to see preview</p>
                    <Button size="sm" onClick={startApp} disabled={!!actionLoading} className="bg-emerald-600 hover:bg-emerald-700 gap-2 mt-2">
                      <PlayCircle className="w-3.5 h-3.5" /> Start App
                    </Button>
                  </div>
                )}
              </div>
            )}

            {/* Drag overlay */}
            {isDragging && (
              <div className="absolute inset-0 bg-violet-950/80 backdrop-blur-sm flex items-center justify-center z-50 border-2 border-dashed border-violet-400 rounded-lg m-2">
                <div className="text-center">
                  <Upload className="w-12 h-12 text-violet-400 mx-auto mb-3" />
                  <p className="text-white font-semibold text-lg">Drop files to upload</p>
                  <p className="text-white/50 text-sm mt-1">Supports HTML, CSS, JS, images and more</p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ── Hidden file inputs ── */}
      <input ref={fileInputRef} type="file" multiple className="hidden" accept="*/*"
        onChange={e => { if (e.target.files) { uploadFiles(e.target.files); e.target.value = '' } }} />
      <input ref={folderInputRef} type="file" multiple className="hidden"
        {...{ webkitdirectory: '', directory: '' } as any}
        onChange={e => { if (e.target.files) { uploadFiles(e.target.files); e.target.value = '' } }} />

      {/* ── Context Menu ── */}
      {ctxMenu && (
        <div style={{ top: ctxMenu.y, left: ctxMenu.x }}
          className="fixed z-[100] bg-[#1a1a2e] border border-white/10 rounded-lg shadow-2xl py-1 min-w-[160px] text-sm">
          {[
            { label: 'Open', icon: FileText, action: () => { selectFile(ctxMenu.file); setCtxMenu(null) } },
            { label: 'Rename', icon: Pencil, action: () => startRename(ctxMenu.file) },
            { label: 'Download', icon: Download, action: () => downloadFile(ctxMenu.file) },
            { label: 'Copy Path', icon: Copy, action: () => { navigator.clipboard.writeText(ctxMenu.file.name); toast.success('Copied'); setCtxMenu(null) } },
          ].map(item => (
            <button key={item.label} onClick={item.action}
              className="flex items-center gap-2.5 px-3 py-2 text-white/70 hover:text-white hover:bg-white/5 w-full text-left transition">
              <item.icon className="w-3.5 h-3.5" /> {item.label}
            </button>
          ))}
          <div className="border-t border-white/5 my-1" />
          <button onClick={() => deleteFile(ctxMenu.file.name)}
            className="flex items-center gap-2.5 px-3 py-2 text-red-400/80 hover:text-red-400 hover:bg-red-500/5 w-full text-left transition">
            <Trash2 className="w-3.5 h-3.5" /> Delete
          </button>
        </div>
      )}

      {/* Add File Dialog */}
      <Dialog open={addFileOpen} onOpenChange={setAddFileOpen}>
        <DialogContent className="bg-zinc-950 border border-white/10 text-white max-w-sm">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2"><FileText className="w-4 h-4 text-violet-400" /> New File</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 mt-2">
            <Input value={newFileName} onChange={e => setNewFileName(e.target.value)}
              placeholder="filename.html"
              className="bg-white/5 border-white/10 text-white placeholder:text-white/30"
              autoFocus onKeyDown={e => e.key === 'Enter' && addNewFile()} />
            <div className="flex gap-2">
              <Button variant="ghost" onClick={() => setAddFileOpen(false)} className="flex-1 text-white/60">Cancel</Button>
              <Button onClick={addNewFile} className="flex-1 bg-violet-600 hover:bg-violet-700">Add</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
