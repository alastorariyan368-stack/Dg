'use client'

import { useState, useEffect } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { toast } from 'sonner'
import { useSession } from 'next-auth/react'
import Link from 'next/link'
import { useParams } from 'next/navigation'
import { ArrowLeft, Loader2, Calendar, Shield, Users } from 'lucide-react'

interface ProfileUser {
  id: string
  username: string
  avatar: string | null
  role: string
  bio: string | null
  createdAt: string
}

interface Post {
  id: string
  content: string
  images: string[]
  tags: string[]
  createdAt: string
  _count: { likes: number; comments: number; shares: number }
}

export default function CommunityProfilePage() {
  const params = useParams()
  const userId = typeof params.userId === 'string' ? params.userId : ''
  const session = useSession()

  const [profile, setProfile] = useState<ProfileUser | null>(null)
  const [posts, setPosts] = useState<Post[]>([])
  const [loading, setLoading] = useState(true)
  const [loadingPosts, setLoadingPosts] = useState(true)

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const res = await fetch(`/api/users/${userId}`)
        if (!res.ok) throw new Error('User not found')
        const data = await res.json()
        setProfile(data.user || data)
      } catch { toast.error('Failed to load profile') }
      finally { setLoading(false) }
    }
    const fetchPosts = async () => {
      try {
        const res = await fetch(`/api/community/posts?userId=${userId}&limit=50`)
        const data = await res.json()
        if (res.ok) setPosts(data.posts)
      } catch { /* ignore */ }
      finally { setLoadingPosts(false) }
    }
    if (userId) { fetchProfile(); fetchPosts() }
  }, [userId])

  const isOwn = session.data?.user?.id === userId
  const isAdmin = profile?.role === 'ADMIN' || profile?.role === 'SUPER_ADMIN'

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a12] text-white flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center"><Loader2 className="w-8 h-8 text-white/30 animate-spin" /></div>
        <Footer />
      </div>
    )
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-[#0a0a12] text-white flex flex-col">
        <Navbar />
        <div className="flex-1 flex flex-col items-center justify-center gap-4">
          <Users className="w-16 h-16 text-white/20" />
          <h2 className="text-xl font-bold text-white/50">User not found</h2>
          <Button asChild variant="outline" className="border-white/10 text-white"><Link href="/community">Back to Community</Link></Button>
        </div>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#0a0a12] text-white flex flex-col">
      <Navbar />

      <div className="flex-1 container mx-auto px-4 py-8 max-w-3xl">
        {/* Back */}
        <Link href="/community" className="inline-flex items-center gap-1.5 text-sm text-white/40 hover:text-white transition mb-6">
          <ArrowLeft className="w-4 h-4" /> Back to Community
        </Link>

        {/* Profile header */}
        <div className="rounded-2xl border border-white/[0.07] bg-gradient-to-b from-white/[0.03] to-transparent p-6 mb-6">
          <div className="flex items-center gap-5">
            <Avatar className="w-20 h-20 border-2 border-violet-500/30">
              <AvatarImage src={profile.avatar || undefined} />
              <AvatarFallback className="bg-gradient-to-br from-violet-600 to-cyan-600 text-white text-2xl font-bold">
                {profile.username?.[0]?.toUpperCase() || 'U'}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 mb-1">
                <h1 className="text-xl font-bold truncate">{profile.username}</h1>
                {isAdmin && <Badge className="bg-amber-500/15 text-amber-300 border border-amber-500/30">Admin</Badge>}
              </div>
              {profile.bio && <p className="text-sm text-white/60 mb-2">{profile.bio}</p>}
              <div className="flex items-center gap-3 text-xs text-white/30">
                <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> Joined {new Date(profile.createdAt).toLocaleDateString()}</span>
                <span>{posts.length} post{posts.length !== 1 ? 's' : ''}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Posts */}
        <h2 className="text-base font-semibold text-white/80 mb-4">Posts</h2>
        {loadingPosts ? (
          <div className="flex justify-center py-10"><Loader2 className="w-6 h-6 text-white/30 animate-spin" /></div>
        ) : posts.length === 0 ? (
          <div className="text-center py-12 text-white/30">
            <p className="text-sm">{isOwn ? "You haven't posted anything yet" : 'No posts yet'}</p>
          </div>
        ) : (
          <div className="space-y-4">
            {posts.map(post => (
              <Link key={post.id} href="/community" className="block rounded-2xl border border-white/[0.07] bg-white/[0.02] p-4 hover:border-white/15 transition">
                <p className="text-sm text-white/85 line-clamp-3 mb-2">{post.content}</p>
                {post.images && post.images.length > 0 && (
                  <div className="flex gap-2 mb-2">
                    {(post.images as string[]).slice(0, 3).map((img, i) => (
                      <div key={i} className="w-16 h-16 rounded-xl overflow-hidden bg-black/30">
                        <img src={img} alt="" className="w-full h-full object-cover" onError={e => { (e.target as HTMLImageElement).style.display = 'none' }} />
                      </div>
                    ))}
                  </div>
                )}
                <div className="flex items-center gap-3 text-[11px] text-white/30">
                  <span>{post._count.likes} like{post._count.likes !== 1 ? 's' : ''}</span>
                  <span>{post._count.comments} comment{post._count.comments !== 1 ? 's' : ''}</span>
                  <span className="ml-auto">{new Date(post.createdAt).toLocaleDateString()}</span>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>

      <Footer />
    </div>
  )
}
