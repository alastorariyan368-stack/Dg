'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Textarea } from '@/components/ui/textarea'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { toast } from 'sonner'
import { useSession } from 'next-auth/react'
import Link from 'next/link'
import {
  Heart, MessageCircle, Share2, ImagePlus, Send, MoreHorizontal,
  Trash2, Loader2, Sparkles, Users, Clock, X,
} from 'lucide-react'

interface PostUser {
  id: string
  username: string
  avatar: string | null
  role: string
}

interface Post {
  id: string
  userId: string
  content: string
  images: string[]
  tags: string[]
  isPinned: boolean
  createdAt: string
  updatedAt: string
  user: PostUser
  _count: { likes: number; comments: number; shares: number }
  isLiked: boolean
}

interface Comment {
  id: string
  content: string
  createdAt: string
  user: PostUser
}

function timeAgo(dateStr: string) {
  const now = Date.now()
  const date = new Date(dateStr).getTime()
  const diff = Math.floor((now - date) / 1000)
  if (diff < 60) return 'just now'
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`
  if (diff < 604800) return `${Math.floor(diff / 86400)}d ago`
  return new Date(dateStr).toLocaleDateString()
}

function PostCard({ post, onDelete, onLikeChange }: { post: Post; onDelete: (id: string) => void; onLikeChange: (id: string, liked: boolean) => void }) {
  const [liked, setLiked] = useState(post.isLiked)
  const [likeCount, setLikeCount] = useState(post._count.likes)
  const [showComments, setShowComments] = useState(false)
  const [comments, setComments] = useState<Comment[]>([])
  const [commentText, setCommentText] = useState('')
  const [loadingComments, setLoadingComments] = useState(false)
  const [sendingComment, setSendingComment] = useState(false)
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false)
  const [imageError, setImageError] = useState<Set<number>>(new Set())
  const session = useSession()
  const isOwner = session?.data?.user?.id === post.userId
  const isAdmin = session?.data?.user?.role === 'ADMIN' || session?.data?.user?.role === 'SUPER_ADMIN'

  const handleLike = async () => {
    const prev = liked
    setLiked(!liked)
    setLikeCount(c => liked ? c - 1 : c + 1)

    try {
      const res = await fetch(`/api/community/posts/${post.id}/like`, { method: 'POST' })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      setLiked(data.liked)
      setLikeCount(c => data.liked ? c + 1 : c - 1)
      onLikeChange(post.id, data.liked)
    } catch {
      setLiked(prev)
      setLikeCount(c => prev ? c + 1 : c - 1)
      toast.error('Failed to like')
    }
  }

  const fetchComments = async () => {
    if (comments.length > 0) { setShowComments(s => !s); return }
    setLoadingComments(true)
    try {
      const res = await fetch(`/api/community/posts/${post.id}/comments`)
      const data = await res.json()
      if (res.ok) setComments(data.comments)
    } catch { toast.error('Failed to load comments') }
    finally { setLoadingComments(false); setShowComments(true) }
  }

  const addComment = async () => {
    if (!commentText.trim()) return
    setSendingComment(true)
    try {
      const res = await fetch(`/api/community/posts/${post.id}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: commentText.trim() }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      setComments(prev => [...prev, data.comment])
      setCommentText('')
    } catch (e: any) { toast.error(e.message) }
    finally { setSendingComment(false) }
  }

  const handleShare = async () => {
    try {
      await navigator.share({
        title: `Post by ${post.user.username}`,
        text: post.content,
        url: window.location.origin + '/community?post=' + post.id,
      })
    } catch {
      navigator.clipboard.writeText(window.location.origin + '/community?post=' + post.id)
      toast.success('Link copied!')
    }
  }

  const images = post.images || []

  return (
    <div className="rounded-2xl border border-white/[0.07] bg-white/[0.02] overflow-hidden transition hover:border-white/15">
      {/* Header */}
      <div className="flex items-center justify-between px-4 pt-4 pb-2">
        <Link href={`/community/profile/${post.userId}`} className="flex items-center gap-3 group">
          <Avatar className="w-10 h-10 border border-white/10">
            <AvatarImage src={post.user.avatar || undefined} />
            <AvatarFallback className="bg-gradient-to-br from-violet-600 to-cyan-600 text-white text-sm font-bold">
              {post.user.username?.[0]?.toUpperCase() || 'U'}
            </AvatarFallback>
          </Avatar>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-semibold text-sm text-white group-hover:text-violet-300 transition">{post.user.username}</span>
              {post.user.role === 'ADMIN' || post.user.role === 'SUPER_ADMIN' ? (
                <Badge className="bg-amber-500/15 text-amber-300 border border-amber-500/30 text-[10px] h-4 px-1.5">Admin</Badge>
              ) : null}
            </div>
            <span className="text-[11px] text-white/40 flex items-center gap-1">
              <Clock className="w-3 h-3" /> {timeAgo(post.createdAt)}
            </span>
          </div>
        </Link>

        {(isOwner || isAdmin) && (
          <div className="relative">
            <button onClick={() => setShowDeleteConfirm(!showDeleteConfirm)} className="p-1.5 rounded-lg text-white/30 hover:text-red-400 hover:bg-red-500/10 transition">
              <MoreHorizontal className="w-4 h-4" />
            </button>
            {showDeleteConfirm && (
              <div className="absolute right-0 top-8 z-20 bg-[#12121e] border border-white/[0.08] rounded-xl p-2 shadow-xl min-w-[140px]">
                <button
                  onClick={() => { onDelete(post.id); setShowDeleteConfirm(false) }}
                  className="flex items-center gap-2 w-full px-3 py-2 text-sm text-red-400 hover:bg-red-500/10 rounded-lg transition"
                >
                  <Trash2 className="w-4 h-4" /> Delete Post
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Content */}
      <div className="px-4 py-2">
        <div className="text-sm text-white/90 leading-relaxed whitespace-pre-wrap break-words">{post.content}</div>
        {post.tags && post.tags.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mt-2">
            {post.tags.map((tag, i) => (
              <span key={i} className="text-[11px] text-violet-400/70 bg-violet-500/10 rounded-full px-2 py-0.5">#{tag}</span>
            ))}
          </div>
        )}
      </div>

      {/* Images */}
      {images.length > 0 && (
        <div className={`px-4 pb-2 ${images.length === 1 ? '' : 'grid grid-cols-2 gap-2'}`}>
          {images.map((img, i) => (
            !imageError.has(i) ? (
              <div key={i} className="rounded-xl overflow-hidden bg-black/30">
                <img
                  src={img}
                  alt=""
                  className="w-full object-cover max-h-96"
                  onError={() => setImageError(prev => new Set(prev).add(i))}
                />
              </div>
            ) : null
          ))}
        </div>
      )}

      {/* Stats */}
      <div className="flex items-center justify-between px-4 py-2 text-xs text-white/30 border-t border-white/[0.04]">
        <span>{likeCount > 0 && <>{likeCount} like{likeCount !== 1 ? 's' : ''}</>}</span>
        <span>
          {post._count.comments > 0 && <>{post._count.comments} comment{post._count.comments !== 1 ? 's' : ''} </>
          }{post._count.shares > 0 && <>· {post._count.shares} share{post._count.shares !== 1 ? 's' : ''}</>}
        </span>
      </div>

      {/* Actions */}
      <div className="flex items-center border-t border-white/[0.04] px-1 py-0.5">
        <button onClick={handleLike} className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-medium transition ${liked ? 'text-rose-400' : 'text-white/40 hover:text-white/70 hover:bg-white/[0.04]'}`}>
          <Heart className={`w-4 h-4 ${liked ? 'fill-rose-400' : ''}`} /> Like
        </button>
        <button onClick={fetchComments} className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-medium text-white/40 hover:text-white/70 hover:bg-white/[0.04] transition">
          <MessageCircle className="w-4 h-4" /> Comment
        </button>
        <button onClick={handleShare} className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-medium text-white/40 hover:text-white/70 hover:bg-white/[0.04] transition">
          <Share2 className="w-4 h-4" /> Share
        </button>
      </div>

      {/* Comments */}
      {showComments && (
        <div className="border-t border-white/[0.04] px-4 py-3 space-y-3 bg-white/[0.01]">
          {loadingComments ? (
            <div className="flex justify-center py-4"><Loader2 className="w-5 h-5 text-white/30 animate-spin" /></div>
          ) : (
            comments.map(cm => (
              <div key={cm.id} className="flex gap-2.5">
                <Avatar className="w-7 h-7 flex-shrink-0 border border-white/5">
                  <AvatarImage src={cm.user.avatar || undefined} />
                  <AvatarFallback className="bg-gradient-to-br from-violet-600/80 to-cyan-600/80 text-white text-[10px] font-bold">
                    {cm.user.username?.[0]?.toUpperCase() || 'U'}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="bg-white/[0.04] rounded-xl px-3 py-2">
                    <div className="flex items-center gap-2 mb-0.5">
                      <Link href={`/community/profile/${cm.user.id}`} className="text-xs font-semibold text-white/80 hover:text-violet-300 transition">{cm.user.username}</Link>
                      <span className="text-[10px] text-white/20">{timeAgo(cm.createdAt)}</span>
                    </div>
                    <p className="text-xs text-white/70 leading-relaxed">{cm.content}</p>
                  </div>
                </div>
              </div>
            ))
          )}

          {session.data?.user ? (
            <div className="flex gap-2.5 pt-1">
              <Avatar className="w-7 h-7 flex-shrink-0 border border-white/5">
                <AvatarFallback className="bg-gradient-to-br from-violet-600/80 to-cyan-600/80 text-white text-[10px] font-bold">
                  {(session.data.user.name || (session.data.user as any).username || 'U')?.[0]?.toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 flex gap-2">
                <Input
                  value={commentText}
                  onChange={e => setCommentText(e.target.value)}
                  placeholder="Write a comment…"
                  className="flex-1 h-9 text-xs bg-white/[0.04] border-white/[0.06] text-white placeholder:text-white/20 rounded-xl"
                  onKeyDown={e => e.key === 'Enter' && !sendingComment && addComment()}
                />
                <Button onClick={addComment} disabled={!commentText.trim() || sendingComment} size="icon" className="h-9 w-9 bg-violet-600 hover:bg-violet-500 rounded-xl">
                  {sendingComment ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                </Button>
              </div>
            </div>
          ) : (
            <p className="text-xs text-white/30 text-center py-2">
              <Link href="/auth/signin" className="text-violet-400 hover:underline">Sign in</Link> to comment
            </p>
          )}
        </div>
      )}
    </div>
  )
}

export default function CommunityPage() {
  const session = useSession()
  const [posts, setPosts] = useState<Post[]>([])
  const [page, setPage] = useState(1)
  const [hasMore, setHasMore] = useState(true)
  const [loading, setLoading] = useState(true)
  const [loadingMore, setLoadingMore] = useState(false)
  const [newPost, setNewPost] = useState('')
  const [newPostImages, setNewPostImages] = useState<string[]>([])
  const [posting, setPosting] = useState(false)
  const [createOpen, setCreateOpen] = useState(false)
  const [uploading, setUploading] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)
  const observerRef = useRef<IntersectionObserver | null>(null)
  const bottomRef = useRef<HTMLDivElement>(null)

  const fetchPosts = useCallback(async (pageNum: number, append = false) => {
    if (pageNum === 1) setLoading(true)
    else setLoadingMore(true)
    try {
      const res = await fetch(`/api/community/posts?page=${pageNum}&limit=15`)
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      setPosts(prev => append ? [...prev, ...data.posts] : data.posts)
      setHasMore(pageNum < data.pagination.totalPages)
    } catch (e: any) { toast.error(e.message) }
    finally { setLoading(false); setLoadingMore(false) }
  }, [])

  useEffect(() => { fetchPosts(1) }, [fetchPosts])

  useEffect(() => {
    if (loading || !hasMore) return
    observerRef.current = new IntersectionObserver(entries => {
      if (entries[0].isIntersecting && !loadingMore) {
        const next = page + 1
        setPage(next)
        fetchPosts(next, true)
      }
    }, { rootMargin: '300px' })
    if (bottomRef.current) observerRef.current.observe(bottomRef.current)
    return () => observerRef.current?.disconnect()
  }, [loading, hasMore, loadingMore, page, fetchPosts])

  const handleCreatePost = async () => {
    if (!newPost.trim()) return
    setPosting(true)
    try {
      const res = await fetch('/api/community/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: newPost.trim(),
          images: newPostImages,
          tags: [],
        }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      setPosts(prev => [data, ...prev])
      setNewPost('')
      setNewPostImages([])
      setCreateOpen(false)
      toast.success('Posted!')
    } catch (e: any) { toast.error(e.message) }
    finally { setPosting(false) }
  }

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (file.size > 10 * 1024 * 1024) { toast.error('Max 10MB per image'); return }

    setUploading(true)
    try {
      const formData = new FormData()
      formData.append('file', file)
      const res = await fetch('/api/upload', { method: 'POST', body: formData })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      setNewPostImages(prev => [...prev, data.url || data.path])
    } catch (e: any) { toast.error(e.message) }
    finally { setUploading(false) }
  }

  const handleDeletePost = async (id: string) => {
    try {
      const res = await fetch(`/api/community/posts/${id}`, { method: 'DELETE' })
      if (!res.ok) { const d = await res.json(); throw new Error(d.error) }
      setPosts(prev => prev.filter(p => p.id !== id))
      toast.success('Post deleted')
    } catch (e: any) { toast.error(e.message) }
  }

  const handleLikeChange = (id: string, liked: boolean) => {
    setPosts(prev => prev.map(p => p.id === id ? { ...p, isLiked: liked, _count: { ...p._count, likes: liked ? p._count.likes + 1 : p._count.likes - 1 } } : p))
  }

  return (
    <div className="min-h-screen bg-[#0a0a12] text-white flex flex-col">
      <Navbar />

      <div className="flex-1 container mx-auto px-4 py-8 max-w-3xl">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <div className="inline-flex items-center gap-2 bg-violet-500/10 border border-violet-500/20 rounded-full px-4 py-1.5 mb-3">
              <Users className="w-4 h-4 text-violet-400" />
              <span className="text-violet-300 text-sm font-medium">Community</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-white">Community Feed</h1>
            <p className="text-white/40 text-sm mt-1">Share your thoughts, photos, and connect with others</p>
          </div>

          {session.data?.user && (
            <Dialog open={createOpen} onOpenChange={setCreateOpen}>
              <DialogTrigger asChild>
                <Button className="bg-gradient-to-r from-violet-600 to-cyan-600 hover:from-violet-500 hover:to-cyan-500 border-0 rounded-xl text-white font-semibold gap-2">
                  <Sparkles className="w-4 h-4" /> Create Post
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-[#0f0f1a] border-white/[0.08] text-white sm:max-w-lg">
                <DialogHeader>
                  <DialogTitle className="text-white font-bold">Create Post</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <Avatar className="w-9 h-9 border border-white/10">
                      <AvatarImage src={session.data.user.image || undefined} />
                      <AvatarFallback className="bg-gradient-to-br from-violet-600 to-cyan-600 text-white text-xs font-bold">
                        {(session.data.user.name || (session.data.user as any).username || 'U')?.[0]?.toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <span className="text-sm font-semibold">{session.data.user.name || (session.data.user as any).username || 'User'}</span>
                  </div>

                  <Textarea
                    value={newPost}
                    onChange={e => setNewPost(e.target.value)}
                    placeholder="What's on your mind?"
                    className="min-h-[120px] bg-white/[0.03] border-white/[0.06] text-white placeholder:text-white/20 rounded-xl resize-none"
                  />

                  {newPostImages.length > 0 && (
                    <div className="flex flex-wrap gap-2">
                      {newPostImages.map((img, i) => (
                        <div key={i} className="relative w-20 h-20 rounded-xl overflow-hidden bg-black/40">
                          <img src={img} alt="" className="w-full h-full object-cover" />
                          <button onClick={() => setNewPostImages(prev => prev.filter((_, j) => j !== i))} className="absolute top-0.5 right-0.5 p-0.5 bg-black/60 rounded-full">
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  <div className="flex items-center justify-between">
                    <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleImageUpload} />
                    <Button onClick={() => fileInputRef.current?.click()} disabled={uploading} variant="outline" size="sm" className="border-white/10 text-white hover:bg-white/[0.05] gap-2">
                      {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <ImagePlus className="w-4 h-4" />}
                      {uploading ? 'Uploading…' : 'Add Photo'}
                    </Button>
                    <span className="text-[10px] text-white/20">{newPost.length}/5000</span>
                  </div>

                  <Button
                    onClick={handleCreatePost}
                    disabled={!newPost.trim() || posting}
                    className="w-full bg-gradient-to-r from-violet-600 to-cyan-600 hover:from-violet-500 hover:to-cyan-500 border-0 rounded-xl text-white font-semibold gap-2"
                  >
                    {posting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                    {posting ? 'Posting…' : 'Post'}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          )}
        </div>

        {/* Feed */}
        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="rounded-2xl border border-white/[0.07] bg-white/[0.02] p-5 space-y-3 animate-pulse">
                <div className="flex items-center gap-3"><div className="w-10 h-10 rounded-full bg-white/5" /><div className="space-y-2"><div className="w-28 h-3 rounded bg-white/5" /><div className="w-16 h-2 rounded bg-white/5" /></div></div>
                <div className="space-y-2"><div className="w-full h-3 rounded bg-white/5" /><div className="w-3/4 h-3 rounded bg-white/5" /></div>
              </div>
            ))}
          </div>
        ) : posts.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-20 h-20 rounded-3xl bg-violet-500/10 border border-violet-500/20 flex items-center justify-center mx-auto mb-4">
              <Users className="w-9 h-9 text-violet-400/60" />
            </div>
            <h3 className="text-lg font-semibold text-white/70 mb-1">No posts yet</h3>
            <p className="text-sm text-white/30 mb-4">Be the first to share something!</p>
            {session.data?.user && (
              <Button onClick={() => setCreateOpen(true)} className="bg-gradient-to-r from-violet-600 to-cyan-600 border-0 rounded-xl text-white">
                Create First Post
              </Button>
            )}
          </div>
        ) : (
          <div className="space-y-4">
            {posts.map(post => (
              <PostCard key={post.id} post={post} onDelete={handleDeletePost} onLikeChange={handleLikeChange} />
            ))}
            {loadingMore && (
              <div className="flex justify-center py-6">
                <Loader2 className="w-6 h-6 text-white/30 animate-spin" />
              </div>
            )}
            <div ref={bottomRef} className="h-4" />
            {!hasMore && posts.length > 10 && (
              <p className="text-center text-xs text-white/20 py-4">You've reached the end</p>
            )}
          </div>
        )}
      </div>

      <Footer />
    </div>
  )
}
