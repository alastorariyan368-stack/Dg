'use client'

import { useState, useEffect, useRef } from 'react'
import { Navbar } from '@/components/navbar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Bot, Send, User, Loader2, Settings, Key, Trash2, ChevronLeft, Sparkles, AlertCircle } from 'lucide-react'
import Link from 'next/link'
import { toast } from 'sonner'
import { Logo } from '@/components/logo'

interface Message { role: 'user' | 'assistant'; content: string; time: string }

const QUICK_PROMPTS = [
  'What content should be approved on the site?',
  'What policies should new users follow?',
  'What are best practices for video moderation?',
  'How do I identify spam content?',
  'What marketing strategy should the site have?',
  'How to improve user engagement on the platform?',
]

export default function AdminAiChatPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const [apiKey, setApiKey] = useState('')
  const [savedKey, setSavedKey] = useState('')
  const [showKeyInput, setShowKeyInput] = useState(false)
  const [savingKey, setSavingKey] = useState(false)
  const [model, setModel] = useState('gpt-4o-mini')
  const [provider, setProvider] = useState('openai')
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    if (status === 'unauthenticated') { router.push('/auth/signin'); return }
    if (status === 'authenticated') {
      const role = (session?.user as any)?.role
      if (!['ADMIN', 'SUPER_ADMIN'].includes(role)) { router.push('/'); return }
      loadSettings()
    }
  }, [status])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const loadSettings = async () => {
    try {
      const res = await fetch('/api/admin/settings')
      if (res.ok) {
        const data = await res.json()
        if (data.aiModel) setModel(data.aiModel)
        
        // Determine which API key to show based on model
        let keyField = 'openaiApiKey'
        if (data.aiModel?.startsWith('claude-')) keyField = 'anthropicApiKey'
        else if (data.aiModel?.startsWith('gemini-')) keyField = 'geminiApiKey'
        
        if (data[keyField]) { 
          setSavedKey('****' + data[keyField].slice(-4)); 
          setShowKeyInput(false) 
        } else { 
          setShowKeyInput(true) 
        }
      }
    } catch {}
  }

  const saveApiKey = async () => {
    if (!apiKey.trim()) { toast.error('Please enter an API key'); return }
    setSavingKey(true)
    try {
      let keyField = 'openaiApiKey'
      if (model.startsWith('claude-')) keyField = 'anthropicApiKey'
      else if (model.startsWith('gemini-')) keyField = 'geminiApiKey'
      
      const updateData = { [keyField]: apiKey.trim(), aiModel: model }
      
      const res = await fetch('/api/admin/settings', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updateData)
      })
      if (res.ok) {
        toast.success('API key saved successfully!')
        setSavedKey('****' + apiKey.slice(-4))
        setApiKey('')
        setShowKeyInput(false)
      } else {
        toast.error('Failed to save API key')
      }
    } catch { toast.error('Error saving API key') }
    setSavingKey(false)
  }

  const sendMessage = async (text?: string) => {
    const userMsg = (text || input).trim()
    if (!userMsg) return

    const newMsg: Message = { role: 'user', content: userMsg, time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) }
    setMessages(prev => [...prev, newMsg])
    setInput('')
    setLoading(true)

    try {
      const res = await fetch('/api/admin/ai-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: [...messages, newMsg].map(m => ({ role: m.role, content: m.content })) })
      })
      const data = await res.json()
      if (res.ok) {
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: data.reply,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }])
      } else {
        toast.error(data.error || 'Could not get AI response')
        if (data.error?.includes('API key') || data.error?.includes('not configured')) {
          setShowKeyInput(true)
        }
      }
    } catch { toast.error('Network error. Please try again.') }
    setLoading(false)
  }

  if (status === 'loading') return null

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white flex flex-col">
      <Navbar />
      <main className="flex-1 container mx-auto px-4 py-6 max-w-4xl flex flex-col" style={{ height: 'calc(100vh - 60px)' }}>
        <div className="flex items-center gap-3 mb-4 flex-shrink-0">
          <Link href="/admin" className="p-2 rounded-xl bg-white/5 hover:bg-white/10 transition-all">
            <ChevronLeft className="w-4 h-4 text-white/60" />
          </Link>
          <div className="flex items-center gap-2.5 flex-1">
            <Logo size="md" />
            <div>
              <h1 className="font-bold text-white text-lg">Admin AI Assistant</h1>
              <p className="text-white/40 text-xs">GfxStore Admin AI — {model}</p>
            </div>
          </div>
          <div className="flex gap-2">
            <Button variant="ghost" size="icon" onClick={() => setShowKeyInput(!showKeyInput)} className="h-8 w-8 text-white/40 hover:text-white hover:bg-white/5 rounded-lg" title="API Key Settings">
              <Key className="w-4 h-4" />
            </Button>
            {messages.length > 0 && (
              <Button variant="ghost" size="icon" onClick={() => setMessages([])} className="h-8 w-8 text-white/40 hover:text-red-400 hover:bg-red-500/10 rounded-lg" title="Clear chat">
                <Trash2 className="w-4 h-4" />
              </Button>
            )}
          </div>
        </div>

        {showKeyInput && (
          <div className="bg-blue-500/10 border border-blue-500/20 rounded-2xl p-4 mb-4 flex-shrink-0">
            <div className="flex items-start gap-2 mb-3">
              <AlertCircle className="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0" />
              <div>
                <p className="text-sm font-medium text-blue-300">Configure OpenAI API Key</p>
                <p className="text-xs text-blue-300/60 mt-0.5">
                  {savedKey ? `Current key: ${savedKey} — Enter a new key below to update` : 'Enter your OpenAI API key to enable AI chat for all users'}
                </p>
                <a href="https://platform.openai.com/api-keys" target="_blank" rel="noopener noreferrer" className="text-xs text-blue-400 hover:text-blue-300 underline mt-1 inline-block">
                  Get API key from OpenAI →
                </a>
              </div>
            </div>
            <div className="flex gap-2">
              <Input value={apiKey} onChange={e => setApiKey(e.target.value)} type="password" placeholder="sk-..." className="bg-white/5 border-blue-500/30 text-white placeholder:text-white/20 text-sm flex-1" />
              <select value={model} onChange={e => setModel(e.target.value)} className="bg-white/5 border border-blue-500/30 text-white text-xs rounded-lg px-2">
                <option value="gpt-4o-mini">GPT-4o Mini (Cheaper)</option>
                <option value="gpt-4o">GPT-4o (Powerful)</option>
                <option value="gpt-3.5-turbo">GPT-3.5 Turbo</option>
              </select>
              <Button onClick={saveApiKey} disabled={savingKey} className="bg-blue-600 hover:bg-blue-700 text-white text-sm whitespace-nowrap">
                {savingKey ? <Loader2 className="w-4 h-4 animate-spin" /> : <><Settings className="w-4 h-4 mr-1" /> Save</>}
              </Button>
            </div>
          </div>
        )}

        <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-1">
          {messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center py-12">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-purple-500/20 to-blue-600/20 border border-purple-500/20 flex items-center justify-center mb-4">
                <Bot className="w-8 h-8 text-purple-400" />
              </div>
              <h2 className="text-white/80 font-semibold mb-1">GfxStore Admin AI Assistant</h2>
              <p className="text-white/30 text-sm mb-6 max-w-xs">Content moderation, user management, marketing — ask anything about the platform</p>
              {!savedKey && (
                <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-3 text-sm text-yellow-400 mb-4 max-w-sm">
                  ⚠️ Please configure your OpenAI API key first (click the key icon above)
                </div>
              )}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-w-lg w-full">
                {QUICK_PROMPTS.map((p, i) => (
                  <button key={i} onClick={() => sendMessage(p)} disabled={!savedKey}
                    className="text-left px-3 py-2.5 bg-white/5 hover:bg-white/10 border border-white/10 hover:border-purple-500/30 rounded-xl text-sm text-white/60 hover:text-white transition-all disabled:opacity-40 disabled:cursor-not-allowed">
                    {p}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            messages.map((msg, i) => (
              <div key={i} className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                <div className={`w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 ${msg.role === 'user' ? 'bg-purple-600' : 'bg-gradient-to-br from-purple-500/30 to-blue-600/30 border border-purple-500/20'}`}>
                  {msg.role === 'user' ? <User className="w-4 h-4 text-white" /> : <Bot className="w-4 h-4 text-purple-400" />}
                </div>
                <div className={`max-w-[80%] ${msg.role === 'user' ? 'items-end' : 'items-start'} flex flex-col gap-1`}>
                  <div className={`rounded-2xl px-4 py-3 text-sm leading-relaxed whitespace-pre-wrap ${msg.role === 'user' ? 'bg-purple-600/80 text-white rounded-tr-sm' : 'bg-white/5 border border-white/10 text-white/80 rounded-tl-sm'}`}>
                    {msg.content}
                  </div>
                  <span className="text-white/20 text-xs px-1">{msg.time}</span>
                </div>
              </div>
            ))
          )}
          {loading && (
            <div className="flex gap-3">
              <div className="w-8 h-8 rounded-xl flex items-center justify-center bg-gradient-to-br from-purple-500/30 to-blue-600/30 border border-purple-500/20 flex-shrink-0">
                <Bot className="w-4 h-4 text-purple-400" />
              </div>
              <div className="bg-white/5 border border-white/10 rounded-2xl rounded-tl-sm px-4 py-3 flex items-center gap-2">
                <div className="flex gap-1">
                  {[0, 1, 2].map(i => <span key={i} className="w-1.5 h-1.5 bg-purple-400/60 rounded-full animate-bounce" style={{ animationDelay: `${i * 150}ms` }} />)}
                </div>
                <span className="text-white/30 text-xs">Generating response...</span>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="flex-shrink-0 flex gap-2">
          <Input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), sendMessage())}
            placeholder={savedKey ? 'Ask AI anything...' : 'Please configure API key first'}
            disabled={loading || !savedKey}
            className="flex-1 h-12 bg-white/5 border-white/10 text-white placeholder:text-white/20 rounded-xl text-base focus:border-purple-500/40" />
          <Button onClick={() => sendMessage()} disabled={loading || !input.trim() || !savedKey} className="h-12 w-12 bg-purple-600 hover:bg-purple-700 rounded-xl flex-shrink-0 p-0">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </Button>
        </div>
      </main>
    </div>
  )
}
