'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Loader2, Check, X, Server, Zap, Clock, RefreshCw, Ban, Play, Copy, User, Wallet, Hash, Calendar, AlertCircle, HardDrive, Cpu } from 'lucide-react'
import { Textarea } from '@/components/ui/textarea'
import { toast } from 'sonner'
import { Switch } from '@/components/ui/switch'
import { Label } from '@/components/ui/label'

interface Order {
  id: string
  userId: string
  user?: { username: string; email: string; walletBalance: number }
  plan: { name: string; price: number; specs?: any }
  amount: number
  paymentMethod: string
  transactionRef?: string
  status: string
  serverInfo?: any
  expiresAt?: string
  pteroServerId?: string
  pteroServerIdentifier?: string
  createdAt: string
}

const STATUS_STYLES: Record<string, string> = {
  PENDING: 'bg-yellow-500/15 text-yellow-300 border-yellow-500/30',
  APPROVED: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30',
  REJECTED: 'bg-red-500/15 text-red-300 border-red-500/30',
  SUSPENDED: 'bg-orange-500/15 text-orange-300 border-orange-500/30',
}

function CopyBtn({ text }: { text: string }) {
  const copy = () => {
    navigator.clipboard.writeText(text)
    toast.success('Copied to clipboard')
  }
  return (
    <button onClick={copy} className="p-1 hover:bg-white/10 rounded-md transition-colors text-white/40 hover:text-white">
      <Copy className="w-3.5 h-3.5" />
    </button>
  )
}

const formatMb = (value?: number | string) => {
  const numeric = Number(value || 0)
  if (!numeric) return '-'
  if (numeric >= 1024) return `${Number((numeric / 1024).toFixed(1))} GB`
  return `${numeric} MB`
}

export default function VPSOrdersAdminPage() {
  const { data: session, status: authStatus } = useSession()
  const router = useRouter()
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState<Order | null>(null)
  const [detailsOrder, setDetailsOrder] = useState<Order | null>(null)
  const [approving, setApproving] = useState(false)
  const [serverInfo, setServerInfo] = useState('')
  const [autoPtero, setAutoPtero] = useState(true)
  const [durationDays, setDurationDays] = useState('30')
  const [pteroConfigured, setPteroConfigured] = useState(false)
  const [gfxConfigured, setGfxConfigured] = useState(false)
  const [autoGfx, setAutoGfx] = useState(true)
  const [actionLoading, setActionLoading] = useState<string | null>(null)

  useEffect(() => {
    if (authStatus === 'loading') return
    if (authStatus === 'unauthenticated' || (session?.user?.role !== 'ADMIN' && session?.user?.role !== 'SUPER_ADMIN')) {
      router.push('/'); return
    }
    fetchOrders()
    checkPteroConfig()
    checkGfxConfig()
  }, [authStatus, session, router])

  const checkPteroConfig = async () => {
    try {
      const r = await fetch('/api/admin/settings')
      const d = await r.json()
      setPteroConfigured(!!(d.pteroUrl && d.pteroAdminApiKey))
    } catch {}
  }

  const checkGfxConfig = async () => {
    try {
      const r = await fetch('/api/admin/gfxpanel')
      const d = await r.json()
      setGfxConfigured(!!d.configured)
    } catch {}
  }

  const fetchOrders = async () => {
    try {
      const res = await fetch('/api/admin/vps-orders')
      if (res.ok) setOrders(await res.json())
    } catch { toast.error('Failed to load orders') } finally { setLoading(false) }
  }

  const openApprove = (order: Order) => {
    setSelected(order)
    setServerInfo(order.serverInfo ? JSON.stringify(order.serverInfo, null, 2) : '')
  }

  const handleApprove = async () => {
    if (!selected) return
    setApproving(true)
    try {
      let parsedInfo: any = {}
      if (serverInfo.trim()) {
        try { parsedInfo = JSON.parse(serverInfo) } catch { parsedInfo = { notes: serverInfo } }
      }
      const res = await fetch(`/api/admin/vps-orders/${selected.id}/approve`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ serverInfo: parsedInfo, autoPtero: autoPtero && pteroConfigured, autoGfx: autoGfx && gfxConfigured, durationDays: parseInt(durationDays) || 30 })
      })
      const d = await res.json()
      if (!res.ok) throw new Error(d.error || 'Failed to approve')
      if (d.gfxProvisioned) {
        toast.success('✅ VPS provisioned on GFX Panel!')
      } else if (d.pteroProvisioned) {
        toast.success('✅ Server provisioned on Pterodactyl!')
      } else if (d.order?.serverInfo?.provisioningWarnings?.length) {
        toast.warning('⚠️ Order approved but auto-provisioning had issues: ' + d.order.serverInfo.provisioningWarnings[0])
      } else {
        toast.success('✅ Order approved')
      }
      setSelected(null); setServerInfo('')
      fetchOrders()
    } catch (err: any) { toast.error(err.message) } finally { setApproving(false) }
  }

  const handleReject = async (id: string) => {
    if (!confirm('Reject this order?')) return
    setActionLoading(id + '_reject')
    try {
      const res = await fetch(`/api/admin/vps-orders/${id}/reject`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({}) })
      if (res.ok) { toast.success('Order rejected'); fetchOrders() } else toast.error('Failed')
    } catch { toast.error('Failed') } finally { setActionLoading(null) }
  }

  const handlePteroAction = async (order: Order, action: 'admin-suspend' | 'admin-unsuspend' | 'admin-delete-server') => {
    if (!order.pteroServerId) { toast.error('No Pterodactyl server linked to this order'); return }
    const label = action === 'admin-suspend' ? 'suspend' : action === 'admin-unsuspend' ? 'unsuspend' : 'delete'
    if (!confirm(`Are you sure you want to ${label} this server?`)) return
    setActionLoading(order.id + '_' + action)
    try {
      const res = await fetch('/api/panel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, serverId: order.pteroServerId })
      })
      const d = await res.json()
      if (d.ok) {
        toast.success(`Server ${label}d successfully`)
        if (action === 'admin-suspend') {
          await fetch(`/api/admin/vps-orders/${order.id}/status`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status: 'SUSPENDED' }) }).catch(() => {})
          fetchOrders()
        }
      } else toast.error(`Failed to ${label}: ` + (d.error || 'Unknown error'))
    } catch { toast.error(`Failed to ${label} server`) } finally { setActionLoading(null) }
  }

  return (
    <div className="p-4 max-w-7xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-bold text-white">VPS Orders</h2>
          <p className="text-xs text-white/40 mt-0.5">{orders.length} total orders</p>
        </div>
        <div className="flex items-center gap-2">
          {pteroConfigured ? (
            <Badge className="bg-emerald-500/15 text-emerald-300 border-emerald-500/30 text-xs">🖥️ Pterodactyl Connected</Badge>
          ) : (
            <Badge className="bg-orange-500/15 text-orange-300 border-orange-500/30 text-xs">⚠️ Pterodactyl Not Configured</Badge>
          )}
          {gfxConfigured ? (
            <Badge className="bg-cyan-500/15 text-cyan-300 border-cyan-500/30 text-xs">⚡ GFX Connected</Badge>
          ) : (
            <Badge className="bg-orange-500/15 text-orange-300 border-orange-500/30 text-xs">⚠️ GFX Not Configured</Badge>
          )}
          <Button size="sm" variant="outline" onClick={fetchOrders} className="border-white/10 text-white/60 rounded-lg h-8 gap-1.5 text-xs">
            <RefreshCw className="h-3 w-3" /> Refresh
          </Button>
        </div>
      </div>

      {!pteroConfigured && (
        <div className="mb-4 p-4 rounded-xl border border-orange-500/20 bg-orange-500/5 text-sm text-orange-300">
          ⚠️ Pterodactyl is not configured. Go to <strong>Admin → Settings → Pterodactyl Panel</strong> to connect your panel for automatic server provisioning.
        </div>
      )}

      {!gfxConfigured && (
        <div className="mb-4 p-4 rounded-xl border border-cyan-500/20 bg-cyan-500/5 text-sm text-cyan-300">
          ⚡ GFX Panel is not configured. Go to <strong>/admin/gfxpanel</strong> to connect your panel for automatic VPS provisioning.
        </div>
      )}

      {loading ? (
        <div className="flex items-center justify-center h-40"><Loader2 className="w-6 h-6 animate-spin text-white/40" /></div>
      ) : orders.length === 0 ? (
        <div className="text-center py-16 text-white/30"><Server className="w-10 h-10 mx-auto mb-3 opacity-30" /><p>No VPS orders yet</p></div>
      ) : (
        <div className="space-y-3">
          {orders.map(o => {
            const specs = o.plan.specs as any || {}
            const isExpired = o.expiresAt && new Date(o.expiresAt) < new Date()
            return (
              <div key={o.id} onClick={() => setDetailsOrder(o)} className="cursor-pointer rounded-xl border border-white/[0.07] bg-white/[0.03] p-4 transition hover:bg-white/[0.055]">
                <div className="flex flex-wrap items-start gap-3 justify-between">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap mb-1">
                      <span className="font-semibold text-white text-sm">{o.user?.username || o.userId}</span>
                      <span className="text-white/40 text-xs">{o.user?.email}</span>
                      <Badge className={`text-[10px] border ${STATUS_STYLES[o.status] || STATUS_STYLES.PENDING}`}>{o.status}</Badge>
                      {isExpired && <Badge className="text-[10px] border bg-red-500/15 text-red-300 border-red-500/30">EXPIRED</Badge>}
                    </div>
                    <div className="flex flex-wrap gap-3 text-xs text-white/50">
                      <span>📦 {o.plan.name}</span>
                      <span>💳 ৳{o.amount} via {o.paymentMethod}</span>
                      {o.transactionRef && <span>🔖 {o.transactionRef}</span>}
                      {specs.ram && <span>🔵 {specs.ram}MB RAM</span>}
                      {specs.cpu && <span>⚡ {specs.cpu}% CPU</span>}
                      {specs.disk && <span>💾 {specs.disk}MB Disk</span>}
                      {o.pteroServerIdentifier && <span className="text-cyan-400">🖥️ {o.pteroServerIdentifier}</span>}
                      {o.expiresAt && <span className={isExpired ? 'text-red-400' : 'text-white/50'}>📅 Expires: {new Date(o.expiresAt).toLocaleDateString()}</span>}
                      <span>🕐 {new Date(o.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-1.5 flex-wrap" onClick={(e) => e.stopPropagation()}>
                    {o.status === 'PENDING' && (
                      <>
                        <Button size="sm" onClick={() => openApprove(o)} className="bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg h-7 text-xs gap-1"><Check className="h-3 w-3" />Approve</Button>
                        <Button size="sm" variant="destructive" onClick={() => handleReject(o.id)} disabled={actionLoading === o.id + '_reject'} className="rounded-lg h-7 text-xs gap-1">
                          {actionLoading === o.id + '_reject' ? <Loader2 className="h-3 w-3 animate-spin" /> : <X className="h-3 w-3" />}Reject
                        </Button>
                      </>
                    )}
                    {o.status === 'APPROVED' && o.pteroServerId && (
                      <Button size="sm" variant="outline" onClick={() => handlePteroAction(o, 'admin-suspend')}
                        disabled={!!actionLoading} className="border-orange-500/30 text-orange-300 hover:bg-orange-500/10 rounded-lg h-7 text-xs gap-1">
                        {actionLoading === o.id + '_admin-suspend' ? <Loader2 className="h-3 w-3 animate-spin" /> : <Ban className="h-3 w-3" />}Suspend
                      </Button>
                    )}
                    {o.status === 'SUSPENDED' && o.pteroServerId && (
                      <Button size="sm" variant="outline" onClick={() => handlePteroAction(o, 'admin-unsuspend')}
                        disabled={!!actionLoading} className="border-emerald-500/30 text-emerald-300 hover:bg-emerald-500/10 rounded-lg h-7 text-xs gap-1">
                        {actionLoading === o.id + '_admin-unsuspend' ? <Loader2 className="h-3 w-3 animate-spin" /> : <Play className="h-3 w-3" />}Unsuspend
                      </Button>
                    )}
                    {o.pteroServerId && (o.status === 'APPROVED' || o.status === 'SUSPENDED') && (
                      <Button size="sm" variant="outline" onClick={() => handlePteroAction(o, 'admin-delete-server')}
                        disabled={!!actionLoading} className="border-red-500/30 text-red-400 hover:bg-red-500/10 rounded-lg h-7 text-xs gap-1">
                        {actionLoading === o.id + '_admin-delete-server' ? <Loader2 className="h-3 w-3 animate-spin" /> : <X className="h-3 w-3" />}Delete
                      </Button>
                    )}
                    {o.status !== 'PENDING' && !o.pteroServerId && (
                      <Button size="sm" variant="outline" onClick={() => openApprove(o)} className="border-white/10 text-white/50 rounded-lg h-7 text-xs">Edit Info</Button>
                    )}
                  </div>
                </div>
                {o.serverInfo && o.status === 'APPROVED' && (
                  <div className="mt-3 pt-3 border-t border-white/[0.06]">
                    <pre className="text-[11px] text-white/50 bg-black/20 rounded-lg p-2 overflow-x-auto max-h-24">
                      {typeof o.serverInfo === 'string' ? o.serverInfo : JSON.stringify(o.serverInfo, null, 2)}
                    </pre>
                  </div>
                )}
              </div>
            )
          })}
        </div>
      )}

      <Dialog open={!!detailsOrder} onOpenChange={(open) => !open && setDetailsOrder(null)}>
        <DialogContent className="sm:max-w-[620px] bg-[#0d0d1a] border-white/10 text-white overflow-hidden p-0">
          <DialogHeader className="sr-only">
            <DialogTitle>VPS Order Details</DialogTitle>
            <DialogDescription>Review VPS order payment transaction and provisioning details.</DialogDescription>
          </DialogHeader>
          {detailsOrder && (() => {
            const specs = detailsOrder.plan.specs || {}
            const serverType = specs.serverType === 'host' ? 'Host / Pterodactyl' : 'VPS / GFX Panel'
            const isExpired = detailsOrder.expiresAt && new Date(detailsOrder.expiresAt) < new Date()
            return (
              <div className="relative">
                <div className="h-2 bg-gradient-to-r from-cyan-500 via-purple-500 to-emerald-500" />
                <div className="p-6">
                  <div className="rounded-3xl border border-white/10 bg-[#0f0f1e] overflow-hidden shadow-2xl relative">
                    <div className="p-7 space-y-7">
                      <div className="flex justify-between items-start gap-4">
                        <div>
                          <h3 className="text-2xl font-black tracking-tighter text-white">VPS Order Receipt</h3>
                          <p className="text-[10px] text-white/30 uppercase tracking-[0.2em] font-bold">#{detailsOrder.id.slice(-8).toUpperCase()}</p>
                        </div>
                        <div className="text-right">
                          <Badge variant="outline" className={`border px-2 py-0 font-bold text-[10px] ${STATUS_STYLES[detailsOrder.status] || STATUS_STYLES.PENDING}`}>
                            {detailsOrder.status}
                          </Badge>
                          {isExpired && <Badge className="ml-2 bg-red-500/15 text-red-300 border-red-500/30 text-[10px]">EXPIRED</Badge>}
                          <p className="text-[10px] text-white/30 mt-1 font-mono">{new Date(detailsOrder.createdAt).toLocaleString()}</p>
                        </div>
                      </div>

                      <div className="grid gap-3 sm:grid-cols-3">
                        <div className="rounded-2xl border border-cyan-500/20 bg-cyan-500/10 p-4">
                          <HardDrive className="mb-2 h-4 w-4 text-cyan-300" />
                          <p className="text-[10px] uppercase tracking-widest text-white/35">RAM</p>
                          <p className="font-black">{formatMb(specs.ram)}</p>
                        </div>
                        <div className="rounded-2xl border border-purple-500/20 bg-purple-500/10 p-4">
                          <Cpu className="mb-2 h-4 w-4 text-purple-300" />
                          <p className="text-[10px] uppercase tracking-widest text-white/35">CPU</p>
                          <p className="font-black">{specs.cpu || '-'}%</p>
                        </div>
                        <div className="rounded-2xl border border-emerald-500/20 bg-emerald-500/10 p-4">
                          <Server className="mb-2 h-4 w-4 text-emerald-300" />
                          <p className="text-[10px] uppercase tracking-widest text-white/35">Disk</p>
                          <p className="font-black">{formatMb(specs.disk)}</p>
                        </div>
                      </div>

                      <div className="space-y-4 py-4 border-y border-white/[0.05]">
                        <div className="flex justify-between items-center text-xs font-bold uppercase tracking-widest text-white/20 pb-1 border-b border-white/5">
                          <span>Payment Transaction</span>
                          <span>{detailsOrder.paymentMethod}</span>
                        </div>

                        <DetailRow icon={<Wallet className="h-4 w-4" />} label="Amount" value={`৳${detailsOrder.amount.toLocaleString()}`} highlight />
                        <DetailRow icon={<Hash className="h-4 w-4" />} label="Transaction Ref" value={detailsOrder.transactionRef || 'No transaction ID submitted'} copy={detailsOrder.transactionRef} />
                        <DetailRow icon={<Calendar className="h-4 w-4" />} label="Order Date" value={new Date(detailsOrder.createdAt).toLocaleString()} />
                        <DetailRow icon={<User className="h-4 w-4" />} label="User" value={`${detailsOrder.user?.username || 'Unknown'} — ${detailsOrder.user?.email || detailsOrder.userId}`} />
                        <DetailRow icon={<Server className="h-4 w-4" />} label="Plan" value={`${detailsOrder.plan.name} (${serverType})`} />
                        <DetailRow icon={<Zap className="h-4 w-4" />} label="Panel Target" value={specs.serverType === 'host' ? `${specs.pteroLocationName || specs.pteroLocationId || '-'} / ${specs.pteroNestName || specs.pteroNestId || '-'} / ${specs.pteroEggName || specs.pteroEggId || '-'}` : `${specs.gfxNodeName || specs.gfxNodeId || '-'}`} />
                        {detailsOrder.expiresAt && <DetailRow icon={<Clock className="h-4 w-4" />} label="Expires At" value={new Date(detailsOrder.expiresAt).toLocaleString()} />}
                        {detailsOrder.pteroServerIdentifier && <DetailRow icon={<Server className="h-4 w-4" />} label="Server Identifier" value={detailsOrder.pteroServerIdentifier} copy={detailsOrder.pteroServerIdentifier} />}
                      </div>

                      {detailsOrder.serverInfo && (
                        <div>
                          <p className="mb-2 text-[10px] font-bold uppercase tracking-widest text-white/30">Server Info / Provisioning Result</p>
                          <pre className="max-h-40 overflow-auto rounded-2xl border border-white/10 bg-black/30 p-4 text-[11px] text-white/60">
                            {typeof detailsOrder.serverInfo === 'string' ? detailsOrder.serverInfo : JSON.stringify(detailsOrder.serverInfo, null, 2)}
                          </pre>
                        </div>
                      )}

                      {detailsOrder.status === 'PENDING' && (
                        <div className="rounded-2xl bg-amber-500/5 border border-amber-500/10 p-4 flex gap-3">
                          <AlertCircle className="w-4 h-4 text-amber-400 mt-0.5 flex-shrink-0" />
                          <div>
                            <p className="text-amber-400 text-[11px] font-bold mb-0.5">Admin Review Info</p>
                            <p className="text-amber-200/50 text-[10px] leading-relaxed">
                              Verify the transaction reference in your {detailsOrder.paymentMethod} account before approving. Approval can auto-provision this service.
                            </p>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex gap-3 p-6 bg-white/[0.02] border-t border-white/5">
                  {detailsOrder.status === 'PENDING' && (
                    <>
                      <Button variant="outline" className="flex-1 h-11 border-red-500/20 text-red-300 hover:bg-red-500/10 rounded-xl" onClick={() => handleReject(detailsOrder.id)}>
                        <X className="h-4 w-4 mr-2" />Reject
                      </Button>
                      <Button className="flex-1 h-11 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl" onClick={() => { setDetailsOrder(null); openApprove(detailsOrder) }}>
                        <Check className="h-4 w-4 mr-2" />Approve & Provision
                      </Button>
                    </>
                  )}
                  {detailsOrder.status !== 'PENDING' && (
                    <Button variant="outline" className="w-full h-11 border-white/10 text-white/60 hover:bg-white/5 rounded-xl" onClick={() => setDetailsOrder(null)}>
                      Close
                    </Button>
                  )}
                </div>
              </div>
            )
          })()}
        </DialogContent>
      </Dialog>

      <Dialog open={!!selected} onOpenChange={() => setSelected(null)}>
        <DialogContent className="bg-[#0f0f1a] border-white/10 max-w-lg">
          <DialogHeader>
            <DialogTitle className="text-white flex items-center gap-2"><Server className="w-4 h-4 text-cyan-400" />Process VPS Order</DialogTitle>
          </DialogHeader>
          {selected && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-2 text-xs bg-white/[0.03] rounded-xl p-3 border border-white/[0.06]">
                <div><span className="text-white/40">User:</span> <span className="text-white font-medium">{selected.user?.username}</span></div>
                <div><span className="text-white/40">Plan:</span> <span className="text-white font-medium">{selected.plan.name}</span></div>
                <div><span className="text-white/40">Amount:</span> <span className="text-white font-medium">৳{selected.amount}</span></div>
                <div><span className="text-white/40">Method:</span> <span className="text-white font-medium">{selected.paymentMethod}</span></div>
                {selected.transactionRef && <div className="col-span-2"><span className="text-white/40">Ref:</span> <span className="text-white font-medium">{selected.transactionRef}</span></div>}
                {(() => { const s = selected.plan.specs as any || {}; return s.ram ? (
                  <div className="col-span-2 flex gap-4 pt-1 border-t border-white/[0.04]">
                    {s.ram && <span className="text-cyan-400">🔵 {s.ram}MB RAM</span>}
                    {s.cpu && <span className="text-amber-400">⚡ {s.cpu}% CPU</span>}
                    {s.disk && <span className="text-purple-400">💾 {s.disk}MB Disk</span>}
                  </div>
                ) : null })()}
              </div>

              <div className="space-y-4 py-4">
                <div className="flex items-center justify-between p-3 rounded-xl bg-white/[0.03] border border-white/[0.06]">
                  <div className="space-y-0.5">
                    <Label className="text-sm font-medium text-white">Auto-Provision (Pterodactyl)</Label>
                    <p className="text-[10px] text-white/30">Automatically create server on panel</p>
                  </div>
                  <Switch checked={autoPtero} onCheckedChange={setAutoPtero} disabled={!pteroConfigured} />
                </div>

                <div className="flex items-center justify-between p-3 rounded-xl bg-cyan-500/[0.04] border border-cyan-500/[0.12]">
                  <div className="space-y-0.5">
                    <Label className="text-sm font-medium text-white">Auto-Provision (GFX Panel)</Label>
                    <p className="text-[10px] text-white/30">Automatically create VPS using GFX Panel API</p>
                  </div>
                  <Switch checked={autoGfx} onCheckedChange={setAutoGfx} disabled={!gfxConfigured} />
                </div>

                <div className="space-y-2">
                  <Label className="text-white/60">Duration (Days)</Label>
                  <Input 
                    type="number" 
                    value={durationDays} 
                    onChange={e => setDurationDays(e.target.value)} 
                    className="bg-white/5 border-white/10 rounded-xl"
                  />
                </div>

                <div className="space-y-2">
                  <Label className="text-white/60">Server Info / Notes (JSON or Text)</Label>
                  <Textarea 
                    placeholder="Credentials, IP, etc."
                    value={serverInfo} 
                    onChange={e => setServerInfo(e.target.value)}
                    className="bg-white/5 border-white/10 rounded-xl min-h-[100px] font-mono text-xs"
                  />
                </div>
              </div>
              <div className="flex gap-2 justify-end">
                <Button variant="outline" onClick={() => setSelected(null)} disabled={approving} className="border-white/10 text-white/70 rounded-xl text-xs h-9">Cancel</Button>
                <Button onClick={handleApprove} disabled={approving} className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white border-0 rounded-xl text-xs h-9 gap-1.5">
                  {approving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
                  {approving ? 'Processing…' : (autoGfx && gfxConfigured) || (autoPtero && pteroConfigured) ? 'Approve & Provision' : 'Approve Order'}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function DetailRow({ icon, label, value, copy, highlight }: { icon: React.ReactNode; label: string; value: string; copy?: string | null; highlight?: boolean }) {
  return (
    <div className="flex items-center justify-between gap-4">
      <div className="flex items-center gap-2 text-white/40">
        {icon}
        <span className="text-xs font-medium">{label}</span>
      </div>
      <div className="flex min-w-0 items-center gap-2 text-right">
        <span className={`truncate font-mono text-xs ${highlight ? 'text-emerald-400 text-lg font-black' : 'text-white/70'}`}>{value}</span>
        {copy && <CopyBtn text={copy} />}
      </div>
    </div>
  )
}
