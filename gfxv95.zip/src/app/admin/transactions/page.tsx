'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { Loader2, Check, X, AlertCircle, User, Wallet, Hash, Calendar, Smartphone, Printer, Copy, CheckCircle2, ArrowLeft } from 'lucide-react'
import { toast } from 'sonner'

interface Transaction {
  id: string
  userId: string
  user?: { username: string; email: string }
  amount: number
  method: string
  reference: string
  transactionType?: string
  status: string
  createdAt: string
}

function CopyBtn({ text }: { text: string }) {
  const copy = () => {
    navigator.clipboard.writeText(text)
    toast.success('Copied to clipboard')
  }
  return (
    <button onClick={copy} className="p-1 hover:bg-white/10 rounded-md transition-colors text-white/40 hover:text-white">
      <Copy className="w-3.5 h-3.5" />
    </button>
  )
}

export default function TransactionsAdminPage() {
  const { data: session, status: authStatus } = useSession()
  const router = useRouter()
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [loading, setLoading] = useState(true)
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null)
  const [approving, setApproving] = useState(false)
  const [isConfirming, setIsConfirming] = useState(false)

  useEffect(() => {
    const role = (session?.user as any)?.role
    if (authStatus === 'unauthenticated' || !['ADMIN', 'SUPER_ADMIN'].includes(role || '')) {
      router.push('/')
      return
    }
    fetchTransactions()
  }, [authStatus, session, router])

  const fetchTransactions = async () => {
    try {
      const res = await fetch('/api/admin/transactions')
      const data = await res.json()
      // API returns array directly
      setTransactions(Array.isArray(data) ? data : (data.transactions || []))
    } catch { toast.error('Failed to load') }
    finally { setLoading(false) }
  }

  const handleApprove = async (transactionId: string) => {
    console.log('Approving transaction:', transactionId)
    setApproving(true)
    try {
      const res = await fetch(`/api/admin/transactions/${transactionId}/approve`, {
        method: 'POST'
      })
      const result = await res.json()

      if (res.ok) {
        toast.success('Transaction approved! Wallet credited.')
        setSelectedTx(null)
        setIsConfirming(false)
        fetchTransactions()
      } else {
        toast.error(result.error || 'Failed to approve transaction')
      }
    } catch (error) {
      console.error('Approval failed:', error)
      toast.error('Approval failed')
    } finally {
      setApproving(false)
    }
  }

  const handleReject = async (transactionId: string) => {
    console.log('Rejecting transaction:', transactionId)
    if (!confirm('Are you sure you want to reject this transaction?')) return

    try {
      const res = await fetch(`/api/admin/transactions/${transactionId}/reject`, {
        method: 'POST'
      })
      const result = await res.json()

      if (res.ok) {
        toast.success('Transaction rejected.')
        setSelectedTx(null)
        fetchTransactions()
      } else {
        toast.error(result.error || 'Failed to reject transaction')
      }
    } catch (error) {
      console.error('Rejection failed:', error)
      toast.error('Rejection failed')
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <Loader2 className="h-8 w-8 animate-spin" />
      </div>
    )
  }

  const pendingTransactions = transactions.filter(tx => tx.status === 'PENDING')
  const completedTransactions = transactions.filter(tx => tx.status === 'COMPLETED')

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Transaction Management</h2>
        <p className="text-muted-foreground">Review and approve deposit transactions from users</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Pending Transactions</span>
            <Badge>{pendingTransactions.length}</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {pendingTransactions.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No pending transactions</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Method & Type</TableHead>
                    <TableHead>Your TrxID</TableHead>
                    <TableHead>Order ID</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Action</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody className="divide-y divide-white/5">
                  {pendingTransactions.map((tx) => (
                    <TableRow key={tx.id} className="cursor-pointer hover:bg-white/[0.02] transition-colors" onClick={() => setSelectedTx(tx)}>
                      <TableCell className="font-medium">
                        <div className="flex flex-col">
                          <span className="text-white font-bold">{tx.user?.username || 'Unknown'}</span>
                          <span className="text-[10px] text-white/30 truncate max-w-[150px]">{tx.user?.email || tx.userId}</span>
                        </div>
                      </TableCell>
                      <TableCell>৳{tx.amount.toLocaleString()}</TableCell>
                      <TableCell className="capitalize">
                        {tx.method}
                        {tx.transactionType && (
                          <span className="block text-[10px] text-muted-foreground uppercase">
                            {tx.transactionType}
                          </span>
                        )}
                      </TableCell>
                      <TableCell className="font-mono text-xs">{tx.reference}</TableCell>
                      <TableCell className="font-mono text-[10px] text-white/30">
                        #{tx.id.slice(-8).toUpperCase()}
                      </TableCell>
                      <TableCell>
                        {new Date(tx.createdAt).toLocaleDateString()}
                      </TableCell>
                      <TableCell onClick={(e) => e.stopPropagation()}>
                        <Button
                          size="sm"
                          variant="outline"
                          className="bg-emerald-500/5 border-emerald-500/20 text-emerald-400 hover:bg-emerald-500 hover:text-white transition-all rounded-lg h-8 text-[11px] font-bold"
                          onClick={() => setSelectedTx(tx)}
                        >
                          Review & Approve
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Completed Transactions</CardTitle>
        </CardHeader>
        <CardContent>
          {completedTransactions.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No completed transactions</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Method</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {completedTransactions.map((tx) => (
                    <TableRow key={tx.id}>
                      <TableCell className="font-medium">
                        <div className="flex flex-col">
                          <span className="text-white font-bold">{tx.user?.username || 'Unknown'}</span>
                          <span className="text-[10px] text-white/30 truncate max-w-[150px]">{tx.user?.email || tx.userId}</span>
                        </div>
                      </TableCell>
                      <TableCell>৳{tx.amount.toLocaleString()}</TableCell>
                      <TableCell className="capitalize">{tx.method}</TableCell>
                      <TableCell>
                        {new Date(tx.createdAt).toLocaleDateString()}
                      </TableCell>
                      <TableCell>
                        <Badge>Completed</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Review Modal */}
      <Dialog open={!!selectedTx} onOpenChange={(open) => { if(!open) { setSelectedTx(null); setIsConfirming(false); } }}>
        <DialogContent className="sm:max-w-[500px] bg-[#0d0d1a] border-white/10 text-white overflow-hidden p-0">
          <DialogHeader className="sr-only">
            <DialogTitle>Transaction Review</DialogTitle>
            <DialogDescription>Review and manage the selected deposit transaction.</DialogDescription>
          </DialogHeader>
          {selectedTx && (
            <div className="relative">
              {!isConfirming ? (
                /* Step 1: Main Review View (The Slip) */
                <div className="animate-in fade-in zoom-in-95 duration-200">
                  <div className="p-6">
                    {/* Visual Receipt/Slip Layout */}
                    <div className="bg-[#0f0f1e] rounded-3xl border border-white/10 overflow-hidden shadow-2xl relative">
                      {/* Decorative Top Bar */}
                      <div className="h-2 bg-gradient-to-r from-emerald-500 to-teal-600 w-full" />
                      
                      <div className="p-8 space-y-8">
                        {/* Receipt Header */}
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="text-2xl font-black tracking-tighter text-white">GfxStore</h3>
                            <p className="text-[10px] text-white/30 uppercase tracking-[0.2em] font-bold">Payment Receipt</p>
                          </div>
                          <div className="text-right">
                            <Badge variant="outline" className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20 px-2 py-0 font-bold text-[10px]">
                              {selectedTx.status}
                            </Badge>
                            <p className="text-[10px] text-white/30 mt-1 font-mono">
                              {new Date(selectedTx.createdAt).toLocaleString()}
                            </p>
                          </div>
                        </div>

                        {/* Receipt Body */}
                        <div className="space-y-4 py-4 border-y border-white/[0.05]">
                          <div className="flex justify-between items-center text-xs font-bold uppercase tracking-widest text-white/20 pb-1 border-b border-white/5">
                            <span>Transaction Summary</span>
                            <span>#{selectedTx.id.slice(-8).toUpperCase()}</span>
                          </div>

                          <div className="flex justify-between items-center">
                            <span className="text-white/40 text-xs font-medium">Payment Reference</span>
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-emerald-400 font-bold">{selectedTx.user?.username || selectedTx.user?.email || 'User'}</span>
                              <CopyBtn text={selectedTx.user?.username || selectedTx.user?.email || 'User'} />
                            </div>
                          </div>

                          <div className="flex justify-between items-center">
                            <span className="text-white/40 text-xs font-medium">Your TrxID</span>
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-white/70 text-[11px]">{selectedTx.reference}</span>
                              <CopyBtn text={selectedTx.reference} />
                            </div>
                          </div>

                          <div className="flex justify-between items-center">
                            <span className="text-white/40 text-xs font-medium">Amount</span>
                            <span className="text-emerald-400 font-black text-xl">৳{selectedTx.amount.toLocaleString()}</span>
                          </div>

                          <div className="flex justify-between items-center">
                            <span className="text-white/40 text-xs font-medium">Method</span>
                            <span className="text-white font-bold text-sm capitalize">
                              {selectedTx.method} ({selectedTx.transactionType || 'Send Money'})
                            </span>
                          </div>

                          <div className="flex justify-between items-center">
                            <span className="text-white/40 text-xs font-medium">User Account</span>
                            <div className="text-right">
                              <p className="text-white font-bold text-sm">{selectedTx.user?.username || 'Unknown'}</p>
                              <p className="text-[10px] text-white/30">{selectedTx.user?.email}</p>
                            </div>
                          </div>
                        </div>

                        {/* Receipt Footer/Instruction */}
                        <div className="rounded-2xl bg-amber-500/5 border border-amber-500/10 p-4 flex gap-3">
                          <AlertCircle className="w-4 h-4 text-amber-400 mt-0.5 flex-shrink-0" />
                          <div>
                            <p className="text-amber-400 text-[11px] font-bold mb-0.5">Admin Review Info</p>
                            <p className="text-amber-200/40 text-[10px] leading-relaxed">
                              Verify this TrxID in your {selectedTx.method} statement. If valid, approve to credit <span className="text-white font-bold">৳{selectedTx.amount}</span> (converted to USD) to this user.
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Punch Holes Effect */}
                      <div className="absolute left-0 top-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-8 bg-[#0d0d1a] rounded-full border-r border-white/10" />
                      <div className="absolute right-0 top-1/2 translate-x-1/2 -translate-y-1/2 w-4 h-8 bg-[#0d0d1a] rounded-full border-l border-white/10" />
                    </div>
                  </div>

                  {/* Modal Actions */}
                  <div className="flex gap-3 p-6 bg-white/[0.02] border-t border-white/5">
                    <Button
                      variant="outline"
                      className="flex-1 h-12 border-white/10 text-white/60 hover:text-white hover:bg-white/[0.05] hover:border-red-500/30 transition-all rounded-xl"
                      onClick={(e) => { e.stopPropagation(); handleReject(selectedTx.id); }}
                    >
                      <X className="h-4 w-4 mr-2" />
                      Reject
                    </Button>
                    <Button
                      className="flex-1 h-12 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-lg shadow-emerald-600/20 transition-all group"
                      onClick={(e) => { e.stopPropagation(); setIsConfirming(true); }}
                    >
                      Approve Deposit
                      <ArrowLeft className="h-4 w-4 ml-2 rotate-180 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </div>
                </div>
              ) : (
                /* Step 2: Stylish Confirmation View */
                <div className="p-6 space-y-8 animate-in fade-in slide-in-from-right-4 duration-300">
                  <div className="text-center space-y-4 py-4">
                    <div className="w-20 h-20 rounded-full bg-emerald-500/20 border-4 border-emerald-500/10 flex items-center justify-center mx-auto mb-4 animate-pulse">
                      <Check className="w-10 h-10 text-emerald-400" />
                    </div>
                    <h3 className="text-2xl font-black text-white">Confirm Approval</h3>
                    <div className="space-y-1">
                      <p className="text-white/40 text-sm">You are about to credit</p>
                      <p className="text-xl font-bold text-emerald-400">৳{selectedTx.amount.toLocaleString()}</p>
                      <p className="text-white/40 text-sm">to <span className="text-white font-bold">{selectedTx.user?.username}</span>'s account</p>
                    </div>
                  </div>

                  <div className="bg-amber-500/5 border border-amber-500/10 rounded-2xl p-4 flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                    <p className="text-xs text-amber-200/60 leading-relaxed">
                      Please ensure you have received <span className="text-white font-bold">৳{selectedTx.amount}</span> in your <span className="text-white font-bold uppercase">{selectedTx.method}</span> account. This action will convert the BDT to USD and update the user's wallet immediately.
                    </p>
                  </div>

                  <div className="flex flex-col gap-3">
                    <Button
                      className="w-full h-14 bg-emerald-600 hover:bg-emerald-500 text-white text-lg font-black rounded-2xl shadow-xl shadow-emerald-600/20 transition-all active:scale-95"
                      onClick={() => handleApprove(selectedTx.id)}
                      disabled={approving}
                    >
                      {approving ? (
                        <Loader2 className="h-6 w-6 animate-spin" />
                      ) : (
                        'YES, APPROVE NOW'
                      )}
                    </Button>
                    <Button
                      variant="ghost"
                      className="w-full h-12 text-white/30 hover:text-white hover:bg-white/5 rounded-2xl"
                      onClick={() => setIsConfirming(false)}
                      disabled={approving}
                    >
                      Go Back & Re-check
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}
