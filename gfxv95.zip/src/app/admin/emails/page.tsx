'use client'

import { useEffect, useState, useRef } from 'react'
import { formatDistanceToNow } from 'date-fns'
import { Mail, MailOpen, Trash2, RefreshCw, Inbox, Copy, Check, ArrowLeft } from 'lucide-react'
import { toast } from 'sonner'
import Link from 'next/link'

interface SentEmail {
  id: string
  to: string
  subject: string
  html: string
  sentAt: string
  read: boolean
}

export default function AdminEmailsPage() {
  const [emails, setEmails] = useState<SentEmail[]>([])
  const [selected, setSelected] = useState<SentEmail | null>(null)
  const [loading, setLoading] = useState(true)
  const [copied, setCopied] = useState(false)
  const iframeRef = useRef<HTMLIFrameElement>(null)

  const load = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/emails')
      if (res.ok) {
        const data = await res.json()
        setEmails(data.emails)
      } else {
        toast.error('Access denied')
      }
    } catch {
      toast.error('Failed to load emails')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const markRead = async (email: SentEmail) => {
    setSelected(email)
    if (!email.read) {
      await fetch('/api/admin/emails', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id: email.id })
      })
      setEmails(prev => prev.map(e => e.id === email.id ? { ...e, read: true } : e))
    }
  }

  const deleteEmail = async (id: string) => {
    await fetch(`/api/admin/emails?id=${id}`, { method: 'DELETE' })
    setEmails(prev => prev.filter(e => e.id !== id))
    if (selected?.id === id) setSelected(null)
    toast.success('Deleted')
  }

  const clearAll = async () => {
    if (!confirm('Delete all emails?')) return
    await fetch('/api/admin/emails', { method: 'DELETE' })
    setEmails([])
    setSelected(null)
    toast.success('All emails deleted')
  }

  const extractResetLink = (html: string) => {
    const match = html.match(/href="(http[^"]+reset-password[^"]+)"/)
    return match ? match[1] : null
  }

  const copyLink = async (link: string) => {
    await navigator.clipboard.writeText(link)
    setCopied(true)
    toast.success('Link copied!')
    setTimeout(() => setCopied(false), 2000)
  }

  const unreadCount = emails.filter(e => !e.read).length

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white flex flex-col">
      <div className="border-b border-white/10 bg-[#0d0d1a] px-6 py-4 flex items-center gap-4">
        <Link href="/admin" className="text-white/40 hover:text-white transition">
          <ArrowLeft className="w-5 h-5" />
        </Link>
        <div className="flex items-center gap-2">
          <Mail className="w-5 h-5 text-violet-400" />
          <h1 className="text-lg font-semibold">System Email Inbox</h1>
          {unreadCount > 0 && (
            <span className="bg-violet-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
              {unreadCount}
            </span>
          )}
        </div>
        <div className="ml-auto flex items-center gap-2">
          <button
            onClick={load}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-sm text-white/70 hover:text-white transition"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Refresh
          </button>
          {emails.length > 0 && (
            <button
              onClick={clearAll}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-red-500/10 hover:bg-red-500/20 text-sm text-red-400 hover:text-red-300 transition"
            >
              <Trash2 className="w-3.5 h-3.5" />
              Clear all
            </button>
          )}
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        <div className="w-80 shrink-0 border-r border-white/10 overflow-y-auto bg-[#0d0d1a]">
          {loading ? (
            <div className="flex items-center justify-center h-32 text-white/40 text-sm">
              Loading…
            </div>
          ) : emails.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-64 text-white/30 gap-3">
              <Inbox className="w-10 h-10" />
              <p className="text-sm">No emails yet</p>
            </div>
          ) : (
            emails.map(email => (
              <div
                key={email.id}
                onClick={() => markRead(email)}
                className={`px-4 py-3.5 border-b border-white/5 cursor-pointer transition group hover:bg-white/5 ${
                  selected?.id === email.id ? 'bg-violet-500/10 border-l-2 border-l-violet-500' : ''
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5 mb-1">
                      {!email.read && <span className="w-2 h-2 rounded-full bg-violet-400 shrink-0" />}
                      <p className={`text-sm truncate ${email.read ? 'text-white/60' : 'text-white font-medium'}`}>
                        {email.to}
                      </p>
                    </div>
                    <p className={`text-xs truncate mb-1 ${email.read ? 'text-white/40' : 'text-white/70'}`}>
                      {email.subject}
                    </p>
                    <p className="text-xs text-white/30">
                      {formatDistanceToNow(new Date(email.sentAt), { addSuffix: true })}
                    </p>
                  </div>
                  <button
                    onClick={e => { e.stopPropagation(); deleteEmail(email.id) }}
                    className="opacity-0 group-hover:opacity-100 p-1 hover:text-red-400 text-white/30 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="flex-1 overflow-y-auto">
          {!selected ? (
            <div className="flex flex-col items-center justify-center h-full text-white/20 gap-3">
              <MailOpen className="w-12 h-12" />
              <p>Select an email to view</p>
            </div>
          ) : (
            <div className="flex flex-col h-full">
              <div className="px-6 py-4 border-b border-white/10 bg-[#0d0d1a]">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <h2 className="text-lg font-semibold text-white mb-1">{selected.subject}</h2>
                    <p className="text-sm text-white/50">To: {selected.to}</p>
                    <p className="text-xs text-white/30 mt-0.5">
                      {new Date(selected.sentAt).toLocaleString()}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    {(() => {
                      const link = extractResetLink(selected.html)
                      if (!link) return null
                      return (
                        <button
                          onClick={() => copyLink(link)}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-violet-500/20 hover:bg-violet-500/30 text-sm text-violet-300 transition"
                        >
                          {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                          {copied ? 'Copied!' : 'Copy reset link'}
                        </button>
                      )
                    })()}
                    {(() => {
                      const link = extractResetLink(selected.html)
                      if (!link) return null
                      return (
                        <Link
                          href={link}
                          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-violet-600 to-cyan-600 text-sm text-white font-medium hover:opacity-90 transition"
                        >
                          Open reset link
                        </Link>
                      )
                    })()}
                  </div>
                </div>
              </div>

              <div className="flex-1 p-4 bg-white">
                <iframe
                  ref={iframeRef}
                  srcDoc={selected.html}
                  className="w-full h-full rounded-lg border-0 min-h-[600px]"
                  sandbox="allow-same-origin"
                  title="Email preview"
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
