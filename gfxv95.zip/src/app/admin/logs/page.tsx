'use client'

import { useState, useEffect, useRef } from 'react'
import { useRouter } from 'next/navigation'
import { useSession } from 'next-auth/react'
import { Navbar } from '@/components/navbar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { ArrowLeft, Search, RefreshCw, Trash2, Activity, Globe, Clock, User, ChevronLeft, ChevronRight, Circle } from 'lucide-react'
import Link from 'next/link'
import { formatDistanceToNow } from 'date-fns'
import { toast } from 'sonner'

interface ActivityLog {
  id: string
  userId?: string
  username?: string
  action: string
  details?: string
  ipAddress?: string
  userAgent?: string
  path?: string
  method?: string
  status?: number
  createdAt: string
}

function statusColor(status?: number) {
  if (!status) return 'text-white/40'
  if (status < 300) return 'text-emerald-400'
  if (status < 400) return 'text-yellow-400'
  if (status < 500) return 'text-orange-400'
  return 'text-red-400'
}

function methodColor(method?: string) {
  switch (method?.toUpperCase()) {
    case 'GET': return 'bg-emerald-500/20 text-emerald-400'
    case 'POST': return 'bg-blue-500/20 text-blue-400'
    case 'PUT': case 'PATCH': return 'bg-yellow-500/20 text-yellow-400'
    case 'DELETE': return 'bg-red-500/20 text-red-400'
    default: return 'bg-white/10 text-white/50'
  }
}

export default function AdminLogsPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [logs, setLogs] = useState<ActivityLog[]>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [autoRefresh, setAutoRefresh] = useState(true)
  const intervalRef = useRef<NodeJS.Timeout | null>(null)
  const limit = 50

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin')
    if (status === 'authenticated' && (session?.user as any)?.role !== 'ADMIN') router.push('/')
  }, [status, session])

  const fetchLogs = async (p = page, q = search) => {
    setLoading(true)
    try {
      const params = new URLSearchParams({ page: String(p), limit: String(limit) })
      if (q) params.set('search', q)
      const res = await fetch(`/api/admin/logs?${params}`)
      if (res.ok) {
        const data = await res.json()
        setLogs(data.logs || [])
        setTotal(data.total || 0)
      }
    } catch {}
    setLoading(false)
  }

  useEffect(() => { fetchLogs() }, [page])

  useEffect(() => {
    if (autoRefresh) {
      intervalRef.current = setInterval(() => fetchLogs(page, search), 2000)
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current)
    }
    return () => { if (intervalRef.current) clearInterval(intervalRef.current) }
  }, [autoRefresh, page, search])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    setPage(1)
    fetchLogs(1, search)
  }

  const clearOldLogs = async () => {
    if (!confirm('Delete logs older than 30 days?')) return
    try {
      const res = await fetch('/api/admin/logs?days=30', { method: 'POST' })
      const data = await res.json().catch(() => ({}))
      if (res.ok) {
        toast.success(data.message || 'Old logs cleared')
        fetchLogs()
      } else {
        toast.error(data.error || 'Failed to clear logs')
      }
    } catch { toast.error('Failed to clear logs') }
  }

  const clearAllLogs = async () => {
    if (!confirm('Delete ALL activity logs? This cannot be undone.')) return
    try {
      const res = await fetch('/api/admin/logs?all=1', { method: 'POST' })
      const data = await res.json().catch(() => ({}))
      if (res.ok) {
        toast.success(data.message || 'All logs cleared')
        fetchLogs()
      } else {
        toast.error(data.error || 'Failed to clear logs')
      }
    } catch { toast.error('Failed to clear logs') }
  }

  const totalPages = Math.ceil(total / limit)

  if (status === 'loading') {
    return <div className="min-h-screen bg-[#0a0a12] flex items-center justify-center"><div className="text-white/50">Loading...</div></div>
  }

  return (
    <div className="min-h-screen bg-[#0a0a12]">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center gap-3 mb-6">
          <Link href="/admin">
            <Button variant="ghost" size="sm" className="text-white/60 hover:text-white">
              <ArrowLeft className="w-4 h-4 mr-1" /> Admin
            </Button>
          </Link>
          <div className="flex-1 flex items-center gap-3">
            <Activity className="w-6 h-6 text-violet-400" />
            <h1 className="text-xl font-bold text-white">Activity Logs</h1>
            <Badge variant="secondary" className="text-xs">{total.toLocaleString()} records</Badge>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant={autoRefresh ? 'default' : 'outline'}
              size="sm"
              onClick={() => setAutoRefresh(v => !v)}
              className={autoRefresh ? 'bg-emerald-600 hover:bg-emerald-500 border-0' : 'border-white/10 text-white/60 hover:text-white'}
            >
              <Circle className={`w-2 h-2 mr-1.5 ${autoRefresh ? 'fill-emerald-300 animate-pulse' : 'fill-white/30'}`} />
              {autoRefresh ? 'Live' : 'Auto-Refresh'}
            </Button>
            <Button variant="ghost" size="sm" onClick={() => fetchLogs()} className="text-white/60 hover:text-white">
              <RefreshCw className="w-4 h-4" />
            </Button>
            <Button variant="ghost" size="sm" onClick={clearOldLogs} className="text-amber-400 hover:text-amber-300">
              <Trash2 className="w-4 h-4 mr-1" /> Clear Old (30d)
            </Button>
            <Button variant="ghost" size="sm" onClick={clearAllLogs} className="text-red-400 hover:text-red-300">
              <Trash2 className="w-4 h-4 mr-1" /> Clear All
            </Button>
          </div>
        </div>

        <form onSubmit={handleSearch} className="flex gap-2 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
            <Input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search by action, username, IP, path..."
              className="pl-10 bg-white/5 border-white/10 text-white placeholder:text-white/30 h-9"
            />
          </div>
          <Button type="submit" size="sm" className="bg-violet-600 hover:bg-violet-500">Search</Button>
        </form>

        {/* Stats row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-4">
          {[
            { label: 'Total Logs', value: total.toLocaleString(), icon: Activity, color: 'text-violet-400' },
            { label: 'Page', value: `${page} / ${totalPages || 1}`, icon: Globe, color: 'text-cyan-400' },
            { label: 'Showing', value: `${logs.length}`, icon: Clock, color: 'text-emerald-400' },
            { label: 'Auto Refresh', value: autoRefresh ? 'ON (2s)' : 'OFF', icon: RefreshCw, color: autoRefresh ? 'text-emerald-400' : 'text-white/30' },
          ].map(s => (
            <div key={s.label} className="bg-white/[0.03] border border-white/[0.06] rounded-xl p-3">
              <div className="flex items-center gap-2 mb-1">
                <s.icon className={`w-3.5 h-3.5 ${s.color}`} />
                <span className="text-xs text-white/40">{s.label}</span>
              </div>
              <div className={`text-lg font-bold ${s.color}`}>{s.value}</div>
            </div>
          ))}
        </div>

        {/* Logs table */}
        <div className="bg-white/[0.02] border border-white/[0.06] rounded-2xl overflow-hidden">
          {loading ? (
            <div className="flex items-center justify-center py-16 text-white/30">
              <RefreshCw className="w-5 h-5 animate-spin mr-2" /> Loading logs...
            </div>
          ) : logs.length === 0 ? (
            <div className="text-center py-16 text-white/30">
              <Activity className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p>No activity logs found.</p>
              <p className="text-xs mt-1">User activity will appear here as they use the site.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-white/[0.06] text-white/40 text-xs">
                    <th className="text-left px-4 py-3 font-medium">Time</th>
                    <th className="text-left px-4 py-3 font-medium">User</th>
                    <th className="text-left px-4 py-3 font-medium">Action</th>
                    <th className="text-left px-4 py-3 font-medium">Path</th>
                    <th className="text-left px-4 py-3 font-medium">Method</th>
                    <th className="text-left px-4 py-3 font-medium">Status</th>
                    <th className="text-left px-4 py-3 font-medium">IP Address</th>
                    <th className="text-left px-4 py-3 font-medium">Details</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/[0.04]">
                  {logs.map(log => (
                    <tr key={log.id} className="hover:bg-white/[0.02] transition-colors">
                      <td className="px-4 py-2.5 text-white/40 text-xs whitespace-nowrap">
                        <div title={new Date(log.createdAt).toLocaleString()}>
                          {formatDistanceToNow(new Date(log.createdAt), { addSuffix: true })}
                        </div>
                      </td>
                      <td className="px-4 py-2.5">
                        {log.username ? (
                          <div className="flex items-center gap-1.5">
                            <User className="w-3 h-3 text-violet-400 flex-shrink-0" />
                            <span className="text-violet-300 text-xs font-medium">{log.username}</span>
                          </div>
                        ) : (
                          <span className="text-white/20 text-xs">Guest</span>
                        )}
                      </td>
                      <td className="px-4 py-2.5">
                        <span className="text-white text-xs font-medium">{log.action}</span>
                      </td>
                      <td className="px-4 py-2.5 text-white/50 text-xs max-w-[200px] truncate">
                        {log.path || '—'}
                      </td>
                      <td className="px-4 py-2.5">
                        {log.method && (
                          <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${methodColor(log.method)}`}>
                            {log.method}
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-2.5">
                        <span className={`text-xs font-mono font-bold ${statusColor(log.status)}`}>
                          {log.status || '—'}
                        </span>
                      </td>
                      <td className="px-4 py-2.5 text-white/40 text-xs font-mono">
                        <div className="flex items-center gap-1">
                          <Globe className="w-3 h-3 flex-shrink-0" />
                          {log.ipAddress || '—'}
                        </div>
                      </td>
                      <td className="px-4 py-2.5 text-white/40 text-xs max-w-[200px] truncate">
                        {log.details || '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-3 mt-4">
            <Button variant="ghost" size="sm" onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="text-white/60">
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <span className="text-white/50 text-sm">Page {page} of {totalPages}</span>
            <Button variant="ghost" size="sm" onClick={() => setPage(p => Math.min(totalPages, p + 1))} disabled={page === totalPages} className="text-white/60">
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        )}
      </div>
    </div>
  )
}
