'use client'

import { useState, useEffect, useRef, useMemo } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { io, Socket } from 'socket.io-client'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import {
  Users, Package, TrendingUp, Download, Shield, Check, X, Eye, Trash2, Edit,
  RefreshCw, AlertTriangle, Bell, Database, Globe, LayoutDashboard, Zap, ShoppingCart,
  FolderOpen, CreditCard, Server, Send, Clock, CheckCircle, XCircle, Loader2,
  Star, DollarSign, UserCheck, MessageSquare, Search, ChevronRight, Ban, MoreVertical,
  Settings, Plus, Save, Crown, Menu, ChevronLeft, Activity, FileText, Layers,
  Monitor, ArrowUpRight, ArrowDownRight, BarChart3, PieChart, Heart, Tag, Megaphone, Ticket,
  ToggleLeft, ToggleRight, Power, Wrench, Image, Link2, MousePointerClick, Copy,
  Trophy, Gift, Share2, Users2, Handshake, Award, Sparkles, Target, CalendarDays,
  Video, Smartphone, Code2, Mail, AlertCircle, ArrowLeft, Tv
} from 'lucide-react'
import Link from 'next/link'
import { toast } from 'sonner'

interface AdminStats {
  totalUsers: number; totalItems: number; totalDownloads: number; totalRevenue: number
  activeUsers: number; pendingItems: number; pendingWithdrawals: number; pendingApplications: number
  pendingReports: number; totalOrders: number; pendingVideos: number; pendingApps: number; pendingCodes: number
}

interface User { id: string; username: string; email: string; role: string; isActive: boolean; isBanned: boolean; walletBalance: number; totalSales: number; sellerLevel: number; isVerified: boolean; createdAt: string; _count?: { items: number } }
interface Item { id: string; title: string; slug: string; status: string; downloads: number; price: number; createdAt: string; author: { username: string } }
interface Application { id: string; userId: string; displayName: string; experience: string; status: string; createdAt: string; user: { username: string; email: string; avatar?: string } }
interface Withdrawal { id: string; amount: number; method: string; accountInfo: string; status: string; adminNote?: string; createdAt: string; user: { username: string; email: string } }
interface Report { id: string; reason: string; details?: string; status: string; createdAt: string; reporter: { username: string }; reportedUser?: { username: string }; item?: { title: string; slug: string } }
interface VpsOrder { id: string; userId: string; user?: { username: string; email: string }; plan: { name: string }; amount: number; paymentMethod: string; transactionRef?: string; status: string; serverInfo?: any; createdAt: string }
interface Transaction { id: string; userId: string; user?: { username: string; email: string }; amount: number; method: string; reference: string; transactionType?: string; status: string; createdAt: string }
interface ServerPlan { id: string; name: string; description: string; price: number; specs: any; isActive: boolean; sortOrder: number }
interface SiteSettings {
  id?: string;
  siteName?: string;
  maintenance?: boolean;
  bkashNumber?: string;
  nagadNumber?: string;
  binanceId?: string;
  bankDetails?: {
    bankName?: string;
    accountName?: string;
    accountNumber?: string;
    routingNumber?: string;
    swiftCode?: string;
    instructions?: string;
  };
  privacyUrl?: string;
  helpCenterUrl?: string;
  documentationUrl?: string;
  contactUsUrl?: string;
  statusPageUrl?: string;
  discordUrl?: string;
  githubUrl?: string;
  twitterUrl?: string;
  privacyPolicy?: string;
  termsOfService?: string;
  guidelines?: string;
  dmcaUrl?: string;
  openaiApiKey?: string;
  anthropicApiKey?: string;
  geminiApiKey?: string;
  aiModel?: string;
  lowTokenMode?: boolean;
}

const STATUS_COLORS: Record<string, string> = {
  PENDING: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  APPROVED: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  COMPLETED: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  REJECTED: 'bg-red-500/10 text-red-400 border-red-500/20',
  RESOLVED: 'bg-sky-500/10 text-sky-400 border-sky-500/20',
  DISMISSED: 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20',
  ARCHIVED: 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20',
  DRAFT: 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20',
}

function CopyBtn({ text }: { text: string }) {
  const copy = () => {
    navigator.clipboard.writeText(text)
    toast.success('Copied to clipboard')
  }
  return (
    <button onClick={copy} className="p-1 hover:bg-white/10 rounded-md transition-colors text-white/40 hover:text-white">
      <Copy className="w-3.5 h-3.5" />
    </button>
  )
}

type Section = 'overview' | 'items' | 'videos' | 'apps' | 'code' | 'users' | 'applications' | 'withdrawals' | 'vps' | 'localVps' | 'transactions' | 'reports' | 'categories' | 'plans' | 'memberships' | 'ads' | 'coupons' | 'features' | 'settings' | 'campaigns' | 'badges' | 'referrals' | 'leaderboard' | 'mysteryRewards' | 'teams' | 'collaborations' | 'apiKeys' | 'emailInbox' | 'emailSettings' | 'logs' | 'aiProviders' | 'tunnels' | 'console' | 'pterodactyl' | 'gfxpanel' | 'aiTraining' | 'appsDeploys' | 'tvchannels'

interface MembershipType { id: string; name: string; roleName: string; description?: string; price: number; features?: string[]; color: string; isActive: boolean; sortOrder: number }
interface AdItem { id: string; title: string; description?: string; imageUrl?: string; linkUrl?: string; position: string; isActive: boolean; sortOrder: number; clicks: number; impressions: number; startDate?: string; endDate?: string; createdAt: string }
interface CouponItem { id: string; code: string; description?: string; discountType: string; discountValue: number; minOrderAmount?: number; maxUsage?: number; usageCount: number; expiresAt?: string; isActive: boolean; createdAt: string; createdBy?: { username: string }; _count?: { usages: number } }
interface FeatureToggleItem { id: string; featureKey: string; featureName: string; description?: string; isEnabled: boolean; category: string }

const NAV_SECTIONS: { key: Section; label: string; icon: any; group: string }[] = [
  { key: 'overview', label: 'Overview', icon: LayoutDashboard, group: 'Main' },
  { key: 'items', label: 'Items', icon: Package, group: 'Main' },
  { key: 'videos', label: 'Videos', icon: Video, group: 'Main' },
  { key: 'apps', label: 'Apps', icon: Smartphone, group: 'Main' },
  { key: 'code', label: 'Code', icon: Code2, group: 'Main' },
  { key: 'users', label: 'Users', icon: Users, group: 'Main' },
  { key: 'applications', label: 'Seller Apps', icon: UserCheck, group: 'Management' },
  { key: 'withdrawals', label: 'Withdrawals', icon: CreditCard, group: 'Management' },
  { key: 'vps', label: 'VPS Orders', icon: Server, group: 'Management' },
  { key: 'transactions', label: 'Transactions', icon: DollarSign, group: 'Management' },
  { key: 'reports', label: 'Reports', icon: AlertTriangle, group: 'Management' },
  { key: 'categories', label: 'Categories', icon: FolderOpen, group: 'Config' },
  { key: 'plans', label: 'Server Plans', icon: Layers, group: 'Config' },
  { key: 'memberships', label: 'Memberships', icon: Crown, group: 'Config' },
  { key: 'ads', label: 'Advertisements', icon: Megaphone, group: 'Marketing' },
  { key: 'coupons', label: 'Coupons', icon: Ticket, group: 'Marketing' },
  { key: 'campaigns', label: 'Campaigns', icon: CalendarDays, group: 'Marketing' },
  { key: 'referrals', label: 'Referrals', icon: Share2, group: 'Marketing' },
  { key: 'badges', label: 'Badges', icon: Award, group: 'Engagement' },
  { key: 'leaderboard', label: 'Leaderboard', icon: Trophy, group: 'Engagement' },
  { key: 'mysteryRewards', label: 'Mystery Rewards', icon: Gift, group: 'Engagement' },
  { key: 'teams', label: 'Teams', icon: Users2, group: 'Engagement' },
  { key: 'collaborations', label: 'Collaborations', icon: Handshake, group: 'Engagement' },
  { key: 'aiProviders', label: 'AI Providers', icon: Sparkles, group: 'AI & Cloud' },
  { key: 'tunnels', label: 'Zero Trust Tunnels', icon: Globe, group: 'AI & Cloud' },
  { key: 'gfxpanel', label: 'GFX Panel', icon: Server, group: 'AI & Cloud' },
  { key: 'aiTraining' as any, label: 'GfxV1 AI Brain', icon: Sparkles, group: 'AI & Cloud' },
  { key: 'pterodactyl', label: 'Pterodactyl Panel', icon: Server, group: 'AI & Cloud' },
  { key: 'appsDeploys' as any, label: 'App Deployments', icon: Globe, group: 'AI & Cloud' },
  { key: 'console', label: 'Server Console', icon: Database, group: 'AI & Cloud' },
  { key: 'tvchannels', label: 'TV Channels', icon: Tv, group: 'AI & Cloud' },
  { key: 'features', label: 'Feature Toggles', icon: ToggleLeft, group: 'System' },
  { key: 'apiKeys', label: 'API Keys', icon: Sparkles, group: 'System' },
  { key: 'emailInbox', label: 'Email Inbox', icon: Mail, group: 'System' },
  { key: 'emailSettings', label: 'Email Settings', icon: Mail, group: 'System' },
  { key: 'logs', label: 'Activity Logs', icon: Activity, group: 'System' },
  { key: 'settings', label: 'Settings', icon: Settings, group: 'System' },
]

export default function AdminPage() {
  const { data: session, status: authStatus } = useSession()
  const router = useRouter()
  const socketRef = useRef<Socket | null>(null)
  const [activeSection, setActiveSection] = useState<Section>('overview')
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [stats, setStats] = useState<AdminStats>({ totalUsers: 0, totalItems: 0, totalDownloads: 0, totalRevenue: 0, activeUsers: 0, pendingItems: 0, pendingWithdrawals: 0, pendingApplications: 0, pendingReports: 0, totalOrders: 0, pendingVideos: 0, pendingApps: 0, pendingCodes: 0 })
  const [users, setUsers] = useState<User[]>([])
  const [items, setItems] = useState<Item[]>([])
  const [applications, setApplications] = useState<Application[]>([])
  const [withdrawals, setWithdrawals] = useState<Withdrawal[]>([])
  const [reports, setReports] = useState<Report[]>([])
  const [categories, setCategories] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [searchUsers, setSearchUsers] = useState('')
  const [searchItems, setSearchItems] = useState('')
  const [newCategory, setNewCategory] = useState({ name: '', description: '' })
  const [announcement, setAnnouncement] = useState('')
  const [siteSettings, setSiteSettings] = useState({
    siteName: 'GfxStore',
    maintenance: true,
    bkashNumber: '',
    nagadNumber: '',
    binanceId: '',
    bankDetails: { bankName: '', accountName: '', accountNumber: '', routingNumber: '', swiftCode: '', instructions: '' },
    privacyUrl: '',
    helpCenterUrl: '',
    documentationUrl: '',
    contactUsUrl: '',
    statusPageUrl: '',
    discordUrl: '',
    githubUrl: '',
    twitterUrl: '',
    privacyPolicy: '',
    termsOfService: '',
    guidelines: '',
    dmcaUrl: ''
  })
  const [activeWdNote, setActiveWdNote] = useState<Record<string, string>>({})
  const [activeAppNote, setActiveAppNote] = useState<Record<string, string>>({})
  const [vpsOrders, setVpsOrders] = useState<VpsOrder[]>([])
  const [transactions, setTransactions] = useState<Transaction[]>([])
  const [plans, setPlans] = useState<ServerPlan[]>([])
  const [memberships, setMemberships] = useState<MembershipType[]>([])
  const [selectedVps, setSelectedVps] = useState<VpsOrder | null>(null)
  const [selectedTx, setSelectedTx] = useState<Transaction | null>(null)
  const [isConfirming, setIsConfirming] = useState(false)
  const [approving, setApproving] = useState(false)
  const [vpsServerInfo, setVpsServerInfo] = useState('')
  const [vpsApproving, setVpsApproving] = useState(false)
  const [editPlan, setEditPlan] = useState<Partial<ServerPlan> | null>(null)
  const [editMembership, setEditMembership] = useState<Partial<MembershipType> | null>(null)
  const [ads, setAds] = useState<AdItem[]>([])
  const [editAd, setEditAd] = useState<Partial<AdItem> | null>(null)
  const [coupons, setCoupons] = useState<CouponItem[]>([])
  const [editCoupon, setEditCoupon] = useState<Partial<CouponItem & { code: string; discountType: string; discountValue: number }> | null>(null)
  const [featureToggles, setFeatureToggles] = useState<FeatureToggleItem[]>([])
  const [campaignsList, setCampaignsList] = useState<any[]>([])
  const [editCampaign, setEditCampaign] = useState<any | null>(null)
  const [badgesList, setBadgesList] = useState<any[]>([])
  const [editBadge, setEditBadge] = useState<any | null>(null)
  const [referralStats, setReferralStats] = useState<any>({ totalReferrals: 0, totalEarnings: 0, topReferrers: [], recentReferrals: [] })
  const [leaderboardData, setLeaderboardData] = useState<any>({ topSellers: [], topBuyers: [], topItems: [] })
  const [mysteryRewards, setMysteryRewards] = useState<any[]>([])
  const [editReward, setEditReward] = useState<any | null>(null)
  const [rewardLogs, setRewardLogs] = useState<any[]>([])
  const [teamsList, setTeamsList] = useState<any[]>([])
  const [collaborationsList, setCollaborationsList] = useState<any[]>([])

  useEffect(() => {
    if (authStatus === 'loading') return
    if (authStatus === 'unauthenticated') { router.push('/auth/signin'); return }
    if (!['ADMIN', 'SUPER_ADMIN'].includes(session?.user?.role || '')) { router.push('/'); return }
    loadAll()
    initSocket()
    return () => { socketRef.current?.disconnect() }
  }, [authStatus, session])

  const initSocket = () => {
    // Check if we're on Vercel (production) - disable Socket.IO for Vercel
    const isVercel = typeof window !== 'undefined' && window.location.hostname.includes('vercel.app')
    const useSocketIO = !isVercel

    if (useSocketIO) {
      try {
        const socket = io(window.location.origin, { path: '/socket.io/', transports: ['websocket', 'polling'], reconnectionAttempts: 5 })
        socket.on('onlineUsers', (count: number) => setStats(p => ({ ...p, activeUsers: count })))
        socketRef.current = socket
      } catch { }
    } else {
      // Fallback for Vercel/production - no real-time admin features
      console.log('ℹ️ Real-time admin features disabled on Vercel')
    }
  }

  const loadAll = async () => {
    setLoading(true)
    try {
      const [statsRes, usersRes, itemsRes, appsRes, wdRes, rptRes, catsRes, vpsRes, txRes, plansRes, membRes, adsRes, couponsRes, featRes, settingsRes, campaignsRes, badgesRes, referralsRes, leaderboardRes, rewardsRes, teamsRes, collabsRes] = await Promise.all([
        fetch('/api/admin/stats').then(r => r.ok ? r.json() : {}).catch(() => ({})),
        fetch('/api/admin/users').then(r => r.ok ? r.json() : { users: [] }).catch(() => ({ users: [] })),
        fetch('/api/admin/items-all?limit=100').then(r => r.ok ? r.json() : []).catch(() => []),
        fetch('/api/admin/seller-applications').then(r => r.ok ? r.json() : { applications: [] }).catch(() => ({ applications: [] })),
        fetch('/api/admin/withdraw').then(r => r.ok ? r.json() : { requests: [] }).catch(() => ({ requests: [] })),
        fetch('/api/admin/reports').then(r => r.ok ? r.json() : { reports: [] }).catch(() => ({ reports: [] })),
        fetch('/api/categories').then(r => r.ok ? r.json() : []).catch(() => []),
        fetch('/api/admin/vps-orders').then(r => r.ok ? r.json() : []).catch(() => []),
        fetch('/api/admin/transactions').then(r => r.ok ? r.json() : []).catch(() => []),
        fetch('/api/admin/plans').then(r => r.ok ? r.json() : []).catch(() => []),
        fetch('/api/memberships').then(r => r.ok ? r.json() : []).catch(() => []),
        fetch('/api/admin/ads').then(r => r.ok ? r.json() : { ads: [] }).catch(() => ({ ads: [] })),
        fetch('/api/admin/coupons').then(r => r.ok ? r.json() : { coupons: [] }).catch(() => ({ coupons: [] })),
        fetch('/api/admin/feature-toggles').then(r => r.ok ? r.json() : { features: [] }).catch(() => ({ features: [] })),
        fetch('/api/admin/settings').then(r => r.ok ? r.json() : {}).catch(() => ({})),
        fetch('/api/admin/campaigns').then(r => r.ok ? r.json() : { campaigns: [] }).catch(() => ({ campaigns: [] })),
        fetch('/api/admin/badges').then(r => r.ok ? r.json() : { badges: [] }).catch(() => ({ badges: [] })),
        fetch('/api/admin/referrals').then(r => r.ok ? r.json() : {}).catch(() => ({})),
        fetch('/api/admin/leaderboard').then(r => r.ok ? r.json() : {}).catch(() => ({})),
        fetch('/api/admin/mystery-rewards').then(r => r.ok ? r.json() : { rewards: [], recentLogs: [] }).catch(() => ({ rewards: [], recentLogs: [] })),
        fetch('/api/admin/teams').then(r => r.ok ? r.json() : { teams: [] }).catch(() => ({ teams: [] })),
        fetch('/api/admin/collaborations').then(r => r.ok ? r.json() : { collaborations: [] }).catch(() => ({ collaborations: [] })),
      ])
      const statsData = statsRes as Partial<AdminStats>
      setStats({
        totalUsers: statsData.totalUsers || 0,
        totalItems: statsData.totalItems || 0,
        totalDownloads: statsData.totalDownloads || 0,
        totalRevenue: statsData.totalRevenue || 0,
        activeUsers: statsData.activeUsers || 0,
        pendingItems: statsData.pendingItems || 0,
        pendingWithdrawals: statsData.pendingWithdrawals || 0,
        pendingApplications: statsData.pendingApplications || 0,
        pendingReports: statsData.pendingReports || 0,
        totalOrders: statsData.totalOrders || 0,
        pendingVideos: statsData.pendingVideos || 0,
        pendingApps: statsData.pendingApps || 0,
        pendingCodes: statsData.pendingCodes || 0
      })
      setUsers(usersRes.users || [])
      setItems(Array.isArray(itemsRes) ? itemsRes : (itemsRes.items || []))
      setApplications(appsRes.applications || [])
      setWithdrawals(wdRes.requests || [])
      setReports(rptRes.reports || [])
      setCategories(Array.isArray(catsRes) ? catsRes : catsRes.categories || [])
      setVpsOrders(Array.isArray(vpsRes) ? vpsRes : (vpsRes.orders || []))
      setTransactions(Array.isArray(txRes) ? txRes : (txRes.transactions || []))
      setPlans(Array.isArray(plansRes) ? plansRes : (plansRes.plans || []))
      setMemberships(Array.isArray(membRes) ? membRes : (membRes.memberships || []))
      setAds(adsRes.ads || [])
      setCoupons(couponsRes.coupons || [])
      setFeatureToggles(featRes.features || [])
      setCampaignsList(campaignsRes.campaigns || [])
      setBadgesList(badgesRes.badges || [])
      setReferralStats(referralsRes || { totalReferrals: 0, totalEarnings: 0, topReferrers: [], recentReferrals: [] })
      setLeaderboardData(leaderboardRes || { topSellers: [], topBuyers: [], topItems: [] })
      setMysteryRewards(rewardsRes.rewards || [])
      setRewardLogs(rewardsRes.recentLogs || [])
      setTeamsList(teamsRes.teams || [])
      setCollaborationsList(collabsRes.collaborations || [])
      if (settingsRes && ((settingsRes as SiteSettings).siteName || (settingsRes as SiteSettings).maintenance !== undefined || (settingsRes as SiteSettings).id)) {
        setSiteSettings(prev => ({
          ...prev,
          siteName: (settingsRes as SiteSettings).siteName || prev.siteName,
          maintenance: (settingsRes as SiteSettings).maintenance ?? prev.maintenance,
          bkashNumber: (settingsRes as SiteSettings).bkashNumber || prev.bkashNumber,
          nagadNumber: (settingsRes as SiteSettings).nagadNumber || prev.nagadNumber,
          binanceId: (settingsRes as SiteSettings).binanceId || prev.binanceId,
          bankDetails: { ...prev.bankDetails, ...((settingsRes as SiteSettings).bankDetails || {}) },
          privacyUrl: (settingsRes as SiteSettings).privacyUrl || prev.privacyUrl,
          helpCenterUrl: (settingsRes as SiteSettings).helpCenterUrl || prev.helpCenterUrl,
          documentationUrl: (settingsRes as SiteSettings).documentationUrl || prev.documentationUrl,
          contactUsUrl: (settingsRes as SiteSettings).contactUsUrl || prev.contactUsUrl,
          statusPageUrl: (settingsRes as SiteSettings).statusPageUrl || prev.statusPageUrl,
          discordUrl: (settingsRes as SiteSettings).discordUrl || prev.discordUrl,
          githubUrl: (settingsRes as SiteSettings).githubUrl || prev.githubUrl,
          twitterUrl: (settingsRes as SiteSettings).twitterUrl || prev.twitterUrl,
          privacyPolicy: (settingsRes as SiteSettings).privacyPolicy || prev.privacyPolicy,
          termsOfService: (settingsRes as SiteSettings).termsOfService || prev.termsOfService,
          guidelines: (settingsRes as SiteSettings).guidelines || prev.guidelines,
          dmcaUrl: (settingsRes as SiteSettings).dmcaUrl || prev.dmcaUrl,
        }))
      }
    } catch { toast.error('Failed to load admin data') } finally { setLoading(false) }
  }

  const updateItemStatus = async (id: string, status: string) => {
    const res = await fetch(`/api/admin/items/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) })
    if (res.ok) { toast.success('Item updated'); loadAll() } else toast.error('Failed')
  }
  const updateUserRole = async (id: string, role: string) => {
    const res = await fetch(`/api/admin/users/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ role }) })
    if (res.ok) { toast.success('Role updated'); loadAll() } else toast.error('Failed')
  }
  const toggleUserBan = async (id: string, ban: boolean) => {
    const res = await fetch(`/api/admin/users/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ isBanned: ban }) })
    if (res.ok) { toast.success(ban ? 'User banned' : 'User unbanned'); loadAll() } else toast.error('Failed')
  }
  const processWithdrawal = async (id: string, status: 'APPROVED' | 'REJECTED') => {
    const adminNote = activeWdNote[id] || ''
    const res = await fetch('/api/admin/withdraw', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, status, adminNote }) })
    if (res.ok) { toast.success(`Withdrawal ${status.toLowerCase()}`); setActiveWdNote(p => { const n = { ...p }; delete n[id]; return n }); loadAll() }
    else { const d = await res.json().catch(() => ({})); toast.error(d.error || 'Failed') }
  }
  const processApplication = async (id: string, status: 'APPROVED' | 'REJECTED') => {
    const adminNote = activeAppNote[id] || ''
    const res = await fetch('/api/admin/seller-applications', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, status, adminNote }) })
    if (res.ok) { toast.success(`Application ${status.toLowerCase()}`); setActiveAppNote(p => { const n = { ...p }; delete n[id]; return n }); loadAll() } else toast.error('Failed')
  }
  const processReport = async (id: string, status: string) => {
    const res = await fetch('/api/admin/reports', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, status }) })
    if (res.ok) { toast.success('Report updated'); loadAll() } else toast.error('Failed')
  }
  const addCategory = async () => {
    if (!newCategory.name) return toast.error('Name required')
    const res = await fetch('/api/admin/categories', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(newCategory) })
    if (res.ok) { toast.success('Category added'); setNewCategory({ name: '', description: '' }); loadAll() }
    else { const d = await res.json().catch(() => ({})); toast.error(d.error || 'Failed') }
  }
  const deleteCategory = async (id: string) => {
    if (!confirm('Delete this category?')) return
    const res = await fetch(`/api/admin/categories/${id}`, { method: 'DELETE' })
    if (res.ok) { toast.success('Category deleted'); loadAll() } else toast.error('Failed')
  }
  const sendAnnouncement = async () => {
    if (!announcement.trim()) return toast.error('Message required')
    const res = await fetch('/api/admin/announcements', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message: announcement }) })
    if (res.ok) { const d = await res.json().catch(() => ({})); const count = d.notifiedUsers ?? d.sentTo ?? 'all'; const emailNote = d?.email?.ok ? ` · email blast sent` : (d?.email?.skipped ? '' : (d?.email?.error ? ` · email failed: ${d.email.error}` : '')); toast.success(`Announcement sent to ${count} users${emailNote}`); setAnnouncement('') } else { const e = await res.json().catch(() => ({})); toast.error(e?.error || 'Failed to send announcement') }
  }
  const approveVpsOrder = async () => {
    if (!selectedVps) return
    setVpsApproving(true)
    try {
      let parsedInfo: any = {}
      if (vpsServerInfo.trim()) { try { parsedInfo = JSON.parse(vpsServerInfo) } catch { parsedInfo = vpsServerInfo } }
      const res = await fetch(`/api/admin/vps-orders/${selectedVps.id}/approve`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ serverInfo: parsedInfo }) })
      if (res.ok) { toast.success('VPS order approved'); setSelectedVps(null); setVpsServerInfo(''); loadAll() } else toast.error('Failed')
    } catch { toast.error('Failed') } finally { setVpsApproving(false) }
  }
  const rejectVpsOrder = async (id: string) => {
    const res = await fetch(`/api/admin/vps-orders/${id}/reject`, { method: 'POST' }).catch(() => null)
    if (res?.ok) { toast.success('VPS order rejected'); loadAll() } else toast.error('Failed')
  }
  const approveTx = async (id: string) => {
    console.log('Approving transaction:', id)
    setApproving(true)
    try {
      const res = await fetch(`/api/admin/transactions/${id}/approve`, { method: 'POST' })
      const result = await res.json()
      
      if (res.ok) {
        toast.success('Transaction approved')
        setSelectedTx(null)
        setIsConfirming(false)
        loadAll()
      } else {
        toast.error(result.error || 'Failed to approve')
      }
    } catch (err) { 
      console.error('Approval error:', err)
      toast.error('Failed to approve') 
    }
    finally { setApproving(false) }
  }
  const rejectTx = async (id: string) => {
    console.log('Rejecting transaction:', id)
    if (!confirm('Are you sure you want to reject this transaction?')) return
    try {
      const res = await fetch(`/api/admin/transactions/${id}/reject`, { method: 'POST' })
      const result = await res.json()

      if (res.ok) {
        toast.success('Transaction rejected')
        setSelectedTx(null)
        loadAll()
      } else {
        toast.error(result.error || 'Failed to reject')
      }
    } catch (err) { 
      console.error('Rejection error:', err)
      toast.error('Failed to reject') 
    }
  }
  const savePlan = async () => {
    if (!editPlan?.name) return toast.error('Name required')
    const method = editPlan.id ? 'PATCH' : 'POST'
    const url = editPlan.id ? `/api/admin/plans/${editPlan.id}` : '/api/admin/plans'
    const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(editPlan) })
    if (res.ok) { toast.success(editPlan.id ? 'Plan updated' : 'Plan created'); setEditPlan(null); loadAll() } else toast.error('Failed')
  }
  const deletePlan = async (id: string) => {
    if (!confirm('Delete this plan?')) return
    const res = await fetch(`/api/admin/plans/${id}`, { method: 'DELETE' })
    if (res.ok) { toast.success('Plan deleted'); loadAll() } else toast.error('Failed')
  }
  const saveMembership = async () => {
    if (!editMembership?.name) return toast.error('Name required')
    const method = editMembership.id ? 'PATCH' : 'POST'
    const url = editMembership.id ? `/api/memberships/${editMembership.id}` : '/api/memberships'
    const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(editMembership) })
    if (res.ok) { toast.success(editMembership.id ? 'Membership updated' : 'Membership created'); setEditMembership(null); loadAll() } else toast.error('Failed')
  }
  const deleteMembership = async (id: string) => {
    if (!confirm('Delete this membership?')) return
    const res = await fetch(`/api/memberships/${id}`, { method: 'DELETE' })
    if (res.ok) { toast.success('Membership deleted'); loadAll() } else toast.error('Failed')
  }

  const saveAd = async () => {
    if (!editAd?.title) return toast.error('Title required')
    const method = editAd.id ? 'PATCH' : 'POST'
    const url = editAd.id ? `/api/admin/ads/${editAd.id}` : '/api/admin/ads'
    const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(editAd) })
    if (res.ok) { toast.success(editAd.id ? 'Ad updated' : 'Ad created'); setEditAd(null); loadAll() } else toast.error('Failed')
  }
  const deleteAd = async (id: string) => {
    if (!confirm('Delete this ad?')) return
    const res = await fetch(`/api/admin/ads/${id}`, { method: 'DELETE' })
    if (res.ok) { toast.success('Ad deleted'); loadAll() } else toast.error('Failed')
  }
  const toggleAd = async (id: string, isActive: boolean) => {
    const res = await fetch(`/api/admin/ads/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ isActive }) })
    if (res.ok) { toast.success(isActive ? 'Ad enabled' : 'Ad disabled'); loadAll() } else toast.error('Failed')
  }
  const saveCoupon = async () => {
    if (!editCoupon?.code || !editCoupon?.discountValue) return toast.error('Code and discount required')
    const res = await fetch('/api/admin/coupons', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(editCoupon) })
    if (res.ok) { toast.success('Coupon created'); setEditCoupon(null); loadAll() } else { const d = await res.json().catch(() => ({})); toast.error(d.error || 'Failed') }
  }
  const deleteCoupon = async (id: string) => {
    if (!confirm('Delete this coupon?')) return
    const res = await fetch('/api/admin/coupons', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) })
    if (res.ok) { toast.success('Coupon deleted'); loadAll() } else toast.error('Failed')
  }
  const toggleCoupon = async (id: string, isActive: boolean) => {
    const res = await fetch('/api/admin/coupons', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, isActive }) })
    if (res.ok) { toast.success(isActive ? 'Coupon enabled' : 'Coupon disabled'); loadAll() } else toast.error('Failed')
  }
  const toggleFeature = async (id: string, isEnabled: boolean) => {
    const res = await fetch('/api/admin/feature-toggles', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id, isEnabled }) })
    if (res.ok) { toast.success(isEnabled ? 'Feature enabled' : 'Feature disabled'); loadAll() } else toast.error('Failed')
  }
  const saveSettings = async () => {
    const res = await fetch('/api/admin/settings', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(siteSettings) })
    if (res.ok) toast.success('Settings saved'); else toast.error('Failed to save settings')
  }
  const toggleMaintenance = async (maintenance: boolean) => {
    await fetch('/api/admin/maintenance', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ maintenance })
    })

    // 🔥 save in localStorage
    localStorage.setItem('maintenance', maintenance.toString())

    window.location.reload()
  }

  const saveCampaign = async () => {
    if (!editCampaign?.name || !editCampaign?.startDate || !editCampaign?.endDate) return toast.error('Name and dates required')
    const method = editCampaign.id ? 'PUT' : 'POST'
    const url = editCampaign.id ? `/api/admin/campaigns/${editCampaign.id}` : '/api/admin/campaigns'
    const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(editCampaign) })
    if (res.ok) { toast.success(editCampaign.id ? 'Campaign updated' : 'Campaign created'); setEditCampaign(null); loadAll() } else toast.error('Failed')
  }
  const deleteCampaign = async (id: string) => {
    if (!confirm('Delete this campaign?')) return
    const res = await fetch(`/api/admin/campaigns/${id}`, { method: 'DELETE' })
    if (res.ok) { toast.success('Campaign deleted'); loadAll() } else toast.error('Failed')
  }
  const saveBadge = async () => {
    if (!editBadge?.name) return toast.error('Badge name required')
    const method = editBadge.id ? 'PUT' : 'POST'
    const url = editBadge.id ? `/api/admin/badges/${editBadge.id}` : '/api/admin/badges'
    const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(editBadge) })
    if (res.ok) { toast.success(editBadge.id ? 'Badge updated' : 'Badge created'); setEditBadge(null); loadAll() } else toast.error('Failed')
  }
  const deleteBadge = async (id: string) => {
    if (!confirm('Delete this badge?')) return
    const res = await fetch(`/api/admin/badges/${id}`, { method: 'DELETE' })
    if (res.ok) { toast.success('Badge deleted'); loadAll() } else toast.error('Failed')
  }
  const saveReward = async () => {
    if (!editReward?.name) return toast.error('Reward name required')
    const method = editReward.id ? 'PUT' : 'POST'
    const url = editReward.id ? `/api/admin/mystery-rewards/${editReward.id}` : '/api/admin/mystery-rewards'
    const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(editReward) })
    if (res.ok) { toast.success(editReward.id ? 'Reward updated' : 'Reward created'); setEditReward(null); loadAll() } else toast.error('Failed')
  }
  const deleteReward = async (id: string) => {
    if (!confirm('Delete this reward?')) return
    const res = await fetch(`/api/admin/mystery-rewards/${id}`, { method: 'DELETE' })
    if (res.ok) { toast.success('Reward deleted'); loadAll() } else toast.error('Failed')
  }

  const pendingApps = applications.filter(a => a.status === 'PENDING').length
  const pendingWds = withdrawals.filter(w => w.status === 'PENDING').length
  const pendingRpts = reports.filter(r => r.status === 'PENDING').length
  const pendingVps = vpsOrders.filter(o => o.status === 'PENDING').length
  const pendingTx = transactions.filter(t => t.status === 'PENDING').length
  const filteredUsers = users.filter(u => !searchUsers || u.username?.toLowerCase().includes(searchUsers.toLowerCase()) || u.email?.toLowerCase().includes(searchUsers.toLowerCase()))
  const filteredItems = items.filter(i => !searchItems || i.title?.toLowerCase().includes(searchItems.toLowerCase()) || i.author?.username?.toLowerCase().includes(searchItems.toLowerCase()))

  const badgeCounts: Partial<Record<Section, number>> = {
    applications: pendingApps, withdrawals: pendingWds, reports: pendingRpts,
    vps: pendingVps, transactions: pendingTx, items: stats.pendingItems,
    videos: stats.pendingVideos, apps: stats.pendingApps, code: stats.pendingCodes
  }

  if (authStatus === 'loading' || loading) return (
    <div className="min-h-screen bg-[#060611] flex items-center justify-center">
      <div className="text-center">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center mx-auto mb-4 animate-pulse">
          <Shield className="w-6 h-6 text-white" />
        </div>
        <Loader2 className="w-5 h-5 animate-spin text-purple-400 mx-auto mb-2" />
        <p className="text-white/30 text-xs">Loading admin panel...</p>
      </div>
    </div>
  )

  const SUBROUTE_SECTIONS: Partial<Record<Section, string>> = {
    videos: '/admin/videos',
    apps: '/admin/apps',
    code: '/admin/code',
    apiKeys: '/admin/api-keys',
    emailInbox: '/admin/emails',
    emailSettings: '/admin/email-settings',
    logs: '/admin/logs',
    tunnels: '/admin/zerotrust',
    gfxpanel: '/admin/gfxpanel',
    pterodactyl: '/admin/pterodactyl',
    aiTraining: '/admin/ai-training',
    appsDeploys: '/admin/appsdeploys',
    tvchannels: '/admin/tvchannels',
  }
  const navClick = (key: Section) => {
    setSidebarOpen(false)
    const route = SUBROUTE_SECTIONS[key]
    if (route) { router.push(route); return }
    setActiveSection(key)
  }

  return (
    <div className="min-h-screen bg-[#060611] text-white flex">
      {sidebarOpen && <div className="fixed inset-0 bg-black/60 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />}

      <aside className={`fixed lg:sticky top-0 left-0 z-50 lg:z-auto h-screen w-[260px] bg-[#0a0a16]/95 backdrop-blur-xl border-r border-white/[0.06] flex flex-col transition-transform duration-300 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="p-5 flex items-center gap-3 border-b border-white/[0.06]">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-purple-600 to-blue-600 flex items-center justify-center flex-shrink-0">
            <Shield className="w-4 h-4 text-white" />
          </div>
          <div className="flex-1 min-w-0">
            <h1 className="text-sm font-bold text-white tracking-tight">Admin Panel</h1>
            <p className="text-[10px] text-white/30 truncate">{session?.user?.email}</p>
          </div>
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden text-white/40 hover:text-white p-1"><X className="w-4 h-4" /></button>
        </div>

        <nav className="flex-1 overflow-y-auto p-3 space-y-1">
          {['Main', 'Management', 'Config', 'Marketing', 'Engagement', 'AI & Cloud', 'System'].map(group => (
            <div key={group}>
              <p className="text-[9px] font-semibold uppercase tracking-[0.15em] text-white/20 px-3 pt-4 pb-2">{group}</p>
              {NAV_SECTIONS.filter(s => s.group === group).map(({ key, label, icon: Icon }) => {
                const badge = badgeCounts[key] || 0
                const active = activeSection === key
                return (
                  <button key={key} onClick={() => navClick(key)} className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-[13px] font-medium transition-all duration-200 ${active ? 'bg-gradient-to-r from-purple-600/20 to-blue-600/10 text-white shadow-lg shadow-purple-900/10 border border-purple-500/10' : 'text-white/40 hover:text-white/80 hover:bg-white/[0.04] border border-transparent'}`}>
                    <Icon className={`w-4 h-4 flex-shrink-0 ${active ? 'text-purple-400' : ''}`} />
                    <span className="flex-1 text-left">{label}</span>
                    {badge > 0 && <span className="text-[9px] bg-red-500/20 text-red-400 border border-red-500/20 rounded-full px-1.5 py-0.5 font-semibold min-w-[20px] text-center">{badge}</span>}
                  </button>
                )
              })}
            </div>
          ))}
        </nav>

        <div className="p-3 border-t border-white/[0.06] space-y-1">
          <Link href="/admin/payment" className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-[13px] font-medium text-emerald-400/80 hover:text-emerald-300 hover:bg-emerald-500/10 transition">
            <CreditCard className="w-4 h-4" /> Payment & API Keys
          </Link>
          <Link href="/admin/tickets" className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-[13px] font-medium text-white/40 hover:text-white/80 hover:bg-white/[0.04] transition">
            <MessageSquare className="w-4 h-4" /> Support Tickets
          </Link>
          <Link href="/admin/tempmail" className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-[13px] font-medium text-blue-400/80 hover:text-blue-300 hover:bg-blue-500/10 transition">
            <Mail className="w-4 h-4" /> Temp Mail Config
          </Link>
          <Link href="/admin/tempnum" className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-[13px] font-medium text-green-400/80 hover:text-green-300 hover:bg-green-500/10 transition">
            <Smartphone className="w-4 h-4" /> Temp Number Config
          </Link>
          <Link href="/admin/health" className="flex items-center gap-2.5 px-3 py-2 rounded-xl text-[13px] font-medium text-emerald-400/80 hover:text-emerald-300 hover:bg-emerald-500/10 transition">
            <Activity className="w-4 h-4" /> CHECK-HEALTH
          </Link>
          <div className="flex items-center gap-2 bg-emerald-500/5 border border-emerald-500/10 rounded-xl px-3 py-2 mt-2">
            <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span className="text-[11px] text-emerald-400 font-medium">{stats.activeUsers} online now</span>
          </div>
          <Link href="/" className="flex items-center gap-2 mt-1 text-white/30 hover:text-white/60 text-[11px] px-3 py-2 rounded-xl hover:bg-white/[0.04] transition-colors">
            <ChevronLeft className="w-3 h-3" /> Back to site
          </Link>
        </div>
      </aside>

      <main className="flex-1 min-w-0">
        <header className="sticky top-0 z-30 bg-[#060611]/80 backdrop-blur-xl border-b border-white/[0.06] px-4 lg:px-8 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button onClick={() => setSidebarOpen(true)} className="lg:hidden text-white/40 hover:text-white p-1.5 rounded-lg hover:bg-white/[0.06]"><Menu className="w-5 h-5" /></button>
            <div>
              <h2 className="text-base font-bold text-white capitalize">{activeSection === 'overview' ? 'Dashboard' : NAV_SECTIONS.find(s => s.key === activeSection)?.label}</h2>
              <p className="text-[11px] text-white/30 hidden sm:block">{new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button onClick={loadAll} size="sm" variant="ghost" className="h-8 text-white/30 hover:text-white gap-1.5 text-xs rounded-xl hover:bg-white/[0.06]">
              <RefreshCw className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">Refresh</span>
            </Button>
          </div>
        </header>

        <div className="p-4 lg:p-8 max-w-[1400px]">
          {activeSection === 'overview' && <OverviewSection stats={stats} pendingApps={pendingApps} pendingWds={pendingWds} pendingRpts={pendingRpts} pendingVps={pendingVps} pendingTx={pendingTx} items={items} users={users} setActiveSection={setActiveSection} />}
          {activeSection === 'items' && <ItemsSection items={filteredItems} searchItems={searchItems} setSearchItems={setSearchItems} updateItemStatus={updateItemStatus} />}
          {activeSection === 'users' && <UsersSection users={filteredUsers} searchUsers={searchUsers} setSearchUsers={setSearchUsers} updateUserRole={updateUserRole} toggleUserBan={toggleUserBan} />}
          {activeSection === 'applications' && <ApplicationsSection applications={applications} activeAppNote={activeAppNote} setActiveAppNote={setActiveAppNote} processApplication={processApplication} />}
          {activeSection === 'withdrawals' && <WithdrawalsSection withdrawals={withdrawals} activeWdNote={activeWdNote} setActiveWdNote={setActiveWdNote} processWithdrawal={processWithdrawal} />}
          {activeSection === 'reports' && <ReportsSection reports={reports} processReport={processReport} />}
          {activeSection === 'categories' && <CategoriesSection categories={categories} newCategory={newCategory} setNewCategory={setNewCategory} addCategory={addCategory} deleteCategory={deleteCategory} />}
          {activeSection === 'vps' && <VpsSection vpsOrders={vpsOrders} selectedVps={selectedVps} setSelectedVps={setSelectedVps} vpsServerInfo={vpsServerInfo} setVpsServerInfo={setVpsServerInfo} vpsApproving={vpsApproving} approveVpsOrder={approveVpsOrder} rejectVpsOrder={rejectVpsOrder} />}
          {activeSection === 'transactions' && <TransactionsSection transactions={transactions} setSelectedTx={setSelectedTx} approveTx={approveTx} rejectTx={rejectTx} />}
          {activeSection === 'plans' && <PlansSection plans={plans} editPlan={editPlan} setEditPlan={setEditPlan} savePlan={savePlan} deletePlan={deletePlan} />}
          {activeSection === 'memberships' && <MembershipsSection memberships={memberships} editMembership={editMembership} setEditMembership={setEditMembership} saveMembership={saveMembership} deleteMembership={deleteMembership} />}
          {activeSection === 'ads' && <AdsSection ads={ads} editAd={editAd} setEditAd={setEditAd} saveAd={saveAd} deleteAd={deleteAd} toggleAd={toggleAd} />}
          {activeSection === 'coupons' && <CouponsSection coupons={coupons} editCoupon={editCoupon} setEditCoupon={setEditCoupon} saveCoupon={saveCoupon} deleteCoupon={deleteCoupon} toggleCoupon={toggleCoupon} />}
          {activeSection === 'features' && <FeatureTogglesSection features={featureToggles} toggleFeature={toggleFeature} />}
          {activeSection === 'settings' && <SettingsSection announcement={announcement} setAnnouncement={setAnnouncement} sendAnnouncement={sendAnnouncement} siteSettings={siteSettings} setSiteSettings={setSiteSettings} toggleMaintenance={toggleMaintenance} saveSettings={saveSettings} />}
          {activeSection === 'campaigns' && <CampaignsSection campaigns={campaignsList} editCampaign={editCampaign} setEditCampaign={setEditCampaign} saveCampaign={saveCampaign} deleteCampaign={deleteCampaign} />}
          {activeSection === 'badges' && <BadgesSection badges={badgesList} editBadge={editBadge} setEditBadge={setEditBadge} saveBadge={saveBadge} deleteBadge={deleteBadge} />}
          {activeSection === 'referrals' && <ReferralsSection stats={referralStats} />}
          {activeSection === 'leaderboard' && <LeaderboardSection data={leaderboardData} />}
          {activeSection === 'mysteryRewards' && <MysteryRewardsSection rewards={mysteryRewards} logs={rewardLogs} editReward={editReward} setEditReward={setEditReward} saveReward={saveReward} deleteReward={deleteReward} />}
          {activeSection === 'teams' && <TeamsSection teams={teamsList} />}
          {activeSection === 'collaborations' && <CollaborationsSection collaborations={collaborationsList} />}
          {activeSection === 'aiProviders' && <AiProvidersSection />}
          {activeSection === 'tunnels' && <AdminTunnelsSection />}
          {activeSection === 'console' && <AdminConsoleSection />}
        </div>
      </main>

      {/* Transaction Review Modal */}
      <Dialog open={!!selectedTx} onOpenChange={(open) => { if(!open) { setSelectedTx(null); setIsConfirming(false); } }}>
        <DialogContent className="sm:max-w-[500px] bg-[#0d0d1a] border-white/10 text-white overflow-hidden p-0">
          <DialogHeader className="sr-only">
            <DialogTitle>Transaction Review</DialogTitle>
            <DialogDescription>Review and manage the selected deposit transaction.</DialogDescription>
          </DialogHeader>
          {selectedTx && (
            <div className="relative">
              {!isConfirming ? (
                /* Step 1: Main Review View (The Slip) */
                <div className="animate-in fade-in zoom-in-95 duration-200">
                  <div className="p-6">
                    {/* Visual Receipt/Slip Layout */}
                    <div className="bg-[#0f0f1e] rounded-3xl border border-white/10 overflow-hidden shadow-2xl relative">
                      {/* Decorative Top Bar */}
                      <div className="h-2 bg-gradient-to-r from-emerald-500 to-teal-600 w-full" />
                      
                      <div className="p-8 space-y-8">
                        {/* Receipt Header */}
                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="text-2xl font-black tracking-tighter text-white">GfxStore</h3>
                            <p className="text-[10px] text-white/30 uppercase tracking-[0.2em] font-bold">Payment Receipt</p>
                          </div>
                          <div className="text-right">
                            <Badge variant="outline" className="bg-emerald-500/10 text-emerald-400 border-emerald-500/20 px-2 py-0 font-bold text-[10px]">
                              {selectedTx.status}
                            </Badge>
                            <p className="text-[10px] text-white/30 mt-1 font-mono">
                              {new Date(selectedTx.createdAt).toLocaleString()}
                            </p>
                          </div>
                        </div>

                        {/* Receipt Body */}
                        <div className="space-y-4 py-4 border-y border-white/[0.05]">
                          <div className="flex justify-between items-center">
                            <span className="text-white/40 text-xs font-medium">Order ID</span>
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-white font-bold">#{selectedTx.id.slice(-8).toUpperCase()}</span>
                              <CopyBtn text={selectedTx.id.slice(-8).toUpperCase()} />
                            </div>
                          </div>

                          <div className="flex justify-between items-center">
                            <span className="text-white/40 text-xs font-medium">Your TrxID</span>
                            <div className="flex items-center gap-2">
                              <span className="font-mono text-white/70 text-[11px]">{selectedTx.reference}</span>
                              <CopyBtn text={selectedTx.reference} />
                            </div>
                          </div>

                          <div className="flex justify-between items-center">
                            <span className="text-white/40 text-xs font-medium">Amount</span>
                            <span className="text-emerald-400 font-black text-xl">৳{selectedTx.amount.toLocaleString()}</span>
                          </div>

                          <div className="flex justify-between items-center">
                            <span className="text-white/40 text-xs font-medium">Method</span>
                            <span className="text-white font-bold text-sm capitalize">
                              {selectedTx.method} ({selectedTx.transactionType || 'Send Money'})
                            </span>
                          </div>

                          <div className="flex justify-between items-center">
                            <span className="text-white/40 text-xs font-medium">User Account</span>
                            <div className="text-right">
                              <p className="text-white font-bold text-sm">{selectedTx.user?.username || 'Unknown'}</p>
                              <p className="text-[10px] text-white/30">{selectedTx.user?.email}</p>
                            </div>
                          </div>
                        </div>

                        {/* Receipt Footer/Instruction */}
                        <div className="rounded-2xl bg-amber-500/5 border border-amber-500/10 p-4 flex gap-3">
                          <AlertCircle className="w-4 h-4 text-amber-400 mt-0.5 flex-shrink-0" />
                          <div>
                            <p className="text-amber-400 text-[11px] font-bold mb-0.5">Admin Review Info</p>
                            <p className="text-amber-200/40 text-[10px] leading-relaxed">
                              Verify this TrxID in your {selectedTx.method} statement. If valid, approve to credit <span className="text-white font-bold">৳{selectedTx.amount}</span> (converted to USD) to this user.
                            </p>
                          </div>
                        </div>
                      </div>

                      {/* Punch Holes Effect */}
                      <div className="absolute left-0 top-1/2 -translate-x-1/2 -translate-y-1/2 w-4 h-8 bg-[#0d0d1a] rounded-full border-r border-white/10" />
                      <div className="absolute right-0 top-1/2 translate-x-1/2 -translate-y-1/2 w-4 h-8 bg-[#0d0d1a] rounded-full border-l border-white/10" />
                    </div>
                  </div>

                  {/* Modal Actions */}
                  <div className="flex gap-3 p-6 bg-white/[0.02] border-t border-white/5">
                    <Button
                      variant="outline"
                      className="flex-1 h-12 border-white/10 text-white/60 hover:text-white hover:bg-white/[0.05] hover:border-red-500/30 transition-all rounded-xl"
                      onClick={(e) => { e.stopPropagation(); rejectTx(selectedTx.id); }}
                    >
                      <X className="h-4 w-4 mr-2" />
                      Reject
                    </Button>
                    <Button
                      className="flex-1 h-12 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl shadow-lg shadow-emerald-600/20 transition-all group"
                      onClick={(e) => { e.stopPropagation(); setIsConfirming(true); }}
                    >
                      Approve Deposit
                      <ArrowLeft className="h-4 w-4 ml-2 rotate-180 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </div>
                </div>
              ) : (
                /* Step 2: Stylish Confirmation View */
                <div className="p-6 space-y-8 animate-in fade-in slide-in-from-right-4 duration-300">
                  <div className="text-center space-y-4 py-4">
                    <div className="w-20 h-20 rounded-full bg-emerald-500/20 border-4 border-emerald-500/10 flex items-center justify-center mx-auto mb-4 animate-pulse">
                      <Check className="w-10 h-10 text-emerald-400" />
                    </div>
                    <h3 className="text-2xl font-black text-white">Confirm Approval</h3>
                    <div className="space-y-1">
                      <p className="text-white/40 text-sm">You are about to credit</p>
                      <p className="text-xl font-bold text-emerald-400">৳{selectedTx.amount.toLocaleString()}</p>
                      <p className="text-white/40 text-sm">to <span className="text-white font-bold">{selectedTx.user?.username}</span>'s account</p>
                    </div>
                  </div>

                  <div className="bg-amber-500/5 border border-amber-500/10 rounded-2xl p-4 flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
                    <p className="text-xs text-amber-200/60 leading-relaxed">
                      Please ensure you have received <span className="text-white font-bold">৳{selectedTx.amount}</span> in your <span className="text-white font-bold uppercase">{selectedTx.method}</span> account. This action will convert the BDT to USD and update the user's wallet immediately.
                    </p>
                  </div>

                  <div className="flex flex-col gap-3">
                    <Button
                      className="w-full h-14 bg-emerald-600 hover:bg-emerald-500 text-white text-lg font-black rounded-2xl shadow-xl shadow-emerald-600/20 transition-all active:scale-95"
                      onClick={() => approveTx(selectedTx.id)}
                      disabled={approving}
                    >
                      {approving ? (
                        <Loader2 className="h-6 w-6 animate-spin" />
                      ) : (
                        'YES, APPROVE NOW'
                      )}
                    </Button>
                    <Button
                      variant="ghost"
                      className="w-full h-12 text-white/30 hover:text-white hover:bg-white/5 rounded-2xl"
                      onClick={() => setIsConfirming(false)}
                      disabled={approving}
                    >
                      Go Back & Re-check
                    </Button>
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function SectionCard({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  return <div className={`bg-[#0c0c1a]/80 border border-white/[0.06] rounded-2xl ${className}`}>{children}</div>
}

function SectionHeader({ title, description, action }: { title: string; description?: string; action?: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 mb-6">
      <div>
        <h3 className="text-lg font-bold text-white">{title}</h3>
        {description && <p className="text-xs text-white/30 mt-0.5">{description}</p>}
      </div>
      {action}
    </div>
  )
}

function EmptyState({ icon: Icon, message }: { icon: any; message: string }) {
  return (
    <div className="text-center py-16">
      <div className="w-12 h-12 rounded-2xl bg-white/[0.03] border border-white/[0.06] flex items-center justify-center mx-auto mb-3">
        <Icon className="w-5 h-5 text-white/20" />
      </div>
      <p className="text-sm text-white/20">{message}</p>
    </div>
  )
}

function OverviewSection({ stats, pendingApps, pendingWds, pendingRpts, pendingVps, pendingTx, items, users, setActiveSection }: any) {
  const statCards = [
    { icon: Users, label: 'Total Users', value: stats.totalUsers?.toLocaleString() || '0', color: 'from-blue-600 to-cyan-600', sub: `${stats.activeUsers || 0} online` },
    { icon: Package, label: 'Total Items', value: stats.totalItems?.toLocaleString() || '0', color: 'from-purple-600 to-violet-600', sub: `${stats.pendingItems || 0} pending` },
    { icon: Download, label: 'Downloads', value: (stats.totalDownloads || 0) >= 1000 ? ((stats.totalDownloads || 0) / 1000).toFixed(1) + 'K' : String(stats.totalDownloads || 0), color: 'from-cyan-600 to-teal-600', sub: 'all time' },
    { icon: DollarSign, label: 'Revenue', value: `$${(stats.totalRevenue || 0).toFixed(0)}`, color: 'from-emerald-600 to-green-600', sub: `${stats.totalOrders || 0} orders` },
  ]

  const pendingActions = [
    { label: 'Seller Applications', count: pendingApps, section: 'applications', icon: UserCheck, color: 'text-blue-400 bg-blue-500/10 border-blue-500/15' },
    { label: 'Pending Items', count: stats.pendingItems, section: 'items', icon: Package, color: 'text-purple-400 bg-purple-500/10 border-purple-500/15' },
    { label: 'Pending Videos', count: stats.pendingVideos, href: '/admin/videos', icon: Video, color: 'text-rose-400 bg-rose-500/10 border-rose-500/15' },
    { label: 'Pending Apps', count: stats.pendingApps, href: '/admin/apps', icon: Smartphone, color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/15' },
    { label: 'Pending Code', count: stats.pendingCodes, href: '/admin/code', icon: Code2, color: 'text-amber-400 bg-amber-500/10 border-amber-500/15' },
    { label: 'Withdrawals', count: pendingWds, section: 'withdrawals', icon: CreditCard, color: 'text-amber-400 bg-amber-500/10 border-amber-500/15' },
    { label: 'VPS Orders', count: pendingVps, section: 'vps', icon: Server, color: 'text-purple-400 bg-purple-500/10 border-purple-500/15' },
    { label: 'Transactions', count: pendingTx, section: 'transactions', icon: DollarSign, color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/15' },
    { label: 'Reports', count: pendingRpts, section: 'reports', icon: AlertTriangle, color: 'text-red-400 bg-red-500/10 border-red-500/15' },
  ].filter(a => a.count > 0)

  const recentItems = items.slice(0, 5)
  const recentUsers = users.slice(0, 5)

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 lg:gap-4">
        {statCards.map(({ icon: Icon, label, value, color, sub }) => (
          <SectionCard key={label} className="p-4 lg:p-5">
            <div className="flex items-start justify-between mb-3">
              <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${color} flex items-center justify-center shadow-lg`}>
                <Icon className="w-5 h-5 text-white" />
              </div>
            </div>
            <p className="text-xl lg:text-2xl font-bold text-white tracking-tight">{value}</p>
            <div className="flex items-center justify-between mt-1">
              <p className="text-[11px] text-white/30">{label}</p>
              <p className="text-[10px] text-white/20">{sub}</p>
            </div>
          </SectionCard>
        ))}
      </div>

      <Link href="/admin/ai-chat" className="block group">
        <SectionCard className="p-4 lg:p-5 border-violet-500/20 bg-gradient-to-br from-violet-600/10 via-transparent to-cyan-600/10 hover:border-violet-500/40 transition-all">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-violet-600 to-cyan-600 flex items-center justify-center shadow-lg shadow-violet-600/30 flex-shrink-0">
              <Sparkles className="w-6 h-6 text-white" />
            </div>
            <div className="flex-1 min-w-0">
              <h4 className="text-sm font-semibold text-white flex items-center gap-2">
                AI Settings &amp; Assistant
                <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-violet-500/20 text-violet-300 border border-violet-500/30">SETUP</span>
              </h4>
              <p className="text-xs text-white/50 mt-0.5">Add your OpenAI API key to enable AI Chat, image generation, and thumbnail generation across the site.</p>
            </div>
            <ChevronRight className="w-5 h-5 text-white/30 group-hover:text-white/70 group-hover:translate-x-0.5 transition-all flex-shrink-0" />
          </div>
        </SectionCard>
      </Link>

      {pendingActions.length > 0 && (
        <SectionCard className="p-4 lg:p-5">
          <h4 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
            <Activity className="w-4 h-4 text-amber-400" /> Pending Actions
          </h4>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            {pendingActions.map(({ label, count, section, href, icon: Icon, color }) => (
              section ? (
                <button key={section} onClick={() => setActiveSection(section)} className={`flex items-center gap-3 p-3 rounded-xl border transition-all hover:scale-[1.02] active:scale-[0.98] ${color}`}>
                  <Icon className="w-4 h-4 flex-shrink-0" />
                  <span className="text-xs font-medium flex-1 text-left">{label}</span>
                  <span className="text-lg font-bold">{count}</span>
                </button>
              ) : (
                <Link key={href} href={href || '#'} className={`flex items-center gap-3 p-3 rounded-xl border transition-all hover:scale-[1.02] active:scale-[0.98] ${color}`}>
                  <Icon className="w-4 h-4 flex-shrink-0" />
                  <span className="text-xs font-medium flex-1 text-left">{label}</span>
                  <span className="text-lg font-bold">{count}</span>
                </Link>
              )
            ))}
          </div>
        </SectionCard>
      )}

      <div className="grid lg:grid-cols-2 gap-4">
        <SectionCard className="p-4 lg:p-5">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-sm font-semibold text-white flex items-center gap-2"><Package className="w-4 h-4 text-purple-400" />Recent Items</h4>
            <button onClick={() => setActiveSection('items')} className="text-[10px] text-purple-400 hover:text-purple-300 font-medium">View All</button>
          </div>
          {recentItems.length === 0 ? <p className="text-xs text-white/20 text-center py-6">No items yet</p> : (
            <div className="space-y-2">
              {recentItems.map((item: Item) => (
                <div key={item.id} className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-white/[0.03] transition-colors">
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-white/80 truncate">{item.title}</p>
                    <p className="text-[10px] text-white/30">by {item.author?.username} · {item.price === 0 ? 'Free' : `$${item.price}`}</p>
                  </div>
                  <Badge className={`text-[8px] h-4 border ${STATUS_COLORS[item.status] || 'bg-white/5 text-white/40 border-white/10'}`}>{item.status}</Badge>
                </div>
              ))}
            </div>
          )}
        </SectionCard>

        <SectionCard className="p-4 lg:p-5">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-sm font-semibold text-white flex items-center gap-2"><Users className="w-4 h-4 text-blue-400" />Recent Users</h4>
            <button onClick={() => setActiveSection('users')} className="text-[10px] text-blue-400 hover:text-blue-300 font-medium">View All</button>
          </div>
          {recentUsers.length === 0 ? <p className="text-xs text-white/20 text-center py-6">No users yet</p> : (
            <div className="space-y-2">
              {recentUsers.map((user: User) => (
                <div key={user.id} className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-white/[0.03] transition-colors">
                  <Avatar className="w-7 h-7 rounded-lg flex-shrink-0">
                    <AvatarFallback className="bg-gradient-to-br from-purple-900 to-blue-900 text-white text-[10px] rounded-lg">{user.username?.[0]?.toUpperCase()}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <p className="text-xs font-medium text-white/80 truncate">{user.username}</p>
                      {user.isVerified && <CheckCircle className="w-3 h-3 text-blue-400 flex-shrink-0" />}
                    </div>
                    <p className="text-[10px] text-white/30">{user.email}</p>
                  </div>
                  <Badge className="text-[8px] h-4 bg-white/5 text-white/30 border-white/10">{user.role}</Badge>
                </div>
              ))}
            </div>
          )}
        </SectionCard>
      </div>

      <SectionCard className="p-4 lg:p-5">
        <h4 className="text-sm font-semibold text-white mb-4 flex items-center gap-2"><BarChart3 className="w-4 h-4 text-emerald-400" />Feature Status</h4>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
          {[
            { name: 'Seller System', ok: true }, { name: 'Buyer/Cart/Checkout', ok: true },
            { name: 'Reviews & Ratings', ok: true }, { name: 'Search & Filter', ok: true },
            { name: 'Secure Downloads', ok: true }, { name: 'Earnings/Wallet', ok: true },
            { name: 'Custom Orders', ok: true }, { name: 'Freebies', ok: true },
            { name: 'Follow System', ok: true }, { name: 'Verified Sellers', ok: true },
            { name: 'Seller Levels', ok: true }, { name: 'Chat System', ok: true },
            { name: 'Notifications', ok: true }, { name: 'Wishlist', ok: true },
            { name: 'Creator Profiles', ok: true }, { name: 'Coupons', ok: true },
            { name: 'Reports', ok: true }, { name: 'VPS Hosting', ok: true },
            { name: 'Memberships', ok: true }, { name: 'Ads/Boost', ok: true },
            { name: 'AI SEO Generator', ok: true }, { name: 'Order Tracking', ok: true },
          ].map(f => (
            <div key={f.name} className={`flex items-center gap-2 px-3 py-2 rounded-lg border text-[11px] ${f.ok ? 'bg-emerald-500/5 border-emerald-500/10 text-emerald-400' : 'bg-red-500/5 border-red-500/10 text-red-400'}`}>
              {f.ok ? <CheckCircle className="w-3 h-3 flex-shrink-0" /> : <XCircle className="w-3 h-3 flex-shrink-0" />}
              <span className="truncate">{f.name}</span>
            </div>
          ))}
        </div>
      </SectionCard>
    </div>
  )
}

function ItemsSection({ items, searchItems, setSearchItems, updateItemStatus }: any) {
  return (
    <div>
      <SectionHeader title="Items Management" description={`${items.length} items total`} />
      <div className="relative max-w-sm mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/20" />
        <Input value={searchItems} onChange={(e: any) => setSearchItems(e.target.value)} placeholder="Search items..." className="pl-9 h-9 bg-white/[0.04] border-white/[0.08] text-white rounded-xl text-sm" />
      </div>
      <SectionCard className="divide-y divide-white/[0.04]">
        {items.length === 0 ? <EmptyState icon={Package} message="No items found" /> : items.map((item: Item) => (
          <div key={item.id} className="flex items-center gap-3 p-3 lg:p-4 hover:bg-white/[0.02] transition-colors">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <span className="text-sm font-medium text-white/90 truncate">{item.title}</span>
                <Badge className={`text-[8px] h-4 border ${STATUS_COLORS[item.status] || 'bg-white/5 text-white/40 border-white/10'}`}>{item.status}</Badge>
              </div>
              <p className="text-[11px] text-white/30 mt-0.5">by {item.author?.username} · {item.downloads} downloads · {item.price === 0 ? 'Free' : `$${item.price}`} · {new Date(item.createdAt).toLocaleDateString()}</p>
            </div>
            <div className="flex items-center gap-1.5 flex-shrink-0">
              <Link href={`/items/${item.slug}`}><Button size="sm" variant="ghost" className="h-7 w-7 p-0 text-white/20 hover:text-white rounded-lg"><Eye className="h-3.5 w-3.5" /></Button></Link>
              {item.status === 'PENDING' && <>
                <Button onClick={() => updateItemStatus(item.id, 'APPROVED')} size="sm" className="h-7 text-[10px] bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border-0 rounded-lg px-2.5 gap-1"><Check className="h-3 w-3" /><span className="hidden sm:inline">Approve</span></Button>
                <Button onClick={() => updateItemStatus(item.id, 'REJECTED')} size="sm" className="h-7 text-[10px] bg-red-500/15 hover:bg-red-500/25 text-red-400 border-0 rounded-lg px-2.5 gap-1"><X className="h-3 w-3" /><span className="hidden sm:inline">Reject</span></Button>
              </>}
              {item.status === 'APPROVED' && <Button onClick={() => updateItemStatus(item.id, 'ARCHIVED')} size="sm" className="h-7 text-[10px] bg-white/5 hover:bg-white/10 text-white/40 border-0 rounded-lg px-2.5">Archive</Button>}
            </div>
          </div>
        ))}
      </SectionCard>
    </div>
  )
}

function UsersSection({ users, searchUsers, setSearchUsers, updateUserRole, toggleUserBan }: any) {
  return (
    <div>
      <SectionHeader title="User Management" description={`${users.length} users total`} />
      <div className="relative max-w-sm mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-white/20" />
        <Input value={searchUsers} onChange={(e: any) => setSearchUsers(e.target.value)} placeholder="Search users..." className="pl-9 h-9 bg-white/[0.04] border-white/[0.08] text-white rounded-xl text-sm" />
      </div>
      <SectionCard className="divide-y divide-white/[0.04]">
        {users.length === 0 ? <EmptyState icon={Users} message="No users found" /> : users.map((user: User) => (
          <div key={user.id} className="p-3 lg:p-4 hover:bg-white/[0.02] transition-colors">
            <div className="flex items-start gap-3">
              <Avatar className="w-9 h-9 rounded-xl flex-shrink-0">
                <AvatarFallback className="bg-gradient-to-br from-purple-900 to-blue-900 text-white text-xs rounded-xl">{user.username?.[0]?.toUpperCase()}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-sm font-medium text-white/90">{user.username}</span>
                  {user.isVerified && <CheckCircle className="w-3.5 h-3.5 text-blue-400" />}
                  {user.isBanned && <Badge className="text-[8px] h-4 bg-red-500/10 text-red-400 border-red-500/20">Banned</Badge>}
                  <Badge className="text-[8px] h-4 bg-white/5 text-white/30 border-white/10">{user.role}</Badge>
                </div>
                <p className="text-[11px] text-white/30 mt-0.5 truncate">{user.email} · Wallet: ${user.walletBalance?.toFixed(2) || '0.00'} · Level {user.sellerLevel || 0} · {user._count?.items || 0} items</p>
              </div>
            </div>
            <div className="flex items-center gap-2 mt-2.5 pl-12 flex-wrap">
              <Select value={user.role} onValueChange={(v: string) => updateUserRole(user.id, v)}>
                <SelectTrigger className="h-7 w-28 bg-white/[0.04] border-white/[0.08] text-white rounded-lg text-[10px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#0f0f1a] border-white/10">
                  {['USER', 'CREATOR', 'MODERATOR', 'ADMIN'].map(r => <SelectItem key={r} value={r} className="text-white/80 text-xs">{r}</SelectItem>)}
                </SelectContent>
              </Select>
              <Button onClick={() => toggleUserBan(user.id, !user.isBanned)} size="sm" className={`h-7 text-[10px] border-0 rounded-lg px-3 ${user.isBanned ? 'bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400' : 'bg-red-500/15 hover:bg-red-500/25 text-red-400'}`}>
                {user.isBanned ? 'Unban' : 'Ban'}
              </Button>
              <Link href={`/profile/${user.username}`}><Button size="sm" variant="ghost" className="h-7 text-[10px] text-white/20 hover:text-white/60 rounded-lg px-2.5 gap-1"><Eye className="h-3 w-3" />Profile</Button></Link>
            </div>
          </div>
        ))}
      </SectionCard>
    </div>
  )
}

function ApplicationsSection({ applications, activeAppNote, setActiveAppNote, processApplication }: any) {
  return (
    <div>
      <SectionHeader title="Seller Applications" description={`${applications.filter((a: Application) => a.status === 'PENDING').length} pending review`} />
      <SectionCard className="divide-y divide-white/[0.04]">
        {applications.length === 0 ? <EmptyState icon={UserCheck} message="No seller applications" /> : applications.map((app: Application) => (
          <div key={app.id} className="p-4 hover:bg-white/[0.02] transition-colors">
            <div className="flex items-start gap-3">
              <Avatar className="w-10 h-10 rounded-xl flex-shrink-0">
                {app.user.avatar && <AvatarImage src={app.user.avatar} />}
                <AvatarFallback className="bg-gradient-to-br from-purple-900 to-blue-900 text-white text-sm rounded-xl">{app.user.username?.[0]?.toUpperCase()}</AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-sm font-semibold text-white">{app.displayName || app.user.username}</span>
                  <Badge className={`text-[8px] h-4 border ${STATUS_COLORS[app.status] || ''}`}>{app.status}</Badge>
                </div>
                <p className="text-[11px] text-white/30 mt-0.5">{app.user.email} · Applied {new Date(app.createdAt).toLocaleDateString()}</p>
                <p className="text-xs text-white/50 mt-2 line-clamp-3 leading-relaxed">{app.experience}</p>
                {app.status === 'PENDING' && (
                  <div className="mt-3 flex items-center gap-2 flex-wrap">
                    <Input value={activeAppNote[app.id] || ''} onChange={(e: any) => setActiveAppNote((p: any) => ({ ...p, [app.id]: e.target.value }))} placeholder="Admin note (optional)..." className="flex-1 h-8 bg-white/[0.04] border-white/[0.08] text-white rounded-lg text-xs min-w-[160px]" />
                    <Button onClick={() => processApplication(app.id, 'APPROVED')} size="sm" className="h-8 text-xs bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border-0 rounded-lg gap-1.5"><Check className="h-3.5 w-3.5" />Approve</Button>
                    <Button onClick={() => processApplication(app.id, 'REJECTED')} size="sm" className="h-8 text-xs bg-red-500/15 hover:bg-red-500/25 text-red-400 border-0 rounded-lg gap-1.5"><X className="h-3.5 w-3.5" />Reject</Button>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </SectionCard>
    </div>
  )
}

function WithdrawalsSection({ withdrawals, activeWdNote, setActiveWdNote, processWithdrawal }: any) {
  return (
    <div>
      <SectionHeader title="Withdrawal Requests" description={`${withdrawals.filter((w: Withdrawal) => w.status === 'PENDING').length} pending`} />
      <SectionCard className="divide-y divide-white/[0.04]">
        {withdrawals.length === 0 ? <EmptyState icon={CreditCard} message="No withdrawal requests" /> : withdrawals.map((wd: Withdrawal) => (
          <div key={wd.id} className="p-4 hover:bg-white/[0.02] transition-colors">
            <div className="flex items-start gap-3">
              <div className={`w-10 h-10 rounded-xl flex-shrink-0 flex items-center justify-center ${wd.status === 'PENDING' ? 'bg-amber-500/10' : wd.status === 'APPROVED' ? 'bg-emerald-500/10' : 'bg-red-500/10'}`}>
                {wd.status === 'PENDING' ? <Clock className="w-4 h-4 text-amber-400" /> : wd.status === 'APPROVED' ? <CheckCircle className="w-4 h-4 text-emerald-400" /> : <XCircle className="w-4 h-4 text-red-400" />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-sm font-semibold text-white">{wd.user.username}</span>
                  <Badge className={`text-[8px] h-4 border ${STATUS_COLORS[wd.status] || ''}`}>{wd.status}</Badge>
                  <span className="text-sm font-bold text-emerald-400">${wd.amount.toFixed(2)}</span>
                </div>
                <p className="text-[11px] text-white/30 mt-0.5">{wd.user.email} · via <span className="capitalize font-medium text-white/50">{wd.method}</span>: <span className="font-mono">{wd.accountInfo}</span> · {new Date(wd.createdAt).toLocaleDateString()}</p>
                {wd.adminNote && <p className="text-[11px] text-white/40 mt-1 italic">Note: {wd.adminNote}</p>}
                {wd.status === 'PENDING' && (
                  <div className="mt-3 flex items-center gap-2 flex-wrap">
                    <Input value={activeWdNote[wd.id] || ''} onChange={(e: any) => setActiveWdNote((p: any) => ({ ...p, [wd.id]: e.target.value }))} placeholder="Admin note (optional)..." className="flex-1 h-8 bg-white/[0.04] border-white/[0.08] text-white rounded-lg text-xs min-w-[160px]" />
                    <Button onClick={() => processWithdrawal(wd.id, 'APPROVED')} size="sm" className="h-8 text-xs bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border-0 rounded-lg gap-1.5"><Check className="h-3.5 w-3.5" />Approve</Button>
                    <Button onClick={() => processWithdrawal(wd.id, 'REJECTED')} size="sm" className="h-8 text-xs bg-red-500/15 hover:bg-red-500/25 text-red-400 border-0 rounded-lg gap-1.5"><X className="h-3.5 w-3.5" />Reject</Button>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </SectionCard>
    </div>
  )
}

function ReportsSection({ reports, processReport }: any) {
  return (
    <div>
      <SectionHeader title="Reports & Moderation" description={`${reports.filter((r: Report) => r.status === 'PENDING').length} need review`} />
      <SectionCard className="divide-y divide-white/[0.04]">
        {reports.length === 0 ? <EmptyState icon={AlertTriangle} message="No reports" /> : reports.map((rpt: Report) => (
          <div key={rpt.id} className="p-4 hover:bg-white/[0.02] transition-colors">
            <div className="flex items-start justify-between gap-3 flex-wrap">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
                  <span className="text-sm font-semibold text-white">{rpt.reason}</span>
                  <Badge className={`text-[8px] h-4 border ${STATUS_COLORS[rpt.status] || ''}`}>{rpt.status}</Badge>
                </div>
                <p className="text-[11px] text-white/30 mt-1">
                  by {rpt.reporter?.username}
                  {rpt.reportedUser && ` · against ${rpt.reportedUser.username}`}
                  {rpt.item && <> · item: <Link href={`/items/${rpt.item.slug}`} className="text-purple-400 hover:underline">{rpt.item.title}</Link></>}
                  {' '}· {new Date(rpt.createdAt).toLocaleDateString()}
                </p>
                {rpt.details && <p className="text-[11px] text-white/40 mt-1.5 italic leading-relaxed">"{rpt.details}"</p>}
              </div>
              {rpt.status === 'PENDING' && (
                <div className="flex gap-2 flex-shrink-0">
                  <Button onClick={() => processReport(rpt.id, 'RESOLVED')} size="sm" className="h-7 text-[10px] bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border-0 rounded-lg px-2.5">Resolve</Button>
                  <Button onClick={() => processReport(rpt.id, 'DISMISSED')} size="sm" className="h-7 text-[10px] bg-white/5 hover:bg-white/10 text-white/40 border-0 rounded-lg px-2.5">Dismiss</Button>
                </div>
              )}
            </div>
          </div>
        ))}
      </SectionCard>
    </div>
  )
}

function CategoriesSection({ categories, newCategory, setNewCategory, addCategory, deleteCategory }: any) {
  return (
    <div>
      <SectionHeader title="Categories" description={`${categories.length} categories configured`} />
      <div className="grid lg:grid-cols-3 gap-4">
        <SectionCard className="p-5 lg:col-span-1">
          <h4 className="text-sm font-semibold text-white mb-4 flex items-center gap-2"><Plus className="w-4 h-4 text-purple-400" />Add Category</h4>
          <div className="space-y-3">
            <div>
              <Label className="text-white/40 text-[11px] mb-1.5 block">Name</Label>
              <Input value={newCategory.name} onChange={(e: any) => setNewCategory((p: any) => ({ ...p, name: e.target.value }))} placeholder="e.g. Logos" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" />
            </div>
            <div>
              <Label className="text-white/40 text-[11px] mb-1.5 block">Description</Label>
              <Textarea value={newCategory.description} onChange={(e: any) => setNewCategory((p: any) => ({ ...p, description: e.target.value }))} placeholder="Short description..." className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl resize-none" rows={2} />
            </div>
            <Button onClick={addCategory} className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl text-xs h-9">Add Category</Button>
          </div>
        </SectionCard>
        <SectionCard className="lg:col-span-2 divide-y divide-white/[0.04]">
          {categories.length === 0 ? <EmptyState icon={FolderOpen} message="No categories" /> : categories.map((cat: any) => (
            <div key={cat.id} className="flex items-center justify-between p-3.5 hover:bg-white/[0.02] transition-colors">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-purple-500/10 flex items-center justify-center flex-shrink-0">
                  <FolderOpen className="w-4 h-4 text-purple-400" />
                </div>
                <div>
                  <p className="text-sm font-medium text-white">{cat.name}</p>
                  <p className="text-[10px] text-white/25">{cat.slug} · {cat._count?.items || 0} items</p>
                </div>
              </div>
              <Button onClick={() => deleteCategory(cat.id)} size="sm" variant="ghost" className="h-7 w-7 p-0 text-red-400/30 hover:text-red-400 hover:bg-red-500/10 rounded-lg"><Trash2 className="h-3.5 w-3.5" /></Button>
            </div>
          ))}
        </SectionCard>
      </div>
    </div>
  )
}

function VpsSection({ vpsOrders, selectedVps, setSelectedVps, vpsServerInfo, setVpsServerInfo, vpsApproving, approveVpsOrder, rejectVpsOrder }: any) {
  return (
    <div>
      <SectionHeader title="VPS Orders" description={`${vpsOrders.filter((o: VpsOrder) => o.status === 'PENDING').length} pending`} />
      <SectionCard className="divide-y divide-white/[0.04]">
        {vpsOrders.length === 0 ? <EmptyState icon={Server} message="No VPS orders" /> : vpsOrders.map((order: VpsOrder) => (
          <div key={order.id} className="p-4 hover:bg-white/[0.02] transition-colors">
            <div className="flex items-start gap-3">
              <div className={`w-10 h-10 rounded-xl flex-shrink-0 flex items-center justify-center ${order.status === 'PENDING' ? 'bg-amber-500/10' : order.status === 'APPROVED' ? 'bg-emerald-500/10' : 'bg-red-500/10'}`}>
                <Server className={`w-4 h-4 ${order.status === 'PENDING' ? 'text-amber-400' : order.status === 'APPROVED' ? 'text-emerald-400' : 'text-red-400'}`} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-sm font-medium text-white/90">{order.user?.username || order.userId}</span>
                  <Badge className={`text-[8px] h-4 border ${STATUS_COLORS[order.status] || 'bg-white/5 text-white/40 border-white/10'}`}>{order.status}</Badge>
                  <span className="text-sm font-bold text-emerald-400">${order.amount}</span>
                </div>
                <p className="text-[11px] text-white/30 mt-0.5">Plan: {order.plan?.name || 'N/A'} · {order.paymentMethod} {order.transactionRef && `· Ref: ${order.transactionRef}`} · {new Date(order.createdAt).toLocaleDateString()}</p>
                {order.status === 'APPROVED' && order.serverInfo && (
                  <div className="mt-2">
                    <p className="text-[10px] text-white/30 mb-1">Server Info:</p>
                    <pre className="text-[10px] text-white/50 bg-white/[0.03] rounded-lg p-2 overflow-x-auto border border-white/[0.04]">{typeof order.serverInfo === 'string' ? order.serverInfo : JSON.stringify(order.serverInfo, null, 2)}</pre>
                  </div>
                )}
                {order.status === 'PENDING' && (
                  <div className="flex items-center gap-2 mt-3">
                    <Button onClick={() => { setSelectedVps(order); setVpsServerInfo(order.serverInfo ? JSON.stringify(order.serverInfo, null, 2) : '') }} size="sm" className="h-7 text-[10px] bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border-0 rounded-lg px-3 gap-1"><Check className="h-3 w-3" />Process</Button>
                    <Button onClick={() => rejectVpsOrder(order.id)} size="sm" className="h-7 text-[10px] bg-red-500/15 hover:bg-red-500/25 text-red-400 border-0 rounded-lg px-3 gap-1"><X className="h-3 w-3" />Reject</Button>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </SectionCard>
      <Dialog open={!!selectedVps} onOpenChange={() => setSelectedVps(null)}>
        <DialogContent className="bg-[#0c0c1a] border-white/[0.08] text-white max-w-md rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-white text-base">Process VPS Order</DialogTitle>
            <DialogDescription className="text-white/30 text-xs">Fill in server details and approve.</DialogDescription>
          </DialogHeader>
          {selectedVps && (
            <div className="space-y-3">
              <div className="text-xs text-white/50 space-y-1 bg-white/[0.03] rounded-xl p-3 border border-white/[0.06]">
                <p><strong className="text-white/70">User:</strong> {selectedVps.user?.username}</p>
                <p><strong className="text-white/70">Plan:</strong> {selectedVps.plan?.name}</p>
                <p><strong className="text-white/70">Amount:</strong> ${selectedVps.amount}</p>
                <p><strong className="text-white/70">Method:</strong> {selectedVps.paymentMethod}</p>
                {selectedVps.transactionRef && <p><strong className="text-white/70">Ref:</strong> {selectedVps.transactionRef}</p>}
              </div>
              <Textarea className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl font-mono text-xs" rows={6} value={vpsServerInfo} onChange={(e: any) => setVpsServerInfo(e.target.value)} placeholder={'Server info:\nIP: 192.168.1.1\nUsername: admin\nPassword: pass123'} />
              <div className="flex gap-2 justify-end">
                <Button variant="ghost" onClick={() => setSelectedVps(null)} disabled={vpsApproving} className="text-white/40 hover:text-white hover:bg-white/5 rounded-xl text-xs">Cancel</Button>
                <Button onClick={approveVpsOrder} disabled={vpsApproving} className="bg-gradient-to-r from-emerald-600 to-green-600 text-white border-0 rounded-xl gap-1.5 text-xs">
                  {vpsApproving ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Check className="h-3.5 w-3.5" />}
                  {vpsApproving ? 'Approving...' : 'Approve'}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function TransactionsSection({ transactions, setSelectedTx, approveTx, rejectTx }: any) {
  return (
    <div>
      <SectionHeader title="Transactions" description={`${transactions.filter((t: Transaction) => t.status === 'PENDING').length} pending review`} />
      <SectionCard className="divide-y divide-white/[0.04]">
        {transactions.length === 0 ? <EmptyState icon={DollarSign} message="No transactions" /> : transactions.map((tx: Transaction) => (
          <div key={tx.id} className="p-4 hover:bg-white/[0.02] transition-colors cursor-pointer group" onClick={() => setSelectedTx(tx)}>
            <div className="flex items-start gap-3">
              <div className={`w-10 h-10 rounded-xl flex-shrink-0 flex items-center justify-center ${tx.status === 'PENDING' ? 'bg-amber-500/10' : tx.status === 'COMPLETED' ? 'bg-emerald-500/10' : 'bg-red-500/10'}`}>
                <DollarSign className={`w-4 h-4 ${tx.status === 'PENDING' ? 'text-amber-400' : tx.status === 'COMPLETED' ? 'text-emerald-400' : 'text-red-400'}`} />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-sm font-medium text-white/90">{tx.user?.username || tx.userId}</span>
                  <Badge className={`text-[8px] h-4 border ${tx.status === 'PENDING' ? STATUS_COLORS.PENDING : tx.status === 'COMPLETED' ? STATUS_COLORS.COMPLETED : STATUS_COLORS.REJECTED}`}>{tx.status}</Badge>
                  <span className="text-sm font-bold text-emerald-400">৳{tx.amount?.toLocaleString()}</span>
                </div>
                <p className="text-[11px] text-white/30 mt-0.5"><span className="capitalize">{tx.method}</span> · Ref: <span className="font-mono">{tx.reference}</span> · {new Date(tx.createdAt).toLocaleDateString()}</p>
              </div>
              {tx.status === 'PENDING' && (
                <div className="flex gap-1.5 flex-shrink-0" onClick={(e) => e.stopPropagation()}>
                  <Button onClick={() => setSelectedTx(tx)} size="sm" className="h-7 text-[10px] bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border-0 rounded-lg px-2.5 gap-1 transition-all active:scale-95"><Check className="h-3 w-3" /><span className="hidden sm:inline">Approve</span></Button>
                  <Button onClick={() => rejectTx(tx.id)} size="sm" className="h-7 text-[10px] bg-red-500/15 hover:bg-red-500/25 text-red-400 border-0 rounded-lg px-2.5 gap-1 transition-all active:scale-95"><X className="h-3 w-3" /><span className="hidden sm:inline">Reject</span></Button>
                </div>
              )}
            </div>
          </div>
        ))}
      </SectionCard>
    </div>
  )
}

function PlansSection({ plans, editPlan, setEditPlan, savePlan, deletePlan }: any) {
  return (
    <div>
      <SectionHeader title="Server Plans" description={`${plans.length} plans configured`}
        action={<Button onClick={() => setEditPlan({ name: '', description: '', price: 0, specs: {}, isActive: true, sortOrder: 0 })} size="sm" className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs h-8"><Plus className="h-3.5 w-3.5" />Add Plan</Button>} />
      <SectionCard className="divide-y divide-white/[0.04]">
        {plans.length === 0 ? <EmptyState icon={Layers} message="No server plans" /> : plans.map((plan: ServerPlan) => (
          <div key={plan.id} className="p-4 hover:bg-white/[0.02] transition-colors">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3 flex-1 min-w-0">
                <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center flex-shrink-0">
                  <Server className="w-4 h-4 text-blue-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-semibold text-white">{plan.name}</span>
                    <span className="text-sm font-bold text-emerald-400">${plan.price}</span>
                    {!plan.isActive && <Badge className="text-[8px] h-4 bg-red-500/10 text-red-400 border-red-500/20">Inactive</Badge>}
                  </div>
                  <p className="text-[11px] text-white/30 mt-0.5">{plan.description}</p>
                  {plan.specs && typeof plan.specs === 'object' && Object.keys(plan.specs).length > 0 && (
                    <div className="flex gap-1.5 flex-wrap mt-2">
                      {Object.entries(plan.specs).map(([k, v]) => (
                        <Badge key={k} className="text-[8px] bg-white/[0.04] text-white/40 border-white/[0.08]">{k}: {String(v)}</Badge>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              <div className="flex gap-1 flex-shrink-0">
                <Button onClick={() => setEditPlan({ ...plan })} size="sm" variant="ghost" className="h-7 w-7 p-0 text-white/20 hover:text-white rounded-lg"><Edit className="h-3.5 w-3.5" /></Button>
                <Button onClick={() => deletePlan(plan.id)} size="sm" variant="ghost" className="h-7 w-7 p-0 text-red-400/30 hover:text-red-400 hover:bg-red-500/10 rounded-lg"><Trash2 className="h-3.5 w-3.5" /></Button>
              </div>
            </div>
          </div>
        ))}
      </SectionCard>
      <Dialog open={!!editPlan} onOpenChange={() => setEditPlan(null)}>
        <DialogContent className="bg-[#0c0c1a] border-white/[0.08] text-white max-w-md rounded-2xl">
          <DialogHeader><DialogTitle className="text-white text-base">{editPlan?.id ? 'Edit Plan' : 'Add Plan'}</DialogTitle></DialogHeader>
          {editPlan && (
            <div className="space-y-3">
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Name</Label><Input value={editPlan.name || ''} onChange={(e: any) => setEditPlan((p: any) => ({ ...p!, name: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Description</Label><Textarea value={editPlan.description || ''} onChange={(e: any) => setEditPlan((p: any) => ({ ...p!, description: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl resize-none" rows={2} /></div>
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Price ($)</Label><Input type="number" value={editPlan.price || 0} onChange={(e: any) => setEditPlan((p: any) => ({ ...p!, price: parseFloat(e.target.value) }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div className="flex items-center justify-between py-1"><Label className="text-white/40 text-[11px]">Active</Label><Switch checked={editPlan.isActive !== false} onCheckedChange={(v: boolean) => setEditPlan((p: any) => ({ ...p!, isActive: v }))} /></div>
              <div className="flex gap-2 justify-end pt-2">
                <Button variant="ghost" onClick={() => setEditPlan(null)} className="text-white/40 hover:text-white hover:bg-white/5 rounded-xl text-xs">Cancel</Button>
                <Button onClick={savePlan} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs"><Save className="h-3.5 w-3.5" />Save</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function MembershipsSection({ memberships, editMembership, setEditMembership, saveMembership, deleteMembership }: any) {
  return (
    <div>
      <SectionHeader title="Memberships" description={`${memberships.length} tiers configured`}
        action={<Button onClick={() => setEditMembership({ name: '', roleName: '', description: '', price: 0, color: '#8B5CF6', isActive: true, sortOrder: 0 })} size="sm" className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs h-8"><Plus className="h-3.5 w-3.5" />Add Membership</Button>} />
      <SectionCard className="divide-y divide-white/[0.04]">
        {memberships.length === 0 ? <EmptyState icon={Crown} message="No memberships configured" /> : memberships.map((mem: MembershipType) => (
          <div key={mem.id} className="p-4 hover:bg-white/[0.02] transition-colors">
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-start gap-3 flex-1 min-w-0">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0" style={{ backgroundColor: (mem.color || '#8B5CF6') + '15' }}>
                  <Crown className="w-4 h-4" style={{ color: mem.color || '#8B5CF6' }} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-semibold text-white">{mem.name}</span>
                    <Badge className="text-[8px] h-4 bg-white/5 text-white/40 border-white/10">{mem.roleName}</Badge>
                    <span className="text-sm font-bold text-emerald-400">${mem.price}</span>
                    {!mem.isActive && <Badge className="text-[8px] h-4 bg-red-500/10 text-red-400 border-red-500/20">Inactive</Badge>}
                  </div>
                  {mem.description && <p className="text-[11px] text-white/30 mt-0.5">{mem.description}</p>}
                </div>
              </div>
              <div className="flex gap-1 flex-shrink-0">
                <Button onClick={() => setEditMembership({ ...mem })} size="sm" variant="ghost" className="h-7 w-7 p-0 text-white/20 hover:text-white rounded-lg"><Edit className="h-3.5 w-3.5" /></Button>
                <Button onClick={() => deleteMembership(mem.id)} size="sm" variant="ghost" className="h-7 w-7 p-0 text-red-400/30 hover:text-red-400 hover:bg-red-500/10 rounded-lg"><Trash2 className="h-3.5 w-3.5" /></Button>
              </div>
            </div>
          </div>
        ))}
      </SectionCard>
      <Dialog open={!!editMembership} onOpenChange={() => setEditMembership(null)}>
        <DialogContent className="bg-[#0c0c1a] border-white/[0.08] text-white max-w-md rounded-2xl">
          <DialogHeader><DialogTitle className="text-white text-base">{editMembership?.id ? 'Edit Membership' : 'Add Membership'}</DialogTitle></DialogHeader>
          {editMembership && (
            <div className="space-y-3">
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Name</Label><Input value={editMembership.name || ''} onChange={(e: any) => setEditMembership((p: any) => ({ ...p!, name: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Role Name</Label><Input value={editMembership.roleName || ''} onChange={(e: any) => setEditMembership((p: any) => ({ ...p!, roleName: e.target.value }))} placeholder="e.g. PREMIUM, VIP" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Description</Label><Textarea value={editMembership.description || ''} onChange={(e: any) => setEditMembership((p: any) => ({ ...p!, description: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl resize-none" rows={2} /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Price ($)</Label><Input type="number" value={editMembership.price || 0} onChange={(e: any) => setEditMembership((p: any) => ({ ...p!, price: parseFloat(e.target.value) }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Color</Label><Input type="color" value={editMembership.color || '#8B5CF6'} onChange={(e: any) => setEditMembership((p: any) => ({ ...p!, color: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] h-10 rounded-xl p-1 cursor-pointer" /></div>
              </div>
              <div className="flex items-center justify-between py-1"><Label className="text-white/40 text-[11px]">Active</Label><Switch checked={editMembership.isActive !== false} onCheckedChange={(v: boolean) => setEditMembership((p: any) => ({ ...p!, isActive: v }))} /></div>
              <div className="flex gap-2 justify-end pt-2">
                <Button variant="ghost" onClick={() => setEditMembership(null)} className="text-white/40 hover:text-white hover:bg-white/5 rounded-xl text-xs">Cancel</Button>
                <Button onClick={saveMembership} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs"><Save className="h-3.5 w-3.5" />Save</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function SettingsSection({ announcement, setAnnouncement, sendAnnouncement, siteSettings, setSiteSettings, toggleMaintenance, saveSettings }: any) {
  const [activeTab, setActiveTab] = useState<'basic' | 'links' | 'content' | 'ai' | 'panel'>('basic')
  const [pteroTesting, setPteroTesting] = useState(false)
  const [pteroStatus, setPteroStatus] = useState<'idle' | 'ok' | 'fail'>('idle')

  async function testPteroConnection() {
    setPteroTesting(true); setPteroStatus('idle')
    try {
      const r = await fetch('/api/panel', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'admin-validate', panelUrl: siteSettings.pteroUrl, apiKey: siteSettings.pteroAdminApiKey }) })
      const d = await r.json()
      setPteroStatus(d.ok ? 'ok' : 'fail')
      if (d.ok) { toast.success('Pterodactyl connected!') } else { toast.error('Connection failed: ' + (d.error || 'Invalid credentials')) }
    } catch { setPteroStatus('fail'); toast.error('Connection failed') } finally { setPteroTesting(false) }
  }

  return (
    <div>
      <SectionHeader title="Settings & Configuration" description="Manage site settings, announcements, payment, and footer links" />
      
      <div className="mb-4 flex gap-2 flex-wrap border-b border-white/10">
        {(['basic','ai','panel','links','content'] as const).map(tab => (
          <button key={tab} onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 text-sm font-medium transition-colors ${activeTab === tab ? 'text-white border-b-2 border-purple-500' : 'text-white/50 hover:text-white'}`}>
            {tab === 'basic' ? 'Basic Settings' : tab === 'ai' ? 'AI Configuration' : tab === 'panel' ? '🖥️ Pterodactyl Panel' : tab === 'links' ? 'Footer Links' : 'Policies & Content'}
          </button>
        ))}
      </div>

      {activeTab === 'panel' && (
        <div className="space-y-4">
          <SectionCard className="p-5 flex items-center gap-4">
            <div className="w-12 h-12 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center flex-shrink-0">
              <Server className="w-6 h-6 text-cyan-400" />
            </div>
            <div className="flex-1">
              <h4 className="text-sm font-semibold text-white mb-0.5">Pterodactyl Panel Configuration</h4>
              <p className="text-[11px] text-white/40">Moved to a dedicated page for better experience.</p>
            </div>
            <Link href="/admin/pterodactyl"
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-medium transition flex-shrink-0">
              <Server className="w-3.5 h-3.5" /> Open Pterodactyl
            </Link>
          </SectionCard>
        </div>
      )}

      {activeTab === 'ai' && (
        <div className="grid lg:grid-cols-2 gap-4">
          <div className="space-y-4">
            <SectionCard className="p-5">
              <h4 className="text-sm font-semibold text-white mb-4 flex items-center gap-2"><Sparkles className="w-4 h-4 text-purple-400" />AI API Keys (quick edit)</h4>
              <p className="text-[11px] text-white/40 mb-3">For the full multi-provider key panel (chat, image-gen, email blast), open <Link href="/admin/api-keys" className="text-purple-300 hover:text-purple-200 underline">/admin/api-keys</Link>.</p>
              <div className="space-y-3">
                <div>
                  <Label className="text-white/40 text-[11px] mb-1.5 block">OpenAI API Key</Label>
                  <Input
                    type="password"
                    value={siteSettings.openaiApiKey || ''}
                    onChange={(e: any) => setSiteSettings((p: any) => ({ ...p, openaiApiKey: e.target.value }))}
                    placeholder="sk-..."
                    className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl"
                  />
                </div>
                <div>
                  <Label className="text-white/40 text-[11px] mb-1.5 block">Anthropic API Key</Label>
                  <Input
                    type="password"
                    value={siteSettings.anthropicApiKey || ''}
                    onChange={(e: any) => setSiteSettings((p: any) => ({ ...p, anthropicApiKey: e.target.value }))}
                    placeholder="sk-ant-..."
                    className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl"
                  />
                </div>
                <div>
                  <Label className="text-white/40 text-[11px] mb-1.5 block">Google Gemini API Key</Label>
                  <Input
                    type="password"
                    value={siteSettings.geminiApiKey || ''}
                    onChange={(e: any) => setSiteSettings((p: any) => ({ ...p, geminiApiKey: e.target.value }))}
                    placeholder="AIza..."
                    className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl"
                  />
                </div>
              </div>
            </SectionCard>
          </div>

          <div className="space-y-4">
            <SectionCard className="p-5">
              <h4 className="text-sm font-semibold text-white mb-4 flex items-center gap-2"><Settings className="w-4 h-4 text-blue-400" />AI Settings</h4>
              <div className="space-y-3">
                <div>
                  <Label className="text-white/40 text-[11px] mb-1.5 block">Default AI Model</Label>
                  <Select value={siteSettings.aiModel || 'gpt-4o-mini'} onValueChange={(value: string) => setSiteSettings((p: any) => ({ ...p, aiModel: value }))}>
                    <SelectTrigger className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="gpt-4o-mini">GPT-4o Mini (OpenAI)</SelectItem>
                      <SelectItem value="gpt-4o">GPT-4o (OpenAI)</SelectItem>
                      <SelectItem value="claude-3-haiku">Claude 3 Haiku (Anthropic)</SelectItem>
                      <SelectItem value="claude-3-sonnet">Claude 3 Sonnet (Anthropic)</SelectItem>
                      <SelectItem value="gemini-pro">Gemini Pro (Google)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-center justify-between py-2.5 border-t border-white/[0.04]">
                  <div>
                    <p className="text-xs font-medium text-white flex items-center gap-2">
                      <Zap className="w-3.5 h-3.5 text-amber-400" />
                      Low Token Usage
                    </p>
                    <p className="text-[10px] text-white/25 mt-0.5">Optimize AI responses for lower token consumption</p>
                  </div>
                  <Switch checked={siteSettings.lowTokenMode || false} onCheckedChange={(v: boolean) => setSiteSettings((p: any) => ({ ...p, lowTokenMode: v }))} />
                </div>
                <Button onClick={saveSettings} className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-2 text-xs h-9 mt-3"><Save className="h-3.5 w-3.5" />Save AI Settings</Button>
              </div>
            </SectionCard>
          </div>
        </div>
      )}

      {activeTab === 'basic' && (
        <div className="grid lg:grid-cols-2 gap-4">
          <div className="space-y-4">
            <SectionCard className="p-5">
              <h4 className="text-sm font-semibold text-white mb-4 flex items-center gap-2"><Bell className="w-4 h-4 text-purple-400" />Send Announcement</h4>
              <Textarea value={announcement} onChange={(e: any) => setAnnouncement(e.target.value)} placeholder="Broadcast a message to all users..." className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl resize-none mb-3" rows={3} />
              <Button onClick={sendAnnouncement} className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-2 text-xs h-9"><Send className="h-3.5 w-3.5" />Send to All Users</Button>
            </SectionCard>

            <SectionCard className="p-5">
              <h4 className="text-sm font-semibold text-white mb-4 flex items-center gap-2"><CreditCard className="w-4 h-4 text-emerald-400" />Payment Config</h4>
              <div className="space-y-3">
                <p className="text-[10px] text-white/30 -mt-1">Mobile Banking (BD)</p>
                <div>
                  <Label className="text-white/40 text-[11px] mb-1.5 block">bKash Number</Label>
                  <Input value={siteSettings.bkashNumber} onChange={(e: any) => setSiteSettings((p: any) => ({ ...p, bkashNumber: e.target.value }))} placeholder="01XXXXXXXXX" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" />
                </div>
                <div>
                  <Label className="text-white/40 text-[11px] mb-1.5 block">Nagad Number</Label>
                  <Input value={siteSettings.nagadNumber} onChange={(e: any) => setSiteSettings((p: any) => ({ ...p, nagadNumber: e.target.value }))} placeholder="01XXXXXXXXX" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" />
                </div>
                <p className="text-[10px] text-white/30 pt-1 border-t border-white/[0.04]">Crypto</p>
                <div>
                  <Label className="text-white/40 text-[11px] mb-1.5 block">Binance Pay ID / UID</Label>
                  <Input value={siteSettings.binanceId} onChange={(e: any) => setSiteSettings((p: any) => ({ ...p, binanceId: e.target.value }))} placeholder="Binance UID or Pay ID" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" />
                </div>
                <p className="text-[10px] text-white/30 pt-1 border-t border-white/[0.04]">Bank Transfer</p>
                <div>
                  <Label className="text-white/40 text-[11px] mb-1.5 block">Bank Name</Label>
                  <Input value={siteSettings.bankDetails?.bankName || ''} onChange={(e: any) => setSiteSettings((p: any) => ({ ...p, bankDetails: { ...p.bankDetails, bankName: e.target.value } }))} placeholder="e.g. HSBC, Standard Chartered" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" />
                </div>
                <div>
                  <Label className="text-white/40 text-[11px] mb-1.5 block">Account Name</Label>
                  <Input value={siteSettings.bankDetails?.accountName || ''} onChange={(e: any) => setSiteSettings((p: any) => ({ ...p, bankDetails: { ...p.bankDetails, accountName: e.target.value } }))} placeholder="Full account holder name" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" />
                </div>
                <div>
                  <Label className="text-white/40 text-[11px] mb-1.5 block">Account Number / IBAN</Label>
                  <Input value={siteSettings.bankDetails?.accountNumber || ''} onChange={(e: any) => setSiteSettings((p: any) => ({ ...p, bankDetails: { ...p.bankDetails, accountNumber: e.target.value } }))} placeholder="Account number or IBAN" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" />
                </div>
                <div>
                  <Label className="text-white/40 text-[11px] mb-1.5 block">Routing / SWIFT Code</Label>
                  <Input value={siteSettings.bankDetails?.swiftCode || ''} onChange={(e: any) => setSiteSettings((p: any) => ({ ...p, bankDetails: { ...p.bankDetails, swiftCode: e.target.value } }))} placeholder="SWIFT/BIC or routing number" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" />
                </div>
                <div>
                  <Label className="text-white/40 text-[11px] mb-1.5 block">Payment Instructions (optional)</Label>
                  <Input value={siteSettings.bankDetails?.instructions || ''} onChange={(e: any) => setSiteSettings((p: any) => ({ ...p, bankDetails: { ...p.bankDetails, instructions: e.target.value } }))} placeholder="e.g. Use your username as reference" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" />
                </div>
                <Button onClick={saveSettings} className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 text-white border-0 rounded-xl gap-2 text-xs h-9 mt-3"><Save className="h-3.5 w-3.5" />Save Payment Info</Button>
              </div>
            </SectionCard>
          </div>

          <div className="space-y-4">
            <SectionCard className="p-5">
              <h4 className="text-sm font-semibold text-white mb-4 flex items-center gap-2"><Settings className="w-4 h-4 text-blue-400" />Site Settings</h4>
              <div className="space-y-3">
                <div>
                  <Label className="text-white/40 text-[11px] mb-1.5 block">Site Name</Label>
                  <Input value={siteSettings.siteName} onChange={(e: any) => setSiteSettings((p: any) => ({ ...p, siteName: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" />
                </div>
                <div className="flex items-center justify-between py-2.5 border-t border-white/[0.04]">
                  <div>
                    <p className="text-xs font-medium text-white flex items-center gap-2">
                      <Wrench className="w-3.5 h-3.5 text-amber-400" />
                      Maintenance Mode
                    </p>
                    <p className="text-[10px] text-white/25 mt-0.5">Block non-admin access to the site</p>
                  </div>
                  <Switch checked={siteSettings.maintenance} onCheckedChange={(v: boolean) => toggleMaintenance(v)} />
                </div>
                {siteSettings.maintenance && (
                  <div className="flex items-center gap-2 bg-amber-500/10 border border-amber-500/20 rounded-xl px-3 py-2 mt-2">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
                    <p className="text-[10px] text-amber-400">Site is in maintenance mode. Only admins can access.</p>
                  </div>
                )}
                <Button onClick={saveSettings} className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white border-0 rounded-xl gap-2 text-xs h-9 mt-3"><Save className="h-3.5 w-3.5" />Save Site Settings</Button>
              </div>
            </SectionCard>

            <SectionCard className="p-5">
              <h4 className="text-sm font-semibold text-white mb-4 flex items-center gap-2"><Database className="w-4 h-4 text-amber-400" />Quick Links</h4>
              <div className="space-y-1.5">
                {[
                  ['/', 'Back to Store', Globe],
                  ['/admin/payment', '💳 Payment & API Gateway', CreditCard],
                  ['/admin/ai-chat', '🤖 AI Assistant', Package],
                  ['/admin/videos', '🎬 Video Moderation', Package],
                  ['/admin/apps', '📱 App Moderation', Package],
                  ['/admin/code', '💻 Code Moderation', Package],
                  ['/dashboard', 'Seller Dashboard', LayoutDashboard],
                  ['/orders', 'All Orders', ShoppingCart],
                  ['/vps', 'VPS Management', Server],
                ].map(([href, label, Icon]: any) => (
                  <Link key={href} href={href}>
                    <div className="flex items-center justify-between text-xs text-white/40 hover:text-white py-2.5 px-3 rounded-xl hover:bg-white/[0.04] transition-all cursor-pointer group">
                      <span className="flex items-center gap-2.5"><Icon className="w-4 h-4" />{label}</span>
                      <ChevronRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </Link>
                ))}
              </div>
            </SectionCard>
          </div>
        </div>
      )}

      {activeTab === 'links' && (
        <div className="grid md:grid-cols-2 gap-4">
          {[
            { key: 'discordUrl', label: 'Discord', placeholder: 'https://discord.gg/...' },
            { key: 'githubUrl', label: 'GitHub', placeholder: 'https://github.com/...' },
            { key: 'twitterUrl', label: 'Twitter/X', placeholder: 'https://twitter.com/...' },
            { key: 'statusPageUrl', label: 'Status Page', placeholder: 'https://status.example.com' },
            { key: 'contactUsUrl', label: 'Contact Us', placeholder: 'https://example.com/contact' },
            { key: 'helpCenterUrl', label: 'Help Center', placeholder: 'https://help.example.com' },
            { key: 'documentationUrl', label: 'Documentation', placeholder: 'https://docs.example.com' },
            { key: 'privacyUrl', label: 'Privacy Policy', placeholder: 'https://example.com/privacy' },
            { key: 'dmcaUrl', label: 'DMCA', placeholder: 'https://example.com/dmca' },
          ].map(({ key, label, placeholder }) => (
            <SectionCard key={key} className="p-4">
              <Label className="text-white/40 text-[11px] mb-1.5 block">{label}</Label>
             <Input
                value={(siteSettings as any)[key] || ''}
                onChange={(e: any) => setSiteSettings((p: any) => ({ ...p, [key]: e.target.value }))}
                placeholder={placeholder}
                className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl text-xs"
              />
            </SectionCard>
          ))}
          <div className="md:col-span-2">
            <Button onClick={saveSettings} className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-2 text-xs h-9"><Save className="h-3.5 w-3.5" />Save Footer Links</Button>
          </div>
        </div>
      )}

      {activeTab === 'content' && (
        <div className="grid md:grid-cols-2 gap-4">
          <SectionCard className="p-5 md:col-span-2">
            <Label className="text-white/40 text-[11px] mb-1.5 block">Privacy Policy</Label>
            <Textarea
              value={siteSettings.privacyPolicy || ''}
              onChange={(e: any) => setSiteSettings((p: any) => ({ ...p, privacyPolicy: e.target.value }))}
              placeholder="Enter your privacy policy content..."
              className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl resize-none"
              rows={4}
            />
          </SectionCard>

          <SectionCard className="p-5 md:col-span-2">
            <Label className="text-white/40 text-[11px] mb-1.5 block">Terms of Service</Label>
            <Textarea
              value={siteSettings.termsOfService || ''}
              onChange={(e: any) => setSiteSettings((p: any) => ({ ...p, termsOfService: e.target.value }))}
              placeholder="Enter your terms of service content..."
              className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl resize-none"
              rows={4}
            />
          </SectionCard>

          <SectionCard className="p-5 md:col-span-2">
            <Label className="text-white/40 text-[11px] mb-1.5 block">Guidelines</Label>
            <Textarea
              value={siteSettings.guidelines || ''}
              onChange={(e: any) => setSiteSettings((p: any) => ({ ...p, guidelines: e.target.value }))}
              placeholder="Enter your community guidelines..."
              className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl resize-none"
              rows={4}
            />
          </SectionCard>

          <div className="md:col-span-2">
            <Button onClick={saveSettings} className="w-full bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-2 text-xs h-9"><Save className="h-3.5 w-3.5" />Save Policies & Content</Button>
          </div>
        </div>
      )}
    </div>
  )
}

function AdsSection({ ads, editAd, setEditAd, saveAd, deleteAd, toggleAd }: any) {
  const positions = ['homepage', 'browse', 'sidebar', 'footer', 'item-detail']
  return (
    <div>
      <SectionHeader title="Advertisements" description={`${ads.length} ads configured · ${ads.filter((a: AdItem) => a.isActive).length} active`}
        action={<Button onClick={() => setEditAd({ title: '', description: '', imageUrl: '', linkUrl: '', position: 'homepage', isActive: true, sortOrder: 0 })} size="sm" className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs h-8"><Plus className="h-3.5 w-3.5" />Create Ad</Button>} />

      {ads.length === 0 ? (
        <SectionCard><EmptyState icon={Megaphone} message="No advertisements yet" /></SectionCard>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {ads.map((ad: AdItem) => (
            <SectionCard key={ad.id} className="p-4">
              <div className="flex items-start justify-between gap-2 mb-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-semibold text-white truncate">{ad.title}</span>
                    <Badge className={`text-[8px] h-4 border ${ad.isActive ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20'}`}>{ad.isActive ? 'Active' : 'Inactive'}</Badge>
                    <Badge className="text-[8px] h-4 bg-purple-500/10 text-purple-400 border-purple-500/20 capitalize">{ad.position}</Badge>
                  </div>
                  {ad.description && <p className="text-[11px] text-white/30 mt-1 line-clamp-2">{ad.description}</p>}
                </div>
                <div className="flex gap-1 flex-shrink-0">
                  <Button onClick={() => toggleAd(ad.id, !ad.isActive)} size="sm" variant="ghost" className="h-7 w-7 p-0 text-white/20 hover:text-white rounded-lg">
                    {ad.isActive ? <ToggleRight className="h-3.5 w-3.5 text-emerald-400" /> : <ToggleLeft className="h-3.5 w-3.5" />}
                  </Button>
                  <Button onClick={() => setEditAd({ ...ad })} size="sm" variant="ghost" className="h-7 w-7 p-0 text-white/20 hover:text-white rounded-lg"><Edit className="h-3.5 w-3.5" /></Button>
                  <Button onClick={() => deleteAd(ad.id)} size="sm" variant="ghost" className="h-7 w-7 p-0 text-red-400/30 hover:text-red-400 hover:bg-red-500/10 rounded-lg"><Trash2 className="h-3.5 w-3.5" /></Button>
                </div>
              </div>
              {ad.imageUrl && (
                <div className="w-full h-24 rounded-xl bg-white/[0.04] border border-white/[0.06] overflow-hidden mb-3">
                  <img src={ad.imageUrl} alt={ad.title} className="w-full h-full object-cover" />
                </div>
              )}
              <div className="flex items-center gap-3 text-[10px] text-white/25">
                {ad.linkUrl && <span className="flex items-center gap-1"><Link2 className="w-3 h-3" />Has link</span>}
                <span className="flex items-center gap-1"><MousePointerClick className="w-3 h-3" />{ad.clicks} clicks</span>
                <span className="flex items-center gap-1"><Eye className="w-3 h-3" />{ad.impressions} views</span>
              </div>
            </SectionCard>
          ))}
        </div>
      )}

      <Dialog open={!!editAd} onOpenChange={() => setEditAd(null)}>
        <DialogContent className="bg-[#0c0c1a] border-white/[0.08] text-white max-w-md rounded-2xl">
          <DialogHeader><DialogTitle className="text-white text-base">{editAd?.id ? 'Edit Ad' : 'Create Ad'}</DialogTitle></DialogHeader>
          {editAd && (
            <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-1">
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Title *</Label><Input value={editAd.title || ''} onChange={(e: any) => setEditAd((p: any) => ({ ...p!, title: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Description</Label><Textarea value={editAd.description || ''} onChange={(e: any) => setEditAd((p: any) => ({ ...p!, description: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl resize-none" rows={2} /></div>
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Image URL</Label><Input value={editAd.imageUrl || ''} onChange={(e: any) => setEditAd((p: any) => ({ ...p!, imageUrl: e.target.value }))} placeholder="https://..." className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Link URL</Label><Input value={editAd.linkUrl || ''} onChange={(e: any) => setEditAd((p: any) => ({ ...p!, linkUrl: e.target.value }))} placeholder="https://..." className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-white/40 text-[11px] mb-1.5 block">Position</Label>
                  <Select value={editAd.position || 'homepage'} onValueChange={(v: string) => setEditAd((p: any) => ({ ...p!, position: v }))}>
                    <SelectTrigger className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl h-10"><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-[#0c0c1a] border-white/[0.08]">
                      {positions.map(p => <SelectItem key={p} value={p} className="text-white capitalize">{p}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Sort Order</Label><Input type="number" value={editAd.sortOrder || 0} onChange={(e: any) => setEditAd((p: any) => ({ ...p!, sortOrder: parseInt(e.target.value) || 0 }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              </div>
              <div className="flex items-center justify-between py-1"><Label className="text-white/40 text-[11px]">Active</Label><Switch checked={editAd.isActive !== false} onCheckedChange={(v: boolean) => setEditAd((p: any) => ({ ...p!, isActive: v }))} /></div>
              <div className="flex gap-2 justify-end pt-2">
                <Button variant="ghost" onClick={() => setEditAd(null)} className="text-white/40 hover:text-white hover:bg-white/5 rounded-xl text-xs">Cancel</Button>
                <Button onClick={saveAd} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs"><Save className="h-3.5 w-3.5" />Save</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function CouponsSection({ coupons, editCoupon, setEditCoupon, saveCoupon, deleteCoupon, toggleCoupon }: any) {
  return (
    <div>
      <SectionHeader title="Coupons" description={`${coupons.length} coupons · ${coupons.filter((c: CouponItem) => c.isActive).length} active`}
        action={<Button onClick={() => setEditCoupon({ code: '', description: '', discountType: 'PERCENTAGE', discountValue: 10, minOrderAmount: null, maxUsage: null, expiresAt: null, isActive: true })} size="sm" className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs h-8"><Plus className="h-3.5 w-3.5" />Create Coupon</Button>} />

      <SectionCard className="divide-y divide-white/[0.04]">
        {coupons.length === 0 ? <EmptyState icon={Ticket} message="No coupons created" /> : coupons.map((coupon: CouponItem) => {
          const isExpired = coupon.expiresAt && new Date(coupon.expiresAt) < new Date()
          const usageLeft = coupon.maxUsage ? coupon.maxUsage - coupon.usageCount : null
          return (
            <div key={coupon.id} className="p-4 hover:bg-white/[0.02] transition-colors">
              <div className="flex items-start gap-3">
                <div className={`w-10 h-10 rounded-xl flex-shrink-0 flex items-center justify-center ${coupon.isActive && !isExpired ? 'bg-emerald-500/10' : 'bg-zinc-500/10'}`}>
                  <Ticket className={`w-4 h-4 ${coupon.isActive && !isExpired ? 'text-emerald-400' : 'text-zinc-400'}`} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-mono font-bold text-white bg-white/[0.06] px-2 py-0.5 rounded-lg">{coupon.code}</span>
                    <Badge className="text-[8px] h-4 bg-purple-500/10 text-purple-400 border-purple-500/20">
                      {coupon.discountType === 'PERCENTAGE' ? `${coupon.discountValue}% OFF` : `$${coupon.discountValue} OFF`}
                    </Badge>
                    {!coupon.isActive && <Badge className="text-[8px] h-4 bg-zinc-500/10 text-zinc-400 border-zinc-500/20">Disabled</Badge>}
                    {isExpired && <Badge className="text-[8px] h-4 bg-red-500/10 text-red-400 border-red-500/20">Expired</Badge>}
                  </div>
                  {coupon.description && <p className="text-[11px] text-white/30 mt-0.5">{coupon.description}</p>}
                  <div className="flex items-center gap-3 mt-1.5 text-[10px] text-white/25">
                    <span>Used: {coupon._count?.usages || coupon.usageCount || 0}{coupon.maxUsage ? `/${coupon.maxUsage}` : ''}</span>
                    {coupon.minOrderAmount && <span>Min: ${coupon.minOrderAmount}</span>}
                    {coupon.expiresAt && <span>Expires: {new Date(coupon.expiresAt).toLocaleDateString()}</span>}
                    {coupon.createdBy && <span>By: {coupon.createdBy.username}</span>}
                  </div>
                </div>
                <div className="flex gap-1 flex-shrink-0">
                  <Button onClick={() => toggleCoupon(coupon.id, !coupon.isActive)} size="sm" variant="ghost" className="h-7 w-7 p-0 text-white/20 hover:text-white rounded-lg">
                    {coupon.isActive ? <ToggleRight className="h-3.5 w-3.5 text-emerald-400" /> : <ToggleLeft className="h-3.5 w-3.5" />}
                  </Button>
                  <Button onClick={() => deleteCoupon(coupon.id)} size="sm" variant="ghost" className="h-7 w-7 p-0 text-red-400/30 hover:text-red-400 hover:bg-red-500/10 rounded-lg"><Trash2 className="h-3.5 w-3.5" /></Button>
                </div>
              </div>
            </div>
          )
        })}
      </SectionCard>

      <Dialog open={!!editCoupon} onOpenChange={() => setEditCoupon(null)}>
        <DialogContent className="bg-[#0c0c1a] border-white/[0.08] text-white max-w-md rounded-2xl">
          <DialogHeader><DialogTitle className="text-white text-base">Create Coupon</DialogTitle></DialogHeader>
          {editCoupon && (
            <div className="space-y-3">
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Coupon Code *</Label><Input value={editCoupon.code || ''} onChange={(e: any) => setEditCoupon((p: any) => ({ ...p!, code: e.target.value.toUpperCase() }))} placeholder="SUMMER2024" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl font-mono uppercase" /></div>
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Description</Label><Input value={editCoupon.description || ''} onChange={(e: any) => setEditCoupon((p: any) => ({ ...p!, description: e.target.value }))} placeholder="Summer sale discount" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-white/40 text-[11px] mb-1.5 block">Discount Type</Label>
                  <Select value={editCoupon.discountType || 'PERCENTAGE'} onValueChange={(v: string) => setEditCoupon((p: any) => ({ ...p!, discountType: v }))}>
                    <SelectTrigger className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl h-10"><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-[#0c0c1a] border-white/[0.08]">
                      <SelectItem value="PERCENTAGE" className="text-white">Percentage (%)</SelectItem>
                      <SelectItem value="FIXED" className="text-white">Fixed Amount ($)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Value *</Label><Input type="number" value={editCoupon.discountValue || ''} onChange={(e: any) => setEditCoupon((p: any) => ({ ...p!, discountValue: parseFloat(e.target.value) || 0 }))} placeholder={editCoupon.discountType === 'PERCENTAGE' ? '10' : '5.00'} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Min Order ($)</Label><Input type="number" value={editCoupon.minOrderAmount || ''} onChange={(e: any) => setEditCoupon((p: any) => ({ ...p!, minOrderAmount: parseFloat(e.target.value) || null }))} placeholder="Optional" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Max Uses</Label><Input type="number" value={editCoupon.maxUsage || ''} onChange={(e: any) => setEditCoupon((p: any) => ({ ...p!, maxUsage: parseInt(e.target.value) || null }))} placeholder="Unlimited" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              </div>
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Expiry Date</Label><Input type="date" value={editCoupon.expiresAt ? new Date(editCoupon.expiresAt).toISOString().split('T')[0] : ''} onChange={(e: any) => setEditCoupon((p: any) => ({ ...p!, expiresAt: e.target.value || null }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div className="flex gap-2 justify-end pt-2">
                <Button variant="ghost" onClick={() => setEditCoupon(null)} className="text-white/40 hover:text-white hover:bg-white/5 rounded-xl text-xs">Cancel</Button>
                <Button onClick={saveCoupon} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs"><Save className="h-3.5 w-3.5" />Create</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function FeatureTogglesSection({ features, toggleFeature }: any) {
  const categories = [...new Set(features.map((f: FeatureToggleItem) => f.category))] as string[]
  const catLabels: Record<string, { label: string; icon: any; color: string }> = {
    core: { label: 'Core Features', icon: Zap, color: 'text-blue-400' },
    payments: { label: 'Payments & Wallet', icon: CreditCard, color: 'text-emerald-400' },
    social: { label: 'Social & Communication', icon: MessageSquare, color: 'text-purple-400' },
    marketplace: { label: 'Marketplace', icon: ShoppingCart, color: 'text-cyan-400' },
    seller: { label: 'Seller System', icon: UserCheck, color: 'text-amber-400' },
    services: { label: 'Services', icon: Server, color: 'text-pink-400' },
    marketing: { label: 'Marketing', icon: Megaphone, color: 'text-orange-400' },
    moderation: { label: 'Moderation', icon: Shield, color: 'text-red-400' },
    general: { label: 'General', icon: Settings, color: 'text-white/40' },
  }

  const enabledCount = features.filter((f: FeatureToggleItem) => f.isEnabled).length
  const totalCount = features.length

  return (
    <div>
      <SectionHeader title="Feature Toggles" description={`${enabledCount}/${totalCount} features enabled · Turn features on/off instantly`} />
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        <SectionCard className="p-3 text-center"><p className="text-2xl font-bold text-emerald-400">{enabledCount}</p><p className="text-[10px] text-white/30">Enabled</p></SectionCard>
        <SectionCard className="p-3 text-center"><p className="text-2xl font-bold text-red-400">{totalCount - enabledCount}</p><p className="text-[10px] text-white/30">Disabled</p></SectionCard>
        <SectionCard className="p-3 text-center"><p className="text-2xl font-bold text-purple-400">{categories.length}</p><p className="text-[10px] text-white/30">Categories</p></SectionCard>
        <SectionCard className="p-3 text-center"><p className="text-2xl font-bold text-blue-400">{totalCount}</p><p className="text-[10px] text-white/30">Total</p></SectionCard>
      </div>
      <div className="space-y-4">
        {categories.map((cat: string) => {
          const catInfo = catLabels[cat] || catLabels.general
          const CatIcon = catInfo.icon
          const catFeatures = features.filter((f: FeatureToggleItem) => f.category === cat)
          return (
            <SectionCard key={cat} className="overflow-hidden">
              <div className="px-4 py-3 border-b border-white/[0.04] flex items-center gap-2.5">
                <CatIcon className={`w-4 h-4 ${catInfo.color}`} />
                <span className="text-xs font-semibold text-white">{catInfo.label}</span>
                <span className="text-[10px] text-white/20 ml-auto">{catFeatures.filter((f: FeatureToggleItem) => f.isEnabled).length}/{catFeatures.length}</span>
              </div>
              <div className="divide-y divide-white/[0.04]">
                {catFeatures.map((feature: FeatureToggleItem) => (
                  <div key={feature.id} className="flex items-center justify-between px-4 py-3 hover:bg-white/[0.02] transition-colors">
                    <div className="flex-1 min-w-0 mr-4">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-white">{feature.featureName}</span>
                        {!feature.isEnabled && <Badge className="text-[8px] h-4 bg-red-500/10 text-red-400 border-red-500/20">OFF</Badge>}
                      </div>
                      {feature.description && <p className="text-[10px] text-white/25 mt-0.5">{feature.description}</p>}
                    </div>
                    <Switch checked={feature.isEnabled} onCheckedChange={(v: boolean) => toggleFeature(feature.id, v)} />
                  </div>
                ))}
              </div>
            </SectionCard>
          )
        })}
      </div>
    </div>
  )
}

function CampaignsSection({ campaigns, editCampaign, setEditCampaign, saveCampaign, deleteCampaign }: any) {
  const now = new Date()
  const activeCampaigns = campaigns.filter((c: any) => c.isActive && new Date(c.endDate) > now)
  return (
    <div>
      <SectionHeader title="Campaigns" description={`${activeCampaigns.length} active campaigns · Run seasonal sales and promotions`} />
      <div className="flex justify-end mb-4">
        <Button onClick={() => setEditCampaign({ name: '', description: '', discountPercent: 10, startDate: new Date().toISOString().split('T')[0], endDate: '', bannerText: '', isActive: true })} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs"><Plus className="h-3.5 w-3.5" />Create Campaign</Button>
      </div>
      <div className="grid gap-3">
        {campaigns.length === 0 && <SectionCard className="p-8 text-center"><CalendarDays className="w-8 h-8 text-white/10 mx-auto mb-2" /><p className="text-white/30 text-sm">No campaigns yet</p></SectionCard>}
        {campaigns.map((c: any) => {
          const isExpired = new Date(c.endDate) < now
          return (
            <SectionCard key={c.id} className="p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <CalendarDays className="w-4 h-4 text-purple-400" />
                  <span className="text-sm font-semibold text-white">{c.name}</span>
                  <Badge className={`text-[9px] h-4 ${c.isActive && !isExpired ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20'}`}>{isExpired ? 'Expired' : c.isActive ? 'Active' : 'Inactive'}</Badge>
                </div>
                <div className="flex gap-1">
                  <Button variant="ghost" size="sm" onClick={() => setEditCampaign({ ...c, startDate: new Date(c.startDate).toISOString().split('T')[0], endDate: new Date(c.endDate).toISOString().split('T')[0] })} className="h-7 w-7 p-0 text-white/30 hover:text-white"><Edit className="h-3 w-3" /></Button>
                  <Button variant="ghost" size="sm" onClick={() => deleteCampaign(c.id)} className="h-7 w-7 p-0 text-white/30 hover:text-red-400"><Trash2 className="h-3 w-3" /></Button>
                </div>
              </div>
              {c.description && <p className="text-xs text-white/40 mb-2">{c.description}</p>}
              <div className="flex gap-3 text-[10px] text-white/30">
                <span className="flex items-center gap-1"><Tag className="w-3 h-3" />{c.discountPercent}% off</span>
                <span>{new Date(c.startDate).toLocaleDateString()} — {new Date(c.endDate).toLocaleDateString()}</span>
                {c.bannerText && <span className="text-purple-400/60">{c.bannerText}</span>}
              </div>
            </SectionCard>
          )
        })}
      </div>
      <Dialog open={!!editCampaign} onOpenChange={() => setEditCampaign(null)}>
        <DialogContent className="bg-[#0c0c1a] border-white/[0.08] text-white max-w-md">
          <DialogHeader><DialogTitle className="text-white text-base">{editCampaign?.id ? 'Edit Campaign' : 'Create Campaign'}</DialogTitle><DialogDescription className="text-white/30 text-xs">Set up a promotional campaign</DialogDescription></DialogHeader>
          {editCampaign && (
            <div className="space-y-3">
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Name *</Label><Input value={editCampaign.name || ''} onChange={(e: any) => setEditCampaign((p: any) => ({ ...p, name: e.target.value }))} placeholder="Black Friday Sale" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Description</Label><Textarea value={editCampaign.description || ''} onChange={(e: any) => setEditCampaign((p: any) => ({ ...p, description: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl min-h-[60px]" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Discount %</Label><Input type="number" value={editCampaign.discountPercent || ''} onChange={(e: any) => setEditCampaign((p: any) => ({ ...p, discountPercent: parseFloat(e.target.value) || 0 }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Banner Text</Label><Input value={editCampaign.bannerText || ''} onChange={(e: any) => setEditCampaign((p: any) => ({ ...p, bannerText: e.target.value }))} placeholder="🔥 50% OFF" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Start Date *</Label><Input type="date" value={editCampaign.startDate || ''} onChange={(e: any) => setEditCampaign((p: any) => ({ ...p, startDate: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">End Date *</Label><Input type="date" value={editCampaign.endDate || ''} onChange={(e: any) => setEditCampaign((p: any) => ({ ...p, endDate: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              </div>
              <div className="flex items-center gap-2"><Switch checked={editCampaign.isActive ?? true} onCheckedChange={(v: boolean) => setEditCampaign((p: any) => ({ ...p, isActive: v }))} /><Label className="text-white/40 text-xs">Active</Label></div>
              <div className="flex gap-2 justify-end pt-2">
                <Button variant="ghost" onClick={() => setEditCampaign(null)} className="text-white/40 hover:text-white hover:bg-white/5 rounded-xl text-xs">Cancel</Button>
                <Button onClick={saveCampaign} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs"><Save className="h-3.5 w-3.5" />{editCampaign.id ? 'Update' : 'Create'}</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function BadgesSection({ badges, editBadge, setEditBadge, saveBadge, deleteBadge }: any) {
  return (
    <div>
      <SectionHeader title="Badges" description={`${badges.length} badges · Create and manage achievement badges`} />
      <div className="flex justify-end mb-4">
        <Button onClick={() => setEditBadge({ name: '', description: '', icon: '⭐', color: '#8B5CF6', isAutomatic: false, isActive: true })} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs"><Plus className="h-3.5 w-3.5" />Create Badge</Button>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {badges.length === 0 && <SectionCard className="p-8 text-center col-span-full"><Award className="w-8 h-8 text-white/10 mx-auto mb-2" /><p className="text-white/30 text-sm">No badges yet</p></SectionCard>}
        {badges.map((b: any) => (
          <SectionCard key={b.id} className="p-4">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl" style={{ backgroundColor: b.color + '20', color: b.color }}>{b.icon || '⭐'}</div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-white truncate">{b.name}</p>
                <div className="flex gap-1">
                  {b.isAutomatic && <Badge className="text-[8px] h-4 bg-blue-500/10 text-blue-400 border-blue-500/20">Auto</Badge>}
                  <Badge className={`text-[8px] h-4 ${b.isActive ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-red-500/10 text-red-400 border-red-500/20'}`}>{b.isActive ? 'Active' : 'Inactive'}</Badge>
                </div>
              </div>
              <div className="flex gap-1">
                <Button variant="ghost" size="sm" onClick={() => setEditBadge({ ...b })} className="h-7 w-7 p-0 text-white/30 hover:text-white"><Edit className="h-3 w-3" /></Button>
                <Button variant="ghost" size="sm" onClick={() => deleteBadge(b.id)} className="h-7 w-7 p-0 text-white/30 hover:text-red-400"><Trash2 className="h-3 w-3" /></Button>
              </div>
            </div>
            {b.description && <p className="text-[10px] text-white/30">{b.description}</p>}
            {b.criteria && <p className="text-[10px] text-purple-400/60 mt-1">Criteria: {b.criteria}</p>}
          </SectionCard>
        ))}
      </div>
      <Dialog open={!!editBadge} onOpenChange={() => setEditBadge(null)}>
        <DialogContent className="bg-[#0c0c1a] border-white/[0.08] text-white max-w-md">
          <DialogHeader><DialogTitle className="text-white text-base">{editBadge?.id ? 'Edit Badge' : 'Create Badge'}</DialogTitle><DialogDescription className="text-white/30 text-xs">Manage achievement badges</DialogDescription></DialogHeader>
          {editBadge && (
            <div className="space-y-3">
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Name *</Label><Input value={editBadge.name || ''} onChange={(e: any) => setEditBadge((p: any) => ({ ...p, name: e.target.value }))} placeholder="Top Seller" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Description</Label><Input value={editBadge.description || ''} onChange={(e: any) => setEditBadge((p: any) => ({ ...p, description: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Icon (emoji)</Label><Input value={editBadge.icon || ''} onChange={(e: any) => setEditBadge((p: any) => ({ ...p, icon: e.target.value }))} placeholder="⭐" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Color</Label><Input type="color" value={editBadge.color || '#8B5CF6'} onChange={(e: any) => setEditBadge((p: any) => ({ ...p, color: e.target.value }))} className="bg-white/[0.04] border-white/[0.08] rounded-xl h-10 w-full" /></div>
              </div>
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Criteria</Label><Input value={editBadge.criteria || ''} onChange={(e: any) => setEditBadge((p: any) => ({ ...p, criteria: e.target.value }))} placeholder="Sell 100 items" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2"><Switch checked={editBadge.isAutomatic ?? false} onCheckedChange={(v: boolean) => setEditBadge((p: any) => ({ ...p, isAutomatic: v }))} /><Label className="text-white/40 text-xs">Auto-assign</Label></div>
                <div className="flex items-center gap-2"><Switch checked={editBadge.isActive ?? true} onCheckedChange={(v: boolean) => setEditBadge((p: any) => ({ ...p, isActive: v }))} /><Label className="text-white/40 text-xs">Active</Label></div>
              </div>
              <div className="flex gap-2 justify-end pt-2">
                <Button variant="ghost" onClick={() => setEditBadge(null)} className="text-white/40 hover:text-white hover:bg-white/5 rounded-xl text-xs">Cancel</Button>
                <Button onClick={saveBadge} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs"><Save className="h-3.5 w-3.5" />{editBadge.id ? 'Update' : 'Create'}</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function ReferralsSection({ stats }: any) {
  return (
    <div>
      <SectionHeader title="Referrals" description="Track referral program performance and top referrers" />
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-6">
        <SectionCard className="p-4 text-center"><Share2 className="w-5 h-5 text-purple-400 mx-auto mb-1" /><p className="text-2xl font-bold text-white">{stats.totalReferrals || 0}</p><p className="text-[10px] text-white/30">Total Referrals</p></SectionCard>
        <SectionCard className="p-4 text-center"><DollarSign className="w-5 h-5 text-emerald-400 mx-auto mb-1" /><p className="text-2xl font-bold text-white">${(stats.totalEarnings || 0).toFixed(2)}</p><p className="text-[10px] text-white/30">Total Earnings Paid</p></SectionCard>
        <SectionCard className="p-4 text-center"><Users className="w-5 h-5 text-blue-400 mx-auto mb-1" /><p className="text-2xl font-bold text-white">{(stats.topReferrers || []).length}</p><p className="text-[10px] text-white/30">Active Referrers</p></SectionCard>
      </div>
      <div className="grid lg:grid-cols-2 gap-4">
        <div>
          <h3 className="text-xs font-semibold text-white/60 mb-3 flex items-center gap-2"><Trophy className="w-3.5 h-3.5" />Top Referrers</h3>
          <SectionCard className="divide-y divide-white/[0.04]">
            {(stats.topReferrers || []).length === 0 && <div className="p-6 text-center text-white/20 text-xs">No referrers yet</div>}
            {(stats.topReferrers || []).map((r: any, i: number) => (
              <div key={r.id} className="flex items-center gap-3 px-4 py-3">
                <span className="text-xs font-bold text-white/20 w-5">#{i + 1}</span>
                <Avatar className="h-7 w-7"><AvatarImage src={r.avatar} /><AvatarFallback className="bg-purple-600/20 text-purple-400 text-[10px]">{r.username?.[0]?.toUpperCase()}</AvatarFallback></Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-white truncate">{r.username}</p>
                  <p className="text-[10px] text-white/30">{r._count?.referrals || 0} referrals · Code: {r.referralCode}</p>
                </div>
                <span className="text-xs font-semibold text-emerald-400">${(r.referralEarnings || 0).toFixed(2)}</span>
              </div>
            ))}
          </SectionCard>
        </div>
        <div>
          <h3 className="text-xs font-semibold text-white/60 mb-3 flex items-center gap-2"><Clock className="w-3.5 h-3.5" />Recent Referrals</h3>
          <SectionCard className="divide-y divide-white/[0.04]">
            {(stats.recentReferrals || []).length === 0 && <div className="p-6 text-center text-white/20 text-xs">No referrals yet</div>}
            {(stats.recentReferrals || []).map((r: any) => (
              <div key={r.id} className="flex items-center gap-3 px-4 py-3">
                <Avatar className="h-7 w-7"><AvatarImage src={r.avatar} /><AvatarFallback className="bg-blue-600/20 text-blue-400 text-[10px]">{r.username?.[0]?.toUpperCase()}</AvatarFallback></Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-white truncate">{r.username}</p>
                  <p className="text-[10px] text-white/30">Referred by {r.referredBy?.username || 'unknown'}</p>
                </div>
                <span className="text-[10px] text-white/20">{new Date(r.createdAt).toLocaleDateString()}</span>
              </div>
            ))}
          </SectionCard>
        </div>
      </div>
    </div>
  )
}

function LeaderboardSection({ data }: any) {
  return (
    <div>
      <SectionHeader title="Leaderboard" description="Top sellers, buyers, and items by performance" />
      <div className="grid lg:grid-cols-3 gap-4">
        <div>
          <h3 className="text-xs font-semibold text-white/60 mb-3 flex items-center gap-2"><Trophy className="w-3.5 h-3.5 text-amber-400" />Top Sellers</h3>
          <SectionCard className="divide-y divide-white/[0.04]">
            {(data.topSellers || []).length === 0 && <div className="p-6 text-center text-white/20 text-xs">No data</div>}
            {(data.topSellers || []).map((s: any, i: number) => (
              <div key={s.id} className="flex items-center gap-3 px-4 py-3">
                <span className={`text-xs font-bold w-5 ${i === 0 ? 'text-amber-400' : i === 1 ? 'text-zinc-300' : i === 2 ? 'text-amber-700' : 'text-white/20'}`}>#{i + 1}</span>
                <Avatar className="h-7 w-7"><AvatarImage src={s.avatar} /><AvatarFallback className="bg-amber-600/20 text-amber-400 text-[10px]">{s.username?.[0]?.toUpperCase()}</AvatarFallback></Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-white truncate">{s.username}</p>
                  <p className="text-[10px] text-white/30">{s._count?.items || 0} items</p>
                </div>
                <span className="text-xs font-semibold text-emerald-400">{s.totalSales} sales</span>
              </div>
            ))}
          </SectionCard>
        </div>
        <div>
          <h3 className="text-xs font-semibold text-white/60 mb-3 flex items-center gap-2"><Download className="w-3.5 h-3.5 text-blue-400" />Top Buyers</h3>
          <SectionCard className="divide-y divide-white/[0.04]">
            {(data.topBuyers || []).length === 0 && <div className="p-6 text-center text-white/20 text-xs">No data</div>}
            {(data.topBuyers || []).map((b: any, i: number) => (
              <div key={b.id} className="flex items-center gap-3 px-4 py-3">
                <span className={`text-xs font-bold w-5 ${i < 3 ? 'text-blue-400' : 'text-white/20'}`}>#{i + 1}</span>
                <Avatar className="h-7 w-7"><AvatarImage src={b.avatar} /><AvatarFallback className="bg-blue-600/20 text-blue-400 text-[10px]">{b.username?.[0]?.toUpperCase()}</AvatarFallback></Avatar>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-white truncate">{b.username}</p>
                </div>
                <span className="text-xs text-white/40">{b._count?.downloadRecords || 0} downloads</span>
              </div>
            ))}
          </SectionCard>
        </div>
        <div>
          <h3 className="text-xs font-semibold text-white/60 mb-3 flex items-center gap-2"><Star className="w-3.5 h-3.5 text-purple-400" />Top Items</h3>
          <SectionCard className="divide-y divide-white/[0.04]">
            {(data.topItems || []).length === 0 && <div className="p-6 text-center text-white/20 text-xs">No data</div>}
            {(data.topItems || []).map((item: any, i: number) => (
              <div key={item.id} className="flex items-center gap-3 px-4 py-3">
                <span className={`text-xs font-bold w-5 ${i < 3 ? 'text-purple-400' : 'text-white/20'}`}>#{i + 1}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-medium text-white truncate">{item.title}</p>
                  <p className="text-[10px] text-white/30">by {item.author?.username} · {item.downloads} DLs · {item.views} views</p>
                </div>
                <span className="text-xs font-semibold text-emerald-400">{item.price > 0 ? `$${item.price}` : 'Free'}</span>
              </div>
            ))}
          </SectionCard>
        </div>
      </div>
    </div>
  )
}

function MysteryRewardsSection({ rewards, logs, editReward, setEditReward, saveReward, deleteReward }: any) {
  return (
    <div>
      <SectionHeader title="Mystery Rewards" description={`${rewards.length} reward types · Random rewards after purchases`} />
      <div className="flex justify-end mb-4">
        <Button onClick={() => setEditReward({ name: '', type: 'COINS', value: 1, probability: 0.1, isActive: true })} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs"><Plus className="h-3.5 w-3.5" />Add Reward</Button>
      </div>
      <div className="grid gap-3 mb-6">
        {rewards.length === 0 && <SectionCard className="p-8 text-center"><Gift className="w-8 h-8 text-white/10 mx-auto mb-2" /><p className="text-white/30 text-sm">No rewards configured</p></SectionCard>}
        {rewards.map((r: any) => (
          <SectionCard key={r.id} className="p-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-amber-500/20 to-purple-500/20 flex items-center justify-center"><Gift className="w-5 h-5 text-amber-400" /></div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-white">{r.name}</p>
                <div className="flex gap-2 text-[10px] text-white/30">
                  <span>Type: {r.type}</span>
                  <span>Value: {r.type === 'COINS' ? `$${r.value}` : `${r.value}%`}</span>
                  <span>Chance: {(r.probability * 100).toFixed(0)}%</span>
                </div>
              </div>
              <Badge className={`text-[9px] h-4 ${r.isActive ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-red-500/10 text-red-400 border-red-500/20'}`}>{r.isActive ? 'Active' : 'Off'}</Badge>
              <Button variant="ghost" size="sm" onClick={() => setEditReward({ ...r })} className="h-7 w-7 p-0 text-white/30 hover:text-white"><Edit className="h-3 w-3" /></Button>
              <Button variant="ghost" size="sm" onClick={() => deleteReward(r.id)} className="h-7 w-7 p-0 text-white/30 hover:text-red-400"><Trash2 className="h-3 w-3" /></Button>
            </div>
          </SectionCard>
        ))}
      </div>
      {logs.length > 0 && (
        <div>
          <h3 className="text-xs font-semibold text-white/60 mb-3">Recent Reward Logs</h3>
          <SectionCard className="divide-y divide-white/[0.04]">
            {logs.map((l: any) => (
              <div key={l.id} className="flex items-center gap-3 px-4 py-2.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <div className="flex-1"><p className="text-xs text-white/60">User won {l.type === 'COINS' ? `$${l.value}` : `${l.value}% discount`}</p></div>
                <span className="text-[10px] text-white/20">{new Date(l.createdAt).toLocaleDateString()}</span>
              </div>
            ))}
          </SectionCard>
        </div>
      )}
      <Dialog open={!!editReward} onOpenChange={() => setEditReward(null)}>
        <DialogContent className="bg-[#0c0c1a] border-white/[0.08] text-white max-w-md">
          <DialogHeader><DialogTitle className="text-white text-base">{editReward?.id ? 'Edit Reward' : 'Add Reward'}</DialogTitle><DialogDescription className="text-white/30 text-xs">Configure mystery reward</DialogDescription></DialogHeader>
          {editReward && (
            <div className="space-y-3">
              <div><Label className="text-white/40 text-[11px] mb-1.5 block">Name *</Label><Input value={editReward.name || ''} onChange={(e: any) => setEditReward((p: any) => ({ ...p, name: e.target.value }))} placeholder="Lucky Coins" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <Label className="text-white/40 text-[11px] mb-1.5 block">Type</Label>
                  <Select value={editReward.type || 'COINS'} onValueChange={(v: string) => setEditReward((p: any) => ({ ...p, type: v }))}>
                    <SelectTrigger className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl h-10"><SelectValue /></SelectTrigger>
                    <SelectContent className="bg-[#0c0c1a] border-white/[0.08]">
                      <SelectItem value="COINS" className="text-white">Coins</SelectItem>
                      <SelectItem value="DISCOUNT" className="text-white">Discount %</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Value</Label><Input type="number" step="0.01" value={editReward.value || ''} onChange={(e: any) => setEditReward((p: any) => ({ ...p, value: parseFloat(e.target.value) || 0 }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
                <div><Label className="text-white/40 text-[11px] mb-1.5 block">Chance (0-1)</Label><Input type="number" step="0.01" min="0" max="1" value={editReward.probability || ''} onChange={(e: any) => setEditReward((p: any) => ({ ...p, probability: parseFloat(e.target.value) || 0 }))} className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" /></div>
              </div>
              <div className="flex items-center gap-2"><Switch checked={editReward.isActive ?? true} onCheckedChange={(v: boolean) => setEditReward((p: any) => ({ ...p, isActive: v }))} /><Label className="text-white/40 text-xs">Active</Label></div>
              <div className="flex gap-2 justify-end pt-2">
                <Button variant="ghost" onClick={() => setEditReward(null)} className="text-white/40 hover:text-white hover:bg-white/5 rounded-xl text-xs">Cancel</Button>
                <Button onClick={saveReward} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-1.5 text-xs"><Save className="h-3.5 w-3.5" />{editReward.id ? 'Update' : 'Create'}</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}

function TeamsSection({ teams }: any) {
  return (
    <div>
      <SectionHeader title="Teams" description={`${teams.length} teams · Manage seller team accounts`} />
      <div className="grid gap-3">
        {teams.length === 0 && <SectionCard className="p-8 text-center"><Users2 className="w-8 h-8 text-white/10 mx-auto mb-2" /><p className="text-white/30 text-sm">No teams created yet</p></SectionCard>}
        {teams.map((t: any) => (
          <SectionCard key={t.id} className="p-4">
            <div className="flex items-center gap-3 mb-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500/20 to-purple-500/20 flex items-center justify-center"><Users2 className="w-5 h-5 text-blue-400" /></div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-white">{t.name}</p>
                <p className="text-[10px] text-white/30">Owner: {t.owner?.username || 'Unknown'} · {t.members?.length || 0} members</p>
              </div>
              <span className="text-[10px] text-white/20">{new Date(t.createdAt).toLocaleDateString()}</span>
            </div>
            {t.description && <p className="text-xs text-white/40 mb-2">{t.description}</p>}
            <div className="flex flex-wrap gap-2">
              {(t.members || []).map((m: any) => (
                <div key={m.id} className="flex items-center gap-1.5 bg-white/[0.03] rounded-lg px-2 py-1">
                  <Avatar className="h-5 w-5"><AvatarImage src={m.user?.avatar} /><AvatarFallback className="bg-purple-600/20 text-purple-400 text-[8px]">{m.user?.username?.[0]?.toUpperCase()}</AvatarFallback></Avatar>
                  <span className="text-[10px] text-white/60">{m.user?.username}</span>
                  <Badge className="text-[7px] h-3.5 bg-white/[0.04] text-white/30 border-white/[0.06]">{m.role}</Badge>
                </div>
              ))}
            </div>
          </SectionCard>
        ))}
      </div>
    </div>
  )
}

function CollaborationsSection({ collaborations }: any) {
  return (
    <div>
      <SectionHeader title="Collaborations" description={`${collaborations.length} collaborations · Track item revenue sharing`} />
      <SectionCard className="overflow-hidden">
        {collaborations.length === 0 && <div className="p-8 text-center"><Handshake className="w-8 h-8 text-white/10 mx-auto mb-2" /><p className="text-white/30 text-sm">No collaborations yet</p></div>}
        <div className="divide-y divide-white/[0.04]">
          {collaborations.map((c: any) => (
            <div key={c.id} className="flex items-center gap-3 px-4 py-3 hover:bg-white/[0.02] transition-colors">
              <Handshake className="w-4 h-4 text-purple-400 flex-shrink-0" />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-white truncate">{c.item?.title || 'Unknown Item'}</p>
                <p className="text-[10px] text-white/30">Collaborator: {c.user?.username || 'Unknown'} · Revenue share: {c.revenueShare}%</p>
              </div>
              <Badge className={`text-[9px] h-4 ${c.status === 'APPROVED' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : c.status === 'PENDING' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' : 'bg-red-500/10 text-red-400 border-red-500/20'}`}>{c.status}</Badge>
              <span className="text-[10px] text-white/20">{new Date(c.createdAt).toLocaleDateString()}</span>
            </div>
          ))}
        </div>
      </SectionCard>
    </div>
  )
}

// ─── AI Providers Section ─────────────────────────────────────────────────
const ALL_PROVIDERS = [
  { slug: 'openai', name: 'OpenAI', description: 'GPT-4o, GPT-4, DALL-E 3, Whisper, TTS', logoUrl: '🟢', isFree: false, apiBase: 'https://api.openai.com/v1', models: ['gpt-4o', 'gpt-4o-mini', 'gpt-4-turbo', 'gpt-3.5-turbo', 'dall-e-3', 'dall-e-2', 'tts-1', 'whisper-1'], features: ['chat', 'image', 'voice', 'transcription'] },
  { slug: 'anthropic', name: 'Anthropic', description: 'Claude 3.5 Sonnet, Claude 3 Opus, Haiku', logoUrl: '🔴', isFree: false, apiBase: 'https://api.anthropic.com/v1', models: ['claude-3-5-sonnet-20241022', 'claude-3-opus-20240229', 'claude-3-haiku-20240307', 'claude-3-sonnet-20240229'], features: ['chat'] },
  { slug: 'google', name: 'Google Gemini', description: 'Gemini 1.5 Pro, Flash, Vision', logoUrl: '🔵', isFree: false, apiBase: 'https://generativelanguage.googleapis.com/v1beta/openai', models: ['gemini-1.5-pro', 'gemini-1.5-flash', 'gemini-1.0-pro', 'gemini-pro-vision'], features: ['chat', 'image', 'video'] },
  { slug: 'groq', name: 'Groq', description: 'Ultra-fast LLM inference — Llama, Mixtral', logoUrl: '⚡', isFree: false, models: ['llama-3.1-70b-versatile', 'llama-3.1-8b-instant', 'mixtral-8x7b-32768', 'gemma2-9b-it'], features: ['chat'] },
  { slug: 'mistral', name: 'Mistral AI', description: 'Mistral Large, Small, Codestral', logoUrl: '🌊', isFree: false, models: ['mistral-large-latest', 'mistral-small-latest', 'codestral-latest', 'open-mistral-7b'], features: ['chat', 'code'] },
  { slug: 'together', name: 'Together AI', description: 'Open-source models — Llama, Falcon, Qwen', logoUrl: '🤝', isFree: false, models: ['meta-llama/Meta-Llama-3.1-70B-Instruct-Turbo', 'meta-llama/Meta-Llama-3.1-8B-Instruct-Turbo', 'Qwen/Qwen2.5-72B-Instruct-Turbo'], features: ['chat', 'image'] },
  { slug: 'huggingface', name: 'Hugging Face', description: 'Thousands of open-source models', logoUrl: '🤗', isFree: true, models: ['meta-llama/Meta-Llama-3-8B-Instruct', 'mistralai/Mistral-7B-Instruct-v0.2', 'stabilityai/stable-diffusion-xl-base-1.0'], features: ['chat', 'image'] },
  { slug: 'cohere', name: 'Cohere', description: 'Command R+, Command R for enterprise', logoUrl: '🟠', isFree: false, models: ['command-r-plus', 'command-r', 'command', 'embed-english-v3.0'], features: ['chat'] },
  { slug: 'stability', name: 'Stability AI', description: 'Stable Diffusion, SDXL, SD3', logoUrl: '🎨', isFree: false, models: ['stable-diffusion-3-large', 'stable-image/core', 'stable-image/ultra'], features: ['image'] },
  { slug: 'replicate', name: 'Replicate', description: 'Run any open-source model in the cloud', logoUrl: '🔮', isFree: false, models: ['flux-1.1-pro', 'flux-dev', 'flux-schnell', 'stable-diffusion-3'], features: ['image', 'video'] },
  { slug: 'fal', name: 'fal.ai', description: 'Fast video & image generation', logoUrl: '🚀', isFree: false, models: ['fal-ai/flux/schnell', 'fal-ai/wan/v2.5/text-to-video', 'fal-ai/minimax/video-01'], features: ['image', 'video'] },
  { slug: 'runway', name: 'RunwayML', description: 'Gen-3 Alpha video generation', logoUrl: '✈️', isFree: false, models: ['gen3a_turbo', 'gen-3a'], features: ['video'] },
  { slug: 'luma', name: 'Luma AI', description: 'Dream Machine video generation', logoUrl: '💡', isFree: false, models: ['dream-machine'], features: ['video'] },
  { slug: 'deepseek', name: 'DeepSeek', description: 'DeepSeek R1 — reasoning model', logoUrl: '🔍', isFree: false, models: ['deepseek-reasoner', 'deepseek-chat', 'deepseek-coder'], features: ['chat', 'code'] },
  { slug: 'perplexity', name: 'Perplexity', description: 'Web-connected AI search', logoUrl: '🌐', isFree: false, models: ['llama-3.1-sonar-large-128k-online', 'llama-3.1-sonar-small-128k-online'], features: ['chat'] },
  { slug: 'xai', name: 'xAI Grok', description: 'Grok-2 — Elon Musk\'s AI', logoUrl: '❌', isFree: false, apiBase: 'https://api.x.ai/v1', models: ['grok-2', 'grok-2-mini', 'grok-beta'], features: ['chat', 'image'] },
  { slug: 'openrouter', name: 'OpenRouter', description: 'Aggregator — 100+ models via single API', logoUrl: '🔀', isFree: false, apiBase: 'https://openrouter.ai/api/v1', models: ['openai/gpt-4o', 'anthropic/claude-3.5-sonnet', 'google/gemini-flash-1.5', 'meta-llama/llama-3.1-405b'], features: ['chat', 'image'] },
  { slug: 'zai', name: 'Z.ai', description: 'Z.ai official API — direct OpenAI-compatible endpoint for z-ai/glm models', logoUrl: '🟣', isFree: false, apiBase: 'https://api.z.ai/v1', models: ['z-ai/glm-4.5', 'z-ai/glm-5.1'], features: ['chat'] },
  { slug: 'elevenlabs', name: 'ElevenLabs', description: 'Realistic voice synthesis & cloning', logoUrl: '🎙️', isFree: false, models: ['eleven_multilingual_v2', 'eleven_turbo_v2', 'eleven_monolingual_v1'], features: ['voice'] },
  { slug: 'deepgram', name: 'Deepgram', description: 'Speech-to-text transcription', logoUrl: '🎤', isFree: false, models: ['nova-2', 'nova-2-meeting', 'nova-2-general'], features: ['transcription'] },
  { slug: 'pollinations', name: 'Pollinations AI', description: '100% free image & text generation — no key needed', logoUrl: '🌸', isFree: true, models: ['flux', 'turbo', 'flux-realism'], features: ['image', 'chat'] },
  { slug: 'deepinfra', name: 'DeepInfra', description: 'Affordable GPU inference for open models', logoUrl: '🖥️', isFree: false, models: ['meta-llama/Meta-Llama-3.1-70B-Instruct', 'mistralai/Mistral-7B-Instruct-v0.3'], features: ['chat', 'image'] },
  { slug: 'fireworks', name: 'Fireworks AI', description: 'Fast open-source model inference', logoUrl: '🎆', isFree: false, models: ['accounts/fireworks/models/llama-v3p1-70b-instruct', 'accounts/fireworks/models/mixtral-8x7b-instruct'], features: ['chat'] },
  { slug: 'nvidia', name: 'NVIDIA NIM', description: 'Nemotron, Llama via NVIDIA cloud', logoUrl: '🟩', isFree: false, models: ['nvidia/llama-3.1-nemotron-70b-instruct', 'meta/llama-3.1-70b-instruct'], features: ['chat'] },
]

function AiProvidersSection() {
  const [providers, setProviders] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState<string | null>(null)
  const [filter, setFilter] = useState<'all' | 'enabled' | 'free'>('all')
  const [editingKey, setEditingKey] = useState<Record<string, string>>({})
  const [customName, setCustomName] = useState('')
  const [customSlug, setCustomSlug] = useState('')
  const [customDescription, setCustomDescription] = useState('')
  const [customApiKey, setCustomApiKey] = useState('')
  const [customApiBase, setCustomApiBase] = useState('')
  const [customModel, setCustomModel] = useState('gpt-4o-mini')
  const [customFeatures, setCustomFeatures] = useState('chat')
  const [customIsFree, setCustomIsFree] = useState(false)
  const [customPriority, setCustomPriority] = useState('0')

  useEffect(() => { load() }, [])

  async function load() {
    setLoading(true)
    try {
      const r = await fetch('/api/admin/ai-providers')
      if (r.ok) { const d = await r.json(); setProviders(d.providers || []) }
    } finally { setLoading(false) }
  }

  async function upsertProvider(pDef: any, apiKey?: string, enabled?: boolean) {
    setSaving(pDef.slug)
    try {
      const existing = providers.find(p => p.slug === pDef.slug)
      const r = await fetch('/api/admin/ai-providers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          slug: pDef.slug,
          name: pDef.name,
          description: pDef.description,
          apiKey: apiKey ?? existing?.apiKey ?? '',
          apiBase: pDef.apiBase || existing?.apiBase || '',
          models: pDef.models,
          features: pDef.features,
          enabled: enabled ?? existing?.enabled ?? true,
          isFree: pDef.isFree,
          priority: pDef.priority || 0,
          logoUrl: pDef.logoUrl
        })
      })
      if (r.ok) { toast.success(`${pDef.name} saved`); await load() }
      else { const e = await r.json(); toast.error(e.error || 'Failed') }
    } finally { setSaving(null) }
  }

  async function toggleEnabled(pDef: any, currentEnabled: boolean) {
    await upsertProvider(pDef, undefined, !currentEnabled)
  }

  async function deleteProvider(id: string) {
    if (!confirm('Remove this provider?')) return
    const r = await fetch(`/api/admin/ai-providers/${id}`, { method: 'DELETE' })
    if (r.ok) { toast.success('Removed'); load() }
  }

  async function createCustomProvider() {
    if (!customName.trim() || !customSlug.trim() || !customModel.trim()) {
      toast.error('Name, slug, and model are required')
      return
    }
    const slug = customSlug.trim().toLowerCase().replace(/[^a-z0-9\-]/g, '-')
    setSaving(slug)
    try {
      const r = await fetch('/api/admin/ai-providers', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          slug,
          name: customName.trim(),
          description: customDescription.trim(),
          apiKey: customApiKey.trim(),
          apiBase: customApiBase.trim(),
          models: [customModel.trim()],
          features: customFeatures.split(',').map(f => f.trim()).filter(Boolean),
          enabled: true,
          isFree: customIsFree,
          priority: Number(customPriority) || 0,
          logoUrl: ''
        })
      })
      if (r.ok) {
        toast.success('Custom provider created')
        setCustomName('')
        setCustomSlug('')
        setCustomDescription('')
        setCustomApiKey('')
        setCustomApiBase('')
        setCustomModel('gpt-4o-mini')
        setCustomFeatures('chat')
        setCustomIsFree(false)
        setCustomPriority('0')
        await load()
      } else {
        const e = await r.json()
        toast.error(e.error || 'Failed to create provider')
      }
    } finally {
      setSaving(null)
    }
  }

  const filtered = ALL_PROVIDERS.filter(p => {
    if (filter === 'enabled') return providers.some(db => db.slug === p.slug && db.enabled)
    if (filter === 'free') return p.isFree
    return true
  })

  const customProviders = providers.filter(p => !ALL_PROVIDERS.some(def => def.slug === p.slug))

  return (
    <div>
      <SectionHeader
        title="AI Provider Management"
        description="Configure API keys for all world AI providers. Manage which models are active across AI features."
        action={
          <div className="flex gap-2">
            {(['all', 'enabled', 'free'] as const).map(f => (
              <button key={f} onClick={() => setFilter(f)}
                className={`text-[11px] px-3 py-1.5 rounded-lg font-medium transition capitalize ${filter === f ? 'bg-purple-600 text-white' : 'bg-white/[0.04] text-white/40 hover:text-white/70'}`}>
                {f}
              </button>
            ))}
          </div>
        }
      />
      <SectionCard className="mb-4 p-4 bg-slate-950/80 border-white/5">
        <div className="flex flex-col gap-3">
          <div>
            <p className="text-sm font-semibold text-white">Add a custom AI provider</p>
            <p className="text-xs text-white/50">Create your own OpenAI-compatible or custom provider entry, including Z.ai/OpenRouter and other external APIs.</p>
          </div>
          <div className="grid gap-2 sm:grid-cols-2">
            <Input value={customName} onChange={e => setCustomName(e.target.value)} placeholder="Provider name" />
            <Input value={customSlug} onChange={e => setCustomSlug(e.target.value)} placeholder="Slug (custom-provider)" />
            <Input value={customApiBase} onChange={e => setCustomApiBase(e.target.value)} placeholder="API base URL (https://api.example.com/v1)" />
            <Input value={customApiKey} onChange={e => setCustomApiKey(e.target.value)} placeholder="API key / token" type="password" />
            <Input value={customModel} onChange={e => setCustomModel(e.target.value)} placeholder="Default model (gpt-4o-mini)" />
            <Input value={customFeatures} onChange={e => setCustomFeatures(e.target.value)} placeholder="Features (chat,image,voice)" />
            <Input value={customPriority} onChange={e => setCustomPriority(e.target.value)} placeholder="Priority (0-100)" />
            <Input value={customDescription} onChange={e => setCustomDescription(e.target.value)} placeholder="Description" />
          </div>
          <div className="flex flex-wrap gap-2 items-center">
            <Button size="sm" onClick={createCustomProvider} disabled={!!saving} className="bg-violet-600 hover:bg-violet-500 text-white">
              {saving ? <Loader2 className="w-3 h-3 animate-spin" /> : 'Create custom provider'}
            </Button>
            <Switch checked={customIsFree} onCheckedChange={setCustomIsFree} />
            <span className="text-xs text-white/50">Mark this provider as free</span>
          </div>
        </div>
      </SectionCard>
      {loading ? (
        <div className="flex items-center justify-center py-20"><Loader2 className="w-6 h-6 animate-spin text-purple-400" /></div>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2">
          {filtered.map(pDef => {
            const dbProvider = providers.find(p => p.slug === pDef.slug)
            const isEnabled = dbProvider?.enabled ?? false
            const hasKey = !!(dbProvider?.apiKey)
            const isSaving = saving === pDef.slug
            return (
              <SectionCard key={pDef.slug} className="p-4">
                <div className="flex items-start gap-3 mb-3">
                  <div className="text-2xl flex-shrink-0">{pDef.logoUrl}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <p className="text-sm font-semibold text-white">{pDef.name}</p>
                      {pDef.isFree && <span className="text-[8px] px-1.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-semibold">FREE</span>}
                      {hasKey && <span className="text-[8px] px-1.5 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20 font-semibold">KEY SET</span>}
                    </div>
                    <p className="text-[11px] text-white/40">{pDef.description}</p>
                    <div className="flex flex-wrap gap-1 mt-1.5">
                      {pDef.features.map((f: string) => (
                        <span key={f} className="text-[9px] px-1.5 py-0.5 rounded bg-white/[0.04] text-white/30 border border-white/[0.06] capitalize">{f}</span>
                      ))}
                    </div>
                  </div>
                  <Switch checked={isEnabled} onCheckedChange={() => toggleEnabled(pDef, isEnabled)} disabled={isSaving} />
                </div>
                {!pDef.isFree && (
                  <div className="flex gap-2">
                    <Input
                      type="password"
                      placeholder={`${pDef.name} API key...`}
                      value={editingKey[pDef.slug] ?? dbProvider?.apiKey ?? ''}
                      onChange={e => setEditingKey(k => ({ ...k, [pDef.slug]: e.target.value }))}
                      className="flex-1 h-8 text-xs bg-white/[0.04] border-white/[0.08] text-white rounded-xl placeholder:text-white/20"
                    />
                    <Button size="sm" onClick={() => upsertProvider(pDef, editingKey[pDef.slug] ?? dbProvider?.apiKey ?? '')} disabled={isSaving}
                      className="h-8 px-3 text-xs bg-purple-600 hover:bg-purple-500 text-white rounded-xl">
                      {isSaving ? <Loader2 className="w-3 h-3 animate-spin" /> : <Save className="w-3 h-3" />}
                    </Button>
                    {dbProvider && <Button size="sm" variant="ghost" onClick={() => deleteProvider(dbProvider.id)} className="h-8 w-8 p-0 text-red-400/60 hover:text-red-400 hover:bg-red-500/10 rounded-xl"><X className="w-3 h-3" /></Button>}
                  </div>
                )}
                {pDef.isFree && !dbProvider && (
                  <Button size="sm" onClick={() => upsertProvider(pDef, '', true)} disabled={isSaving}
                    className="w-full h-8 text-xs bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-400 border border-emerald-500/20 rounded-xl">
                    {isSaving ? <Loader2 className="w-3 h-3 animate-spin" /> : <Plus className="w-3 h-3 mr-1" />}Enable Free Provider
                  </Button>
                )}
                <details className="mt-2">
                  <summary className="text-[10px] text-white/20 cursor-pointer hover:text-white/40">View {pDef.models.length} models</summary>
                  <div className="mt-1.5 flex flex-wrap gap-1">
                    {pDef.models.map((m: string) => (
                      <span key={m} className="text-[9px] px-1.5 py-0.5 rounded bg-white/[0.03] text-white/25 border border-white/[0.04] font-mono">{m}</span>
                    ))}
                  </div>
                </details>
              </SectionCard>
            )
          })}
          {customProviders.length > 0 && (
            <>
              <div className="col-span-full">
                <SectionCard className="p-4 bg-slate-950/80 border-white/5">
                  <p className="text-sm font-semibold text-white">Custom AI Providers</p>
                  <p className="text-xs text-white/50 mt-1">These provider records were added manually and can be deleted or disabled individually.</p>
                </SectionCard>
              </div>
              {customProviders.map(provider => (
                <SectionCard key={provider.id} className="p-4">
                  <div className="flex items-start gap-3 mb-3">
                    <div className="text-2xl flex-shrink-0">📦</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <p className="text-sm font-semibold text-white">{provider.name}</p>
                        {provider.isFree && <span className="text-[8px] px-1.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-semibold">FREE</span>}
                        {provider.enabled ? <Badge className="text-[8px] border border-white/[0.08] bg-white/[0.04] text-white/40">Enabled</Badge> : <Badge className="text-[8px] border border-white/[0.08] bg-white/[0.04] text-white/40">Disabled</Badge>}
                      </div>
                      <p className="text-[11px] text-white/40 mb-2">{provider.description || provider.slug}</p>
                      {provider.apiBase && <p className="text-[10px] text-white/30 break-all">Base: {provider.apiBase}</p>}
                      {provider.apiKey && <p className="text-[10px] text-white/30">Key stored</p>}
                      <div className="flex flex-wrap gap-1 mt-2">
                        {(Array.isArray(provider.models) ? provider.models : []).map((model: string) => (
                          <span key={model} className="text-[9px] px-1.5 py-0.5 rounded bg-white/[0.03] text-white/25 border border-white/[0.04] font-mono">{model}</span>
                        ))}
                      </div>
                    </div>
                    <button onClick={() => deleteProvider(provider.id)} className="h-8 w-8 p-0 text-red-400/60 hover:text-red-400 hover:bg-red-500/10 rounded-xl">
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                </SectionCard>
              ))}
            </>
          )}
        </div>
      )}
    </div>
  )
}

// ─── Admin Tunnels Section ─────────────────────────────────────────────────
function AdminTunnelsSection() {
  const [tunnels, setTunnels] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [fetchingZones, setFetchingZones] = useState(false)
  const [savingZones, setSavingZones] = useState(false)
  const [savingCreds, setSavingCreds] = useState(false)
  const [deleting, setDeleting] = useState<string | null>(null)

  // Credentials
  const [cfAccountId, setCfAccountId] = useState('')
  const [cfApiToken, setCfApiToken] = useState('')
  const [maxTunnels, setMaxTunnels] = useState('2')

  // Zones from CF API
  const [cfZones, setCfZones] = useState<any[]>([])
  const [allowedZones, setAllowedZones] = useState<any[]>([])
  const [zonesLoaded, setZonesLoaded] = useState(false)

  useEffect(() => { loadAll() }, [])

  async function loadAll() {
    setLoading(true)
    try {
      const [tunnelsRes, settingsRes] = await Promise.all([
        fetch('/api/admin/tunnels'),
        fetch('/api/admin/settings')
      ])
      if (tunnelsRes.ok) { const d = await tunnelsRes.json(); setTunnels(d.tunnels || []) }
      if (settingsRes.ok) {
        const d = await settingsRes.json()
        setCfAccountId(d.cfAccountId || '')
        setCfApiToken(d.cfApiToken || '')
        setMaxTunnels(String(d.maxTunnelsPerUser || 2))
        setAllowedZones(d.cfAllowedZones || [])
      }
    } finally { setLoading(false) }
  }

  async function saveCreds() {
    setSavingCreds(true)
    try {
      const r = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cfAccountId, cfApiToken, maxTunnelsPerUser: parseInt(maxTunnels) || 2 })
      })
      if (r.ok) toast.success('Cloudflare credentials saved')
      else toast.error('Failed to save credentials')
    } finally { setSavingCreds(false) }
  }

  async function fetchZones() {
    setFetchingZones(true)
    setCfZones([])
    setZonesLoaded(false)
    try {
      const r = await fetch('/api/admin/cf-zones')
      if (r.ok) {
        const d = await r.json()
        setCfZones(d.zones || [])
        // Pre-select already-allowed zones
        setAllowedZones(d.allowedZones || [])
        setZonesLoaded(true)
        if ((d.zones || []).length === 0) toast.info('No active zones found in your Cloudflare account')
        else toast.success(`Found ${d.zones.length} domain${d.zones.length !== 1 ? 's' : ''} in your account`)
      } else {
        const d = await r.json()
        toast.error(d.error || 'Failed to fetch zones. Check your credentials.')
      }
    } finally { setFetchingZones(false) }
  }

  function toggleZone(zone: any) {
    setAllowedZones(prev => {
      const exists = prev.find((z: any) => z.id === zone.id)
      if (exists) return prev.filter((z: any) => z.id !== zone.id)
      return [...prev, { id: zone.id, name: zone.name }]
    })
  }

  async function saveAllowedZones() {
    setSavingZones(true)
    try {
      const r = await fetch('/api/admin/cf-zones', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ allowedZones })
      })
      if (r.ok) toast.success(`${allowedZones.length} domain${allowedZones.length !== 1 ? 's' : ''} enabled for users`)
      else toast.error('Failed to save domain settings')
    } finally { setSavingZones(false) }
  }

  async function deleteTunnel(id: string) {
    if (!confirm('Delete this tunnel? This will also remove it from Cloudflare.')) return
    setDeleting(id)
    try {
      const r = await fetch('/api/admin/tunnels', { method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }) })
      if (r.ok) { toast.success('Tunnel deleted'); loadAll() }
      else toast.error('Failed to delete')
    } finally { setDeleting(null) }
  }

  const statusColors: Record<string, string> = {
    ACTIVE: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    PENDING: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    ERROR: 'bg-red-500/10 text-red-400 border-red-500/20',
    DELETED: 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20',
  }

  return (
    <div className="space-y-6">
      <SectionHeader title="Zero Trust Tunnels" description="Users create Cloudflare tunnels under your domains — just add credentials and enable domains" />

      {/* Step 1: Credentials */}
      <SectionCard className="p-5">
        <div className="flex items-center gap-2 mb-1">
          <span className="w-5 h-5 rounded-full bg-orange-500/20 text-orange-400 text-[10px] font-bold flex items-center justify-center flex-shrink-0">1</span>
          <h4 className="text-sm font-semibold text-white">Cloudflare Credentials</h4>
        </div>
        <p className="text-[11px] text-white/30 mb-4 ml-7">
          API Token needs <span className="font-mono text-white/50">Cloudflare Tunnel:Edit</span> + <span className="font-mono text-white/50">DNS:Edit</span> permissions.
        </p>
        <div className="grid sm:grid-cols-2 gap-3 mb-3">
          <div>
            <Label className="text-white/40 text-[11px] mb-1.5 block">Account ID</Label>
            <Input value={cfAccountId} onChange={e => setCfAccountId(e.target.value)}
              placeholder="e.g. a1b2c3d4e5f6..." className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl text-sm font-mono" />
          </div>
          <div>
            <Label className="text-white/40 text-[11px] mb-1.5 block">API Token</Label>
            <Input type="password" value={cfApiToken} onChange={e => setCfApiToken(e.target.value)}
              placeholder="Cloudflare API Token" className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl text-sm font-mono" />
          </div>
          <div>
            <Label className="text-white/40 text-[11px] mb-1.5 block">Max Tunnels Per User</Label>
            <Input type="number" min="1" max="20" value={maxTunnels} onChange={e => setMaxTunnels(e.target.value)}
              className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl text-sm w-28" />
          </div>
        </div>
        <Button onClick={saveCreds} disabled={savingCreds} size="sm"
          className="bg-gradient-to-r from-orange-600 to-amber-600 text-white rounded-xl text-xs gap-1.5">
          {savingCreds ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
          Save Credentials
        </Button>
      </SectionCard>

      {/* Step 2: Pick domains */}
      <SectionCard className="p-5">
        <div className="flex items-center gap-2 mb-1">
          <span className="w-5 h-5 rounded-full bg-orange-500/20 text-orange-400 text-[10px] font-bold flex items-center justify-center flex-shrink-0">2</span>
          <h4 className="text-sm font-semibold text-white">Enable Domains for Users</h4>
        </div>
        <p className="text-[11px] text-white/30 mb-4 ml-7">
          Fetch your Cloudflare zones, then tick the ones users can create tunnels on.
        </p>

        <div className="flex items-center gap-2 mb-4">
          <Button onClick={fetchZones} disabled={fetchingZones || !cfAccountId} size="sm"
            variant="outline" className="border-white/[0.1] text-white/70 hover:text-white rounded-xl text-xs gap-1.5">
            {fetchingZones ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
            {fetchingZones ? 'Fetching…' : 'Fetch My Domains'}
          </Button>
          {allowedZones.length > 0 && !zonesLoaded && (
            <span className="text-[11px] text-white/30">{allowedZones.length} domain{allowedZones.length !== 1 ? 's' : ''} currently enabled</span>
          )}
        </div>

        {/* Current allowed zones (before fetch) */}
        {!zonesLoaded && allowedZones.length > 0 && (
          <div className="mb-4 space-y-1.5">
            <p className="text-[11px] text-white/30 mb-2">Currently enabled:</p>
            {allowedZones.map((z: any) => (
              <div key={z.id} className="flex items-center gap-2 px-3 py-2 rounded-xl bg-emerald-500/5 border border-emerald-500/10">
                <Globe className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                <span className="text-xs font-mono text-emerald-300">{z.name}</span>
                <span className="text-[10px] text-white/20 ml-auto font-mono truncate">{z.id}</span>
              </div>
            ))}
          </div>
        )}

        {/* Zone picker after fetch */}
        {zonesLoaded && cfZones.length > 0 && (
          <div className="space-y-2 mb-4">
            <p className="text-[11px] text-white/30 mb-2">Select domains to enable (users can create tunnels on ticked domains):</p>
            {cfZones.map(zone => {
              const isEnabled = allowedZones.some((z: any) => z.id === zone.id)
              return (
                <button key={zone.id} onClick={() => toggleZone(zone)}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl border transition text-left ${
                    isEnabled
                      ? 'bg-emerald-500/10 border-emerald-500/25 hover:bg-emerald-500/15'
                      : 'bg-white/[0.02] border-white/[0.06] hover:bg-white/[0.05]'
                  }`}>
                  <div className={`w-4 h-4 rounded flex items-center justify-center border flex-shrink-0 ${
                    isEnabled ? 'bg-emerald-500 border-emerald-500' : 'border-white/20 bg-white/[0.04]'
                  }`}>
                    {isEnabled && <span className="text-white text-[10px] leading-none">✓</span>}
                  </div>
                  <Globe className={`w-3.5 h-3.5 flex-shrink-0 ${isEnabled ? 'text-emerald-400' : 'text-white/30'}`} />
                  <div className="flex-1 min-w-0">
                    <p className={`text-sm font-mono font-medium ${isEnabled ? 'text-emerald-300' : 'text-white/70'}`}>{zone.name}</p>
                    <p className="text-[10px] text-white/20">{zone.plan} · {zone.status}</p>
                  </div>
                  {isEnabled && (
                    <Badge className="text-[9px] h-4 border bg-emerald-500/10 text-emerald-400 border-emerald-500/20 flex-shrink-0">Enabled</Badge>
                  )}
                </button>
              )
            })}
          </div>
        )}

        {zonesLoaded && cfZones.length === 0 && (
          <div className="py-6 text-center text-white/30 text-sm mb-4">No active zones found in your Cloudflare account.</div>
        )}

        {(zonesLoaded || allowedZones.length > 0) && (
          <Button onClick={saveAllowedZones} disabled={savingZones} size="sm"
            className="bg-gradient-to-r from-orange-600 to-amber-600 text-white rounded-xl text-xs gap-1.5">
            {savingZones ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
            Save ({allowedZones.length} domain{allowedZones.length !== 1 ? 's' : ''} enabled)
          </Button>
        )}
      </SectionCard>

      {/* All tunnels list */}
      <SectionCard className="overflow-hidden">
        <div className="p-4 border-b border-white/[0.04] flex items-center justify-between">
          <h4 className="text-sm font-semibold text-white">All User Tunnels ({tunnels.length})</h4>
          <button onClick={loadAll} className="text-white/30 hover:text-white p-1.5 rounded-lg hover:bg-white/[0.04] transition">
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>
        {loading ? (
          <div className="flex items-center justify-center py-12"><Loader2 className="w-5 h-5 animate-spin text-white/20" /></div>
        ) : tunnels.length === 0 ? (
          <div className="py-12 text-center">
            <Globe className="w-8 h-8 text-white/10 mx-auto mb-2" />
            <p className="text-white/20 text-sm">No tunnels created yet</p>
          </div>
        ) : (
          <div className="divide-y divide-white/[0.04]">
            {tunnels.map((t: any) => {
              const fullHost = t.subdomain && t.zoneDomain ? `${t.subdomain}.${t.zoneDomain}` : null
              return (
                <div key={t.id} className="flex items-center gap-3 px-4 py-3 hover:bg-white/[0.02]">
                  <Avatar className="h-8 w-8 flex-shrink-0">
                    {t.user?.avatar && <AvatarImage src={t.user.avatar} />}
                    <AvatarFallback className="bg-orange-500/20 text-orange-400 text-xs">{t.user?.username?.[0]?.toUpperCase() || '?'}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-white truncate">{t.name}</p>
                    <p className="text-[10px] text-white/30 truncate">
                      {t.user?.username || 'Unknown'}
                      {fullHost && <> · <span className="font-mono text-white/40">{fullHost}</span></>}
                      {' '}&rarr; {t.protocol}://{t.targetHost}:{t.targetPort}
                    </p>
                    {t.cfTunnelId && <p className="text-[9px] text-white/15 font-mono truncate">{t.cfTunnelId}</p>}
                  </div>
                  <Badge className={`text-[9px] h-4 border flex-shrink-0 ${statusColors[t.status] || 'bg-white/5 text-white/30 border-white/10'}`}>{t.status}</Badge>
                  <span className="text-[10px] text-white/20 flex-shrink-0 hidden sm:block">{new Date(t.createdAt).toLocaleDateString()}</span>
                  <button onClick={() => deleteTunnel(t.id)} disabled={deleting === t.id}
                    className="text-red-400/30 hover:text-red-400 hover:bg-red-500/10 p-1.5 rounded-lg transition flex-shrink-0">
                    {deleting === t.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                  </button>
                </div>
              )
            })}
          </div>
        )}
      </SectionCard>
    </div>
  )
}

// ─── Admin Console Section ────────────────────────────────────────────────
function AdminConsoleSection() {
  const [history, setHistory] = useState<{ cmd: string; out: string; err: string; code: number; ts: number }[]>([])
  const [input, setInput] = useState('')
  const [cwd, setCwd] = useState(typeof window !== 'undefined' ? '~' : '~')
  const [running, setRunning] = useState(false)
  const [cmdHistory, setCmdHistory] = useState<string[]>([])
  const [histIdx, setHistIdx] = useState(-1)
  const outputRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  useEffect(() => {
    if (outputRef.current) outputRef.current.scrollTop = outputRef.current.scrollHeight
  }, [history])

  async function runCommand(e: React.FormEvent) {
    e.preventDefault()
    const cmd = input.trim()
    if (!cmd || running) return
    setInput('')
    setHistIdx(-1)

    if (cmd === 'clear') { setHistory([]); return }

    setCmdHistory(h => [cmd, ...h.slice(0, 99)])
    setRunning(true)
    const ts = Date.now()
    try {
      const r = await fetch('/api/admin/console', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ command: cmd, cwd })
      })
      const data = await r.json()
      setHistory(h => [...h, { cmd, out: data.stdout || '', err: data.stderr || data.error || '', code: data.exitCode ?? (data.error ? 1 : 0), ts }])
    } catch (err: any) {
      setHistory(h => [...h, { cmd, out: '', err: err?.message || 'Request failed', code: 1, ts }])
    } finally { setRunning(false); setTimeout(() => inputRef.current?.focus(), 50) }
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === 'ArrowUp') {
      e.preventDefault()
      const idx = Math.min(histIdx + 1, cmdHistory.length - 1)
      setHistIdx(idx)
      setInput(cmdHistory[idx] || '')
    } else if (e.key === 'ArrowDown') {
      e.preventDefault()
      const idx = Math.max(histIdx - 1, -1)
      setHistIdx(idx)
      setInput(idx === -1 ? '' : cmdHistory[idx] || '')
    }
  }

  return (
    <div>
      <SectionHeader title="Server Console" description="Execute commands directly on the VPS server — use with caution" />
      <SectionCard className="overflow-hidden">
        <div className="bg-[#0a0a12] border-b border-white/[0.06] px-4 py-2 flex items-center gap-2">
          <div className="flex gap-1.5"><div className="w-3 h-3 rounded-full bg-red-500/60" /><div className="w-3 h-3 rounded-full bg-yellow-500/60" /><div className="w-3 h-3 rounded-full bg-green-500/60" /></div>
          <span className="text-[11px] text-white/30 font-mono ml-2">root@gfxstore-vps:~</span>
          <button onClick={() => setHistory([])} className="ml-auto text-white/20 hover:text-white/50 text-[10px] transition">Clear</button>
        </div>
        <div ref={outputRef} className="h-[500px] overflow-y-auto bg-[#070712] font-mono text-[12px] p-4 space-y-3">
          {history.length === 0 && (
            <div className="text-white/20 text-center py-12">
              <Database className="w-8 h-8 mx-auto mb-2 opacity-20" />
              <p>Terminal ready. Type a command and press Enter.</p>
              <p className="text-[11px] mt-1 opacity-60">Use ↑/↓ arrow keys to navigate command history</p>
            </div>
          )}
          {history.map((entry, i) => (
            <div key={i}>
              <div className="flex items-start gap-2">
                <span className="text-emerald-400 flex-shrink-0">$</span>
                <span className="text-white/80">{entry.cmd}</span>
              </div>
              {entry.out && (
                <pre className="text-white/60 whitespace-pre-wrap break-all mt-1 pl-4 leading-relaxed">{entry.out}</pre>
              )}
              {entry.err && (
                <pre className={`whitespace-pre-wrap break-all mt-1 pl-4 leading-relaxed ${entry.code !== 0 ? 'text-red-400/80' : 'text-yellow-400/60'}`}>{entry.err}</pre>
              )}
              {entry.code !== 0 && <div className="text-[10px] text-red-400/40 pl-4">exit code: {entry.code}</div>}
            </div>
          ))}
          {running && (
            <div className="flex items-center gap-2 text-white/30">
              <Loader2 className="w-3 h-3 animate-spin" />
              <span>Running...</span>
            </div>
          )}
        </div>
        <form onSubmit={runCommand} className="border-t border-white/[0.06] bg-[#0a0a12] px-4 py-3 flex items-center gap-2">
          <span className="text-emerald-400 font-mono text-sm flex-shrink-0">$</span>
          <input
            ref={inputRef}
            value={input}
            onChange={e => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            disabled={running}
            placeholder="Enter command... (type 'clear' to clear)"
            className="flex-1 bg-transparent text-white/80 font-mono text-sm outline-none placeholder:text-white/15 disabled:opacity-50"
            autoComplete="off"
            autoFocus
          />
          <button type="submit" disabled={running || !input.trim()}
            className="text-[11px] px-3 py-1.5 rounded-lg bg-emerald-600/20 text-emerald-400 hover:bg-emerald-600/30 disabled:opacity-30 transition font-medium">
            {running ? '...' : 'Run'}
          </button>
        </form>
      </SectionCard>
      <div className="mt-3 p-3 rounded-xl bg-red-500/5 border border-red-500/10 text-[11px] text-red-300/50 space-y-0.5">
        <p>⚠️ Dangerous commands (rm -rf /, shutdown, etc.) are blocked. Commands timeout after 30s. Output is limited to 5MB.</p>
      </div>
    </div>
  )
}
