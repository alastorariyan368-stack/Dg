'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useSession } from 'next-auth/react'
import { Navbar } from '@/components/navbar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  ArrowLeft, Mail, Save, Send, CheckCircle2, AlertCircle,
  Eye, EyeOff, ExternalLink, Zap, Server, Globe, Inbox,
} from 'lucide-react'
import { toast } from 'sonner'
import { Logo } from '@/components/logo'

type Provider = 'direct' | 'resend' | 'gmail' | 'smtp'

interface Config {
  provider: Provider
  host: string
  port: number
  secure: boolean
  user: string
  pass: string
  resendKey: string
  fromName: string
  fromAddress: string
}

const PROVIDERS: { id: Provider; label: string; icon: any; color: string; desc: string }[] = [
  {
    id: 'resend',
    label: 'Resend',
    icon: Zap,
    color: 'from-violet-600 to-fuchsia-600',
    desc: 'Free REST API — no SMTP setup. 100 emails/day free. Best choice.',
  },
  {
    id: 'gmail',
    label: 'Gmail',
    icon: Mail,
    color: 'from-red-500 to-orange-500',
    desc: 'Send using your Google account + App Password. Free, reliable.',
  },
  {
    id: 'smtp',
    label: 'Custom SMTP',
    icon: Server,
    color: 'from-blue-500 to-cyan-500',
    desc: 'Any SMTP server — Mailgun, SendGrid, Zoho, Outlook, etc.',
  },
  {
    id: 'direct',
    label: 'Built-in (Direct)',
    icon: Globe,
    color: 'from-emerald-600 to-teal-600',
    desc: 'Sends directly to mail servers — no account needed, but Gmail/Outlook may block it.',
  },
]

export default function AdminEmailSettingsPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [testing, setTesting] = useState(false)
  const [testEmail, setTestEmail] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [showKey, setShowKey] = useState(false)
  const [cfg, setCfg] = useState<Config>({
    provider: 'direct',
    host: '', port: 587, secure: false,
    user: '', pass: '', resendKey: '',
    fromName: 'GfxStore', fromAddress: 'noreply@gfxstore.app',
  })

  useEffect(() => {
    if (status === 'loading') return
    if (status === 'unauthenticated') { router.push('/auth/signin'); return }
    if (!['ADMIN', 'SUPER_ADMIN'].includes((session?.user as any)?.role || '')) {
      router.push('/'); return
    }
    load()
    setTestEmail((session?.user?.email as string) || '')
  }, [status])

  const load = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/email-settings')
      if (res.ok) {
        const data = await res.json()
        if (data.config && Object.keys(data.config).length > 0) {
          setCfg(prev => ({ ...prev, ...data.config }))
        }
      }
    } finally {
      setLoading(false)
    }
  }

  const save = async () => {
    setSaving(true)
    try {
      const res = await fetch('/api/admin/email-settings', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(cfg),
      })
      if (!res.ok) { const e = await res.json(); throw new Error(e.error || 'Save failed') }
      toast.success('Email settings saved')
      load()
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setSaving(false)
    }
  }

  const sendTest = async () => {
    if (!testEmail) { toast.error('Enter a test email address'); return }
    setTesting(true)
    try {
      const res = await fetch('/api/admin/email-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ testTo: testEmail }),
      })
      const data = await res.json()
      if (data.success) toast.success('Test email sent! Check your inbox.')
      else toast.error('Failed: ' + (data.error || 'Unknown error'))
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setTesting(false)
    }
  }

  const set = (key: keyof Config, value: any) => setCfg(prev => ({ ...prev, [key]: value }))

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a12] text-white">
        <Navbar />
        <div className="container mx-auto px-4 py-12 text-center text-white/50">Loading…</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#0a0a12] text-white">
      <Navbar />
      <div className="container mx-auto px-4 py-8 max-w-3xl">
        <Link href="/admin" className="inline-flex items-center gap-2 text-white/50 hover:text-white text-sm mb-6">
          <ArrowLeft className="w-4 h-4" /> Back to Admin
        </Link>

        <div className="flex items-start gap-4 mb-8">
          <Logo size="lg" />
          <div>
            <h1 className="text-2xl font-bold text-white">Email Settings</h1>
            <p className="text-sm text-white/50 mt-1">
              Configure how GfxStore sends password reset emails. If none configured, emails are stored in the Admin Inbox.
            </p>
          </div>
        </div>

        <div className="space-y-4">
          {/* Provider selector */}
          <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
            <Label className="text-white text-sm font-semibold mb-3 block">Email Provider</Label>
            <div className="grid grid-cols-2 gap-3">
              {PROVIDERS.map(p => {
                const Icon = p.icon
                const active = cfg.provider === p.id
                return (
                  <button
                    key={p.id}
                    onClick={() => set('provider', p.id)}
                    className={`relative rounded-xl border p-4 text-left transition-all ${
                      active
                        ? 'border-violet-500/50 bg-violet-500/10'
                        : 'border-white/10 bg-black/20 hover:bg-white/5'
                    }`}
                  >
                    <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${p.color} flex items-center justify-center mb-2`}>
                      <Icon className="w-4 h-4 text-white" />
                    </div>
                    <p className="text-sm font-semibold text-white">{p.label}</p>
                    <p className="text-xs text-white/40 mt-0.5 leading-relaxed">{p.desc}</p>
                    {active && (
                      <CheckCircle2 className="absolute top-3 right-3 w-4 h-4 text-violet-400" />
                    )}
                  </button>
                )
              })}
            </div>
          </div>

          {/* Resend config */}
          {cfg.provider === 'resend' && (
            <div className="rounded-2xl border border-violet-500/20 bg-violet-500/5 p-5 space-y-4">
              <div className="flex items-center gap-2 text-violet-300">
                <Zap className="w-4 h-4" />
                <span className="text-sm font-semibold">Resend API Key</span>
                <a href="https://resend.com" target="_blank" rel="noopener noreferrer"
                   className="ml-auto flex items-center gap-1 text-xs text-violet-400 hover:text-violet-300">
                  Get free key <ExternalLink className="w-3 h-3" />
                </a>
              </div>
              <ol className="text-xs text-white/50 space-y-1 ml-4 list-decimal">
                <li>Sign up free at <strong className="text-white/70">resend.com</strong></li>
                <li>Create an API key → paste it below</li>
                <li>For &quot;From&quot; address: use <strong className="text-white/70">onboarding@resend.dev</strong> (testing) or verify your own domain</li>
              </ol>
              <div className="relative">
                <Input
                  type={showKey ? 'text' : 'password'}
                  value={cfg.resendKey}
                  onChange={e => set('resendKey', e.target.value)}
                  placeholder="re_..."
                  className="bg-black/40 border-white/10 text-white pr-10 font-mono text-xs"
                />
                <button type="button" onClick={() => setShowKey(v => !v)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-white/40 hover:text-white p-1.5">
                  {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
          )}

          {/* Gmail config */}
          {cfg.provider === 'gmail' && (
            <div className="rounded-2xl border border-red-500/20 bg-red-500/5 p-5 space-y-4">
              <div className="flex items-center gap-2 text-red-300">
                <Mail className="w-4 h-4" />
                <span className="text-sm font-semibold">Gmail Credentials</span>
              </div>
              <ol className="text-xs text-white/50 space-y-1 ml-4 list-decimal">
                <li>Go to <strong className="text-white/70">myaccount.google.com/security</strong></li>
                <li>Enable <strong className="text-white/70">2-Step Verification</strong></li>
                <li>Search for &quot;App passwords&quot; → Create one for &quot;Mail&quot;</li>
                <li>Paste the 16-character password below (no spaces needed)</li>
              </ol>
              <div className="grid gap-3">
                <div>
                  <Label className="text-white/70 text-xs mb-1.5 block">Gmail Address</Label>
                  <Input value={cfg.user} onChange={e => set('user', e.target.value)}
                    placeholder="you@gmail.com"
                    className="bg-black/40 border-white/10 text-white font-mono text-sm" />
                </div>
                <div>
                  <Label className="text-white/70 text-xs mb-1.5 block">Gmail App Password</Label>
                  <div className="relative">
                    <Input type={showPass ? 'text' : 'password'} value={cfg.pass}
                      onChange={e => set('pass', e.target.value)}
                      placeholder="16-character app password"
                      className="bg-black/40 border-white/10 text-white pr-10 font-mono text-sm" />
                    <button type="button" onClick={() => setShowPass(v => !v)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-white/40 hover:text-white p-1.5">
                      {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Custom SMTP config */}
          {cfg.provider === 'smtp' && (
            <div className="rounded-2xl border border-blue-500/20 bg-blue-500/5 p-5 space-y-4">
              <div className="flex items-center gap-2 text-blue-300">
                <Server className="w-4 h-4" />
                <span className="text-sm font-semibold">SMTP Configuration</span>
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="col-span-2">
                  <Label className="text-white/70 text-xs mb-1.5 block">SMTP Host</Label>
                  <Input value={cfg.host} onChange={e => set('host', e.target.value)}
                    placeholder="smtp.example.com"
                    className="bg-black/40 border-white/10 text-white font-mono text-sm" />
                </div>
                <div>
                  <Label className="text-white/70 text-xs mb-1.5 block">Port</Label>
                  <Input type="number" value={cfg.port} onChange={e => set('port', Number(e.target.value))}
                    placeholder="587"
                    className="bg-black/40 border-white/10 text-white font-mono text-sm" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <Label className="text-white/70 text-xs mb-1.5 block">Username / Email</Label>
                  <Input value={cfg.user} onChange={e => set('user', e.target.value)}
                    placeholder="user@example.com"
                    className="bg-black/40 border-white/10 text-white font-mono text-sm" />
                </div>
                <div>
                  <Label className="text-white/70 text-xs mb-1.5 block">Password</Label>
                  <div className="relative">
                    <Input type={showPass ? 'text' : 'password'} value={cfg.pass}
                      onChange={e => set('pass', e.target.value)}
                      placeholder="••••••••"
                      className="bg-black/40 border-white/10 text-white pr-10 font-mono text-sm" />
                    <button type="button" onClick={() => setShowPass(v => !v)}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-white/40 hover:text-white p-1.5">
                      {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Direct info */}
          {cfg.provider === 'direct' && (
            <div className="rounded-2xl border border-emerald-500/20 bg-emerald-500/5 p-5">
              <div className="flex items-center gap-2 text-emerald-300 mb-2">
                <Globe className="w-4 h-4" />
                <span className="text-sm font-semibold">Built-in Direct Delivery</span>
              </div>
              <p className="text-xs text-white/50 leading-relaxed">
                No setup required — GfxStore connects directly to the recipient&apos;s mail server.
                Works for most providers, but <strong className="text-amber-300">Gmail and Outlook may block it</strong> due to
                SPF/DKIM requirements. If delivery fails, emails are stored in the Admin Inbox instead.
              </p>
            </div>
          )}

          {/* From address */}
          <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5 space-y-3">
            <Label className="text-white text-sm font-semibold block">From Address</Label>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-white/70 text-xs mb-1.5 block">Display Name</Label>
                <Input value={cfg.fromName} onChange={e => set('fromName', e.target.value)}
                  placeholder="GfxStore"
                  className="bg-black/40 border-white/10 text-white text-sm" />
              </div>
              <div>
                <Label className="text-white/70 text-xs mb-1.5 block">
                  Email Address
                  {cfg.provider === 'resend' && (
                    <span className="ml-1 text-violet-400">(use onboarding@resend.dev for testing)</span>
                  )}
                  {(cfg.provider === 'gmail' || cfg.provider === 'smtp') && (
                    <span className="ml-1 text-white/40">(must match login email)</span>
                  )}
                </Label>
                <Input value={cfg.fromAddress} onChange={e => set('fromAddress', e.target.value)}
                  placeholder="noreply@gfxstore.app"
                  className="bg-black/40 border-white/10 text-white font-mono text-sm" />
              </div>
            </div>
          </div>

          {/* Test */}
          <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
            <Label className="text-white text-sm font-semibold mb-3 block">Send Test Email</Label>
            <div className="flex gap-3">
              <Input
                value={testEmail}
                onChange={e => setTestEmail(e.target.value)}
                placeholder="your@email.com"
                type="email"
                className="bg-black/40 border-white/10 text-white"
              />
              <Button
                onClick={sendTest}
                disabled={testing}
                variant="outline"
                className="border-white/20 text-white hover:bg-white/10 gap-2 shrink-0"
              >
                <Send className="w-4 h-4" />
                {testing ? 'Sending…' : 'Send test'}
              </Button>
            </div>
          </div>

          {/* Admin inbox note */}
          <div className="rounded-2xl border border-white/10 bg-black/20 p-4 flex items-start gap-3">
            <Inbox className="w-5 h-5 text-white/40 shrink-0 mt-0.5" />
            <div>
              <p className="text-sm text-white/70 font-medium">Admin Email Inbox</p>
              <p className="text-xs text-white/40 mt-0.5">
                If delivery fails, emails are always saved to the Admin Inbox.{' '}
                <Link href="/admin/emails" className="text-violet-400 hover:text-violet-300 underline">
                  Open Inbox →
                </Link>
              </p>
            </div>
          </div>

          <div className="flex items-center justify-between pt-2">
            <div className="flex items-center gap-1.5 text-xs text-white/30">
              <AlertCircle className="w-3.5 h-3.5" />
              Settings are encrypted in the database
            </div>
            <div className="flex items-center gap-3">
              <Button variant="ghost" onClick={load} className="text-white/60 hover:text-white">Reset</Button>
              <Button
                onClick={save}
                disabled={saving}
                className="bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 text-white border-0 gap-2"
              >
                <Save className="w-4 h-4" />
                {saving ? 'Saving…' : 'Save Settings'}
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
