'use client'

import { useState, useEffect } from 'react'
import { Navbar } from '@/components/navbar'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { CheckCircle, XCircle, ExternalLink, Code2, ChevronLeft } from 'lucide-react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import Link from 'next/link'
import { formatDistanceToNow } from 'date-fns'

interface CodeItem {
  id: string
  title: string
  language: string
  type: string
  status: string
  shortDesc?: string
  createdAt: string
  author: { id: string; username: string; avatar?: string }
}

const LANGUAGE_COLORS: Record<string, string> = {
  JavaScript: 'bg-yellow-500/20 text-yellow-400',
  TypeScript: 'bg-blue-500/20 text-blue-400',
  HTML: 'bg-orange-500/20 text-orange-400',
  Python: 'bg-green-500/20 text-green-400',
}

export default function AdminCodePage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [items, setItems] = useState<CodeItem[]>([])
  const [loading, setLoading] = useState(true)
  const [currentStatus, setCurrentStatus] = useState('PENDING')
  const [processing, setProcessing] = useState<string | null>(null)

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin')
    const isAdmin = (session?.user as any)?.role === 'ADMIN' || (session?.user as any)?.role === 'SUPER_ADMIN'
    if (status === 'authenticated' && !isAdmin) router.push('/')
  }, [status, session])

  useEffect(() => { fetchItems() }, [currentStatus])

  const fetchItems = async () => {
    setLoading(true)
    try {
      const res = await fetch(`/api/admin/content?type=code&status=${currentStatus}&limit=50`)
      if (res.ok) { const data = await res.json(); setItems(data.code || []) }
    } catch {}
    setLoading(false)
  }

  const handleAction = async (id: string, action: 'approve' | 'reject') => {
    setProcessing(id)
    try {
      const res = await fetch('/api/admin/content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, contentType: 'code', action })
      })
      if (res.ok) {
        toast.success(action === 'approve' ? 'Project approved!' : 'Project rejected')
        setItems(prev => prev.filter(i => i.id !== id))
      } else { toast.error('Failed') }
    } catch { toast.error('Error') }
    setProcessing(null)
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        <div className="flex items-center gap-3 mb-6">
          <Link href="/admin"><Button variant="outline" size="sm" className="border-white/20 gap-1"><ChevronLeft className="w-4 h-4" /> Admin</Button></Link>
          <h1 className="text-2xl font-bold flex items-center gap-2"><Code2 className="w-6 h-6 text-yellow-400" /> Code Moderation</h1>
        </div>
        <div className="flex gap-2 mb-6">
          {['PENDING', 'APPROVED', 'REJECTED'].map(s => (
            <button key={s} onClick={() => setCurrentStatus(s)}
              className={`px-3 py-1.5 rounded-full text-sm font-medium transition-all ${currentStatus === s ? 'bg-yellow-600 text-white' : 'bg-white/5 text-white/60 hover:bg-white/10'}`}>
              {s}
            </button>
          ))}
        </div>
        {loading ? (
          <div className="space-y-3">{Array.from({length: 5}).map((_, i) => <div key={i} className="h-16 bg-white/5 rounded-xl animate-pulse" />)}</div>
        ) : items.length === 0 ? (
          <div className="text-center py-16 text-white/40">No {currentStatus.toLowerCase()} projects</div>
        ) : (
          <div className="space-y-3">
            {items.map(item => (
              <div key={item.id} className="flex items-center gap-4 bg-white/5 rounded-xl p-4 border border-white/5">
                <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-yellow-500/10 flex items-center justify-center">
                  <Code2 className="w-5 h-5 text-yellow-400" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-white">{item.title}</p>
                    <Badge className={`text-xs ${LANGUAGE_COLORS[item.language] || 'bg-white/10 text-white/60'}`}>{item.language}</Badge>
                    <Badge className="text-xs bg-white/10 text-white/60">{item.type}</Badge>
                  </div>
                  {item.shortDesc && <p className="text-xs text-white/40 mt-0.5 line-clamp-1">{item.shortDesc}</p>}
                  <div className="flex items-center gap-2 mt-1">
                    <Avatar className="w-5 h-5"><AvatarImage src={item.author.avatar} /><AvatarFallback className="text-xs bg-yellow-700">{item.author.username[0]}</AvatarFallback></Avatar>
                    <span className="text-xs text-white/50">{item.author.username}</span>
                    <span className="text-xs text-white/30">{formatDistanceToNow(new Date(item.createdAt), { addSuffix: true })}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <Link href={`/code/${item.id}`} target="_blank"><Button size="sm" variant="outline" className="border-white/20 hover:bg-white/10 gap-1"><ExternalLink className="w-3 h-3" /> View</Button></Link>
                  {currentStatus === 'PENDING' && (
                    <>
                      <Button size="sm" onClick={() => handleAction(item.id, 'approve')} disabled={processing === item.id} className="bg-green-600 hover:bg-green-700 gap-1"><CheckCircle className="w-3.5 h-3.5" /> Approve</Button>
                      <Button size="sm" onClick={() => handleAction(item.id, 'reject')} disabled={processing === item.id} className="bg-red-600/80 hover:bg-red-700 gap-1"><XCircle className="w-3.5 h-3.5" /> Reject</Button>
                    </>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  )
}
