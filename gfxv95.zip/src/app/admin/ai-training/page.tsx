'use client'

import { useState, useEffect, useCallback } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'

interface BrainEntry {
  id: string
  category: string
  question: string
  answer: string
  keywords: string
  confidence: number
  usageCount: number
  source: string
  isActive: boolean
  createdAt: string
}

interface Stats {
  total: number
  manual: number
  learned: number
  api: number
  memories: number
  aiUsages: number
  config?: { totalResponses: number }
}

interface AiConfig {
  id: string
  name: string
  systemPrompt: string
  personality: string
  version: string
  totalResponses: number
}

const SOURCE_COLORS: Record<string, string> = {
  manual: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
  learned: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
  api: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
}

const PERSONALITIES = ['professional', 'friendly', 'technical', 'creative', 'formal', 'casual']

export default function AiTrainingPage() {
  const { data: session, status } = useSession()
  const router = useRouter()

  const [tab, setTab] = useState<'brain' | 'config' | 'memories' | 'import'>('brain')
  const [stats, setStats] = useState<Stats | null>(null)
  const [entries, setEntries] = useState<BrainEntry[]>([])
  const [total, setTotal] = useState(0)
  const [page, setPage] = useState(1)
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(false)
  const [config, setConfig] = useState<AiConfig | null>(null)
  const [configDraft, setConfigDraft] = useState({ systemPrompt: '', personality: 'professional', version: '5.0.0' })
  const [savingConfig, setSavingConfig] = useState(false)
  const [editEntry, setEditEntry] = useState<BrainEntry | null>(null)
  const [showAdd, setShowAdd] = useState(false)
  const [addForm, setAddForm] = useState({ question: '', answer: '', category: 'general', keywords: '' })
  const [bulkText, setBulkText] = useState('')
  const [importResult, setImportResult] = useState('')
  const [toast, setToast] = useState<{ msg: string; type: 'ok' | 'err' } | null>(null)

  const showToast = (msg: string, type: 'ok' | 'err' = 'ok') => {
    setToast({ msg, type })
    setTimeout(() => setToast(null), 3000)
  }

  useEffect(() => {
    if (status === 'loading') return
    const role = (session?.user as any)?.role
    if (!session || (role !== 'ADMIN' && role !== 'SUPER_ADMIN')) {
      router.replace('/admin')
    }
  }, [session, status, router])

  const fetchStats = useCallback(async () => {
    const r = await fetch('/api/admin/ai-training?action=stats').then(r => r.json()).catch(() => ({}))
    setStats(r)
  }, [])

  const fetchEntries = useCallback(async () => {
    setLoading(true)
    const params = new URLSearchParams({ action: 'list', page: String(page), limit: '20', search })
    const r = await fetch(`/api/admin/ai-training?${params}`).then(r => r.json()).catch(() => ({ entries: [], total: 0 }))
    setEntries(r.entries || [])
    setTotal(r.total || 0)
    setLoading(false)
  }, [page, search])

  const fetchConfig = useCallback(async () => {
    const r = await fetch('/api/admin/ai-training?action=config').then(r => r.json()).catch(() => ({}))
    if (r.config) {
      setConfig(r.config)
      setConfigDraft({ systemPrompt: r.config.systemPrompt || '', personality: r.config.personality || 'professional', version: r.config.version || '5.0.0' })
    }
  }, [])

  useEffect(() => { fetchStats() }, [fetchStats])
  useEffect(() => { if (tab === 'brain') fetchEntries() }, [tab, fetchEntries])
  useEffect(() => { if (tab === 'config') fetchConfig() }, [tab, fetchConfig])

  const handleAdd = async () => {
    if (!addForm.question.trim() || !addForm.answer.trim()) return showToast('Question and answer required', 'err')
    const r = await fetch('/api/admin/ai-training', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'add', ...addForm }) }).then(r => r.json())
    if (r.success) { showToast('Entry added!'); setShowAdd(false); setAddForm({ question: '', answer: '', category: 'general', keywords: '' }); fetchEntries(); fetchStats() }
    else showToast(r.error || 'Failed', 'err')
  }

  const handleUpdate = async () => {
    if (!editEntry) return
    const r = await fetch('/api/admin/ai-training', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'update', ...editEntry }) }).then(r => r.json())
    if (r.success) { showToast('Updated!'); setEditEntry(null); fetchEntries() }
    else showToast(r.error || 'Failed', 'err')
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Delete this entry from the AI brain?')) return
    const r = await fetch('/api/admin/ai-training', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'delete', id }) }).then(r => r.json())
    if (r.success) { showToast('Deleted'); fetchEntries(); fetchStats() }
    else showToast(r.error || 'Failed', 'err')
  }

  const handleSaveConfig = async () => {
    setSavingConfig(true)
    const r = await fetch('/api/admin/ai-training', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'update-config', ...configDraft }) }).then(r => r.json())
    setSavingConfig(false)
    if (r.success) showToast('AI Config saved!')
    else showToast(r.error || 'Failed', 'err')
  }

  const handleBulkImport = async () => {
    let data: any[] = []
    try {
      data = JSON.parse(bulkText)
      if (!Array.isArray(data)) throw new Error('Must be a JSON array')
    } catch (e: any) {
      // Try plain text Q&A format
      const lines = bulkText.split('\n').filter(l => l.trim())
      for (let i = 0; i < lines.length - 1; i += 2) {
        const q = lines[i].replace(/^Q:\s*/i, '').trim()
        const a = lines[i + 1]?.replace(/^A:\s*/i, '').trim()
        if (q && a) data.push({ question: q, answer: a, category: 'imported' })
      }
      if (!data.length) return showToast('Invalid format. Use JSON array or Q:/A: lines', 'err')
    }
    const r = await fetch('/api/admin/ai-training', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'bulk-import', data }) }).then(r => r.json())
    if (r.success) { showToast(`Imported ${r.imported} entries!`); setImportResult(`✓ ${r.imported} entries imported`); fetchStats() }
    else showToast(r.error || 'Failed', 'err')
  }

  const handleClearLearned = async () => {
    if (!confirm('Delete all auto-learned and API entries? Manual entries are safe.')) return
    const r = await fetch('/api/admin/ai-training', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'clear-all' }) }).then(r => r.json())
    if (r.success) { showToast(`Cleared ${r.deleted} auto-learned entries`); fetchEntries(); fetchStats() }
    else showToast(r.error || 'Failed', 'err')
  }

  const tabs = [
    { key: 'brain', label: '🧠 Brain', count: stats?.total },
    { key: 'config', label: '⚙️ Config' },
    { key: 'import', label: '📥 Import' },
    { key: 'memories', label: '💬 Memories', count: stats?.memories },
  ]

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white p-4 md:p-8">
      {/* Toast */}
      {toast && (
        <div className={`fixed top-4 right-4 z-50 px-4 py-3 rounded-xl text-sm font-medium shadow-xl transition-all ${toast.type === 'ok' ? 'bg-emerald-600 text-white' : 'bg-red-600 text-white'}`}>
          {toast.msg}
        </div>
      )}

      {/* Header */}
      <div className="mb-8 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-violet-400 via-blue-400 to-cyan-400 bg-clip-text text-transparent">
            GfxV1 AI Brain
          </h1>
          <p className="text-gray-400 mt-1 text-sm">Train, configure and monitor the self-contained AI system</p>
        </div>
        <Link href="/admin" className="text-sm text-gray-400 hover:text-white border border-white/10 rounded-lg px-4 py-2 transition">
          ← Admin Panel
        </Link>
      </div>

      {/* Stats */}
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-5 gap-3 mb-8">
          {[
            { label: 'Total Knowledge', value: stats.total, color: 'violet' },
            { label: 'Manual Training', value: stats.manual, color: 'emerald' },
            { label: 'Auto-Learned', value: stats.learned, color: 'blue' },
            { label: 'From APIs', value: stats.api, color: 'purple' },
            { label: 'Total Memories', value: stats.memories, color: 'cyan' },
          ].map(s => (
            <div key={s.label} className={`bg-white/5 border border-white/10 rounded-xl p-4 text-center`}>
              <div className={`text-2xl font-bold text-${s.color}-400`}>{s.value?.toLocaleString()}</div>
              <div className="text-xs text-gray-400 mt-1">{s.label}</div>
            </div>
          ))}
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-2 mb-6 flex-wrap">
        {tabs.map(t => (
          <button
            key={t.key}
            onClick={() => setTab(t.key as any)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${tab === t.key ? 'bg-violet-600 text-white' : 'bg-white/5 text-gray-400 hover:bg-white/10'}`}
          >
            {t.label} {t.count !== undefined && <span className="ml-1 text-xs opacity-70">({t.count})</span>}
          </button>
        ))}
      </div>

      {/* ── BRAIN TAB ────────────────────────────────────────────────── */}
      {tab === 'brain' && (
        <div>
          <div className="flex flex-wrap gap-3 mb-4">
            <input
              type="text"
              placeholder="Search knowledge..."
              value={search}
              onChange={e => { setSearch(e.target.value); setPage(1) }}
              className="flex-1 min-w-[200px] bg-white/5 border border-white/10 rounded-lg px-4 py-2 text-sm outline-none focus:border-violet-500"
            />
            <button onClick={() => setShowAdd(true)} className="bg-violet-600 hover:bg-violet-700 px-4 py-2 rounded-lg text-sm font-medium transition">
              + Add Knowledge
            </button>
            <button onClick={handleClearLearned} className="bg-red-600/20 hover:bg-red-600/30 text-red-400 px-4 py-2 rounded-lg text-sm transition border border-red-500/20">
              Clear Auto-Learned
            </button>
          </div>

          {/* Add Entry Modal */}
          {showAdd && (
            <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/70 p-4">
              <div className="bg-[#12121a] border border-white/10 rounded-2xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
                <h3 className="text-lg font-bold mb-4 text-violet-400">Add Knowledge Entry</h3>
                <div className="space-y-3">
                  <input placeholder="Question / Trigger phrase" value={addForm.question} onChange={e => setAddForm(p => ({ ...p, question: e.target.value }))} className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-violet-500" />
                  <textarea placeholder="Answer / Response" rows={5} value={addForm.answer} onChange={e => setAddForm(p => ({ ...p, answer: e.target.value }))} className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-violet-500 resize-none" />
                  <input placeholder="Category (e.g. gfxstore, coding, general)" value={addForm.category} onChange={e => setAddForm(p => ({ ...p, category: e.target.value }))} className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-violet-500" />
                  <input placeholder="Keywords (optional, auto-generated if empty)" value={addForm.keywords} onChange={e => setAddForm(p => ({ ...p, keywords: e.target.value }))} className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-violet-500" />
                </div>
                <div className="flex gap-3 mt-4">
                  <button onClick={handleAdd} className="flex-1 bg-violet-600 hover:bg-violet-700 py-2 rounded-lg text-sm font-medium transition">Save to Brain</button>
                  <button onClick={() => setShowAdd(false)} className="flex-1 bg-white/5 hover:bg-white/10 py-2 rounded-lg text-sm transition">Cancel</button>
                </div>
              </div>
            </div>
          )}

          {/* Edit Entry Modal */}
          {editEntry && (
            <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/70 p-4">
              <div className="bg-[#12121a] border border-white/10 rounded-2xl p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
                <h3 className="text-lg font-bold mb-4 text-blue-400">Edit Knowledge Entry</h3>
                <div className="space-y-3">
                  <input value={editEntry.question} onChange={e => setEditEntry(p => p ? { ...p, question: e.target.value } : p)} className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-blue-500" />
                  <textarea rows={5} value={editEntry.answer} onChange={e => setEditEntry(p => p ? { ...p, answer: e.target.value } : p)} className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-blue-500 resize-none" />
                  <div className="grid grid-cols-2 gap-3">
                    <input placeholder="Category" value={editEntry.category} onChange={e => setEditEntry(p => p ? { ...p, category: e.target.value } : p)} className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-blue-500" />
                    <input placeholder="Confidence (0-1)" type="number" step="0.1" min="0" max="1" value={editEntry.confidence} onChange={e => setEditEntry(p => p ? { ...p, confidence: parseFloat(e.target.value) } : p)} className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-blue-500" />
                  </div>
                  <label className="flex items-center gap-2 text-sm text-gray-400">
                    <input type="checkbox" checked={editEntry.isActive} onChange={e => setEditEntry(p => p ? { ...p, isActive: e.target.checked } : p)} />
                    Active
                  </label>
                </div>
                <div className="flex gap-3 mt-4">
                  <button onClick={handleUpdate} className="flex-1 bg-blue-600 hover:bg-blue-700 py-2 rounded-lg text-sm font-medium transition">Update</button>
                  <button onClick={() => setEditEntry(null)} className="flex-1 bg-white/5 hover:bg-white/10 py-2 rounded-lg text-sm transition">Cancel</button>
                </div>
              </div>
            </div>
          )}

          {/* Entries Table */}
          {loading ? (
            <div className="text-center py-16 text-gray-500">Loading brain...</div>
          ) : (
            <div className="space-y-2">
              {entries.map(e => (
                <div key={e.id} className={`bg-white/5 border rounded-xl p-4 ${e.isActive ? 'border-white/10' : 'border-red-500/20 opacity-60'}`}>
                  <div className="flex flex-wrap items-start gap-2 mb-2">
                    <span className={`text-xs px-2 py-0.5 rounded-full border font-medium ${SOURCE_COLORS[e.source] || 'bg-white/10 text-gray-300 border-white/10'}`}>
                      {e.source}
                    </span>
                    <span className="text-xs px-2 py-0.5 rounded-full bg-white/10 text-gray-300">{e.category}</span>
                    <span className="text-xs text-gray-500">used {e.usageCount}×</span>
                    <span className="text-xs text-gray-500">conf: {e.confidence.toFixed(2)}</span>
                    <div className="ml-auto flex gap-2">
                      <button onClick={() => setEditEntry(e)} className="text-xs text-blue-400 hover:text-blue-300 px-2 py-1 bg-blue-500/10 rounded">Edit</button>
                      <button onClick={() => handleDelete(e.id)} className="text-xs text-red-400 hover:text-red-300 px-2 py-1 bg-red-500/10 rounded">Delete</button>
                    </div>
                  </div>
                  <p className="text-sm font-medium text-white mb-1">Q: {e.question}</p>
                  <p className="text-sm text-gray-400 line-clamp-2">A: {e.answer}</p>
                </div>
              ))}
              {entries.length === 0 && !loading && (
                <div className="text-center py-16 text-gray-500">
                  <div className="text-4xl mb-3">🧠</div>
                  <p>No entries yet. Start by adding knowledge or chatting — the AI learns automatically.</p>
                </div>
              )}
            </div>
          )}

          {/* Pagination */}
          {total > 20 && (
            <div className="flex gap-2 mt-6 justify-center">
              {Array.from({ length: Math.ceil(total / 20) }, (_, i) => (
                <button key={i} onClick={() => setPage(i + 1)} className={`px-3 py-1 rounded-lg text-sm ${page === i + 1 ? 'bg-violet-600' : 'bg-white/5 hover:bg-white/10'}`}>{i + 1}</button>
              )).slice(Math.max(0, page - 3), page + 3)}
            </div>
          )}
        </div>
      )}

      {/* ── CONFIG TAB ───────────────────────────────────────────────── */}
      {tab === 'config' && (
        <div className="max-w-2xl space-y-6">
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
            <h3 className="text-lg font-bold mb-4 text-violet-400">AI Personality & System Prompt</h3>
            <div className="space-y-4">
              <div>
                <label className="text-sm text-gray-400 mb-2 block">Personality Style</label>
                <div className="flex flex-wrap gap-2">
                  {PERSONALITIES.map(p => (
                    <button key={p} onClick={() => setConfigDraft(prev => ({ ...prev, personality: p }))}
                      className={`px-3 py-1.5 rounded-lg text-sm capitalize transition ${configDraft.personality === p ? 'bg-violet-600 text-white' : 'bg-white/5 text-gray-400 hover:bg-white/10'}`}>
                      {p}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="text-sm text-gray-400 mb-2 block">Custom System Prompt (Admin Training Instructions)</label>
                <textarea
                  rows={8}
                  placeholder="Enter instructions to customize GfxV1's behavior. Example: Always respond in Bengali. You specialize in GfxStore products..."
                  value={configDraft.systemPrompt}
                  onChange={e => setConfigDraft(p => ({ ...p, systemPrompt: e.target.value }))}
                  className="w-full bg-black/30 border border-white/10 rounded-xl px-4 py-3 text-sm outline-none focus:border-violet-500 resize-none font-mono"
                />
              </div>
              <div>
                <label className="text-sm text-gray-400 mb-2 block">Version String</label>
                <input value={configDraft.version} onChange={e => setConfigDraft(p => ({ ...p, version: e.target.value }))}
                  className="w-full bg-white/5 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-violet-500" />
              </div>
              <button onClick={handleSaveConfig} disabled={savingConfig}
                className="w-full bg-violet-600 hover:bg-violet-700 disabled:opacity-50 py-3 rounded-xl font-medium transition">
                {savingConfig ? 'Saving...' : 'Save Configuration'}
              </button>
            </div>
          </div>
          {config && (
            <div className="bg-white/5 border border-white/10 rounded-xl p-4 text-sm text-gray-400">
              <div className="grid grid-cols-2 gap-4">
                <div>Total Responses: <span className="text-white font-medium">{config.totalResponses?.toLocaleString()}</span></div>
                <div>AI Usages Today: <span className="text-white font-medium">{stats?.aiUsages?.toLocaleString()}</span></div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ── IMPORT TAB ───────────────────────────────────────────────── */}
      {tab === 'import' && (
        <div className="max-w-2xl space-y-6">
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
            <h3 className="text-lg font-bold mb-2 text-violet-400">Bulk Import Training Data</h3>
            <p className="text-sm text-gray-400 mb-4">Paste JSON array or Q:/A: line format. AI will learn from all entries.</p>
            <div className="text-xs text-gray-500 mb-4 bg-black/30 rounded-lg p-3 font-mono">
              {`// JSON format:\n[{"question":"What is GfxStore?","answer":"GfxStore is...","category":"gfxstore"},...]`}<br/>
              {`\n// OR Q/A line format:\nQ: What is GfxStore?\nA: GfxStore is the best digital marketplace...`}
            </div>
            <textarea
              rows={12}
              placeholder='[{"question": "...", "answer": "...", "category": "general"}]'
              value={bulkText}
              onChange={e => setBulkText(e.target.value)}
              className="w-full bg-black/30 border border-white/10 rounded-xl px-4 py-3 text-sm outline-none focus:border-violet-500 resize-none font-mono"
            />
            {importResult && <div className="mt-2 text-emerald-400 text-sm">{importResult}</div>}
            <button onClick={handleBulkImport} className="mt-4 w-full bg-violet-600 hover:bg-violet-700 py-3 rounded-xl font-medium transition">
              Import to Brain
            </button>
          </div>
        </div>
      )}

      {/* ── MEMORIES TAB ─────────────────────────────────────────────── */}
      {tab === 'memories' && <MemoriesTab stats={stats} showToast={showToast} />}
    </div>
  )
}

function MemoriesTab({ stats, showToast }: { stats: Stats | null; showToast: (m: string, t?: 'ok' | 'err') => void }) {
  const [memories, setMemories] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [userId, setUserId] = useState('')

  const fetchMemories = async () => {
    setLoading(true)
    const params = new URLSearchParams({ action: 'memories' })
    if (userId) params.set('userId', userId)
    const r = await fetch(`/api/admin/ai-training?${params}`).then(r => r.json()).catch(() => ({ memories: [] }))
    setMemories(r.memories || [])
    setLoading(false)
  }

  useEffect(() => { fetchMemories() }, [])

  const clearMemories = async () => {
    if (!confirm('Clear all conversation memories?')) return
    const r = await fetch('/api/admin/ai-training', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'clear-memories', userId: userId || undefined }) }).then(r => r.json())
    if (r.success) { showToast(`Cleared ${r.deleted} memories`); fetchMemories() }
    else showToast(r.error || 'Failed', 'err')
  }

  return (
    <div>
      <div className="flex gap-3 mb-4">
        <input type="text" placeholder="Filter by User ID (optional)" value={userId} onChange={e => setUserId(e.target.value)}
          className="flex-1 bg-white/5 border border-white/10 rounded-lg px-4 py-2 text-sm outline-none focus:border-violet-500" />
        <button onClick={fetchMemories} className="bg-violet-600 hover:bg-violet-700 px-4 py-2 rounded-lg text-sm transition">Filter</button>
        <button onClick={clearMemories} className="bg-red-600/20 hover:bg-red-600/30 text-red-400 px-4 py-2 rounded-lg text-sm transition border border-red-500/20">Clear</button>
      </div>
      {loading ? <div className="text-center py-16 text-gray-500">Loading...</div> : (
        <div className="space-y-2 max-h-[600px] overflow-y-auto">
          {memories.map((m: any) => (
            <div key={m.id} className={`rounded-xl px-4 py-3 text-sm ${m.role === 'user' ? 'bg-blue-500/10 border border-blue-500/20 text-blue-200' : 'bg-violet-500/10 border border-violet-500/20 text-violet-200'}`}>
              <div className="flex gap-2 text-xs opacity-60 mb-1">
                <span className="font-bold uppercase">{m.role}</span>
                <span>{m.sessionId}</span>
                <span>{new Date(m.createdAt).toLocaleString()}</span>
              </div>
              <p>{m.content}</p>
            </div>
          ))}
          {memories.length === 0 && <div className="text-center py-16 text-gray-500">No conversation memories yet.</div>}
        </div>
      )}
    </div>
  )
}
