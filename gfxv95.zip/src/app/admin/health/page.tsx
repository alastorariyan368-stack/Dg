'use client'
import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Activity, Cpu, HardDrive, MemoryStick, Server, Shield, Users, MessageSquare, ShoppingBag, AlertTriangle, RefreshCcw, Wifi } from 'lucide-react'
import { toast } from 'sonner'

function fmt(bytes: number) {
  if (!bytes) return '0 B'
  const u = ['B', 'KB', 'MB', 'GB', 'TB']; let i = 0; let n = bytes
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++ }
  return `${n.toFixed(n >= 100 ? 0 : 1)} ${u[i]}`
}
function fmtTime(s: number) {
  const d = Math.floor(s / 86400), h = Math.floor((s % 86400) / 3600), m = Math.floor((s % 3600) / 60)
  if (d) return `${d}d ${h}h`; if (h) return `${h}h ${m}m`; return `${m}m`
}

export default function HealthPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [data, setData] = useState<any>(null)
  const [auto, setAuto] = useState(true)

  useEffect(() => {
    if (status === 'authenticated' && (session.user as any).role !== 'ADMIN' && (session.user as any).role !== 'SUPER_ADMIN') router.push('/')
  }, [session, status, router])

  async function load() {
    try {
      const r = await fetch('/api/admin/health', { cache: 'no-store' })
      if (r.ok) setData(await r.json())
    } catch {}
  }
  useEffect(() => { load() }, [])
  useEffect(() => {
    if (!auto) return
    const t = setInterval(load, 5000)
    return () => clearInterval(t)
  }, [auto])

  async function clearCounters() {
    if (!confirm('Clear request and threat counters?')) return
    const r = await fetch('/api/admin/health', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ action: 'clear' }) })
    if (r.ok) { toast.success('Counters cleared'); load() }
  }

  if (!session) return null
  if (!data) return <div className="py-20 text-center">Loading…</div>

  const memPct = data.memory.percent
  const diskPct = data.disk.percent
  const cpuPct = data.system.cpuPercent

  return (
    <div className="container max-w-7xl mx-auto py-6 px-4">
      <div className="flex items-center justify-between mb-6 flex-wrap gap-3">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2"><Activity className="w-8 h-8 text-emerald-500" /> System Health</h1>
          <p className="text-muted-foreground">Live monitoring · refreshes every 5s</p>
        </div>
        <div className="flex gap-2 items-center">
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" checked={auto} onChange={e => setAuto(e.target.checked)} /> Auto-refresh
          </label>
          <Button size="sm" variant="outline" onClick={load} className="gap-1"><RefreshCcw className="w-4 h-4" /> Refresh</Button>
          <Button size="sm" variant="destructive" onClick={clearCounters}>Clear counters</Button>
        </div>
      </div>

      {/* Top metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
        <Metric icon={<Cpu />} label="CPU" value={`${cpuPct.toFixed(1)}%`} sub={`${data.system.cpuCount} cores · load ${data.system.load1.toFixed(2)}`} pct={cpuPct} color="from-blue-500 to-cyan-500" />
        <Metric icon={<MemoryStick />} label="Memory" value={`${memPct}%`} sub={`${fmt(data.memory.used)} / ${fmt(data.memory.total)}`} pct={memPct} color="from-purple-500 to-pink-500" />
        <Metric icon={<HardDrive />} label="Disk" value={`${diskPct}%`} sub={`${fmt(data.disk.used)} / ${fmt(data.disk.total)}`} pct={diskPct} color="from-amber-500 to-orange-500" />
        <Metric icon={<Server />} label="Uptime" value={fmtTime(data.process.uptimeSec)} sub={`Sys ${fmtTime(data.system.uptimeSec)}`} color="from-emerald-500 to-teal-500" />
      </div>

      {/* Traffic + DB */}
      <div className="grid lg:grid-cols-3 gap-3 mb-6">
        <Card className="p-5">
          <div className="flex items-center gap-2 mb-3"><Wifi className="w-5 h-5 text-blue-500" /><h3 className="font-semibold">Traffic</h3></div>
          <Stat label="Requests / minute" value={data.traffic.requestsPerMinute} accent="text-blue-500" />
          <Stat label="Total requests" value={data.traffic.totalRequests} />
          <Stat label="Active sockets" value={data.traffic.activeSockets} accent="text-emerald-500" />
          <Stat label="Errors / minute" value={data.traffic.errorsPerMinute} accent={data.traffic.errorsPerMinute > 0 ? 'text-red-500' : 'text-muted-foreground'} />
          <Stat label="Total errors" value={data.traffic.totalErrors} />
        </Card>

        <Card className="p-5">
          <div className="flex items-center gap-2 mb-3"><Shield className="w-5 h-5 text-red-500" /><h3 className="font-semibold">Threats (24h)</h3></div>
          <div className="text-3xl font-bold mb-2">{data.threats.last24h}</div>
          {data.threats.recent.length === 0 ? (
            <p className="text-sm text-muted-foreground">✅ No threats detected</p>
          ) : (
            <div className="space-y-1.5 max-h-48 overflow-y-auto text-sm">
              {data.threats.recent.map((t: any, i: number) => (
                <div key={i} className="flex items-start gap-2 p-2 rounded bg-red-500/10 border border-red-500/20">
                  <AlertTriangle className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
                  <div className="flex-1 min-w-0">
                    <div className="font-medium text-red-700 dark:text-red-300">{t.reason}</div>
                    <div className="text-xs text-muted-foreground">{t.ip} · {t.path}</div>
                    <div className="text-xs text-muted-foreground">{new Date(t.at).toLocaleString()}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        <Card className="p-5">
          <div className="flex items-center gap-2 mb-3"><Activity className="w-5 h-5 text-purple-500" /><h3 className="font-semibold">Database</h3></div>
          <Stat label={<><Users className="w-3 h-3 inline mr-1" /> Users</>} value={data.db.users} />
          <Stat label={<><ShoppingBag className="w-3 h-3 inline mr-1" /> Orders</>} value={data.db.orders} />
          <Stat label={<><MessageSquare className="w-3 h-3 inline mr-1" /> Messages</>} value={data.db.messages} />
          <Stat label="Tickets" value={data.db.tickets} />
        </Card>
      </div>

      {/* Process & system info */}
      <div className="grid lg:grid-cols-2 gap-3">
        <Card className="p-5">
          <h3 className="font-semibold mb-3">Process</h3>
          <Row label="PID" value={data.process.pid} />
          <Row label="Node" value={data.process.node} />
          <Row label="Environment" value={<Badge>{data.process.env}</Badge>} />
          <Row label="Heap used" value={fmt(data.memory.proc.heapUsed)} />
          <Row label="Heap total" value={fmt(data.memory.proc.heapTotal)} />
          <Row label="RSS" value={fmt(data.memory.proc.rss)} />
          <Row label="Started" value={new Date(data.process.bootedAt).toLocaleString()} />
        </Card>
        <Card className="p-5">
          <h3 className="font-semibold mb-3">System</h3>
          <Row label="Hostname" value={data.system.hostname} />
          <Row label="Platform" value={`${data.system.platform} · ${data.system.arch}`} />
          <Row label="CPU model" value={<span className="truncate">{data.system.cpuModel}</span>} />
          <Row label="Cores" value={data.system.cpuCount} />
          <Row label="Load (1/5/15m)" value={`${data.system.load1.toFixed(2)} / ${data.system.load5.toFixed(2)} / ${data.system.load15.toFixed(2)}`} />
          <Row label="Free memory" value={fmt(data.memory.free)} />
          <Row label="Free disk" value={fmt(data.disk.free)} />
        </Card>
      </div>

      <p className="text-xs text-muted-foreground text-center mt-6">Snapshot at {new Date(data.timestamp).toLocaleString()}</p>
    </div>
  )
}

function Metric({ icon, label, value, sub, pct, color }: any) {
  return (
    <Card className="p-4 relative overflow-hidden">
      <div className={`absolute inset-0 bg-gradient-to-br ${color} opacity-5`} />
      <div className="relative">
        <div className="flex items-center justify-between mb-2">
          <div className={`p-2 rounded-lg bg-gradient-to-br ${color} text-white`}>{icon}</div>
          {typeof pct === 'number' && (
            <Badge variant={pct > 80 ? 'destructive' : pct > 60 ? 'default' : 'secondary'}>{pct > 80 ? 'High' : pct > 60 ? 'Warm' : 'OK'}</Badge>
          )}
        </div>
        <div className="text-xs text-muted-foreground">{label}</div>
        <div className="text-2xl font-bold mt-0.5">{value}</div>
        <div className="text-xs text-muted-foreground mt-0.5">{sub}</div>
        {typeof pct === 'number' && <Progress value={pct} className="mt-2 h-1.5" />}
      </div>
    </Card>
  )
}
function Stat({ label, value, accent }: any) {
  return (
    <div className="flex items-center justify-between py-1.5 border-b last:border-0">
      <span className="text-sm text-muted-foreground">{label}</span>
      <span className={`font-semibold ${accent || ''}`}>{value}</span>
    </div>
  )
}
function Row({ label, value }: any) {
  return (
    <div className="flex items-center justify-between py-1.5 text-sm border-b last:border-0">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium truncate ml-2">{value}</span>
    </div>
  )
}
