'use client'
import { useState, useEffect } from 'react'
import { Phone, Plus, Trash2, ToggleLeft, ToggleRight, RefreshCw, Copy, Check, Pencil, X } from 'lucide-react'

interface Config {
  id: string; countryCode: string; countryName: string; numberPrefix: string
  isActive: boolean; expiryMinutes: number; maxPerUser: number; createdAt: string
}
interface Stats { phoneCount: number; msgCount: number }

const PRESET_COUNTRIES = [
  { countryCode: 'US', countryName: 'United States', numberPrefix: '+1' },
  { countryCode: 'UK', countryName: 'United Kingdom', numberPrefix: '+44' },
  { countryCode: 'DE', countryName: 'Germany', numberPrefix: '+49' },
  { countryCode: 'FR', countryName: 'France', numberPrefix: '+33' },
  { countryCode: 'IN', countryName: 'India', numberPrefix: '+91' },
  { countryCode: 'BD', countryName: 'Bangladesh', numberPrefix: '+880' },
]

export default function AdminTempNumPage() {
  const [configs, setConfigs] = useState<Config[]>([])
  const [stats, setStats] = useState<Stats>({ phoneCount: 0, msgCount: 0 })
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [editing, setEditing] = useState<Config | null>(null)
  const [form, setForm] = useState({ countryCode: '', countryName: '', numberPrefix: '', expiryMinutes: 30, maxPerUser: 3 })
  const [copied, setCopied] = useState('')

  const load = async () => {
    setLoading(true)
    const r = await fetch('/api/admin/tempnum')
    const data = await r.json()
    setConfigs(data.configs || [])
    setStats(data.stats || {})
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  const addConfig = async () => {
    if (!form.countryCode || !form.countryName || !form.numberPrefix) {
      setError('All fields are required'); return
    }
    setSaving(true); setError('')
    const r = await fetch('/api/admin/tempnum', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    })
    const data = await r.json()
    if (!r.ok) { setError(data.error); setSaving(false); return }
    setForm({ countryCode: '', countryName: '', numberPrefix: '', expiryMinutes: 30, maxPerUser: 3 })
    setSaving(false); load()
  }

  const updateConfig = async () => {
    if (!editing) return
    setSaving(true)
    await fetch('/api/admin/tempnum', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id: editing.id, ...form }),
    })
    setEditing(null)
    setSaving(false); load()
  }

  const toggleConfig = async (id: string, isActive: boolean) => {
    await fetch('/api/admin/tempnum', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, isActive }),
    })
    load()
  }

  const deleteConfig = async (id: string) => {
    if (!confirm('Delete this country config? All numbers will be removed.')) return
    await fetch('/api/admin/tempnum', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id }),
    })
    load()
  }

  const startEdit = (c: Config) => {
    setEditing(c)
    setForm({ countryCode: c.countryCode, countryName: c.countryName, numberPrefix: c.numberPrefix, expiryMinutes: c.expiryMinutes, maxPerUser: c.maxPerUser })
  }

  const webhookUrl = typeof window !== 'undefined' ? `${window.location.origin}/api/tempnum/receive` : '/api/tempnum/receive'

  return (
    <div className="min-h-screen bg-gray-950 text-white p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <div className="p-2 bg-green-500/20 rounded-lg">
            <Phone className="w-6 h-6 text-green-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Temp Number Config</h1>
            <p className="text-gray-400 text-sm">Manage country configs and SMS webhook</p>
          </div>
          <button onClick={load} className="ml-auto p-2 rounded-lg bg-white/5 hover:bg-white/10 transition">
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          {[
            { label: 'Active Countries', value: configs.filter(c => c.isActive).length },
            { label: 'Numbers Generated', value: stats.phoneCount },
            { label: 'SMS Received', value: stats.msgCount },
          ].map(s => (
            <div key={s.label} className="bg-white/5 rounded-xl p-4 border border-white/10">
              <div className="text-2xl font-bold text-green-400">{s.value}</div>
              <div className="text-gray-400 text-sm mt-1">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Webhook Info */}
        <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-4 mb-6">
          <h3 className="font-semibold text-amber-400 mb-2">📱 SMS Webhook</h3>
          <p className="text-gray-300 text-sm mb-3">
            Configure your SMS gateway (Twilio, Vonage, etc.) to POST incoming messages:
          </p>
          <div className="flex items-center gap-2 bg-black/30 rounded-lg px-3 py-2">
            <code className="text-green-400 text-sm flex-1 break-all">{webhookUrl}</code>
            <button onClick={() => { navigator.clipboard.writeText(webhookUrl); setCopied('wh'); setTimeout(() => setCopied(''), 2000) }} className="shrink-0 p-1 rounded hover:bg-white/10">
              {copied === 'wh' ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4 text-gray-400" />}
            </button>
          </div>
          <p className="text-gray-500 text-xs mt-2">
            Required fields: <code className="text-gray-300">to, from, body, secret</code>.
            Set <code className="text-gray-300">TEMPNUM_WEBHOOK_SECRET</code> in .env
          </p>
        </div>

        {/* Preset Quick-Add */}
        <div className="bg-white/5 rounded-xl p-4 border border-white/10 mb-6">
          <h3 className="font-semibold mb-3 text-sm text-gray-300">Quick Add Presets</h3>
          <div className="flex flex-wrap gap-2">
            {PRESET_COUNTRIES.filter(p => !configs.find(c => c.countryCode === p.countryCode)).map(p => (
              <button
                key={p.countryCode}
                onClick={() => setForm({ ...p, expiryMinutes: 30, maxPerUser: 3 })}
                className="px-3 py-1.5 text-xs bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg transition"
              >
                {p.countryName} ({p.countryCode})
              </button>
            ))}
          </div>
        </div>

        {/* Add / Edit Form */}
        <div className="bg-white/5 rounded-xl p-5 border border-white/10 mb-6">
          <h3 className="font-semibold mb-4">{editing ? '✏️ Edit Country Config' : 'Add Country Config'}</h3>
          <div className="grid grid-cols-2 gap-3 mb-3">
            <div>
              <label className="text-xs text-gray-400 mb-1 block">Country Code</label>
              <input value={form.countryCode} onChange={e => setForm(f => ({ ...f, countryCode: e.target.value.toUpperCase() }))}
                placeholder="US" className="w-full bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-green-500 transition" />
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1 block">Country Name</label>
              <input value={form.countryName} onChange={e => setForm(f => ({ ...f, countryName: e.target.value }))}
                placeholder="United States" className="w-full bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-green-500 transition" />
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1 block">Number Prefix</label>
              <input value={form.numberPrefix} onChange={e => setForm(f => ({ ...f, numberPrefix: e.target.value }))}
                placeholder="+1" className="w-full bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-green-500 transition" />
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1 block">Expiry (minutes)</label>
              <input type="number" value={form.expiryMinutes} onChange={e => setForm(f => ({ ...f, expiryMinutes: +e.target.value }))}
                className="w-full bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-green-500 transition" />
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1 block">Max per User</label>
              <input type="number" value={form.maxPerUser} onChange={e => setForm(f => ({ ...f, maxPerUser: +e.target.value }))}
                className="w-full bg-black/30 border border-white/10 rounded-lg px-3 py-2 text-sm outline-none focus:border-green-500 transition" />
            </div>
          </div>
          {error && <p className="text-red-400 text-sm mb-3">{error}</p>}
          <div className="flex gap-2">
            <button onClick={editing ? updateConfig : addConfig} disabled={saving}
              className="flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-500 disabled:opacity-50 rounded-lg text-sm font-medium transition">
              <Plus className="w-4 h-4" />
              {saving ? 'Saving...' : editing ? 'Update' : 'Add Country'}
            </button>
            {editing && (
              <button onClick={() => { setEditing(null); setForm({ countryCode: '', countryName: '', numberPrefix: '', expiryMinutes: 30, maxPerUser: 3 }) }}
                className="px-4 py-2 bg-white/10 hover:bg-white/15 rounded-lg text-sm transition">
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* Configs List */}
        <div className="space-y-3">
          <h3 className="font-semibold text-gray-300">Country Configs ({configs.length})</h3>
          {loading ? <div className="text-center py-8 text-gray-500">Loading...</div>
            : configs.length === 0 ? (
              <div className="text-center py-12 bg-white/3 rounded-xl border border-white/5 text-gray-500">
                No countries configured. Add one above.
              </div>
            ) : configs.map(c => (
              <div key={c.id} className="flex items-center gap-3 bg-white/5 rounded-xl px-4 py-3 border border-white/10">
                <div className={`w-2 h-2 rounded-full shrink-0 ${c.isActive ? 'bg-green-400' : 'bg-gray-600'}`} />
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm">{c.countryName} <span className="text-gray-400">({c.countryCode})</span></div>
                  <div className="text-xs text-gray-500">
                    Prefix: <span className="text-gray-300 font-mono">{c.numberPrefix}</span>
                    {' · '}Expiry: <span className="text-gray-300">{c.expiryMinutes}m</span>
                    {' · '}Max/user: <span className="text-gray-300">{c.maxPerUser}</span>
                  </div>
                </div>
                <span className={`text-xs px-2 py-0.5 rounded-full ${c.isActive ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'}`}>
                  {c.isActive ? 'Active' : 'Disabled'}
                </span>
                <button onClick={() => startEdit(c)} className="p-1.5 rounded-lg hover:bg-white/10 transition">
                  <Pencil className="w-4 h-4 text-gray-400" />
                </button>
                <button onClick={() => toggleConfig(c.id, !c.isActive)} className="p-1.5 rounded-lg hover:bg-white/10 transition">
                  {c.isActive ? <ToggleRight className="w-5 h-5 text-green-400" /> : <ToggleLeft className="w-5 h-5 text-gray-500" />}
                </button>
                <button onClick={() => deleteConfig(c.id)} className="p-1.5 rounded-lg hover:bg-red-500/20 text-red-400 transition">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
        </div>
      </div>
    </div>
  )
}
