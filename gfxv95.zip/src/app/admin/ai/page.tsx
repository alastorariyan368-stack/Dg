'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { 
  Sparkles, Settings, Shield, MessageSquare, Database,
  Save, Loader2, Zap, Info, Activity, Users, Key, Bot, Trash2,
  ChevronRight as ChevronRightIcon
} from 'lucide-react'
import { toast } from 'sonner'

export default function AdminAiDashboard() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [stats, setStats] = useState({ totalUsages: 0, usersCount: 0, todayUsages: 0 })
  const [model, setModel] = useState<any>(null)
  const [newPair, setNewPair] = useState({ q: '', a: '' })
  const [isAdding, setIsAdding] = useState(false)

  useEffect(() => {
    const role = (session?.user as any)?.role
    if (status === 'unauthenticated' || !['ADMIN', 'SUPER_ADMIN'].includes(role)) {
      router.push('/')
      return
    }
    fetchData()
  }, [status])

  const fetchData = async () => {
    try {
      const [statsRes, modelRes] = await Promise.all([
        fetch('/api/admin/ai/stats'),
        fetch('/api/admin/ai/model')
      ])
      if (statsRes.ok) setStats(await statsRes.json())
      if (modelRes.ok) setModel(await modelRes.json())
    } catch { toast.error('Failed to load AI data') }
    finally { setLoading(false) }
  }

  const handleSave = async () => {
    setSaving(true)
    try {
      const res = await fetch('/api/admin/ai/model', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(model)
      })
      if (res.ok) toast.success('AI settings updated!')
      else toast.error('Update failed')
    } catch { toast.error('Error saving settings') }
    finally { setSaving(false) }
  }

  const addTrainingPair = () => {
    if (!newPair.q || !newPair.a) { toast.error('Fill both fields'); return }
    const currentData = Array.isArray(model.trainingData) ? model.trainingData : []
    const updatedData = [...currentData, newPair]
    setModel({ ...model, trainingData: updatedData })
    setNewPair({ q: '', a: '' })
    setIsAdding(false)
    toast.info('Training pair added locally. Click Save to apply.')
  }

  const removeTrainingPair = (index: number) => {
    const updatedData = [...model.trainingData]
    updatedData.splice(index, 1)
    setModel({ ...model, trainingData: updatedData })
  }

  if (loading) return <div className="min-h-screen bg-[#06060c] flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin text-purple-400" /></div>

  return (
    <div className="min-h-screen bg-[#06060c] text-white">
      <Navbar />
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-black flex items-center gap-3">
              <Sparkles className="w-8 h-8 text-purple-400" /> GFXV1 Control Center
            </h1>
            <p className="text-white/40 text-sm mt-1">Manage multimodal AI capabilities, limits, and training.</p>
          </div>
          <Button onClick={handleSave} disabled={saving} className="bg-gradient-to-r from-purple-600 to-blue-600 rounded-xl gap-2 font-bold px-6 h-12">
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            Save Changes
          </Button>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Total AI Usages', value: stats.totalUsages, icon: Activity, color: 'text-blue-400' },
            { label: 'Active AI Users', value: stats.usersCount, icon: Users, color: 'text-purple-400' },
            { label: 'Usages Today', value: stats.todayUsages, icon: Zap, color: 'text-yellow-400' },
            { label: 'Model Status', value: model?.isActive ? 'ONLINE' : 'OFFLINE', icon: Shield, color: model?.isActive ? 'text-emerald-400' : 'text-red-400' },
          ].map((s, i) => (
            <Card key={i} className="bg-white/[0.03] border-white/10 p-6 rounded-[24px]">
              <s.icon className={`w-5 h-5 ${s.color} mb-4`} />
              <p className="text-white/40 text-[10px] uppercase font-bold tracking-widest">{s.label}</p>
              <p className="text-2xl font-black mt-1">{s.value}</p>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Settings */}
          <div className="lg:col-span-2 space-y-8">
            <Card className="bg-white/[0.03] border-white/10 rounded-[32px] overflow-hidden">
              <CardHeader className="border-b border-white/5 bg-white/[0.01] p-6">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Settings className="w-5 h-5 text-purple-400" /> Core Configuration
                </CardTitle>
                <CardDescription className="text-white/40">Adjust GFXV1 base settings and operational status.</CardDescription>
              </CardHeader>
              <CardContent className="p-8 space-y-6">
                <div className="flex items-center justify-between p-4 rounded-2xl bg-white/[0.02] border border-white/5">
                  <div>
                    <p className="font-bold">Model Status</p>
                    <p className="text-xs text-white/40">Turn GFXV1 availability on or off for users.</p>
                  </div>
                  <button 
                    onClick={() => setModel({...model, isActive: !model.isActive})}
                    className={`w-12 h-6 rounded-full transition-all relative ${model?.isActive ? 'bg-emerald-500' : 'bg-white/10'}`}
                  >
                    <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${model?.isActive ? 'left-7' : 'left-1'}`} />
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-white/40 uppercase tracking-wider">Daily Usage Limit</label>
                    <Input 
                      type="number" 
                      value={model?.dailyLimit} 
                      onChange={e => setModel({...model, dailyLimit: parseInt(e.target.value)})}
                      className="bg-white/[0.04] border-white/10 rounded-xl h-12" 
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold text-white/40 uppercase tracking-wider">Monthly Usage Limit</label>
                    <Input 
                      type="number" 
                      value={model?.monthlyLimit} 
                      onChange={e => setModel({...model, monthlyLimit: parseInt(e.target.value)})}
                      className="bg-white/[0.04] border-white/10 rounded-xl h-12" 
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold text-white/40 uppercase tracking-wider">Model Description</label>
                  <textarea 
                    value={model?.description}
                    onChange={e => setModel({...model, description: e.target.value})}
                    className="w-full bg-white/[0.04] border border-white/10 rounded-xl p-4 text-sm min-h-[100px] focus:outline-none focus:border-purple-500/50"
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/[0.03] border-white/10 rounded-[32px] overflow-hidden">
              <CardHeader className="border-b border-white/5 bg-white/[0.01] p-6">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Database className="w-5 h-5 text-blue-400" /> Training & Knowledge Base
                </CardTitle>
                <CardDescription className="text-white/40">Manually train GFXV1 by adding custom prompt-response pairs.</CardDescription>
              </CardHeader>
              <CardContent className="p-8">
                <div className="bg-amber-500/10 border border-amber-500/20 rounded-2xl p-4 flex items-start gap-3 mb-6">
                  <Info className="w-5 h-5 text-amber-400 flex-shrink-0" />
                  <p className="text-xs text-amber-300/80 leading-relaxed">
                    Custom training data will be injected into GFXV1's base prompt. This allows you to teach the AI specific facts about GfxStore, policies, or even a custom personality.
                  </p>
                </div>
                
                <div className="space-y-4">
                  {Array.isArray(model?.trainingData) && model.trainingData.length > 0 ? (
                    <div className="space-y-3">
                      {model.trainingData.map((pair: any, i: number) => (
                        <div key={i} className="p-4 rounded-2xl bg-white/[0.02] border border-white/5 relative group">
                          <p className="text-xs font-bold text-purple-400 mb-1 flex items-center gap-2">
                            <MessageSquare className="w-3 h-3" /> User Prompt:
                          </p>
                          <p className="text-sm text-white/80 mb-3">{pair.q}</p>
                          <p className="text-xs font-bold text-blue-400 mb-1 flex items-center gap-2">
                            <Bot className="w-3 h-3" /> GFXV1 Response:
                          </p>
                          <p className="text-sm text-white/60">{pair.a}</p>
                          <button 
                            onClick={() => removeTrainingPair(i)}
                            className="absolute top-4 right-4 p-2 rounded-lg bg-red-500/10 text-red-400 opacity-0 group-hover:opacity-100 transition-all hover:bg-red-500 hover:text-white"
                          >
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                      {!isAdding && (
                        <Button 
                          variant="ghost" 
                          onClick={() => setIsAdding(true)}
                          className="w-full border border-dashed border-white/10 rounded-2xl h-12 text-white/40 hover:text-white hover:bg-white/5"
                        >
                          + Add More Training Data
                        </Button>
                      )}
                    </div>
                  ) : !isAdding ? (
                    <div className="text-center py-10 border-2 border-dashed border-white/5 rounded-[24px]">
                      <MessageSquare className="w-8 h-8 text-white/10 mx-auto mb-3" />
                      <p className="text-sm text-white/20">No custom training data added yet.</p>
                      <Button onClick={() => setIsAdding(true)} variant="ghost" className="mt-4 text-purple-400 hover:text-purple-300 text-xs">+ Add New Training Pair</Button>
                    </div>
                  ) : null}

                  {isAdding && (
                    <div className="p-6 rounded-[24px] bg-white/[0.04] border border-purple-500/30 space-y-4 animate-in fade-in slide-in-from-bottom-2">
                      <div className="space-y-2">
                        <label className="text-[10px] font-bold text-white/40 uppercase">Expected User Prompt</label>
                        <Input 
                          placeholder="e.g. Who created you?" 
                          value={newPair.q}
                          onChange={e => setNewPair({...newPair, q: e.target.value})}
                          className="bg-white/5 border-white/10 rounded-xl h-11"
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-[10px] font-bold text-white/40 uppercase">AI Response</label>
                        <textarea 
                          placeholder="e.g. I am GFXV1, created by the GfxStore team."
                          value={newPair.a}
                          onChange={e => setNewPair({...newPair, a: e.target.value})}
                          className="w-full bg-white/5 border border-white/10 rounded-xl p-3 text-sm min-h-[80px] focus:outline-none focus:border-purple-500/50"
                        />
                      </div>
                      <div className="flex gap-2">
                        <Button onClick={addTrainingPair} className="flex-1 bg-purple-600 hover:bg-purple-500 rounded-xl h-10 text-xs">Add Pair</Button>
                        <Button onClick={() => setIsAdding(false)} variant="ghost" className="flex-1 rounded-xl h-10 text-xs">Cancel</Button>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar Settings */}
          <div className="space-y-8">
            <Card className="bg-white/[0.03] border-white/10 rounded-[32px] overflow-hidden">
              <CardHeader className="border-b border-white/5 bg-white/[0.01] p-6">
                <CardTitle className="text-sm font-bold flex items-center gap-2">
                  <Key className="w-4 h-4 text-yellow-400" /> Active API Engines
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                {[
                  { name: 'Gemini Pro', status: 'Connected', type: 'Chat' },
                  { name: 'Stability AI', status: 'Connected', type: 'Image' },
                  { name: 'Pollinations', status: 'Public', type: 'Multimodal' },
                  { name: 'Runway Gen-2', status: 'Pending', type: 'Video' },
                ].map((api, i) => (
                  <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-white/[0.02] border border-white/5">
                    <div>
                      <p className="text-xs font-bold">{api.name}</p>
                      <p className="text-[10px] text-white/30 uppercase tracking-tighter">{api.type}</p>
                    </div>
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      api.status === 'Connected' ? 'bg-emerald-500/10 text-emerald-400' :
                      api.status === 'Public' ? 'bg-blue-500/10 text-blue-400' : 'bg-white/5 text-white/30'
                    }`}>
                      {api.status}
                    </span>
                  </div>
                ))}
                <Button className="w-full bg-white/5 border border-white/10 hover:bg-white/10 text-white/70 rounded-xl text-xs h-10">
                  Manage API Keys
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-purple-600/20 to-blue-600/10 border border-purple-500/20 rounded-[32px] p-6">
              <Sparkles className="w-6 h-6 text-purple-400 mb-4" />
              <h3 className="font-bold mb-2">Build Your Own AI</h3>
              <p className="text-xs text-white/50 leading-relaxed mb-4">
                GFXV1 is designed to be modular. You can switch engines, change base prompts, and even expose its API to external developers from this panel.
              </p>
              <div className="flex items-center gap-2 text-purple-400 text-xs font-bold cursor-pointer hover:underline">
                View Documentation <ChevronRightIcon className="w-3 h-3" />
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
