'use client'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Search, MessageSquare, Loader2 } from 'lucide-react'

const STATUS_COLORS: Record<string, string> = { OPEN: 'bg-emerald-500', PENDING: 'bg-amber-500', RESOLVED: 'bg-blue-500', CLOSED: 'bg-zinc-500' }
const PRIORITY_COLORS: Record<string, string> = { LOW: 'bg-zinc-500', NORMAL: 'bg-blue-500', HIGH: 'bg-orange-500', URGENT: 'bg-red-500' }

export default function AdminTicketsPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [tickets, setTickets] = useState<any[]>([])
  const [counts, setCounts] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [tab, setTab] = useState('all')
  const [q, setQ] = useState('')

  useEffect(() => {
    if (status === 'authenticated' && (session.user as any).role !== 'ADMIN' && (session.user as any).role !== 'SUPER_ADMIN') router.push('/')
  }, [session, status, router])

  async function load() {
    setLoading(true)
    try {
      const params = new URLSearchParams()
      if (tab !== 'all') params.set('status', tab.toUpperCase())
      if (q) params.set('q', q)
      const r = await fetch(`/api/admin/tickets?${params}`, { cache: 'no-store' })
      if (r.ok) { const j = await r.json(); setTickets(j.tickets || []); setCounts(j.counts || []) }
    } finally { setLoading(false) }
  }
  useEffect(() => { if (session) load() }, [session, tab])

  if (!session) return null

  const cnt = (s: string) => counts.find((c: any) => c.status === s)?._count || 0

  return (
    <div className="container max-w-6xl mx-auto py-8 px-4">
      <h1 className="text-3xl font-bold mb-1">🎫 Tickets — Admin</h1>
      <p className="text-muted-foreground mb-6">Reply to user support tickets in real time.</p>

      <div className="flex flex-col sm:flex-row gap-3 mb-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={q} onChange={e => setQ(e.target.value)} onKeyDown={e => e.key === 'Enter' && load()} placeholder="Search subject, user, email…" className="pl-9" />
        </div>
        <Tabs value={tab} onValueChange={setTab}>
          <TabsList>
            <TabsTrigger value="all">All</TabsTrigger>
            <TabsTrigger value="open">Open ({cnt('OPEN')})</TabsTrigger>
            <TabsTrigger value="pending">Pending ({cnt('PENDING')})</TabsTrigger>
            <TabsTrigger value="resolved">Resolved ({cnt('RESOLVED')})</TabsTrigger>
            <TabsTrigger value="closed">Closed ({cnt('CLOSED')})</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {loading ? (
        <div className="py-20 text-center"><Loader2 className="w-8 h-8 animate-spin mx-auto text-muted-foreground" /></div>
      ) : tickets.length === 0 ? (
        <Card className="p-12 text-center">
          <MessageSquare className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
          <p className="text-muted-foreground">No tickets here.</p>
        </Card>
      ) : (
        <div className="space-y-2">
          {tickets.map(t => (
            <Link key={t.id} href={`/admin/tickets/${t.id}`}>
              <Card className="p-4 hover:bg-accent/40 cursor-pointer transition">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 text-white grid place-items-center text-sm font-bold shrink-0">
                    {t.user?.username?.[0]?.toUpperCase() || '?'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <span className="text-xs font-mono text-muted-foreground">#{t.ticketNumber}</span>
                      <Badge className={`${STATUS_COLORS[t.status]} text-white border-0`}>{t.status}</Badge>
                      <Badge className={`${PRIORITY_COLORS[t.priority]} text-white border-0`}>{t.priority}</Badge>
                      <Badge variant="outline">{t.category}</Badge>
                    </div>
                    <h3 className="font-semibold truncate">{t.subject}</h3>
                    <div className="text-xs text-muted-foreground">{t.user?.username} • {t.user?.email}</div>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-xs text-muted-foreground">{new Date(t.updatedAt).toLocaleDateString()}</div>
                    <div className="text-xs text-muted-foreground mt-1">{t._count?.messages || 0} msgs</div>
                  </div>
                </div>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  )
}
