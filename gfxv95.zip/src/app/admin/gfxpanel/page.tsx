'use client'

import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Activity, Cpu, Database, HardDrive, Loader2, MemoryStick, RefreshCw, Save, Server, Wifi } from 'lucide-react'
import { toast } from 'sonner'

type GfxConfig = {
  gfxPanelUrl: string
  gfxDefaultNodeId: string
  gfxDefaultOs: string
  gfxDefaultUserId: string
  hasApiKey: boolean
}

export default function AdminGfxPanelPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [testing, setTesting] = useState(false)
  const [configured, setConfigured] = useState(false)
  const [panelInfo, setPanelInfo] = useState<any>(null)
  const [form, setForm] = useState({
    gfxPanelUrl: '',
    gfxPanelApiKey: '',
    gfxDefaultNodeId: '1',
    gfxDefaultOs: 'ubuntu:22.04',
    gfxDefaultUserId: '1',
  })

  useEffect(() => {
    if (status === 'loading') return
    if (status === 'unauthenticated' || (session?.user?.role !== 'ADMIN' && session?.user?.role !== 'SUPER_ADMIN')) {
      router.push('/')
      return
    }
    loadConfig()
  }, [status, session, router])

  async function loadConfig() {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/gfxpanel')
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed to load config')
      const cfg: GfxConfig = data.config
      setConfigured(data.configured)
      setPanelInfo(data.panelInfo)
      setForm((prev) => ({ ...prev, ...cfg, gfxPanelApiKey: '' }))
    } catch (error: any) {
      toast.error(error.message || 'Failed to load GFX Panel config')
    } finally {
      setLoading(false)
    }
  }

  async function saveConfig() {
    setSaving(true)
    try {
      const res = await fetch('/api/admin/gfxpanel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed to save')
      toast.success('GFX Panel config saved')
      await loadConfig()
    } catch (error: any) {
      toast.error(error.message || 'Failed to save')
    } finally {
      setSaving(false)
    }
  }

  async function testConnection() {
    setTesting(true)
    try {
      const res = await fetch('/api/admin/gfxpanel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, action: 'test' }),
      })
      const data = await res.json()
      if (!res.ok || !data.ok) throw new Error(data.error || data.data?.error || 'Connection failed')
      toast.success('GFX Panel connected')
      setPanelInfo({ info: data })
    } catch (error: any) {
      toast.error(error.message || 'Connection failed')
    } finally {
      setTesting(false)
    }
  }

  const vpsList = panelInfo?.vps?.data?.vps || panelInfo?.vps?.data?.data || []
  const nodes = panelInfo?.nodes?.data?.nodes || panelInfo?.nodes?.data?.data || []
  const activeVps = Array.isArray(vpsList) ? vpsList.filter((vps: any) => ['running', 'active'].includes(String(vps.status || vps.attributes?.status || '').toLowerCase())).length : 0
  const stoppedVps = Array.isArray(vpsList) ? vpsList.filter((vps: any) => ['stopped', 'offline'].includes(String(vps.status || vps.attributes?.status || '').toLowerCase())).length : 0

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center"><Loader2 className="h-8 w-8 animate-spin" /></div>
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1 container mx-auto px-4 py-8 space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-white flex items-center gap-2"><Server className="h-7 w-7 text-cyan-400" />GFX Panel</h1>
            <p className="text-white/50 text-sm mt-1">Connect the main website with your GFX Panel API.</p>
          </div>
          <Badge className={configured ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30' : 'bg-orange-500/15 text-orange-300 border-orange-500/30'}>
            <Wifi className="h-3 w-3 mr-1" />{configured ? 'Configured' : 'Not configured'}
          </Badge>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[
            { label: 'API Status', value: panelInfo?.info?.ok ? 'Online' : configured ? 'Check failed' : 'Not set', icon: Wifi, color: 'text-emerald-300' },
            { label: 'Nodes', value: Array.isArray(nodes) ? nodes.length : '-', icon: Database, color: 'text-cyan-300' },
            { label: 'Active VPS', value: activeVps, icon: Activity, color: 'text-green-300' },
            { label: 'Stopped VPS', value: stoppedVps, icon: Server, color: 'text-orange-300' },
          ].map(({ label, value, icon: Icon, color }) => (
            <Card key={label} className="bg-white/[0.03] border-white/10">
              <CardContent className="p-4 flex items-center gap-3">
                <div className="h-11 w-11 rounded-xl bg-white/[0.05] border border-white/10 flex items-center justify-center">
                  <Icon className={`h-5 w-5 ${color}`} />
                </div>
                <div>
                  <p className="text-xs text-white/40">{label}</p>
                  <p className="text-xl font-bold text-white">{value}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2 bg-white/[0.03] border-white/10">
            <CardHeader>
              <CardTitle>API Configuration</CardTitle>
              <CardDescription>Use an admin API key from the GFX Panel.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Panel URL</Label>
                <Input value={form.gfxPanelUrl} placeholder="https://panel.example.com" onChange={(e) => setForm({ ...form, gfxPanelUrl: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>Admin API Key {form.gfxPanelApiKey ? '' : configured ? '(saved)' : ''}</Label>
                <Input type="password" value={form.gfxPanelApiKey} placeholder={configured ? 'Leave blank to keep saved key' : 'X-API-Key'} onChange={(e) => setForm({ ...form, gfxPanelApiKey: e.target.value })} />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Default Node ID</Label>
                  <Input value={form.gfxDefaultNodeId} onChange={(e) => setForm({ ...form, gfxDefaultNodeId: e.target.value })} />
                </div>
                <div className="space-y-2">
                  <Label>Default OS</Label>
                  <Input value={form.gfxDefaultOs} onChange={(e) => setForm({ ...form, gfxDefaultOs: e.target.value })} />
                </div>
                <div className="space-y-2">
                  <Label>Default GFX User ID</Label>
                  <Input value={form.gfxDefaultUserId} onChange={(e) => setForm({ ...form, gfxDefaultUserId: e.target.value })} />
                </div>
              </div>
              <div className="flex gap-2">
                <Button onClick={saveConfig} disabled={saving} className="gap-2"><Save className="h-4 w-4" />{saving ? 'Saving...' : 'Save Config'}</Button>
                <Button variant="outline" onClick={testConnection} disabled={testing} className="gap-2"><RefreshCw className={`h-4 w-4 ${testing ? 'animate-spin' : ''}`} />Test</Button>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white/[0.03] border-white/10">
            <CardHeader>
              <CardTitle>Panel Summary</CardTitle>
              <CardDescription>Live data from GFX Panel API.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="flex justify-between"><span className="text-white/50">Nodes</span><span className="font-semibold text-white">{Array.isArray(nodes) ? nodes.length : '-'}</span></div>
              <div className="flex justify-between"><span className="text-white/50">Servers</span><span className="font-semibold text-white">{Array.isArray(vpsList) ? vpsList.length : '-'}</span></div>
              <div className="flex justify-between"><span className="text-white/50">API</span><span className="font-semibold text-white">{panelInfo?.info?.ok ? 'Online' : configured ? 'Check failed' : 'Not set'}</span></div>
              {panelInfo?.info?.data?.api?.version && <div className="flex justify-between"><span className="text-white/50">Version</span><span className="font-semibold text-white">{panelInfo.info.data.api.version}</span></div>}
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card className="bg-white/[0.03] border-white/10">
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Database className="h-5 w-5 text-cyan-400" />Nodes</CardTitle>
              <CardDescription>Available GFX Panel nodes and capacity overview.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {!Array.isArray(nodes) || nodes.length === 0 ? (
                <p className="text-sm text-white/40 py-6 text-center">No nodes returned from API.</p>
              ) : nodes.map((node: any, index: number) => {
                const item = node.attributes || node
                return (
                  <div key={item.id || index} className="rounded-xl border border-white/[0.07] bg-black/20 p-4">
                    <div className="flex items-center justify-between gap-3 mb-3">
                      <div>
                        <p className="font-semibold text-white">{item.name || item.hostname || `Node ${item.id || index + 1}`}</p>
                        <p className="text-xs text-white/40">{item.location || item.ip_address || item.address || 'GFX Node'}</p>
                      </div>
                      <Badge className="bg-emerald-500/15 text-emerald-300 border-emerald-500/30">Online</Badge>
                    </div>
                    <div className="grid grid-cols-3 gap-2 text-xs">
                      <div className="rounded-lg bg-white/[0.03] p-2"><Cpu className="h-3.5 w-3.5 text-amber-300 mb-1" />CPU<br /><span className="text-white/70">{item.cpu || item.cpu_usage || '-'}</span></div>
                      <div className="rounded-lg bg-white/[0.03] p-2"><MemoryStick className="h-3.5 w-3.5 text-cyan-300 mb-1" />RAM<br /><span className="text-white/70">{item.ram || item.memory || '-'}</span></div>
                      <div className="rounded-lg bg-white/[0.03] p-2"><HardDrive className="h-3.5 w-3.5 text-purple-300 mb-1" />Disk<br /><span className="text-white/70">{item.disk || item.storage || '-'}</span></div>
                    </div>
                  </div>
                )
              })}
            </CardContent>
          </Card>

          <Card className="bg-white/[0.03] border-white/10">
            <CardHeader>
              <CardTitle className="flex items-center gap-2"><Server className="h-5 w-5 text-cyan-400" />VPS Servers</CardTitle>
              <CardDescription>Live VPS inventory synced from GFX Panel.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {!Array.isArray(vpsList) || vpsList.length === 0 ? (
                <p className="text-sm text-white/40 py-6 text-center">No VPS servers returned from API.</p>
              ) : vpsList.slice(0, 12).map((vps: any, index: number) => {
                const item = vps.attributes || vps
                const statusText = String(item.status || 'unknown')
                return (
                  <div key={item.id || index} className="rounded-xl border border-white/[0.07] bg-black/20 p-4 flex items-center justify-between gap-3">
                    <div className="min-w-0">
                      <p className="font-semibold text-white truncate">{item.container_name || item.name || item.hostname || `VPS ${item.id || index + 1}`}</p>
                      <p className="text-xs text-white/40 truncate">{item.os_version || item.os || 'Default OS'} • {item.ram || item.memory || '-'}MB RAM • {item.cpu || '-'} CPU</p>
                    </div>
                    <Badge className={statusText.toLowerCase() === 'running' ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30' : 'bg-orange-500/15 text-orange-300 border-orange-500/30'}>{statusText}</Badge>
                  </div>
                )
              })}
            </CardContent>
          </Card>
        </div>

        {panelInfo && (
          <Card className="bg-white/[0.03] border-white/10">
            <CardHeader><CardTitle>Raw API Info</CardTitle></CardHeader>
            <CardContent><pre className="text-xs text-white/60 bg-black/30 rounded-xl p-4 overflow-auto max-h-96">{JSON.stringify(panelInfo, null, 2)}</pre></CardContent>
          </Card>
        )}
      </main>
      <Footer />
    </div>
  )
}
