import { redirect } from 'next/navigation'

export default function AdminGfxPlansPage() {
  redirect('/admin/plans')
}
