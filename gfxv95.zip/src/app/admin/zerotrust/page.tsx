'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import {
  Globe, Save, Loader2, ChevronLeft, Shield, RefreshCw, Trash2,
  CheckCircle, XCircle, Copy, ExternalLink, Info, Zap
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { toast } from 'sonner'
import Link from 'next/link'

const STATUS_COLORS: Record<string, string> = {
  ACTIVE: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
  PENDING: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
  ERROR: 'bg-red-500/10 text-red-400 border-red-500/20',
  DELETED: 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20',
}

export default function ZeroTrustAdminPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [pageLoading, setPageLoading] = useState(true)

  const [cfAccountId, setCfAccountId] = useState('')
  const [cfApiToken, setCfApiToken] = useState('')
  const [maxTunnels, setMaxTunnels] = useState('2')
  const [savingCreds, setSavingCreds] = useState(false)

  const [cfZones, setCfZones] = useState<any[]>([])
  const [allowedZones, setAllowedZones] = useState<any[]>([])
  const [zonesLoaded, setZonesLoaded] = useState(false)
  const [fetchingZones, setFetchingZones] = useState(false)
  const [savingZones, setSavingZones] = useState(false)

  const [tunnels, setTunnels] = useState<any[]>([])
  const [loadingTunnels, setLoadingTunnels] = useState(false)
  const [deleting, setDeleting] = useState<string | null>(null)

  useEffect(() => {
    if (status === 'unauthenticated') { router.push('/'); return }
    if (status === 'authenticated') {
      const role = (session?.user as any)?.role
      if (role !== 'ADMIN' && role !== 'SUPER_ADMIN') { router.push('/'); return }
      loadAll()
    }
  }, [status])

  async function loadAll() {
    setPageLoading(true)
    setLoadingTunnels(true)
    try {
      const [tunnelsRes, settingsRes] = await Promise.all([
        fetch('/api/admin/tunnels'),
        fetch('/api/admin/settings'),
      ])
      if (tunnelsRes.ok) { const d = await tunnelsRes.json(); setTunnels(d.tunnels || []) }
      if (settingsRes.ok) {
        const d = await settingsRes.json()
        setCfAccountId(d.cfAccountId || '')
        setCfApiToken(d.cfApiToken || '')
        setMaxTunnels(String(d.maxTunnelsPerUser || 2))
        setAllowedZones(d.cfAllowedZones || [])
      }
    } finally { setPageLoading(false); setLoadingTunnels(false) }
  }

  async function saveCreds() {
    setSavingCreds(true)
    try {
      const r = await fetch('/api/admin/cf-zones', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ cfAccountId, cfApiToken, maxTunnelsPerUser: parseInt(maxTunnels) || 2 }),
      })
      if (r.ok) toast.success('Cloudflare credentials saved')
      else { const d = await r.json().catch(() => ({})); toast.error(d.error || 'Failed to save credentials') }
    } finally { setSavingCreds(false) }
  }

  async function fetchZones() {
    setFetchingZones(true)
    setCfZones([]); setZonesLoaded(false)
    try {
      const r = await fetch('/api/admin/cf-zones')
      if (r.ok) {
        const d = await r.json()
        setCfZones(d.zones || [])
        setAllowedZones(d.allowedZones || [])
        setZonesLoaded(true)
        if ((d.zones || []).length === 0) toast.info('No active zones found in your Cloudflare account')
        else toast.success(`Found ${d.zones.length} domain${d.zones.length !== 1 ? 's' : ''}`)
      } else {
        const d = await r.json()
        toast.error(d.error || 'Failed to fetch zones — check your credentials')
      }
    } finally { setFetchingZones(false) }
  }

  function toggleZone(zone: any) {
    setAllowedZones(prev => {
      const exists = prev.find((z: any) => z.id === zone.id)
      if (exists) return prev.filter((z: any) => z.id !== zone.id)
      return [...prev, { id: zone.id, name: zone.name }]
    })
  }

  async function saveAllowedZones() {
    setSavingZones(true)
    try {
      const r = await fetch('/api/admin/cf-zones', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ allowedZones }),
      })
      if (r.ok) toast.success(`${allowedZones.length} domain${allowedZones.length !== 1 ? 's' : ''} enabled for users`)
      else toast.error('Failed to save domain settings')
    } finally { setSavingZones(false) }
  }

  async function deleteTunnel(id: string) {
    if (!confirm('Delete this tunnel? This will also remove it from Cloudflare.')) return
    setDeleting(id)
    try {
      const r = await fetch('/api/admin/tunnels', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      })
      if (r.ok) { toast.success('Tunnel deleted'); loadAll() }
      else toast.error('Failed to delete tunnel')
    } finally { setDeleting(null) }
  }

  function copyText(text: string) {
    navigator.clipboard.writeText(text).then(() => toast.success('Copied!'))
  }

  if (status === 'loading' || pageLoading) return (
    <div className="min-h-screen bg-[#060611] flex items-center justify-center">
      <Loader2 className="w-6 h-6 animate-spin text-orange-400" />
    </div>
  )

  return (
    <div className="min-h-screen bg-[#060611] text-white">
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <Link href="/admin" className="inline-flex items-center gap-1.5 text-white/40 hover:text-white text-sm mb-4 transition">
            <ChevronLeft className="w-4 h-4" /> Back to Admin
          </Link>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-orange-500/10 border border-orange-500/20 flex items-center justify-center">
                <Globe className="w-5 h-5 text-orange-400" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">Cloudflare Zero Trust</h1>
                <p className="text-white/40 text-sm">Configure tunnels and allowed domains for users</p>
              </div>
            </div>
            <button onClick={loadAll} className="p-2 rounded-xl text-white/30 hover:text-white hover:bg-white/[0.04] transition">
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="space-y-4">
          {/* Step 1: Credentials */}
          <div className="rounded-2xl border border-white/[0.06] bg-white/[0.02] p-5">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-5 h-5 rounded-full bg-orange-500/20 text-orange-400 text-[10px] font-bold flex items-center justify-center">1</div>
              <h3 className="text-sm font-semibold text-white">Cloudflare Credentials</h3>
            </div>
            <p className="text-[11px] text-white/40 mb-4 ml-7">
              API Token needs: <span className="text-orange-300 font-mono">Account → Cloudflare Tunnel → Edit</span> and <span className="text-orange-300 font-mono">Zone → DNS → Edit</span>
            </p>
            <div className="space-y-3">
              <div>
                <label className="text-white/40 text-[11px] mb-1.5 block">Account ID</label>
                <div className="flex gap-2">
                  <Input value={cfAccountId} onChange={e => setCfAccountId(e.target.value)}
                    placeholder="32-character account ID from Cloudflare dashboard"
                    className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl font-mono text-xs" />
                  <a href="https://dash.cloudflare.com/" target="_blank" rel="noreferrer"
                    className="flex items-center gap-1 px-3 rounded-xl border border-white/[0.08] text-white/40 hover:text-white hover:border-orange-500/30 transition text-xs flex-shrink-0">
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
              <div>
                <label className="text-white/40 text-[11px] mb-1.5 block">API Token</label>
                <Input type="password" value={cfApiToken} onChange={e => setCfApiToken(e.target.value)}
                  placeholder="Cloudflare API Token with Tunnel+DNS permissions"
                  className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl font-mono text-xs" />
              </div>
              <div>
                <label className="text-white/40 text-[11px] mb-1.5 block">Max tunnels per user</label>
                <Input type="number" value={maxTunnels} onChange={e => setMaxTunnels(e.target.value)} min={1} max={20}
                  className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl w-28" />
              </div>
              <Button onClick={saveCreds} disabled={savingCreds}
                className="bg-gradient-to-r from-orange-600 to-amber-600 text-white border-0 rounded-xl gap-2 text-xs h-9">
                {savingCreds ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                {savingCreds ? 'Saving…' : 'Save Credentials'}
              </Button>
            </div>
          </div>

          {/* Step 2: Domains */}
          <div className="rounded-2xl border border-white/[0.06] bg-white/[0.02] p-5">
            <div className="flex items-center gap-2 mb-1">
              <div className="w-5 h-5 rounded-full bg-orange-500/20 text-orange-400 text-[10px] font-bold flex items-center justify-center">2</div>
              <h3 className="text-sm font-semibold text-white">Enable Domains for Users</h3>
            </div>
            <p className="text-[11px] text-white/40 mb-4 ml-7">Fetch your Cloudflare zones, then tick which domains users can create tunnels on.</p>

            <div className="flex gap-2 mb-4">
              <Button onClick={fetchZones} disabled={fetchingZones} variant="outline"
                className="border-white/10 text-white rounded-xl gap-2 text-xs h-9 hover:bg-white/5">
                {fetchingZones ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
                {fetchingZones ? 'Fetching…' : 'Fetch My Domains'}
              </Button>
              {zonesLoaded && cfZones.length > 0 && (
                <Button onClick={saveAllowedZones} disabled={savingZones} size="sm"
                  className="bg-gradient-to-r from-orange-600 to-amber-600 text-white rounded-xl text-xs gap-1.5">
                  {savingZones ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
                  Save ({allowedZones.length} enabled)
                </Button>
              )}
            </div>

            {!zonesLoaded && allowedZones.length > 0 && (
              <div className="mb-3 flex flex-wrap gap-2">
                <p className="text-[11px] text-white/30 w-full">Currently enabled:</p>
                {allowedZones.map((z: any) => (
                  <Badge key={z.id} className="bg-orange-500/10 text-orange-300 border-orange-500/20 text-[10px] font-mono">
                    {z.name}
                  </Badge>
                ))}
              </div>
            )}

            {zonesLoaded && cfZones.length > 0 && (
              <div className="space-y-1.5">
                {cfZones.map((zone: any) => {
                  const isEnabled = allowedZones.some((z: any) => z.id === zone.id)
                  return (
                    <button key={zone.id} onClick={() => toggleZone(zone)}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl border transition text-left ${isEnabled ? 'border-orange-500/30 bg-orange-500/5' : 'border-white/[0.06] bg-white/[0.02] hover:border-white/10'}`}>
                      <div className={`w-4 h-4 rounded border-2 flex-shrink-0 flex items-center justify-center ${isEnabled ? 'bg-orange-500 border-orange-500' : 'border-white/20'}`}>
                        {isEnabled && <CheckCircle className="w-2.5 h-2.5 text-white" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-mono font-medium text-white truncate">{zone.name}</p>
                        <p className="text-[10px] text-white/30 truncate">{zone.id}</p>
                      </div>
                      <Badge className={`text-[9px] border flex-shrink-0 ${zone.status === 'active' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20'}`}>
                        {zone.status}
                      </Badge>
                    </button>
                  )
                })}
              </div>
            )}

            {zonesLoaded && cfZones.length === 0 && (
              <div className="text-center py-6 text-white/30 text-sm">
                <Globe className="w-6 h-6 mx-auto mb-2 opacity-30" />
                No active zones found in your Cloudflare account
              </div>
            )}
          </div>

          {/* How tunnel works */}
          <div className="rounded-2xl border border-white/[0.06] bg-white/[0.02] p-5">
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
              <Info className="w-4 h-4 text-sky-400" /> How Tunnels Work
            </h3>
            <div className="space-y-2.5">
              {[
                { n: '1', t: 'User creates a tunnel', d: 'Picks a subdomain + enabled domain and sets target port (e.g. 3000, 8080).' },
                { n: '2', t: 'Real CF Tunnel created', d: 'API call creates a Cloudflare Tunnel, configures ingress rules, and adds a DNS CNAME record automatically.' },
                { n: '3', t: 'Install cloudflared', d: 'User installs cloudflared on their server using the provided token — OS-specific commands shown.' },
                { n: '4', t: 'Live instantly', d: 'Once cloudflared connects, traffic is routed: internet → CF edge → tunnel → localhost:port. No open ports needed.' },
              ].map(({ n, t, d }) => (
                <div key={n} className="flex gap-3 items-start">
                  <div className="w-5 h-5 rounded-full bg-sky-500/20 text-sky-400 text-[10px] font-bold flex items-center justify-center flex-shrink-0 mt-0.5">{n}</div>
                  <div><p className="text-xs font-medium text-white">{t}</p><p className="text-[11px] text-white/40">{d}</p></div>
                </div>
              ))}
            </div>
          </div>

          {/* All Tunnels */}
          <div className="rounded-2xl border border-white/[0.06] bg-white/[0.02] overflow-hidden">
            <div className="px-5 py-4 border-b border-white/[0.04] flex items-center justify-between">
              <h3 className="text-sm font-semibold text-white">All User Tunnels ({tunnels.length})</h3>
              <button onClick={loadAll} className="text-white/30 hover:text-white p-1.5 rounded-lg hover:bg-white/[0.04] transition">
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
            </div>

            {loadingTunnels ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-5 h-5 animate-spin text-white/20" />
              </div>
            ) : tunnels.length === 0 ? (
              <div className="py-12 text-center">
                <Globe className="w-8 h-8 text-white/10 mx-auto mb-2" />
                <p className="text-white/20 text-sm">No tunnels created yet</p>
              </div>
            ) : (
              <div className="divide-y divide-white/[0.04]">
                {tunnels.map((t: any) => {
                  const fullHost = t.subdomain && t.zoneDomain ? `${t.subdomain}.${t.zoneDomain}` : null
                  return (
                    <div key={t.id} className="flex items-center gap-3 px-4 py-3 hover:bg-white/[0.02] transition">
                      <Avatar className="h-8 w-8 flex-shrink-0">
                        {t.user?.avatar && <AvatarImage src={t.user.avatar} />}
                        <AvatarFallback className="bg-orange-500/20 text-orange-400 text-xs">
                          {t.user?.username?.[0]?.toUpperCase() || '?'}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-semibold text-white truncate">{t.name}</p>
                        <p className="text-[10px] text-white/30 truncate">
                          <span className="text-white/50">{t.user?.username || 'Unknown'}</span>
                          {fullHost && (
                            <> · <span className="font-mono text-orange-300/70">{fullHost}</span></>
                          )}
                          {' '}→ {t.protocol}://{t.targetHost}:{t.targetPort}
                        </p>
                        {t.cfTunnelId && (
                          <button onClick={() => copyText(t.cfTunnelId)}
                            className="text-[9px] text-white/15 font-mono hover:text-white/40 transition flex items-center gap-1">
                            <Copy className="w-2.5 h-2.5" />
                            {t.cfTunnelId}
                          </button>
                        )}
                      </div>
                      <Badge className={`text-[9px] h-4 border flex-shrink-0 ${STATUS_COLORS[t.status] || 'bg-white/5 text-white/30 border-white/10'}`}>
                        {t.status}
                      </Badge>
                      <span className="text-[10px] text-white/20 flex-shrink-0 hidden sm:block">
                        {new Date(t.createdAt).toLocaleDateString()}
                      </span>
                      <button onClick={() => deleteTunnel(t.id)} disabled={deleting === t.id}
                        className="text-red-400/30 hover:text-red-400 hover:bg-red-500/10 p-1.5 rounded-lg transition flex-shrink-0">
                        {deleting === t.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                  )
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
