'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useSession } from 'next-auth/react'
import { Navbar } from '@/components/navbar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue, SelectGroup, SelectLabel,
} from '@/components/ui/select'
import { ArrowLeft, Eye, EyeOff, Key, Save, Sparkles, CheckCircle2, AlertCircle } from 'lucide-react'
import { toast } from 'sonner'

type ProviderKey =
  | 'openai' | 'anthropic' | 'gemini' | 'banana'
  | 'deepseek' | 'openrouter' | 'xai' | 'groq'
  | 'mistral' | 'cohere' | 'cloudflareAi' | 'pollinations'
  | 'deepinfra' | 'segmind' | 'a4f'
  | 'stability' | 'replicate' | 'huggingface' | 'together'
  | 'pixabay' | 'unsplash' | 'resend'
  | 'fal' | 'runway' | 'luma' | 'kling' | 'minimax'
  | 'perplexity' | 'fireworks' | 'ai21' | 'nvidia' | 'sambanova' | 'novita'
  | 'ideogram' | 'recraft' | 'leonardo' | 'bfl' | 'getimg'
  | 'pika' | 'vidu' | 'hedra' | 'hotshot' | 'ltxStudio'
  | 'elevenlabs' | 'deepgram' | 'assemblyai'
  | 'paimon' | 'glif' | 'haiper' | 'viggle' | 'hunyuan' | 'kuaishou' | 'cogvideo' | 'mochi' | 'tencent' | 'ali' | 'bytedance'

interface SiteSettings {
  openaiApiKey?: string
  anthropicApiKey?: string
  geminiApiKey?: string
  bananaApiKey?: string
  deepseekApiKey?: string
  openrouterApiKey?: string
  xaiApiKey?: string
  groqApiKey?: string
  mistralApiKey?: string
  cohereApiKey?: string
  cloudflareAiApiKey?: string
  pollinationsApiKey?: string
  stabilityApiKey?: string
  replicateApiKey?: string
  huggingfaceApiKey?: string
  togetherApiKey?: string
  pixabayApiKey?: string
  unsplashApiKey?: string
  resendApiKey?: string
  falApiKey?: string
  runwayApiKey?: string
  lumaApiKey?: string
  klingApiKey?: string
  minimaxApiKey?: string
  modelsLabApiKey?: string
  // extra chat
  perplexityApiKey?: string
  fireworksApiKey?: string
  ai21ApiKey?: string
  nvidiaApiKey?: string
  sambanovaApiKey?: string
  novitaApiKey?: string
  // extra image
  ideogramApiKey?: string
  recraftApiKey?: string
  leonardoApiKey?: string
  bflApiKey?: string
  getimgApiKey?: string
  // extra video
  pikaApiKey?: string
  viduApiKey?: string
  hedraApiKey?: string
  hotshotApiKey?: string
  ltxStudioApiKey?: string
  // extra video providers
  paimonApiKey?: string
  glifApiKey?: string
  haiperApiKey?: string
  viggleApiKey?: string
  hunyuanApiKey?: string
  kuaishouApiKey?: string
  cogvideoApiKey?: string
  mochiApiKey?: string
  tencentApiKey?: string
  aliApiKey?: string
  bytedanceApiKey?: string
  // voice / audio
  elevenlabsApiKey?: string
  deepgramApiKey?: string
  assemblyaiApiKey?: string
  fromEmail?: string
  aiApiKey?: string
  aiModel?: string
  videoModel?: string
  lowTokenMode?: boolean
  gmailUser?: string
  gmailClientId?: string
  gmailClientSecret?: string
  gmailRefreshToken?: string
  gmailAppPassword?: string
  emailVerificationEnabled?: boolean
}

const MODEL_GROUPS: { label: string; options: { value: string; label: string }[] }[] = [
  {
    label: 'OpenAI',
    options: [
      { value: 'gpt-4o-mini', label: 'GPT-4o mini (fast, cheap)' },
      { value: 'gpt-4o', label: 'GPT-4o' },
      { value: 'gpt-4-turbo', label: 'GPT-4 Turbo' },
      { value: 'gpt-4.1-mini', label: 'GPT-4.1 mini' },
      { value: 'o1-mini', label: 'o1-mini (reasoning)' },
    ],
  },
  {
    label: 'Anthropic Claude',
    options: [
      { value: 'claude-3-5-sonnet-20241022', label: 'Claude 3.5 Sonnet' },
      { value: 'claude-3-5-haiku-20241022', label: 'Claude 3.5 Haiku' },
      { value: 'claude-3-opus-20240229', label: 'Claude 3 Opus' },
    ],
  },
  {
    label: 'Google Gemini',
    options: [
      { value: 'gemini-1.5-flash', label: 'Gemini 1.5 Flash' },
      { value: 'gemini-1.5-pro', label: 'Gemini 1.5 Pro' },
      { value: 'gemini-2.0-flash', label: 'Gemini 2.0 Flash' },
    ],
  },
  {
    label: 'DeepSeek',
    options: [
      { value: 'deepseek-chat', label: 'DeepSeek Chat (V3)' },
      { value: 'deepseek-reasoner', label: 'DeepSeek Reasoner (R1)' },
    ],
  },
  {
    label: 'xAI Grok',
    options: [
      { value: 'grok-2-latest', label: 'Grok 2' },
      { value: 'grok-beta', label: 'Grok Beta' },
    ],
  },
  {
    label: 'Groq (fast inference)',
    options: [
      { value: 'llama-3.1-8b-instant', label: 'Llama 3.1 8B Instant' },
      { value: 'llama-3.3-70b-versatile', label: 'Llama 3.3 70B' },
      { value: 'mixtral-8x7b-32768', label: 'Mixtral 8x7B' },
    ],
  },
  {
    label: 'OpenRouter',
    options: [
      { value: 'openai/gpt-4o-mini', label: 'GPT-4o mini (via OpenRouter)' },
      { value: 'anthropic/claude-3.5-sonnet', label: 'Claude 3.5 Sonnet (via OpenRouter)' },
      { value: 'meta-llama/llama-3.1-70b-instruct', label: 'Llama 3.1 70B (via OpenRouter)' },
      { value: 'z-ai/glm-4.5', label: 'Z.ai GLM-4.5 (via OpenRouter)' },
      { value: 'qwen/qwen-2.5-72b-instruct', label: 'Qwen 2.5 72B (via OpenRouter)' },
    ],
  },
]

type ProviderTier = 'free' | 'paid' | 'freemium'

const PROVIDERS: {
  id: ProviderKey
  label: string
  field: keyof SiteSettings
  color: string
  hint: string
  placeholder: string
  tier: ProviderTier
}[] = [
  // ── Paid premium chat providers ────────────────────────────────────
  { id: 'openai', label: 'OpenAI', field: 'openaiApiKey', color: 'text-emerald-400', tier: 'paid',
    hint: 'GPT-4o, GPT-4 Turbo, DALL·E. Get one at platform.openai.com.', placeholder: 'sk-...' },
  { id: 'anthropic', label: 'Anthropic (Claude)', field: 'anthropicApiKey', color: 'text-amber-400', tier: 'paid',
    hint: 'Claude 3.5 Sonnet/Haiku/Opus. Get one at console.anthropic.com.', placeholder: 'sk-ant-...' },
  { id: 'gemini', label: 'Google Gemini', field: 'geminiApiKey', color: 'text-cyan-400', tier: 'freemium',
    hint: 'Gemini 1.5/2.0 + Imagen. Generous free tier — get one at aistudio.google.com.', placeholder: 'AIza...' },
  { id: 'banana', label: 'Banana (Nano-Banana image gen)', field: 'bananaApiKey', color: 'text-yellow-400', tier: 'freemium',
    hint: 'Gemini 2.5 Flash Image. Leave blank to reuse the Gemini key above.', placeholder: 'AIza... (or leave blank to use Gemini key)' },
  { id: 'deepseek', label: 'DeepSeek', field: 'deepseekApiKey', color: 'text-blue-400', tier: 'paid',
    hint: 'DeepSeek V3 / R1. Get one at platform.deepseek.com.', placeholder: 'sk-...' },
  { id: 'xai', label: 'xAI (Grok)', field: 'xaiApiKey', color: 'text-rose-400', tier: 'paid',
    hint: 'Grok 2/Beta. Get one at console.x.ai.', placeholder: 'xai-...' },

  // ── Free chat providers ────────────────────────────────────────────
  { id: 'groq', label: 'Groq (free, ultra-fast Llama/Mixtral)', field: 'groqApiKey', color: 'text-orange-400', tier: 'free',
    hint: 'FREE tier — Llama 3.x & Mixtral on Groq hardware. Get one at console.groq.com.', placeholder: 'gsk_...' },
  { id: 'openrouter', label: 'OpenRouter (free + paid models)', field: 'openrouterApiKey', color: 'text-fuchsia-400', tier: 'freemium',
    hint: 'One key, many models — has free models too (Llama, Mistral, Z.ai). Get one at openrouter.ai.', placeholder: 'sk-or-...' },
  { id: 'mistral', label: 'Mistral (free tier — Mistral 7B / Codestral)', field: 'mistralApiKey', color: 'text-indigo-400', tier: 'free',
    hint: 'FREE tier on console.mistral.ai. Mistral Small/Large + open models.', placeholder: 'mistral-...' },
  { id: 'cohere', label: 'Cohere (free trial — Command R/R+)', field: 'cohereApiKey', color: 'text-pink-300', tier: 'freemium',
    hint: 'FREE trial keys at dashboard.cohere.com — Command R / Command R+.', placeholder: 'co_...' },
  { id: 'cloudflareAi', label: 'Cloudflare Workers AI (free Llama)', field: 'cloudflareAiApiKey', color: 'text-orange-300', tier: 'free',
    hint: 'FREE Workers AI inference (Llama 3, Mistral). Format: <accountId>:<apiToken> from dash.cloudflare.com.', placeholder: 'accountId:apiToken' },

  // ── Newly added chat providers ────────────────────────────────────
  { id: 'perplexity', label: 'Perplexity (Sonar — web-aware models)', field: 'perplexityApiKey', color: 'text-sky-400', tier: 'paid',
    hint: 'Perplexity Sonar / Llama Sonar with live web search. Get a key at perplexity.ai/settings/api.', placeholder: 'pplx-...' },
  { id: 'fireworks', label: 'Fireworks AI (fast Llama / Mixtral / Qwen)', field: 'fireworksApiKey', color: 'text-orange-400', tier: 'freemium',
    hint: 'Fast OSS LLMs on Fireworks. Free credits — get one at fireworks.ai/account/api-keys.', placeholder: 'fw_...' },
  { id: 'ai21', label: 'AI21 (Jamba / Jurassic)', field: 'ai21ApiKey', color: 'text-emerald-400', tier: 'freemium',
    hint: 'Jamba 1.5, Jurassic-2. Free trial — get one at studio.ai21.com/account/api-key.', placeholder: 'ai21-...' },
  { id: 'nvidia', label: 'NVIDIA NIM (free Llama, Mixtral, Phi-3)', field: 'nvidiaApiKey', color: 'text-lime-400', tier: 'free',
    hint: 'FREE NVIDIA NIM endpoints (Llama 3.x, Mixtral, Phi-3, Nemotron). Get one at build.nvidia.com.', placeholder: 'nvapi-...' },
  { id: 'sambanova', label: 'SambaNova (free fast Llama 405B)', field: 'sambanovaApiKey', color: 'text-violet-400', tier: 'freemium',
    hint: 'FREE tier — Llama 3.1 405B at >100 tok/s. Get one at cloud.sambanova.ai/apis.', placeholder: 'sambanova-...' },
  { id: 'novita', label: 'Novita AI (cheap Llama / DeepSeek / Qwen)', field: 'novitaApiKey', color: 'text-cyan-400', tier: 'freemium',
    hint: 'Low-cost OSS LLM gateway. Free credits — get one at novita.ai/settings/key-management.', placeholder: 'novita-...' },
]

const IMAGE_PROVIDERS: typeof PROVIDERS = [
  { id: 'pollinations', label: 'Pollinations (100% FREE — no key needed)', field: 'pollinationsApiKey', color: 'text-emerald-300', tier: 'free',
    hint: 'Pollinations.ai works with NO API key. Optional token improves rate limits. Always available as last fallback.', placeholder: '(optional) leave blank for free tier' },
  { id: 'stability', label: 'Stability AI (Stable Diffusion)', field: 'stabilityApiKey', color: 'text-purple-400', tier: 'paid',
    hint: 'Stable Image Core / Ultra. Get one at platform.stability.ai.', placeholder: 'sk-...' },
  { id: 'replicate', label: 'Replicate (FLUX, SDXL, more)', field: 'replicateApiKey', color: 'text-pink-400', tier: 'paid',
    hint: 'Runs FLUX-Schnell and many other models. Get one at replicate.com/account/api-tokens.', placeholder: 'r8_...' },
  { id: 'huggingface', label: 'Hugging Face (free tier)', field: 'huggingfaceApiKey', color: 'text-yellow-300', tier: 'free',
    hint: 'FREE — FLUX & SDXL inference. Get one at huggingface.co/settings/tokens.', placeholder: 'hf_...' },
  { id: 'together', label: 'Together AI (FLUX-Schnell free)', field: 'togetherApiKey', color: 'text-teal-400', tier: 'freemium',
    hint: 'FLUX-Schnell-Free is FREE. Other models pay-as-you-go. Get one at api.together.xyz/settings/api-keys.', placeholder: 'sk-...' },
  { id: 'pixabay', label: 'Pixabay (free stock fallback)', field: 'pixabayApiKey', color: 'text-lime-400', tier: 'free',
    hint: 'FREE stock photo fallback. Get one at pixabay.com/api/docs.', placeholder: 'free Pixabay key' },
  { id: 'unsplash', label: 'Unsplash (free stock fallback)', field: 'unsplashApiKey', color: 'text-sky-400', tier: 'free',
    hint: 'FREE Unsplash photos fallback. Get one at unsplash.com/developers.', placeholder: 'access key' },

  // ── Newly added image providers ──────────────────────────────────
  { id: 'bfl', label: 'Black Forest Labs (FLUX direct API)', field: 'bflApiKey', color: 'text-orange-300', tier: 'paid',
    hint: 'FLUX.1 Pro / Dev / Schnell direct from Black Forest Labs. Get one at api.bfl.ml.', placeholder: 'bfl-...' },
  { id: 'ideogram', label: 'Ideogram (typography & posters)', field: 'ideogramApiKey', color: 'text-purple-300', tier: 'paid',
    hint: 'Ideogram 2.0 — best for text/logos in images. Get one at developer.ideogram.ai.', placeholder: 'ideogram-...' },
  { id: 'recraft', label: 'Recraft V3 (vector + brand-style)', field: 'recraftApiKey', color: 'text-rose-400', tier: 'paid',
    hint: 'Recraft V3 — vector art + brand-consistent images. Get one at recraft.ai/profile/api.', placeholder: 'recraft-...' },
  { id: 'leonardo', label: 'Leonardo.AI (game art / characters)', field: 'leonardoApiKey', color: 'text-amber-400', tier: 'freemium',
    hint: 'Leonardo Phoenix / Anime / Lightning XL. Free trial credits — get one at app.leonardo.ai/settings/api-keys.', placeholder: 'leonardo-...' },
  { id: 'getimg', label: 'getimg.ai (SDXL / FLUX cheap inference)', field: 'getimgApiKey', color: 'text-emerald-300', tier: 'freemium',
    hint: 'FLUX, SDXL, Stable Diffusion via getimg.ai. Free trial — get one at getimg.ai/dashboard/api.', placeholder: 'key-...' },
]

const EMAIL_PROVIDERS: typeof PROVIDERS = [
  { id: 'resend', label: 'Resend (announcement email blast)', field: 'resendApiKey', color: 'text-red-400', tier: 'freemium',
    hint: 'FREE up to 3,000 emails/month. Used to email all users when an announcement is posted. Get one at resend.com.', placeholder: 're_...' },
]

const VIDEO_PROVIDERS: typeof PROVIDERS = [
  { id: 'fal', label: 'FAL.ai (Wan, Kling, Hailuo, Veo, Luma)', field: 'falApiKey', color: 'text-violet-400', tier: 'freemium',
    hint: 'One key, dozens of video models — Wan-2.5, Kling, Hailuo, Veo3, Luma Ray. FREE credits to start at fal.ai/dashboard/keys.', placeholder: 'fal-key-id:fal-key-secret' },
  { id: 'video-replicate' as any, label: 'Replicate (video models)', field: 'replicateApiKey' as any, color: 'text-pink-400', tier: 'paid',
    hint: 'Reuses the same Replicate key as image gen. Runs Wan-2.5, MiniMax Hailuo, Stable Video Diffusion.', placeholder: 'r8_... (already saved if image set)' },
  { id: 'runway', label: 'Runway ML (Gen-3, Gen-4)', field: 'runwayApiKey', color: 'text-fuchsia-400', tier: 'paid',
    hint: 'Cinematic Runway Gen-3 / Gen-4 video. Get one at dev.runwayml.com.', placeholder: 'key_...' },
  { id: 'luma', label: 'Luma AI (Dream Machine)', field: 'lumaApiKey', color: 'text-amber-400', tier: 'freemium',
    hint: 'Dream Machine text-to-video. Free trial credits — get one at lumalabs.ai/dream-machine/api.', placeholder: 'luma-...' },
  { id: 'kling', label: 'Kling AI', field: 'klingApiKey', color: 'text-cyan-400', tier: 'paid',
    hint: 'Kling 1.6 / 2.0 text-to-video direct API. Get one at klingai.com.', placeholder: 'access-key:secret-key' },
  { id: 'minimax', label: 'MiniMax Hailuo', field: 'minimaxApiKey', color: 'text-emerald-400', tier: 'freemium',
    hint: 'MiniMax Hailuo-02 text/image-to-video. Free credits — get one at platform.minimaxi.com.', placeholder: 'eyJ... (JWT)' },
  { id: 'video-huggingface' as any, label: 'Hugging Face (free fallback)', field: 'huggingfaceApiKey' as any, color: 'text-yellow-300', tier: 'free',
    hint: 'FREE — same Hugging Face key as image gen. Used as a free fallback for short text-to-video clips (Zeroscope, LTX-Video, CogVideoX, AnimateDiff, etc.).', placeholder: 'hf_... (already saved if image set)' },
  { id: 'modelslab' as any, label: 'ModelsLab (free tier available)', field: 'modelsLabApiKey' as any, color: 'text-lime-400', tier: 'freemium',
    hint: 'FREE tier with 10 credits/day. Supports Zeroscope, AnimateDiff, and more. Get a key at modelslab.com/dashboard/api.', placeholder: 'your-modelslab-api-key' },
  { id: 'deepinfra' as any, label: 'DeepInfra (FREE credits, LTX-Video)', field: 'deepinfraApiKey' as any, color: 'text-cyan-300', tier: 'freemium',
    hint: 'FREE — sign up at deepinfra.com/dash for free credits. Runs LTX-Video, CogVideoX, Mochi-1.', placeholder: 'di_...' },
  { id: 'segmind' as any, label: 'Segmind (FREE 100 credits/day)', field: 'segmindApiKey' as any, color: 'text-pink-300', tier: 'freemium',
    hint: 'FREE 100 credits/day. Runs LTX-Video, AnimateDiff, Mochi. Get a key at segmind.com/console.', placeholder: 'SG_...' },
  { id: 'a4f' as any, label: 'A4F.co (FREE aggregator — many models)', field: 'a4fApiKey' as any, color: 'text-teal-300', tier: 'free',
    hint: 'FREE aggregator that proxies many providers (Wan, Luma, Veo) under one key. Sign up at a4f.co.', placeholder: 'a4f_...' },
  { id: 'video-cloudflare' as any, label: 'Cloudflare Workers AI (free tier)', field: 'cloudflareAiApiKey' as any, color: 'text-orange-300', tier: 'free',
    hint: 'FREE — same Cloudflare AI key as text gen. Used as a fast still-frame fallback when paid video providers fail.', placeholder: 'cf_... (already saved if text set)' },

  // ── Newly added video providers ──────────────────────────────────
  { id: 'pika', label: 'Pika Labs (Pika 1.5 / 2.0)', field: 'pikaApiKey', color: 'text-rose-300', tier: 'paid',
    hint: 'Pika 1.5 / 2.0 cinematic video. Get one at pika.art/api.', placeholder: 'pika-...' },
  { id: 'vidu', label: 'Vidu (China — fast text-to-video)', field: 'viduApiKey', color: 'text-purple-300', tier: 'freemium',
    hint: 'Vidu Studio fast T2V. Free credits — get one at vidu.studio/api.', placeholder: 'vidu-...' },
  { id: 'hedra', label: 'Hedra (talking-head / character video)', field: 'hedraApiKey', color: 'text-amber-300', tier: 'freemium',
    hint: 'Hedra Character-1 / Audio2Video — talking avatars. Get one at hedra.com/app/api.', placeholder: 'hedra-...' },
  { id: 'hotshot', label: 'Hotshot (short GIF-style clips)', field: 'hotshotApiKey', color: 'text-yellow-300', tier: 'freemium',
    hint: 'Hotshot — short looping clips. Get one at hotshot.co/account.', placeholder: 'hs_...' },
  { id: 'ltxStudio', label: 'LTX Studio (Lightricks LTX-Video direct)', field: 'ltxStudioApiKey', color: 'text-emerald-300', tier: 'freemium',
    hint: 'Lightricks LTX-Video direct API — fast HD. Get one at ltx.studio/dashboard.', placeholder: 'ltx-...' },

  // ── Free & Community Video Providers ──────────────────────────────
  { id: 'paimon', label: 'Paimon AI (FREE — Genshin/Anime Video)', field: 'paimonApiKey', color: 'text-pink-300', tier: 'free',
    hint: 'FREE — high quality anime & stylized video. Sign up at paimon.ai/api.', placeholder: 'pa_...' },
  { id: 'glif', label: 'Glif (FREE trial — many open models)', field: 'glifApiKey', color: 'text-orange-400', tier: 'freemium',
    hint: 'FREE credits — runs many community video models. Get one at glif.app.', placeholder: 'glif_...' },
  { id: 'haiper', label: 'Haiper AI (FREE trial — HD Video)', field: 'haiperApiKey', color: 'text-blue-300', tier: 'freemium',
    hint: 'FREE trial credits daily. High-quality artistic video. Get one at haiper.ai.', placeholder: 'hp_...' },
  { id: 'viggle', label: 'Viggle AI (FREE — character animation)', field: 'viggleApiKey', color: 'text-yellow-400', tier: 'free',
    hint: 'FREE — best for character motion & memes. Get a key at viggle.ai.', placeholder: 'vig_...' },
  
  // ── Enterprise Video Providers ────────────────────────────────────
  { id: 'hunyuan', label: 'Tencent Hunyuan Video', field: 'hunyuanApiKey', color: 'text-blue-500', tier: 'paid',
    hint: 'Enterprise grade video gen from Tencent. Get a key at cloud.tencent.com.', placeholder: 'secret-id:secret-key' },
  { id: 'kuaishou', label: 'Kuaishou Kling (Direct Enterprise)', field: 'kuaishouApiKey', color: 'text-orange-500', tier: 'paid',
    hint: 'Kling 1.6/2.0 direct enterprise API. Get one at kuaishou.com.', placeholder: 'key:secret' },
  { id: 'cogvideo', label: 'Zhipu AI CogVideoX', field: 'cogvideoApiKey', color: 'text-indigo-400', tier: 'freemium',
    hint: 'CogVideoX 2B/5B/Plus. Free credits — get one at bigmodel.cn.', placeholder: 'api-key' },
  { id: 'mochi', label: 'Genmo Mochi-1', field: 'mochiApiKey', color: 'text-emerald-400', tier: 'freemium',
    hint: 'Mochi-1 open video model. Free trial — get one at genmo.ai.', placeholder: 'gm_...' },
]

const VOICE_PROVIDERS: typeof PROVIDERS = [
  { id: 'elevenlabs', label: 'ElevenLabs (best-in-class TTS / voice clone)', field: 'elevenlabsApiKey', color: 'text-rose-400', tier: 'freemium',
    hint: 'ElevenLabs Multilingual v2 / Voice Cloning. Free 10k characters/mo. Get one at elevenlabs.io/app/settings/api-keys.', placeholder: 'sk_xxx...' },
  { id: 'deepgram', label: 'Deepgram (fast speech-to-text)', field: 'deepgramApiKey', color: 'text-cyan-400', tier: 'freemium',
    hint: 'Nova-3 STT, transcription & live captions. $200 free credit — get one at console.deepgram.com.', placeholder: 'dg-...' },
  { id: 'assemblyai', label: 'AssemblyAI (transcription + summarisation)', field: 'assemblyaiApiKey', color: 'text-violet-400', tier: 'freemium',
    hint: 'Universal-2 transcription + LeMUR summarisation. $50 free credit — get one at assemblyai.com/dashboard/api-keys.', placeholder: 'aai-...' },
]

const VIDEO_MODEL_GROUPS: { label: string; options: { value: string; label: string }[] }[] = [
  {
    label: 'Community & Free (New)',
    options: [
      { value: 'paimon/anime-v1', label: 'Paimon Anime V1 (Free)' },
      { value: 'glif/video-flux', label: 'Glif Video Flux (Free trial)' },
      { value: 'haiper/v2-hd', label: 'Haiper V2 HD (Free trial)' },
      { value: 'viggle/motion-v1', label: 'Viggle Motion V1 (Free)' },
      { value: 'deepinfra/ltx-video', label: 'LTX-Video (DeepInfra - Free credits)' },
      { value: 'segmind/mochi-1', label: 'Mochi-1 (Segmind - Free credits)' },
    ],
  },
  {
    label: 'Enterprise APIs',
    options: [
      { value: 'hunyuan/video-v1', label: 'Tencent Hunyuan Video' },
      { value: 'kuaishou/kling-v2', label: 'Kling 2.0 (Kuaishou Direct)' },
      { value: 'cogvideo/plus-v1', label: 'CogVideoX Plus (Zhipu)' },
      { value: 'mochi/v1-hd', label: 'Mochi-1 HD (Genmo Direct)' },
    ],
  },
  {
    label: 'FAL.ai (recommended — fast, low cost)',
    options: [
      { value: 'fal-ai/wan/v2.5/text-to-video/fast', label: 'Wan 2.5 Fast (cheap, good quality)' },
      { value: 'fal-ai/wan/v2.5/text-to-video', label: 'Wan 2.5 Standard' },
      { value: 'fal-ai/minimax/hailuo-02/standard/text-to-video', label: 'MiniMax Hailuo-02 Standard' },
      { value: 'fal-ai/kling-video/v1.6/standard/text-to-video', label: 'Kling 1.6 Standard' },
      { value: 'fal-ai/kling-video/v2/master/text-to-video', label: 'Kling 2.0 Master (premium)' },
      { value: 'fal-ai/luma-dream-machine', label: 'Luma Dream Machine' },
      { value: 'fal-ai/veo3/fast', label: 'Google Veo 3 Fast (premium)' },
    ],
  },
  {
    label: 'Replicate',
    options: [
      { value: 'replicate/wan-video/wan-2.5-t2v-fast', label: 'Wan 2.5 T2V Fast (Replicate)' },
      { value: 'replicate/minimax/hailuo-02', label: 'MiniMax Hailuo-02 (Replicate)' },
      { value: 'replicate/stability-ai/stable-video-diffusion', label: 'Stable Video Diffusion (cheap)' },
    ],
  },
  {
    label: 'Direct provider APIs',
    options: [
      { value: 'runway/gen3a_turbo', label: 'Runway Gen-3 Alpha Turbo' },
      { value: 'runway/gen4_turbo', label: 'Runway Gen-4 Turbo' },
      { value: 'luma/ray-2', label: 'Luma Ray-2 (Direct)' },
      { value: 'luma/ray-flash-2', label: 'Luma Ray Flash-2 (cheap)' },
      { value: 'kling/v1.6-standard', label: 'Kling 1.6 Standard (Direct)' },
      { value: 'minimax/T2V-01', label: 'MiniMax T2V-01 (Direct)' },
    ],
  },
  {
    label: 'Hugging Face (free — needs HF key)',
    options: [
      { value: 'huggingface/Lightricks/LTX-Video', label: 'LTX-Video (fast, HD quality)' },
      { value: 'huggingface/damo-vilab/text-to-video-ms-1.7b', label: 'Text-to-Video MS 1.7B (DAMO)' },
      { value: 'huggingface/cerspense/zeroscope_v2_576w', label: 'Zeroscope v2 576w' },
      { value: 'huggingface/THUDM/CogVideoX-5b', label: 'CogVideoX-5B (THUDM)' },
      { value: 'huggingface/ali-vilab/i2vgen-xl', label: 'I2VGen-XL (Alibaba)' },
      { value: 'huggingface/guoyww/animatediff-motion-adapter-v1-5-2', label: 'AnimateDiff v1.5' },
    ],
  },
  {
    label: 'ModelsLab (free tier)',
    options: [
      { value: 'modelslab/zeroscope', label: 'ModelsLab Zeroscope (free tier)' },
      { value: 'modelslab/animatediff', label: 'ModelsLab AnimateDiff (free tier)' },
    ],
  },
  {
    label: 'Stability AI',
    options: [
      { value: 'stability/svd', label: 'Stable Video Diffusion (SVD)' },
    ],
  },
]

export default function AdminApiKeysPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [show, setShow] = useState<Record<string, boolean>>({})
  const [masked, setMasked] = useState<Record<string, boolean>>({})
  const [settings, setSettings] = useState<SiteSettings>({
    aiModel: 'gpt-4o-mini', videoModel: 'fal-ai/wan/v2.5/text-to-video/fast', lowTokenMode: false,
  })

  useEffect(() => {
    if (status === 'loading') return
    if (status === 'unauthenticated') { router.push('/auth/signin'); return }
    if (!['ADMIN', 'SUPER_ADMIN'].includes((session?.user as any)?.role || '')) {
      router.push('/'); return
    }
    load()
  }, [status])

  const load = async () => {
    setLoading(true)
    try {
      const res = await fetch('/api/admin/settings')
      if (res.ok) {
        const data = await res.json()
        const s = data.settings || data || {}
        const unmask = (v?: string | null) => (v && !v.startsWith('****') ? v : '')
        const next: SiteSettings = {
          aiModel: s.aiModel || 'gpt-4o-mini',
          videoModel: s.videoModel || 'fal-ai/wan/v2.5/text-to-video/fast',
          lowTokenMode: !!s.lowTokenMode,
          aiApiKey: unmask(s.aiApiKey),
        }
        const m: Record<string, boolean> = {}
        ;[...PROVIDERS, ...IMAGE_PROVIDERS, ...EMAIL_PROVIDERS, ...VIDEO_PROVIDERS, ...VOICE_PROVIDERS].forEach(p => {
          ;(next as any)[p.field] = unmask(s[p.field])
          m[p.id] = !!(s[p.field] && String(s[p.field]).startsWith('****'))
        })
        ;(next as any).fromEmail = s.fromEmail || ''
        ;(next as any).gmailUser = s.gmailUser || ''
        ;(next as any).gmailClientId = unmask(s.gmailClientId)
        ;(next as any).gmailClientSecret = unmask(s.gmailClientSecret)
        ;(next as any).gmailRefreshToken = unmask(s.gmailRefreshToken)
        ;(next as any).gmailAppPassword = unmask(s.gmailAppPassword)
        ;(next as any).emailVerificationEnabled = !!s.emailVerificationEnabled
        setSettings(next)
        setMasked(m)
      }
    } catch {
      toast.error('Failed to load settings')
    } finally {
      setLoading(false)
    }
  }

  const save = async () => {
    setSaving(true)
    try {
      const payload: any = {
        aiModel: settings.aiModel || 'gpt-4o-mini',
        videoModel: settings.videoModel || 'fal-ai/wan/v2.5/text-to-video/fast',
        lowTokenMode: !!settings.lowTokenMode,
      }
      ;[...PROVIDERS, ...IMAGE_PROVIDERS, ...EMAIL_PROVIDERS, ...VIDEO_PROVIDERS, ...VOICE_PROVIDERS].forEach(p => {
        const val = (settings as any)[p.field]
        if (val) payload[p.field] = val
      })
      if ((settings as any).fromEmail) payload.fromEmail = (settings as any).fromEmail
      if ((settings as any).gmailUser) payload.gmailUser = (settings as any).gmailUser
      if ((settings as any).gmailClientId) payload.gmailClientId = (settings as any).gmailClientId
      if ((settings as any).gmailClientSecret) payload.gmailClientSecret = (settings as any).gmailClientSecret
      if ((settings as any).gmailRefreshToken) payload.gmailRefreshToken = (settings as any).gmailRefreshToken
      if ((settings as any).gmailAppPassword) payload.gmailAppPassword = (settings as any).gmailAppPassword
      payload.emailVerificationEnabled = !!(settings as any).emailVerificationEnabled
      // Keep aiApiKey synced with openai for backwards compat
      if (settings.openaiApiKey) payload.aiApiKey = settings.openaiApiKey

      const res = await fetch('/api/admin/settings', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      if (!res.ok) {
        const err = await res.json().catch(() => ({}))
        throw new Error(err.error || 'Failed to save')
      }
      toast.success('AI API keys saved successfully')
      load()
    } catch (e: any) {
      toast.error(e.message || 'Failed to save')
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a12] text-white">
        <Navbar />
        <div className="container mx-auto px-4 py-12 text-center text-white/50">Loading…</div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#0a0a12] text-white">
      <Navbar />
      <div className="container mx-auto px-4 py-8 max-w-3xl">
        <Link href="/admin" className="inline-flex items-center gap-2 text-white/50 hover:text-white text-sm mb-6">
          <ArrowLeft className="w-4 h-4" /> Back to Admin
        </Link>

        <div className="flex items-start gap-4 mb-8">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-violet-600 to-cyan-600 flex items-center justify-center shadow-lg shadow-violet-600/30">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">AI API Keys</h1>
            <p className="text-sm text-white/50 mt-1">
              Add provider keys so site-wide AI features work. The selected default model decides which provider runs first; if it fails, the system automatically falls back to any other configured provider.
            </p>
          </div>
        </div>

        <div className="space-y-4">
          {(() => {
            const renderProvider = (p: typeof PROVIDERS[number]) => {
              const value = ((settings as any)[p.field] || '') as string
              const isMasked = !!masked[p.id]
              const visible = !!show[p.id]
              return (
                <div key={p.id} className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
                  <div className="flex items-center justify-between mb-3 gap-2 flex-wrap">
                    <div className="flex items-center gap-2 flex-wrap">
                      <Key className={`w-4 h-4 ${p.color}`} />
                      <Label htmlFor={p.id} className="text-white text-sm font-semibold">{p.label}</Label>
                      {(p as any).tier === 'free' && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">Free</span>
                      )}
                      {(p as any).tier === 'freemium' && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">Free + Paid</span>
                      )}
                      {(p as any).tier === 'paid' && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-orange-500/20 text-orange-300 border border-orange-500/30">Paid</span>
                      )}
                    </div>
                    {(isMasked || value) ? (
                      <span className="inline-flex items-center gap-1 text-xs text-emerald-400"><CheckCircle2 className="w-3.5 h-3.5" /> Set</span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-xs text-white/40"><AlertCircle className="w-3.5 h-3.5" /> Not set</span>
                    )}
                  </div>
                  <p className="text-xs text-white/50 mb-3">{isMasked ? 'A key is already saved. Leave blank to keep it, or paste a new key to replace it.' : p.hint}</p>
                  <div className="relative">
                    <Input
                      id={p.id}
                      type={visible ? 'text' : 'password'}
                      value={value}
                      onChange={(e) => setSettings(s => ({ ...s, [p.field]: e.target.value } as any))}
                      placeholder={isMasked ? '•••• already set — paste new key to replace' : p.placeholder}
                      className="bg-black/40 border-white/10 text-white pr-10 font-mono text-xs"
                      autoComplete="off" spellCheck={false}
                    />
                    <button
                      type="button"
                      onClick={() => setShow(s => ({ ...s, [p.id]: !s[p.id] }))}
                      className="absolute right-2 top-1/2 -translate-y-1/2 text-white/40 hover:text-white p-1.5"
                    >
                      {visible ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              )
            }
            return (
              <>
                <div className="text-xs uppercase tracking-wider text-white/40 mt-2 mb-1">Chat / Text AI providers</div>
                {PROVIDERS.map(renderProvider)}

                <div className="text-xs uppercase tracking-wider text-white/40 mt-6 mb-1">Image generation providers (free + paid)</div>
                <p className="text-xs text-white/50 -mt-1 mb-2">Add as many as you like. The system tries them in order — OpenAI → Nano-Banana → Imagen → Together (FLUX-Free) → Stability → Replicate → Hugging Face → Pollinations (always free) → Pixabay/Unsplash stock fallback. Pollinations works with no key.</p>
                {IMAGE_PROVIDERS.map(renderProvider)}

                <div className="text-xs uppercase tracking-wider text-white/40 mt-6 mb-1">Voice / Audio providers (TTS + STT)</div>
                <p className="text-xs text-white/50 -mt-1 mb-2">For text-to-speech narration, voice cloning, and speech-to-text transcription. All offer generous free tiers.</p>
                {VOICE_PROVIDERS.map(renderProvider)}

                <div className="text-xs uppercase tracking-wider text-white/40 mt-6 mb-1">AI Video generation providers (free + paid)</div>
                <p className="text-xs text-white/50 -mt-1 mb-2">Used by <strong>AI Video Gen</strong> + <strong>YouTube Gen</strong>. Try order: chosen video model first → FAL.ai → Replicate → Runway → Luma → Kling → MiniMax → Hugging Face (free fallback). FAL.ai is the cheapest unified gateway.</p>
                {VIDEO_PROVIDERS.map(renderProvider)}

                <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
                  <Label className="text-white text-sm font-semibold">Default Video Model</Label>
                  <p className="text-xs text-white/50 mt-1 mb-3">
                    Selected model decides the primary provider for AI Video / YouTube thumbnail b-roll. If it fails or its key is missing, the system automatically falls back to other configured video providers.
                  </p>
                  <Select value={settings.videoModel || 'fal-ai/wan/v2.5/text-to-video/fast'} onValueChange={(v) => setSettings(s => ({ ...s, videoModel: v }))}>
                    <SelectTrigger className="bg-black/40 border-white/10 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-[#0f0f1a] border-white/10 text-white max-h-[400px]">
                      {VIDEO_MODEL_GROUPS.map(g => (
                        <SelectGroup key={g.label}>
                          <SelectLabel className="text-white/40 text-[10px] uppercase tracking-wider">{g.label}</SelectLabel>
                          {g.options.map(m => (
                            <SelectItem key={m.value} value={m.value} className="focus:bg-white/5 focus:text-white">{m.label}</SelectItem>
                          ))}
                        </SelectGroup>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="text-xs uppercase tracking-wider text-white/40 mt-6 mb-1">Email blast (announcements)</div>
                {EMAIL_PROVIDERS.map(renderProvider)}
                <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
                  <Label className="text-white text-sm font-semibold">From email address</Label>
                  <p className="text-xs text-white/50 mt-1 mb-3">Used as the From: address for announcement emails. Must match a verified Resend domain.</p>
                  <Input
                    value={(settings as any).fromEmail || ''}
                    onChange={(e) => setSettings(s => ({ ...s, fromEmail: e.target.value } as any))}
                    placeholder="announcements@yourdomain.com"
                    className="bg-black/40 border-white/10 text-white font-mono text-xs"
                  />
                </div>

                {/* Email Verification Toggle */}
                <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5">
                  <div className="flex items-center justify-between">
                    <div>
                      <Label className="text-white text-sm font-semibold">OTP Email Verification on Registration</Label>
                      <p className="text-xs text-white/50 mt-1">When enabled, new users must verify their email with a 6-digit OTP code before their account is created. Requires an email provider to be configured above.</p>
                    </div>
                    <Switch
                      checked={!!(settings as any).emailVerificationEnabled}
                      onCheckedChange={(v) => setSettings(s => ({ ...s, emailVerificationEnabled: v } as any))}
                    />
                  </div>
                </div>

                {/* Gmail Configuration */}
                <div className="rounded-2xl border border-violet-500/20 bg-violet-500/5 p-5 space-y-4">
                  <div>
                    <Label className="text-white text-sm font-semibold flex items-center gap-2">
                      <span className="text-violet-400">📧</span> Gmail Configuration
                    </Label>
                    <p className="text-xs text-white/50 mt-1">Configure Gmail to send OTP emails and announcements. Use either OAuth2 (recommended) or App Password (simpler).</p>
                  </div>
                  <div className="grid grid-cols-1 gap-3">
                    <div>
                      <Label className="text-xs text-white/60 mb-1 block">Gmail Address</Label>
                      <Input value={(settings as any).gmailUser || ''} onChange={e => setSettings(s => ({ ...s, gmailUser: e.target.value } as any))} placeholder="your@gmail.com" className="bg-black/40 border-white/10 text-white font-mono text-xs" />
                    </div>
                    <div>
                      <Label className="text-xs text-white/60 mb-1 block">App Password <span className="text-white/30">(simpler — create at myaccount.google.com/security → 2-Step → App passwords)</span></Label>
                      <Input type="password" value={(settings as any).gmailAppPassword || ''} onChange={e => setSettings(s => ({ ...s, gmailAppPassword: e.target.value } as any))} placeholder="xxxx xxxx xxxx xxxx" className="bg-black/40 border-white/10 text-white font-mono text-xs" />
                    </div>
                    <div className="border-t border-white/10 pt-3">
                      <p className="text-xs text-white/40 mb-3">— OR use OAuth2 (more secure) —</p>
                      <div className="space-y-2">
                        <div>
                          <Label className="text-xs text-white/60 mb-1 block">OAuth2 Client ID</Label>
                          <Input type="password" value={(settings as any).gmailClientId || ''} onChange={e => setSettings(s => ({ ...s, gmailClientId: e.target.value } as any))} placeholder="xxxxx.apps.googleusercontent.com" className="bg-black/40 border-white/10 text-white font-mono text-xs" />
                        </div>
                        <div>
                          <Label className="text-xs text-white/60 mb-1 block">OAuth2 Client Secret</Label>
                          <Input type="password" value={(settings as any).gmailClientSecret || ''} onChange={e => setSettings(s => ({ ...s, gmailClientSecret: e.target.value } as any))} placeholder="GOCSPX-..." className="bg-black/40 border-white/10 text-white font-mono text-xs" />
                        </div>
                        <div>
                          <Label className="text-xs text-white/60 mb-1 block">OAuth2 Refresh Token</Label>
                          <Input type="password" value={(settings as any).gmailRefreshToken || ''} onChange={e => setSettings(s => ({ ...s, gmailRefreshToken: e.target.value } as any))} placeholder="1//0e..." className="bg-black/40 border-white/10 text-white font-mono text-xs" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )
          })()}

          {/* ─────────── LOGIN config (Discord + Gmail OAuth) ─────────── */}
          <div className="rounded-2xl border border-cyan-500/20 bg-cyan-500/5 p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <Label className="text-white text-sm font-semibold flex items-center gap-2">
                  <span className="text-cyan-400">🔐</span> LOGIN config — OAuth (Discord + Google)
                </Label>
                <p className="text-xs text-white/50 mt-1">Configure social login here. The buttons on the sign-in page will only appear if a provider has both Client ID + Secret saved.</p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-white/50">Enabled</span>
                <Switch
                  checked={(settings as any).oauthEnabled !== false}
                  onCheckedChange={(v) => setSettings(s => ({ ...s, oauthEnabled: v } as any))}
                />
              </div>
            </div>

            {/* Google */}
            <div className="rounded-xl border border-white/10 bg-black/30 p-4 space-y-3">
              <div className="flex items-center gap-2">
                <span className="text-base">🟢</span>
                <span className="text-sm font-semibold text-white">Google (Gmail) Login</span>
              </div>
              <p className="text-[11px] text-white/40">
                Create at <span className="text-cyan-300">console.cloud.google.com</span> → APIs &amp; Services → Credentials → OAuth 2.0 Client.
                Authorized redirect URI: <code className="text-cyan-300 bg-black/40 px-1 rounded">{`${typeof window !== 'undefined' ? window.location.origin : ''}/api/auth/callback/google`}</code>
              </p>
              <div>
                <Label className="text-xs text-white/60 mb-1 block">Google Client ID</Label>
                <Input
                  value={(settings as any).googleClientId || ''}
                  onChange={e => setSettings(s => ({ ...s, googleClientId: e.target.value } as any))}
                  placeholder="xxxxxxxx.apps.googleusercontent.com"
                  className="bg-black/40 border-white/10 text-white font-mono text-xs"
                />
              </div>
              <div>
                <Label className="text-xs text-white/60 mb-1 block">Google Client Secret</Label>
                <Input
                  type="password"
                  value={(settings as any).googleClientSecret || ''}
                  onChange={e => setSettings(s => ({ ...s, googleClientSecret: e.target.value } as any))}
                  placeholder="GOCSPX-..."
                  className="bg-black/40 border-white/10 text-white font-mono text-xs"
                />
              </div>
            </div>

            {/* Discord */}
            <div className="rounded-xl border border-white/10 bg-black/30 p-4 space-y-3">
              <div className="flex items-center gap-2">
                <span className="text-base">💬</span>
                <span className="text-sm font-semibold text-white">Discord Login</span>
              </div>
              <p className="text-[11px] text-white/40">
                Create at <span className="text-indigo-300">discord.com/developers/applications</span> → New Application → OAuth2.
                Add redirect: <code className="text-indigo-300 bg-black/40 px-1 rounded">{`${typeof window !== 'undefined' ? window.location.origin : ''}/api/auth/callback/discord`}</code>
              </p>
              <div>
                <Label className="text-xs text-white/60 mb-1 block">Discord Client ID</Label>
                <Input
                  value={(settings as any).discordClientId || ''}
                  onChange={e => setSettings(s => ({ ...s, discordClientId: e.target.value } as any))}
                  placeholder="1234567890..."
                  className="bg-black/40 border-white/10 text-white font-mono text-xs"
                />
              </div>
              <div>
                <Label className="text-xs text-white/60 mb-1 block">Discord Client Secret</Label>
                <Input
                  type="password"
                  value={(settings as any).discordClientSecret || ''}
                  onChange={e => setSettings(s => ({ ...s, discordClientSecret: e.target.value } as any))}
                  placeholder="xxxxxxxxxxxxxxxxx"
                  className="bg-black/40 border-white/10 text-white font-mono text-xs"
                />
              </div>
            </div>
            <p className="text-[11px] text-cyan-200/60">
              💡 Click <strong>Save</strong> below — changes take effect immediately, no restart needed.
            </p>
          </div>

          <div className="rounded-2xl border border-white/10 bg-white/[0.02] p-5 space-y-4">
            <div>
              <Label className="text-white text-sm font-semibold">Default AI Model</Label>
              <p className="text-xs text-white/50 mt-1 mb-3">
                Selected model decides the primary provider for site-wide chat. If it fails or the key is missing, other configured providers are tried automatically.
              </p>
              <Select value={settings.aiModel || 'gpt-4o-mini'} onValueChange={(v) => setSettings(s => ({ ...s, aiModel: v }))}>
                <SelectTrigger className="bg-black/40 border-white/10 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#0f0f1a] border-white/10 text-white max-h-[400px]">
                  {MODEL_GROUPS.map(g => (
                    <SelectGroup key={g.label}>
                      <SelectLabel className="text-white/40 text-[10px] uppercase tracking-wider">{g.label}</SelectLabel>
                      {g.options.map(m => (
                        <SelectItem key={m.value} value={m.value} className="focus:bg-white/5 focus:text-white">{m.label}</SelectItem>
                      ))}
                    </SelectGroup>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center justify-between pt-3 border-t border-white/5">
              <div>
                <Label className="text-white text-sm font-semibold">Low-token mode</Label>
                <p className="text-xs text-white/50 mt-0.5">Limit AI replies to ~500 tokens to save cost.</p>
              </div>
              <Switch
                checked={!!settings.lowTokenMode}
                onCheckedChange={(v) => setSettings(s => ({ ...s, lowTokenMode: v }))}
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-2">
            <Button variant="ghost" onClick={load} className="text-white/60 hover:text-white">Reset</Button>
            <Button
              onClick={save}
              disabled={saving}
              className="bg-gradient-to-r from-violet-600 to-cyan-600 hover:from-violet-500 hover:to-cyan-500 text-white border-0 gap-2"
            >
              <Save className="w-4 h-4" />
              {saving ? 'Saving…' : 'Save API Keys'}
            </Button>
          </div>

          <div className="rounded-2xl border border-violet-500/20 bg-violet-500/5 p-4 text-xs text-violet-200/80">
            <p className="font-semibold text-violet-200 mb-1">Image generation</p>
            <p>Site uses <strong>Banana / Nano-Banana</strong> (Gemini 2.5 Flash Image) for AI image gen. The Banana key — or your Google Gemini key — powers this. All generated images get a small <strong>GfxStore</strong> watermark in the bottom-left corner.</p>
          </div>
        </div>
      </div>
    </div>
  )
}
