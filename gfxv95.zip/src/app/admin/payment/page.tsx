'use client'

import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Badge } from '@/components/ui/badge'
import { Textarea } from '@/components/ui/textarea'
import {
  Smartphone, Bitcoin, Building2, Wallet, Key, Copy, Plus, Trash2,
  Clock, CheckCircle2, AlertCircle, RefreshCw,
  Globe, Shield, Eye, EyeOff,
} from 'lucide-react'
import { toast } from 'sonner'
import Link from 'next/link'

interface PaymentSettings {
  nagadEnabled: boolean; bkashEnabled: boolean; binanceEnabled: boolean; bankEnabled: boolean; paypalEnabled: boolean
  nagadNumber: string; bkashNumber: string; binanceId: string; paypalEmail: string
  nagadQr: string; bkashQr: string; binanceQr: string
  nagadInstruction: string; bkashInstruction: string; binanceInstruction: string; bankInstruction: string; paypalInstruction: string
  bankDetails: any
  afkEarningEnabled: boolean; afkRatePerMinute: number; afkMinMinutes: number; afkMaxPerDay: number
}

interface ExternalKey { id: string; name: string; key: string; isActive: boolean; requestCount: number; webhookUrl?: string; lastUsedAt?: string; owner: { username: string } }

export default function AdminPaymentPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [settings, setSettings] = useState<PaymentSettings>({
    nagadEnabled: true, bkashEnabled: true, binanceEnabled: false, bankEnabled: false, paypalEnabled: false,
    nagadNumber: '', bkashNumber: '', binanceId: '', paypalEmail: '',
    nagadQr: '', bkashQr: '', binanceQr: '',
    nagadInstruction: '', bkashInstruction: '', binanceInstruction: '', bankInstruction: '', paypalInstruction: '',
    bankDetails: { bankName: '', accountName: '', accountNumber: '', routingNumber: '', swiftCode: '', branch: '' },
    afkEarningEnabled: false, afkRatePerMinute: 0.01, afkMinMinutes: 5, afkMaxPerDay: 10,
  })
  const [extKeys, setExtKeys] = useState<ExternalKey[]>([])
  const [showKeys, setShowKeys] = useState<Record<string, boolean>>({})
  const [newKeyName, setNewKeyName] = useState('')
  const [newKeyWebhook, setNewKeyWebhook] = useState('')
  const [creatingKey, setCreatingKey] = useState(false)
  const [newlyCreatedKey, setNewlyCreatedKey] = useState<string | null>(null)

  useEffect(() => {
    if (status === 'loading') return
    const role = (session?.user as any)?.role
    if (!['ADMIN', 'SUPER_ADMIN'].includes(role || '')) { router.push('/'); return }
    loadAll()
  }, [status])

  const loadAll = async () => {
    setLoading(true)
    try {
      const [pRes, kRes] = await Promise.all([
        fetch('/api/admin/payment'),
        fetch('/api/admin/external-keys'),
      ])
      
      if (pRes.ok) {
        const ps = await pRes.json()
        setSettings(s => ({ ...s, ...ps, bankDetails: ps.bankDetails || s.bankDetails }))
      }
      
      if (kRes.ok) {
        const ks = await kRes.json()
        if (ks.keys) setExtKeys(ks.keys)
      } else {
        const kErr = await kRes.json()
        console.error('API Keys error:', kErr)
      }
    } catch (err) { 
      console.error('Load error:', err)
      toast.error('Failed to load some settings') 
    }
    finally { setLoading(false) }
  }

  const save = async () => {
    setSaving(true)
    try {
      const res = await fetch('/api/admin/payment', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      })
      if (res.ok) toast.success('Payment settings saved')
      else toast.error('Save failed')
    } finally { setSaving(false) }
  }

  const createKey = async () => {
    if (!newKeyName.trim()) return toast.error('Enter a key name')
    setCreatingKey(true)
    try {
      const res = await fetch('/api/admin/external-keys', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newKeyName, webhookUrl: newKeyWebhook || undefined }),
      })
      const data = await res.json()
      if (res.ok) {
        setExtKeys(prev => [data.key, ...prev])
        setNewlyCreatedKey(data.key.key)
        setNewKeyName(''); setNewKeyWebhook('')
        toast.success('API key created! Copy it now — it won\'t be shown again.')
      } else toast.error(data.error || 'Failed')
    } finally { setCreatingKey(false) }
  }

  const toggleKey = async (id: string, isActive: boolean) => {
    await fetch(`/api/admin/external-keys/${id}`, {
      method: 'PATCH', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ isActive }),
    })
    setExtKeys(prev => prev.map(k => k.id === id ? { ...k, isActive } : k))
    toast.success(isActive ? 'Key activated' : 'Key deactivated')
  }

  const deleteKey = async (id: string) => {
    if (!confirm('Delete this API key? This cannot be undone.')) return
    await fetch(`/api/admin/external-keys/${id}`, { method: 'DELETE' })
    setExtKeys(prev => prev.filter(k => k.id !== id))
    toast.success('Key deleted')
  }

  const copy = (text: string, label = 'Copied') => { navigator.clipboard.writeText(text); toast.success(label) }

  const set = (k: keyof PaymentSettings, v: any) => setSettings(s => ({ ...s, [k]: v }))
  const setBank = (k: string, v: string) => setSettings(s => ({ ...s, bankDetails: { ...s.bankDetails, [k]: v } }))

  if (loading) return (
    <div className="min-h-screen bg-[#07070d]"><Navbar />
      <div className="flex items-center justify-center h-64"><div className="w-8 h-8 border-2 border-violet-500 border-t-transparent rounded-full animate-spin" /></div>
    </div>
  )

  return (
    <div className="min-h-screen bg-[#07070d]">
      <Navbar />
      <div className="w-full max-w-4xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-white">Payment Management</h1>
            <p className="text-white/40 text-sm mt-1">Configure payment methods, API gateway, and AFK earning</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={loadAll} className="border-white/10 text-white/60 hover:text-white bg-transparent">
              <RefreshCw className="w-4 h-4 mr-2" />Refresh
            </Button>
            <Button onClick={save} disabled={saving} className="bg-violet-600 hover:bg-violet-500 text-white">
              {saving ? <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" /> : <CheckCircle2 className="w-4 h-4 mr-2" />}
              Save Changes
            </Button>
          </div>
        </div>

        <Tabs defaultValue="methods">
          <TabsList className="bg-white/[0.05] border border-white/10 mb-6 flex-wrap h-auto gap-1 p-1">
            <TabsTrigger value="methods" className="data-[state=active]:bg-violet-600 text-white/60 data-[state=active]:text-white">
              <Wallet className="w-4 h-4 mr-2" />Methods
            </TabsTrigger>
            <TabsTrigger value="api" className="data-[state=active]:bg-violet-600 text-white/60 data-[state=active]:text-white">
              <Key className="w-4 h-4 mr-2" />API Gateway
            </TabsTrigger>
            <Link href="/admin/afk" className="inline-flex items-center px-3 py-1.5 rounded-md text-sm text-white/60 hover:text-white hover:bg-white/[0.07] transition gap-2">
              <Clock className="w-4 h-4" />AFK Earning ↗
            </Link>
          </TabsList>

          {/* ── PAYMENT METHODS ─────────────────────────────── */}
          <TabsContent value="methods" className="space-y-4">
            {/* Nagad */}
            <MethodCard
              icon={<Smartphone className="w-5 h-5 text-orange-400" />}
              label="Nagad" badge="Popular" badgeColor="bg-orange-500/20 text-orange-300 border-orange-500/30"
              enabled={settings.nagadEnabled} onToggle={v => set('nagadEnabled', v)}
              color="border-orange-500/20"
            >
              <Field label="Nagad Number (Send Money number)">
                <Input value={settings.nagadNumber} onChange={e => set('nagadNumber', e.target.value)} placeholder="01xxxxxxxxx" className="bg-white/[0.05] border-white/10 text-white" />
              </Field>
              <Field label="QR Code Image URL (optional)">
                <Input value={settings.nagadQr} onChange={e => set('nagadQr', e.target.value)} placeholder="https://..." className="bg-white/[0.05] border-white/10 text-white" />
              </Field>
              <Field label="Instructions for users">
                <Textarea value={settings.nagadInstruction} onChange={e => set('nagadInstruction', e.target.value)} rows={2} placeholder="Send money using Nagad..." className="bg-white/[0.05] border-white/10 text-white resize-none" />
              </Field>
            </MethodCard>

            {/* bKash */}
            <MethodCard
              icon={<Smartphone className="w-5 h-5 text-pink-400" />}
              label="bKash" badge="BD Mobile" badgeColor="bg-pink-500/20 text-pink-300 border-pink-500/30"
              enabled={settings.bkashEnabled} onToggle={v => set('bkashEnabled', v)}
              color="border-pink-500/20"
            >
              <Field label="bKash Number (Send Money number)">
                <Input value={settings.bkashNumber} onChange={e => set('bkashNumber', e.target.value)} placeholder="01xxxxxxxxx" className="bg-white/[0.05] border-white/10 text-white" />
              </Field>
              <Field label="QR Code Image URL (optional)">
                <Input value={settings.bkashQr} onChange={e => set('bkashQr', e.target.value)} placeholder="https://..." className="bg-white/[0.05] border-white/10 text-white" />
              </Field>
              <Field label="Instructions for users">
                <Textarea value={settings.bkashInstruction} onChange={e => set('bkashInstruction', e.target.value)} rows={2} placeholder="Send money using bKash..." className="bg-white/[0.05] border-white/10 text-white resize-none" />
              </Field>
            </MethodCard>

            {/* Binance Pay */}
            <MethodCard
              icon={<Bitcoin className="w-5 h-5 text-yellow-400" />}
              label="Binance Pay" badge="Crypto" badgeColor="bg-yellow-500/20 text-yellow-300 border-yellow-500/30"
              enabled={settings.binanceEnabled} onToggle={v => set('binanceEnabled', v)}
              color="border-yellow-500/20"
            >
              <Field label="Binance Pay ID">
                <Input value={settings.binanceId} onChange={e => set('binanceId', e.target.value)} placeholder="Binance Pay ID..." className="bg-white/[0.05] border-white/10 text-white" />
              </Field>
              <Field label="QR Code Image URL (optional)">
                <Input value={settings.binanceQr} onChange={e => set('binanceQr', e.target.value)} placeholder="https://..." className="bg-white/[0.05] border-white/10 text-white" />
              </Field>
              <Field label="Instructions for users">
                <Textarea value={settings.binanceInstruction} onChange={e => set('binanceInstruction', e.target.value)} rows={2} placeholder="Send USDT to this Binance Pay ID..." className="bg-white/[0.05] border-white/10 text-white resize-none" />
              </Field>
            </MethodCard>

            {/* Bank Transfer */}
            <MethodCard
              icon={<Building2 className="w-5 h-5 text-blue-400" />}
              label="Bank Transfer" badge="Global" badgeColor="bg-blue-500/20 text-blue-300 border-blue-500/30"
              enabled={settings.bankEnabled} onToggle={v => set('bankEnabled', v)}
              color="border-blue-500/20"
            >
              <div className="grid grid-cols-2 gap-3">
                {[
                  { k: 'bankName', label: 'Bank Name', placeholder: 'Dutch-Bangla Bank' },
                  { k: 'accountName', label: 'Account Name', placeholder: 'Your Name' },
                  { k: 'accountNumber', label: 'Account Number', placeholder: '1234567890' },
                  { k: 'routingNumber', label: 'Routing Number', placeholder: '123456789' },
                  { k: 'swiftCode', label: 'SWIFT/BIC Code', placeholder: 'DBBLBDDH' },
                  { k: 'branch', label: 'Branch', placeholder: 'Gulshan Branch' },
                ].map(({ k, label, placeholder }) => (
                  <Field key={k} label={label}>
                    <Input value={settings.bankDetails?.[k] || ''} onChange={e => setBank(k, e.target.value)} placeholder={placeholder} className="bg-white/[0.05] border-white/10 text-white" />
                  </Field>
                ))}
              </div>
              <Field label="Instructions for users">
                <Textarea value={settings.bankInstruction} onChange={e => set('bankInstruction', e.target.value)} rows={2} placeholder="Transfer to the account below..." className="bg-white/[0.05] border-white/10 text-white resize-none" />
              </Field>
            </MethodCard>

            {/* PayPal */}
            <MethodCard
              icon={<Globe className="w-5 h-5 text-sky-400" />}
              label="PayPal" badge="International" badgeColor="bg-sky-500/20 text-sky-300 border-sky-500/30"
              enabled={settings.paypalEnabled} onToggle={v => set('paypalEnabled', v)}
              color="border-sky-500/20"
            >
              <Field label="PayPal Email">
                <Input value={settings.paypalEmail} onChange={e => set('paypalEmail', e.target.value)} placeholder="your@paypal.com" className="bg-white/[0.05] border-white/10 text-white" />
              </Field>
              <Field label="Instructions for users">
                <Textarea value={settings.paypalInstruction} onChange={e => set('paypalInstruction', e.target.value)} rows={2} placeholder="Send to the PayPal email..." className="bg-white/[0.05] border-white/10 text-white resize-none" />
              </Field>
            </MethodCard>

            <div className="pt-2 flex justify-end">
              <Button onClick={save} disabled={saving} className="bg-violet-600 hover:bg-violet-500 text-white px-8">
                {saving ? 'Saving...' : 'Save Payment Settings'}
              </Button>
            </div>
          </TabsContent>

          {/* ── PAYMENT GATEWAY API ─────────────────────────── */}
          <TabsContent value="api" className="space-y-6">
            {/* Info card */}
            <div className="rounded-2xl border border-violet-500/20 bg-violet-500/5 p-5">
              <div className="flex items-start gap-3">
                <Shield className="w-5 h-5 text-violet-300 mt-0.5 flex-shrink-0" />
                <div>
                  <h3 className="text-white font-semibold mb-1">Payment Gateway API</h3>
                  <p className="text-white/50 text-sm mb-3">Give API keys to external developers so they can use your payment gateway in their apps. Each key can create deposit requests on behalf of your users.</p>
                  <div className="rounded-xl bg-white/[0.04] border border-white/10 p-3 font-mono text-xs text-white/70 space-y-1">
                    <p className="text-violet-300 font-semibold">POST /api/v1/payment/deposit</p>
                    <p>Headers: <span className="text-emerald-300">X-API-Key: gfx_xxxx</span></p>
                    <p>Body: <span className="text-amber-300">{'{ userId, amount, method, reference? }'}</span></p>
                    <p className="mt-2 text-violet-300 font-semibold">GET /api/v1/payment/status?txId=xxx</p>
                    <p>Headers: <span className="text-emerald-300">X-API-Key: gfx_xxxx</span></p>
                  </div>
                  <Link href="/admin/payment/docs" className="inline-flex items-center gap-1 mt-3 text-violet-300 text-xs hover:text-violet-200">
                    View full API docs →
                  </Link>
                </div>
              </div>
            </div>

            {/* Newly created key banner */}
            {newlyCreatedKey && (
              <div className="rounded-2xl border border-emerald-500/30 bg-emerald-500/5 p-4">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <p className="text-emerald-300 font-semibold text-sm mb-1">New API key created! Copy it now — it won't be shown again.</p>
                    <code className="text-white font-mono text-xs break-all">{newlyCreatedKey}</code>
                  </div>
                  <Button size="sm" onClick={() => copy(newlyCreatedKey, 'API key copied!')} className="bg-emerald-600 hover:bg-emerald-500 text-white flex-shrink-0">
                    <Copy className="w-3.5 h-3.5" />
                  </Button>
                </div>
                <button className="mt-2 text-white/40 text-xs" onClick={() => setNewlyCreatedKey(null)}>Dismiss</button>
              </div>
            )}

            {/* Create new key */}
            <div className="rounded-2xl border border-white/[0.08] bg-white/[0.02] p-5">
              <h3 className="text-white font-semibold mb-4 flex items-center gap-2"><Plus className="w-4 h-4" />Create New API Key</h3>
              <div className="grid sm:grid-cols-2 gap-3 mb-3">
                <Field label="Key Name (e.g. My App)">
                  <Input value={newKeyName} onChange={e => setNewKeyName(e.target.value)} placeholder="My Website" className="bg-white/[0.05] border-white/10 text-white" />
                </Field>
                <Field label="Webhook URL (optional)">
                  <Input value={newKeyWebhook} onChange={e => setNewKeyWebhook(e.target.value)} placeholder="https://yoursite.com/webhook" className="bg-white/[0.05] border-white/10 text-white" />
                </Field>
              </div>
              <Button onClick={createKey} disabled={creatingKey} className="bg-violet-600 hover:bg-violet-500 text-white">
                {creatingKey ? 'Creating...' : <><Plus className="w-4 h-4 mr-2" />Create Key</>}
              </Button>
            </div>

            {/* Webhook info card */}
            <div className="rounded-2xl border border-blue-500/20 bg-blue-500/5 p-5">
              <div className="flex items-start gap-3">
                <Globe className="w-5 h-5 text-blue-300 mt-0.5 flex-shrink-0" />
                <div className="flex-1">
                  <h3 className="text-white font-semibold mb-1">Webhook Callback</h3>
                  <p className="text-white/50 text-sm mb-3">GfxStore POSTs to your webhook URL when a deposit is approved. Set a webhook URL per key below.</p>
                  <div className="rounded-xl bg-white/[0.04] border border-white/10 p-3 font-mono text-xs text-white/70 space-y-1">
                    <p className="text-blue-300 font-semibold">POST {'<your-webhook-url>'}</p>
                    <p className="text-white/40">GfxStore sends this payload when a payment is approved:</p>
                    <pre className="text-amber-300 mt-1 whitespace-pre-wrap">{`{
  "event": "payment.approved",
  "txId": "clxxxx",
  "userId": "user_id",
  "amount": 100,
  "method": "nagad",
  "status": "APPROVED",
  "approvedAt": "2025-01-01T00:00:00Z"
}`}</pre>
                  </div>
                </div>
              </div>
            </div>

            {/* Key list */}
            <div className="space-y-3">
              {extKeys.length === 0 ? (
                <div className="rounded-2xl border border-white/[0.06] bg-white/[0.02] p-8 text-center text-white/30 text-sm">No API keys yet</div>
              ) : extKeys.map(k => (
                <div key={k.id} className={`rounded-2xl border p-4 ${k.isActive ? 'border-white/[0.08] bg-white/[0.02]' : 'border-red-500/15 bg-red-500/5 opacity-60'}`}>
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-white font-medium">{k.name}</span>
                        <Badge className={k.isActive ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' : 'bg-red-500/20 text-red-300 border-red-500/30'}>
                          {k.isActive ? 'Active' : 'Inactive'}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2 mb-2">
                        <code className="text-white/50 font-mono text-xs">{showKeys[k.id] ? k.key : k.key.slice(0, 8) + '••••••••••••••••••••'}</code>
                        <button onClick={() => setShowKeys(p => ({ ...p, [k.id]: !p[k.id] }))} className="text-white/30 hover:text-white/60">
                          {showKeys[k.id] ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </button>
                        <button onClick={() => copy(k.key, 'Key copied!')} className="text-white/30 hover:text-white/60"><Copy className="w-3.5 h-3.5" /></button>
                      </div>
                      <div className="flex flex-wrap gap-3 text-[11px] text-white/30">
                        <span>Owner: {k.owner?.username || 'Unknown'}</span>
                        <span>Requests: {k.requestCount}</span>
                        {k.lastUsedAt && <span>Last used: {new Date(k.lastUsedAt).toLocaleDateString()}</span>}
                      </div>
                      {k.webhookUrl && (
                        <div className="mt-2 flex items-center gap-2 px-2 py-1.5 rounded-lg bg-blue-500/5 border border-blue-500/15 w-fit max-w-full">
                          <Globe className="w-3 h-3 text-blue-400 flex-shrink-0" />
                          <code className="text-blue-300/70 text-[11px] truncate max-w-[280px]">{k.webhookUrl}</code>
                          <button onClick={() => copy(k.webhookUrl!, 'Webhook URL copied')} className="text-white/20 hover:text-white/50 flex-shrink-0">
                            <Copy className="w-3 h-3" />
                          </button>
                        </div>
                      )}
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <Switch checked={k.isActive} onCheckedChange={v => toggleKey(k.id, v)} />
                      <Button size="sm" variant="ghost" onClick={() => deleteKey(k.id)} className="text-red-400 hover:text-red-300 hover:bg-red-500/10 h-8 w-8 p-0">
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </TabsContent>

        </Tabs>
      </div>
    </div>
  )
}

function MethodCard({ children, icon, label, badge, badgeColor, enabled, onToggle, color }: {
  children: React.ReactNode; icon: React.ReactNode; label: string; badge: string
  badgeColor: string; enabled: boolean; onToggle: (v: boolean) => void; color: string
}) {
  return (
    <div className={`rounded-2xl border ${enabled ? color : 'border-white/[0.06]'} bg-white/[0.02] p-5 transition-all ${!enabled && 'opacity-60'}`}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-white/[0.04] flex items-center justify-center">{icon}</div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-white font-semibold">{label}</span>
              <Badge className={`text-[10px] ${badgeColor}`}>{badge}</Badge>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-white/40 text-sm">{enabled ? 'Enabled' : 'Disabled'}</span>
          <Switch checked={enabled} onCheckedChange={onToggle} />
        </div>
      </div>
      {enabled && <div className="space-y-3">{children}</div>}
    </div>
  )
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-white/50 text-xs font-medium">{label}</Label>
      {children}
    </div>
  )
}
