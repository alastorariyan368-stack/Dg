'use client'

import { useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Copy, CheckCircle2, ArrowLeft } from 'lucide-react'
import Link from 'next/link'
import { toast } from 'sonner'

export default function ApiDocsPage() {
  const { data: session } = useSession()
  const role = (session?.user as any)?.role

  const copy = (text: string) => { navigator.clipboard.writeText(text); toast.success('Copied!') }

  const CodeBlock = ({ code, lang = 'json' }: { code: string; lang?: string }) => (
    <div className="relative rounded-xl bg-[#0a0a18] border border-white/[0.06] p-4 overflow-x-auto">
      <button onClick={() => copy(code)} className="absolute top-3 right-3 p-1.5 rounded-lg bg-white/[0.06] hover:bg-white/[0.1] text-white/40 hover:text-white transition-all">
        <Copy className="w-3.5 h-3.5" />
      </button>
      <pre className="font-mono text-xs text-white/70 whitespace-pre-wrap break-all">{code}</pre>
    </div>
  )

  const Endpoint = ({ method, path, desc, children }: any) => (
    <div className="rounded-2xl border border-white/[0.07] bg-white/[0.02] overflow-hidden">
      <div className="flex items-center gap-3 px-5 py-3 bg-white/[0.03] border-b border-white/[0.06]">
        <Badge className={`font-mono text-xs ${method === 'POST' ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30' : 'bg-blue-500/20 text-blue-300 border-blue-500/30'}`}>{method}</Badge>
        <code className="text-white font-mono text-sm">{path}</code>
        <span className="text-white/30 text-xs ml-auto">{desc}</span>
      </div>
      <div className="p-5 space-y-4">{children}</div>
    </div>
  )

  return (
    <div className="min-h-screen bg-[#07070d]">
      <Navbar />
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="flex items-center gap-3 mb-6">
          <Link href="/admin/payment">
            <Button variant="ghost" size="sm" className="text-white/40 hover:text-white">
              <ArrowLeft className="w-4 h-4 mr-1" />Back
            </Button>
          </Link>
          <div>
            <h1 className="text-2xl font-bold text-white">Payment Gateway API</h1>
            <p className="text-white/40 text-sm">Allow third-party apps to use your payment infrastructure</p>
          </div>
        </div>

        {/* Auth */}
        <div className="rounded-2xl border border-white/[0.07] bg-white/[0.02] p-5 mb-6">
          <h2 className="text-white font-semibold mb-2">Authentication</h2>
          <p className="text-white/50 text-sm mb-3">All endpoints require an API key. Create one in <Link href="/admin/payment" className="text-violet-300 hover:underline">Admin → Payment → API Gateway</Link>.</p>
          <CodeBlock code={`// Send the key in every request header:
X-API-Key: gfx_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

// OR as Bearer token:
Authorization: Bearer gfx_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`} lang="http" />
        </div>

        <div className="space-y-4">
          {/* Create deposit */}
          <Endpoint method="POST" path="/api/v1/payment/deposit" desc="Create a deposit request">
            <p className="text-white/50 text-sm">Creates a pending deposit transaction. Returns payment details so you can show them to the user.</p>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <p className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-2">Request Body</p>
                <CodeBlock code={JSON.stringify({ userId: "user_id_here", amount: 100, method: "nagad", reference: "optional-ref", metadata: { orderId: "xyz" } }, null, 2)} />
              </div>
              <div>
                <p className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-2">Response 200</p>
                <CodeBlock code={JSON.stringify({ success: true, transactionId: "cmxxx...", reference: "optional-ref", status: "PENDING", paymentTarget: "01xxxxxxxxx", instructions: "Send ৳100 via nagad..." }, null, 2)} />
              </div>
            </div>
            <div>
              <p className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-2">Supported Methods</p>
              <div className="flex flex-wrap gap-2">
                {['nagad', 'bkash', 'binance', 'bank', 'paypal'].map(m => (
                  <Badge key={m} className="bg-white/[0.05] text-white/60 border-white/10 font-mono text-xs">{m}</Badge>
                ))}
              </div>
            </div>
          </Endpoint>

          {/* Check status */}
          <Endpoint method="GET" path="/api/v1/payment/status?txId=xxx" desc="Check transaction status">
            <p className="text-white/50 text-sm">Poll this endpoint to check if a deposit has been approved by the admin.</p>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <p className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-2">Query Params</p>
                <CodeBlock code="txId=cmxxxxxxxx (transaction ID from deposit response)" />
              </div>
              <div>
                <p className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-2">Response 200</p>
                <CodeBlock code={JSON.stringify({ transactionId: "cmxxx...", status: "APPROVED", amount: 100, method: "nagad", reference: "ref-123", createdAt: "2025-01-01T00:00:00Z" }, null, 2)} />
              </div>
            </div>
            <div>
              <p className="text-white/40 text-xs font-semibold uppercase tracking-wider mb-2">Status Values</p>
              <div className="flex flex-wrap gap-2">
                {[['PENDING', 'amber'], ['APPROVED', 'emerald'], ['REJECTED', 'red']].map(([s, c]) => (
                  <Badge key={s} className={`bg-${c}-500/20 text-${c}-300 border-${c}-500/30 font-mono text-xs`}>{s}</Badge>
                ))}
              </div>
            </div>
          </Endpoint>

          {/* Webhook */}
          <div className="rounded-2xl border border-white/[0.07] bg-white/[0.02] p-5">
            <h3 className="text-white font-semibold mb-2">Webhooks</h3>
            <p className="text-white/50 text-sm mb-3">If you set a webhook URL when creating your API key, we'll POST to that URL when a payment event occurs.</p>
            <CodeBlock code={JSON.stringify({ event: "payment.created", transactionId: "cmxxx...", userId: "user_id", amount: 100, method: "nagad", status: "PENDING", metadata: { orderId: "xyz" } }, null, 2)} />
          </div>

          {/* Code example */}
          <div className="rounded-2xl border border-white/[0.07] bg-white/[0.02] p-5">
            <h3 className="text-white font-semibold mb-3">Example — JavaScript / Node.js</h3>
            <CodeBlock code={`const res = await fetch('https://yourdomain.com/api/v1/payment/deposit', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
    'X-API-Key': 'gfx_your_key_here'
  },
  body: JSON.stringify({
    userId: 'user_abc123',
    amount: 500,
    method: 'bkash',
    reference: 'order_456'
  })
})
const data = await res.json()
// Show data.paymentTarget (phone number) and data.instructions to user`} lang="js" />
          </div>

          {/* Error codes */}
          <div className="rounded-2xl border border-white/[0.07] bg-white/[0.02] p-5">
            <h3 className="text-white font-semibold mb-3">Error Codes</h3>
            <div className="space-y-2">
              {[
                { code: 401, msg: 'Invalid or missing API key' },
                { code: 403, msg: 'Key lacks required permission' },
                { code: 404, msg: 'User not found' },
                { code: 400, msg: 'Missing required fields or invalid amount' },
                { code: 500, msg: 'Server error — contact admin' },
              ].map(e => (
                <div key={e.code} className="flex items-center gap-3 py-2 border-b border-white/[0.05] last:border-0">
                  <Badge className="bg-red-500/20 text-red-300 border-red-500/30 font-mono w-12 justify-center">{e.code}</Badge>
                  <span className="text-white/50 text-sm">{e.msg}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
