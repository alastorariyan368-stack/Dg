'use client'
import { useState, useEffect } from 'react'
import { Mail, Plus, Trash2, ToggleLeft, ToggleRight, RefreshCw, Zap, CheckCircle2, XCircle, Loader2 } from 'lucide-react'

interface Domain { id: string; domain: string; isActive: boolean; createdAt: string }
interface Stats { inboxCount: number; msgCount: number }
interface DnsResult { domain: string; serverIp?: string; alreadyHadA?: boolean; alreadyHadMX?: boolean; created?: string[]; error?: string }

export default function AdminTempMailPage() {
  const [domains, setDomains] = useState<Domain[]>([])
  const [stats, setStats] = useState<Stats>({ inboxCount: 0, msgCount: 0 })
  const [newDomain, setNewDomain] = useState('')
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [error, setError] = useState('')
  const [copied, setCopied] = useState('')
  const [dnsLoading, setDnsLoading] = useState(false)
  const [dnsResults, setDnsResults] = useState<DnsResult[] | null>(null)
  const [dnsError, setDnsError] = useState('')

  const setupDns = async () => {
    setDnsLoading(true); setDnsError(''); setDnsResults(null)
    const r = await fetch('/api/admin/tempmail/setup-dns', { method: 'POST' })
    const data = await r.json()
    if (!r.ok) { setDnsError(data.error); setDnsLoading(false); return }
    setDnsResults(data.results)
    setDnsLoading(false)
    load()
  }

  const load = async () => {
    setLoading(true)
    const r = await fetch('/api/admin/tempmail')
    const data = await r.json()
    setDomains(data.domains || [])
    setStats(data.stats || {})
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  const addDomain = async () => {
    if (!newDomain.trim()) return
    setSaving(true); setError('')
    const r = await fetch('/api/admin/tempmail', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ domain: newDomain.trim().toLowerCase() }),
    })
    const data = await r.json()
    if (!r.ok) { setError(data.error); setSaving(false); return }
    setNewDomain('')
    setSaving(false)
    load()
  }

  const toggleDomain = async (id: string, isActive: boolean) => {
    await fetch('/api/admin/tempmail', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, isActive }),
    })
    load()
  }

  const deleteDomain = async (id: string) => {
    if (!confirm('Delete this domain? All inboxes will be lost.')) return
    await fetch('/api/admin/tempmail', {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id }),
    })
    load()
  }


  return (
    <div className="min-h-screen bg-gray-950 text-white p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          <div className="p-2 bg-blue-500/20 rounded-lg">
            <Mail className="w-6 h-6 text-blue-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">Temp Mail Config</h1>
            <p className="text-gray-400 text-sm">Manage email domains and webhook settings</p>
          </div>
          <button onClick={load} className="ml-auto p-2 rounded-lg bg-white/5 hover:bg-white/10 transition">
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          {[
            { label: 'Active Domains', value: domains.filter(d => d.isActive).length },
            { label: 'Total Inboxes', value: stats.inboxCount },
            { label: 'Messages Received', value: stats.msgCount },
          ].map(s => (
            <div key={s.label} className="bg-white/5 rounded-xl p-4 border border-white/10">
              <div className="text-2xl font-bold text-blue-400">{s.value}</div>
              <div className="text-gray-400 text-sm mt-1">{s.label}</div>
            </div>
          ))}
        </div>

        {/* Built-in SMTP Info */}
        <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-4 mb-6">
          <h3 className="font-semibold text-green-400 mb-2">✅ Built-in SMTP Server</h3>
          <p className="text-gray-300 text-sm mb-3">
            No external mail server needed. The app has a built-in SMTP server. Just point your domain's MX record to this server's IP.
          </p>
          <div className="space-y-2 text-xs">
            <div className="bg-black/30 rounded-lg px-3 py-2">
              <span className="text-gray-400">Step 1 — Start with custom server:</span>
              <code className="block text-green-400 mt-1">npm run custom-dev  <span className="text-gray-500"># or custom-start for production</span></code>
            </div>
            <div className="bg-black/30 rounded-lg px-3 py-2">
              <span className="text-gray-400">Step 2 — DNS: Add MX record for your domain pointing to this server's IP</span>
              <code className="block text-blue-400 mt-1">MX  tempmail.yourdomain.com  →  your.server.ip  (priority 10)</code>
            </div>
            <div className="bg-black/30 rounded-lg px-3 py-2">
              <span className="text-gray-400">Step 3 — Add the domain below. Done — emails arrive automatically!</span>
            </div>
          </div>
          <p className="text-gray-500 text-xs mt-3">
            Default SMTP port: <code className="text-gray-300">25</code>. If blocked, set <code className="text-gray-300">SMTP_PORT=2525</code> in .env and use port 2525.
          </p>
        </div>

        {/* DNS Auto-Setup */}
        <div className="bg-purple-500/10 border border-purple-500/30 rounded-xl p-4 mb-6">
          <div className="flex items-start justify-between gap-4">
            <div>
              <h3 className="font-semibold text-purple-400 mb-1">⚡ Auto DNS Setup (Cloudflare)</h3>
              <p className="text-gray-400 text-xs">
                Automatically creates A + MX records in Cloudflare for all active domains.
                Requires Cloudflare API Token in Admin → Zero Trust settings.
              </p>
            </div>
            <button
              onClick={setupDns}
              disabled={dnsLoading}
              className="shrink-0 flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-500 disabled:opacity-50 rounded-lg text-sm font-medium transition"
            >
              {dnsLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
              {dnsLoading ? 'Setting up...' : 'Auto Setup DNS'}
            </button>
          </div>
          {dnsError && <p className="text-red-400 text-xs mt-3 bg-red-500/10 rounded-lg px-3 py-2">{dnsError}</p>}
          {dnsResults && (
            <div className="mt-3 space-y-2">
              {dnsResults.map((r, i) => (
                <div key={i} className={`rounded-lg px-3 py-2 text-xs ${r.error ? 'bg-red-500/10 border border-red-500/20' : 'bg-green-500/10 border border-green-500/20'}`}>
                  {r.error ? (
                    <div className="flex items-center gap-2 text-red-400"><XCircle className="w-3.5 h-3.5" />{r.domain}: {r.error}</div>
                  ) : (
                    <div className="flex items-center gap-2 text-green-400">
                      <CheckCircle2 className="w-3.5 h-3.5 shrink-0" />
                      <span><strong>{r.domain}</strong> — IP: {r.serverIp} — {r.created && r.created.length > 0 ? `Created: ${r.created.join(', ')}` : 'Records already existed ✓'}</span>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Add Domain */}
        <div className="bg-white/5 rounded-xl p-5 border border-white/10 mb-6">
          <h3 className="font-semibold mb-3">Add Email Domain</h3>
          <div className="flex gap-3">
            <input
              type="text"
              value={newDomain}
              onChange={e => setNewDomain(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && addDomain()}
              placeholder="e.g. tempmail.gfxv70.com"
              className="flex-1 bg-black/30 border border-white/10 rounded-lg px-4 py-2 text-sm outline-none focus:border-blue-500 transition"
            />
            <button
              onClick={addDomain}
              disabled={saving}
              className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 rounded-lg text-sm font-medium transition"
            >
              <Plus className="w-4 h-4" />
              {saving ? 'Adding...' : 'Add Domain'}
            </button>
          </div>
          {error && <p className="text-red-400 text-sm mt-2">{error}</p>}
        </div>

        {/* Domains List */}
        <div className="space-y-3">
          <h3 className="font-semibold text-gray-300">Configured Domains ({domains.length})</h3>
          {loading ? (
            <div className="text-center py-8 text-gray-500">Loading...</div>
          ) : domains.length === 0 ? (
            <div className="text-center py-12 bg-white/3 rounded-xl border border-white/5 text-gray-500">
              No domains configured yet. Add your first domain above.
            </div>
          ) : (
            domains.map(d => (
              <div key={d.id} className="flex items-center gap-3 bg-white/5 rounded-xl px-4 py-3 border border-white/10">
                <div className={`w-2 h-2 rounded-full shrink-0 ${d.isActive ? 'bg-green-400' : 'bg-gray-600'}`} />
                <span className="flex-1 font-mono text-sm">{d.domain}</span>
                <span className={`text-xs px-2 py-0.5 rounded-full ${d.isActive ? 'bg-green-500/20 text-green-400' : 'bg-gray-500/20 text-gray-400'}`}>
                  {d.isActive ? 'Active' : 'Disabled'}
                </span>
                <button
                  onClick={() => toggleDomain(d.id, !d.isActive)}
                  className="p-1.5 rounded-lg hover:bg-white/10 transition"
                  title={d.isActive ? 'Disable' : 'Enable'}
                >
                  {d.isActive ? <ToggleRight className="w-5 h-5 text-green-400" /> : <ToggleLeft className="w-5 h-5 text-gray-500" />}
                </button>
                <button
                  onClick={() => deleteDomain(d.id)}
                  className="p-1.5 rounded-lg hover:bg-red-500/20 text-red-400 transition"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  )
}
