'use client'

import { useState, useEffect } from 'react'
import { Save, Bot, Sliders, Cpu, Terminal, Brain } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Switch } from '@/components/ui/switch'
import { toast } from 'sonner'

interface DiscordBotConfig {
  maxBotsPerUser: number
  maxRamPerBot: number
  aiEnabled: boolean
  defaultPrefix: string
}

export default function DiscordBotAdminPage() {
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [config, setConfig] = useState<DiscordBotConfig>({
    maxBotsPerUser: 5,
    maxRamPerBot: 512,
    aiEnabled: true,
    defaultPrefix: '!',
  })

  useEffect(() => {
    load()
  }, [])

  async function load() {
    setLoading(true)
    try {
      const r = await fetch('/api/admin/discordbot')
      if (r.ok) {
        const d = await r.json()
        setConfig({
          maxBotsPerUser: d.maxBotsPerUser ?? 5,
          maxRamPerBot: d.maxRamPerBot ?? 512,
          aiEnabled: d.aiEnabled ?? true,
          defaultPrefix: d.defaultPrefix ?? '!',
        })
      }
    } catch {
      toast.error('Failed to load Discord bot settings')
    } finally {
      setLoading(false)
    }
  }

  async function save() {
    setSaving(true)
    try {
      const r = await fetch('/api/admin/discordbot', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(config),
      })
      if (r.ok) {
        toast.success('Discord bot settings saved')
      } else {
        const err = await r.json().catch(() => ({}))
        throw new Error(err.error || 'Failed to save')
      }
    } catch (e: any) {
      toast.error(e.message || 'Failed to save')
    } finally {
      setSaving(false)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-2 border-purple-500 border-t-transparent" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <div className="w-12 h-12 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center">
            <Bot className="w-6 h-6 text-purple-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white">Discord Bot Settings</h1>
            <p className="text-gray-400 text-sm">Configure global Discord bot behaviour and limits</p>
          </div>
        </div>

        {/* Limits */}
        <div className="rounded-2xl border border-gray-700 bg-gray-800 p-6 mb-4">
          <div className="flex items-center gap-2 mb-1">
            <Sliders className="w-4 h-4 text-purple-400" />
            <h3 className="text-sm font-semibold text-white">Limits</h3>
          </div>
          <p className="text-xs text-gray-400 mb-5 ml-6">Set maximums that apply to all users across the platform.</p>
          <div className="space-y-4 ml-6">
            <div>
              <label className="text-xs font-medium text-gray-300 mb-1.5 block">Max Bots Per User</label>
              <Input
                type="number"
                min={1}
                max={100}
                value={config.maxBotsPerUser}
                onChange={(e) => setConfig({ ...config, maxBotsPerUser: parseInt(e.target.value) || 1 })}
                className="bg-gray-900 border-gray-700 text-white w-32"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-gray-300 mb-1.5 block">Max RAM Per Bot (MB)</label>
              <Input
                type="number"
                min={64}
                max={8192}
                step={64}
                value={config.maxRamPerBot}
                onChange={(e) => setConfig({ ...config, maxRamPerBot: parseInt(e.target.value) || 64 })}
                className="bg-gray-900 border-gray-700 text-white w-32"
              />
            </div>
          </div>
        </div>

        {/* Resources */}
        <div className="rounded-2xl border border-gray-700 bg-gray-800 p-6 mb-4">
          <div className="flex items-center gap-2 mb-1">
            <Cpu className="w-4 h-4 text-purple-400" />
            <h3 className="text-sm font-semibold text-white">Resources</h3>
          </div>
          <p className="text-xs text-gray-400 mb-5 ml-6">Control which features bots can use at startup.</p>
          <div className="space-y-4 ml-6">
            <div className="flex items-center justify-between">
              <div>
                <label className="text-xs font-medium text-gray-300">AI Enabled</label>
                <p className="text-[11px] text-gray-500">Allow bots to use AI-powered features</p>
              </div>
              <Switch
                checked={config.aiEnabled}
                onCheckedChange={(v) => setConfig({ ...config, aiEnabled: v })}
                className="data-[state=checked]:bg-purple-500"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-gray-300 mb-1.5 block">Default Prefix</label>
              <Input
                value={config.defaultPrefix}
                onChange={(e) => setConfig({ ...config, defaultPrefix: e.target.value })}
                placeholder="!"
                maxLength={5}
                className="bg-gray-900 border-gray-700 text-white w-32 font-mono"
              />
            </div>
          </div>
        </div>

        {/* Info card */}
        <div className="rounded-2xl border border-purple-500/20 bg-purple-500/5 p-5 mb-6">
          <div className="flex items-start gap-3">
            <Brain className="w-5 h-5 text-purple-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-sm font-semibold text-purple-200">Discord Bot System</p>
              <p className="text-xs text-purple-300/70 mt-1">
                Bots run in isolated containers with resource limits. Changes apply to newly created bots — existing bots retain their current configuration until restarted.
              </p>
            </div>
          </div>
        </div>

        {/* Save */}
        <Button
          onClick={save}
          disabled={saving}
          className="w-full bg-purple-600 hover:bg-purple-500 text-white border-0 rounded-xl gap-2 h-10"
        >
          <Save className="w-4 h-4" />
          {saving ? 'Saving...' : 'Save Settings'}
        </Button>
      </div>
    </div>
  )
}
