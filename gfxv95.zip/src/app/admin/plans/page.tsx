'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Textarea } from '@/components/ui/textarea'
import { Switch } from '@/components/ui/switch'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { 
  Trash2, 
  Edit, 
  Plus, 
  Save, 
  X,
  Loader2,
  Zap,
  Server,
  HardDrive,
  Clock,
  Cpu,
  Database,
  Image as ImageIcon,
  Link as LinkIcon,
  MessageCircle
} from 'lucide-react'

interface Plan {
  id: string
  name: string
  description: string
  price: number
  features?: any[]
  specs?: any
  isActive: boolean
  sortOrder: number
  createdAt: string
  updatedAt: string
}

const BOX_TYPES = ['gradient', 'solid', 'image', 'card']
const COLORS = [
  '#6366f1', '#8b5cf6', '#d946ef', '#ec4899',
  '#f43f5e', '#f97316', '#eab308', '#22c55e',
  '#10b981', '#14b8a6', '#06b6d4', '#0ea5e9'
]

const formatMb = (value?: number | string) => {
  const numeric = Number(value || 0)
  if (!numeric) return '-'
  if (numeric >= 1024) return `${Number((numeric / 1024).toFixed(1))} GB`
  return `${numeric} MB`
}

export default function AdminPlans() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [plans, setPlans] = useState<Plan[]>([])
  const [panelData, setPanelData] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [showForm, setShowForm] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    features: '',
    boxType: 'card',
    backgroundColor: '#6366f1',
    backgroundImage: '',
    planImage: '',
    planGif: '',
    serverType: 'vps',
    osVersion: 'ubuntu:22.04',
    availableOs: 'ubuntu:22.04\nubuntu:20.04\ndebian:12\ndebian:11',
    gfxNodeId: '1',
    gfxUserId: '1',
    pteroLocationId: '1',
    pteroNestId: '1',
    pteroEggId: '1',
    pteroDockerImage: '',
    pteroStartupCommand: '',
    ram: '1024',
    cpu: '100',
    disk: '10240',
    expiresInDays: '30',
    discordLink: '',
    isActive: true,
    sortOrder: 0
  })

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/signin')
    }
    if (status === 'authenticated') {
      checkAdminAccess()
      fetchPlans()
      fetchPanelData()
    }
  }, [status])

  const checkAdminAccess = async () => {
    try {
      const response = await fetch('/api/admin/check-access')
      if (!response.ok) {
        router.push('/dashboard')
      }
    } catch (error) {
      router.push('/dashboard')
    }
  }

  const fetchPlans = async () => {
    try {
      const response = await fetch('/api/admin/plans')
      if (response.ok) {
        const data = await response.json()
        setPlans(Array.isArray(data.plans) ? data.plans : [])
      } else {
        setPlans([])
      }
    } catch (error) {
      console.error('Failed to fetch plans:', error)
      setPlans([])
    } finally {
      setLoading(false)
    }
  }

  const fetchPanelData = async () => {
    try {
      const response = await fetch('/api/admin/plans/panel-data')
      if (response.ok) setPanelData(await response.json())
    } catch (error) {
      console.error('Failed to fetch panel data:', error)
    }
  }

  const getAttr = (item: any) => item?.attributes || item || {}
  const pteroEggs = panelData?.pterodactyl?.eggsByNest?.[formData.pteroNestId] || []
  const selectedPteroLocation = panelData?.pterodactyl?.locations?.map(getAttr).find((item: any) => String(item.id) === formData.pteroLocationId)
  const selectedPteroNest = panelData?.pterodactyl?.nests?.map(getAttr).find((item: any) => String(item.id) === formData.pteroNestId)
  const selectedPteroEgg = pteroEggs.map(getAttr).find((item: any) => String(item.id) === formData.pteroEggId)
  const selectedGfxNode = panelData?.gfx?.nodes?.map(getAttr).find((item: any) => String(item.id) === formData.gfxNodeId)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.name.trim() || !formData.description.trim()) {
      alert('Plan name and description are required')
      return
    }

    if (!formData.price || parseFloat(formData.price) < 0) {
      alert('Price must be a valid positive number')
      return
    }
    
    const payload = {
      name: formData.name.trim(),
      description: formData.description.trim(),
      price: parseFloat(formData.price),
      features: formData.features.split('\n').filter(f => f.trim()),
      specs: {
        boxType: formData.boxType,
        backgroundColor: formData.backgroundColor,
        backgroundImage: formData.backgroundImage,
        planImage: formData.planImage,
        planGif: formData.planGif,
        serverType: formData.serverType,
        osVersion: formData.osVersion,
        availableOs: formData.availableOs.split('\n').map(os => os.trim()).filter(Boolean),
        gfxNodeId: formData.gfxNodeId,
        gfxNodeName: selectedGfxNode?.name || selectedGfxNode?.hostname || '',
        gfxUserId: formData.gfxUserId,
        pteroLocationId: formData.pteroLocationId,
        pteroLocationName: selectedPteroLocation?.short || selectedPteroLocation?.name || '',
        pteroNestId: formData.pteroNestId,
        pteroNestName: selectedPteroNest?.name || '',
        pteroEggId: formData.pteroEggId,
        pteroEggName: selectedPteroEgg?.name || '',
        pteroDockerImage: formData.pteroDockerImage,
        pteroStartupCommand: formData.pteroStartupCommand,
        ram: parseInt(formData.ram) || 1024,
        cpu: parseInt(formData.cpu) || 100,
        disk: parseInt(formData.disk) || 10240,
        expiresInDays: parseInt(formData.expiresInDays) || 30,
        discordLink: formData.discordLink || '',
      },
      isActive: formData.isActive,
      sortOrder: parseInt(String(formData.sortOrder)) || 0
    }

    try {
      const url = editingId ? `/api/admin/plans/${editingId}` : '/api/admin/plans'
      const method = editingId ? 'PUT' : 'POST'
      
      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      })

      const data = await response.json()

      if (response.ok) {
        alert(editingId ? 'Plan updated successfully!' : 'Plan created successfully!')
        await fetchPlans()
        resetForm()
      } else {
        console.error('Failed to save plan:', data)
        alert('Failed to save plan: ' + (data.error || response.statusText))
      }
    } catch (error) {
      console.error('Failed to save plan:', error)
      alert('Failed to save plan: ' + (error instanceof Error ? error.message : 'Unknown error'))
    }
  }

  const handleEdit = (plan: Plan) => {
    setFormData({
      name: plan.name,
      description: plan.description,
      price: plan.price.toString(),
      features: (plan.features || []).join('\n'),
      boxType: plan.specs?.boxType || 'card',
      backgroundColor: plan.specs?.backgroundColor || '#6366f1',
      backgroundImage: plan.specs?.backgroundImage || '',
      planImage: plan.specs?.planImage || '',
      planGif: plan.specs?.planGif || '',
      serverType: plan.specs?.serverType || 'vps',
      osVersion: plan.specs?.osVersion || 'ubuntu:22.04',
      availableOs: Array.isArray(plan.specs?.availableOs) ? plan.specs.availableOs.join('\n') : 'ubuntu:22.04\nubuntu:20.04\ndebian:12\ndebian:11',
      gfxNodeId: (plan.specs?.gfxNodeId || '1').toString(),
      gfxUserId: (plan.specs?.gfxUserId || '1').toString(),
      pteroLocationId: (plan.specs?.pteroLocationId || '1').toString(),
      pteroNestId: (plan.specs?.pteroNestId || '1').toString(),
      pteroEggId: (plan.specs?.pteroEggId || '1').toString(),
      pteroDockerImage: plan.specs?.pteroDockerImage || '',
      pteroStartupCommand: plan.specs?.pteroStartupCommand || '',
      ram: (plan.specs?.ram || 1024).toString(),
      cpu: (plan.specs?.cpu || 100).toString(),
      disk: (plan.specs?.disk || 10240).toString(),
      expiresInDays: (plan.specs?.expiresInDays || 30).toString(),
      discordLink: plan.specs?.discordLink || '',
      isActive: plan.isActive,
      sortOrder: plan.sortOrder
    })
    setEditingId(plan.id)
    setShowForm(true)
  }

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this plan?')) return

    try {
      const response = await fetch(`/api/admin/plans/${id}`, { method: 'DELETE' })
      if (response.ok) {
        fetchPlans()
      }
    } catch (error) {
      console.error('Failed to delete plan:', error)
    }
  }

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      price: '',
      features: '',
      boxType: 'card',
      backgroundColor: '#6366f1',
      backgroundImage: '',
      planImage: '',
      planGif: '',
      serverType: 'vps',
      osVersion: 'ubuntu:22.04',
      availableOs: 'ubuntu:22.04\nubuntu:20.04\ndebian:12\ndebian:11',
      gfxNodeId: '1',
      gfxUserId: '1',
      pteroLocationId: '1',
      pteroNestId: '1',
      pteroEggId: '1',
      pteroDockerImage: '',
      pteroStartupCommand: '',
      ram: '1024',
      cpu: '100',
      disk: '10240',
      expiresInDays: '30',
      discordLink: '',
      isActive: true,
      sortOrder: 0
    })
    setEditingId(null)
    setShowForm(false)
  }

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <Loader2 className="h-8 w-8 animate-spin" />
        </div>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#060611] text-white">
      <Navbar />
      
      <div className="flex-1 container mx-auto px-4 py-8">
        <div className="mb-8 rounded-3xl border border-white/10 bg-gradient-to-br from-cyan-500/10 via-purple-500/10 to-transparent p-6">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.3em] text-cyan-300/80">Admin Hosting Manager</p>
              <h1 className="text-4xl font-black mt-2 mb-2">VPS & Host Plans</h1>
              <p className="text-white/50">Create provider-aware plans with live GFX Panel and Pterodactyl configuration.</p>
            </div>
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div className="rounded-2xl border border-cyan-500/20 bg-cyan-500/10 p-4 min-w-32">
                <p className="text-white/40 text-xs">GFX Panel</p>
                <p className="font-bold text-cyan-200">{panelData?.gfx?.configured ? 'Connected' : 'Not configured'}</p>
              </div>
              <div className="rounded-2xl border border-purple-500/20 bg-purple-500/10 p-4 min-w-32">
                <p className="text-white/40 text-xs">Pterodactyl</p>
                <p className="font-bold text-purple-200">{panelData?.pterodactyl?.configured ? 'Connected' : 'Not configured'}</p>
              </div>
            </div>
          </div>
        </div>

        <Tabs defaultValue="list" className="space-y-4">
          <TabsList className="bg-white/[0.04] border border-white/10 rounded-2xl p-1">
            <TabsTrigger value="list">Plans ({plans.length})</TabsTrigger>
            <TabsTrigger value="create">Add New Plan</TabsTrigger>
          </TabsList>

          <TabsContent value="list">
            <div className="grid gap-5">
              {plans.length === 0 ? (
                <Card className="bg-white/[0.03] border-white/10 rounded-3xl">
                  <CardContent className="pt-6 text-center text-white/50">
                    No plans found. Create your first plan!
                  </CardContent>
                </Card>
              ) : (
                plans.map(plan => (
                  <Card key={plan.id} className="group overflow-hidden rounded-3xl border-white/10 bg-white/[0.035] transition hover:bg-white/[0.055]">
                    <CardHeader className="pb-4">
                      <div className="flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between">
                        <div className="flex gap-4">
                          <div className={`hidden h-16 w-16 shrink-0 items-center justify-center rounded-2xl border md:flex ${plan.specs?.serverType === 'host' ? 'border-purple-400/30 bg-purple-500/10' : plan.specs?.serverType === 'invite' ? 'border-indigo-400/30 bg-indigo-500/10' : 'border-cyan-400/30 bg-cyan-500/10'}`}>
                            {plan.specs?.serverType === 'host' ? <HardDrive className="h-7 w-7 text-purple-200" /> : plan.specs?.serverType === 'invite' ? <MessageCircle className="h-7 w-7 text-indigo-200" /> : <Server className="h-7 w-7 text-cyan-200" />}
                          </div>
                          <div>
                            <CardTitle className="flex flex-wrap items-center gap-2 text-2xl">
                              {plan.name}
                            <Badge variant="outline" className={plan.specs?.serverType === 'host' ? 'bg-purple-500/10 text-purple-300' : plan.specs?.serverType === 'invite' ? 'bg-indigo-500/10 text-indigo-300' : 'bg-cyan-500/10 text-cyan-300'}>
                              {plan.specs?.serverType === 'host' ? 'Host / Pterodactyl' : plan.specs?.serverType === 'invite' ? 'Invite / Discord' : 'VPS / GFX'}
                            </Badge>
                            {plan.isActive ? (
                              <Badge variant="outline" className="bg-green-500/10">Active</Badge>
                            ) : (
                              <Badge variant="outline" className="bg-red-500/10">Inactive</Badge>
                            )}
                            </CardTitle>
                            <CardDescription className="mt-2 max-w-3xl text-white/50">{plan.description}</CardDescription>
                          </div>
                        </div>
                        <div className="rounded-2xl border border-white/10 bg-black/20 px-5 py-4 text-left lg:text-right">
                          <p className="text-3xl font-black text-white">${plan.price}</p>
                          <p className="text-xs uppercase tracking-widest text-white/35">monthly</p>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {plan.specs && plan.specs.serverType === 'invite' ? (
                        <div className="rounded-2xl border border-indigo-400/20 bg-indigo-500/10 p-4 flex items-center gap-3">
                          <MessageCircle className="h-5 w-5 text-indigo-300 flex-shrink-0" />
                          <div className="min-w-0 flex-1">
                            <p className="text-[11px] uppercase tracking-widest text-white/40">Discord Invite Link</p>
                            {plan.specs.discordLink ? (
                              <a href={plan.specs.discordLink} target="_blank" rel="noopener" className="text-indigo-300 font-bold text-sm hover:text-indigo-200 truncate block">{plan.specs.discordLink}</a>
                            ) : (
                              <p className="text-white/40 text-sm italic">No Discord link set</p>
                            )}
                          </div>
                        </div>
                      ) : plan.specs && (
                        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
                          <div className="rounded-2xl border border-cyan-400/20 bg-cyan-500/10 p-4">
                            <Database className="mb-2 h-4 w-4 text-cyan-200" />
                            <p className="text-[11px] uppercase tracking-widest text-white/40">RAM</p>
                            <p className="text-lg font-black">{formatMb(plan.specs.ram)}</p>
                          </div>
                          <div className="rounded-2xl border border-purple-400/20 bg-purple-500/10 p-4">
                            <Cpu className="mb-2 h-4 w-4 text-purple-200" />
                            <p className="text-[11px] uppercase tracking-widest text-white/40">CPU</p>
                            <p className="text-lg font-black">{plan.specs.cpu || '-'}%</p>
                          </div>
                          <div className="rounded-2xl border border-emerald-400/20 bg-emerald-500/10 p-4">
                            <HardDrive className="mb-2 h-4 w-4 text-emerald-200" />
                            <p className="text-[11px] uppercase tracking-widest text-white/40">Disk</p>
                            <p className="text-lg font-black">{formatMb(plan.specs.disk)}</p>
                          </div>
                          <div className="rounded-2xl border border-amber-400/20 bg-amber-500/10 p-4">
                            <Clock className="mb-2 h-4 w-4 text-amber-200" />
                            <p className="text-[11px] uppercase tracking-widest text-white/40">Expire</p>
                            <p className="text-lg font-black">{plan.specs.expiresInDays || 30} Days</p>
                          </div>
                        </div>
                      )}

                      {plan.features && plan.features.length > 0 && (
                        <div className="rounded-2xl border border-white/10 bg-black/20 p-4">
                          <p className="text-sm font-bold mb-3 text-white">Admin configured features</p>
                          <div className="grid gap-2 md:grid-cols-2">
                            {plan.features.map((f, i) => <div key={i} className="rounded-xl bg-white/[0.04] px-3 py-2 text-sm text-white/70">{f}</div>)}
                          </div>
                        </div>
                      )}
                      
                      {plan.specs && (
                        <div className="space-y-3">
                          {plan.specs.serverType === 'invite' ? (
                            <div className="grid grid-cols-1 gap-2 rounded-2xl border border-indigo-500/10 bg-indigo-500/5 p-3 md:grid-cols-2">
                              <div>
                                <p className="text-[10px] text-indigo-400 font-bold uppercase">Provider</p>
                                <p className="text-xs text-white">Discord Invite</p>
                              </div>
                              <div>
                                <p className="text-[10px] text-indigo-400 font-bold uppercase">Invite Link</p>
                                <p className="text-xs text-white truncate">{plan.specs.discordLink || 'Not set'}</p>
                              </div>
                            </div>
                          ) : (plan.specs.ram || plan.specs.cpu || plan.specs.disk) && (
                            <div className="grid grid-cols-1 gap-2 rounded-2xl border border-blue-500/10 bg-blue-500/5 p-3 md:grid-cols-3">
                              <div>
                                <p className="text-[10px] text-blue-400 font-bold uppercase">Provider</p>
                                <p className="text-xs text-white">{plan.specs.serverType === 'host' ? 'Pterodactyl' : 'GFX Panel'}</p>
                              </div>
                              <div>
                                <p className="text-[10px] text-blue-400 font-bold uppercase">{plan.specs.serverType === 'host' ? 'Panel Config' : 'Node'}</p>
                                <p className="text-xs text-white">{plan.specs.serverType === 'host' ? `${plan.specs.pteroLocationName || `Location ${plan.specs.pteroLocationId || '-'}`} / ${plan.specs.pteroEggName || `Egg ${plan.specs.pteroEggId || '-'}`}` : plan.specs.gfxNodeName || `Node ${plan.specs.gfxNodeId || '-'}`}</p>
                              </div>
                              <div>
                                <p className="text-[10px] text-blue-400 font-bold uppercase">{plan.specs.serverType === 'host' ? 'Nest' : 'OS'}</p>
                                <p className="text-xs text-white">{plan.specs.serverType === 'host' ? plan.specs.pteroNestName || `Nest ${plan.specs.pteroNestId || '-'}` : plan.specs.osVersion || '-'}</p>
                              </div>
                            </div>
                          )}
                          <div className="flex flex-wrap gap-2 text-xs">
                            <Badge variant="outline" className="border-white/10 text-white/60">Box: {plan.specs.boxType || 'card'}</Badge>
                            <Badge variant="outline" className="border-white/10 text-white/60">Sort: {plan.sortOrder}</Badge>
                            {(plan.specs.backgroundImage || plan.specs.planImage || plan.specs.planGif) && (
                              <Badge variant="outline" className="border-green-500/30 bg-green-500/10 text-green-300"><ImageIcon className="mr-1 h-3 w-3" /> Media configured</Badge>
                            )}
                          </div>
                        </div>
                      )}

                      <div className="flex gap-2 pt-4 border-t border-white/10">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleEdit(plan)}
                          className="flex-1"
                        >
                          <Edit className="h-4 w-4 mr-2" />
                          Edit
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleDelete(plan.id)}
                          className="flex-1"
                        >
                          <Trash2 className="h-4 w-4 mr-2" />
                          Delete
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          </TabsContent>

          <TabsContent value="create" className="space-y-4">
            <form onSubmit={handleSubmit} className="grid gap-6 xl:grid-cols-[1fr_380px]">
              <div className="space-y-6">
                <div className="rounded-3xl border border-white/10 bg-white/[0.035] p-5 space-y-5">
                  <div>
                    <p className="text-xs font-bold uppercase tracking-[0.25em] text-cyan-300/80">Plan Identity</p>
                    <h2 className="text-2xl font-black text-white">{editingId ? 'Edit hosting plan' : 'Create new hosting plan'}</h2>
                    <p className="text-sm text-white/45">Set the name, price, selling points and public card style shown on `/vps`.</p>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                  <Label>Plan Name *</Label>
                  <Input
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder="e.g., Basic Plan"
                    required
                  />
                    </div>
                    <div>
                  <Label>Price (USD) *</Label>
                  <Input
                    type="number"
                    step="0.01"
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                    placeholder="9.99"
                    required
                  />
                    </div>
                  </div>

                  <div>
                    <Label>Description *</Label>
                    <Textarea
                      value={formData.description}
                      onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                      placeholder="Brief description of the plan"
                      required
                      className="min-h-24"
                    />
                  </div>

                  <div>
                    <Label>Features (one per line)</Label>
                    <Textarea
                      value={formData.features}
                      onChange={(e) => setFormData({ ...formData, features: e.target.value })}
                      placeholder="2GB RAM&#10;20GB SSD Storage&#10;2 CPU Cores"
                      rows={5}
                    />
                  </div>
                </div>

                <div className="rounded-3xl border border-white/10 bg-white/[0.035] p-5 space-y-5">
                  <div>
                    <p className="text-xs font-bold uppercase tracking-[0.25em] text-purple-300/80">Visual Style</p>
                    <h2 className="text-xl font-black text-white">Public card design</h2>
                  </div>
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label>Box Type</Label>
                      <Select value={formData.boxType} onValueChange={(v) => setFormData({ ...formData, boxType: v })}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {BOX_TYPES.map(type => (
                            <SelectItem key={type} value={type}>{type}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label>Background Color</Label>
                      <div className="flex gap-2 flex-wrap">
                        {COLORS.map(color => (
                          <button
                            key={color}
                            type="button"
                            onClick={() => setFormData({ ...formData, backgroundColor: color })}
                            className={`h-8 w-8 rounded-full border-2 transition ${
                              formData.backgroundColor === color ? 'scale-110 border-white' : 'border-white/10'
                            }`}
                            style={{ backgroundColor: color }}
                          />
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="grid md:grid-cols-3 gap-4">
                    <div>
                      <Label>Background Image URL</Label>
                      <Input
                        value={formData.backgroundImage}
                        onChange={(e) => setFormData({ ...formData, backgroundImage: e.target.value })}
                        placeholder="https://example.com/image.jpg"
                      />
                    </div>

                    <div>
                      <Label>Plan Image URL</Label>
                      <Input
                        value={formData.planImage}
                        onChange={(e) => setFormData({ ...formData, planImage: e.target.value })}
                        placeholder="https://example.com/plan-image.png"
                      />
                    </div>

                    <div>
                      <Label>Plan GIF URL</Label>
                      <Input
                        value={formData.planGif}
                        onChange={(e) => setFormData({ ...formData, planGif: e.target.value })}
                        placeholder="https://example.com/plan-animation.gif"
                      />
                    </div>
                  </div>
                </div>

              <div className="rounded-2xl border border-white/10 bg-gradient-to-br from-slate-950/80 via-blue-950/20 to-slate-950/80 p-5 space-y-5">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h3 className="text-lg font-bold text-white flex items-center gap-2">
                      <Zap className="h-5 w-5 text-blue-400" /> Professional Provisioning Setup
                    </h3>
                    <p className="text-xs text-muted-foreground mt-1">Choose provider and configure the exact panel settings for this plan.</p>
                  </div>
                  <Badge variant="outline" className={
                    formData.serverType === 'host' ? 'bg-purple-500/10 text-purple-300 border-purple-500/30'
                    : formData.serverType === 'invite' ? 'bg-indigo-500/10 text-indigo-300 border-indigo-500/30'
                    : 'bg-cyan-500/10 text-cyan-300 border-cyan-500/30'
                  }>
                    {formData.serverType === 'host' ? 'Host Plan / Pterodactyl' : formData.serverType === 'invite' ? 'Invite Plan / Discord' : 'VPS Plan / GFX Panel'}
                  </Badge>
                </div>

                <div className="grid md:grid-cols-3 gap-4">
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, serverType: 'vps' })}
                    className={`text-left rounded-2xl border p-4 transition ${formData.serverType === 'vps' ? 'border-cyan-400/60 bg-cyan-500/10 shadow-lg shadow-cyan-500/10' : 'border-white/10 bg-white/[0.03] hover:bg-white/[0.06]'}`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="h-11 w-11 rounded-xl bg-cyan-500/15 flex items-center justify-center"><Server className="h-5 w-5 text-cyan-300" /></div>
                      <div>
                        <p className="font-semibold text-white">VPS - GFX Panel</p>
                        <p className="text-xs text-muted-foreground">LXC/VPS provisioning with GFX node, user, OS and resources.</p>
                      </div>
                    </div>
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, serverType: 'host' })}
                    className={`text-left rounded-2xl border p-4 transition ${formData.serverType === 'host' ? 'border-purple-400/60 bg-purple-500/10 shadow-lg shadow-purple-500/10' : 'border-white/10 bg-white/[0.03] hover:bg-white/[0.06]'}`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="h-11 w-11 rounded-xl bg-purple-500/15 flex items-center justify-center"><HardDrive className="h-5 w-5 text-purple-300" /></div>
                      <div>
                        <p className="font-semibold text-white">Host - Pterodactyl</p>
                        <p className="text-xs text-muted-foreground">Game/app hosting with nest, egg, location, Docker and startup config.</p>
                      </div>
                    </div>
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData({ ...formData, serverType: 'invite' })}
                    className={`text-left rounded-2xl border p-4 transition ${formData.serverType === 'invite' ? 'border-indigo-400/60 bg-indigo-500/10 shadow-lg shadow-indigo-500/10' : 'border-white/10 bg-white/[0.03] hover:bg-white/[0.06]'}`}
                  >
                    <div className="flex items-center gap-3">
                      <div className="h-11 w-11 rounded-xl bg-indigo-500/15 flex items-center justify-center"><MessageCircle className="h-5 w-5 text-indigo-300" /></div>
                      <div>
                        <p className="font-semibold text-white">Invite - Discord</p>
                        <p className="text-xs text-muted-foreground">Discord server invite link plan. Buyer gets access via Discord URL.</p>
                      </div>
                    </div>
                  </button>
                </div>

                {formData.serverType === 'invite' ? (
                  <div className="rounded-xl border border-indigo-500/20 bg-indigo-500/5 p-4 space-y-4">
                    <h4 className="text-sm font-bold text-indigo-300 flex items-center gap-2"><MessageCircle className="h-4 w-4" />Discord Invite Config</h4>
                    <div>
                      <Label>Discord Invite Link *</Label>
                      <div className="flex gap-2 mt-1">
                        <LinkIcon className="w-4 h-4 text-indigo-400 mt-2.5 flex-shrink-0" />
                        <Input
                          value={formData.discordLink}
                          onChange={(e) => setFormData({ ...formData, discordLink: e.target.value })}
                          placeholder="https://discord.gg/your-invite-code"
                          className="flex-1"
                        />
                      </div>
                      <p className="text-[10px] text-muted-foreground mt-1">When admin approves the order, this Discord link will be sent to the buyer automatically.</p>
                    </div>
                    <div className="rounded-xl bg-indigo-500/10 border border-indigo-500/20 p-3 text-xs text-indigo-200">
                      <strong>How it works:</strong> Buyer places order → Admin approves → System sends Discord invite link to buyer via notification and email.
                    </div>
                  </div>
                ) : formData.serverType === 'vps' ? (
                  <div className="rounded-xl border border-cyan-500/20 bg-cyan-500/5 p-4 space-y-4">
                    <h4 className="text-sm font-bold text-cyan-300 flex items-center gap-2"><Server className="h-4 w-4" />GFX Panel VPS Config</h4>
                    {!panelData?.gfx?.configured && (
                      <div className="rounded-xl border border-orange-500/20 bg-orange-500/10 p-3 text-xs text-orange-200">GFX Panel config missing. Configure it first from Admin → GFX Panel, then nodes will show here.</div>
                    )}
                    <div className="grid md:grid-cols-3 gap-4">
                      <div>
                        <Label>Create VPS On Node</Label>
                        <Select value={formData.gfxNodeId} onValueChange={(v) => setFormData({ ...formData, gfxNodeId: v })}>
                          <SelectTrigger><SelectValue placeholder="Select GFX node" /></SelectTrigger>
                          <SelectContent>
                            {panelData?.gfx?.nodes?.length ? panelData.gfx.nodes.map((node: any) => {
                              const item = getAttr(node)
                              return <SelectItem key={String(item.id)} value={String(item.id)}>{item.name || item.hostname || `Node ${item.id}`}</SelectItem>
                            }) : <SelectItem value={formData.gfxNodeId}>Node {formData.gfxNodeId}</SelectItem>}
                          </SelectContent>
                        </Select>
                        {selectedGfxNode && <p className="text-[10px] text-cyan-200/70 mt-1">{selectedGfxNode.location || selectedGfxNode.ip_address || selectedGfxNode.address || 'Selected GFX node'}</p>}
                      </div>
                      <div>
                        <Label>Fallback GFX User ID</Label>
                        <Input value={formData.gfxUserId} onChange={(e) => setFormData({ ...formData, gfxUserId: e.target.value })} placeholder="1" />
                        <p className="text-[10px] text-muted-foreground mt-1">If buyer has mapped GFX account later, provisioning can use their account; this is fallback.</p>
                      </div>
                      <div>
                        <Label>Default OS</Label>
                        <Select value={formData.osVersion} onValueChange={(v) => setFormData({ ...formData, osVersion: v })}>
                          <SelectTrigger><SelectValue /></SelectTrigger>
                          <SelectContent>
                            {formData.availableOs.split('\n').map(os => os.trim()).filter(Boolean).map(os => (
                              <SelectItem key={os} value={os}>{os}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <div>
                      <Label>Available OS Images (one per line)</Label>
                      <Textarea value={formData.availableOs} onChange={(e) => setFormData({ ...formData, availableOs: e.target.value })} placeholder="ubuntu:22.04&#10;debian:12" rows={4} />
                    </div>
                  </div>
                ) : (
                  <div className="rounded-xl border border-purple-500/20 bg-purple-500/5 p-4 space-y-4">
                    <h4 className="text-sm font-bold text-purple-300 flex items-center gap-2"><HardDrive className="h-4 w-4" />Pterodactyl Host Config</h4>
                    {!panelData?.pterodactyl?.configured && (
                      <div className="rounded-xl border border-orange-500/20 bg-orange-500/10 p-3 text-xs text-orange-200">Pterodactyl config missing. Configure it first from Admin → Pterodactyl Panel, then locations/nests/eggs will show here.</div>
                    )}
                    <div className="grid md:grid-cols-3 gap-4">
                      <div>
                        <Label>Location</Label>
                        <Select value={formData.pteroLocationId} onValueChange={(v) => setFormData({ ...formData, pteroLocationId: v })}>
                          <SelectTrigger><SelectValue placeholder="Select location" /></SelectTrigger>
                          <SelectContent>
                            {panelData?.pterodactyl?.locations?.length ? panelData.pterodactyl.locations.map((location: any) => {
                              const item = getAttr(location)
                              return <SelectItem key={String(item.id)} value={String(item.id)}>{item.short || item.name || `Location ${item.id}`} {item.long ? `(${item.long})` : ''}</SelectItem>
                            }) : <SelectItem value={formData.pteroLocationId}>Location {formData.pteroLocationId}</SelectItem>}
                          </SelectContent>
                        </Select>
                        {selectedPteroLocation && <p className="text-[10px] text-purple-200/70 mt-1">{selectedPteroLocation.long || selectedPteroLocation.short}</p>}
                      </div>
                      <div>
                        <Label>Nest</Label>
                        <Select value={formData.pteroNestId} onValueChange={(v) => setFormData({ ...formData, pteroNestId: v, pteroEggId: '' })}>
                          <SelectTrigger><SelectValue placeholder="Select nest" /></SelectTrigger>
                          <SelectContent>
                            {panelData?.pterodactyl?.nests?.length ? panelData.pterodactyl.nests.map((nest: any) => {
                              const item = getAttr(nest)
                              return <SelectItem key={String(item.id)} value={String(item.id)}>{item.name || `Nest ${item.id}`}</SelectItem>
                            }) : <SelectItem value={formData.pteroNestId}>Nest {formData.pteroNestId}</SelectItem>}
                          </SelectContent>
                        </Select>
                        {selectedPteroNest && <p className="text-[10px] text-purple-200/70 mt-1">{selectedPteroNest.description || selectedPteroNest.name}</p>}
                      </div>
                      <div>
                        <Label>Egg</Label>
                        <Select value={formData.pteroEggId || undefined} onValueChange={(v) => setFormData({ ...formData, pteroEggId: v })}>
                          <SelectTrigger><SelectValue placeholder="Select egg" /></SelectTrigger>
                          <SelectContent>
                            {pteroEggs.length ? pteroEggs.map((egg: any) => {
                              const item = getAttr(egg)
                              return <SelectItem key={String(item.id)} value={String(item.id)}>{item.name || `Egg ${item.id}`}</SelectItem>
                            }) : <SelectItem value={formData.pteroEggId || '1'}>Egg {formData.pteroEggId || '1'}</SelectItem>}
                          </SelectContent>
                        </Select>
                        {selectedPteroEgg && <p className="text-[10px] text-purple-200/70 mt-1">{selectedPteroEgg.author || selectedPteroEgg.name}</p>}
                      </div>
                    </div>
                    <div>
                      <div>
                        <Label>Docker Image</Label>
                        <Input value={formData.pteroDockerImage} onChange={(e) => setFormData({ ...formData, pteroDockerImage: e.target.value })} placeholder="ghcr.io/pterodactyl/yolks:java_21" />
                      </div>
                    </div>
                    <div>
                      <Label>Startup Command</Label>
                      <Textarea value={formData.pteroStartupCommand} onChange={(e) => setFormData({ ...formData, pteroStartupCommand: e.target.value })} placeholder="java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar {{SERVER_JARFILE}}" rows={3} />
                    </div>
                  </div>
                )}

                <div className="grid md:grid-cols-4 gap-4">
                  <div>
                    <Label>RAM (MB)</Label>
                    <Input
                      type="number"
                      value={formData.ram}
                      onChange={(e) => setFormData({ ...formData, ram: e.target.value })}
                      placeholder="1024"
                    />
                    <p className="text-[10px] text-muted-foreground mt-1">1024 MB = 1GB</p>
                  </div>
                  <div>
                    <Label>CPU (%)</Label>
                    <Input
                      type="number"
                      value={formData.cpu}
                      onChange={(e) => setFormData({ ...formData, cpu: e.target.value })}
                      placeholder="100"
                    />
                    <p className="text-[10px] text-muted-foreground mt-1">100 = 1 vCPU Core</p>
                  </div>
                  <div>
                    <Label>Disk (MB)</Label>
                    <Input
                      type="number"
                      value={formData.disk}
                      onChange={(e) => setFormData({ ...formData, disk: e.target.value })}
                      placeholder="10240"
                    />
                    <p className="text-[10px] text-muted-foreground mt-1">10240 MB = 10GB</p>
                  </div>
                  <div>
                    <Label className="flex items-center gap-1"><Clock className="h-3 w-3" />Expire Days</Label>
                    <Input
                      type="number"
                      value={formData.expiresInDays}
                      onChange={(e) => setFormData({ ...formData, expiresInDays: e.target.value })}
                      placeholder="30"
                    />
                    <p className="text-[10px] text-muted-foreground mt-1">Auto expiry duration after approval</p>
                  </div>
                </div>
              </div>

              <div className="rounded-3xl border border-white/10 bg-white/[0.035] p-5">
                <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <Label>Sort Order</Label>
                  <Input
                    type="number"
                    value={formData.sortOrder}
                    onChange={(e) => setFormData({ ...formData, sortOrder: parseInt(e.target.value) || 0 })}
                    placeholder="0"
                  />
                </div>

                <div className="flex items-end gap-2">
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={formData.isActive}
                      onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
                    />
                    <Label>{formData.isActive ? 'Active' : 'Inactive'}</Label>
                  </div>
                </div>
              </div>
              </div>

              <div className="flex gap-2 pt-4 border-t border-white/10">
                <Button type="submit" className="flex-1">
                  <Save className="h-4 w-4 mr-2" />
                  {editingId ? 'Update Plan' : 'Create Plan'}
                </Button>
                {editingId && (
                  <Button type="button" variant="outline" onClick={resetForm} className="flex-1">
                    <X className="h-4 w-4 mr-2" />
                    Cancel
                  </Button>
                )}
              </div>
              </div>

              <aside className="xl:sticky xl:top-6 xl:self-start">
                <div className="overflow-hidden rounded-3xl border border-white/10 bg-white/[0.04]">
                  {(formData.planGif || formData.planImage) ? (
                    <div className="h-44 bg-black/30">
                      <img src={formData.planGif || formData.planImage} alt={formData.name || 'Plan preview'} className="h-full w-full object-cover" />
                    </div>
                  ) : (
                    <div className="flex h-36 items-center justify-center" style={{ background: `linear-gradient(135deg, ${formData.backgroundColor}44, transparent)` }}>
                      {formData.serverType === 'host' ? <HardDrive className="h-12 w-12 text-purple-200" /> : formData.serverType === 'invite' ? <MessageCircle className="h-12 w-12 text-indigo-200" /> : <Server className="h-12 w-12 text-cyan-200" />}
                    </div>
                  )}
                  <div className="space-y-5 p-5">
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="outline" className={formData.serverType === 'host' ? 'border-purple-400/30 bg-purple-500/10 text-purple-200' : formData.serverType === 'invite' ? 'border-indigo-400/30 bg-indigo-500/10 text-indigo-200' : 'border-cyan-400/30 bg-cyan-500/10 text-cyan-200'}>
                        {formData.serverType === 'host' ? 'Host / Pterodactyl' : formData.serverType === 'invite' ? 'Invite / Discord' : 'VPS / GFX'}
                      </Badge>
                      {formData.serverType !== 'invite' && <Badge variant="outline" className="border-white/10 text-white/60">{formData.osVersion || 'No OS'}</Badge>}
                    </div>
                    <div>
                      <h3 className="text-2xl font-black">{formData.name || 'Plan name'}</h3>
                      <p className="mt-2 text-sm text-white/50">{formData.description || 'Plan description will appear here.'}</p>
                    </div>
                    <div>
                      <p className="text-4xl font-black">${formData.price || '0'}</p>
                      <p className="text-xs uppercase tracking-widest text-white/35">per month</p>
                    </div>
                    {formData.serverType === 'invite' ? (
                      <div className="rounded-2xl border border-indigo-500/20 bg-indigo-500/10 p-3">
                        <p className="text-[10px] text-indigo-300/60 uppercase tracking-widest mb-1">Discord Invite</p>
                        <p className="text-xs text-indigo-200 break-all">{formData.discordLink || 'No link set yet'}</p>
                      </div>
                    ) : (
                      <div className="grid grid-cols-3 gap-2">
                        <div className="rounded-2xl border border-white/10 bg-black/20 p-3">
                          <p className="text-[10px] text-white/40">RAM</p>
                          <p className="font-bold">{formatMb(formData.ram)}</p>
                        </div>
                        <div className="rounded-2xl border border-white/10 bg-black/20 p-3">
                          <p className="text-[10px] text-white/40">CPU</p>
                          <p className="font-bold">{formData.cpu || '-'}%</p>
                        </div>
                        <div className="rounded-2xl border border-white/10 bg-black/20 p-3">
                          <p className="text-[10px] text-white/40">Disk</p>
                          <p className="font-bold">{formatMb(formData.disk)}</p>
                        </div>
                      </div>
                    )}
                    <div className="rounded-2xl border border-white/10 bg-black/20 p-3 text-xs text-white/55">
                      {formData.serverType === 'invite'
                        ? 'Auto-send Discord invite on order approval'
                        : `Auto provision target: ${formData.serverType === 'host' ? (selectedPteroEgg?.name || selectedPteroNest?.name || 'Pterodactyl config') : (selectedGfxNode?.name || selectedGfxNode?.hostname || 'GFX node')}`}
                    </div>
                  </div>
                </div>
              </aside>
            </form>
          </TabsContent>
        </Tabs>
      </div>

      <Footer />
    </div>
  )
}
