'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import {
  Server, RefreshCw, Trash2, Terminal, Globe, Search,
  Loader2, Play, Square, AlertCircle, CheckCircle, Clock,
  Users, Activity, Code2, X, ArrowLeft, BarChart3
} from 'lucide-react'
import { toast } from 'sonner'
import Link from 'next/link'

interface Deployment {
  id: string
  name: string
  type: string
  status: string
  port?: number
  url?: string
  logs: string
  createdAt: string
  updatedAt: string
  user: { id: string; username: string; email: string; avatar?: string }
}

interface Stats {
  total: number
  running: number
  stopped: number
  error: number
}

const STATUS_CONFIG: Record<string, { label: string; color: string; icon: any }> = {
  running: { label: 'Running', color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20', icon: CheckCircle },
  stopped: { label: 'Stopped', color: 'text-zinc-400 bg-zinc-500/10 border-zinc-500/20', icon: Square },
  building: { label: 'Building', color: 'text-amber-400 bg-amber-500/10 border-amber-500/20', icon: Loader2 },
  error: { label: 'Error', color: 'text-red-400 bg-red-500/10 border-red-500/20', icon: AlertCircle },
}

export default function AdminAppDeploysPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [deployments, setDeployments] = useState<Deployment[]>([])
  const [stats, setStats] = useState<Stats>({ total: 0, running: 0, stopped: 0, error: 0 })
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [filterStatus, setFilterStatus] = useState('all')
  const [logsOpen, setLogsOpen] = useState(false)
  const [selectedDeploy, setSelectedDeploy] = useState<Deployment | null>(null)
  const [actionLoading, setActionLoading] = useState<string | null>(null)

  useEffect(() => {
    if (status === 'loading') return
    if (!session?.user || (session.user.role !== 'ADMIN' && session.user.role !== 'SUPER_ADMIN')) {
      router.push('/')
      return
    }
    fetchDeployments()
  }, [session, status, router])

  async function fetchDeployments() {
    setLoading(true)
    try {
      const url = filterStatus !== 'all' ? `/api/admin/deployments?status=${filterStatus}` : '/api/admin/deployments'
      const res = await fetch(url)
      if (res.ok) {
        const data = await res.json()
        setDeployments(data.deployments || [])
        setStats(data.stats || { total: 0, running: 0, stopped: 0, error: 0 })
      }
    } catch { toast.error('Failed to load deployments') }
    finally { setLoading(false) }
  }

  useEffect(() => { fetchDeployments() }, [filterStatus])

  async function deleteDeployment(id: string) {
    if (!confirm('Delete this deployment? This cannot be undone.')) return
    setActionLoading(id + ':delete')
    try {
      const res = await fetch(`/api/admin/deployments/${id}`, { method: 'DELETE' })
      if (!res.ok) return toast.error('Failed to delete')
      setDeployments(prev => prev.filter(d => d.id !== id))
      setStats(prev => ({ ...prev, total: prev.total - 1 }))
      toast.success('Deployment deleted')
    } catch { toast.error('Failed to delete') }
    finally { setActionLoading(null) }
  }

  async function updateStatus(id: string, newStatus: string) {
    setActionLoading(id + ':status')
    try {
      const res = await fetch(`/api/admin/deployments/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      })
      if (!res.ok) return toast.error('Failed to update')
      const data = await res.json()
      setDeployments(prev => prev.map(d => d.id === id ? { ...d, ...data } : d))
      toast.success(`Status changed to ${newStatus}`)
    } catch { toast.error('Failed to update') }
    finally { setActionLoading(null) }
  }

  const filtered = deployments.filter(d => {
    const q = search.toLowerCase()
    return (
      d.name.toLowerCase().includes(q) ||
      d.user?.username?.toLowerCase().includes(q) ||
      d.user?.email?.toLowerCase().includes(q)
    )
  })

  if (status === 'loading' || loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-violet-400" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <Navbar />
      <main className="max-w-7xl mx-auto px-4 py-10">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Link href="/admin" className="text-white/40 hover:text-white transition">
            <ArrowLeft className="w-5 h-5" />
          </Link>
          <div className="flex-1">
            <div className="flex items-center gap-3 mb-1">
              <div className="w-10 h-10 rounded-xl bg-violet-500/20 border border-violet-500/30 flex items-center justify-center">
                <Server className="w-5 h-5 text-violet-400" />
              </div>
              <h1 className="text-2xl font-bold">App Deployments</h1>
              <Badge variant="outline" className="border-violet-500/30 text-violet-400 text-xs">Admin</Badge>
            </div>
            <p className="text-white/50 text-sm">Manage all user app deployments across the platform</p>
          </div>
          <Button onClick={fetchDeployments} variant="outline" size="sm" className="border-white/10 text-white/60 hover:text-white gap-2">
            <RefreshCw className="w-4 h-4" /> Refresh
          </Button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          {[
            { label: 'Total Deployments', value: stats.total, icon: Server, color: 'text-violet-400', bg: 'bg-violet-500/10' },
            { label: 'Running', value: stats.running, icon: Play, color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
            { label: 'Stopped', value: stats.stopped, icon: Square, color: 'text-zinc-400', bg: 'bg-zinc-500/10' },
            { label: 'Errors', value: stats.error, icon: AlertCircle, color: 'text-red-400', bg: 'bg-red-500/10' },
          ].map(s => (
            <div key={s.label} className="bg-white/[0.03] border border-white/[0.06] rounded-xl p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs text-white/40">{s.label}</span>
                <div className={`w-8 h-8 rounded-lg ${s.bg} flex items-center justify-center`}>
                  <s.icon className={`w-4 h-4 ${s.color}`} />
                </div>
              </div>
              <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
            </div>
          ))}
        </div>

        {/* Filters */}
        <div className="flex items-center gap-3 mb-6">
          <div className="relative flex-1 max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
            <Input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search by app or username..."
              className="pl-9 bg-white/5 border-white/10 text-white placeholder:text-white/30"
            />
          </div>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-36 bg-white/5 border-white/10 text-white">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="bg-zinc-900 border-white/10 text-white">
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="running">Running</SelectItem>
              <SelectItem value="stopped">Stopped</SelectItem>
              <SelectItem value="error">Error</SelectItem>
            </SelectContent>
          </Select>
          <span className="text-sm text-white/40">{filtered.length} results</span>
        </div>

        {/* Table */}
        {filtered.length === 0 ? (
          <div className="text-center py-20 border border-dashed border-white/10 rounded-2xl">
            <Server className="w-12 h-12 text-white/20 mx-auto mb-4" />
            <p className="text-white/40">No deployments found</p>
          </div>
        ) : (
          <div className="space-y-2">
            {filtered.map(dep => {
              const cfg = STATUS_CONFIG[dep.status] || STATUS_CONFIG.stopped
              const StatusIcon = cfg.icon
              const isActing = actionLoading?.startsWith(dep.id)
              return (
                <div key={dep.id} className="bg-white/[0.03] border border-white/[0.06] rounded-xl p-4 hover:border-white/10 transition">
                  <div className="flex items-center gap-4">
                    <div className="w-9 h-9 rounded-lg bg-violet-500/10 border border-violet-500/20 flex items-center justify-center flex-shrink-0">
                      <Code2 className="w-4 h-4 text-violet-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5">
                        <h3 className="font-semibold text-sm truncate">{dep.name}</h3>
                        <Badge variant="outline" className="text-[10px] py-0 px-1.5 border-white/10 text-white/40">{dep.type.toUpperCase()}</Badge>
                        <span className={`flex items-center gap-1 px-2 py-0.5 rounded-full border text-[11px] ${cfg.color}`}>
                          <StatusIcon className={`w-3 h-3 ${dep.status === 'building' ? 'animate-spin' : ''}`} />
                          {cfg.label}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-white/30">
                        <span>@{dep.user?.username}</span>
                        <span>{dep.user?.email}</span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {new Date(dep.createdAt).toLocaleDateString()}
                        </span>
                        {dep.url && dep.status === 'running' && (
                          <a href={dep.url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-1 text-violet-400 hover:underline">
                            <Globe className="w-3 h-3" /> View
                          </a>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => { setSelectedDeploy(dep); setLogsOpen(true) }}
                        className="h-8 px-2 text-xs text-white/40 hover:text-white gap-1"
                      >
                        <Terminal className="w-3.5 h-3.5" /> Logs
                      </Button>
                      <Select
                        value={dep.status}
                        onValueChange={v => updateStatus(dep.id, v)}
                        disabled={isActing}
                      >
                        <SelectTrigger className="h-8 w-28 text-xs bg-white/5 border-white/10 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent className="bg-zinc-900 border-white/10 text-white">
                          <SelectItem value="running">Running</SelectItem>
                          <SelectItem value="stopped">Stopped</SelectItem>
                          <SelectItem value="error">Error</SelectItem>
                        </SelectContent>
                      </Select>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => deleteDeployment(dep.id)}
                        disabled={isActing}
                        className="h-8 w-8 p-0 text-red-400/50 hover:text-red-400 hover:bg-red-500/10"
                      >
                        {isActing && actionLoading === dep.id + ':delete' ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                      </Button>
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </main>
      <Footer />

      {/* Logs Dialog */}
      <Dialog open={logsOpen} onOpenChange={setLogsOpen}>
        <DialogContent className="bg-zinc-950 border border-white/10 text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Terminal className="w-5 h-5 text-emerald-400" />
              Logs — {selectedDeploy?.name}
              <span className="text-xs text-white/40 ml-auto">@{selectedDeploy?.user?.username}</span>
            </DialogTitle>
            <DialogDescription className="text-white/50">Deployment logs for this app.</DialogDescription>
          </DialogHeader>
          <pre className="bg-black/60 border border-white/5 rounded-xl p-4 text-xs text-emerald-300 font-mono h-64 overflow-y-auto whitespace-pre-wrap mt-2">
            {selectedDeploy?.logs || 'No logs yet.'}
          </pre>
        </DialogContent>
      </Dialog>
    </div>
  )
}
