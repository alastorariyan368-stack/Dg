'use client'
import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Switch } from '@/components/ui/switch'
import { Plus, Trash2, RefreshCw, Upload, Tv, Power } from 'lucide-react'

interface Channel {
  id: string; name: string; url: string; logo: string | null
  groupTitle: string; isActive: boolean; sortOrder: number
  tvgId: string | null; tvgName: string | null; tvgLogo: string | null; tvgCountry: string | null
}

export default function AdminTVChannelsPage() {
  const [channels, setChannels] = useState<Channel[]>([])
  const [loading, setLoading] = useState(true)
  const [importing, setImporting] = useState(false)
  const [showForm, setShowForm] = useState(false)
  const [edit, setEdit] = useState<Channel | null>(null)
  const [form, setForm] = useState({ name: '', url: '', logo: '', groupTitle: 'General', sortOrder: 0 })

  const load = async () => {
    setLoading(true)
    const r = await fetch('/api/admin/tvchannels')
    const d = await r.json()
    setChannels(d.channels || [])
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  const save = async () => {
    const r = await fetch('/api/admin/tvchannels', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    })
    if (r.ok) { setShowForm(false); setForm({ name: '', url: '', logo: '', groupTitle: 'General', sortOrder: 0 }); load() }
  }

  const toggleActive = async (ch: Channel) => {
    await fetch(`/api/admin/tvchannels/${ch.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ isActive: !ch.isActive }),
    })
    load()
  }

  const del = async (id: string) => {
    if (!confirm('Delete this channel?')) return
    await fetch(`/api/admin/tvchannels/${id}`, { method: 'DELETE' })
    load()
  }

  const importM3U = async () => {
    setImporting(true)
    await fetch('/api/tvchannels/fetch-m3u', { method: 'POST' })
    setImporting(false)
    load()
  }

  return (
    <div className="min-h-screen bg-[#07070d] text-white p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-black text-white">TV Channels</h1>
            <p className="text-white/40 text-sm">{channels.length} channels · {channels.filter(c => c.isActive).length} active</p>
          </div>
          <div className="flex gap-3">
            <Button onClick={importM3U} disabled={importing} variant="outline"
              className="border-white/10 text-white hover:bg-white/5">
              <Upload className="w-4 h-4 mr-2" />{importing ? 'Importing...' : 'Import M3U'}
            </Button>
            <Button onClick={() => { setShowForm(true); setEdit(null) }}
              className="bg-violet-600 hover:bg-violet-500 text-white">
              <Plus className="w-4 h-4 mr-2" /> Add Channel
            </Button>
          </div>
        </div>

        {showForm && (
          <div className="mb-8 p-6 rounded-2xl border border-white/[0.08] bg-white/[0.02]">
            <h3 className="text-lg font-bold text-white mb-4">New Channel</h3>
            <div className="grid md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="text-xs font-bold text-white/40 mb-1 block">Name *</label>
                <Input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })}
                  className="bg-white/[0.04] border-white/10 text-white" />
              </div>
              <div>
                <label className="text-xs font-bold text-white/40 mb-1 block">URL *</label>
                <Input value={form.url} onChange={e => setForm({ ...form, url: e.target.value })}
                  className="bg-white/[0.04] border-white/10 text-white" />
              </div>
              <div>
                <label className="text-xs font-bold text-white/40 mb-1 block">Logo URL</label>
                <Input value={form.logo} onChange={e => setForm({ ...form, logo: e.target.value })}
                  className="bg-white/[0.04] border-white/10 text-white" />
              </div>
              <div>
                <label className="text-xs font-bold text-white/40 mb-1 block">Group</label>
                <Input value={form.groupTitle} onChange={e => setForm({ ...form, groupTitle: e.target.value })}
                  className="bg-white/[0.04] border-white/10 text-white" />
              </div>
            </div>
            <div className="flex gap-3">
              <Button onClick={save} className="bg-violet-600 hover:bg-violet-500 text-white">Save</Button>
              <Button onClick={() => setShowForm(false)} variant="outline" className="border-white/10 text-white/60">Cancel</Button>
            </div>
          </div>
        )}

        {loading ? (
          <div className="flex justify-center py-20"><RefreshCw className="w-6 h-6 text-violet-400 animate-spin" /></div>
        ) : (
          <div className="space-y-2">
            {channels.map(ch => (
              <div key={ch.id} className="flex items-center gap-4 p-4 rounded-xl border border-white/[0.05] bg-white/[0.02] hover:bg-white/[0.04] transition">
                <div className="w-10 h-10 rounded-lg bg-white/[0.03] flex items-center justify-center flex-shrink-0 overflow-hidden">
                  {ch.logo ? <img src={ch.logo} className="w-full h-full object-contain" /> : <Tv className="w-5 h-5 text-white/30" />}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-white truncate">{ch.name}</p>
                  <p className="text-xs text-white/30 truncate">{ch.groupTitle} · {ch.url.slice(0, 60)}...</p>
                </div>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <Switch checked={ch.isActive} onCheckedChange={() => toggleActive(ch)}
                    className="data-[state=checked]:bg-violet-500" />
                  <button onClick={() => del(ch.id)} className="p-2 rounded-lg hover:bg-red-500/10 text-white/30 hover:text-red-400 transition">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
