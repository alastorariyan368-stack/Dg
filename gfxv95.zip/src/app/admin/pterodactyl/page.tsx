'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Server, Save, Activity, CheckCircle, Loader2, ChevronLeft, Zap, Target, Shield } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { toast } from 'sonner'
import Link from 'next/link'

export default function PterodactylAdminPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [testing, setTesting] = useState(false)
  const [testStatus, setTestStatus] = useState<'idle' | 'ok' | 'fail'>('idle')

  const [locations, setLocations] = useState<any[]>([])
  const [nodes, setNodes] = useState<any[]>([])
  const [nests, setNests] = useState<any[]>([])
  const [eggs, setEggs] = useState<any[]>([])
  const [fetchingData, setFetchingData] = useState(false)

  const [settings, setSettings] = useState({
    pteroUrl: '',
    pteroAdminApiKey: '',
    pteroLocationId: '1',
    pteroNestId: '1',
    pteroEggId: '1',
    pteroDockerImage: '',
    pteroStartupCommand: '',
  })

  useEffect(() => {
    if (status === 'unauthenticated') { router.push('/'); return }
    if (status === 'authenticated') {
      const role = (session?.user as any)?.role
      if (role !== 'ADMIN' && role !== 'SUPER_ADMIN') { router.push('/'); return }
      loadSettings()
    }
  }, [status])

  async function loadSettings() {
    try {
      const r = await fetch('/api/admin/settings')
      if (r.ok) {
        const d = await r.json()
        setSettings({
          pteroUrl: d.pteroUrl || '',
          pteroAdminApiKey: d.pteroAdminApiKey || '',
          pteroLocationId: d.pteroLocationId || '1',
          pteroNestId: d.pteroNestId || '1',
          pteroEggId: d.pteroEggId || '1',
          pteroDockerImage: d.pteroDockerImage || '',
          pteroStartupCommand: d.pteroStartupCommand || '',
        })
        if (d.pteroUrl && d.pteroAdminApiKey) {
          fetchPteroData(d.pteroUrl, d.pteroAdminApiKey)
        }
      }
    } finally { setLoading(false) }
  }

  async function save() {
    setSaving(true)
    try {
      const r = await fetch('/api/admin/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings),
      })
      if (r.ok) toast.success('Pterodactyl settings saved')
      else toast.error('Failed to save')
    } finally { setSaving(false) }
  }

  async function testConnection() {
    setTesting(true); setTestStatus('idle')
    try {
      const r = await fetch('/api/panel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'admin-validate', panelUrl: settings.pteroUrl, apiKey: settings.pteroAdminApiKey })
      })
      const d = await r.json()
      setTestStatus(d.ok ? 'ok' : 'fail')
      if (r.ok) {
        toast.success('Connected to Pterodactyl!')
        fetchPteroData(settings.pteroUrl, settings.pteroAdminApiKey)
      }
      else toast.error('Connection failed: ' + (d.error || 'Invalid credentials'))
    } catch { setTestStatus('fail'); toast.error('Connection failed') } finally { setTesting(false) }
  }

  async function fetchPteroData(url?: string, key?: string) {
    const pUrl = url || settings.pteroUrl
    const pKey = key || settings.pteroAdminApiKey
    if (!pUrl || !pKey) return

    setFetchingData(true)
    try {
      const [locs, nsts, nds] = await Promise.all([
        fetch('/api/panel', { method: 'POST', body: JSON.stringify({ action: 'admin-list-locations', panelUrl: pUrl, apiKey: pKey }) }).then(r => r.json()),
        fetch('/api/panel', { method: 'POST', body: JSON.stringify({ action: 'admin-list-nests', panelUrl: pUrl, apiKey: pKey }) }).then(r => r.json()),
        fetch('/api/panel', { method: 'POST', body: JSON.stringify({ action: 'admin-list-nodes', panelUrl: pUrl, apiKey: pKey }) }).then(r => r.json()),
      ])

      if (locs.data) setLocations(locs.data)
      if (nsts.data) setNests(nsts.data)
      if (nds.data) setNodes(nds.data)

      if (settings.pteroNestId) {
        fetchEggs(settings.pteroNestId, pUrl, pKey)
      }
    } catch (err) {
      console.error('Failed to fetch Pterodactyl data:', err)
    } finally {
      setFetchingData(false)
    }
  }

  async function fetchEggs(nestId: string, url?: string, key?: string) {
    const pUrl = url || settings.pteroUrl
    const pKey = key || settings.pteroAdminApiKey
    try {
      const res = await fetch('/api/panel', {
        method: 'POST',
        body: JSON.stringify({ action: 'admin-list-eggs', nestId, panelUrl: pUrl, apiKey: pKey })
      }).then(r => r.json())
      if (res.data) setEggs(res.data)
    } catch (err) {
      console.error('Failed to fetch eggs:', err)
    }
  }

  function set(key: string, val: string) {
    setSettings(p => {
      const next = { ...p, [key]: val }
      if (key === 'pteroNestId') fetchEggs(val)
      return next
    })
  }

  if (status === 'loading' || loading) return (
    <div className="min-h-screen bg-[#060611] flex items-center justify-center">
      <Loader2 className="w-6 h-6 animate-spin text-purple-400" />
    </div>
  )

  return (
    <div className="min-h-screen bg-[#060611] text-white">
      <div className="max-w-3xl mx-auto px-4 py-8">
        <div className="mb-8">
          <Link href="/admin" className="inline-flex items-center gap-1.5 text-white/40 hover:text-white text-sm mb-4 transition">
            <ChevronLeft className="w-4 h-4" /> Back to Admin
          </Link>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center">
              <Server className="w-5 h-5 text-cyan-400" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-white">Pterodactyl Panel</h1>
              <p className="text-white/40 text-sm">Connect your panel to auto-provision VPS servers</p>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          {/* Connection */}
          <div className="rounded-2xl border border-white/[0.06] bg-white/[0.02] p-5">
            <h3 className="text-sm font-semibold text-white mb-1 flex items-center gap-2">
              <Shield className="w-4 h-4 text-cyan-400" /> Panel Credentials
            </h3>
            <p className="text-[11px] text-white/40 mb-4">Generate the API key at: Panel → Admin → Application API → Create New</p>
            <div className="space-y-3">
              <div>
                <label className="text-white/40 text-[11px] mb-1.5 block">Panel URL</label>
                <Input value={settings.pteroUrl} onChange={e => set('pteroUrl', e.target.value)}
                  placeholder="https://panel.yourdomain.com"
                  className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" />
              </div>
              <div>
                <label className="text-white/40 text-[11px] mb-1.5 block">Admin API Key (Application API)</label>
                <Input type="password" value={settings.pteroAdminApiKey} onChange={e => set('pteroAdminApiKey', e.target.value)}
                  placeholder="ptla_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                  className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" />
              </div>
              <div className="flex gap-2 pt-1">
                <Button onClick={testConnection} disabled={testing} variant="outline"
                  className={`flex-1 border-white/10 text-white rounded-xl gap-2 text-xs h-9 hover:bg-white/5 ${testStatus === 'ok' ? 'border-emerald-500/50 text-emerald-400' : testStatus === 'fail' ? 'border-red-500/50 text-red-400' : ''}`}>
                  {testing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : testStatus === 'ok' ? <CheckCircle className="h-3.5 w-3.5" /> : <Activity className="h-3.5 w-3.5" />}
                  {testing ? 'Testing…' : testStatus === 'ok' ? 'Connected ✓' : testStatus === 'fail' ? 'Failed ✗' : 'Test Connection'}
                </Button>
              </div>
            </div>
          </div>

          {/* Server Defaults */}
          <div className="rounded-2xl border border-white/[0.06] bg-white/[0.02] p-5">
            <h3 className="text-sm font-semibold text-white mb-4 flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-400" /> Server Defaults
            </h3>
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-white/40 text-[11px] mb-1.5 block">Location</label>
                  <Select value={settings.pteroLocationId} onValueChange={v => set('pteroLocationId', v)}>
                    <SelectTrigger className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl">
                      <SelectValue placeholder="Select Location" />
                    </SelectTrigger>
                    <SelectContent className="bg-[#0a0a14] border-white/10 text-white">
                      {locations.length > 0 ? locations.map(l => (
                        <SelectItem key={l.attributes.id} value={String(l.attributes.id)}>
                          {l.attributes.short} ({l.attributes.long})
                        </SelectItem>
                      )) : <SelectItem value={settings.pteroLocationId}>Location ID: {settings.pteroLocationId}</SelectItem>}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-white/40 text-[11px] mb-1.5 block">Default Node (Info only)</label>
                  <div className="p-2.5 rounded-xl bg-white/[0.04] border border-white/[0.08] text-xs text-white/60">
                    {nodes.length > 0 ? `${nodes.length} nodes available` : 'No nodes found'}
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-white/40 text-[11px] mb-1.5 block">Nest</label>
                  <Select value={settings.pteroNestId} onValueChange={v => set('pteroNestId', v)}>
                    <SelectTrigger className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl">
                      <SelectValue placeholder="Select Nest" />
                    </SelectTrigger>
                    <SelectContent className="bg-[#0a0a14] border-white/10 text-white">
                      {nests.length > 0 ? nests.map(n => (
                        <SelectItem key={n.attributes.id} value={String(n.attributes.id)}>
                          {n.attributes.name}
                        </SelectItem>
                      )) : <SelectItem value={settings.pteroNestId}>Nest ID: {settings.pteroNestId}</SelectItem>}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-white/40 text-[11px] mb-1.5 block">Egg</label>
                  <Select value={settings.pteroEggId} onValueChange={v => set('pteroEggId', v)}>
                    <SelectTrigger className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl">
                      <SelectValue placeholder="Select Egg" />
                    </SelectTrigger>
                    <SelectContent className="bg-[#0a0a14] border-white/10 text-white">
                      {eggs.length > 0 ? eggs.map(e => (
                        <SelectItem key={e.attributes.id} value={String(e.attributes.id)}>
                          {e.attributes.name}
                        </SelectItem>
                      )) : <SelectItem value={settings.pteroEggId}>Egg ID: {settings.pteroEggId}</SelectItem>}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div>
                <label className="text-white/40 text-[11px] mb-1.5 block">Docker Image <span className="opacity-50">(optional override)</span></label>
                <Input value={settings.pteroDockerImage} onChange={e => set('pteroDockerImage', e.target.value)}
                  placeholder="ghcr.io/pterodactyl/yolks:java_21"
                  className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" />
              </div>
              <div>
                <label className="text-white/40 text-[11px] mb-1.5 block">Startup Command <span className="opacity-50">(optional override)</span></label>
                <Input value={settings.pteroStartupCommand} onChange={e => set('pteroStartupCommand', e.target.value)}
                  placeholder="java -Xms128M -Xmx{{SERVER_MEMORY}}M -jar server.jar"
                  className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl" />
              </div>
            </div>
          </div>

          <Button onClick={save} disabled={saving}
            className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 text-white border-0 rounded-xl gap-2 h-10">
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            {saving ? 'Saving…' : 'Save Configuration'}
          </Button>

          {/* How it works */}
          <div className="rounded-2xl border border-white/[0.06] bg-white/[0.02] p-5">
            <h3 className="text-sm font-semibold text-white mb-3 flex items-center gap-2">
              <Target className="w-4 h-4 text-purple-400" /> How It Works
            </h3>
            <div className="space-y-3">
              {[
                { n: '1', t: 'User buys a hosting plan', d: 'A VPS order is created with the plan specs (RAM, CPU, Disk).' },
                { n: '2', t: 'Admin approves the order', d: 'In Admin → VPS Orders, enable "Auto-provision via Pterodactyl" and click Approve.' },
                { n: '3', t: 'Server created automatically', d: 'A Pterodactyl user is created (or reused) and a server is provisioned with plan specs.' },
                { n: '4', t: 'User receives credentials', d: 'Login credentials are sent via private message. Server is accessible immediately.' },
                { n: '5', t: 'Auto-suspend on expiry', d: 'When the order expires, use Suspend in VPS Orders to suspend the server.' },
              ].map(({ n, t, d }) => (
                <div key={n} className="flex gap-3 items-start">
                  <div className="w-5 h-5 rounded-full bg-cyan-500/20 text-cyan-400 text-[10px] font-bold flex items-center justify-center flex-shrink-0 mt-0.5">{n}</div>
                  <div>
                    <p className="text-xs font-medium text-white">{t}</p>
                    <p className="text-[11px] text-white/40">{d}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-4 p-3 rounded-xl bg-black/30 border border-white/[0.04]">
              <p className="text-[11px] text-white/40 mb-2 font-semibold">Plan Specs JSON format:</p>
              <pre className="text-[11px] text-emerald-300">{`{
  "ram": 2048,    // MB — 2048 = 2GB
  "cpu": 200,     // % — 200 = 2 vCPU
  "disk": 20480   // MB — 20480 = 20GB
}`}</pre>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
