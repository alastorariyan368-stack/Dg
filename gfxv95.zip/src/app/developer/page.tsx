'use client'

import { useState, useEffect } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import {
  Key, Plus, Trash2, Copy, Eye, EyeOff, Power, PowerOff,
  Code2, Globe, Shield, Zap, BookOpen, Terminal, CheckCircle2,
  AlertCircle, RefreshCw, Webhook
} from 'lucide-react'

interface ApiKey {
  id: string
  name: string
  key: string
  permissions: string[]
  webhookUrl?: string | null
  isActive: boolean
  requestCount: number
  lastUsedAt?: string | null
  createdAt: string
}

const PERMISSION_OPTIONS = [
  { value: 'payment:deposit', label: 'Deposits', desc: 'Create deposit requests' },
  { value: 'payment:status', label: 'Payment Status', desc: 'Check payment status' },
  { value: 'payment:withdraw', label: 'Withdrawals', desc: 'Initiate withdrawals' },
  { value: 'user:read', label: 'User Read', desc: 'Read user profile data' },
  { value: 'items:read', label: 'Items Read', desc: 'Browse marketplace items' },
  { value: 'items:write', label: 'Items Write', desc: 'Create/update items' },
  { value: 'ai:generate', label: 'AI Generate', desc: 'Use AI generation APIs' },
]

export default function DeveloperPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [keys, setKeys] = useState<ApiKey[]>([])
  const [loading, setLoading] = useState(true)
  const [creating, setCreating] = useState(false)
  const [showCreate, setShowCreate] = useState(false)
  const [newName, setNewName] = useState('')
  const [newWebhook, setNewWebhook] = useState('')
  const [newPermissions, setNewPermissions] = useState<string[]>(['payment:deposit', 'payment:status'])
  const [revealedKeys, setRevealedKeys] = useState<Set<string>>(new Set())
  const [newlyCreated, setNewlyCreated] = useState<string | null>(null)

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin?callbackUrl=/developer')
  }, [status, router])

  useEffect(() => {
    if (status === 'authenticated') fetchKeys()
  }, [status])

  async function fetchKeys() {
    setLoading(true)
    try {
      const res = await fetch('/api/developer/keys')
      const data = await res.json()
      setKeys(data.keys || [])
    } catch {
      toast.error('Failed to load API keys')
    } finally {
      setLoading(false)
    }
  }

  async function createKey() {
    if (!newName.trim()) return toast.error('Name is required')
    setCreating(true)
    try {
      const res = await fetch('/api/developer/keys', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newName, webhookUrl: newWebhook, permissions: newPermissions }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed')
      setKeys(prev => [data.key, ...prev])
      setNewlyCreated(data.key.key)
      setRevealedKeys(prev => new Set([...prev, data.key.id]))
      setShowCreate(false)
      setNewName('')
      setNewWebhook('')
      setNewPermissions(['payment:deposit', 'payment:status'])
      toast.success('API key created! Copy it now — it will be hidden later.')
    } catch (err: any) {
      toast.error(err.message)
    } finally {
      setCreating(false)
    }
  }

  async function deleteKey(id: string) {
    if (!confirm('Delete this API key? This action cannot be undone.')) return
    try {
      const res = await fetch('/api/developer/keys', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id }),
      })
      if (!res.ok) throw new Error('Failed to delete')
      setKeys(prev => prev.filter(k => k.id !== id))
      if (newlyCreated) setNewlyCreated(null)
      toast.success('Key deleted')
    } catch {
      toast.error('Failed to delete key')
    }
  }

  async function toggleKey(id: string, isActive: boolean) {
    try {
      const res = await fetch('/api/developer/keys', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ id, isActive: !isActive }),
      })
      if (!res.ok) throw new Error('Failed to update')
      setKeys(prev => prev.map(k => k.id === id ? { ...k, isActive: !isActive } : k))
      toast.success(isActive ? 'Key disabled' : 'Key enabled')
    } catch {
      toast.error('Failed to update key')
    }
  }

  function copyKey(key: string) {
    navigator.clipboard.writeText(key).then(() => toast.success('Key copied to clipboard!'))
  }

  function toggleReveal(id: string) {
    setRevealedKeys(prev => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })
  }

  function maskKey(key: string) {
    return key.slice(0, 8) + '••••••••••••••••••••••••••••••••' + key.slice(-4)
  }

  function togglePermission(p: string) {
    setNewPermissions(prev =>
      prev.includes(p) ? prev.filter(x => x !== p) : [...prev, p]
    )
  }

  if (status === 'loading') return null

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      <div className="max-w-5xl mx-auto px-4 py-12">

        {/* Header */}
        <div className="mb-10">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center">
              <Code2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-blue-400 bg-clip-text text-transparent">
                Developer Portal
              </h1>
              <p className="text-white/50 text-sm">Manage API keys to integrate GfxStore into your apps</p>
            </div>
          </div>
        </div>

        {/* Quick Links */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-10">
          {[
            { icon: BookOpen, label: 'API Docs', desc: 'Full reference', href: '/api-docs' },
            { icon: Terminal, label: 'Quickstart', desc: 'Get started fast', href: '/api-docs#quickstart' },
            { icon: Webhook, label: 'Webhooks', desc: 'Real-time events', href: '/api-docs#webhooks' },
            { icon: Shield, label: 'Auth Guide', desc: 'Secure your keys', href: '/api-docs#auth' },
          ].map(({ icon: Icon, label, desc, href }) => (
            <a key={label} href={href}
              className="bg-white/5 border border-white/10 rounded-xl p-4 hover:bg-white/8 hover:border-purple-500/40 transition-all group">
              <Icon className="w-5 h-5 text-purple-400 mb-2 group-hover:scale-110 transition-transform" />
              <div className="text-sm font-semibold text-white">{label}</div>
              <div className="text-xs text-white/40">{desc}</div>
            </a>
          ))}
        </div>

        {/* API Base URL info */}
        <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-4 mb-8 flex items-start gap-3">
          <Globe className="w-5 h-5 text-blue-400 mt-0.5 shrink-0" />
          <div>
            <div className="text-sm font-semibold text-blue-300 mb-1">API Base URL</div>
            <code className="text-xs text-blue-200 bg-blue-900/30 px-2 py-1 rounded font-mono">
              {typeof window !== 'undefined' ? window.location.origin : 'https://your-domain.com'}/api/v1
            </code>
            <p className="text-xs text-white/40 mt-1.5">
              Pass your key as <code className="text-blue-300 font-mono">Authorization: Bearer gfx_...</code> header
            </p>
          </div>
        </div>

        {/* Keys section */}
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-semibold text-white">Your API Keys</h2>
          <Button onClick={() => setShowCreate(!showCreate)}
            className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white text-sm h-9 px-4 rounded-lg">
            <Plus className="w-4 h-4 mr-1.5" />
            New Key
          </Button>
        </div>

        {/* Create form */}
        {showCreate && (
          <div className="bg-white/5 border border-white/10 rounded-xl p-6 mb-6">
            <h3 className="font-semibold text-white mb-4">Create New API Key</h3>
            <div className="space-y-4">
              <div>
                <Label className="text-white/60 text-sm mb-1.5 block">Key Name</Label>
                <Input
                  value={newName}
                  onChange={e => setNewName(e.target.value)}
                  placeholder="e.g. My App, Production, Test"
                  className="bg-white/5 border-white/10 text-white placeholder:text-white/30 focus:border-purple-500"
                />
              </div>
              <div>
                <Label className="text-white/60 text-sm mb-1.5 block">
                  Webhook URL <span className="text-white/30">(optional)</span>
                </Label>
                <Input
                  value={newWebhook}
                  onChange={e => setNewWebhook(e.target.value)}
                  placeholder="https://your-server.com/webhook"
                  className="bg-white/5 border-white/10 text-white placeholder:text-white/30 focus:border-purple-500"
                />
              </div>
              <div>
                <Label className="text-white/60 text-sm mb-2 block">Permissions</Label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {PERMISSION_OPTIONS.map(p => (
                    <button key={p.value}
                      onClick={() => togglePermission(p.value)}
                      className={`text-left p-3 rounded-lg border transition-all text-sm ${
                        newPermissions.includes(p.value)
                          ? 'border-purple-500 bg-purple-500/20 text-white'
                          : 'border-white/10 bg-white/3 text-white/50 hover:border-white/20'
                      }`}
                    >
                      <div className="font-medium">{p.label}</div>
                      <div className="text-xs text-white/40">{p.desc}</div>
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex gap-3 pt-2">
                <Button onClick={createKey} disabled={creating}
                  className="bg-purple-600 hover:bg-purple-500 text-white">
                  {creating ? <><RefreshCw className="w-4 h-4 mr-2 animate-spin" />Creating...</> : <><Key className="w-4 h-4 mr-2" />Create Key</>}
                </Button>
                <Button variant="ghost" onClick={() => setShowCreate(false)} className="text-white/50 hover:text-white">
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Keys list */}
        {loading ? (
          <div className="flex items-center justify-center py-16">
            <RefreshCw className="w-6 h-6 animate-spin text-purple-400" />
          </div>
        ) : keys.length === 0 ? (
          <div className="text-center py-16 bg-white/3 border border-white/8 rounded-xl">
            <Key className="w-10 h-10 text-white/20 mx-auto mb-3" />
            <p className="text-white/40">No API keys yet</p>
            <p className="text-white/25 text-sm mt-1">Create your first key to get started</p>
          </div>
        ) : (
          <div className="space-y-3">
            {/* New key warning */}
            {newlyCreated && (
              <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-xl p-4 flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-yellow-400 shrink-0 mt-0.5" />
                <div>
                  <div className="text-sm font-semibold text-yellow-300 mb-1">Save your key now!</div>
                  <div className="text-xs text-white/50">
                    The full key is shown below. Copy it — it will be masked after you leave this page.
                  </div>
                </div>
              </div>
            )}
            {keys.map(k => {
              const revealed = revealedKeys.has(k.id)
              const displayKey = revealed ? k.key : maskKey(k.key)
              return (
                <div key={k.id}
                  className={`bg-white/5 border rounded-xl p-4 transition-all ${k.isActive ? 'border-white/10' : 'border-white/5 opacity-60'}`}
                >
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold text-white text-sm">{k.name}</span>
                        <Badge className={k.isActive
                          ? 'bg-green-500/15 text-green-400 border-green-500/20 text-[10px]'
                          : 'bg-red-500/15 text-red-400 border-red-500/20 text-[10px]'
                        }>
                          {k.isActive ? 'Active' : 'Disabled'}
                        </Badge>
                      </div>
                      <div className="text-xs text-white/30">
                        {k.requestCount.toLocaleString()} requests •
                        Created {new Date(k.createdAt).toLocaleDateString()}
                        {k.lastUsedAt && ` • Last used ${new Date(k.lastUsedAt).toLocaleDateString()}`}
                      </div>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <button onClick={() => toggleKey(k.id, k.isActive)}
                        title={k.isActive ? 'Disable key' : 'Enable key'}
                        className="p-1.5 rounded-lg hover:bg-white/10 text-white/40 hover:text-white transition-colors">
                        {k.isActive ? <Power className="w-4 h-4" /> : <PowerOff className="w-4 h-4" />}
                      </button>
                      <button onClick={() => deleteKey(k.id)}
                        className="p-1.5 rounded-lg hover:bg-red-500/20 text-white/40 hover:text-red-400 transition-colors">
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Key display */}
                  <div className="flex items-center gap-2 bg-black/30 rounded-lg px-3 py-2 mb-3 font-mono text-xs">
                    <span className="text-green-400 flex-1 break-all">{displayKey}</span>
                    <button onClick={() => toggleReveal(k.id)} className="text-white/40 hover:text-white shrink-0">
                      {revealed ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                    <button onClick={() => copyKey(k.key)} className="text-white/40 hover:text-purple-400 shrink-0">
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Permissions */}
                  <div className="flex flex-wrap gap-1.5">
                    {(Array.isArray(k.permissions) ? k.permissions : []).map((p: string) => (
                      <span key={p} className="text-[10px] px-2 py-0.5 bg-purple-500/15 text-purple-300 rounded-full border border-purple-500/20">
                        {p}
                      </span>
                    ))}
                    {k.webhookUrl && (
                      <span className="text-[10px] px-2 py-0.5 bg-blue-500/15 text-blue-300 rounded-full border border-blue-500/20 flex items-center gap-1">
                        <Webhook className="w-2.5 h-2.5" /> webhook
                      </span>
                    )}
                  </div>
                </div>
              )
            })}
          </div>
        )}

        {/* Code example */}
        <div className="mt-12 bg-white/3 border border-white/8 rounded-xl p-6">
          <h3 className="font-semibold text-white mb-4 flex items-center gap-2">
            <Terminal className="w-4 h-4 text-purple-400" />
            Quick Example
          </h3>
          <pre className="text-xs font-mono text-green-400 bg-black/40 rounded-lg p-4 overflow-x-auto leading-relaxed">
{`// Create a deposit request
const res = await fetch('${typeof window !== 'undefined' ? window.location.origin : ''}/api/v1/payment/deposit', {
  method: 'POST',
  headers: {
    'Authorization': 'Bearer gfx_your_api_key_here',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    userId: 'user_123',
    amount: 500,
    method: 'bkash',
    phone: '01XXXXXXXXX'
  })
})

const { transactionId, status } = await res.json()`}
          </pre>
        </div>

      </div>
      <Footer />
    </div>
  )
}
