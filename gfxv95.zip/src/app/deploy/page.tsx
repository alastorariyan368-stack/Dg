'use client'
import { useState, useRef, useEffect } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Server, Terminal, Globe, Shield, Key, Lock, Rocket,
  Monitor, Settings, Download, CheckCircle, XCircle,
  AlertTriangle, Play, Loader2, ChevronDown, ChevronUp,
  Cloud, Network, Copy, Link,
} from 'lucide-react'

const SOFTWARE_OPTIONS = [
  { id: 'pterodactyl', label: 'Pterodactyl Panel', icon: Server, desc: 'Game server management panel + Wings daemon' },
  { id: 'jellyfin', label: 'Jellyfin Media Server', icon: Monitor, desc: 'Open-source media streaming server' },
  { id: 'portainer', label: 'Portainer', icon: Settings, desc: 'Docker container management UI' },
  { id: 'uptime-kuma', label: 'Uptime Kuma', icon: Shield, desc: 'Self-hosted uptime monitoring' },
  { id: 'n8n', label: 'n8n Automation', icon: Network, desc: 'Workflow automation tool' },
  { id: 'nginx', label: 'Nginx Web Server', icon: Globe, desc: 'High-performance web server' },
  { id: 'docker', label: 'Docker Engine', icon: Settings, desc: 'Container runtime environment' },
  { id: 'node', label: 'Node.js 22.x', icon: Terminal, desc: 'JavaScript runtime environment' },
  { id: 'python', label: 'Python 3', icon: Terminal, desc: 'Python programming language' },
  { id: 'mysql', label: 'MariaDB Database', icon: Server, desc: 'SQL database server' },
  { id: 'php', label: 'PHP 8.3', icon: Terminal, desc: 'PHP scripting language + Composer' },
  { id: 'custom', label: 'Custom Command', icon: Terminal, desc: 'Run any install command on the server' },
]

const CONN_METHODS = [
  { id: 'password', label: 'Password', icon: Key },
  { id: 'key', label: 'Private Key', icon: Lock },
  { id: 'url', label: 'tmate / SSH URL', icon: Link },
]

export default function DeployPage() {
  const [step, setStep] = useState<'form' | 'deploying' | 'done'>('form')
  const [connMethod, setConnMethod] = useState('password')
  const [software, setSoftware] = useState('')
  const [logs, setLogs] = useState<string[]>([])
  const [showAdvanced, setShowAdvanced] = useState(false)
  const [connectionUrl, setConnectionUrl] = useState('')
  const [connType, setConnType] = useState<'ssh' | 'tmate' | 'sshx' | null>(null)
  const [deployId] = useState(() => Math.random().toString(36).slice(2, 8))
  const logEndRef = useRef<HTMLDivElement>(null)
  const [form, setForm] = useState({
    host: '', port: '22', username: 'root', password: '', privateKey: '',
    domain: '', email: '',
    cfToken: '', cfEmail: '', cfApiKey: '',
    tailscaleKey: '', tailscaleHostname: '',
    customCommand: '', customType: 'script', softwareName: '', port: '',
    dbPassword: '', mediaPath: '/media',
  })

  useEffect(() => {
    logEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [logs])

  const parseConnectionString = (input: string) => {
    const trimmed = input.trim()
    // tmate: ssh <session_key>@<host> or ssh -o StrictHostKeyChecking=no <session>@<host>
    const sshUrlMatch = trimmed.match(/^ssh(?:\s+-[^\s]+)?\s+(\S+)@(\S+)/)
    if (sshUrlMatch) {
      const user = sshUrlMatch[1]; const host = sshUrlMatch[2].replace(/^\[|\]$/g, '')
      let port = 22
      const portMatch = trimmed.match(/-p\s+(\d+)/)
      if (portMatch) port = parseInt(portMatch[1])
      if (host.includes('tmate.io')) {
        setConnType('tmate')
      } else if (host.includes('sshx.io')) {
        setConnType('sshx')
        setConnectionUrl(trimmed)
        return
      } else {
        setConnType('ssh')
      }
      setForm(prev => ({ ...prev, host: host, port: String(port), username: user }))
      return
    }
    // ssh user@host or user@host
    const sshMatch = trimmed.match(/^(?:ssh\s+)?(\S+)@(\S+)(?::(\d+))?\s*$/)
    if (sshMatch) {
      const user = sshMatch[1]; const host = sshMatch[2]; const port = sshMatch[3] || '22'
      setConnType(host.includes('tmate.io') ? 'tmate' : host.includes('sshx.io') ? 'sshx' : 'ssh')
      setForm(prev => ({ ...prev, host: host, port: port, username: user }))
      return
    }
    // host:port or just host
    const hostPortMatch = trimmed.match(/^([\w.-]+?)(?::(\d+))?\s*$/)
    if (hostPortMatch) {
      const host = hostPortMatch[1]; const port = hostPortMatch[2] || '22'
      setConnType('ssh')
      setForm(prev => ({ ...prev, host: host, port: port }))
    }
  }

  const handleConnectionUrlPaste = (val: string) => {
    setConnectionUrl(val)
    parseConnectionString(val)
  }

  const startDeploy = async () => {
    if (!software) return
    setStep('deploying')
    setLogs([`🚀 Deploy #${deployId} started...`])

    const payload: any = {
      software,
      ssh: {
        host: form.host,
        port: parseInt(form.port) || 22,
        username: form.username,
      },
    }
    if (connMethod === 'password') payload.ssh.password = form.password
    else if (connMethod === 'key') payload.ssh.privateKey = form.privateKey
    if (connType === 'tmate' || connType === 'sshx') payload.ssh.tmate = true

    if (form.domain) payload.domain = form.domain
    if (form.email) payload.email = form.email
    if (form.cfToken) payload.cfToken = form.cfToken
    if (form.cfEmail) payload.cfEmail = form.cfEmail
    if (form.cfApiKey) payload.cfApiKey = form.cfApiKey
    if (form.tailscaleKey) payload.tailscaleKey = form.tailscaleKey
    if (form.tailscaleHostname) payload.tailscaleHostname = form.tailscaleHostname
    if (form.dbPassword) payload.dbPassword = form.dbPassword
    if (form.mediaPath) payload.mediaPath = form.mediaPath
    if (form.port) payload.port = form.port
    if (software === 'custom') {
      payload.customCommand = form.customCommand
      payload.customType = form.customType
      payload.softwareName = form.softwareName
    }

    try {
      const res = await fetch('/api/deploy/install', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })

      const reader = res.body?.getReader()
      if (!reader) { setLogs(prev => [...prev, '❌ No response stream']); return }

      const decoder = new TextDecoder()
      let buffer = ''

      while (true) {
        const { done, value } = await reader.read()
        if (done) break

        buffer += decoder.decode(value, { stream: true })
        const lines = buffer.split('\n')
        buffer = lines.pop() || ''

        for (const line of lines) {
          if (line.startsWith('event: ')) {
            const eventType = line.slice(7).trim()
            continue
          }
          if (line.startsWith('data: ')) {
            const data = line.slice(6).trim()
            const parsed = JSON.parse(data)
            setLogs(prev => [...prev, parsed])
          }
        }
      }

      setStep('done')
      setLogs(prev => [...prev, '✅ Deployment completed!'])
    } catch (err: any) {
      setLogs(prev => [...prev, `❌ Error: ${err.message}`])
      setStep('done')
    }
  }

  const copyLogs = () => {
    navigator.clipboard.writeText(logs.join('\n'))
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <Navbar />

      <div className="px-4 md:px-8 py-8 max-w-6xl mx-auto">
        <div className="flex items-center gap-4 mb-8">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-500/20 to-teal-500/20 border border-emerald-500/20 flex items-center justify-center">
            <Rocket className="w-6 h-6 text-emerald-400" />
          </div>
          <div>
            <h1 className="text-3xl font-black text-white">Auto Deploy</h1>
            <p className="text-white/40 text-sm">One-click server setup — SSH, install, Cloudflare, Tailscale</p>
          </div>
        </div>

        <AnimatePresence mode="wait">
          {step === 'form' && (
            <motion.div key="form" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="grid lg:grid-cols-3 gap-6">
              {/* Software Selection */}
              <div className="lg:col-span-2 space-y-6">
                <div className="p-6 rounded-2xl border border-white/[0.08] bg-white/[0.02]">
                  <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                    <Download className="w-4 h-4 text-emerald-400" /> Software to Install
                  </h2>
                  <div className="grid sm:grid-cols-2 gap-2">
                    {SOFTWARE_OPTIONS.map(opt => (
                      <button key={opt.id} onClick={() => setSoftware(opt.id)}
                        className={`flex items-start gap-3 p-3 rounded-xl border transition-all text-left ${
                          software === opt.id
                            ? 'border-emerald-500/40 bg-emerald-500/5'
                            : 'border-white/[0.06] bg-white/[0.02] hover:bg-white/[0.04]'
                        }`}>
                        <div className={`w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 ${
                          software === opt.id ? 'bg-emerald-500/20 text-emerald-400' : 'bg-white/5 text-white/40'
                        }`}>
                          <opt.icon className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-sm font-bold text-white">{opt.label}</p>
                          <p className="text-[10px] text-white/40 mt-0.5">{opt.desc}</p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Connection */}
                <div className="p-6 rounded-2xl border border-white/[0.08] bg-white/[0.02]">
                  <h2 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                    <Globe className="w-4 h-4 text-emerald-400" /> Connection
                  </h2>

                  <div className="flex gap-2 mb-4">
                    {CONN_METHODS.map(m => (
                      <button key={m.id} onClick={() => setConnMethod(m.id)}
                        className={`flex items-center gap-1.5 px-4 py-1.5 rounded-full text-xs font-bold transition-all ${
                          connMethod === m.id
                            ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                            : 'bg-white/5 text-white/50 border border-white/10'
                        }`}>
                        <m.icon className="w-3 h-3" />
                        {m.label}
                      </button>
                    ))}
                  </div>

                  {connMethod === 'url' ? (
                    <div>
                      <label className="text-xs font-bold text-white/40 mb-1 block">Paste SSH command or tmate URL</label>
                      <div className="relative">
                        <Input value={connectionUrl} onChange={e => handleConnectionUrlPaste(e.target.value)}
                          placeholder="ssh root@1.2.3.4  or  ssh abc123@ny1.tmate.io"
                          className="bg-white/[0.04] border-white/10 text-white text-sm font-mono pr-24" />
                        {connType && (
                          <Badge className={`absolute right-2 top-1/2 -translate-y-1/2 text-[10px] px-2 py-0.5 ${
                            connType === 'tmate' ? 'bg-purple-500/20 text-purple-300 border-purple-500/30' :
                            connType === 'sshx' ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30' :
                            'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
                          }`}>
                            {connType === 'tmate' ? '🔗 tmate' : connType === 'sshx' ? '🔗 sshx' : '🔗 SSH'}
                          </Badge>
                        )}
                      </div>
                      {connType === 'tmate' && (
                        <p className="text-[11px] text-purple-400/60 mt-2">
                          tmate detected — no password needed, session key used as username
                        </p>
                      )}
                      {form.host && connMethod === 'url' && (
                        <div className="mt-3 p-3 rounded-xl bg-white/[0.02] border border-white/[0.05] text-xs text-white/50 space-y-1">
                          <div className="flex gap-2"><span className="text-white/30 w-16">Host:</span><span className="text-white font-mono">{form.host}</span></div>
                          <div className="flex gap-2"><span className="text-white/30 w-16">Port:</span><span className="text-white font-mono">{form.port}</span></div>
                          <div className="flex gap-2"><span className="text-white/30 w-16">User:</span><span className="text-white font-mono">{form.username || '(session key)'}</span></div>
                        </div>
                      )}
                    </div>
                  ) : (
                    <>
                      <div className="grid md:grid-cols-3 gap-3 mb-4">
                        <div>
                          <label className="text-xs font-bold text-white/40 mb-1 block">Host *</label>
                          <Input value={form.host} onChange={e => setForm({...form, host: e.target.value})}
                            placeholder="192.168.1.1" className="bg-white/[0.04] border-white/10 text-white text-sm" />
                        </div>
                        <div>
                          <label className="text-xs font-bold text-white/40 mb-1 block">Port</label>
                          <Input value={form.port} onChange={e => setForm({...form, port: e.target.value})}
                            placeholder="22" className="bg-white/[0.04] border-white/10 text-white text-sm" />
                        </div>
                        <div>
                          <label className="text-xs font-bold text-white/40 mb-1 block">Username</label>
                          <Input value={form.username} onChange={e => setForm({...form, username: e.target.value})}
                            placeholder="root" className="bg-white/[0.04] border-white/10 text-white text-sm" />
                        </div>
                      </div>

                      {connMethod === 'password' ? (
                        <div>
                          <label className="text-xs font-bold text-white/40 mb-1 block">Password</label>
                          <Input type="password" value={form.password} onChange={e => setForm({...form, password: e.target.value})}
                            placeholder="••••••••" className="bg-white/[0.04] border-white/10 text-white text-sm font-mono" />
                        </div>
                      ) : (
                        <div>
                          <label className="text-xs font-bold text-white/40 mb-1 block">Private Key (PEM)</label>
                          <textarea value={form.privateKey} onChange={e => setForm({...form, privateKey: e.target.value})}
                            placeholder="-----BEGIN OPENSSH PRIVATE KEY-----&#10;..."
                            className="w-full h-28 rounded-xl bg-white/[0.04] border border-white/10 text-white text-xs font-mono p-3 resize-none focus:outline-none focus:border-emerald-500/40" />
                        </div>
                      )}
                    </>
                  )}
                </div>

                {/* Cloudflare + Tailscale */}
                <div className="p-6 rounded-2xl border border-white/[0.08] bg-white/[0.02]">
                  <button onClick={() => setShowAdvanced(!showAdvanced)}
                    className="flex items-center gap-2 text-lg font-bold text-white mb-4 w-full justify-between">
                    <span className="flex items-center gap-2"><Settings className="w-4 h-4 text-white/40" /> Advanced Options</span>
                    {showAdvanced ? <ChevronUp className="w-4 h-4 text-white/40" /> : <ChevronDown className="w-4 h-4 text-white/40" />}
                  </button>
                  <AnimatePresence>
                    {showAdvanced && (
                      <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }} exit={{ height: 0, opacity: 0 }} className="space-y-4 overflow-hidden">
                        <div className="grid md:grid-cols-2 gap-4 p-4 rounded-xl bg-white/[0.02] border border-white/[0.05]">
                          <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold mb-1 col-span-full">
                            <Cloud className="w-3.5 h-3.5" /> Cloudflare Tunnel
                          </div>
                          <div>
                            <label className="text-xs text-white/40 mb-1 block">Domain</label>
                            <Input value={form.domain} onChange={e => setForm({...form, domain: e.target.value})}
                              placeholder="panel.yourdomain.com" className="bg-white/[0.04] border-white/10 text-white text-sm" />
                          </div>
                          <div>
                            <label className="text-xs text-white/40 mb-1 block">Email</label>
                            <Input value={form.email} onChange={e => setForm({...form, email: e.target.value})}
                              placeholder="admin@example.com" className="bg-white/[0.04] border-white/10 text-white text-sm" />
                          </div>
                          <div>
                            <label className="text-xs text-white/40 mb-1 block">Cloudflare Token</label>
                            <Input value={form.cfToken} onChange={e => setForm({...form, cfToken: e.target.value})}
                              placeholder="cfn_..." className="bg-white/[0.04] border-white/10 text-white text-sm" />
                          </div>
                          <div>
                            <label className="text-xs text-white/40 mb-1 block">API Key</label>
                            <Input value={form.cfApiKey} onChange={e => setForm({...form, cfApiKey: e.target.value})}
                              placeholder="Optional" className="bg-white/[0.04] border-white/10 text-white text-sm" />
                          </div>
                        </div>

                        <div className="grid md:grid-cols-2 gap-4 p-4 rounded-xl bg-white/[0.02] border border-white/[0.05]">
                          <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold mb-1 col-span-full">
                            <Network className="w-3.5 h-3.5" /> Tailscale
                          </div>
                          <div>
                            <label className="text-xs text-white/40 mb-1 block">Auth Key</label>
                            <Input value={form.tailscaleKey} onChange={e => setForm({...form, tailscaleKey: e.target.value})}
                              placeholder="tskey-..." className="bg-white/[0.04] border-white/10 text-white text-sm" />
                          </div>
                          <div>
                            <label className="text-xs text-white/40 mb-1 block">Hostname</label>
                            <Input value={form.tailscaleHostname} onChange={e => setForm({...form, tailscaleHostname: e.target.value})}
                              placeholder="my-server" className="bg-white/[0.04] border-white/10 text-white text-sm" />
                          </div>
                        </div>

                        {software === 'pterodactyl' && (
                          <div className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.05]">
                            <label className="text-xs text-white/40 mb-1 block">Database Password (leave empty for auto)</label>
                            <Input value={form.dbPassword} onChange={e => setForm({...form, dbPassword: e.target.value})}
                              placeholder="Auto-generated" className="bg-white/[0.04] border-white/10 text-white text-sm font-mono" />
                          </div>
                        )}

                        {software === 'jellyfin' && (
                          <div className="p-4 rounded-xl bg-white/[0.02] border border-white/[0.05]">
                            <label className="text-xs text-white/40 mb-1 block">Media Path</label>
                            <Input value={form.mediaPath} onChange={e => setForm({...form, mediaPath: e.target.value})}
                              placeholder="/media" className="bg-white/[0.04] border-white/10 text-white text-sm" />
                          </div>
                        )}

                        {software === 'custom' && (
                          <div className="space-y-3 p-4 rounded-xl bg-white/[0.02] border border-white/[0.05]">
                            <div>
                              <label className="text-xs text-white/40 mb-1 block">Software Name</label>
                              <Input value={form.softwareName} onChange={e => setForm({...form, softwareName: e.target.value})}
                                placeholder="My App" className="bg-white/[0.04] border-white/10 text-white text-sm" />
                            </div>
                            <div>
                              <label className="text-xs text-white/40 mb-1 block">Install Command *</label>
                              <textarea value={form.customCommand} onChange={e => setForm({...form, customCommand: e.target.value})}
                                placeholder="apt install -y myapp"
                                className="w-full h-20 rounded-xl bg-white/[0.04] border border-white/10 text-white text-sm font-mono p-3 resize-none focus:outline-none focus:border-emerald-500/40" />
                            </div>
                            <div>
                              <label className="text-xs text-white/40 mb-1 block">Type</label>
                              <div className="flex gap-2">
                                {['script', 'docker', 'binary', 'apt'].map(t => (
                                  <button key={t} onClick={() => setForm({...form, customType: t})}
                                    className={`px-3 py-1 rounded-full text-[10px] font-bold transition-all ${
                                      form.customType === t
                                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                                        : 'bg-white/5 text-white/50 border border-white/10'
                                    }`}>{t}</button>
                                ))}
                              </div>
                            </div>
                            <div>
                              <label className="text-xs text-white/40 mb-1 block">Port (optional)</label>
                              <Input value={form.port} onChange={e => setForm({...form, port: e.target.value})}
                                placeholder="8080" className="bg-white/[0.04] border-white/10 text-white text-sm" />
                            </div>
                          </div>
                        )}
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>

              {/* Sidebar - Summary + Deploy */}
              <div className="space-y-6">
                <div className="p-6 rounded-2xl border border-white/[0.08] bg-white/[0.02] sticky top-24">
                  <h2 className="text-lg font-bold text-white mb-4">Deploy Summary</h2>
                  <div className="space-y-3 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-white/40">Software</span>
                      <Badge className="bg-emerald-500/10 text-emerald-300 border-emerald-500/20 text-xs">
                        {software ? SOFTWARE_OPTIONS.find(o => o.id === software)?.label || software : 'Not selected'}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-white/40">Server</span>
                      <span className="text-white font-mono text-xs">{form.host || '—'}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-white/40">Cloudflare</span>
                      <span className={form.cfToken ? 'text-emerald-400' : 'text-white/30'}>
                        {form.cfToken ? '✅' : '—'}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-white/40">Tailscale</span>
                      <span className={form.tailscaleKey ? 'text-emerald-400' : 'text-white/30'}>
                        {form.tailscaleKey ? '✅' : '—'}
                      </span>
                    </div>
                  </div>
                  <Button onClick={startDeploy} disabled={!software || (!form.host && connType !== 'tmate')}
                    className="w-full mt-6 bg-emerald-600 hover:bg-emerald-500 text-white rounded-full h-12 text-base font-bold shadow-lg shadow-emerald-500/25">
                    <Rocket className="w-5 h-5 mr-2" /> Deploy Now
                  </Button>
                  <p className="text-[10px] text-white/20 text-center mt-2">
                    SSH connection required · logs will stream in real-time
                  </p>
                </div>
              </div>
            </motion.div>
          )}

          {step === 'deploying' && (
            <motion.div key="deploying" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Loader2 className="w-5 h-5 text-emerald-400 animate-spin" />
                  <div>
                    <h2 className="text-lg font-bold text-white">Deploying #{deployId}</h2>
                    <p className="text-xs text-white/40">{software} → {form.host}</p>
                  </div>
                </div>
                <Badge className="bg-emerald-500/10 text-emerald-300 border-emerald-500/20 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> Running
                </Badge>
              </div>

              <div className="rounded-2xl border border-white/[0.08] bg-black overflow-hidden">
                <div className="flex items-center justify-between px-4 py-2 bg-white/[0.02] border-b border-white/[0.05]">
                  <div className="flex items-center gap-2 text-white/40 text-xs">
                    <Terminal className="w-3 h-3" /> Installation Log
                  </div>
                  <span className="text-[10px] text-white/20 font-mono">{deployId}</span>
                </div>
                <div className="h-[60vh] overflow-y-auto p-4 font-mono text-xs leading-relaxed" style={{ background: '#0a0a0f' }}>
                  {logs.map((log, i) => (
                    <motion.div key={i} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }}
                      className={`${
                        log.startsWith('❌') ? 'text-red-400' :
                        log.startsWith('✅') ? 'text-emerald-400' :
                        log.startsWith('⚠️') || log.includes('⚠️') ? 'text-amber-400' :
                        log.startsWith('🚀') || log.startsWith('📋') ? 'text-cyan-400' :
                        log.startsWith('📦') ? 'text-white/70' :
                        log.startsWith('🔌') || log.startsWith('🔗') || log.startsWith('🔑') || log.startsWith('🔓') ? 'text-yellow-400' :
                        log.startsWith('🌐') ? 'text-blue-400' :
                        log.startsWith('[ERR]') ? 'text-red-400/70' :
                        log.startsWith('[EXIT]') && log.includes('0') ? 'text-emerald-400/70' :
                        log.startsWith('[EXIT]') ? 'text-red-400/70' :
                        'text-white/50'
                      }`}>
                      <span className="text-white/20 mr-2">[{String(i).padStart(3, '0')}]</span>
                      {log}
                    </motion.div>
                  ))}
                  <div ref={logEndRef} />
                </div>
              </div>
            </motion.div>
          )}

          {step === 'done' && (
            <motion.div key="done" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="text-center py-12">
              <div className="w-20 h-20 rounded-full bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-10 h-10 text-emerald-400" />
              </div>
              <h2 className="text-3xl font-black text-white mb-2">Deployment Complete</h2>
              <p className="text-white/40 mb-8">{software} → {form.host}</p>

              <div className="max-w-2xl mx-auto mb-8">
                <div className="rounded-2xl border border-white/[0.08] bg-black overflow-hidden">
                  <div className="flex items-center justify-between px-4 py-2 bg-white/[0.02] border-b border-white/[0.05]">
                    <div className="flex items-center gap-2 text-white/40 text-xs">
                      <Terminal className="w-3 h-3" /> Installation Log
                    </div>
                    <button onClick={copyLogs} className="text-white/30 hover:text-white/60 text-xs flex items-center gap-1">
                      <Copy className="w-3 h-3" /> Copy
                    </button>
                  </div>
                  <div className="h-48 overflow-y-auto p-4 font-mono text-xs leading-relaxed text-left" style={{ background: '#0a0a0f' }}>
                    {logs.map((log, i) => (
                      <div key={i} className={`${
                        log.startsWith('❌') ? 'text-red-400' :
                        log.startsWith('✅') ? 'text-emerald-400' :
                        log.startsWith('📋') ? 'text-cyan-400' :
                        'text-white/50'
                      }`}>{log}</div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex gap-3 justify-center">
                <Button onClick={() => { setStep('form'); setLogs([]); setSoftware('') }}
                  className="bg-white/5 hover:bg-white/10 text-white border border-white/10 rounded-full px-8">
                  Deploy Another
                </Button>
                <Button onClick={() => window.location.href = '/'}
                  variant="outline" className="border-white/10 text-white/50 rounded-full px-8">
                  Go Home
                </Button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <Footer />
    </div>
  )
}
