'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Gift, Package, Download, Star, Search, Loader2, ArrowRight, Heart } from 'lucide-react'

interface FreeItem {
  id: string; title: string; slug: string; logo?: string; shortDesc?: string
  downloads: number; likes: number
  category: { name: string }
  author: { username: string; avatar?: string; isVerified: boolean }
}

export default function FreebiesPage() {
  const [items, setItems] = useState<FreeItem[]>([])
  const [filtered, setFiltered] = useState<FreeItem[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')

  useEffect(() => {
    fetchFreebies()
  }, [])

  useEffect(() => {
    if (search.trim()) {
      setFiltered(items.filter(i => i.title.toLowerCase().includes(search.toLowerCase()) || i.category?.name.toLowerCase().includes(search.toLowerCase())))
    } else {
      setFiltered(items)
    }
  }, [search, items])

  const fetchFreebies = async () => {
    try {
      const res = await fetch('/api/items?accessType=FREE&status=APPROVED&limit=50')
      if (res.ok) {
        const data = await res.json()
        setItems(data.items || [])
        setFiltered(data.items || [])
      }
    } catch {} finally { setLoading(false) }
  }

  const fmt = (n: number) => n >= 1000 ? (n / 1000).toFixed(1) + 'K' : n.toString()

  return (
    <div className="min-h-screen bg-[#0a0a0f]">
      <Navbar />

      {/* Hero */}
      <section className="relative py-20 px-4 text-center overflow-hidden">
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff08_1px,transparent_1px),linear-gradient(to_bottom,#ffffff08_1px,transparent_1px)] bg-[size:32px_32px]" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-green-600/15 rounded-full blur-3xl pointer-events-none" />
        <div className="container mx-auto relative z-10">
          <Badge className="mb-4 px-4 py-1.5 bg-green-500/10 text-green-300 border-green-500/30 text-sm">
            <Gift className="w-3.5 h-3.5 mr-1.5" />
            100% Free Content
          </Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">
            Free{' '}
            <span className="bg-gradient-to-r from-green-400 to-emerald-400 bg-clip-text text-transparent">Ultimate</span>
            {' '}Resources
          </h1>
          <p className="text-white/50 text-lg mb-8 max-w-xl mx-auto">
            Download premium-quality digital content for free. No account needed for most items.
          </p>
          <div className="max-w-md mx-auto relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-white/30" />
            <Input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search freebies..."
              className="pl-10 h-12 bg-white/5 border-white/10 text-white placeholder:text-white/30 rounded-xl text-base"
            />
          </div>
        </div>
      </section>

      {/* Items */}
      <div className="container mx-auto px-4 pb-20 max-w-6xl">
        <div className="flex items-center justify-between mb-6">
          <p className="text-white/40 text-sm">{filtered.length} free items available</p>
          <Link href="/browse">
            <Button variant="ghost" className="text-white/50 hover:text-white hover:bg-white/5 gap-2 text-sm">
              Browse All <ArrowRight className="h-4 w-4" />
            </Button>
          </Link>
        </div>

        {loading ? (
          <div className="flex items-center justify-center py-20"><Loader2 className="w-8 h-8 animate-spin text-green-400" /></div>
        ) : filtered.length === 0 ? (
          <div className="text-center py-20">
            <Gift className="w-16 h-16 mx-auto text-white/10 mb-4" />
            <p className="text-white/40 text-lg">No free items found</p>
            {search && <p className="text-white/30 text-sm mt-1">Try a different search term</p>}
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filtered.map(item => (
              <Link key={item.id} href={`/items/${item.slug}`}>
                <div className="group bg-white/[0.03] hover:bg-white/[0.06] border border-white/8 hover:border-green-500/30 rounded-2xl p-4 transition-all duration-300 cursor-pointer h-full flex flex-col">
                  <div className="flex items-start gap-3 mb-3">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-green-500/20 to-emerald-500/10 border border-white/10 flex items-center justify-center flex-shrink-0">
                      {item.logo ? <img src={item.logo} alt={item.title} className="w-full h-full object-cover rounded-xl" /> : <Package className="w-4 h-4 text-white/30" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <Badge className="bg-white/5 text-white/40 border-white/10 text-[9px] mb-1">{item.category?.name}</Badge>
                      <h3 className="font-semibold text-white text-sm line-clamp-1 group-hover:text-green-300 transition-colors">{item.title}</h3>
                    </div>
                  </div>
                  {item.shortDesc && <p className="text-white/40 text-xs line-clamp-2 mb-3 flex-1">{item.shortDesc}</p>}
                  <div className="flex items-center justify-between mt-auto">
                    <div className="flex items-center gap-2 text-xs text-white/30">
                      <span className="flex items-center gap-1"><Star className="h-3 w-3 text-yellow-400" />{item.likes}</span>
                      <span className="flex items-center gap-1"><Download className="h-3 w-3" />{fmt(item.downloads)}</span>
                    </div>
                    <Badge className="bg-green-500/10 text-green-400 border-green-500/20 text-[10px]">FREE</Badge>
                  </div>
                  <p className="text-[10px] text-white/30 mt-2">by {item.author?.username} {item.author?.isVerified && '✓'}</p>
                </div>
              </Link>
            ))}
          </div>
        )}
      </div>
      <Footer />
    </div>
  )
}
