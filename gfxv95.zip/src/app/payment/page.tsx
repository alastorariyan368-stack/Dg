'use client'

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'

export default function PaymentRedirectPage() {
  const router = useRouter()
  
  useEffect(() => {
    router.replace('/deposit')
  }, [router])

  return (
    <div className="min-h-screen bg-[#060611] flex items-center justify-center">
      <div className="text-center">
        <div className="w-10 h-10 border-4 border-purple-500/20 border-t-purple-500 rounded-full animate-spin mx-auto mb-4" />
        <p className="text-white/40 text-sm">Redirecting to secure deposit page...</p>
      </div>
    </div>
  )
}
