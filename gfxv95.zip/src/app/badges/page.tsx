'use client'

import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Loader2, Award, Check, Lock, Star, ChevronRight } from 'lucide-react'
import { toast } from 'sonner'

type BadgeItem = {
  id: string
  name: string
  description?: string | null
  icon: string | null
  color: string
  criteria?: string | null
  isAutomatic: boolean
}

type BadgeStatus = 'earned' | 'claimable' | 'locked'

export default function BadgesPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [allBadges, setAllBadges] = useState<BadgeItem[]>([])
  const [userBadgeIds, setUserBadgeIds] = useState<string[]>([])
  const [claimableIds, setClaimableIds] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const [claiming, setClaiming] = useState<string | null>(null)

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/auth/signin')
    }
  }, [status, router])

  useEffect(() => {
    if (status !== 'authenticated') return

    const load = async () => {
      setLoading(true)
      try {
        const [allRes, claimRes] = await Promise.all([
          fetch('/api/badges'),
          fetch('/api/badges/claimable'),
        ])

        if (allRes.ok) {
          const data = await allRes.json()
          setAllBadges(data.badges || [])
          setUserBadgeIds(data.userBadgeIds || [])
        }

        if (claimRes.ok) {
          const data = await claimRes.json()
          setClaimableIds((data.claimableBadges || []).map((b: BadgeItem) => b.id))
        }
      } catch (error) {
        console.error('Failed to load badges:', error)
        toast.error('Failed to load badges')
      } finally {
        setLoading(false)
      }
    }

    load()
  }, [status])

  const claimBadge = async (badgeId: string) => {
    setClaiming(badgeId)
    try {
      const res = await fetch('/api/badges/claimable', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ badgeId }),
      })

      if (res.ok) {
        const data = await res.json()
        toast.success(data.message || 'Badge claimed!')
        setUserBadgeIds(prev => [...prev, badgeId])
        setClaimableIds(prev => prev.filter(id => id !== badgeId))
      } else {
        const error = await res.json().catch(() => ({}))
        toast.error(error.error || 'Failed to claim badge')
      }
    } catch {
      toast.error('Failed to claim badge')
    } finally {
      setClaiming(null)
    }
  }

  const getBadgeStatus = (badge: BadgeItem): BadgeStatus => {
    if (userBadgeIds.includes(badge.id)) return 'earned'
    if (claimableIds.includes(badge.id)) return 'claimable'
    return 'locked'
  }

  const getCriteriaLabel = (badge: BadgeItem): string => {
    if (!badge.isAutomatic) return 'Awarded by admin'
    if (!badge.criteria) return 'Special achievement'
    const c = badge.criteria.toLowerCase()
    if (c.includes('first item')) return 'Upload your first item'
    if (c.includes('first sale')) return 'Make your first sale'
    if (c.includes('first review')) return 'Write your first review'
    if (c.includes('first download')) return 'Download your first item'
    if (c.includes('first follow')) return 'Follow someone'
    if (c.includes('first follower')) return 'Get your first follower'
    const mFollower = c.match(/(\d+)\s*follower/)
    if (mFollower) return `Reach ${mFollower[1]} followers`
    const mSale = c.match(/(\d+)\s*(sale|sell|sold)/)
    if (mSale) return `Complete ${mSale[1]} sales`
    const mReview = c.match(/(\d+)\s*review/)
    if (mReview) return `Write ${mReview[1]} reviews`
    return badge.criteria
  }

  const earned = allBadges.filter(b => getBadgeStatus(b) === 'earned')
  const claimable = allBadges.filter(b => getBadgeStatus(b) === 'claimable')
  const locked = allBadges.filter(b => getBadgeStatus(b) === 'locked')

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />

      <div className="container mx-auto px-4 py-10 max-w-5xl">
        {/* Header */}
        <div className="mb-10">
          <div className="flex items-center gap-3 mb-2">
            <Award className="w-6 h-6 text-purple-400" />
            <h1 className="text-3xl font-bold">Achievement Badges</h1>
          </div>
          <p className="text-white/40">Complete tasks and earn badges to showcase your achievements</p>

          <div className="flex gap-4 mt-4 text-sm">
            <span className="flex items-center gap-1.5 text-emerald-400">
              <Check className="w-4 h-4" /> {earned.length} earned
            </span>
            <span className="flex items-center gap-1.5 text-yellow-400">
              <Star className="w-4 h-4" /> {claimable.length} ready to claim
            </span>
            <span className="flex items-center gap-1.5 text-white/30">
              <Lock className="w-4 h-4" /> {locked.length} locked
            </span>
          </div>
        </div>

        {/* Claimable Badges */}
        {claimable.length > 0 && (
          <section className="mb-10">
            <h2 className="text-base font-semibold text-yellow-400 mb-4 flex items-center gap-2">
              <Star className="w-4 h-4" /> Ready to Claim ({claimable.length})
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {claimable.map(badge => (
                <div key={badge.id}
                  className="bg-yellow-500/5 border border-yellow-500/20 rounded-xl p-5 hover:bg-yellow-500/10 transition-colors">
                  <div className="flex items-start justify-between mb-3">
                    <span className="text-4xl">{badge.icon || '⭐'}</span>
                    <Badge className="text-[10px] bg-yellow-500/10 text-yellow-400 border-yellow-500/20">
                      Claimable
                    </Badge>
                  </div>
                  <h3 className="text-sm font-semibold text-white mb-1">{badge.name}</h3>
                  {badge.description && (
                    <p className="text-[12px] text-white/40 mb-2">{badge.description}</p>
                  )}
                  <p className="text-[11px] text-yellow-400/70 italic mb-3">
                    ✓ {getCriteriaLabel(badge)}
                  </p>
                  <Button
                    onClick={() => claimBadge(badge.id)}
                    disabled={claiming === badge.id}
                    className="w-full text-[12px] h-8 bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-500 hover:to-orange-500 text-white border-0 rounded-lg gap-1.5"
                  >
                    {claiming === badge.id ? (
                      <><Loader2 className="w-3.5 h-3.5 animate-spin" />Claiming...</>
                    ) : (
                      <><Check className="w-3.5 h-3.5" />Claim Badge</>
                    )}
                  </Button>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Earned Badges */}
        {earned.length > 0 && (
          <section className="mb-10">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base font-semibold text-emerald-400 flex items-center gap-2">
                <Check className="w-4 h-4" /> Your Earned Badges ({earned.length})
              </h2>
              <Link href="/profile" className="text-xs text-white/30 hover:text-white/60 flex items-center gap-1 transition-colors">
                View Profile <ChevronRight className="w-3 h-3" />
              </Link>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {earned.map(badge => (
                <div key={badge.id}
                  className="bg-emerald-500/5 border border-emerald-500/20 rounded-xl p-5">
                  <div className="flex items-start justify-between mb-3">
                    <span className="text-4xl" style={{ filter: 'drop-shadow(0 0 8px currentColor)', color: badge.color }}>
                      {badge.icon || '⭐'}
                    </span>
                    <Badge className="text-[10px] bg-emerald-500/10 text-emerald-400 border-emerald-500/20">
                      Earned ✓
                    </Badge>
                  </div>
                  <h3 className="text-sm font-semibold text-white mb-1">{badge.name}</h3>
                  {badge.description && (
                    <p className="text-[12px] text-white/40 mb-2">{badge.description}</p>
                  )}
                  <p className="text-[11px] text-emerald-400/60 italic">
                    {getCriteriaLabel(badge)}
                  </p>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Locked Badges */}
        {locked.length > 0 && (
          <section className="mb-10">
            <h2 className="text-base font-semibold text-white/30 mb-4 flex items-center gap-2">
              <Lock className="w-4 h-4" /> Locked Badges ({locked.length})
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {locked.map(badge => (
                <div key={badge.id}
                  className="bg-white/[0.02] border border-white/5 rounded-xl p-5 opacity-60">
                  <div className="flex items-start justify-between mb-3">
                    <span className="text-4xl grayscale opacity-40">{badge.icon || '⭐'}</span>
                    <Badge className="text-[10px] bg-white/5 text-white/20 border-white/10">
                      {badge.isAutomatic ? 'Locked' : 'Admin Award'}
                    </Badge>
                  </div>
                  <h3 className="text-sm font-semibold text-white/50 mb-1">{badge.name}</h3>
                  {badge.description && (
                    <p className="text-[12px] text-white/25 mb-2">{badge.description}</p>
                  )}
                  <p className="text-[11px] text-white/30 italic">
                    🔒 {getCriteriaLabel(badge)}
                  </p>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Empty state */}
        {allBadges.length === 0 && (
          <div className="text-center py-20">
            <Award className="w-16 h-16 text-white/10 mx-auto mb-4" />
            <p className="text-white/30 text-lg mb-2">No badges available</p>
            <p className="text-white/20 text-sm">Check back soon for new achievements!</p>
          </div>
        )}

        <div className="text-center mt-6">
          <Link href="/profile">
            <Button variant="outline" className="border-white/10 text-white/40 hover:text-white hover:border-white/20 gap-2">
              View Your Profile <ChevronRight className="w-4 h-4" />
            </Button>
          </Link>
        </div>
      </div>

      <Footer />
    </div>
  )
}
