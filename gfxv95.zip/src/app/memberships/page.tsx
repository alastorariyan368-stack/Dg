'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Crown, Check, Loader2 } from 'lucide-react'
import { toast } from 'sonner'

interface Membership {
  id: string
  name: string
  roleName: string
  description: string
  price: number
  features: string[]
  color: string
  isActive: boolean
  sortOrder: number
}

export default function MembershipsPage() {
  const { data: session } = useSession()
  const [memberships, setMemberships] = useState<Membership[]>([])
  const [loading, setLoading] = useState(true)
  const [purchasing, setPurchasing] = useState<string | null>(null)
  const [userRole, setUserRole] = useState<string>('')

  useEffect(() => {
    fetchMemberships()
    if (session?.user) {
      setUserRole(session.user.role || '')
    }
  }, [session])

  const fetchMemberships = async () => {
    try {
      const res = await fetch('/api/memberships')
      if (res.ok) {
        const data = await res.json()
        setMemberships(Array.isArray(data) ? data : [])
      }
    } catch (error) {
      console.error('Error fetching memberships:', error)
      toast.error('Failed to load memberships')
    } finally {
      setLoading(false)
    }
  }

  const handlePurchase = async (membershipId: string) => {
    if (!session?.user?.id) {
      toast.error('Please sign in to purchase a membership')
      return
    }

    setPurchasing(membershipId)
    try {
      const res = await fetch('/api/memberships/purchase', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ membershipId })
      })

      const data = await res.json()

      if (res.ok) {
        toast.success(data.message || 'Membership purchased successfully!')
        setUserRole(data.newRole)
        // Refresh to show updated state
        setTimeout(() => window.location.reload(), 1500)
      } else {
        toast.error(data.error || 'Failed to purchase membership')
      }
    } catch (error) {
      console.error('Error purchasing membership:', error)
      toast.error('An error occurred while purchasing')
    } finally {
      setPurchasing(null)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center">
          <Loader2 className="w-8 h-8 animate-spin text-purple-500" />
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] flex flex-col">
      <Navbar />

      <main className="flex-1 container mx-auto px-4 py-12">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-white mb-4 flex items-center justify-center gap-3">
            <Crown className="w-10 h-10 text-yellow-500" />
            Membership Plans
          </h1>
          <p className="text-white/60 max-w-2xl mx-auto">
            Upgrade your account and unlock exclusive features and benefits
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {memberships.map((membership) => {
            const isCurrentRole = userRole === membership.roleName
            const features: string[] = Array.isArray(membership.features)
              ? membership.features
              : typeof membership.features === 'string'
              ? JSON.parse(membership.features)
              : []

            return (
              <Card
                key={membership.id}
                className={`relative border-2 transition-all ${
                  isCurrentRole
                    ? 'border-green-500 bg-green-500/5'
                    : 'border-white/10 hover:border-white/20'
                }`}
              >
                {isCurrentRole && (
                  <div className="absolute top-4 right-4 bg-green-500 text-white px-3 py-1 rounded-full text-sm font-medium">
                    Current
                  </div>
                )}

                <CardHeader>
                  <CardTitle className="text-2xl text-white">{membership.name}</CardTitle>
                  <CardDescription className="text-white/60">
                    {membership.description}
                  </CardDescription>
                  <div className="mt-4">
                    <span className="text-4xl font-bold text-white">
                      ৳{membership.price.toFixed(2)}
                    </span>
                    <span className="text-white/40 ml-2">/ one-time</span>
                  </div>
                </CardHeader>

                <CardContent className="space-y-6">
                  <div className="space-y-3">
                    {features.map((feature, idx) => (
                      <div key={idx} className="flex items-start gap-3">
                        <Check className="w-5 h-5 text-green-500 flex-shrink-0 mt-0.5" />
                        <span className="text-white/80">{feature}</span>
                      </div>
                    ))}
                  </div>

                  {!session?.user ? (
                    <Button
                      disabled
                      className="w-full"
                      variant="outline"
                    >
                      Sign in to purchase
                    </Button>
                  ) : isCurrentRole ? (
                    <Button
                      disabled
                      className="w-full bg-green-500/20 border-green-500 text-green-400"
                      variant="outline"
                    >
                      ✓ Your current plan
                    </Button>
                  ) : (
                    <Button
                      onClick={() => handlePurchase(membership.id)}
                      disabled={purchasing === membership.id}
                      className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white"
                    >
                      {purchasing === membership.id ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin mr-2" />
                          Purchasing...
                        </>
                      ) : (
                        <>
                          <Crown className="w-4 h-4 mr-2" />
                          Upgrade Now
                        </>
                      )}
                    </Button>
                  )}
                </CardContent>
              </Card>
            )
          })}
        </div>

        {memberships.length === 0 && (
          <div className="text-center py-12">
            <p className="text-white/40">No membership plans available</p>
          </div>
        )}
      </main>

      <Footer />
    </div>
  )
}
