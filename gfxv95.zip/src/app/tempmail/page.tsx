'use client'
import { useState, useEffect, useRef, useCallback } from 'react'
import { Mail, RefreshCw, Trash2, Copy, Check, Clock, Inbox, ChevronLeft, Zap } from 'lucide-react'

interface Message {
  id: string; fromAddress: string; fromName?: string
  subject: string; isRead: boolean; receivedAt: string
}
interface InboxData {
  id: string; address: string; token: string; expiresAt: string
  expired: boolean; messageCount: number; unreadCount: number; messages: Message[]
}
interface FullMessage extends Message { bodyText: string; bodyHtml: string }

function timeLeft(expiresAt: string) {
  const diff = new Date(expiresAt).getTime() - Date.now()
  if (diff <= 0) return 'Expired'
  const m = Math.floor(diff / 60000)
  const s = Math.floor((diff % 60000) / 1000)
  return m > 0 ? `${m}m ${s}s` : `${s}s`
}

function timeAgo(date: string) {
  const diff = Date.now() - new Date(date).getTime()
  if (diff < 60000) return 'just now'
  if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`
  return `${Math.floor(diff / 3600000)}h ago`
}

export default function TempMailPage() {
  const [inbox, setInbox] = useState<InboxData | null>(null)
  const [generating, setGenerating] = useState(false)
  const [refreshing, setRefreshing] = useState(false)
  const [selectedMsg, setSelectedMsg] = useState<FullMessage | null>(null)
  const [copied, setCopied] = useState(false)
  const [timer, setTimer] = useState('')
  const tokenRef = useRef<string | null>(null)
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null)

  const copyAddress = () => {
    if (!inbox) return
    navigator.clipboard.writeText(inbox.address)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const loadInbox = useCallback(async (token: string, quiet = false) => {
    if (!quiet) setRefreshing(true)
    const r = await fetch(`/api/tempmail/inbox/${token}`)
    if (r.ok) {
      const data = await r.json()
      setInbox(data)
    }
    setRefreshing(false)
  }, [])

  const generate = async () => {
    setGenerating(true)
    setSelectedMsg(null)
    const r = await fetch('/api/tempmail/generate', { method: 'POST' })
    const data = await r.json()
    if (!r.ok) { alert(data.error); setGenerating(false); return }
    setInbox({ ...data, messageCount: 0, unreadCount: 0, messages: [], expired: false })
    tokenRef.current = data.token
    localStorage.setItem('tempmail_token', data.token)
    setGenerating(false)
  }

  const deleteInbox = async () => {
    if (!inbox || !confirm('Delete this inbox?')) return
    await fetch(`/api/tempmail/inbox/${inbox.token}`, { method: 'DELETE' })
    setInbox(null)
    setSelectedMsg(null)
    tokenRef.current = null
    localStorage.removeItem('tempmail_token')
    if (intervalRef.current) clearInterval(intervalRef.current)
  }

  const openMessage = async (msgId: string) => {
    if (!inbox) return
    const r = await fetch(`/api/tempmail/message/${msgId}?token=${inbox.token}`)
    if (r.ok) {
      const data = await r.json()
      setSelectedMsg(data)
      setInbox(prev => prev ? { ...prev, messages: prev.messages.map(m => m.id === msgId ? { ...m, isRead: true } : m), unreadCount: Math.max(0, prev.unreadCount - 1) } : prev)
    }
  }

  const deleteMessage = async (msgId: string) => {
    if (!inbox) return
    await fetch(`/api/tempmail/message/${msgId}?token=${inbox.token}`, { method: 'DELETE' })
    setSelectedMsg(null)
    loadInbox(inbox.token)
  }

  // Restore from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('tempmail_token')
    if (saved) { tokenRef.current = saved; loadInbox(saved) }
  }, [loadInbox])

  // Auto-refresh every 8s
  useEffect(() => {
    if (!inbox?.token || inbox.expired) return
    intervalRef.current = setInterval(() => loadInbox(inbox.token, true), 8000)
    return () => { if (intervalRef.current) clearInterval(intervalRef.current) }
  }, [inbox?.token, inbox?.expired, loadInbox])

  // Countdown timer
  useEffect(() => {
    if (!inbox) return
    const t = setInterval(() => setTimer(timeLeft(inbox.expiresAt)), 1000)
    return () => clearInterval(t)
  }, [inbox?.expiresAt])

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      {/* Hero */}
      <div className="bg-gradient-to-b from-blue-950/50 to-gray-950 py-12 px-4 text-center">
        <div className="inline-flex items-center gap-2 bg-blue-500/10 border border-blue-500/30 rounded-full px-4 py-1.5 text-blue-400 text-sm mb-4">
          <Zap className="w-3.5 h-3.5" /> Disposable Email
        </div>
        <h1 className="text-4xl font-bold mb-3 bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
          Temp Mail
        </h1>
        <p className="text-gray-400 max-w-md mx-auto text-sm">
          Generate a disposable email instantly. No signup needed. Receive emails in real-time.
        </p>
      </div>

      <div className="max-w-4xl mx-auto px-4 pb-16">
        {!inbox ? (
          <div className="flex flex-col items-center gap-6 py-12">
            <button
              onClick={generate}
              disabled={generating}
              className="flex items-center gap-3 px-8 py-4 bg-blue-600 hover:bg-blue-500 disabled:opacity-50 rounded-2xl text-lg font-semibold transition-all shadow-lg shadow-blue-500/20 hover:shadow-blue-500/40"
            >
              <Mail className="w-5 h-5" />
              {generating ? 'Generating...' : 'Generate Email Address'}
            </button>
            <p className="text-gray-600 text-sm">Valid for 1 hour · No registration required</p>
          </div>
        ) : (
          <div className="mt-6 space-y-4">
            {/* Inbox Card */}
            <div className={`rounded-2xl p-5 border ${inbox.expired ? 'border-red-500/30 bg-red-950/20' : 'border-blue-500/30 bg-blue-950/20'}`}>
              <div className="flex items-start gap-4">
                <div className="flex-1 min-w-0">
                  <div className="text-xs text-gray-400 mb-1">Your temporary email</div>
                  <div className="flex items-center gap-2">
                    <span className="text-xl font-mono font-bold truncate">{inbox.address}</span>
                    <button onClick={copyAddress} className="shrink-0 p-1.5 rounded-lg bg-white/5 hover:bg-white/10 transition">
                      {copied ? <Check className="w-4 h-4 text-green-400" /> : <Copy className="w-4 h-4 text-gray-400" />}
                    </button>
                  </div>
                  <div className="flex items-center gap-4 mt-2 text-xs text-gray-500">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {inbox.expired ? <span className="text-red-400">Expired</span> : <span className="text-green-400">{timer} left</span>}
                    </span>
                    <span className="flex items-center gap-1">
                      <Inbox className="w-3 h-3" />
                      {inbox.messageCount} message{inbox.messageCount !== 1 ? 's' : ''}
                      {inbox.unreadCount > 0 && <span className="ml-1 bg-blue-500 text-white rounded-full px-1.5 py-0.5 text-[10px]">{inbox.unreadCount} new</span>}
                    </span>
                  </div>
                </div>
                <div className="flex gap-2 shrink-0">
                  <button onClick={() => loadInbox(inbox.token)} disabled={refreshing} className="p-2 rounded-lg bg-white/5 hover:bg-white/10 transition">
                    <RefreshCw className={`w-4 h-4 ${refreshing ? 'animate-spin' : ''}`} />
                  </button>
                  <button onClick={generate} disabled={generating} className="px-3 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-xs font-medium transition" title="Generate new">
                    New
                  </button>
                  <button onClick={deleteInbox} className="p-2 rounded-lg hover:bg-red-500/20 text-red-400 transition">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Message List */}
              <div className="bg-white/5 rounded-2xl border border-white/10 overflow-hidden">
                <div className="px-4 py-3 border-b border-white/10 flex items-center justify-between">
                  <span className="font-semibold text-sm">Inbox</span>
                  {refreshing && <RefreshCw className="w-3 h-3 animate-spin text-gray-500" />}
                </div>
                {inbox.messages.length === 0 ? (
                  <div className="flex flex-col items-center py-12 text-gray-600">
                    <Mail className="w-8 h-8 mb-2 opacity-30" />
                    <p className="text-sm">Waiting for emails...</p>
                    <p className="text-xs mt-1 text-gray-700">Auto-refreshes every 8 seconds</p>
                  </div>
                ) : (
                  <div className="divide-y divide-white/5">
                    {inbox.messages.map(msg => (
                      <button key={msg.id} onClick={() => openMessage(msg.id)}
                        className={`w-full text-left px-4 py-3 hover:bg-white/5 transition ${selectedMsg?.id === msg.id ? 'bg-blue-500/10' : ''}`}>
                        <div className="flex items-start gap-2">
                          <div className={`w-2 h-2 rounded-full mt-1.5 shrink-0 ${msg.isRead ? 'bg-gray-600' : 'bg-blue-400'}`} />
                          <div className="min-w-0 flex-1">
                            <div className={`text-sm truncate ${msg.isRead ? 'text-gray-400' : 'text-white font-medium'}`}>{msg.subject}</div>
                            <div className="text-xs text-gray-500 truncate">{msg.fromName ? `${msg.fromName} <${msg.fromAddress}>` : msg.fromAddress}</div>
                            <div className="text-xs text-gray-600 mt-0.5">{timeAgo(msg.receivedAt)}</div>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Message Viewer */}
              <div className="bg-white/5 rounded-2xl border border-white/10 overflow-hidden">
                <div className="px-4 py-3 border-b border-white/10 flex items-center gap-2">
                  {selectedMsg && (
                    <button onClick={() => setSelectedMsg(null)} className="p-1 rounded hover:bg-white/10 mr-1">
                      <ChevronLeft className="w-4 h-4" />
                    </button>
                  )}
                  <span className="font-semibold text-sm flex-1 truncate">
                    {selectedMsg ? selectedMsg.subject : 'Select a message'}
                  </span>
                  {selectedMsg && (
                    <button onClick={() => deleteMessage(selectedMsg.id)} className="p-1.5 rounded hover:bg-red-500/20 text-red-400">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
                {!selectedMsg ? (
                  <div className="flex flex-col items-center py-16 text-gray-600">
                    <Mail className="w-8 h-8 mb-2 opacity-20" />
                    <p className="text-sm">Click a message to read</p>
                  </div>
                ) : (
                  <div className="p-4 overflow-auto max-h-80">
                    <div className="mb-4 pb-4 border-b border-white/10">
                      <div className="text-xs text-gray-500 space-y-1">
                        <div><span className="text-gray-400">From:</span> {selectedMsg.fromName ? `${selectedMsg.fromName} <${selectedMsg.fromAddress}>` : selectedMsg.fromAddress}</div>
                        <div><span className="text-gray-400">Time:</span> {new Date(selectedMsg.receivedAt).toLocaleString()}</div>
                      </div>
                    </div>
                    {selectedMsg.bodyHtml ? (
                      <div className="text-sm prose prose-invert prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: selectedMsg.bodyHtml }} />
                    ) : (
                      <pre className="text-sm text-gray-300 whitespace-pre-wrap font-sans">{selectedMsg.bodyText}</pre>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
