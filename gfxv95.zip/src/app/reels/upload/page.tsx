'use client'

import { useState, useEffect, useRef } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Upload, Image as ImageIcon, X, Loader2, Film, Link2, CheckCircle, Play, ArrowLeft } from 'lucide-react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'
import Link from 'next/link'
import { generateAndUploadThumbnail, getVideoDuration } from '@/lib/video-thumbnail'

const CATEGORIES = ['General', 'Gaming', 'Tech', 'Tutorial', 'Entertainment', 'Music', 'Education', 'Sports', 'Other']

export default function ReelUploadPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [thumbnailPreview, setThumbnailPreview] = useState<string | null>(null)
  const [uploadingThumb, setUploadingThumb] = useState(false)
  const [uploadingVideo, setUploadingVideo] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [uploadMode, setUploadMode] = useState<'file' | 'url'>('file')
  const videoInputRef = useRef<HTMLInputElement>(null)

  const [form, setForm] = useState({
    title: '',
    description: '',
    videoUrl: '',
    thumbnail: '',
    category: 'Entertainment',
    tags: '',
    duration: '',
    type: 'reel',
  })

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin?callbackUrl=/reels/upload')
  }, [status, router])

  const handleThumbnailUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    setUploadingThumb(true)
    try {
      const fd = new FormData()
      fd.append('file', file)
      fd.append('type', 'general')
      const res = await fetch('/api/upload', { method: 'POST', body: fd })
      if (res.ok) {
        const data = await res.json()
        setForm(f => ({ ...f, thumbnail: data.url }))
        setThumbnailPreview(data.url)
        toast.success('Cover uploaded!')
      } else {
        const err = await res.json().catch(() => ({}))
        toast.error(err.error || 'Cover upload failed')
      }
    } catch { toast.error('Upload error') }
    setUploadingThumb(false)
  }

  const handleVideoFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return
    if (!file.type.startsWith('video/')) { toast.error('Please pick a video file'); return }

    try {
      const dur = await getVideoDuration(file)
      if (dur > 0) setForm(f => f.duration ? f : { ...f, duration: String(dur) })
    } catch {}

    if (!form.thumbnail) {
      try {
        setUploadingThumb(true)
        const t = await generateAndUploadThumbnail(file)
        if (t) { setForm(f => f.thumbnail ? f : { ...f, thumbnail: t }); setThumbnailPreview(prev => prev || t) }
      } catch {} finally { setUploadingThumb(false) }
    }

    setUploadingVideo(true); setUploadProgress(0)
    try {
      await new Promise<void>((resolve, reject) => {
        const fd = new FormData()
        fd.append('file', file)
        fd.append('type', 'video')
        const xhr = new XMLHttpRequest()
        xhr.upload.onprogress = (ev) => {
          if (ev.lengthComputable) setUploadProgress(Math.round((ev.loaded / ev.total) * 90))
        }
        xhr.onload = () => {
          if (xhr.status === 200) {
            const data = JSON.parse(xhr.responseText)
            setForm(f => ({ ...f, videoUrl: data.url }))
            setUploadProgress(100)
            toast.success('Reel uploaded!')
            resolve()
          } else {
            try { reject(new Error(JSON.parse(xhr.responseText).error || 'Upload failed')) }
            catch { reject(new Error('Upload failed')) }
          }
        }
        xhr.onerror = () => reject(new Error('Network error'))
        xhr.open('POST', '/api/upload')
        xhr.send(fd)
      })
    } catch (err: any) {
      toast.error(err.message || 'Reel upload failed')
      setUploadProgress(0)
    }
    setUploadingVideo(false)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!form.title.trim()) { toast.error('Give your reel a title'); return }
    if (!form.videoUrl.trim()) { toast.error('Add a reel video first'); return }
    setLoading(true)
    try {
      const tags = form.tags.split(',').map(t => t.trim()).filter(Boolean)
      const res = await fetch('/api/videos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, type: 'reel', tags, duration: form.duration ? parseInt(form.duration) : null }),
      })
      if (res.ok) {
        const data = await res.json()
        toast.success('Reel published successfully!')
        setTimeout(() => router.push('/reels'), 1000)
      } else {
        const err = await res.json().catch(() => ({}))
        toast.error(err.error || 'Failed to upload reel')
      }
    } catch { toast.error('Error submitting') }
    setLoading(false)
  }

  if (status === 'loading') return null

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      <main className="container mx-auto px-4 py-6 max-w-2xl">
        <Link href="/reels" className="inline-flex items-center gap-2 text-white/50 hover:text-white text-sm mb-4">
          <ArrowLeft className="w-4 h-4" /> Back to Reels
        </Link>

        <div className="mb-6">
          <h1 className="text-2xl sm:text-3xl font-bold flex items-center gap-3">
            <span className="p-2 bg-gradient-to-br from-pink-600 to-violet-600 rounded-lg flex-shrink-0 shadow-lg shadow-pink-600/30">
              <Play className="w-5 h-5 sm:w-6 sm:h-6 fill-white" />
            </span>
            Upload Reel
          </h1>
          <p className="text-white/50 mt-1 text-sm">Short vertical video (9:16). Goes live immediately!</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Vertical preview + upload */}
          <div className="bg-white/5 rounded-2xl p-5 border border-white/10">
            <h2 className="font-semibold mb-3">Reel Video <span className="text-pink-400 text-sm">*</span></h2>

            <div className="flex rounded-xl overflow-hidden border border-white/10 mb-3">
              <button type="button" onClick={() => setUploadMode('file')}
                className={`flex-1 py-2.5 text-sm font-medium transition-all flex items-center justify-center gap-2 ${uploadMode === 'file' ? 'bg-gradient-to-r from-pink-600 to-violet-600 text-white' : 'bg-white/5 text-white/50 hover:bg-white/10'}`}>
                <Film className="w-4 h-4" /> Upload File
              </button>
              <button type="button" onClick={() => setUploadMode('url')}
                className={`flex-1 py-2.5 text-sm font-medium transition-all flex items-center justify-center gap-2 ${uploadMode === 'url' ? 'bg-gradient-to-r from-pink-600 to-violet-600 text-white' : 'bg-white/5 text-white/50 hover:bg-white/10'}`}>
                <Link2 className="w-4 h-4" /> Paste URL
              </button>
            </div>

            {uploadMode === 'file' ? (
              <>
                <input ref={videoInputRef} type="file" accept="video/*,.mp4,.mov,.webm" className="hidden" onChange={handleVideoFileUpload} />
                {form.videoUrl ? (
                  <div className="flex items-center gap-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-3">
                    <CheckCircle className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-emerald-400 font-medium">Reel uploaded</p>
                      <p className="text-xs text-white/40 truncate">{form.videoUrl}</p>
                    </div>
                    <button type="button" onClick={() => { setForm(f => ({ ...f, videoUrl: '' })); setUploadProgress(0) }} className="text-white/40 hover:text-white p-1"><X className="w-4 h-4" /></button>
                  </div>
                ) : uploadingVideo ? (
                  <div className="bg-white/5 border border-white/10 rounded-xl p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Loader2 className="w-4 h-4 text-pink-400 animate-spin" />
                      <span className="text-sm text-white/70">Uploading… {uploadProgress}%</span>
                    </div>
                    <div className="w-full bg-white/10 rounded-full h-2">
                      <div className="bg-gradient-to-r from-pink-500 to-violet-500 h-2 rounded-full transition-all" style={{ width: `${uploadProgress}%` }} />
                    </div>
                  </div>
                ) : (
                  <button type="button" onClick={() => videoInputRef.current?.click()}
                    className="w-full flex flex-col items-center justify-center py-10 rounded-xl border-2 border-dashed border-white/20 hover:border-pink-400 hover:bg-pink-500/5 transition-all">
                    <Film className="w-10 h-10 text-white/20 mb-2" />
                    <p className="text-white/60 font-medium">Tap to choose your reel</p>
                    <p className="text-white/30 text-xs mt-1">Vertical 9:16 works best · MP4, MOV, WebM</p>
                  </button>
                )}
              </>
            ) : (
              <div>
                <Input value={form.videoUrl} onChange={e => setForm(f => ({ ...f, videoUrl: e.target.value }))}
                  placeholder="https://… direct mp4 or video URL"
                  className="bg-white/5 border-white/10 text-white placeholder:text-white/30 text-base" />
                <p className="text-xs text-white/30 mt-1">Direct video URL only. Vertical 9:16 recommended.</p>
              </div>
            )}
          </div>

          {/* Info */}
          <div className="bg-white/5 rounded-2xl p-5 border border-white/10 space-y-4">
            <h2 className="font-semibold">Reel Info</h2>
            <div>
              <Label className="text-white/70 mb-1.5 block text-sm">Title <span className="text-pink-400">*</span></Label>
              <Input value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
                placeholder="A catchy title (max 100 chars)" maxLength={100}
                className="bg-white/5 border-white/10 text-white placeholder:text-white/30 text-base" />
            </div>
            <div>
              <Label className="text-white/70 mb-1.5 block text-sm">Caption</Label>
              <Textarea value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
                placeholder="Tell viewers what your reel is about…"
                className="bg-white/5 border-white/10 text-white placeholder:text-white/30 min-h-[80px] text-base" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-white/70 mb-1.5 block text-sm">Category</Label>
                <Select value={form.category} onValueChange={v => setForm(f => ({ ...f, category: v }))}>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white text-sm"><SelectValue /></SelectTrigger>
                  <SelectContent className="bg-[#1a1a2e] border-white/10 text-white">
                    {CATEGORIES.map(c => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-white/70 mb-1.5 block text-sm">Duration (sec)</Label>
                <Input value={form.duration} onChange={e => setForm(f => ({ ...f, duration: e.target.value }))}
                  placeholder="e.g. 30" type="number" min="0" max="180"
                  className="bg-white/5 border-white/10 text-white placeholder:text-white/30 text-sm" />
              </div>
            </div>
            <div>
              <Label className="text-white/70 mb-1.5 block text-sm">Tags (comma separated)</Label>
              <Input value={form.tags} onChange={e => setForm(f => ({ ...f, tags: e.target.value }))}
                placeholder="funny, viral, trending"
                className="bg-white/5 border-white/10 text-white placeholder:text-white/30 text-base" />
            </div>
          </div>

          {/* Cover */}
          <div className="bg-white/5 rounded-2xl p-5 border border-white/10">
            <h2 className="font-semibold mb-1">Cover Image <span className="text-white/40 text-xs font-normal">(optional)</span></h2>
            <p className="text-xs text-white/40 mb-3">Auto-generated from your video. Upload your own to override.</p>
            <label className="flex flex-col items-center justify-center w-full max-w-[220px] mx-auto aspect-[9/16] rounded-xl border-2 border-dashed border-white/20 cursor-pointer hover:border-pink-400 hover:bg-white/5 transition-all overflow-hidden">
              {uploadingThumb ? (
                <Loader2 className="w-8 h-8 text-white/40 animate-spin" />
              ) : thumbnailPreview ? (
                <img src={thumbnailPreview} alt="Cover" className="w-full h-full object-cover" />
              ) : (
                <div className="flex flex-col items-center text-white/30 py-6 px-3 text-center">
                  <ImageIcon className="w-8 h-8 mb-2" />
                  <span className="text-sm font-medium">Add cover</span>
                  <span className="text-xs mt-1">Vertical 9:16</span>
                </div>
              )}
              <input type="file" className="hidden" accept="image/*" onChange={handleThumbnailUpload} />
            </label>
            {thumbnailPreview && (
              <button type="button" onClick={() => { setThumbnailPreview(null); setForm(f => ({ ...f, thumbnail: '' })) }}
                className="mt-2 mx-auto text-xs text-white/30 hover:text-white flex items-center gap-1">
                <X className="w-3 h-3" /> Remove cover
              </button>
            )}
          </div>

          {/* Submit */}
          <div className="flex flex-col sm:flex-row gap-3">
            <Button type="submit" disabled={loading || uploadingVideo} className="bg-gradient-to-r from-pink-600 to-violet-600 hover:from-pink-500 hover:to-violet-500 flex-1 h-12 text-base">
              {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Submitting…</> : <><Upload className="w-4 h-4 mr-2" /> Submit Reel</>}
            </Button>
            <Link href="/reels" className="w-full sm:w-auto">
              <Button type="button" variant="outline" className="border-white/20 hover:bg-white/10 h-12 w-full">Cancel</Button>
            </Link>
          </div>
          <p className="text-xs text-white/30 text-center">Reel will be published after admin review</p>
        </form>
      </main>
      <Footer />
    </div>
  )
}
