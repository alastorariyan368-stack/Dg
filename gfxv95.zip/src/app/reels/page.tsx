'use client'

import { useState, useEffect, useRef, useCallback } from 'react'
import { Navbar } from '@/components/navbar'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Sheet, SheetContent, SheetHeader, SheetTitle } from '@/components/ui/sheet'
import { Input } from '@/components/ui/input'
import {
  Play, Pause, Upload, Heart, MessageCircle, Share2,
  Volume2, VolumeX, Music2, Video as VideoIcon, ChevronUp, ChevronDown, Send, X, Plus
} from 'lucide-react'
import Link from 'next/link'
import { useSession } from 'next-auth/react'
import { toast } from 'sonner'
import { formatDistanceToNow } from 'date-fns'

interface Reel {
  id: string
  title: string
  description?: string
  thumbnail?: string
  videoUrl: string
  duration?: number
  views: number
  likes: number
  category: string
  tags: any[]
  createdAt: string
  author: { id: string; username: string; avatar?: string; isVerified: boolean }
  _count?: { comments: number; videoLikes: number }
}

function formatViews(n: number) {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`
  return String(n || 0)
}

function ReelCard({
  reel,
  isActive,
  muted,
  onToggleMute,
  onLike,
  liked,
  likes,
  onOpenComments,
  commentCount,
}: {
  reel: Reel
  isActive: boolean
  muted: boolean
  onToggleMute: () => void
  onLike: () => void
  liked: boolean
  likes: number
  onOpenComments: () => void
  commentCount: number
}) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [showOverlay, setShowOverlay] = useState(false)

  useEffect(() => {
    const v = videoRef.current
    if (!v) return
    if (isActive) {
      v.currentTime = 0
      v.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false))
    } else {
      v.pause()
      setIsPlaying(false)
    }
  }, [isActive])

  useEffect(() => {
    const v = videoRef.current
    if (v) v.muted = muted
  }, [muted])

  const togglePlay = () => {
    const v = videoRef.current
    if (!v) return
    if (v.paused) {
      v.play().then(() => setIsPlaying(true)).catch(() => {})
    } else {
      v.pause()
      setIsPlaying(false)
    }
    setShowOverlay(true)
    window.setTimeout(() => setShowOverlay(false), 600)
  }

  const handleShare = async () => {
    const url = `${window.location.origin}/videos/${reel.id}`
    try {
      if (navigator.share) {
        await navigator.share({ title: reel.title, url })
      } else {
        await navigator.clipboard.writeText(url)
        toast.success('Link copied to clipboard')
      }
    } catch {}
  }

  return (
    <div
      className="relative w-full flex items-center justify-center bg-black"
      style={{ height: 'var(--reel-h, calc(100dvh - 64px))' }}
    >
      {/* Phone-frame card: full-width on mobile, max 420px centered on desktop */}
      <div
        className="relative w-full h-full md:w-auto md:h-full overflow-hidden bg-black"
        style={{ maxWidth: 'min(100vw, 420px)', aspectRatio: undefined }}
      >
        {/* Video */}
        <video
          ref={videoRef}
          src={reel.videoUrl}
          poster={reel.thumbnail}
          className="absolute inset-0 w-full h-full object-cover"
          loop
          playsInline
          preload="metadata"
          onClick={togglePlay}
        />

        {/* Tap-to-pause overlay */}
        {showOverlay && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-20">
            <div className="w-20 h-20 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center animate-in fade-in zoom-in duration-200">
              {isPlaying
                ? <Play className="w-9 h-9 text-white fill-white ml-1" />
                : <Pause className="w-9 h-9 text-white fill-white" />}
            </div>
          </div>
        )}

        {/* Top gradient bar */}
        <div className="absolute top-0 left-0 right-0 px-4 pt-4 pb-8 flex items-center justify-between bg-gradient-to-b from-black/70 via-black/20 to-transparent z-10">
          <span className="text-white font-bold text-base tracking-wide drop-shadow">Reels</span>
          <button
            onClick={onToggleMute}
            className="w-9 h-9 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center text-white hover:bg-black/60 transition"
            aria-label={muted ? 'Unmute' : 'Mute'}
          >
            {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>
        </div>

        {/* Right-side action buttons */}
        <div className="absolute right-3 bottom-24 flex flex-col items-center gap-4 z-10">
          {/* Author avatar */}
          <Link href={`/profile/${reel.author.username}`} className="relative flex-shrink-0">
            <Avatar className="w-11 h-11 ring-2 ring-white shadow-lg">
              <AvatarImage src={reel.author.avatar} />
              <AvatarFallback className="bg-gradient-to-br from-violet-600 to-cyan-600 text-white text-sm font-bold">
                {reel.author.username?.[0]?.toUpperCase()}
              </AvatarFallback>
            </Avatar>
            <span className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 w-5 h-5 rounded-full bg-rose-500 text-white text-[10px] font-black flex items-center justify-center border-2 border-black shadow">+</span>
          </Link>

          {/* Like */}
          <button onClick={onLike} className="flex flex-col items-center gap-0.5 group">
            <div className={`w-11 h-11 rounded-full flex items-center justify-center transition-all ${liked ? 'bg-rose-500/20 scale-110' : 'bg-black/40 backdrop-blur-md group-hover:bg-black/60'}`}>
              <Heart className={`w-6 h-6 transition-all ${liked ? 'text-rose-400 fill-rose-400 scale-110' : 'text-white'}`} />
            </div>
            <span className="text-white text-[10px] font-bold drop-shadow mt-0.5">{formatViews(likes)}</span>
          </button>

          {/* Comment */}
          <button onClick={onOpenComments} className="flex flex-col items-center gap-0.5 group">
            <div className="w-11 h-11 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center group-hover:bg-black/60 transition">
              <MessageCircle className="w-6 h-6 text-white" />
            </div>
            <span className="text-white text-[10px] font-bold drop-shadow mt-0.5">{formatViews(commentCount)}</span>
          </button>

          {/* Share */}
          <button onClick={handleShare} className="flex flex-col items-center gap-0.5 group">
            <div className="w-11 h-11 rounded-full bg-black/40 backdrop-blur-md flex items-center justify-center group-hover:bg-black/60 transition">
              <Share2 className="w-5 h-5 text-white" />
            </div>
            <span className="text-white text-[10px] font-bold drop-shadow mt-0.5">Share</span>
          </button>

          {/* Spinning disc */}
          <div className="w-9 h-9 rounded-full overflow-hidden border-2 border-white/60 animate-spin" style={{ animationDuration: '4s' }}>
            {reel.thumbnail ? (
              <img src={reel.thumbnail} alt="" className="w-full h-full object-cover" />
            ) : (
              <div className="w-full h-full bg-gradient-to-br from-violet-500 to-cyan-500 flex items-center justify-center">
                <Music2 className="w-3.5 h-3.5 text-white" />
              </div>
            )}
          </div>
        </div>

        {/* Bottom info — leave room for the + button */}
        <div className="absolute left-0 right-16 bottom-0 px-4 pt-8 pb-16 bg-gradient-to-t from-black/90 via-black/50 to-transparent z-10 pointer-events-none">
          <Link href={`/profile/${reel.author.username}`} className="inline-flex items-center gap-1.5 text-white pointer-events-auto">
            <span className="font-bold text-sm drop-shadow">@{reel.author.username}</span>
            {reel.author.isVerified && (
              <span className="w-4 h-4 rounded-full bg-cyan-500 flex items-center justify-center text-[9px] font-black">✓</span>
            )}
          </Link>
          <h3 className="text-white text-sm mt-1 line-clamp-2 leading-snug drop-shadow">{reel.title}</h3>
          {reel.description && (
            <p className="text-white/70 text-xs mt-0.5 line-clamp-1">{reel.description}</p>
          )}
          <div className="flex items-center gap-1.5 mt-2 text-white/80 text-xs">
            <Music2 className="w-3 h-3 flex-shrink-0" />
            <span className="line-clamp-1 text-[11px]">Original sound · {reel.author.username}</span>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function ReelsPage() {
  const { data: session } = useSession()
  const [reels, setReels] = useState<Reel[]>([])
  const [loading, setLoading] = useState(true)
  const [activeIndex, setActiveIndex] = useState(0)
  const [muted, setMuted] = useState(true)
  const [likedMap, setLikedMap] = useState<Record<string, boolean>>({})
  const [likeCounts, setLikeCounts] = useState<Record<string, number>>({})
  const [commentCounts, setCommentCounts] = useState<Record<string, number>>({})
  const [commentsOpenFor, setCommentsOpenFor] = useState<Reel | null>(null)
  const [comments, setComments] = useState<any[]>([])
  const [commentsLoading, setCommentsLoading] = useState(false)
  const [newComment, setNewComment] = useState('')
  const [postingComment, setPostingComment] = useState(false)
  const containerRef = useRef<HTMLDivElement>(null)
  const itemRefs = useRef<Array<HTMLDivElement | null>>([])

  useEffect(() => {
    fetch('/api/videos?type=reel&limit=50')
      .then(r => r.ok ? r.json() : { videos: [] })
      .then(d => {
        const list: Reel[] = d.videos || []
        setReels(list)
        const counts: Record<string, number> = {}
        const cc: Record<string, number> = {}
        list.forEach(r => {
          counts[r.id] = r.likes || r._count?.videoLikes || 0
          cc[r.id] = r._count?.comments || 0
        })
        setLikeCounts(counts)
        setCommentCounts(cc)
      })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  useEffect(() => {
    if (!reels.length) return
    const obs = new IntersectionObserver(
      (entries) => {
        entries.forEach(entry => {
          if (entry.isIntersecting && entry.intersectionRatio >= 0.6) {
            const idx = Number((entry.target as HTMLElement).dataset.index)
            if (!Number.isNaN(idx)) setActiveIndex(idx)
          }
        })
      },
      { threshold: [0.6], root: containerRef.current }
    )
    itemRefs.current.forEach(el => el && obs.observe(el))
    return () => obs.disconnect()
  }, [reels])

  const handleLike = useCallback(async (reel: Reel) => {
    if (!session?.user) {
      toast.error('Please sign in to like reels')
      return
    }
    const wasLiked = !!likedMap[reel.id]
    setLikedMap(m => ({ ...m, [reel.id]: !wasLiked }))
    setLikeCounts(c => ({ ...c, [reel.id]: (c[reel.id] || 0) + (wasLiked ? -1 : 1) }))
    try {
      await fetch(`/api/videos/${reel.id}/like`, { method: 'POST' })
    } catch {}
  }, [session, likedMap])

  const scrollToIndex = (i: number) => {
    const el = itemRefs.current[i]
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' })
  }

  const openComments = useCallback(async (reel: Reel) => {
    setCommentsOpenFor(reel)
    setComments([])
    setCommentsLoading(true)
    try {
      const res = await fetch(`/api/videos/${reel.id}/comments?limit=50`)
      if (res.ok) {
        const d = await res.json()
        setComments(d.comments || [])
        setCommentCounts(c => ({ ...c, [reel.id]: d.total || (d.comments?.length || 0) }))
      }
    } catch {}
    setCommentsLoading(false)
  }, [])

  const submitComment = async () => {
    if (!commentsOpenFor) return
    if (!session?.user) { toast.error('Please sign in to comment'); return }
    const text = newComment.trim()
    if (!text) return
    setPostingComment(true)
    try {
      const res = await fetch(`/api/videos/${commentsOpenFor.id}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: text }),
      })
      if (res.ok) {
        const d = await res.json()
        const c = d.comment || d
        setComments(prev => [c, ...prev])
        setCommentCounts(cc => ({ ...cc, [commentsOpenFor.id]: (cc[commentsOpenFor.id] || 0) + 1 }))
        setNewComment('')
      } else {
        const err = await res.json().catch(() => ({}))
        toast.error(err.error || 'Failed to post comment')
      }
    } catch { toast.error('Failed to post comment') }
    setPostingComment(false)
  }

  if (loading) {
    return (
      <div className="h-screen overflow-hidden bg-black text-white flex flex-col">
        <Navbar />
        <div className="flex-1 flex items-center justify-center text-white/60">Loading reels…</div>
      </div>
    )
  }

  if (!reels.length) {
    return (
      <div className="h-screen overflow-hidden bg-black text-white flex flex-col">
        <Navbar />
        <div className="flex-1 flex flex-col items-center justify-center text-center px-4">
          <VideoIcon className="w-16 h-16 text-white/20 mb-4" />
          <h2 className="text-2xl font-semibold mb-2">No reels yet</h2>
          <p className="text-white/50 mb-6">Be the first to upload a short video.</p>
          {session && (
            <Link href="/reels/upload">
              <Button className="bg-gradient-to-r from-violet-600 to-cyan-600 text-white border-0 rounded-xl gap-2">
                <Upload className="w-4 h-4" /> Upload Reel
              </Button>
            </Link>
          )}
        </div>
      </div>
    )
  }

  return (
    <div
      className="h-screen overflow-hidden bg-black text-white flex flex-col"
      style={{ '--reel-h': 'calc(100dvh - 64px)' } as React.CSSProperties}
    >
      <Navbar />

      {/* Scroll container */}
      <div
        ref={containerRef}
        className="flex-1 min-h-0 w-full overflow-y-scroll bg-black"
        style={{
          scrollSnapType: 'y mandatory',
          overscrollBehavior: 'contain',
          WebkitOverflowScrolling: 'touch',
        }}
      >
        {reels.map((reel, i) => (
          <div
            key={reel.id}
            ref={el => { itemRefs.current[i] = el }}
            data-index={i}
            style={{ scrollSnapAlign: 'start', scrollSnapStop: 'always' }}
          >
            <ReelCard
              reel={reel}
              isActive={i === activeIndex}
              muted={muted}
              onToggleMute={() => setMuted(m => !m)}
              onLike={() => handleLike(reel)}
              liked={!!likedMap[reel.id]}
              likes={likeCounts[reel.id] ?? reel.likes ?? 0}
              onOpenComments={() => openComments(reel)}
              commentCount={commentCounts[reel.id] ?? reel._count?.comments ?? 0}
            />
          </div>
        ))}
      </div>

      {/* TikTok-style Create Reel button — fixed at the bottom center */}
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-30 flex flex-col items-center">
        <Link href="/reels/upload">
          <button
            className="relative flex items-center justify-center focus:outline-none group"
            aria-label="Create reel"
          >
            {/* Left half (cyan) */}
            <span
              className="absolute left-[-10px] w-[46px] h-[36px] rounded-l-lg bg-cyan-400 group-hover:bg-cyan-300 transition"
              style={{ borderRadius: '10px 0 0 10px' }}
            />
            {/* Right half (rose) */}
            <span
              className="absolute right-[-10px] w-[46px] h-[36px] bg-rose-500 group-hover:bg-rose-400 transition"
              style={{ borderRadius: '0 10px 10px 0' }}
            />
            {/* White center pill with + */}
            <span className="relative z-10 flex items-center justify-center w-[52px] h-[36px] bg-white rounded-lg shadow-xl">
              <Plus className="w-5 h-5 text-black font-black" strokeWidth={3} />
            </span>
          </button>
          <span className="text-white/70 text-[10px] font-semibold mt-1.5 text-center block drop-shadow">Create</span>
        </Link>
      </div>

      {/* Desktop nav arrows */}
      <div className="hidden md:flex flex-col gap-3 fixed right-6 top-1/2 -translate-y-1/2 z-20">
        <button
          onClick={() => scrollToIndex(Math.max(0, activeIndex - 1))}
          disabled={activeIndex === 0}
          className="w-11 h-11 rounded-full bg-white/10 backdrop-blur-md text-white hover:bg-white/20 disabled:opacity-30 transition flex items-center justify-center"
          aria-label="Previous"
        >
          <ChevronUp className="w-5 h-5" />
        </button>
        <button
          onClick={() => scrollToIndex(Math.min(reels.length - 1, activeIndex + 1))}
          disabled={activeIndex === reels.length - 1}
          className="w-11 h-11 rounded-full bg-white/10 backdrop-blur-md text-white hover:bg-white/20 disabled:opacity-30 transition flex items-center justify-center"
          aria-label="Next"
        >
          <ChevronDown className="w-5 h-5" />
        </button>
      </div>

      {/* Comments drawer */}
      <Sheet open={!!commentsOpenFor} onOpenChange={(o) => { if (!o) setCommentsOpenFor(null) }}>
        <SheetContent side="bottom" className="bg-[#0a0a12] border-t border-white/10 text-white p-0 h-[75vh] sm:h-[70vh] max-w-xl mx-auto sm:rounded-t-2xl flex flex-col">
          <SheetHeader className="px-4 py-3 border-b border-white/10 flex-row items-center justify-between space-y-0 flex-shrink-0">
            <SheetTitle className="text-white text-base font-semibold">
              Comments {commentsOpenFor ? `· ${commentCounts[commentsOpenFor.id] ?? 0}` : ''}
            </SheetTitle>
          </SheetHeader>
          <div className="flex-1 overflow-y-auto px-4 py-3 space-y-4">
            {commentsLoading && <div className="text-center text-white/40 text-sm py-6">Loading…</div>}
            {!commentsLoading && comments.length === 0 && (
              <div className="text-center text-white/40 text-sm py-10">Be the first to comment.</div>
            )}
            {comments.map((c: any) => (
              <div key={c.id} className="flex gap-3">
                <Avatar className="w-8 h-8 flex-shrink-0">
                  <AvatarImage src={c.author?.avatar} />
                  <AvatarFallback className="bg-gradient-to-br from-violet-600 to-cyan-600 text-white text-xs">
                    {c.author?.username?.[0]?.toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="flex items-baseline gap-2">
                    <span className="text-sm font-semibold text-white truncate">@{c.author?.username || 'user'}</span>
                    <span className="text-[10px] text-white/40">{c.createdAt ? formatDistanceToNow(new Date(c.createdAt), { addSuffix: true }) : ''}</span>
                  </div>
                  <p className="text-sm text-white/80 mt-0.5 break-words">{c.content}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="px-4 py-3 border-t border-white/10 flex gap-2 items-center bg-[#0a0a12] flex-shrink-0">
            <Input
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submitComment() } }}
              placeholder={session?.user ? 'Add a comment…' : 'Sign in to comment'}
              disabled={!session?.user || postingComment}
              className="bg-white/5 border-white/10 text-white placeholder:text-white/30"
            />
            <Button
              onClick={submitComment}
              disabled={!session?.user || postingComment || !newComment.trim()}
              size="sm"
              className="bg-gradient-to-r from-violet-600 to-cyan-600 text-white border-0"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </SheetContent>
      </Sheet>
    </div>
  )
}
