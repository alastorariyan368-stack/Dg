'use client'

import { useState } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { ImageIcon, FileImage, Loader2, Download, RefreshCw, Sparkles } from 'lucide-react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { toast } from 'sonner'

const STYLES = ['gaming', 'modern', 'retro', 'minimalist', 'neon', 'cinematic', 'anime']

export default function AIGeneratePage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [activeTab, setActiveTab] = useState<'image' | 'thumbnail'>('thumbnail')
  const [prompt, setPrompt] = useState('')
  const [thumbnailPrompt, setThumbnailPrompt] = useState('')
  const [thumbnailStyle, setThumbnailStyle] = useState('gaming')
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedUrl, setGeneratedUrl] = useState('')

  if (status === 'unauthenticated') {
    router.push('/auth/signin')
    return null
  }

  const generate = async (promptText: string, purpose: string) => {
    if (!promptText.trim()) return
    setIsGenerating(true)
    setGeneratedUrl('')
    try {
      const res = await fetch('/api/ai/generate/image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: promptText, purpose }),
      })
      const data = await res.json()
      if (res.ok && data.imageUrl) {
        setGeneratedUrl(data.imageUrl)
        toast.success('Image generated!')
      } else {
        toast.error(data.error || 'Generation failed')
      }
    } catch {
      toast.error('Connection error. Please try again.')
    } finally {
      setIsGenerating(false)
    }
  }

  const handleGenerateImage = () => generate(prompt, 'image')
  const handleGenerateThumbnail = () => {
    const full = `${thumbnailPrompt}. ${thumbnailStyle} style, high quality digital content thumbnail.`
    generate(full, 'thumbnail')
  }

  const downloadImage = async () => {
    if (!generatedUrl) return
    try {
      const response = await fetch(generatedUrl)
      const blob = await response.blob()
      const objectUrl = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = objectUrl
      a.download = `gfxstore-ai-${Date.now()}.png`
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(objectUrl)
      toast.success('Image downloaded!')
    } catch {
      window.open(generatedUrl, '_blank')
    }
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white flex flex-col">
      <Navbar />
      <div className="flex-1 container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 bg-purple-500/10 border border-purple-500/20 rounded-full px-4 py-1.5 mb-4">
            <Sparkles className="w-4 h-4 text-purple-400" />
            <span className="text-purple-300 text-sm font-medium">Powered by AI</span>
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">AI Image Generator</h1>
          <p className="text-white/50 text-sm">Create stunning images and thumbnails for your content</p>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 bg-white/5 p-1 rounded-xl w-fit mx-auto">
          {[
            { id: 'thumbnail', label: 'Thumbnail', icon: <FileImage className="w-4 h-4" /> },
            { id: 'image', label: 'Image', icon: <ImageIcon className="w-4 h-4" /> },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => { setActiveTab(tab.id as any); setGeneratedUrl('') }}
              className={`flex items-center gap-2 px-5 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === tab.id
                  ? 'bg-gradient-to-r from-purple-600 to-blue-600 text-white shadow-lg'
                  : 'text-white/50 hover:text-white hover:bg-white/5'
              }`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Input Panel */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6 space-y-4">
            <h2 className="text-base font-semibold text-white">
              {activeTab === 'thumbnail' ? 'Create Thumbnail' : 'Generate Image'}
            </h2>

            {activeTab === 'thumbnail' ? (
              <>
                <div className="space-y-1.5">
                  <label className="text-sm text-white/60">Content description</label>
                  <Textarea
                    placeholder="e.g. Modern minimalist landing page hero design"
                    value={thumbnailPrompt}
                    onChange={e => setThumbnailPrompt(e.target.value)}
                    rows={4}
                    className="bg-white/5 border-white/10 text-white placeholder:text-white/30 resize-none rounded-xl focus-visible:ring-purple-500/50"
                  />
                </div>
                <div className="space-y-1.5">
                  <label className="text-sm text-white/60">Style</label>
                  <div className="flex flex-wrap gap-2">
                    {STYLES.map(s => (
                      <button
                        key={s}
                        onClick={() => setThumbnailStyle(s)}
                        className={`px-3 py-1 rounded-lg text-xs font-medium capitalize transition-all border ${
                          thumbnailStyle === s
                            ? 'bg-purple-600 border-purple-500 text-white'
                            : 'bg-white/5 border-white/10 text-white/50 hover:text-white hover:bg-white/10'
                        }`}
                      >
                        {s}
                      </button>
                    ))}
                  </div>
                </div>
                <Button
                  onClick={handleGenerateThumbnail}
                  disabled={isGenerating || !thumbnailPrompt.trim()}
                  className="w-full h-11 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 border-0 rounded-xl text-white font-medium"
                >
                  {isGenerating
                    ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Generating…</>
                    : <><Sparkles className="w-4 h-4 mr-2" /> Generate Thumbnail</>}
                </Button>
              </>
            ) : (
              <>
                <div className="space-y-1.5">
                  <label className="text-sm text-white/60">Describe your image</label>
                  <Textarea
                    placeholder="e.g. Cinematic mountain sunset landscape, ultra detailed"
                    value={prompt}
                    onChange={e => setPrompt(e.target.value)}
                    rows={5}
                    className="bg-white/5 border-white/10 text-white placeholder:text-white/30 resize-none rounded-xl focus-visible:ring-purple-500/50"
                  />
                </div>
                <Button
                  onClick={handleGenerateImage}
                  disabled={isGenerating || !prompt.trim()}
                  className="w-full h-11 bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 border-0 rounded-xl text-white font-medium"
                >
                  {isGenerating
                    ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Generating…</>
                    : <><Sparkles className="w-4 h-4 mr-2" /> Generate Image</>}
                </Button>
              </>
            )}
          </div>

          {/* Output Panel */}
          <div className="bg-white/5 border border-white/10 rounded-2xl p-6 flex flex-col">
            <h2 className="text-base font-semibold text-white mb-4">Result</h2>

            <div className="flex-1 min-h-[280px] flex items-center justify-center">
              {isGenerating ? (
                <div className="text-center">
                  <div className="w-16 h-16 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center mx-auto mb-4">
                    <Loader2 className="w-7 h-7 text-purple-400 animate-spin" />
                  </div>
                  <p className="text-white/50 text-sm">Generating your image…</p>
                  <p className="text-white/30 text-xs mt-1">This may take 10–30 seconds</p>
                </div>
              ) : generatedUrl ? (
                <div className="w-full space-y-3">
                  <div className="relative rounded-xl overflow-hidden border border-white/10">
                    <img
                      src={generatedUrl}
                      alt="AI generated"
                      className="w-full h-auto block"
                    />
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={downloadImage}
                      className="flex-1 h-9 bg-green-600 hover:bg-green-500 border-0 text-white text-sm rounded-xl gap-2"
                    >
                      <Download className="w-3.5 h-3.5" /> Download
                    </Button>
                    <Button
                      onClick={() => {
                        setGeneratedUrl('')
                        if (activeTab === 'thumbnail') {
                          handleGenerateThumbnail()
                        } else {
                          handleGenerateImage()
                        }
                      }}
                      variant="outline"
                      className="h-9 border-white/10 text-white hover:bg-white/5 text-sm rounded-xl gap-2"
                    >
                      <RefreshCw className="w-3.5 h-3.5" /> Regenerate
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="text-center">
                  <div className="w-16 h-16 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center mx-auto mb-4">
                    <ImageIcon className="w-7 h-7 text-white/20" />
                  </div>
                  <p className="text-white/30 text-sm">Your generated image will appear here</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  )
}
