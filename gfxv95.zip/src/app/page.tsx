'use client'

import { useState, useEffect } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { ChatWidget } from '@/components/chat/chat-widget'
import { AnnouncementBanner } from '@/components/announcement-banner'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import {
  Download, Star, Users, Sparkles, Zap, ArrowRight,
  Check, Heart, ShoppingCart, Play, Crown,
  Video as VideoIcon, Smartphone, Code2, Upload, LayoutDashboard,
  ChevronLeft, ChevronRight, MessageSquare, Package, TrendingUp,
  Server, Shield, Globe, Rocket, Image as ImageIcon, Mic,
  Eye, MousePointer2, ExternalLink,
} from 'lucide-react'
import Link from 'next/link'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
function safeTimeAgo(dateVal: any): string {
  try {
    if (dateVal === null || dateVal === undefined || dateVal === '') return ''
    const d = new Date(dateVal)
    const t = d.getTime()
    if (!isFinite(t) || isNaN(t)) return ''
    const seconds = Math.floor((Date.now() - t) / 1000)
    if (seconds < 5) return 'just now'
    if (seconds < 60) return `${seconds}s ago`
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`
    if (seconds < 2592000) return `${Math.floor(seconds / 86400)}d ago`
    if (seconds < 31536000) return `${Math.floor(seconds / 2592000)}mo ago`
    return `${Math.floor(seconds / 31536000)}y ago`
  } catch { return '' }
}
import { useSession } from 'next-auth/react'
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel'
import { motion, AnimatePresence } from 'framer-motion'

interface Stats { totalUsers: number; totalItems: number; totalDownloads: number }
interface FeaturedItem {
  id: string; title: string; slug: string; shortDesc?: string
  downloads: number; likes: number; logo?: string; accessType?: string
  category: { name: string }; author: { username: string; avatar?: string }
}
interface MembershipPlan {
  id: string; name: string; roleName: string; description: string
  price: number; features: string[]; color: string; isActive: boolean; sortOrder: number
}

export default function Home() {
  const { data: session, status: sessionStatus } = useSession()
  const [mounted, setMounted] = useState(false)
  useEffect(() => { setMounted(true) }, [])
  const isAuthed = mounted && sessionStatus === 'authenticated' && !!session?.user
  const [isChatOpen, setIsChatOpen] = useState(false)
  const [stats, setStats] = useState<Stats>({ totalUsers: 0, totalItems: 0, totalDownloads: 0 })
  const [featuredItems, setFeaturedItems] = useState<FeaturedItem[]>([])
  const [memberships, setMemberships] = useState<MembershipPlan[]>([])
  const [latestApps, setLatestApps] = useState<any[]>([])
  const [latestCodes, setLatestCodes] = useState<any[]>([])
  const [latestVideos, setLatestVideos] = useState<any[]>([])
  const [latestReels, setLatestReels] = useState<any[]>([])
  const [latestItems, setLatestItems] = useState<any[]>([])
  const [announcements, setAnnouncements] = useState<any[]>([])
  const [homepageAds, setHomepageAds] = useState<any[]>([])
  const [userData, setUserData] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetch('/api/home-data').then(async res => {
      if (!res.ok) return
      const data = await res.json()
      if (data.stats) setStats(data.stats)
      if (data.featuredItems) setFeaturedItems(data.featuredItems)
      if (data.memberships) setMemberships((data.memberships as MembershipPlan[]).filter(m => m.isActive).sort((a, b) => a.sortOrder - b.sortOrder))
      if (data.latestApps) setLatestApps(data.latestApps)
      if (data.latestCodes) setLatestCodes(data.latestCodes)
      if (data.latestVideos) setLatestVideos(data.latestVideos)
      if (data.latestReels) setLatestReels(data.latestReels)
      if (data.latestItems) setLatestItems(data.latestItems)
      if (data.announcements) setAnnouncements(data.announcements)
      if (data.user) setUserData(data.user)
    }).catch(() => {})

    fetch('/api/ads?position=homepage').then(r => r.json()).then(d => {
      if (d.ads) setHomepageAds(d.ads)
    }).catch(() => {})

    .finally(() => setLoading(false))
  }, [])

  const fmt = (n: number) => n >= 1000000 ? (n / 1000000).toFixed(1) + 'M' : n >= 1000 ? (n / 1000).toFixed(1) + 'K' : n.toString()

  const fadeInUp = {
    initial: { opacity: 0, y: 20 },
    animate: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } }
  }

  const staggerContainer = {
    initial: {},
    animate: {
      transition: {
        staggerChildren: 0.1
      }
    }
  }

  return (
    <div className="min-h-screen bg-[#07070d] text-white selection:bg-violet-500/30">
      <Navbar onChatToggle={() => setIsChatOpen(!isChatOpen)} />
      <AnnouncementBanner />

      {/* ── HERO ─────────────────────────────────────────── */}
      <section className="relative min-h-[80vh] flex items-center overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <motion.div 
            animate={{ 
              scale: [1, 1.2, 1],
              opacity: [0.4, 0.6, 0.4],
            }}
            transition={{ duration: 10, repeat: Infinity, ease: "easeInOut" }}
            className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] bg-violet-600/30 rounded-full blur-[120px]" 
          />
          <motion.div 
            animate={{ 
              scale: [1, 1.1, 1],
              opacity: [0.3, 0.5, 0.3],
            }}
            transition={{ duration: 15, repeat: Infinity, ease: "easeInOut", delay: 2 }}
            className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-cyan-500/25 rounded-full blur-[100px]" 
          />
        </div>
        
        {/* Grid Pattern */}
        <div className="absolute inset-0 opacity-50 pointer-events-none" style={{ 
          backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(255,255,255,0.2) 1.5px, transparent 0)', 
          backgroundSize: '40px 40px' 
        }} />

        <div className="container mx-auto px-4 relative z-10 py-16">
          {!mounted ? (
            <div className="h-[400px] flex items-center justify-center">
              <div className="w-8 h-8 border-4 border-violet-500 border-t-transparent rounded-full animate-spin" />
            </div>
          ) : (
            <div className="w-full">
              {isAuthed ? (
                /* ── Authenticated hero ── */
                <div className="max-w-5xl mx-auto">
                  <div className="grid lg:grid-cols-5 gap-6">
                    {/* Welcome card */}
                    <motion.div 
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.5 }}
                      className="lg:col-span-3 relative rounded-[2rem] border border-white/[0.08] bg-gradient-to-br from-violet-950/40 via-[#0d0d1f]/90 to-cyan-950/30 p-6 lg:p-8 overflow-hidden backdrop-blur-xl shadow-2xl shadow-black/50"
                    >
                      <div className="absolute -top-24 -right-24 w-80 h-80 bg-violet-500/20 rounded-full blur-[100px]" />
                      <div className="relative">
                        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/[0.05] border border-white/[0.1] text-[10px] font-bold text-white/80 mb-6">
                          <span className="relative flex h-1.5 w-1.5">
                            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                            <span className="relative inline-flex rounded-full h-1.5 w-1.5 bg-emerald-500"></span>
                          </span>
                          Welcome back, <span className="text-white font-black">{session?.user?.name?.split(' ')[0] || 'creator'}</span>
                        </div>
                        
                        <h1 className="text-3xl lg:text-5xl font-black text-white leading-[1.1] tracking-tight mb-4">
                          Your creativity,<br/>
                          <span className="bg-gradient-to-r from-violet-400 via-fuchsia-300 to-cyan-400 bg-clip-text text-transparent">
                            unleashed.
                          </span>
                        </h1>
                        
                        <p className="text-white/50 mb-8 text-sm lg:text-base leading-relaxed max-w-md">
                          Ready to build something amazing today? Access your tools and track your growth.
                        </p>

                        <div className="grid grid-cols-4 gap-2.5 mb-8">
                          {[
                            { href: '/videos/upload', icon: VideoIcon, label: 'Video', color: 'text-rose-400', bg: 'bg-rose-500/10' },
                            { href: '/apps/upload', icon: Smartphone, label: 'App', color: 'text-emerald-400', bg: 'bg-emerald-500/10' },
                            { href: '/code/upload', icon: Code2, label: 'Code', color: 'text-amber-400', bg: 'bg-amber-500/10' },
                            { href: '/seller', icon: Upload, label: 'Upload', color: 'text-violet-400', bg: 'bg-violet-500/10' },
                          ].map(({ href, icon: Icon, label, color, bg }) => (
                            <Link key={href} href={href} className={`group flex flex-col items-center gap-2.5 py-4 rounded-2xl border border-white/[0.05] bg-white/[0.02] hover:bg-white/[0.08] hover:border-white/20 transition-all duration-300`}>
                              <div className={`p-2 rounded-xl ${bg}`}>
                                <Icon className={`w-4 h-4 ${color}`} />
                              </div>
                              <span className="text-[10px] font-black text-white/60 group-hover:text-white uppercase tracking-wider">{label}</span>
                            </Link>
                          ))}
                        </div>

                        <div className="flex flex-wrap gap-2.5">
                          <Link href="/dashboard">
                            <Button className="h-11 px-6 bg-white text-black hover:bg-white/90 rounded-xl font-black text-xs gap-2 shadow-lg shadow-white/10">
                              <LayoutDashboard className="h-3.5 w-3.5" /> Dashboard
                            </Button>
                          </Link>
                          <Link href="/ai-generate">
                            <Button variant="outline" className="h-11 px-6 bg-white/[0.05] border-white/10 text-white hover:bg-white/[0.1] rounded-xl font-black text-xs gap-2">
                              <Sparkles className="h-3.5 w-3.5 text-violet-400" /> AI Studio
                            </Button>
                          </Link>
                        </div>

                        {/* Quick Stats Summary for Authed */}
                        <div className="grid grid-cols-3 gap-2 mt-8 pt-8 border-t border-white/[0.05]">
                          <div className="text-center lg:text-left">
                            <p className="text-white/30 text-[9px] uppercase font-black tracking-widest mb-1">Balance</p>
                            <p className="text-lg font-black text-emerald-400 tracking-tight">৳{userData?.walletBalance?.toFixed(1) || '0.0'}</p>
                          </div>
                          <div className="text-center lg:text-left border-x border-white/[0.05]">
                            <p className="text-white/30 text-[9px] uppercase font-black tracking-widest mb-1">Total Sales</p>
                            <p className="text-lg font-black text-violet-400 tracking-tight">{userData?.totalSales || '0'}</p>
                          </div>
                          <div className="text-center lg:text-left">
                            <p className="text-white/30 text-[9px] uppercase font-black tracking-widest mb-1">Level</p>
                            <p className="text-lg font-black text-amber-400 tracking-tight">{userData?.sellerLevel || '1'}</p>
                          </div>
                        </div>
                      </div>
                    </motion.div>

                    {/* Quick-access grid */}
                    <div className="lg:col-span-2 grid grid-cols-2 gap-3 md:gap-4">
                      {[
                        { href: '/messages', icon: MessageSquare, label: 'Messages', color: 'from-blue-500/20 to-cyan-500/10', ic: 'text-blue-400', delay: 0.1 },
                        { href: '/cart', icon: ShoppingCart, label: 'Orders', color: 'from-emerald-500/20 to-teal-500/10', ic: 'text-emerald-400', delay: 0.2 },
                        { href: '/ai-generate', icon: Sparkles, label: 'AI Tools', color: 'from-violet-500/20 to-purple-500/10', ic: 'text-violet-400', delay: 0.3 },
                        { href: '/memberships', icon: Crown, label: 'Premium', color: 'from-amber-500/20 to-yellow-500/10', ic: 'text-amber-400', delay: 0.4 },
                        { href: '/vps', icon: Server, label: 'Cloud VPS', color: 'from-cyan-500/20 to-sky-500/10', ic: 'text-cyan-400', delay: 0.5 },
                        { href: '/rewards', icon: Zap, label: 'Rewards', color: 'from-rose-500/20 to-pink-500/10', ic: 'text-rose-400', delay: 0.6 },
                      ].map(({ href, icon: Icon, label, color, ic, delay }) => (
                        <motion.div 
                          key={href}
                          initial={{ opacity: 0, y: 15 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: 0.2 + delay }}
                          className="h-full"
                        >
                          <Link href={href} className={`group h-full flex flex-col items-center justify-center gap-2.5 p-5 md:p-6 rounded-[1.5rem] bg-gradient-to-br ${color} border border-white/[0.05] hover:border-white/20 hover:bg-white/[0.05] transition-all duration-300 shadow-xl shadow-black/20`}>
                            <div className="relative">
                              <Icon className={`w-6 h-6 md:w-7 md:h-7 ${ic} relative z-10 group-hover:scale-110 transition-transform`} />
                              <div className={`absolute inset-0 blur-lg opacity-40 ${ic.replace('text-', 'bg-')}`} />
                            </div>
                            <span className="text-xs font-black text-white/60 group-hover:text-white uppercase tracking-wider">{label}</span>
                          </Link>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </div>
              ) : (
                /* ── Guest hero ── */
                <div className="text-center max-w-5xl mx-auto">
                  <motion.div 
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: 0.2 }}
                    className="inline-flex items-center gap-2.5 px-5 py-2.5 rounded-full border border-violet-500/30 bg-violet-500/10 text-violet-300 text-sm font-bold mb-10 backdrop-blur-md"
                  >
                    <Sparkles className="w-4 h-4 animate-pulse" />
                    The Ultimate Digital Asset Marketplace
                  </motion.div>

                  <h1 className="text-6xl sm:text-7xl lg:text-8xl font-[900] text-white leading-[1] tracking-tight mb-8">
                    Design Your<br/>
                    <span className="relative inline-block mt-2">
                      <span className="bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent">
                        Digital Future.
                      </span>
                      <div className="absolute -bottom-2 left-0 w-full h-1.5 bg-gradient-to-r from-violet-500/50 to-transparent rounded-full" />
                    </span>
                  </h1>

                  <p className="text-xl sm:text-2xl text-white/50 mb-12 max-w-3xl mx-auto leading-relaxed font-medium">
                    Join a community of <span className="text-white font-bold">{fmt(stats.totalUsers)}+</span> creators selling premium apps, code, and digital assets globally.
                  </p>

                  <div className="flex flex-col sm:flex-row items-center justify-center gap-5 mb-20">
                    <Link href="/browse">
                      <Button size="lg" className="h-14 px-10 bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 text-white border-0 rounded-2xl font-black text-lg gap-3 shadow-2xl shadow-violet-600/30 hover:scale-105 transition-all">
                        Start Exploring <ArrowRight className="w-5 h-5" />
                      </Button>
                    </Link>
                    <Link href="/auth/signup">
                      <Button size="lg" variant="outline" className="h-14 px-10 bg-white/[0.03] border-white/10 text-white hover:bg-white/[0.08] hover:border-white/20 rounded-2xl font-black text-lg backdrop-blur-sm">
                        Join for Free
                      </Button>
                    </Link>
                  </div>

                  {/* New stylish guest elements instead of trust bar */}
                  <div className="flex flex-wrap items-center justify-center gap-4 max-w-4xl mx-auto">
                    {['Premium Assets', 'Secure Checkout', '24/7 Support', 'Fast Delivery'].map((text, i) => (
                      <div key={text} className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/[0.03] border border-white/[0.05] text-[11px] font-black text-white/40 uppercase tracking-widest">
                        <div className="w-1.5 h-1.5 rounded-full bg-violet-500 shadow-[0_0_8px_rgba(139,92,246,0.8)]" />
                        {text}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Bottom fade */}
        <div className="absolute bottom-0 inset-x-0 h-40 bg-gradient-to-t from-[#07070d] to-transparent pointer-events-none" />
      </section>

      {/* ── AFK EARN BANNER (authenticated only) ───────────── */}
      {isAuthed && (
        <section className="px-4 py-4 md:py-6">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="container mx-auto max-w-5xl"
          >
            <Link href="/afk" className="group block relative p-[1px] rounded-3xl overflow-hidden bg-gradient-to-r from-emerald-500/20 via-teal-500/40 to-emerald-500/20 hover:from-emerald-500/40 transition-all">
              <div className="relative p-6 rounded-[23px] bg-[#0a0a1a] flex flex-col md:flex-row items-center gap-6">
                <div className="w-14 h-14 rounded-2xl bg-emerald-500/15 border border-emerald-500/20 flex items-center justify-center flex-shrink-0 relative overflow-hidden">
                  <div className="absolute inset-0 bg-emerald-500/10 animate-pulse" />
                  <Zap className="w-7 h-7 text-emerald-400 relative z-10" />
                </div>
                <div className="flex-1 text-center md:text-left">
                  <h3 className="text-xl font-black text-white mb-1">Passive Earning Active</h3>
                  <p className="text-white/50 text-sm leading-relaxed">Stay on the platform and earn coins automatically. Your time is literally money here.</p>
                </div>
                <Button className="bg-emerald-500 hover:bg-emerald-400 text-black font-black px-8 rounded-2xl h-12 shadow-lg shadow-emerald-500/20 group-hover:scale-105 transition-all">
                  Start Now
                </Button>
              </div>
            </Link>
          </motion.div>
        </section>
      )}

      {/* ── ANNOUNCEMENTS ──────────────────────────────── */}
      {announcements.length > 0 && (
        <section className="py-12 px-4">
          <div className="container mx-auto max-w-5xl">
            <div className="flex items-center gap-3 mb-8">
              <div className="w-1.5 h-6 bg-violet-500 rounded-full" />
              <h2 className="text-2xl font-black text-white tracking-tight">Recent Updates</h2>
            </div>
            <div className="grid gap-4">
              {announcements.map((a: any) => (
                <div key={a.id} className="p-6 rounded-3xl border border-white/[0.05] bg-white/[0.02] hover:bg-white/[0.04] transition-all">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-lg font-bold text-white">{a.title}</h3>
                    <span className="text-[10px] font-bold text-white/20 uppercase tracking-widest">{safeTimeAgo(a.createdAt)}</span>
                  </div>
                  <p className="text-white/40 text-sm leading-relaxed">{a.content}</p>
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ── HOMEPAGE ADS ──────────────────────────────── */}
      {homepageAds.length > 0 && (
        <section className="py-12 px-4 bg-[#090915]">
          <div className="container mx-auto max-w-6xl">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {homepageAds.map((ad: any) => (
                <a key={ad.id} href={ad.linkUrl || '#'} target={ad.linkUrl ? '_blank' : undefined} rel="noopener noreferrer"
                  className="group relative rounded-2xl overflow-hidden border border-white/[0.05] bg-white/[0.02] hover:bg-white/[0.05] hover:border-white/20 transition-all duration-300">
                  {ad.imageUrl && (
                    <div className="aspect-[16/9] relative overflow-hidden bg-white/[0.02]">
                      <img src={ad.imageUrl} alt={ad.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                    </div>
                  )}
                  <div className="p-5">
                    <h3 className="text-white font-bold text-lg mb-1 group-hover:text-violet-300 transition-colors">{ad.title}</h3>
                    {ad.description && <p className="text-white/40 text-sm line-clamp-2">{ad.description}</p>}
                    {ad.linkUrl && (
                      <div className="mt-3 flex items-center gap-1 text-xs font-bold text-violet-400">
                        Learn More <ExternalLink className="w-3 h-3" />
                      </div>
                    )}
                  </div>
                </a>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ── AI STUDIO ──────────────────────────────────── */}
      <section className="py-24 px-4 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-[400px] h-[400px] bg-violet-600/5 rounded-full blur-[100px] pointer-events-none" />
        <div className="container mx-auto max-w-6xl relative z-10">
          <div className="flex flex-col items-center text-center mb-16">
            <Badge className="mb-4 px-4 py-1.5 bg-violet-500/10 text-violet-300 border-violet-500/20 rounded-full text-xs font-black uppercase tracking-widest">Innovation Hub</Badge>
            <h2 className="text-4xl sm:text-5xl font-black text-white tracking-tight mb-4">Powerful AI Studio</h2>
            <p className="text-white/40 text-lg max-w-2xl mx-auto font-medium">The most advanced AI tools for creators, fully integrated into your workflow.</p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[
              { href: '/ai-generate', icon: ImageIcon, label: 'Visual AI', desc: 'Text to Art', color: 'from-pink-600/20 to-rose-600/10', ic: 'text-pink-400' },
              { href: '/ai-chat', icon: MessageSquare, label: 'Conversational', desc: 'GPT-4o & Claude', color: 'from-blue-600/20 to-cyan-600/10', ic: 'text-blue-400' },
              { href: '/ai-video', icon: VideoIcon, label: 'Motion AI', desc: 'Cinematic Video', color: 'from-red-600/20 to-orange-600/10', ic: 'text-red-400' },
              { href: '/ai-voice', icon: Mic, label: 'Audio AI', desc: 'Realistic TTS', color: 'from-emerald-600/20 to-teal-600/10', ic: 'text-emerald-400' },
              { href: '/thumbnails', icon: ImageIcon, label: 'Content Tools', desc: 'Pro Thumbnails', color: 'from-amber-600/20 to-yellow-600/10', ic: 'text-amber-400' },
              { href: '/tasks', icon: Zap, label: 'Earn Rewards', desc: 'Bounties & Tasks', color: 'from-violet-600/20 to-purple-600/10', ic: 'text-violet-400' },
              { href: '/messages', icon: MessageSquare, label: 'Social Hub', desc: 'Direct Connect', color: 'from-cyan-600/20 to-sky-600/10', ic: 'text-cyan-400' },
              { href: '/vps', icon: Server, label: 'Infrastructure', desc: 'High-Perf VPS', color: 'from-slate-600/20 to-gray-600/10', ic: 'text-slate-400' },
            ].map(({ href, icon: Icon, label, desc, color, ic }, idx) => (
              <motion.div
                key={href}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.05 }}
              >
                <Link href={href} className={`group relative p-6 rounded-3xl bg-gradient-to-br ${color} border border-white/[0.05] hover:border-white/20 transition-all duration-300 hover:scale-[1.03] hover:shadow-2xl hover:shadow-black/40 h-full flex flex-col items-start`}>
                  <div className={`p-3 rounded-2xl bg-white/[0.03] mb-5 group-hover:scale-110 transition-transform ${ic}`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <h4 className="text-white font-black text-lg mb-1">{label}</h4>
                  <p className="text-white/40 text-xs font-medium">{desc}</p>
                  <div className="mt-auto pt-6 w-full flex justify-end">
                    <div className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center group-hover:bg-white/10 transition-colors">
                      <ArrowRight className="w-4 h-4 text-white/20 group-hover:text-white" />
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FEATURED ITEMS ─────────────────────────────── */}
      {featuredItems.length > 0 && (
        <section className="py-24 px-4 bg-[#090915]">
          <div className="container mx-auto max-w-6xl">
            <div className="flex flex-col md:flex-row items-center md:items-end justify-between gap-6 mb-16">
              <div className="text-center md:text-left">
                <Badge className="mb-4 px-4 py-1.5 bg-amber-500/10 text-amber-300 border-amber-500/20 rounded-full text-xs font-black uppercase tracking-widest">🔥 Hot Picks</Badge>
                <h2 className="text-4xl font-black text-white tracking-tight">Featured Collections</h2>
              </div>
              <Link href="/browse">
                <Button variant="ghost" className="text-white/40 hover:text-white hover:bg-white/5 font-bold gap-2 group">
                  Explore All Products <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
            </div>
            
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {featuredItems.slice(0, 8).map((item, idx) => (
                <motion.div
                  key={item.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: idx * 0.1 }}
                >
                  <Link href={`/items/${item.slug}`}
                    className="group flex flex-col h-full rounded-[2rem] border border-white/[0.05] bg-white/[0.02] hover:bg-white/[0.05] hover:border-white/20 transition-all duration-500 overflow-hidden">
                    <div className="aspect-[4/3] relative overflow-hidden bg-white/[0.02]">
                      {item.logo ? (
                        <img src={item.logo} alt={item.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Package className="w-12 h-12 text-white/5" />
                        </div>
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-end p-4">
                        <Button className="w-full h-10 rounded-xl bg-white text-black font-bold text-xs gap-2">
                          <Eye className="w-3.5 h-3.5" /> View Project
                        </Button>
                      </div>
                      {item.accessType === 'FREE' && (
                        <div className="absolute top-4 left-4">
                          <Badge className="bg-emerald-500 text-black font-black text-[10px] border-0 shadow-lg shadow-emerald-500/20">FREE</Badge>
                        </div>
                      )}
                    </div>
                    <div className="p-6 flex flex-col flex-1">
                      <div className="flex items-center gap-2 mb-3">
                        <Badge variant="outline" className="bg-white/[0.03] border-white/10 text-[10px] text-white/40 px-2 py-0">{item.category.name}</Badge>
                      </div>
                      <h3 className="text-white font-bold text-lg leading-tight mb-2 line-clamp-1 group-hover:text-violet-300 transition-colors">{item.title}</h3>
                      <p className="text-white/40 text-xs line-clamp-2 mb-6 font-medium leading-relaxed">{item.shortDesc}</p>
                      
                      <div className="mt-auto flex items-center justify-between pt-4 border-t border-white/[0.05]">
                        <div className="flex items-center gap-2">
                          <Avatar className="w-6 h-6 border border-white/10">
                            <AvatarImage src={item.author.avatar} />
                            <AvatarFallback className="text-[10px] bg-violet-500/20 text-violet-300 font-bold">{item.author.username[0]}</AvatarFallback>
                          </Avatar>
                          <span className="text-xs font-bold text-white/60">{item.author.username}</span>
                        </div>
                        <div className="flex items-center gap-3">
                          <div className="flex items-center gap-1 text-[11px] font-bold text-white/30">
                            <Download className="w-3 h-3" /> {fmt(item.downloads)}
                          </div>
                          <div className="flex items-center gap-1 text-[11px] font-bold text-white/30">
                            <Heart className="w-3 h-3" /> {fmt(item.likes)}
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ── LATEST VIDEOS ──────────────────────────────── */}
      {latestVideos.length > 0 && (
        <section className="py-24 px-4 overflow-hidden">
          <div className="container mx-auto max-w-6xl">
            <div className="flex items-end justify-between mb-12">
              <div>
                <Badge className="mb-4 px-4 py-1.5 bg-red-500/10 text-red-300 border-red-500/20 rounded-full text-xs font-black uppercase tracking-widest">🎬 Visuals</Badge>
                <h2 className="text-4xl font-black text-white tracking-tight">Trending Videos</h2>
              </div>
              <Link href="/videos">
                <Button variant="ghost" className="text-white/40 hover:text-white hover:bg-white/5 font-bold group">
                  Watch All <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
            </div>
            
            <Carousel opts={{ align: 'start' }} className="w-full">
              <CarouselContent className="-ml-6">
                {latestVideos.map((v: any, idx: number) => (
                  <CarouselItem key={v.id} className="pl-6 basis-full sm:basis-1/2 lg:basis-1/3 xl:basis-1/4">
                    <Link href={`/videos/${v.id}`} className="group block relative rounded-[2rem] overflow-hidden border border-white/[0.05] bg-white/[0.02] hover:border-white/20 transition-all duration-500">
                      <div className="aspect-video relative overflow-hidden">
                        {v.thumbnail ? (
                          <img src={v.thumbnail} alt={v.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center bg-black/40">
                            <Play className="w-10 h-10 text-white/10" />
                          </div>
                        )}
                        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-60" />
                        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                          <div className="w-12 h-12 rounded-full bg-white text-black flex items-center justify-center scale-75 group-hover:scale-100 transition-transform duration-300">
                            <Play className="w-5 h-5 fill-current" />
                          </div>
                        </div>
                        <div className="absolute bottom-4 left-4 right-4">
                          <p className="text-white text-sm font-black line-clamp-1 group-hover:text-red-300 transition-colors">{v.title}</p>
                        </div>
                      </div>
                      <div className="p-5 flex items-center justify-between border-t border-white/[0.05]">
                        <span className="text-[11px] font-bold text-white/40 uppercase tracking-wider">{v.author?.username || 'creator'}</span>
                        <span className="text-[10px] font-medium text-white/20">{safeTimeAgo(v.createdAt)}</span>
                      </div>
                    </Link>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <div className="hidden md:flex gap-2 absolute -top-16 right-40">
                <CarouselPrevious className="relative left-0 top-0 translate-y-0 border-white/10 bg-white/5 hover:bg-white/10 text-white rounded-xl h-10 w-10" />
                <CarouselNext className="relative right-0 top-0 translate-y-0 border-white/10 bg-white/5 hover:bg-white/10 text-white rounded-xl h-10 w-10" />
              </div>
            </Carousel>
          </div>
        </section>
      )}

      {/* ── APPS + CODE ────────────────────────────────── */}
      <section className="py-24 px-4 bg-gradient-to-b from-transparent via-white/[0.02] to-transparent">
        <div className="container mx-auto max-w-6xl">
          <div className="grid lg:grid-cols-2 gap-12">
            {/* Apps */}
            {latestApps.length > 0 && (
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
              >
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
                      <Smartphone className="w-6 h-6 text-emerald-400" />
                    </div>
                    <h3 className="text-2xl font-black text-white">Premium Apps</h3>
                  </div>
                  <Link href="/apps" className="text-xs font-bold text-white/30 hover:text-white transition-colors">View All</Link>
                </div>
                <div className="grid gap-3">
                  {latestApps.slice(0, 4).map((app: any) => (
                    <Link key={app.id} href={`/apps/${app.id}`}
                      className="group flex items-center gap-4 p-4 rounded-3xl border border-white/[0.05] bg-white/[0.02] hover:bg-white/[0.06] hover:border-white/20 transition-all duration-300">
                      <div className="w-14 h-14 rounded-2xl bg-white/[0.05] border border-white/[0.05] flex items-center justify-center overflow-hidden flex-shrink-0 group-hover:scale-105 transition-transform">
                        {app.icon ? <img src={app.icon} alt={app.title} className="w-full h-full object-cover" /> : <Smartphone className="w-6 h-6 text-white/10" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-white font-bold text-base mb-1 group-hover:text-emerald-300 transition-colors">{app.title}</p>
                        <p className="text-white/30 text-xs font-medium uppercase tracking-wider">{app.category || 'Mobile App'}</p>
                      </div>
                      <div className="flex flex-col items-end gap-1">
                        <div className="flex items-center gap-1 text-xs font-black text-amber-400">
                          <Star className="w-3.5 h-3.5 fill-current" /> {app.rating?.toFixed(1) || '5.0'}
                        </div>
                        <span className="text-[10px] font-bold text-white/20 uppercase tracking-tighter">Verified</span>
                      </div>
                    </Link>
                  ))}
                </div>
              </motion.div>
            )}

            {/* Code */}
            {latestCodes.length > 0 && (
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
              >
                <div className="flex items-center justify-between mb-8">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center">
                      <Code2 className="w-6 h-6 text-amber-400" />
                    </div>
                    <h3 className="text-2xl font-black text-white">Source Code</h3>
                  </div>
                  <Link href="/code" className="text-xs font-bold text-white/30 hover:text-white transition-colors">View All</Link>
                </div>
                <div className="grid gap-3">
                    {latestCodes.slice(0, 4).map((proj: any) => (
                      <Link key={proj.id} href={`/code/${proj.id}`}
                        className="group flex items-center gap-4 p-4 rounded-3xl border border-white/[0.05] bg-white/[0.02] hover:bg-white/[0.06] hover:border-white/20 transition-all duration-300">
                      <div className="w-14 h-14 rounded-2xl bg-amber-500/5 border border-amber-500/10 flex items-center justify-center flex-shrink-0 group-hover:scale-105 transition-transform">
                        <Code2 className="w-6 h-6 text-amber-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-white font-bold text-base mb-1 group-hover:text-amber-300 transition-colors">{proj.title || proj.name}</p>
                        <p className="text-white/30 text-xs font-medium uppercase tracking-wider">{proj.language || 'Project'}</p>
                      </div>
                      <div className="flex flex-col items-end gap-1">
                        <div className="flex items-center gap-1 text-xs font-black text-white/60">
                          <Download className="w-3.5 h-3.5" /> {fmt(proj.downloads || 0)}
                        </div>
                        <span className="text-[10px] font-bold text-white/20 uppercase tracking-tighter">Full Access</span>
                      </div>
                    </Link>
                  ))}
                </div>
              </motion.div>
            )}
          </div>
        </div>
      </section>

      {/* ── MEMBERSHIP PLANS ───────────────────────────── */}
      {memberships.length > 0 && (
        <section className="py-32 px-4 relative overflow-hidden">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-violet-600/10 rounded-full blur-[120px] pointer-events-none" />
          
          <div className="container mx-auto max-w-6xl relative z-10">
            <div className="text-center mb-20">
              <Badge className="mb-4 px-4 py-1.5 bg-amber-500/10 text-amber-300 border-amber-500/20 rounded-full text-xs font-black uppercase tracking-widest">💎 Elite Access</Badge>
              <h2 className="text-4xl sm:text-6xl font-[900] text-white tracking-tight mb-6">Upgrade Your Experience</h2>
              <p className="text-white/40 text-xl max-w-2xl mx-auto font-medium">Get exclusive benefits, higher earning rates, and premium content access.</p>
            </div>
            
            <div className="grid md:grid-cols-3 gap-8">
              {memberships.slice(0, 3).map((plan, i) => {
                const isPopular = i === 1 || memberships.length === 1
                const features: string[] = Array.isArray(plan.features) ? plan.features : typeof plan.features === 'string' ? JSON.parse(plan.features) : []
                return (
                  <motion.div 
                    key={plan.id}
                    initial={{ opacity: 0, y: 30 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                    className={`relative rounded-[2.5rem] border p-10 transition-all duration-500 ${
                      isPopular 
                      ? 'border-violet-500/40 bg-gradient-to-b from-violet-900/40 to-[#0a0a1a] shadow-2xl shadow-violet-500/20 scale-105 z-10' 
                      : 'border-white/[0.08] bg-white/[0.03] hover:border-white/20'
                    }`}
                  >
                    {isPopular && (
                      <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-6 py-1.5 rounded-full bg-gradient-to-r from-violet-600 to-fuchsia-600 text-white text-xs font-black uppercase tracking-widest shadow-xl">Recommended</div>
                    )}
                    
                    <div className={`w-14 h-14 rounded-2xl mb-8 flex items-center justify-center ${isPopular ? 'bg-violet-500/20 text-violet-300' : 'bg-white/5 text-white/30'}`}>
                      <Crown className="w-8 h-8" />
                    </div>
                    
                    <h3 className="text-2xl font-black text-white mb-2">{plan.name}</h3>
                    <p className="text-white/40 text-sm mb-8 font-medium leading-relaxed">{plan.description}</p>
                    
                    <div className="mb-10">
                      <div className="flex items-baseline gap-1">
                        <span className="text-5xl font-black text-white">৳{plan.price.toFixed(0)}</span>
                        <span className="text-white/30 text-sm font-bold uppercase tracking-wider">/ Life</span>
                      </div>
                    </div>
                    
                    <ul className="space-y-4 mb-10">
                      {features.slice(0, 6).map((f: string, fi: number) => (
                        <li key={fi} className="flex items-start gap-3 text-sm font-bold text-white/70">
                          <div className="mt-1 p-0.5 rounded-full bg-emerald-500/20">
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                          </div>
                          {f}
                        </li>
                      ))}
                    </ul>
                    
                    <Link href="/memberships">
                      <Button className={`w-full rounded-2xl h-14 text-base font-black transition-all duration-300 ${
                        isPopular 
                        ? 'bg-white text-black hover:bg-white/90 shadow-xl shadow-white/10' 
                        : 'bg-white/5 text-white border border-white/10 hover:bg-white/10'
                      }`}>
                        Get Started
                      </Button>
                    </Link>
                  </motion.div>
                )
              })}
            </div>
          </div>
        </section>
      )}

      {/* ── STATS STRIP (Stylish & Responsive) ────────── */}
      <section className="py-12 md:py-16 px-4 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-violet-500/5 to-transparent" />
        <div className="container mx-auto max-w-6xl relative z-10">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            {[
              { v: fmt(stats.totalUsers), l: 'Creators', color: 'text-violet-400', icon: Users, bg: 'bg-violet-500/10', border: 'border-violet-500/20' },
              { v: fmt(stats.totalItems), l: 'Assets', color: 'text-cyan-400', icon: Package, bg: 'bg-cyan-500/10', border: 'border-cyan-500/20' },
              { v: fmt(stats.totalDownloads), l: 'Downloads', color: 'text-emerald-400', icon: Download, bg: 'bg-emerald-500/10', border: 'border-emerald-500/20' },
              { v: '99.9%', l: 'Uptime', color: 'text-amber-400', icon: Globe, bg: 'bg-amber-500/10', border: 'border-amber-500/20' },
            ].map(({ v, l, color, icon: Icon, bg, border }) => (
              <motion.div 
                key={l}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                className={`group relative p-6 md:p-8 rounded-[2.5rem] border ${border} bg-[#0d0d1f]/40 backdrop-blur-xl hover:bg-[#0d0d1f]/60 transition-all duration-500 overflow-hidden`}
              >
                <div className={`absolute top-0 right-0 w-24 h-24 ${bg} blur-[50px] -mr-12 -mt-12 opacity-0 group-hover:opacity-100 transition-opacity duration-700`} />
                <div className="relative flex flex-col items-center lg:items-start gap-4">
                  <div className={`w-12 h-12 rounded-2xl ${bg} flex items-center justify-center ${color} group-hover:scale-110 transition-transform duration-500`}>
                    <Icon className="w-6 h-6" />
                  </div>
                  <div className="text-center lg:text-left">
                    <div className={`text-3xl md:text-4xl font-black tracking-tight mb-1 ${color}`}>{v}</div>
                    <div className="text-[10px] text-white/30 font-black uppercase tracking-widest">{l}</div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ── WHY US ────────────────────────────────────── */}
      <section className="py-24 px-4 bg-white/[0.01]">
        <div className="container mx-auto max-w-6xl">
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { icon: Rocket, title: 'Instant Delivery', desc: 'Get your digital assets immediately after purchase. No waiting, no manual processing.', color: 'text-violet-400' },
              { icon: Shield, title: 'Secure Platform', desc: 'Every transaction and download is protected by industry-leading security standards.', color: 'text-emerald-400' },
              { icon: Globe, title: 'Global Reach', desc: 'Sell your products to creators worldwide and earn in multiple currencies.', color: 'text-cyan-400' },
            ].map(({ icon: Icon, title, desc, color }) => (
              <div key={title} className="p-8 rounded-[2rem] border border-white/[0.05] bg-white/[0.01] hover:bg-white/[0.03] transition-all group">
                <div className={`w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center mb-6 ${color} group-hover:scale-110 transition-transform`}>
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="text-xl font-black text-white mb-3">{title}</h3>
                <p className="text-white/40 text-sm leading-relaxed font-medium">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── CTA BANNER ─────────────────────────────────── */}
      <section className="py-20 md:py-24 px-4">
        <div className="container mx-auto max-w-5xl">
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative rounded-[2.5rem] border border-white/[0.08] bg-gradient-to-br from-violet-950/40 via-[#0d0d1f] to-fuchsia-950/30 p-8 md:p-14 overflow-hidden text-center"
          >
            <div className="absolute -top-24 -left-24 w-96 h-96 bg-violet-600/20 rounded-full blur-[120px] pointer-events-none animate-pulse" />
            <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-fuchsia-600/15 rounded-full blur-[120px] pointer-events-none animate-pulse" />
            
            <div className="relative z-10 max-w-2xl mx-auto">
              <div className="w-16 h-16 rounded-[1.5rem] bg-white/5 border border-white/10 flex items-center justify-center mx-auto mb-8 group-hover:scale-110 transition-transform">
                <Rocket className="w-8 h-8 text-violet-400" />
              </div>
              {isAuthed ? (
                <>
                  <h2 className="text-3xl md:text-5xl font-[900] text-white mb-4 tracking-tight leading-[1.1]">Become a Verified<br/>Creator Pro</h2>
                  <p className="text-white/50 text-base md:text-lg mb-10 font-medium leading-relaxed">Unlock advanced analytics, lower fees, and featured placements by verifying your identity.</p>
                  <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                    <Link href="/seller-verification">
                      <Button size="lg" className="h-14 px-10 bg-white text-black hover:bg-white/90 rounded-2xl font-black text-base gap-3 shadow-2xl shadow-white/10">
                        Get Verified Now <Check className="w-5 h-5" />
                      </Button>
                    </Link>
                  </div>
                </>
              ) : (
                <>
                  <h2 className="text-3xl md:text-5xl font-[900] text-white mb-4 tracking-tight leading-[1.1]">Ready to join the<br/>creator economy?</h2>
                  <p className="text-white/50 text-base md:text-lg mb-10 font-medium leading-relaxed">Start selling your digital products and earning passively today. No setup fees, just growth.</p>
                  <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                    <Link href="/auth/signup">
                      <Button size="lg" className="h-14 px-10 bg-white text-black hover:bg-white/90 rounded-2xl font-black text-base gap-3 shadow-2xl shadow-white/10">
                        Create Your Account <ArrowRight className="w-5 h-5" />
                      </Button>
                    </Link>
                    <Link href="/browse">
                      <Button size="lg" variant="ghost" className="h-14 px-10 text-white font-black text-base hover:bg-white/5 rounded-2xl">
                        Browse Assets
                      </Button>
                    </Link>
                  </div>
                </>
              )}
            </div>
          </motion.div>
        </div>
      </section>

      <Footer />
      {mounted && <ChatWidget isOpen={isChatOpen} onToggle={() => setIsChatOpen(!isChatOpen)} />}
    </div>
  )
}
