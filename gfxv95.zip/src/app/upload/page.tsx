'use client'

import { Suspense, useState, useEffect, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter, useSearchParams } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Upload, X, Loader2, Image as ImageIcon, Plus, Trash2, Wand2, FileArchive, ChevronRight, CheckCircle2, ArrowLeft } from 'lucide-react'
import { toast } from 'sonner'
import Link from 'next/link'

const STEPS = [
  { id: 'basic', label: 'Basic Info', num: 1 },
  { id: 'details', label: 'Details', num: 2 },
  { id: 'media', label: 'Media & Files', num: 3 },
]

function UploadForm() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const searchParams = useSearchParams()
  const editId = searchParams.get('edit')
  const fileInputRef = useRef<HTMLInputElement>(null)
  const screenshotInputRef = useRef<HTMLInputElement>(null)
  const logoInputRef = useRef<HTMLInputElement>(null)
  
  const [activeStep, setActiveStep] = useState('basic')
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    shortDesc: '',
    moreInfo: '',
    categoryId: '',
    price: 0,
    tags: '' as string,
    version: '1.0.0',
    gameVersion: '1.20.1',
    accessType: 'FREE',
    requiredRole: '',
  })
  const [memberships, setMemberships] = useState<any[]>([])
  const [isEditMode, setIsEditMode] = useState(false)
  
  const [files, setFiles] = useState<File[]>([])
  const [screenshots, setScreenshots] = useState<File[]>([])
  const [logo, setLogo] = useState<File | null>(null)
  const [categories, setCategories] = useState<any[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [aiGenerating, setAiGenerating] = useState(false)
  const [screenshotPreviews, setScreenshotPreviews] = useState<Array<{ name: string; url: string; size: number }>>([])
  const [filePreviews, setFilePreviews] = useState<Array<{ name: string; url: string; size: number }>>([])
  const [logoPreview, setLogoPreview] = useState<{ url: string; name: string } | null>(null)

  useEffect(() => {
    if (status === 'loading') return
    if (status === 'unauthenticated') {
      router.push('/auth/signin')
      return
    }
    fetchCategories()
    fetchMemberships()
    if (editId) loadEditItem(editId)
  }, [status, router, editId])

  const loadEditItem = async (itemId: string) => {
    try {
      const res = await fetch(`/api/items/${itemId}`)
      if (res.ok) {
        const item = await res.json()
        setIsEditMode(true)
        setFormData({
          title: item.title || '',
          description: item.description || '',
          shortDesc: item.shortDesc || '',
          moreInfo: '',
          categoryId: item.categoryId || '',
          price: item.price || 0,
          tags: Array.isArray(item.tags) ? item.tags.join(', ') : (item.tags || ''),
          version: item.versions?.[0]?.version || '1.0.0',
          gameVersion: '1.20.1',
          accessType: item.accessType || 'FREE',
          requiredRole: item.requiredRole || '',
        })
        if (item.logo) setLogoPreview({ url: item.logo, name: 'Current logo' })
      }
    } catch { toast.error('Failed to load item for editing') }
  }

  const fetchCategories = async () => {
    try {
      const response = await fetch('/api/categories')
      if (response.ok) {
        const data = await response.json()
        setCategories(data)
      }
    } catch (error) {
      console.error('Failed to fetch categories:', error)
    }
  }

  const fetchMemberships = async () => {
    try {
      const response = await fetch('/api/memberships')
      if (response.ok) {
        const data = await response.json()
        setMemberships(Array.isArray(data) ? data : data.memberships || [])
      }
    } catch (error) {
      console.error('Failed to fetch memberships:', error)
    }
  }

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || [])
    const newFiles = [...files, ...selectedFiles]
    setFiles(newFiles)
    selectedFiles.forEach(file => {
      setFilePreviews(prev => [...prev, {
        name: file.name,
        url: '',
        size: file.size
      }])
    })
  }

  const handleScreenshotChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(e.target.files || [])
    const newScreenshots = [...screenshots, ...selectedFiles]
    setScreenshots(newScreenshots)
    selectedFiles.forEach(file => {
      const reader = new FileReader()
      reader.onloadend = () => {
        setScreenshotPreviews(prev => [...prev, {
          name: file.name,
          url: reader.result as string,
          size: file.size
        }])
      }
      reader.readAsDataURL(file)
    })
  }

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index))
    setFilePreviews(prev => prev.filter((_, i) => i !== index))
  }

  const removeScreenshot = (index: number) => {
    setScreenshots(prev => prev.filter((_, i) => i !== index))
    setScreenshotPreviews(prev => prev.filter((_, i) => i !== index))
  }

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) {
      setLogo(file)
      const reader = new FileReader()
      reader.onloadend = () => {
        setLogoPreview({ name: file.name, url: reader.result as string })
      }
      reader.readAsDataURL(file)
    }
  }

  const removeLogo = () => {
    setLogo(null)
    setLogoPreview(null)
    if (logoInputRef.current) logoInputRef.current.value = ''
  }

  const generateSEO = async () => {
    if (!formData.title) { toast.error('Enter a title first to generate SEO content'); return }
    setAiGenerating(true)
    try {
      const selectedCategory = categories.find(c => c.id === formData.categoryId)
      const res = await fetch('/api/ai/seo', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: formData.title, category: selectedCategory?.slug || selectedCategory?.name || '' })
      })
      const data = await res.json()
      if (res.ok) {
        setFormData(prev => ({
          ...prev,
          description: data.description || prev.description,
          shortDesc: data.shortDesc || prev.shortDesc,
        }))
        toast.success('AI-generated content applied!')
      } else toast.error('Failed to generate SEO content')
    } catch { toast.error('Failed to generate') } finally { setAiGenerating(false) }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!session) return

    if (!formData.title || !formData.description || !formData.categoryId) {
      setError('Please fill in all required fields')
      toast.error('Please fill in all required fields')
      setActiveStep('basic')
      return
    }

    if (!isEditMode && files.length === 0) {
      setError('Please upload at least one file')
      toast.error('Please upload at least one file')
      setActiveStep('media')
      return
    }

    setLoading(true)
    setError('')

    try {
      const formDataToSend = new FormData()
      formDataToSend.append('title', formData.title)
      formDataToSend.append('description', formData.description)
      formDataToSend.append('shortDesc', formData.shortDesc)
      formDataToSend.append('moreInfo', formData.moreInfo)
      formDataToSend.append('categoryId', formData.categoryId)
      formDataToSend.append('price', formData.price.toString())
      formDataToSend.append('tags', formData.tags)
      formDataToSend.append('version', formData.version)
      formDataToSend.append('gameVersion', formData.gameVersion)
      formDataToSend.append('authorId', session.user.id)
      formDataToSend.append('accessType', formData.accessType)
      formDataToSend.append('requiredRole', formData.requiredRole)

      files.forEach((file) => formDataToSend.append('files', file))
      screenshots.forEach((screenshot) => formDataToSend.append('screenshots', screenshot))
      if (logo) formDataToSend.append('logo', logo)

      let response
      if (isEditMode && editId) {
        response = await fetch(`/api/items/${editId}`, { method: 'PATCH', body: formDataToSend })
      } else {
        response = await fetch('/api/items/upload', { method: 'POST', body: formDataToSend })
      }

      const data = await response.json()

      if (!response.ok) {
        setError(data.error || (isEditMode ? 'Failed to update item' : 'Failed to upload item'))
        toast.error(data.error || 'Upload failed')
      } else {
        toast.success(isEditMode ? 'Item updated successfully!' : 'Item uploaded successfully!')
        setTimeout(() => router.push('/dashboard'), 1500)
      }
    } catch (error) {
      setError('An error occurred during upload')
      toast.error('An error occurred')
    } finally {
      setLoading(false)
    }
  }

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B'
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB'
    return (bytes / 1024 / 1024).toFixed(2) + ' MB'
  }

  const getFileIcon = (name: string) => {
    const ext = name.split('.').pop()?.toLowerCase() || ''
    if (['jar'].includes(ext)) return '☕'
    if (['zip', 'rar', '7z'].includes(ext)) return '📦'
    if (['mcworld', 'mcpack', 'mcaddon'].includes(ext)) return '🎮'
    return '📄'
  }

  if (status === 'loading') {
    return (
      <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
      </div>
    )
  }

  const stepComplete = {
    basic: !!(formData.title && formData.description && formData.categoryId),
    details: !!(formData.version && formData.gameVersion),
    media: isEditMode || files.length > 0,
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      
      <div className="container mx-auto px-3 sm:px-4 py-6 sm:py-8 max-w-4xl">
        <div className="mb-6 sm:mb-8">
          <Link href="/dashboard" className="inline-flex items-center gap-1.5 text-xs text-white/30 hover:text-white/60 transition-colors mb-3 sm:mb-4">
            <ArrowLeft className="h-3.5 w-3.5" />
            Back to Dashboard
          </Link>
          <h1 className="text-xl sm:text-2xl font-bold text-white">{isEditMode ? 'Edit Item' : 'Upload Content'}</h1>
          <p className="text-xs sm:text-sm text-white/40 mt-1">
            {isEditMode ? 'Update your item details and files' : 'Share your digital creations with the community'}
          </p>
        </div>

        {/* Step Indicator - Responsive */}
        <div className="flex items-center gap-1.5 sm:gap-2 mb-6 sm:mb-8 overflow-x-auto pb-2 -mx-3 sm:mx-0 px-3 sm:px-0">
          {STEPS.map((step, i) => {
            const isActive = activeStep === step.id
            const isComplete = stepComplete[step.id as keyof typeof stepComplete]
            return (
              <button
                key={step.id}
                onClick={() => setActiveStep(step.id)}
                className={`flex items-center gap-1 sm:gap-2 px-2 sm:px-4 py-2 sm:py-2.5 rounded-lg sm:rounded-xl text-[10px] sm:text-xs font-medium transition-all whitespace-nowrap ${
                  isActive
                    ? 'bg-purple-500/20 text-purple-300 border border-purple-500/30'
                    : isComplete
                      ? 'bg-green-500/10 text-green-400 border border-green-500/20'
                      : 'bg-white/[0.03] text-white/40 border border-white/5 hover:bg-white/[0.06]'
                }`}
              >
                {isComplete && !isActive ? (
                  <CheckCircle2 className="w-3 sm:w-3.5 h-3 sm:h-3.5" />
                ) : (
                  <span className={`w-4 sm:w-5 h-4 sm:h-5 rounded-full flex items-center justify-center text-[8px] sm:text-[10px] font-bold ${isActive ? 'bg-purple-500 text-white' : 'bg-white/10 text-white/30'}`}>
                    {step.num}
                  </span>
                )}
                <span className="hidden sm:inline">{step.label}</span>
              </button>
            )
          })}
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-xl text-sm text-red-400">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit}>
          {/* Step 1: Basic Info */}
          {activeStep === 'basic' && (
            <div className="space-y-4 sm:space-y-6">
              <div className="bg-white/[0.03] border border-white/8 rounded-xl sm:rounded-2xl p-4 sm:p-6">
                <h2 className="text-base sm:text-lg font-semibold text-white mb-1">Basic Information</h2>
                <p className="text-[10px] sm:text-xs text-white/30 mb-4 sm:mb-6">Set up the core details of your content</p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div className="space-y-2">
                    <Label className="text-white/60 text-xs">Title *</Label>
                    <Input
                      value={formData.title}
                      onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                      placeholder="Enter item title"
                      className="bg-white/5 border-white/10 text-white rounded-xl focus:border-purple-500/50 focus:ring-purple-500/20"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white/60 text-xs">Category *</Label>
                    <Select value={formData.categoryId} onValueChange={(value) => setFormData(prev => ({ ...prev, categoryId: value }))}>
                      <SelectTrigger className="bg-white/5 border-white/10 text-white rounded-xl">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent className="bg-[#0f0f1a] border-white/10">
                        {categories.map((category) => (
                          <SelectItem key={category.id} value={category.id} className="text-white/80 focus:bg-white/10 focus:text-white">
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="mt-5 space-y-2">
                  <Label className="text-white/60 text-xs">Short Description</Label>
                  <Input
                    value={formData.shortDesc}
                    onChange={(e) => setFormData(prev => ({ ...prev, shortDesc: e.target.value }))}
                    placeholder="Brief description (max 200 chars)"
                    maxLength={200}
                    className="bg-white/5 border-white/10 text-white rounded-xl"
                  />
                  <p className="text-[10px] text-white/20 text-right">{formData.shortDesc.length}/200</p>
                </div>

                <div className="mt-5 space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-white/60 text-xs">Full Description *</Label>
                    <Button type="button" size="sm" onClick={generateSEO} disabled={aiGenerating}
                      className="h-7 text-[10px] bg-gradient-to-r from-violet-500/20 to-purple-500/20 hover:from-violet-500/30 hover:to-purple-500/30 text-violet-300 border border-violet-500/20 rounded-lg gap-1.5">
                      {aiGenerating ? <Loader2 className="h-3 w-3 animate-spin" /> : <Wand2 className="h-3 w-3" />}
                      AI Generate
                    </Button>
                  </div>
                  <Textarea
                    value={formData.description}
                    onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Detailed description of your content..."
                    rows={6}
                    className="bg-white/5 border-white/10 text-white rounded-xl resize-none"
                  />
                </div>
              </div>

              <div className="flex justify-end">
                <Button type="button" onClick={() => setActiveStep('details')} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-2 text-xs">
                  Next: Details <ChevronRight className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
          )}

          {/* Step 2: Details */}
          {activeStep === 'details' && (
            <div className="space-y-6">
              <div className="bg-white/[0.03] border border-white/8 rounded-2xl p-6">
                <h2 className="text-lg font-semibold text-white mb-1">Item Details</h2>
                <p className="text-xs text-white/30 mb-6">Version info, pricing, and tags</p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <div className="space-y-2">
                    <Label className="text-white/60 text-xs">Version</Label>
                    <Input
                      value={formData.gameVersion}
                      onChange={(e) => setFormData(prev => ({ ...prev, gameVersion: e.target.value }))}
                      placeholder="e.g., 1.20.1"
                      className="bg-white/5 border-white/10 text-white rounded-xl"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white/60 text-xs">Content Version</Label>
                    <Input
                      value={formData.version}
                      onChange={(e) => setFormData(prev => ({ ...prev, version: e.target.value }))}
                      placeholder="e.g., 1.0.0"
                      className="bg-white/5 border-white/10 text-white rounded-xl"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 mt-5">
                  <div className="space-y-2 col-span-1 sm:col-span-2 lg:col-span-1">
                    <Label className="text-white/60 text-xs font-semibold">Access Level</Label>
                    <Select value={formData.accessType} onValueChange={(value) => {
                      setFormData(prev => ({ 
                        ...prev, 
                        accessType: value,
                        requiredRole: value === 'ROLE' ? prev.requiredRole : '',
                        price: value === 'PAID' ? prev.price : 0
                      }))
                    }}>
                      <SelectTrigger className="bg-white/5 border-white/10 text-white rounded-lg hover:bg-white/10 transition">
                        <SelectValue placeholder="Select access level" />
                      </SelectTrigger>
                      <SelectContent className="bg-[#0f0f1a] border-white/10">
                        <SelectItem value="FREE" className="text-white/80 focus:bg-white/10 focus:text-white">🟢 Free for All</SelectItem>
                        <SelectItem value="ROLE" className="text-white/80 focus:bg-white/10 focus:text-white">👑 Membership Required</SelectItem>
                        <SelectItem value="PAID" className="text-white/80 focus:bg-white/10 focus:text-white">💎 Paid Item</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  {formData.accessType === 'ROLE' && (
                    <div className="space-y-2 col-span-1 sm:col-span-2 lg:col-span-1">
                      <Label className="text-white/60 text-xs font-semibold">Required Membership</Label>
                      <Select value={formData.requiredRole} onValueChange={(value) => setFormData(prev => ({ ...prev, requiredRole: value }))}>
                        <SelectTrigger className="bg-white/5 border-white/10 text-white rounded-lg hover:bg-white/10 transition">
                          <SelectValue placeholder="Select membership" />
                        </SelectTrigger>
                        <SelectContent className="bg-[#0f0f1a] border-white/10">
                          {memberships.map((m) => (
                            <SelectItem key={m.id} value={m.roleName} className="text-white/80 focus:bg-white/10 focus:text-white">
                              {m.name} - ${m.price}/month
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}

                  {formData.accessType === 'PAID' && (
                    <div className="space-y-2 col-span-1 sm:col-span-2 lg:col-span-1">
                      <Label className="text-white/60 text-xs font-semibold">Price ($)</Label>
                      <Input
                        type="number"
                        min="0"
                        step="0.01"
                        value={formData.price}
                        onChange={(e) => setFormData(prev => ({ ...prev, price: parseFloat(e.target.value) || 0 }))}
                        placeholder="0.00"
                        className="bg-white/5 border-white/10 text-white rounded-lg hover:bg-white/10 transition"
                      />
                    </div>
                  )}
                </div>

                <div className="mt-5 space-y-2">
                  <Label className="text-white/60 text-xs">Tags (comma-separated)</Label>
                  <Input
                    value={formData.tags}
                    onChange={(e) => setFormData(prev => ({ ...prev, tags: e.target.value }))}
                    placeholder="e.g., survival, pvp, utility"
                    className="bg-white/5 border-white/10 text-white rounded-xl"
                  />
                  {formData.tags && (
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {formData.tags.split(',').filter(t => t.trim()).map((tag, i) => (
                        <Badge key={i} className="bg-purple-500/10 text-purple-300 border-purple-500/20 text-[10px] h-5">
                          {tag.trim()}
                        </Badge>
                      ))}
                    </div>
                  )}
                </div>

                <div className="mt-5 space-y-2">
                  <Label className="text-white/60 text-xs">Additional Information</Label>
                  <Textarea
                    value={formData.moreInfo}
                    onChange={(e) => setFormData(prev => ({ ...prev, moreInfo: e.target.value }))}
                    placeholder="Installation instructions, requirements, compatibility notes..."
                    rows={4}
                    className="bg-white/5 border-white/10 text-white rounded-xl resize-none"
                  />
                </div>
              </div>

              <div className="flex justify-between">
                <Button type="button" variant="ghost" onClick={() => setActiveStep('basic')} className="text-white/50 hover:text-white hover:bg-white/5 rounded-xl text-xs">
                  <ArrowLeft className="h-3.5 w-3.5 mr-1.5" /> Back
                </Button>
                <Button type="button" onClick={() => setActiveStep('media')} className="bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl gap-2 text-xs">
                  Next: Media <ChevronRight className="h-3.5 w-3.5" />
                </Button>
              </div>
            </div>
          )}

          {/* Step 3: Media & Files */}
          {activeStep === 'media' && (
            <div className="space-y-6">
              {/* Logo */}
              <div className="bg-white/[0.03] border border-white/8 rounded-2xl p-6">
                <h2 className="text-lg font-semibold text-white mb-1">Item Logo</h2>
                <p className="text-xs text-white/30 mb-4">Square image shown on browse pages (recommended 512x512)</p>

                {logoPreview ? (
                  <div className="flex items-center gap-4 p-3 bg-white/[0.03] border border-white/8 rounded-xl">
                    <img src={logoPreview.url} alt="" className="w-16 h-16 rounded-xl object-cover border border-white/10" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-white/80 truncate">{logoPreview.name}</p>
                      <p className="text-[10px] text-white/30">Logo preview</p>
                    </div>
                    <Button type="button" variant="ghost" size="sm" onClick={removeLogo} className="text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ) : (
                  <div
                    onClick={() => logoInputRef.current?.click()}
                    className="border-2 border-dashed border-white/10 hover:border-purple-500/30 rounded-xl p-8 text-center cursor-pointer transition-all hover:bg-purple-500/[0.03] group"
                  >
                    <div className="w-12 h-12 mx-auto rounded-xl bg-white/5 flex items-center justify-center mb-3 group-hover:bg-purple-500/10 transition-colors">
                      <ImageIcon className="h-6 w-6 text-white/20 group-hover:text-purple-400 transition-colors" />
                    </div>
                    <p className="text-sm font-medium text-white/50 mb-1">Click to upload logo</p>
                    <p className="text-[10px] text-white/20">PNG, JPG, WebP</p>
                  </div>
                )}
                <input ref={logoInputRef} type="file" accept="image/*" onChange={handleLogoChange} className="hidden" />
              </div>

              {/* Content Files */}
              <div className="bg-white/[0.03] border border-white/8 rounded-2xl p-6">
                <h2 className="text-lg font-semibold text-white mb-1">Content Files {!isEditMode && '*'}</h2>
                <p className="text-xs text-white/30 mb-4">Your plugin, mod, texture pack, or map file</p>

                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-2 border-dashed border-white/10 hover:border-purple-500/30 rounded-xl p-8 text-center cursor-pointer transition-all hover:bg-purple-500/[0.03] group"
                >
                  <div className="w-12 h-12 mx-auto rounded-xl bg-white/5 flex items-center justify-center mb-3 group-hover:bg-purple-500/10 transition-colors">
                    <FileArchive className="h-6 w-6 text-white/20 group-hover:text-purple-400 transition-colors" />
                  </div>
                  <p className="text-sm font-medium text-white/50 mb-1">Drop files here or click to browse</p>
                  <p className="text-[10px] text-white/20">.zip, .rar, .jar, .mcworld, .mcpack, .mcaddon</p>
                </div>
                <input ref={fileInputRef} type="file" multiple onChange={handleFileChange} className="hidden" accept=".zip,.rar,.jar,.mcworld,.mcpack,.mcaddon" />

                {filePreviews.length > 0 && (
                  <div className="mt-4 space-y-2">
                    {filePreviews.map((file, index) => (
                      <div key={index} className="flex items-center gap-3 p-3 bg-white/[0.03] border border-white/8 rounded-xl">
                        <span className="text-lg">{getFileIcon(file.name)}</span>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-white/80 truncate">{file.name}</p>
                          <p className="text-[10px] text-white/30">{formatFileSize(file.size)}</p>
                        </div>
                        <Button type="button" variant="ghost" size="sm" onClick={() => removeFile(index)} className="text-red-400 hover:text-red-300 hover:bg-red-500/10 rounded-lg h-8 w-8 p-0">
                          <X className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Screenshots */}
              <div className="bg-white/[0.03] border border-white/8 rounded-2xl p-6">
                <h2 className="text-lg font-semibold text-white mb-1">Screenshots</h2>
                <p className="text-xs text-white/30 mb-4">Show your content in action</p>

                <div
                  onClick={() => screenshotInputRef.current?.click()}
                  className="border-2 border-dashed border-white/10 hover:border-purple-500/30 rounded-xl p-6 text-center cursor-pointer transition-all hover:bg-purple-500/[0.03] group"
                >
                  <div className="w-10 h-10 mx-auto rounded-xl bg-white/5 flex items-center justify-center mb-2 group-hover:bg-purple-500/10 transition-colors">
                    <Plus className="h-5 w-5 text-white/20 group-hover:text-purple-400 transition-colors" />
                  </div>
                  <p className="text-xs text-white/40">Add screenshots (PNG, JPG)</p>
                </div>
                <input ref={screenshotInputRef} type="file" multiple accept="image/*" onChange={handleScreenshotChange} className="hidden" />

                {screenshotPreviews.length > 0 && (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 mt-4">
                    {screenshotPreviews.map((ss, index) => (
                      <div key={index} className="relative group rounded-xl overflow-hidden border border-white/8">
                        <img src={ss.url} alt={ss.name} className="w-full h-24 object-cover" />
                        <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <Button type="button" variant="ghost" size="sm" onClick={() => removeScreenshot(index)} className="text-white hover:text-red-400 h-8 w-8 p-0">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                        <p className="absolute bottom-0 left-0 right-0 bg-black/60 text-[9px] text-white/60 px-2 py-1 truncate">{ss.name}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Submit */}
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mt-6 sm:mt-8">
                <Button type="button" variant="ghost" onClick={() => setActiveStep('details')} className="w-full sm:w-auto text-white/50 hover:text-white hover:bg-white/5 rounded-lg sm:rounded-xl text-xs sm:text-sm">
                  <ArrowLeft className="h-3.5 w-3.5 mr-1.5" /> Back
                </Button>
                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full sm:w-auto bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white border-0 rounded-lg sm:rounded-xl gap-2 px-6 sm:px-8 py-2 sm:py-2.5 text-xs sm:text-sm font-medium"
                >
                  {loading ? (
                    <><Loader2 className="h-3.5 w-3.5 sm:h-4 sm:w-4 animate-spin" /> {isEditMode ? 'Updating...' : 'Uploading...'}</>
                  ) : (
                    <><Upload className="h-3.5 w-3.5 sm:h-4 sm:w-4" /> {isEditMode ? 'Update Item' : 'Upload Item'}</>
                  )}
                </Button>
              </div>
            </div>
          )}
        </form>
      </div>
      <Footer />
    </div>
  )
}

export default function UploadPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
      </div>
    }>
      <UploadForm />
    </Suspense>
  )
}
