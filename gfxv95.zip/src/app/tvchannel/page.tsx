'use client'
import { useState, useEffect, useRef } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Search, Tv, Play, X, ChevronLeft, ChevronRight,
  Sparkles, Monitor, Globe, RefreshCw, Volume2,
  Signal, Radio,
} from 'lucide-react'

interface Channel {
  id: string; name: string; logo: string | null; url: string
  groupTitle: string; tvgCountry: string | null; isActive: boolean
  tvgLogo: string | null
}

const GROUP_COLORS: Record<string, string> = {
  'General': 'from-blue-600/40 to-indigo-900/60',
  'Sports': 'from-emerald-600/40 to-teal-900/60',
  'News': 'from-red-600/40 to-rose-900/60',
  'Entertainment': 'from-violet-600/40 to-purple-900/60',
  'Movies': 'from-amber-600/40 to-orange-900/60',
  'Music': 'from-pink-600/40 to-fuchsia-900/60',
  'Kids': 'from-cyan-500/40 to-sky-900/60',
  'Documentary': 'from-zinc-500/40 to-stone-900/60',
  'Religious': 'from-yellow-600/40 to-amber-900/60',
  'Regional': 'from-lime-600/40 to-green-900/60',
}

const getGroupColor = (group: string) => {
  for (const [key, val] of Object.entries(GROUP_COLORS)) {
    if (group.toLowerCase().includes(key.toLowerCase())) return val
  }
  const colors = Object.values(GROUP_COLORS)
  let hash = 0
  for (let i = 0; i < group.length; i++) hash = group.charCodeAt(i) + ((hash << 5) - hash)
  return colors[Math.abs(hash) % colors.length]
}

const getInitials = (name: string) => {
  const parts = name.trim().split(/\s+/)
  if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase()
  return name.slice(0, 2).toUpperCase()
}

const shimmer = `relative overflow-hidden before:absolute before:inset-0 before:-translate-x-full before:animate-[shimmer_1.5s_infinite] before:bg-gradient-to-r before:from-transparent before:via-white/5 before:to-transparent`

export default function TVChannelPage() {
  const [channels, setChannels] = useState<Channel[]>([])
  const [groups, setGroups] = useState<string[]>([])
  const [activeGroup, setActiveGroup] = useState<string>('All')
  const [search, setSearch] = useState('')
  const [playing, setPlaying] = useState<Channel | null>(null)
  const [loading, setLoading] = useState(true)
  const [hero, setHero] = useState<Channel | null>(null)
  const rowRefs = useRef<Record<string, HTMLDivElement | null>>({})

  useEffect(() => {
    fetch('/api/tvchannels').then(r => r.json()).then(data => {
      const chs = data.channels || []
      setChannels(chs)
      if (chs.length > 0) setHero(chs[Math.floor(Math.random() * Math.min(5, chs.length))])
      const gs = [...new Set(chs.map((c: Channel) => c.groupTitle))] as string[]
      setGroups(['All', ...gs])
    }).catch(() => {}).finally(() => setLoading(false))
  }, [])

  const filtered = channels.filter(c => {
    if (search && !c.name.toLowerCase().includes(search.toLowerCase())) return false
    return true
  })

  const scrollRow = (group: string, dir: 'left' | 'right') => {
    const el = rowRefs.current[group]
    if (!el) return
    const scroll = dir === 'left' ? -el.clientWidth * 0.75 : el.clientWidth * 0.75
    el.scrollBy({ left: scroll, behavior: 'smooth' })
  }

  const groupedChannels = groups.reduce((acc, g) => {
    if (g === 'All') return acc
    const chs = channels.filter(c => c.groupTitle === g)
    if (chs.length > 0) acc[g] = chs
    return acc
  }, {} as Record<string, Channel[]>)

  const ChannelCard = ({ ch, compact = false }: { ch: Channel; compact?: boolean }) => {
    const logoUrl = ch.logo || ch.tvgLogo
    const groupColor = getGroupColor(ch.groupTitle)
    const initials = getInitials(ch.name)

    return (
      <motion.button
        layout
        whileHover={{ scale: 1.05, y: -6 }}
        whileTap={{ scale: 0.98 }}
        onClick={() => setPlaying(ch)}
        className={`group/card relative rounded-xl overflow-hidden bg-white/[0.03] border border-white/[0.06] hover:border-violet-500/40 transition-all text-left ${compact ? '' : 'w-44 md:w-52'} flex-shrink-0`}
        style={{ scrollSnapAlign: 'start' }}
      >
        <div className={`${compact ? 'aspect-[4/3]' : 'aspect-[16/9]'} relative flex items-center justify-center overflow-hidden bg-gradient-to-br ${groupColor}`}>
          {logoUrl ? (
            <img src={logoUrl} className="w-full h-full object-contain p-4 group-hover/card:scale-110 transition-transform duration-500"
              onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; (e.target as HTMLImageElement).nextElementSibling?.classList.remove('hidden') }} />
          ) : null}
          <div className={`${logoUrl ? 'hidden' : ''} flex flex-col items-center justify-center w-full h-full`}>
            <div className="w-14 h-14 md:w-16 md:h-16 rounded-2xl bg-white/10 backdrop-blur-sm flex items-center justify-center mb-2 border border-white/20 shadow-xl">
              <span className="text-xl md:text-2xl font-black text-white drop-shadow-lg">{initials}</span>
            </div>
          </div>
          <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-transparent to-transparent" />
          <Badge className="absolute top-2 right-2 bg-red-600/90 text-white text-[9px] border-0 px-1.5 py-0.5 flex items-center gap-1 shadow-lg">
            <Signal className="w-2.5 h-2.5 animate-pulse" /> LIVE
          </Badge>
          {ch.groupTitle && (
            <Badge className="absolute top-2 left-2 bg-black/50 text-white/80 text-[8px] border-0 px-1.5 py-0.5 backdrop-blur-sm truncate max-w-[80px]">
              {ch.groupTitle}
            </Badge>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover/card:opacity-100 transition-opacity duration-300 flex items-center justify-center">
            <div className="w-12 h-12 rounded-full bg-violet-600/95 flex items-center justify-center shadow-lg shadow-violet-500/40 backdrop-blur-sm">
              <Play className="w-5 h-5 text-white fill-current ml-0.5" />
            </div>
          </div>
        </div>
        <div className="p-3">
          <p className="text-sm font-bold text-white/90 group-hover/card:text-white truncate leading-tight">{ch.name}</p>
          <p className="text-[10px] text-white/40 truncate mt-1 flex items-center gap-1">
            <Radio className="w-2.5 h-2.5 inline" /> {ch.groupTitle}
            {ch.tvgCountry && <><span className="text-white/20">·</span> <Globe className="w-2.5 h-2.5 inline" /> {ch.tvgCountry}</>}
          </p>
        </div>
      </motion.button>
    )
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <Navbar />

      {/* Hero Banner */}
      {hero && !loading && (
        <div className="relative h-[55vh] min-h-[400px] w-full overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-black/20 z-10" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-transparent to-black/50 z-10" />
          <div className={`absolute inset-0 bg-gradient-to-br ${getGroupColor(hero.groupTitle)} opacity-50 z-0`} />
          <div className="absolute inset-0 flex items-end z-20 p-8 md:p-16">
            <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="max-w-2xl">
              <div className="flex items-center gap-2 mb-4">
                <Badge className="bg-violet-500/20 text-violet-300 border-violet-500/30 px-3 py-1 text-xs">
                  <Sparkles className="w-3 h-3 mr-1" /> Featured Channel
                </Badge>
                <Badge className="bg-red-500/20 text-red-300 border-red-500/30 px-2 py-1 text-[10px] flex items-center gap-1">
                  <Signal className="w-2.5 h-2.5 animate-pulse" /> LIVE
                </Badge>
              </div>
              <h1 className="text-4xl md:text-6xl font-black text-white mb-3 leading-tight drop-shadow-lg">
                {hero.name}
              </h1>
              <p className="text-white/50 text-sm md:text-base mb-6 flex items-center gap-3 flex-wrap">
                <span className="flex items-center gap-1"><Monitor className="w-3.5 h-3.5" /> {hero.groupTitle}</span>
                {hero.tvgCountry && <span className="flex items-center gap-1"><Globe className="w-3.5 h-3.5" /> {hero.tvgCountry}</span>}
                <span className="flex items-center gap-1 text-emerald-400"><Signal className="w-3 h-3" /> Live Now</span>
              </p>
              <div className="flex gap-3">
                <Button onClick={() => setPlaying(hero)}
                  className="bg-violet-600 hover:bg-violet-500 text-white rounded-full px-8 h-12 text-base font-bold shadow-lg shadow-violet-500/25">
                  <Play className="w-5 h-5 mr-2 fill-current" /> Watch Now
                </Button>
                <Button variant="outline"
                  className="border-white/20 text-white/70 hover:text-white hover:border-white/40 rounded-full px-6 h-12 text-base">
                  <Volume2 className="w-5 h-5 mr-2" /> More Info
                </Button>
              </div>
            </motion.div>
          </div>
        </div>
      )}

      {loading && (
        <div className="h-[55vh] min-h-[400px] flex items-center justify-center bg-black">
          <RefreshCw className="w-8 h-8 text-violet-400 animate-spin" />
        </div>
      )}

      <div className="relative z-30 -mt-12 px-4 md:px-8 pb-16">
        {/* Search & Filter Bar */}
        <div className="flex flex-col md:flex-row gap-4 mb-8 items-start md:items-center justify-between">
          <div className="flex gap-2 overflow-x-auto scrollbar-hide max-w-full pb-1">
            {groups.slice(0, 15).map(g => (
              <button key={g} onClick={() => setActiveGroup(g)}
                className={`whitespace-nowrap px-4 py-1.5 rounded-full text-sm font-medium transition-all ${
                  activeGroup === g
                    ? 'bg-violet-600 text-white shadow-lg shadow-violet-500/20'
                    : 'bg-white/5 text-white/50 hover:text-white hover:bg-white/10'
                }`}>
                {g === 'All' ? `All (${channels.length})` : g}
              </button>
            ))}
          </div>
          <div className="relative w-full md:w-72">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
            <Input value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Search channels..."
              className="pl-9 bg-white/5 border-white/10 text-white rounded-full text-sm placeholder:text-white/30 h-10" />
          </div>
        </div>

        {/* Category Rows */}
        {activeGroup === 'All' ? (
          <>
            {Object.entries(groupedChannels).map(([group, chs]) => {
              if (search && !chs.some(c => c.name.toLowerCase().includes(search.toLowerCase()))) return null
              const filteredChs = search ? chs.filter(c => c.name.toLowerCase().includes(search.toLowerCase())) : chs
              if (filteredChs.length === 0) return null
              return (
                <motion.section key={group} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mb-8">
                  <div className="flex items-center gap-3 mb-4">
                    <div className={`w-1 h-6 rounded-full bg-gradient-to-b ${getGroupColor(group).replace('from-', 'from-').split(' ')[0] || 'bg-violet-500'}`} />
                    <h2 className="text-xl font-bold text-white">{group}</h2>
                    <Badge className="bg-white/5 text-white/40 text-xs">{filteredChs.length}</Badge>
                  </div>
                  <div className="relative group/row">
                    <button onClick={() => scrollRow(group, 'left')}
                      className="absolute left-0 top-0 bottom-0 z-10 w-12 opacity-0 group-hover/row:opacity-100 transition-opacity flex items-center justify-center bg-gradient-to-r from-black/80 to-transparent rounded-l-xl">
                      <ChevronLeft className="w-6 h-6 text-white drop-shadow-lg" />
                    </button>
                    <div ref={el => { rowRefs.current[group] = el }}
                      className="flex gap-3 overflow-x-auto scrollbar-hide pb-2" style={{ scrollSnapType: 'x mandatory' }}>
                      {filteredChs.map(ch => <ChannelCard key={ch.id} ch={ch} />)}
                    </div>
                    <button onClick={() => scrollRow(group, 'right')}
                      className="absolute right-0 top-0 bottom-0 z-10 w-12 opacity-0 group-hover/row:opacity-100 transition-opacity flex items-center justify-center bg-gradient-to-l from-black/80 to-transparent rounded-r-xl">
                      <ChevronRight className="w-6 h-6 text-white drop-shadow-lg" />
                    </button>
                  </div>
                </motion.section>
              )
            })}
            {loading && (
              <div className="space-y-8">
                {[1, 2, 3].map(i => (
                  <div key={i}>
                    <Skeleton className="h-6 w-48 mb-4 bg-white/5" />
                    <div className="flex gap-3">
                      {[1, 2, 3, 4].map(j => (
                        <div key={j} className={`flex-shrink-0 w-44 ${shimmer}`}>
                          <Skeleton className="aspect-[16/9] rounded-xl bg-white/5" />
                          <Skeleton className="h-4 w-32 mt-3 bg-white/5" />
                          <Skeleton className="h-3 w-20 mt-2 bg-white/5" />
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        ) : (
          /* Single Category Grid */
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
            className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
            {filtered.filter(c => c.groupTitle === activeGroup).map(ch => (
              <div key={ch.id} className="w-auto" style={{ scrollSnapAlign: 'start' }}>
                <ChannelCard ch={ch} compact />
              </div>
            ))}
            {!loading && filtered.filter(c => c.groupTitle === activeGroup).length === 0 && (
              <div className="col-span-full text-center py-20 text-white/30">
                <Tv className="w-12 h-12 mx-auto mb-4 opacity-30" />
                <p className="font-bold text-lg">No channels found</p>
                <p className="text-sm">Try a different category or search term</p>
              </div>
            )}
          </motion.div>
        )}

        {!loading && !search && activeGroup === 'All' && Object.keys(groupedChannels).length > 0 && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="mt-8 text-center">
            <p className="text-white/30 text-sm">
              {channels.length} channels across {groups.length - 1} categories
            </p>
          </motion.div>
        )}
      </div>

      {/* Player Modal */}
      <AnimatePresence>
        {playing && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-xl">
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="relative w-full max-w-5xl mx-4">
              <div className="rounded-2xl overflow-hidden border border-white/[0.1] bg-black shadow-2xl shadow-violet-500/10">
                <div className="flex items-center justify-between px-5 py-3 bg-white/[0.03] border-b border-white/[0.05]">
                  <div className="flex items-center gap-3 min-w-0">
                    <div className={`w-8 h-8 rounded-lg bg-gradient-to-br ${getGroupColor(playing.groupTitle)} flex items-center justify-center flex-shrink-0`}>
                      {(playing.logo || playing.tvgLogo) ? (
                        <img src={playing.logo || playing.tvgLogo || ''} className="w-6 h-6 rounded object-contain"
                          onError={(e) => { (e.target as HTMLImageElement).style.display = 'none' }} />
                      ) : (
                        <span className="text-[10px] font-black text-white">{getInitials(playing.name)}</span>
                      )}
                    </div>
                    <div className="min-w-0">
                      <p className="font-bold text-white text-sm truncate">{playing.name}</p>
                      <p className="text-[10px] text-white/40 truncate flex items-center gap-1">
                        {playing.groupTitle}
                        {playing.tvgCountry && <><span className="text-white/20">·</span> {playing.tvgCountry}</>}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className="bg-red-500/10 text-red-300 border-red-500/20 text-[10px] flex items-center gap-1">
                      <Signal className="w-2.5 h-2.5 animate-pulse" /> LIVE
                    </Badge>
                    <button onClick={() => setPlaying(null)}
                      className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors">
                      <X className="w-4 h-4 text-white/60" />
                    </button>
                  </div>
                </div>
                <div className="aspect-video bg-black relative">
                  {playing.url.endsWith('.m3u8') ? (
                    <video controls autoPlay className="w-full h-full" playsInline>
                      <source src={playing.url} type="application/x-mpegURL" />
                    </video>
                  ) : (
                    <iframe src={playing.url} className="w-full h-full" allowFullScreen
                      allow="autoplay; encrypted-media" style={{ border: 0 }} />
                  )}
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <Footer />
    </div>
  )
}
