'use client'

import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Loader2, Users, Handshake, AlertTriangle } from 'lucide-react'
import { toast } from 'sonner'

type Collaboration = {
  id: string
  revenueShare: number
  status: string
  createdAt: string
  item: {
    id: string
    title: string
    slug: string
    price: number
    downloads: number
    logo?: string | null
    author: { username: string }
  }
}

export default function CollaborationsPage() {
  const { data: session, status } = useSession()
  const router = useRouter()

  const [collaborations, setCollaborations] = useState<Collaboration[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin')
  }, [status, router])

  useEffect(() => {
    if (status !== 'authenticated') return
    const load = async () => {
      setLoading(true)
      try {
        const res = await fetch('/api/collaborations')
        if (res.ok) {
          const data = await res.json()
          setCollaborations(Array.isArray(data.collaborations) ? data.collaborations : [])
        } else {
          toast.error('Failed to load collaborations')
        }
      } catch {
        toast.error('Failed to load collaborations')
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [status])

  if (loading) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />

      <div className="container mx-auto px-4 py-10 max-w-5xl">
        <div className="flex items-start justify-between gap-4 flex-wrap mb-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Handshake className="w-5 h-5 text-purple-400" />
              <h1 className="text-2xl font-bold">Collaborations</h1>
            </div>
            <p className="text-sm text-white/40">Items where you are a collaborator</p>
          </div>
          <Link href="/dashboard">
            <Button variant="ghost" className="text-white/60 hover:bg-white/5 rounded-xl text-sm">
              Back to Dashboard
            </Button>
          </Link>
        </div>

        {collaborations.length === 0 ? (
          <div className="bg-white/[0.02] border border-white/5 rounded-2xl p-8 text-center">
            <AlertTriangle className="w-10 h-10 text-white/10 mx-auto mb-3" />
            <p className="text-white/30">No collaborations yet.</p>
            <p className="text-white/40 text-sm mt-1">
              When an item owner adds you as a collaborator, it will show up here.
            </p>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-4">
            {collaborations.map((c) => (
              <div
                key={c.id}
                className="bg-white/[0.03] border border-white/8 rounded-2xl p-5 hover:bg-white/[0.06] transition-colors"
              >
                <div className="flex items-start justify-between gap-4 mb-3">
                  <div className="flex items-start gap-3 min-w-0">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500/20 to-blue-500/20 border border-white/10 flex items-center justify-center overflow-hidden flex-shrink-0">
                      {c.item.logo ? (
                        <img src={c.item.logo} alt={c.item.title} className="w-full h-full object-cover" />
                      ) : (
                        <Users className="w-5 h-5 text-white/20" />
                      )}
                    </div>

                    <div className="min-w-0">
                      <Link href={`/items/${c.item.slug}`}>
                        <p className="text-sm font-semibold text-white/90 truncate hover:text-purple-300 transition-colors">
                          {c.item.title}
                        </p>
                      </Link>
                      <p className="text-xs text-white/40 mt-1">
                        by {c.item.author.username}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-between gap-3 flex-wrap">
                  <Badge className="bg-purple-500/10 text-purple-300 border-purple-500/20 text-[10px] h-6 flex items-center">
                    Revenue Share: {c.revenueShare}%
                  </Badge>
                  <Badge
                    className={`text-[10px] h-6 ${
                      c.status === 'APPROVED'
                        ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
                        : c.status === 'PENDING'
                          ? 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20'
                          : 'bg-white/5 text-white/40 border-white/10'
                    }`}
                  >
                    {c.status}
                  </Badge>
                </div>

                <p className="text-xs text-white/30 mt-3">
                  {new Date(c.createdAt).toLocaleDateString()}
                </p>
              </div>
            ))}
          </div>
        )}
      </div>

      <Footer />
    </div>
  )
}

