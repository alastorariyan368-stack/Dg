'use client'

import { useState, useEffect } from 'react'
import { useSession } from 'next-auth/react'
import { useParams } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { User, Globe, Github, Twitter, MessageCircle, Package, Star, Download, Heart, CheckCircle, Award, Loader2, TrendingUp } from 'lucide-react'
import { toast } from 'sonner'
import Link from 'next/link'

const LEVEL_NAMES = ['', 'Starter', 'Rising', 'Pro', 'Elite', 'Legend']
const LEVEL_COLORS = ['', 'text-gray-400', 'text-blue-400', 'text-purple-400', 'text-orange-400', 'text-yellow-400']
const LEVEL_BG = ['', 'bg-gray-500/10 border-gray-500/20', 'bg-blue-500/10 border-blue-500/20', 'bg-purple-500/10 border-purple-500/20', 'bg-orange-500/10 border-orange-500/20', 'bg-yellow-500/10 border-yellow-500/20']

export default function PublicProfilePage() {
  const { username } = useParams()
  const { data: session } = useSession()
  const [profile, setProfile] = useState<any>(null)
  const [items, setItems] = useState<any[]>([])
  const [reviews, setReviews] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [following, setFollowing] = useState(false)
  const [followLoading, setFollowLoading] = useState(false)

  useEffect(() => {
    if (username) loadProfile()
  }, [username])

  const loadProfile = async () => {
    setLoading(true)
    try {
      const [profileRes, itemsRes] = await Promise.all([
        fetch(`/api/users/profile/${username}`),
        fetch(`/api/items?username=${username}&status=APPROVED&limit=20`)
      ])
      if (profileRes.ok) {
        const data = await profileRes.json()
        setProfile(data)
        setFollowing(data.isFollowing || false)
      } else {
        toast.error('User not found')
      }
      if (itemsRes.ok) {
        const data = await itemsRes.json()
        setItems(data.items || [])
      }
    } catch { toast.error('Failed to load profile') } finally { setLoading(false) }
  }

  const toggleFollow = async () => {
    if (!session) { toast.error('Sign in to follow'); return }
    setFollowLoading(true)
    try {
      const res = await fetch('/api/follow', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ followingId: profile.id }) })
      if (res.ok) {
        setFollowing(!following)
        setProfile((p: any) => ({ ...p, _count: { ...p._count, followers: following ? p._count.followers - 1 : p._count.followers + 1 } }))
      }
    } catch { } finally { setFollowLoading(false) }
  }

  if (loading) return (
    <div className="min-h-screen bg-[#0a0a0f] flex items-center justify-center">
      <Loader2 className="w-8 h-8 animate-spin text-purple-400" />
    </div>
  )

  if (!profile) return (
    <div className="min-h-screen bg-[#0a0a0f] text-white flex items-center justify-center">
      <div className="text-center">
        <User className="w-16 h-16 mx-auto text-white/10 mb-4" />
        <h2 className="text-xl font-bold">User not found</h2>
        <p className="text-white/40 text-sm mt-2">This user doesn't exist or has been removed</p>
        <Link href="/browse"><Button className="mt-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white border-0 rounded-xl">Browse Items</Button></Link>
      </div>
    </div>
  )

  const level = profile.sellerLevel || 1
  const isCreator = ['CREATOR', 'ADMIN', 'SUPER_ADMIN', 'MODERATOR'].includes(profile.role)
  const isOwnProfile = session?.user?.id === profile.id

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />

      {/* Cover */}
      <div className="h-32 md:h-44 bg-gradient-to-br from-purple-900/30 via-blue-900/20 to-[#0a0a0f] border-b border-white/5 relative overflow-hidden">
        
        <div className="absolute inset-0 bg-gradient-to-t from-[#0a0a0f] to-transparent" />
      </div>

      <div className="container mx-auto px-4 max-w-5xl -mt-12 pb-8 relative">
        {/* Profile card */}
        <div className="bg-[#0f0f1a] border border-white/10 rounded-2xl p-6 mb-6">
          <div className="flex items-start justify-between flex-wrap gap-4">
            <div className="flex items-end gap-4">
              <div className="w-20 h-20 rounded-2xl border-2 border-purple-500/30 overflow-hidden bg-gradient-to-br from-purple-900 to-blue-900 flex-shrink-0">
                {profile.avatar ? <img src={profile.avatar} alt={profile.username} className="w-full h-full object-cover" /> : <User className="w-8 h-8 text-white/30 m-auto mt-6" />}
              </div>
              <div className="pb-1">
                <div className="flex items-center gap-2 flex-wrap">
                  <h1 className="text-xl font-bold text-white">{profile.username}</h1>
                  {profile.isVerified && <CheckCircle className="w-4 h-4 text-blue-400" />}
                  {isCreator && (
                    <Badge className={`text-[10px] border ${LEVEL_BG[level]}`}>
                      <Award className={`w-3 h-3 mr-1 ${LEVEL_COLORS[level]}`} />
                      <span className={LEVEL_COLORS[level]}>Lv.{level} {LEVEL_NAMES[level]}</span>
                    </Badge>
                  )}
                  <Badge className="text-[10px] bg-white/5 text-white/30 border-white/10 capitalize">{profile.role?.toLowerCase()?.replace('_', ' ')}</Badge>
                </div>
                <p className="text-xs text-white/30 mt-0.5">Member since {new Date(profile.createdAt).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}</p>
                {profile.bio && <p className="text-sm text-white/60 mt-2 max-w-lg">{profile.bio}</p>}
                <div className="flex items-center gap-3 mt-2 flex-wrap">
                  {profile.socialLinks?.website && <a href={profile.socialLinks.website} target="_blank" rel="noreferrer" className="text-xs text-white/40 hover:text-white/70 flex items-center gap-1"><Globe className="h-3 w-3" />{profile.socialLinks.website.replace(/^https?:\/\//, '')}</a>}
                  {profile.socialLinks?.github && <a href={`https://github.com/${profile.socialLinks.github}`} target="_blank" rel="noreferrer" className="text-xs text-white/40 hover:text-white/70 flex items-center gap-1"><Github className="h-3 w-3" />{profile.socialLinks.github}</a>}
                  {profile.socialLinks?.twitter && <a href={`https://twitter.com/${profile.socialLinks.twitter}`} target="_blank" rel="noreferrer" className="text-xs text-white/40 hover:text-white/70 flex items-center gap-1"><Twitter className="h-3 w-3" />@{profile.socialLinks.twitter}</a>}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              {!isOwnProfile && session && (
                <>
                  <Button onClick={toggleFollow} disabled={followLoading} size="sm" className={`rounded-xl text-xs gap-1.5 border-0 ${following ? 'bg-white/10 text-white/70 hover:bg-white/15' : 'bg-gradient-to-r from-purple-600 to-blue-600 text-white'}`}>
                    <Heart className={`h-3.5 w-3.5 ${following ? 'fill-current text-pink-400' : ''}`} />
                    {following ? 'Following' : 'Follow'}
                  </Button>
                  <Link href={`/messages?userId=${profile.id}`}>
                    <Button size="sm" className="bg-white/5 hover:bg-white/10 text-white/70 border border-white/10 rounded-xl text-xs gap-1.5">
                      <MessageCircle className="h-3.5 w-3.5" />Message
                    </Button>
                  </Link>
                </>
              )}
              {isOwnProfile && <Link href="/profile"><Button size="sm" className="bg-white/5 text-white/70 border border-white/10 rounded-xl text-xs">Edit Profile</Button></Link>}
            </div>
          </div>

          {/* Stats bar */}
          <div className="grid grid-cols-3 sm:grid-cols-5 gap-3 mt-5 pt-4 border-t border-white/5">
            {[
              { label: 'Items', value: profile._count?.items || 0, icon: Package, color: 'text-purple-400' },
              { label: 'Followers', value: profile._count?.followers || 0, icon: Heart, color: 'text-pink-400' },
              { label: 'Following', value: profile._count?.following || 0, icon: User, color: 'text-blue-400' },
              { label: 'Sales', value: profile.totalSales || 0, icon: TrendingUp, color: 'text-green-400' },
              { label: 'Downloads', value: items.reduce((s: number, i: any) => s + (i.downloads || 0), 0), icon: Download, color: 'text-cyan-400' },
            ].map(stat => (
              <div key={stat.label} className="text-center">
                <stat.icon className={`w-4 h-4 mx-auto mb-1 ${stat.color}`} />
                <p className="text-lg font-bold text-white">{stat.value >= 1000 ? (stat.value / 1000).toFixed(1) + 'K' : stat.value}</p>
                <p className="text-[10px] text-white/30">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Items */}
        <Tabs defaultValue="items">
          <TabsList className="bg-white/5 border border-white/10 rounded-xl p-1 mb-5 h-auto">
            <TabsTrigger value="items" className="rounded-lg text-white/50 data-[state=active]:bg-white/10 data-[state=active]:text-white text-xs px-3 py-2">Items ({items.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="items">
            {items.length === 0 ? (
              <div className="text-center py-16 bg-white/[0.02] border border-white/5 rounded-2xl">
                <Package className="w-12 h-12 mx-auto text-white/10 mb-3" />
                <p className="text-white/40">No items uploaded yet</p>
              </div>
            ) : (
              <div className="grid sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {items.map((item: any) => (
                  <Link key={item.id} href={`/items/${item.slug}`}>
                    <div className="group bg-white/[0.03] hover:bg-white/[0.06] border border-white/8 hover:border-purple-500/20 rounded-2xl overflow-hidden transition-all">
                      <div className="h-28 bg-gradient-to-br from-purple-900/20 to-blue-900/10 flex items-center justify-center border-b border-white/5 overflow-hidden">
                        {item.logo ? <img src={item.logo} alt={item.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" /> : <Package className="w-8 h-8 text-white/10" />}
                      </div>
                      <div className="p-3">
                        <h3 className="text-sm font-medium text-white/90 line-clamp-1 group-hover:text-purple-300 transition-colors">{item.title}</h3>
                        <div className="flex items-center justify-between mt-2">
                          <div className="flex items-center gap-2 text-xs text-white/30">
                            <span className="flex items-center gap-1"><Download className="h-3 w-3" />{item.downloads || 0}</span>
                            <span className="flex items-center gap-1"><Star className="h-3 w-3 text-yellow-400" />{item._count?.reviews || 0}</span>
                          </div>
                          <span className={`text-xs font-bold ${item.price === 0 ? 'text-green-400' : 'text-white/70'}`}>{item.price === 0 ? 'Free' : `$${item.price.toFixed(2)}`}</span>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
      <Footer />
    </div>
  )
}
