'use client'
import { useState, useEffect, useRef, useCallback } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { motion, AnimatePresence } from 'framer-motion'
import {
  Search, Play, X, Clock, TrendingUp, Sparkles,
  Grid3X3, User, Film, AlertTriangle, Home,
  ChevronLeft, ChevronRight, Loader2,
} from 'lucide-react'

const AGE_KEY = 'adult_age_verified'

interface Video {
  id: string; title: string; thumbnail?: string; duration?: string; url?: string
}

export default function AdultPage() {
  const [verified, setVerified] = useState(false)
  const [videos, setVideos] = useState<Video[]>([])
  const [categories, setCategories] = useState<string[]>([])
  const [pornstars, setPornstars] = useState<string[]>([])
  const [searchQuery, setSearchQuery] = useState('')
  const [playing, setPlaying] = useState<Video | null>(null)
  const [activeMode, setActiveMode] = useState<'trending' | string>('trending')
  const [heroVideo, setHeroVideo] = useState<Video | null>(null)
  const [loading, setLoading] = useState(true)
  const [loadingMore, setLoadingMore] = useState(false)
  const [searching, setSearching] = useState(false)
  const [showGate, setShowGate] = useState(false)
  const [page, setPage] = useState(1)
  const [hasMore, setHasMore] = useState(true)
  const [totalCount, setTotalCount] = useState(0)
  const rowRefs = useRef<Record<string, HTMLDivElement | null>>({})
  const sentinelRef = useRef<HTMLDivElement | null>(null)
  const observerRef = useRef<IntersectionObserver | null>(null)

  useEffect(() => {
    if (localStorage.getItem(AGE_KEY) === 'true') { setVerified(true); fetchTrending() }
    else { setShowGate(true); setLoading(false) }
  }, [])

  useEffect(() => {
    if (!verified || loading || loadingMore || !hasMore || videos.length === 0) return
    if (observerRef.current) observerRef.current.disconnect()
    observerRef.current = new IntersectionObserver((entries) => {
      if (entries[0].isIntersecting && !loadingMore && hasMore) {
        loadMore()
      }
    }, { rootMargin: '400px' })
    if (sentinelRef.current) observerRef.current.observe(sentinelRef.current)
    return () => observerRef.current?.disconnect()
  }, [verified, loading, loadingMore, hasMore, videos.length])

  const LIMIT = 100

  const fetchTrending = async (pg = 1, append = false) => {
    if (!append) setLoading(true)
    try {
      const [trendRes, catRes, starRes] = await Promise.all([
        fetch(`/api/adult/trending-with-details?page=${pg}&limit=${LIMIT}`).then(r => r.json()),
        fetch('/api/adult/categories').then(r => r.json()),
        fetch('/api/adult/pornstar').then(r => r.json()),
      ])
      const vids = trendRes?.videos || []
      if (append) setVideos(prev => [...prev, ...vids])
      else setVideos(vids)
      setHasMore(vids.length >= LIMIT)
      setTotalCount(prev => append ? prev + vids.length : vids.length)
      if (!append && vids.length > 0) setHeroVideo(vids[Math.floor(Math.random() * Math.min(5, vids.length))])
      if (catRes?.categories) setCategories(catRes.categories.map((c: any) => c.name))
      if (Array.isArray(starRes)) setPornstars(starRes.slice(0, 20))
      else if (starRes?.topPornstars) setPornstars(starRes.topPornstars.slice(0, 20))
      else if (starRes?.pornstars) setPornstars(starRes.pornstars.slice(0, 20))
    } catch (e) { console.error(e) }
    setLoading(false)
  }

  const loadCategory = async (name: string, pg = 1, append = false) => {
    setActiveMode(name)
    setSearchQuery('')
    if (!append) { setLoading(true); setPage(1); setTotalCount(0) }
    try {
      const res = await fetch(`/api/adult/category-with-details?name=${encodeURIComponent(name)}&page=${pg}&limit=${LIMIT}`)
      const data = await res.json()
      const vids = data?.videos || []
      if (append) setVideos(prev => [...prev, ...vids])
      else setVideos(vids)
      setHasMore(vids.length >= LIMIT)
      setTotalCount(prev => append ? prev + vids.length : vids.length)
    } catch (e) { console.error(e); if (!append) setVideos([]) }
    if (!append) setLoading(false)
  }

  const handleSearch = async (pg = 1, append = false) => {
    if (!searchQuery.trim()) return
    setActiveMode('search')
    if (!append) { setSearching(true); setLoading(true); setPage(1); setTotalCount(0) }
    try {
      const res = await fetch(`/api/adult/search/${encodeURIComponent(searchQuery)}?page=${pg}&limit=50`)
      const data = await res.json()
      const ids = data?.videos || []
      if (!ids.length) { if (!append) setVideos([]); setHasMore(false); return }
      const details = await Promise.allSettled(
        ids.map((id: string) =>
          fetch(`/api/adult/video/${id}?puppeteer=false`).then(r => r.json())
        )
      )
      const vids = details
        .filter(r => r.status === 'fulfilled' && r.value?.title)
        .map(r => (r as PromiseFulfilledResult<any>).value)
        .map((v: any) => ({ id: v.video_id, title: v.title, thumbnail: v.thumbnail, duration: v.length, url: v.url }))
      if (append) setVideos(prev => [...prev, ...vids])
      else setVideos(vids)
      setHasMore(vids.length >= 50)
      setTotalCount(prev => append ? prev + vids.length : vids.length)
    } catch (e) { console.error(e); if (!append) setVideos([]) }
    if (!append) { setLoading(false); setSearching(false) }
  }

  const loadMore = useCallback(() => {
    const nextPage = page + 1
    setPage(nextPage)
    setLoadingMore(true)
    const done = () => setLoadingMore(false)
    if (activeMode === 'trending') fetchTrending(nextPage, true).then(done)
    else if (categories.includes(activeMode)) loadCategory(activeMode, nextPage, true).then(done)
    else if (activeMode === 'search') handleSearch(nextPage, true).then(done)
    else done()
  }, [page, activeMode, categories])

  const scrollRow = (key: string, dir: 'left' | 'right') => {
    const el = rowRefs.current[key]
    if (!el) return
    el.scrollBy({ left: dir === 'left' ? -el.clientWidth * 0.75 : el.clientWidth * 0.75, behavior: 'smooth' })
  }

  const acceptAge = () => {
    localStorage.setItem(AGE_KEY, 'true')
    setVerified(true); setShowGate(false); fetchTrending()
  }

  if (!verified) {
    return (
      <div className="min-h-screen bg-black text-white">
        <Navbar />
        <AnimatePresence>
          {showGate && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
              className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-2xl">
              <motion.div initial={{ scale: 0.8, opacity: 0, y: 40 }}
                animate={{ scale: 1, opacity: 1, y: 0 }}
                transition={{ type: 'spring', damping: 20, stiffness: 200 }}
                className="max-w-md w-full mx-4 p-8 rounded-3xl border border-white/[0.08] bg-gradient-to-b from-white/[0.04] to-white/[0.01] text-center">
                <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center">
                  <AlertTriangle className="w-10 h-10 text-red-400" />
                </div>
                <h1 className="text-3xl font-black text-white mb-2">Are you 18+?</h1>
                <p className="text-white/40 text-sm mb-8 leading-relaxed">
                  This section contains adult content. You must be at least 18 to enter.
                </p>
                <div className="flex flex-col gap-3">
                  <Button onClick={acceptAge}
                    className="bg-red-600 hover:bg-red-500 text-white rounded-full h-14 text-lg font-bold shadow-lg shadow-red-500/25">
                    Yes, I am 18+
                  </Button>
                  <Button onClick={() => window.location.href = '/'} variant="outline"
                    className="border-white/10 text-white/50 hover:text-white hover:border-white/30 rounded-full h-12">
                    No, take me back
                  </Button>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-black text-white">
      <Navbar />

      {/* Hero Video Player */}
      {heroVideo && activeMode === 'trending' && !loading && (
        <div className="relative w-full overflow-hidden" style={{ height: 'min(75vh, 650px)' }}>
          <div className="absolute inset-0 bg-gradient-to-b from-black/20 via-black/5 to-black z-10 pointer-events-none" />
          <iframe src={`https://www.pornhub.com/embed/${heroVideo.id}?autoplay=1`}
            className="absolute inset-0 w-full h-[120%] -top-[10%]"
            allow="autoplay; encrypted-media"
            style={{ border: 0, pointerEvents: 'none' }} />
          <div className="absolute bottom-0 left-0 right-0 z-20 p-6 md:p-12 bg-gradient-to-t from-black via-black/70 to-transparent">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="max-w-3xl">
              <Badge className="mb-3 bg-red-500/20 text-red-300 border-red-500/30 text-xs px-3 py-1">
                <Sparkles className="w-3 h-3 mr-1" /> Featured
              </Badge>
              <h1 className="text-xl md:text-3xl font-black text-white mb-2 line-clamp-2">{heroVideo.title}</h1>
              <div className="flex items-center gap-3 text-sm text-white/50 mb-4">
                {heroVideo.duration && <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" />{heroVideo.duration}</span>}
              </div>
              <Button onClick={() => setPlaying(heroVideo)}
                className="bg-red-600 hover:bg-red-500 text-white rounded-full px-8 h-12 text-base font-bold shadow-lg shadow-red-500/25">
                <Play className="w-5 h-5 mr-2 fill-current" /> Watch Now
              </Button>
            </motion.div>
          </div>
        </div>
      )}

      {/* Nav Pills */}
      <div className="sticky top-0 z-30 bg-black/90 backdrop-blur-lg border-b border-white/[0.05]">
        <div className="px-4 md:px-8 py-3">
          <div className="flex items-center gap-2 overflow-x-auto scrollbar-hide max-w-full pb-1">
            <button onClick={() => { setActiveMode('trending'); setSearchQuery(''); fetchTrending() }}
              className={`flex items-center gap-1.5 whitespace-nowrap px-4 py-1.5 rounded-full text-xs font-bold transition-all ${
                activeMode === 'trending' ? 'bg-red-600 text-white shadow-lg shadow-red-500/20' : 'bg-white/5 text-white/50 hover:text-white hover:bg-white/10'}`}>
              <Home className="w-3 h-3" /> Home
            </button>
            {categories.slice(0, 20).map(cat => (
              <button key={cat} onClick={() => loadCategory(cat)}
                className={`whitespace-nowrap px-3 py-1.5 rounded-full text-[11px] font-medium transition-all ${
                  activeMode === cat ? 'bg-red-600 text-white shadow-lg shadow-red-500/20' : 'bg-white/5 text-white/50 hover:text-white hover:bg-white/10'}`}>
                {cat}
              </button>
            ))}
          </div>
          {/* Search */}
          <div className="relative mt-3 max-w-xl">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-white/30" />
            <Input value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSearch()}
              placeholder="Search Pornhub videos..."
              className="pl-9 pr-20 bg-white/5 border-white/10 text-white rounded-full text-xs h-9 placeholder:text-white/30" />
            <Button onClick={handleSearch} disabled={searching}
              className="absolute right-1 top-1/2 -translate-y-1/2 h-7 px-3 bg-red-600 hover:bg-red-500 text-white rounded-full text-[10px]">
              {searching ? '...' : 'Search'}
            </Button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-4 md:px-8 py-6">
        <div className="max-w-7xl mx-auto">
          {/* Section Header */}
          <div className="flex items-center gap-3 mb-5">
            <div className="w-1 h-6 bg-red-500 rounded-full" />
            <h2 className="text-xl font-black text-white capitalize">
              {activeMode === 'trending' ? 'Trending Now' : activeMode === 'search' ? `Search: ${searchQuery}` : activeMode}
            </h2>
            {!loading && <Badge className="bg-white/5 text-white/40 text-[10px]">{totalCount || videos.length}</Badge>}
          </div>

          {loading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
              {Array.from({ length: 12 }).map((_, i) => (
                <div key={i}>
                  <Skeleton className="aspect-[16/9] rounded-xl bg-white/5" />
                  <Skeleton className="h-3 w-full mt-2 bg-white/5 rounded" />
                  <Skeleton className="h-2 w-2/3 mt-1 bg-white/5 rounded" />
                </div>
              ))}
            </div>
          ) : videos.length === 0 ? (
            <div className="text-center py-20 text-white/30">
              <Film className="w-12 h-12 mx-auto mb-4 opacity-30" />
              <p className="font-bold text-lg">No videos found</p>
              <p className="text-sm">Try a different category or search</p>
            </div>
          ) : activeMode === 'trending' ? (
            /* Horizontal scroll row */
            <div className="relative group/row">
              <button onClick={() => scrollRow('trending', 'left')}
                className="absolute -left-2 top-0 bottom-2 z-10 w-10 opacity-0 group-hover/row:opacity-100 transition-opacity flex items-center justify-center">
                <div className="w-8 h-8 rounded-full bg-black/60 backdrop-blur border border-white/10 flex items-center justify-center">
                  <ChevronLeft className="w-4 h-4 text-white" />
                </div>
              </button>
              <div ref={el => { rowRefs.current['trending'] = el }}
                className="flex gap-3 overflow-x-auto scrollbar-hide pb-2" style={{ scrollSnapType: 'x mandatory' }}>
                {videos.map((v, i) => (
                  <motion.button key={v.id || i}
                    initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.02 }}
                    whileHover={{ scale: 1.04, y: -6 }} whileTap={{ scale: 0.98 }}
                    onClick={() => setPlaying(v)}
                    className="flex-shrink-0 w-52 md:w-56 group/card relative rounded-xl overflow-hidden bg-white/[0.03] border border-white/[0.06] hover:border-red-500/40 transition-all text-left"
                    style={{ scrollSnapAlign: 'start' }}>
                    <div className="aspect-[16/9] bg-white/[0.05] relative overflow-hidden">
                      {v.thumbnail ? <img src={v.thumbnail} className="w-full h-full object-cover group-hover/card:scale-110 transition-transform duration-500" />
                        : <div className="w-full h-full flex items-center justify-center"><Film className="w-8 h-8 text-white/20" /></div>}
                      {v.duration && <Badge className="absolute bottom-2 right-2 bg-black/80 text-white text-[10px] border-0 px-1.5 py-0.5">
                        <Clock className="w-2.5 h-2.5 mr-0.5 inline" />{v.duration}</Badge>}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover/card:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                        <div className="w-12 h-12 rounded-full bg-red-600/90 flex items-center justify-center shadow-lg shadow-red-500/30">
                          <Play className="w-5 h-5 text-white fill-current ml-0.5" /></div>
                      </div>
                    </div>
                    <div className="p-3">
                      <p className="text-sm font-bold text-white/90 group-hover/card:text-white line-clamp-2 leading-tight">{v.title}</p>
                    </div>
                  </motion.button>
                ))}
              </div>
              <button onClick={() => scrollRow('trending', 'right')}
                className="absolute -right-2 top-0 bottom-2 z-10 w-10 opacity-0 group-hover/row:opacity-100 transition-opacity flex items-center justify-center">
                <div className="w-8 h-8 rounded-full bg-black/60 backdrop-blur border border-white/10 flex items-center justify-center">
                  <ChevronRight className="w-4 h-4 text-white" />
                </div>
              </button>
            </div>
          ) : (
            /* Grid view for categories/search */
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-2.5">
              {videos.map((v, i) => (
                <motion.button key={v.id || i}
                  initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.02 }}
                  whileHover={{ scale: 1.03, y: -4 }} whileTap={{ scale: 0.98 }}
                  onClick={() => setPlaying(v)}
                  className="group/card relative rounded-xl overflow-hidden bg-white/[0.03] border border-white/[0.06] hover:border-red-500/40 transition-all text-left">
                  <div className="aspect-[16/9] bg-white/[0.05] relative overflow-hidden">
                    {v.thumbnail ? <img src={v.thumbnail} className="w-full h-full object-cover group-hover/card:scale-110 transition-transform duration-500" />
                      : <div className="w-full h-full flex items-center justify-center"><Film className="w-8 h-8 text-white/20" /></div>}
                    {v.duration && <Badge className="absolute bottom-2 right-2 bg-black/80 text-white text-[10px] border-0 px-1.5 py-0.5">
                      <Clock className="w-2.5 h-2.5 mr-0.5 inline" />{v.duration}</Badge>}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover/card:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                      <div className="w-10 h-10 rounded-full bg-red-600/90 flex items-center justify-center">
                        <Play className="w-4 h-4 text-white fill-current ml-0.5" /></div>
                    </div>
                  </div>
                  <div className="p-2.5">
                    <p className="text-xs font-bold text-white/90 group-hover/card:text-white line-clamp-2 leading-tight">{v.title}</p>
                  </div>
                </motion.button>
              ))}
            </div>
          )}

          {/* Infinite Scroll Sentinel */}
          {!loading && hasMore && videos.length > 0 && (
            <div ref={sentinelRef} className="w-full h-20 flex items-center justify-center mt-4">
              {loadingMore ? (
                <div className="flex items-center gap-3 text-white/40">
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span className="text-xs">Loading more videos...</span>
                </div>
              ) : (
                <div className="flex flex-col items-center gap-3">
                  <Button onClick={loadMore}
                    className="bg-white/5 hover:bg-white/10 text-white border border-white/10 rounded-full px-10 h-11 text-sm font-bold">
                    Load More ({totalCount}+)
                  </Button>
                </div>
              )}
            </div>
          )}
          {!loading && !hasMore && videos.length > 0 && (
            <p className="text-center text-white/20 text-xs mt-6 pb-4">All videos loaded</p>
          )}

          {/* Pornstars */}
          {pornstars.length > 0 && activeMode === 'trending' && !loading && (
            <section className="mt-12">
              <div className="flex items-center gap-3 mb-4">
                <User className="w-4 h-4 text-pink-400" />
                <h2 className="text-lg font-bold text-white">Popular Pornstars</h2>
              </div>
              <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2">
                {pornstars.map((name, i) => (
                  <button key={name || i}
                    className="flex-shrink-0 px-4 py-2.5 rounded-xl bg-white/[0.03] border border-white/[0.06] hover:border-pink-500/40 hover:bg-pink-500/5 transition-all text-center min-w-[90px]">
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-pink-500/20 to-purple-500/20 mx-auto mb-1.5 flex items-center justify-center">
                      <User className="w-4 h-4 text-pink-400/60" />
                    </div>
                    <p className="text-[10px] font-bold text-white/70 truncate">{name}</p>
                  </button>
                ))}
              </div>
            </section>
          )}
        </div>
      </div>

      {/* Player Modal */}
      <AnimatePresence>
        {playing && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/95 backdrop-blur-2xl">
            <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }} exit={{ scale: 0.9, opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="relative w-full max-w-5xl mx-4">
              <div className="rounded-2xl overflow-hidden border border-white/[0.1] bg-black shadow-2xl shadow-red-500/10">
                <div className="flex items-center justify-between px-5 py-3 bg-white/[0.03] border-b border-white/[0.05]">
                  <div className="flex items-center gap-3 min-w-0 flex-1">
                    <Badge className="bg-red-500/10 text-red-300 border-red-500/20 text-[10px] flex-shrink-0">18+</Badge>
                    <p className="text-sm font-bold text-white truncate">{playing.title}</p>
                  </div>
                  <button onClick={() => setPlaying(null)}
                    className="w-8 h-8 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center transition-colors flex-shrink-0">
                    <X className="w-4 h-4 text-white/60" />
                  </button>
                </div>
                <div className="aspect-video bg-black relative">
                  <iframe src={`https://www.pornhub.com/embed/${playing.id}`}
                    className="w-full h-full" allowFullScreen
                    allow="autoplay; encrypted-media" style={{ border: 0 }} />
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <Footer />
    </div>
  )
}
