'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { useSession } from 'next-auth/react'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ArrowLeft, Send, Loader2 } from 'lucide-react'
import { toast } from 'sonner'
import { Navbar } from '@/components/navbar'
import Link from 'next/link'

export default function NewTicketPage() {
  const { data: session } = useSession()
  const router = useRouter()
  const [subject, setSubject] = useState('')
  const [description, setDescription] = useState('')
  const [category, setCategory] = useState('GENERAL')
  const [priority, setPriority] = useState('NORMAL')
  const [submitting, setSubmitting] = useState(false)

  if (!session) {
    if (typeof window !== 'undefined') {
      router.push('/auth/signin?callbackUrl=/tickets/new')
    }
    return null
  }

  async function submit() {
    if (!subject.trim() || !description.trim()) { toast.error('Subject and description are required'); return }
    setSubmitting(true)
    try {
      const r = await fetch('/api/tickets', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subject, description, category, priority }),
      })
      const j = await r.json()
      if (!r.ok) throw new Error(j.error || 'Failed')
      toast.success(`Ticket #${j.ticket.ticketNumber} created — admin will reply soon.`)
      router.push(`/tickets/${j.ticket.id}`)
    } catch (e: any) { toast.error(e.message); setSubmitting(false) }
  }

  return (
    <>
      <Navbar />
      <div className="container max-w-2xl mx-auto py-8 px-4 pb-24 md:pb-8">
        <Link href="/tickets" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-4"><ArrowLeft className="w-4 h-4" /> Back to tickets</Link>
        <Card className="p-6">
          <h1 className="text-2xl font-bold mb-1">Open a new ticket</h1>
          <p className="text-muted-foreground text-sm mb-6">Describe your issue clearly. You'll be able to chat with the admin (and attach files / voice) once it's open.</p>

          <div className="space-y-4">
            <div>
              <Label>Subject</Label>
              <Input value={subject} onChange={e => setSubject(e.target.value)} placeholder="Short summary of your issue" maxLength={200} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Category</Label>
                <Select value={category} onValueChange={setCategory}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="GENERAL">General question</SelectItem>
                    <SelectItem value="BILLING">Billing / Payment</SelectItem>
                    <SelectItem value="BUG">Bug report</SelectItem>
                    <SelectItem value="FEATURE">Feature request</SelectItem>
                    <SelectItem value="ACCOUNT">Account / Login</SelectItem>
                    <SelectItem value="OTHER">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label>Priority</Label>
                <Select value={priority} onValueChange={setPriority}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="LOW">Low</SelectItem>
                    <SelectItem value="NORMAL">Normal</SelectItem>
                    <SelectItem value="HIGH">High</SelectItem>
                    <SelectItem value="URGENT">Urgent</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label>Description</Label>
              <Textarea rows={8} value={description} onChange={e => setDescription(e.target.value)} placeholder="Describe what happened, any error messages, and what you expected." maxLength={4000} />
              <div className="text-xs text-muted-foreground mt-1 text-right">{description.length} / 4000</div>
            </div>
            <Button onClick={submit} disabled={submitting} className="w-full gap-2">
              {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              {submitting ? 'Creating…' : 'Create ticket'}
            </Button>
          </div>
        </Card>
      </div>
    </>
  )
}
