'use client'
import { useEffect, useRef, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { useSession } from 'next-auth/react'
import Link from 'next/link'
import { io as ioClient, Socket } from 'socket.io-client'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { ArrowLeft, Send, Paperclip, Mic, StopCircle, Loader2, Image as ImgIcon, X, Trash2, Video } from 'lucide-react'
import { toast } from 'sonner'
import { Navbar } from '@/components/navbar'

const STATUS_COLORS: Record<string, string> = { OPEN: 'bg-emerald-500', PENDING: 'bg-amber-500', RESOLVED: 'bg-blue-500', CLOSED: 'bg-zinc-500' }

export default function TicketChatPage() {
  const { id } = useParams<{ id: string }>()
  const router = useRouter()
  const { data: session } = useSession()
  const [ticket, setTicket] = useState<any>(null)
  const [messages, setMessages] = useState<any[]>([])
  const [draft, setDraft] = useState('')
  const [sending, setSending] = useState(false)
  const [recording, setRecording] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)
  const imgRef = useRef<HTMLInputElement>(null)
  const vidRef = useRef<HTMLInputElement>(null)
  const recRef = useRef<{ rec: MediaRecorder; chunks: Blob[]; startedAt: number } | null>(null)
  const scrollRef = useRef<HTMLDivElement>(null)
  const socketRef = useRef<Socket | null>(null)

  async function load() {
    const [tr, mr] = await Promise.all([
      fetch(`/api/tickets/${id}`, { cache: 'no-store' }),
      fetch(`/api/tickets/${id}/messages`, { cache: 'no-store' }),
    ])
    if (!tr.ok) { toast.error('Ticket not found'); router.push('/tickets'); return }
    const tj = await tr.json(); setTicket(tj.ticket)
    if (mr.ok) { const mj = await mr.json(); setMessages(mj.messages || []) }
  }
  useEffect(() => { if (id && session) load() }, [id, session])
  useEffect(() => { scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' }) }, [messages])

  // Live socket subscription
  useEffect(() => {
    if (!id || !session) return
    const s = ioClient({ path: '/api/socketio', transports: ['websocket', 'polling'] })
    socketRef.current = s
    s.on('connect', () => { s.emit('join', `ticket:${id}`) })
    s.on('ticket:message', (m: any) => {
      if (m.ticketId !== id) return
      setMessages(prev => prev.some(x => x.id === m.id) ? prev : [...prev, m])
    })
    return () => { s.disconnect() }
  }, [id, session])

  async function send() {
    if ((!draft.trim() && !recRef.current) || sending) return
    const text = draft.trim(); setDraft(''); setSending(true)
    try {
      const r = await fetch(`/api/tickets/${id}/messages`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content: text }),
      })
      if (!r.ok) throw new Error((await r.json()).error || 'Failed')
      const m = await r.json(); setMessages(prev => prev.some(x => x.id === m.id) ? prev : [...prev, m])
    } catch (e: any) { toast.error(e.message); setDraft(text) }
    finally { setSending(false) }
  }

  async function uploadFile(file: File, kind?: string, durationSec?: number) {
    const fd = new FormData()
    fd.append('file', file)
    if (kind) fd.append('kind', kind)
    if (durationSec) fd.append('durationSec', String(durationSec))
    setSending(true)
    try {
      const r = await fetch(`/api/tickets/${id}/messages`, { method: 'POST', body: fd })
      if (!r.ok) throw new Error((await r.json()).error || 'Upload failed')
      const m = await r.json(); setMessages(prev => prev.some(x => x.id === m.id) ? prev : [...prev, m])
    } catch (e: any) { toast.error(e.message) }
    finally { setSending(false) }
  }

  async function startRecording() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const rec = new MediaRecorder(stream)
      const chunks: Blob[] = []
      rec.ondataavailable = e => { if (e.data.size) chunks.push(e.data) }
      rec.onstop = () => {
        stream.getTracks().forEach(t => t.stop())
        const blob = new Blob(chunks, { type: 'audio/webm' })
        const dur = Math.round((Date.now() - (recRef.current?.startedAt || Date.now())) / 1000)
        const file = new File([blob], `voice-${Date.now()}.webm`, { type: 'audio/webm' })
        uploadFile(file, 'VOICE', dur)
      }
      rec.start()
      recRef.current = { rec, chunks, startedAt: Date.now() }
      setRecording(true)
    } catch { toast.error('Microphone permission denied') }
  }
  function stopRecording() { recRef.current?.rec.stop(); recRef.current = null; setRecording(false) }

  async function deleteTicket() {
    if (!confirm('Delete this ticket? This cannot be undone.')) return
    const r = await fetch(`/api/tickets/${id}`, { method: 'DELETE' })
    if (r.ok) { toast.success('Ticket deleted'); router.push('/tickets') }
    else toast.error('Failed to delete')
  }

  async function setStatus(status: string) {
    const r = await fetch(`/api/tickets/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) })
    if (r.ok) { const j = await r.json(); setTicket(j.ticket); toast.success(`Status: ${status}`) }
  }

  if (!session || !ticket) return <div className="py-20 text-center"><Loader2 className="w-8 h-8 animate-spin mx-auto" /></div>

  const closed = ticket.status === 'CLOSED'

  return (
    <>
      <Navbar />
      <div className="container max-w-4xl mx-auto py-4 px-3 pb-24 md:pb-4">
        <Link href="/tickets" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground mb-3"><ArrowLeft className="w-4 h-4" /> Back</Link>

        <Card className="overflow-hidden">
          {/* Header */}
          <div className="p-4 border-b bg-gradient-to-r from-purple-500/10 to-blue-500/10">
            <div className="flex items-start justify-between gap-3 flex-wrap">
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2 mb-1 flex-wrap">
                  <span className="text-xs font-mono text-muted-foreground">#{ticket.ticketNumber}</span>
                  <Badge className={`${STATUS_COLORS[ticket.status]} text-white border-0`}>{ticket.status}</Badge>
                  <Badge variant="outline">{ticket.category}</Badge>
                  <Badge variant="outline">{ticket.priority}</Badge>
                </div>
                <h1 className="text-xl font-bold truncate">{ticket.subject}</h1>
              </div>
              <div className="flex gap-2">
                {!closed && <Button size="sm" variant="outline" onClick={() => setStatus('CLOSED')}>Close ticket</Button>}
                {closed && <Button size="sm" variant="outline" onClick={() => setStatus('OPEN')}>Reopen</Button>}
                <Button size="sm" variant="destructive" onClick={deleteTicket}><Trash2 className="w-4 h-4" /></Button>
              </div>
            </div>
          </div>

          {/* Messages */}
          <div ref={scrollRef} className="h-[calc(100vh-340px)] min-h-[400px] overflow-y-auto p-4 space-y-3 bg-muted/20">
            {messages.map(m => <MessageBubble key={m.id} m={m} mine={m.senderId === (session.user as any).id} />)}
            {messages.length === 0 && <div className="text-center text-muted-foreground py-12">Start the conversation…</div>}
          </div>

          {/* Composer */}
          {!closed ? (
            <div className="p-3 border-t bg-background">
              <div className="flex items-center gap-2">
                <input ref={fileRef} type="file" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) uploadFile(f); e.target.value = '' }} />
                <input ref={imgRef} type="file" accept="image/*" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) uploadFile(f, 'IMAGE'); e.target.value = '' }} />
                <input ref={vidRef} type="file" accept="video/*" className="hidden" onChange={e => { const f = e.target.files?.[0]; if (f) uploadFile(f, 'VIDEO'); e.target.value = '' }} />
                <Button size="icon" variant="ghost" onClick={() => imgRef.current?.click()} disabled={sending}><ImgIcon className="w-5 h-5" /></Button>
                <Button size="icon" variant="ghost" onClick={() => vidRef.current?.click()} disabled={sending} title="Attach video"><Video className="w-5 h-5" /></Button>
                <Button size="icon" variant="ghost" onClick={() => fileRef.current?.click()} disabled={sending}><Paperclip className="w-5 h-5" /></Button>
                {recording ? (
                  <Button size="icon" variant="destructive" onClick={stopRecording}><StopCircle className="w-5 h-5" /></Button>
                ) : (
                  <Button size="icon" variant="ghost" onClick={startRecording} disabled={sending}><Mic className="w-5 h-5" /></Button>
                )}
                <Input value={draft} onChange={e => setDraft(e.target.value)} onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send()} placeholder={recording ? 'Recording voice…' : 'Type your reply…'} disabled={recording || sending} />
                <Button onClick={send} disabled={sending || (!draft.trim() && !recording)} size="icon">{sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}</Button>
              </div>
            </div>
          ) : (
            <div className="p-4 border-t bg-muted/40 text-center text-sm text-muted-foreground">This ticket is closed. Reopen to reply.</div>
          )}
        </Card>
      </div>
    </>
  )
}

function MessageBubble({ m, mine }: { m: any; mine: boolean }) {
  const adminColor = m.isAdmin ? 'bg-gradient-to-br from-purple-600 to-pink-600 text-white' : ''
  return (
    <div className={`flex gap-2 ${mine ? 'flex-row-reverse' : ''}`}>
      <div className={`w-8 h-8 rounded-full bg-gradient-to-br ${m.isAdmin ? 'from-purple-500 to-pink-500' : 'from-blue-500 to-cyan-500'} flex items-center justify-center text-white text-xs font-bold shrink-0`}>
        {m.sender?.username?.[0]?.toUpperCase() || '?'}
      </div>
      <div className={`max-w-[75%] rounded-2xl px-3 py-2 ${mine ? (m.isAdmin ? adminColor : 'bg-primary text-primary-foreground') : (m.isAdmin ? adminColor : 'bg-card border')}`}>
        <div className="flex items-center gap-2 mb-0.5">
          <span className="text-xs font-medium opacity-80">{m.sender?.username}{m.isAdmin && ' • Admin'}</span>
          <span className="text-[10px] opacity-50">{new Date(m.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
        </div>
        {m.kind === 'IMAGE' && m.mediaUrl && <img src={m.mediaUrl} alt="" className="rounded-lg max-w-full max-h-80 mb-1" />}
        {m.kind === 'VOICE' && m.mediaUrl && <audio controls src={m.mediaUrl} className="max-w-full" />}
        {m.kind === 'FILE' && m.mediaUrl && <a href={m.mediaUrl} download={m.mediaName} className="flex items-center gap-2 underline text-sm"><Paperclip className="w-3 h-3" /> {m.mediaName}</a>}
        {m.content && <div className="text-sm whitespace-pre-wrap break-words">{m.content}</div>}
      </div>
    </div>
  )
}
