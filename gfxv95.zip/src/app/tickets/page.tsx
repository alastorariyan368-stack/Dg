'use client'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Card } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Plus, MessageSquare, Clock, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react'
import { Navbar } from '@/components/navbar'

const STATUS_COLORS: Record<string, string> = {
  OPEN: 'bg-emerald-500',
  PENDING: 'bg-amber-500',
  RESOLVED: 'bg-blue-500',
  CLOSED: 'bg-zinc-500',
}
const PRIORITY_COLORS: Record<string, string> = {
  LOW: 'bg-zinc-500',
  NORMAL: 'bg-blue-500',
  HIGH: 'bg-orange-500',
  URGENT: 'bg-red-500',
}

export default function TicketsListPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [tickets, setTickets] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin?callbackUrl=/tickets')
  }, [status, router])

  async function load() {
    setLoading(true)
    try {
      const r = await fetch('/api/tickets', { cache: 'no-store' })
      if (r.ok) { const j = await r.json(); setTickets(j.tickets || []) }
    } finally { setLoading(false) }
  }
  useEffect(() => { if (session) load() }, [session])

  if (status === 'loading' || !session) return null

  const open = tickets.filter(t => t.status === 'OPEN' || t.status === 'PENDING')
  const closed = tickets.filter(t => t.status === 'RESOLVED' || t.status === 'CLOSED')

  return (
    <>
      <Navbar />
      <div className="container max-w-5xl mx-auto py-8 px-4 pb-24 md:pb-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2"><MessageSquare className="w-8 h-8 text-purple-500" /> Support Tickets</h1>
            <p className="text-muted-foreground mt-1">Open a ticket and chat directly with our admin team.</p>
          </div>
          <Link href="/tickets/new"><Button className="gap-2"><Plus className="w-4 h-4" /> New ticket</Button></Link>
        </div>

        {loading ? (
          <div className="py-20 text-center"><Loader2 className="w-8 h-8 animate-spin mx-auto text-muted-foreground" /></div>
        ) : tickets.length === 0 ? (
          <Card className="p-12 text-center">
            <MessageSquare className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
            <h3 className="text-lg font-semibold">No tickets yet</h3>
            <p className="text-muted-foreground mb-4">Need help? Open a ticket and we'll reply fast.</p>
            <Link href="/tickets/new"><Button>Create your first ticket</Button></Link>
          </Card>
        ) : (
          <div className="space-y-6">
            {open.length > 0 && (
              <section>
                <h2 className="font-semibold mb-3 flex items-center gap-2"><AlertCircle className="w-4 h-4 text-emerald-500" /> Active ({open.length})</h2>
                <div className="space-y-2">{open.map(t => <TicketRow key={t.id} t={t} />)}</div>
              </section>
            )}
            {closed.length > 0 && (
              <section>
                <h2 className="font-semibold mb-3 flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-zinc-500" /> Closed ({closed.length})</h2>
                <div className="space-y-2">{closed.map(t => <TicketRow key={t.id} t={t} />)}</div>
              </section>
            )}
          </div>
        )}
      </div>
    </>
  )
}

function TicketRow({ t }: { t: any }) {
  return (
    <Link href={`/tickets/${t.id}`}>
      <Card className="p-4 hover:bg-accent/40 transition cursor-pointer">
        <div className="flex items-start gap-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <span className="text-xs text-muted-foreground font-mono">#{t.ticketNumber}</span>
              <Badge className={`${STATUS_COLORS[t.status]} text-white border-0`}>{t.status}</Badge>
              <Badge variant="outline" className={`${PRIORITY_COLORS[t.priority]} text-white border-0`}>{t.priority}</Badge>
              <Badge variant="outline">{t.category}</Badge>
            </div>
            <h3 className="font-semibold truncate">{t.subject}</h3>
            <p className="text-sm text-muted-foreground line-clamp-1">{t.description}</p>
          </div>
          <div className="text-right shrink-0">
            <div className="text-xs text-muted-foreground flex items-center gap-1"><Clock className="w-3 h-3" /> {new Date(t.updatedAt).toLocaleDateString()}</div>
            <div className="text-xs text-muted-foreground mt-1">{t._count?.messages || 0} messages</div>
          </div>
        </div>
      </Card>
    </Link>
  )
}
