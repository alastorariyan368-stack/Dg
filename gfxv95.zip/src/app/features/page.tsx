'use client'

import React from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { motion } from 'framer-motion'
import Link from 'next/link'
import { 
  Zap, 
  Coins, 
  ShieldCheck, 
  Cpu, 
  LayoutDashboard, 
  Globe, 
  MessageSquare, 
  Image as ImageIcon, 
  Smartphone, 
  Code, 
  Video, 
  CreditCard, 
  UserPlus, 
  Settings2,
  Lock,
  Sparkles,
  ArrowRight,
  Film,
  Mic,
  Gift,
  Crown,
  Wallet,
  ClipboardList,
  ChevronRight,
  Server,
  Users2,
  CalendarDays,
  Handshake,
  Briefcase,
  Trophy,
  Award,
  Youtube,
  BarChart2,
  Package,
  Users
} from 'lucide-react'

const features = [
  {
    title: "AI Marketplace",
    description: "A professional hub for downloading AI-generated mobile apps, high-quality code projects, and cinematic videos.",
    icon: Globe,
    color: "text-violet-400",
    bg: "bg-violet-400/10",
    border: "border-violet-400/20",
    href: "/browse"
  },
  {
    title: "Premium Apps",
    description: "Browse ready-to-use Android apps, tools, and mobile products submitted by verified creators.",
    icon: Smartphone,
    color: "text-emerald-400",
    bg: "bg-emerald-400/10",
    border: "border-emerald-400/20",
    href: "/apps"
  },
  {
    title: "Source Code Projects",
    description: "Discover web apps, scripts, templates, and full-stack source code projects for your next build.",
    icon: Code,
    color: "text-amber-400",
    bg: "bg-amber-400/10",
    border: "border-amber-400/20",
    href: "/code"
  },
  {
    title: "Video Marketplace",
    description: "Explore cinematic videos, reels, motion graphics, and creator-made video assets.",
    icon: Video,
    color: "text-rose-400",
    bg: "bg-rose-400/10",
    border: "border-rose-400/20",
    href: "/videos"
  },
  {
    title: "Zero Trust Tunnels",
    description: "Securely expose your local servers to the internet without a public IP. Powered by Cloudflare technology.",
    icon: Globe,
    color: "text-orange-400",
    bg: "bg-orange-400/10",
    border: "border-orange-400/20",
    href: "/tunnels"
  },
  {
    title: "AFK Earning System",
    description: "Earn rewards automatically just by keeping the platform open. Features daily caps and anti-abuse protection.",
    icon: Zap,
    color: "text-amber-400",
    bg: "bg-amber-400/10",
    border: "border-amber-400/20",
    href: "/afk"
  },
  {
    title: "VPS & Game Servers",
    description: "High-performance VPS hosting and dedicated game servers with full Pterodactyl panel control.",
    icon: Server,
    color: "text-blue-400",
    bg: "bg-blue-400/10",
    border: "border-blue-400/20",
    href: "/vps"
  },
  {
    title: "Earn Tasks",
    description: "Complete simple tasks like watching videos, liking posts, or joining groups to earn instant rewards.",
    icon: Coins,
    color: "text-emerald-400",
    bg: "bg-emerald-400/10",
    border: "border-emerald-400/20",
    href: "/tasks"
  },
  {
    title: "AI Studio Suite",
    description: "Advanced AI tools for chat, professional image generation, and cinematic video creation.",
    icon: Sparkles,
    color: "text-cyan-400",
    bg: "bg-cyan-400/10",
    border: "border-cyan-400/20",
    href: "/ai-chat"
  },
  {
    title: "YouTube Generation",
    description: "Automate your content creation with AI-powered YouTube script and video generation tools.",
    icon: Youtube,
    color: "text-red-400",
    bg: "bg-red-400/10",
    border: "border-red-400/20",
    href: "/youtube-gen"
  },
  {
    title: "Team Collaboration",
    description: "Create or join teams to work together on projects and share resources within the ecosystem.",
    icon: Users2,
    color: "text-indigo-400",
    bg: "bg-indigo-400/10",
    border: "border-indigo-400/20",
    href: "/teams"
  },
  {
    title: "Custom Orders",
    description: "Need something unique? Hire professional creators for custom development, design, or video work.",
    icon: Briefcase,
    color: "text-sky-400",
    bg: "bg-sky-400/10",
    border: "border-sky-400/20",
    href: "/custom-orders"
  },
  {
    title: "Leaderboard & Stats",
    description: "Compete with other users, earn badges, and climb the ranks to become a top creator on GFX STORE.",
    icon: Trophy,
    color: "text-yellow-400",
    bg: "bg-yellow-400/10",
    border: "border-yellow-400/20",
    href: "/leaderboard"
  },
  {
    title: "Professional Wallet",
    description: "Securely manage your funds, deposits, and withdrawals with full transaction transparency.",
    icon: Wallet,
    color: "text-emerald-400",
    bg: "bg-emerald-400/10",
    border: "border-emerald-400/20",
    href: "/wallet"
  },
  {
    title: "Campaigns & Events",
    description: "Participate in seasonal campaigns and community events to earn exclusive rewards and discounts.",
    icon: CalendarDays,
    color: "text-fuchsia-400",
    bg: "bg-fuchsia-400/10",
    border: "border-fuchsia-400/20",
    href: "/campaigns"
  },
  {
    title: "Marketplace Categories",
    description: "Browse our extensive catalog of Apps, Code, Videos, and Graphics organized by categories.",
    icon: Package,
    color: "text-slate-400",
    bg: "bg-slate-400/10",
    border: "border-slate-400/20",
    href: "/categories"
  },
  {
    title: "Verified Creators",
    description: "Discover and follow the best talent in the community. View portfolios and past works before you buy.",
    icon: Users,
    color: "text-pink-400",
    bg: "bg-pink-400/10",
    border: "border-pink-400/20",
    href: "/creators"
  },
  {
    title: "Support System",
    description: "Get professional help through our dedicated ticket system. Our team is available to assist you 24/7.",
    icon: ClipboardList,
    color: "text-slate-300",
    bg: "bg-slate-300/10",
    border: "border-slate-300/20",
    href: "/tickets"
  }
]

export default function FeaturesPage() {
  return (
    <div className="min-h-screen bg-[#07070d] text-white flex flex-col">
      <Navbar />
      
      <main className="flex-1 container mx-auto px-4 py-20 max-w-7xl relative">
        {/* Background glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-violet-600/10 rounded-full blur-[120px] pointer-events-none" />
        
        <div className="text-center mb-16 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-violet-500/10 border border-violet-500/20 text-violet-400 text-xs font-bold uppercase tracking-widest mb-4">
              <Sparkles className="w-3 h-3" /> Discover Everything
            </div>
            <h1 className="text-5xl md:text-6xl font-black tracking-tight mb-6">
              Marketplace <span className="bg-gradient-to-r from-violet-400 via-fuchsia-400 to-cyan-400 bg-clip-text text-transparent">Ecosystem</span>
            </h1>
            <p className="text-white/50 max-w-2xl mx-auto text-lg leading-relaxed">
              Explore all the powerful tools and services available on GFX STORE. Click on any feature to get started.
            </p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 relative z-10">
          {features.map((feature, index) => (
            <Link key={feature.title} href={feature.href}>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.05 }}
                whileHover={{ y: -8, scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className={`group h-full p-6 sm:p-8 rounded-[2rem] sm:rounded-[2.5rem] border ${feature.border} bg-white/[0.02] hover:bg-white/[0.05] transition-all duration-300 shadow-xl flex flex-col`}
              >
                <div className={`w-12 h-12 sm:w-14 h-14 rounded-xl sm:rounded-2xl ${feature.bg} flex items-center justify-center mb-6 sm:mb-8 group-hover:rotate-6 transition-transform duration-500`}>
                  <feature.icon className={`w-6 h-6 sm:w-7 h-7 ${feature.color}`} />
                </div>
                
                <div className="flex-1">
                  <h3 className="text-xl sm:text-2xl font-black text-white mb-3 sm:mb-4 group-hover:text-violet-400 transition-colors flex items-center gap-2">
                    {feature.title}
                    <ArrowRight className="w-4 h-4 sm:w-5 h-5 opacity-0 -translate-x-2 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300 text-violet-400" />
                  </h3>
                  <p className="text-white/40 text-sm sm:text-[15px] leading-relaxed mb-6">
                    {feature.description}
                  </p>
                </div>

                <div className="pt-4 border-t border-white/[0.05] flex items-center justify-between">
                  <span className={`text-[10px] sm:text-xs font-bold uppercase tracking-widest ${feature.color} opacity-70 group-hover:opacity-100 transition-opacity`}>
                    Launch App
                  </span>
                  <div className="w-7 h-7 sm:w-8 h-8 rounded-full bg-white/[0.05] flex items-center justify-center group-hover:bg-violet-500/20 transition-colors">
                    <ChevronRight className="w-3.5 h-3.5 sm:w-4 h-4 text-white/20 group-hover:text-violet-400 transition-colors" />
                  </div>
                </div>
              </motion.div>
            </Link>
          ))}
        </div>

        {/* Call to action */}
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1, duration: 1 }}
          className="mt-20 p-12 rounded-[3rem] bg-gradient-to-br from-violet-600/10 via-white/[0.02] to-cyan-600/10 border border-white/10 text-center relative overflow-hidden group"
        >
          <div className="absolute top-0 right-0 p-20 opacity-5 group-hover:opacity-10 transition-opacity rotate-12">
            <Sparkles className="w-64 h-64 text-white" />
          </div>
          
          <h2 className="text-3xl md:text-4xl font-black mb-4 relative z-10">Start Your Creative Journey</h2>
          <p className="text-white/40 mb-10 max-w-xl mx-auto text-lg relative z-10">Join thousands of creators building the future of AI and design on GFX STORE.</p>
          
          <div className="flex flex-wrap justify-center gap-4 relative z-10">
            <Link href="/auth/signup" className="px-10 py-4 bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:scale-105 active:scale-95 text-white font-black rounded-2xl transition-all shadow-xl shadow-violet-600/25">
              GET STARTED NOW
            </Link>
            <Link href="/browse" className="px-10 py-4 bg-white/5 hover:bg-white/10 text-white font-bold rounded-2xl border border-white/10 transition-all">
              EXPLORE STORE
            </Link>
          </div>
        </motion.div>
      </main>

      <Footer />
    </div>
  )
}

