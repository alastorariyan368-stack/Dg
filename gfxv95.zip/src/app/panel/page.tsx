'use client'

import { useState, useEffect, useCallback } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { toast } from 'sonner'
import {
  Server, Power, RefreshCw, Terminal, HardDrive, Cpu, MemoryStick,
  Play, Square, RotateCcw, AlertTriangle, CheckCircle, Loader2,
  Settings, ChevronRight, Wifi, WifiOff, Eye, EyeOff, Shield,
  Archive, Folder, Zap, Activity
} from 'lucide-react'

interface PterodactylServer {
  identifier: string
  uuid: string
  name: string
  description: string
  node: string
  sftp_details: { ip: string; port: number }
  status: string | null
  is_suspended: boolean
  is_installing: boolean
  limits: { memory: number; swap: number; disk: number; io: number; cpu: number }
  feature_limits: { databases: number; backups: number }
}

interface ServerResources {
  current_state: string
  memory_bytes: number
  cpu_absolute: number
  disk_bytes: number
  network: { rx_bytes: number; tx_bytes: number }
}

function fmtBytes(b: number) {
  if (b >= 1024 ** 3) return (b / 1024 ** 3).toFixed(1) + ' GB'
  if (b >= 1024 ** 2) return (b / 1024 ** 2).toFixed(1) + ' MB'
  if (b >= 1024) return (b / 1024).toFixed(1) + ' KB'
  return b + ' B'
}

function StateBadge({ state }: { state: string }) {
  const map: Record<string, string> = {
    running: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
    starting: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
    stopping: 'bg-orange-500/20 text-orange-300 border-orange-500/30',
    offline: 'bg-white/10 text-white/50 border-white/10',
  }
  return (
    <Badge className={`text-[10px] border ${map[state] || map.offline}`}>
      {state === 'running' ? <CheckCircle className="w-2.5 h-2.5 mr-1" /> : <AlertTriangle className="w-2.5 h-2.5 mr-1" />}
      {state || 'offline'}
    </Badge>
  )
}

export default function PanelPage() {
  const { data: session, status } = useSession()
  const router = useRouter()

  const [panelUrl, setPanelUrl] = useState('')
  const [apiKey, setApiKey] = useState('')
  const [showKey, setShowKey] = useState(false)
  const [connected, setConnected] = useState(false)
  const [connecting, setConnecting] = useState(false)

  const [servers, setServers] = useState<PterodactylServer[]>([])
  const [loading, setLoading] = useState(false)
  const [selected, setSelected] = useState<PterodactylServer | null>(null)
  const [resources, setResources] = useState<ServerResources | null>(null)
  const [command, setCommand] = useState('')
  const [sending, setSending] = useState(false)
  const [backups, setBackups] = useState<any[]>([])
  const [loadingBackups, setLoadingBackups] = useState(false)

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin')
    const saved = localStorage.getItem('panel_url')
    const savedKey = localStorage.getItem('panel_key')
    if (saved) setPanelUrl(saved)
    if (savedKey) setApiKey(savedKey)
  }, [status])

  async function panelCall(action: string, params: Record<string, any> = {}) {
    const r = await fetch('/api/panel', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ panelUrl, apiKey, action, ...params }),
    })
    return r.json()
  }

  async function connect() {
    if (!panelUrl || !apiKey) return toast.error('Enter panel URL and API key')
    setConnecting(true)
    try {
      const r = await panelCall('validate')
      if (r.ok) {
        setConnected(true)
        localStorage.setItem('panel_url', panelUrl)
        localStorage.setItem('panel_key', apiKey)
        toast.success('Connected to panel!')
        loadServers()
      } else {
        toast.error('Could not connect. Check URL and API key.')
      }
    } catch {
      toast.error('Connection failed')
    } finally {
      setConnecting(false)
    }
  }

  async function loadServers() {
    setLoading(true)
    try {
      const r = await panelCall('list-servers')
      if (r.ok) {
        const list = (r.data?.data || []).map((s: any) => s.attributes as PterodactylServer)
        setServers(list)
      } else {
        toast.error('Failed to load servers')
      }
    } finally {
      setLoading(false)
    }
  }

  async function selectServer(srv: PterodactylServer) {
    setSelected(srv)
    setResources(null)
    setBackups([])
    const r = await panelCall('server-resources', { identifier: srv.identifier })
    if (r.ok) setResources(r.data?.attributes)
  }

  async function sendPower(signal: string) {
    if (!selected) return
    const r = await panelCall('power', { identifier: selected.identifier, signal })
    if (r.ok || r.status === 204) toast.success(`Signal "${signal}" sent`)
    else toast.error('Failed to send signal')
    setTimeout(() => selectServer(selected), 2000)
  }

  async function sendCommand() {
    if (!selected || !command.trim()) return
    setSending(true)
    try {
      const r = await panelCall('send-command', { identifier: selected.identifier, command: command.trim() })
      if (r.ok || r.status === 204) { toast.success('Command sent'); setCommand('') }
      else toast.error('Failed to send command')
    } finally { setSending(false) }
  }

  async function loadBackups() {
    if (!selected) return
    setLoadingBackups(true)
    try {
      const r = await panelCall('list-backups', { identifier: selected.identifier })
      if (r.ok) setBackups(r.data?.data || [])
    } finally { setLoadingBackups(false) }
  }

  async function createBackup() {
    if (!selected) return
    const name = `backup-${new Date().toISOString().slice(0, 10)}`
    const r = await panelCall('create-backup', { identifier: selected.identifier, name })
    if (r.ok) { toast.success('Backup started'); loadBackups() }
    else toast.error('Backup failed')
  }

  function disconnect() {
    setConnected(false)
    setServers([])
    setSelected(null)
    setResources(null)
    localStorage.removeItem('panel_url')
    localStorage.removeItem('panel_key')
    setPanelUrl('')
    setApiKey('')
  }

  if (status === 'loading') {
    return <div className="min-h-screen bg-[#08080f] flex items-center justify-center"><Loader2 className="w-6 h-6 animate-spin text-violet-400" /></div>
  }

  return (
    <div className="min-h-screen bg-[#08080f] text-white">
      <Navbar />
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center gap-2 mb-2">
            <Server className="w-6 h-6 text-violet-400" />
            <h1 className="text-2xl font-bold text-white">Server Control Panel</h1>
            {connected && <Badge className="bg-emerald-500/20 text-emerald-300 border-emerald-500/30 text-xs"><Wifi className="w-3 h-3 mr-1" />Connected</Badge>}
          </div>
          <p className="text-white/50 text-sm">Manage your Pterodactyl game servers</p>
        </div>

        {/* Connection form */}
        {!connected ? (
          <div className="max-w-lg">
            <div className="bg-white/[0.03] border border-white/[0.08] rounded-2xl p-6 space-y-4">
              <div className="flex items-center gap-2 mb-2">
                <Shield className="w-5 h-5 text-violet-400" />
                <h2 className="font-semibold text-white">Connect to Pterodactyl Panel</h2>
              </div>
              <p className="text-white/40 text-sm">Enter your panel URL and client API key to manage your servers.</p>
              <div>
                <label className="text-xs text-white/50 mb-1.5 block">Panel URL</label>
                <Input
                  value={panelUrl}
                  onChange={e => setPanelUrl(e.target.value)}
                  placeholder="https://panel.example.com"
                  className="bg-black/30 border-white/[0.08] text-sm"
                />
              </div>
              <div>
                <label className="text-xs text-white/50 mb-1.5 block">Client API Key</label>
                <div className="relative">
                  <Input
                    value={apiKey}
                    onChange={e => setApiKey(e.target.value)}
                    type={showKey ? 'text' : 'password'}
                    placeholder="ptlc_..."
                    className="bg-black/30 border-white/[0.08] text-sm pr-10"
                  />
                  <button onClick={() => setShowKey(s => !s)} className="absolute right-3 top-1/2 -translate-y-1/2 text-white/40 hover:text-white">
                    {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <p className="text-[11px] text-white/30 mt-1">Generate from your Pterodactyl panel → Account → API Credentials</p>
              </div>
              <Button onClick={connect} disabled={connecting} className="w-full bg-gradient-to-r from-violet-600 to-cyan-600 hover:from-violet-500 hover:to-cyan-500">
                {connecting ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Connecting…</> : <><Zap className="w-4 h-4 mr-2" />Connect</>}
              </Button>
            </div>
          </div>
        ) : (
          <div className="flex gap-6 h-[calc(100vh-220px)]">
            {/* Server list */}
            <div className="w-72 flex-shrink-0 flex flex-col gap-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-white/40 uppercase tracking-wider">Servers ({servers.length})</span>
                <div className="flex gap-1">
                  <button onClick={loadServers} className="p-1.5 rounded-lg hover:bg-white/[0.06] text-white/50 hover:text-white" title="Refresh">
                    <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
                  </button>
                  <button onClick={disconnect} className="p-1.5 rounded-lg hover:bg-white/[0.06] text-white/50 hover:text-red-400" title="Disconnect">
                    <WifiOff className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto space-y-2">
                {loading && servers.length === 0 ? (
                  <div className="flex items-center justify-center py-12"><Loader2 className="w-5 h-5 animate-spin text-violet-400" /></div>
                ) : servers.length === 0 ? (
                  <div className="text-center py-8 text-white/30 text-sm">No servers found</div>
                ) : servers.map(srv => (
                  <button key={srv.identifier} onClick={() => selectServer(srv)}
                    className={`w-full text-left p-3 rounded-xl border transition-all ${selected?.identifier === srv.identifier ? 'bg-violet-600/20 border-violet-500/40' : 'bg-white/[0.02] border-white/[0.06] hover:bg-white/[0.04] hover:border-white/10'}`}>
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium text-white text-sm truncate">{srv.name}</span>
                      <ChevronRight className="w-3.5 h-3.5 text-white/30 flex-shrink-0" />
                    </div>
                    <div className="text-[11px] text-white/40">{srv.node} · {srv.identifier}</div>
                    {srv.is_suspended && <Badge className="mt-1 text-[9px] bg-red-500/20 text-red-300 border-red-500/30">Suspended</Badge>}
                  </button>
                ))}
              </div>
            </div>

            {/* Server detail */}
            <div className="flex-1 overflow-y-auto">
              {!selected ? (
                <div className="flex items-center justify-center h-full text-white/30">
                  <div className="text-center">
                    <Server className="w-12 h-12 mx-auto mb-3 text-white/10" />
                    <p className="text-sm">Select a server to manage</p>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Server header */}
                  <div className="bg-white/[0.03] border border-white/[0.08] rounded-2xl p-5">
                    <div className="flex items-start justify-between gap-4 mb-4">
                      <div>
                        <h2 className="text-lg font-bold text-white">{selected.name}</h2>
                        <p className="text-white/40 text-sm">{selected.description || 'No description'}</p>
                        <div className="flex gap-2 mt-2">
                          {resources && <StateBadge state={resources.current_state} />}
                          <Badge className="text-[10px] bg-white/5 text-white/40 border-white/10">{selected.identifier}</Badge>
                        </div>
                      </div>
                      <button onClick={() => selectServer(selected)} className="p-2 rounded-lg hover:bg-white/[0.06] text-white/50 hover:text-white">
                        <RefreshCw className="w-4 h-4" />
                      </button>
                    </div>

                    {/* Resource bars */}
                    {resources && (
                      <div className="grid grid-cols-3 gap-3 mb-4">
                        {[
                          { label: 'CPU', value: resources.cpu_absolute.toFixed(1) + '%', pct: Math.min(100, resources.cpu_absolute), icon: Cpu, color: 'from-violet-500 to-cyan-500' },
                          { label: 'RAM', value: fmtBytes(resources.memory_bytes), pct: selected.limits.memory ? Math.min(100, (resources.memory_bytes / (selected.limits.memory * 1024 * 1024)) * 100) : 0, icon: MemoryStick, color: 'from-cyan-500 to-emerald-500' },
                          { label: 'Disk', value: fmtBytes(resources.disk_bytes), pct: selected.limits.disk ? Math.min(100, (resources.disk_bytes / (selected.limits.disk * 1024 * 1024)) * 100) : 0, icon: HardDrive, color: 'from-pink-500 to-violet-500' },
                        ].map(m => (
                          <div key={m.label} className="bg-black/30 rounded-xl p-3">
                            <div className="flex items-center gap-1.5 mb-1.5">
                              <m.icon className="w-3.5 h-3.5 text-white/50" />
                              <span className="text-[11px] text-white/50">{m.label}</span>
                            </div>
                            <div className="text-sm font-semibold text-white mb-1.5">{m.value}</div>
                            <div className="h-1 bg-white/10 rounded-full overflow-hidden">
                              <div className={`h-full bg-gradient-to-r ${m.color} rounded-full transition-all`} style={{ width: `${m.pct}%` }} />
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Power controls */}
                    <div className="flex gap-2 flex-wrap">
                      <Button size="sm" onClick={() => sendPower('start')} className="bg-emerald-600/80 hover:bg-emerald-600 text-white h-8 text-xs gap-1.5">
                        <Play className="w-3.5 h-3.5" />Start
                      </Button>
                      <Button size="sm" onClick={() => sendPower('restart')} className="bg-amber-600/80 hover:bg-amber-600 text-white h-8 text-xs gap-1.5">
                        <RotateCcw className="w-3.5 h-3.5" />Restart
                      </Button>
                      <Button size="sm" onClick={() => sendPower('stop')} className="bg-orange-600/80 hover:bg-orange-600 text-white h-8 text-xs gap-1.5">
                        <Square className="w-3.5 h-3.5" />Stop
                      </Button>
                      <Button size="sm" onClick={() => sendPower('kill')} variant="destructive" className="h-8 text-xs gap-1.5">
                        <AlertTriangle className="w-3.5 h-3.5" />Kill
                      </Button>
                    </div>
                  </div>

                  {/* Console */}
                  <div className="bg-white/[0.03] border border-white/[0.08] rounded-2xl p-5">
                    <div className="flex items-center gap-2 mb-3">
                      <Terminal className="w-4 h-4 text-cyan-400" />
                      <h3 className="font-semibold text-white text-sm">Send Command</h3>
                    </div>
                    <div className="flex gap-2">
                      <Input value={command} onChange={e => setCommand(e.target.value)}
                        onKeyDown={e => e.key === 'Enter' && sendCommand()}
                        placeholder="say Hello, world!" className="bg-black/40 border-white/[0.08] font-mono text-sm text-green-400" />
                      <Button onClick={sendCommand} disabled={sending || !command.trim()} className="bg-cyan-600 hover:bg-cyan-500 shrink-0">
                        {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Send'}
                      </Button>
                    </div>
                  </div>

                  {/* Limits */}
                  <div className="bg-white/[0.03] border border-white/[0.08] rounded-2xl p-5">
                    <div className="flex items-center gap-2 mb-3">
                      <Activity className="w-4 h-4 text-violet-400" />
                      <h3 className="font-semibold text-white text-sm">Server Limits</h3>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                      {[
                        { label: 'Memory', value: selected.limits.memory ? `${selected.limits.memory} MB` : 'Unlimited' },
                        { label: 'Disk', value: selected.limits.disk ? `${selected.limits.disk} MB` : 'Unlimited' },
                        { label: 'CPU', value: selected.limits.cpu ? `${selected.limits.cpu}%` : 'Unlimited' },
                        { label: 'Databases', value: selected.feature_limits.databases },
                        { label: 'Backups', value: selected.feature_limits.backups },
                        { label: 'Node', value: selected.node },
                      ].map(l => (
                        <div key={l.label} className="bg-black/20 rounded-lg p-2.5">
                          <div className="text-[10px] text-white/40 mb-0.5">{l.label}</div>
                          <div className="text-sm font-medium text-white">{l.value}</div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Backups */}
                  <div className="bg-white/[0.03] border border-white/[0.08] rounded-2xl p-5">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <Archive className="w-4 h-4 text-amber-400" />
                        <h3 className="font-semibold text-white text-sm">Backups</h3>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="ghost" onClick={loadBackups} className="h-7 text-xs text-white/50 hover:text-white">
                          {loadingBackups ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}
                        </Button>
                        <Button size="sm" onClick={createBackup} className="h-7 text-xs bg-amber-600/80 hover:bg-amber-600 text-white">
                          + Create
                        </Button>
                      </div>
                    </div>
                    {backups.length === 0 ? (
                      <p className="text-sm text-white/30 text-center py-4">Click refresh to load backups</p>
                    ) : (
                      <div className="space-y-2">
                        {backups.map((b: any) => {
                          const attrs = b.attributes
                          return (
                            <div key={attrs.uuid} className="flex items-center gap-3 bg-black/20 rounded-lg p-2.5">
                              <Archive className="w-4 h-4 text-amber-400/60 flex-shrink-0" />
                              <div className="flex-1 min-w-0">
                                <div className="text-sm text-white truncate">{attrs.name}</div>
                                <div className="text-[11px] text-white/40">{attrs.completed_at ? fmtBytes(attrs.bytes) + ' · ' + new Date(attrs.completed_at).toLocaleString() : 'In progress…'}</div>
                              </div>
                              {attrs.is_successful ? <CheckCircle className="w-4 h-4 text-emerald-400 flex-shrink-0" /> : <Loader2 className="w-4 h-4 animate-spin text-amber-400 flex-shrink-0" />}
                            </div>
                          )
                        })}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
