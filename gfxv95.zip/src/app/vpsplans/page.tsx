import { redirect } from 'next/navigation'

export default function VpsPlansAliasPage() {
  redirect('/vps')
}
