'use client'

import { useState, useEffect, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import { 
  Sparkles, Send, Bot, User, Loader2, Image as ImageIcon, Video, Music, 
  Code, Mic, Trash2, Settings, Shield, Zap, Info, ChevronRight, Download
} from 'lucide-react'
import { toast } from 'sonner'
import ReactMarkdown from 'react-markdown'

interface Message {
  id: string
  role: 'user' | 'assistant'
  content: string
  type: 'text' | 'image' | 'video' | 'audio' | 'code'
  mediaUrl?: string
  timestamp: Date
}

export default function GfxV1Page() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState('')
  const [mode, setMode] = useState<'chat' | 'photo' | 'video' | 'audio'>('chat')
  const [selectedModel, setSelectedModel] = useState<'GFXV1' | 'GFXV2' | 'GFXV3'>('GFXV1')
  const [chatStyle, setChatStyle] = useState<'general' | 'code'>('general')
  const [loading, setLoading] = useState(false)
  const [limits, setLimits] = useState({ daily: 0, monthly: 0, usedToday: 0 })
  const scrollRef = useRef<HTMLDivElement>(null)

  const copyText = async (text: string) => {
    try {
      await navigator.clipboard.writeText(text)
      toast.success('Copied')
    } catch {
      toast.error('Copy failed')
    }
  }

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin?callbackUrl=/ai')
    if (status === 'authenticated') fetchLimits()
  }, [status])

  useEffect(() => {
    scrollRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const fetchLimits = async () => {
    try {
      const res = await fetch('/api/ai/limits')
      if (res.ok) {
        const data = await res.json()
        setLimits(data)
      }
    } catch {}
  }

  const handleSend = async () => {
    if (!input.trim()) return
    if (loading) return

    const prompt = input.trim() // Save prompt before clearing

    const userMsg: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: prompt,
      type: mode === 'chat' ? 'text' : (mode as any),
      timestamp: new Date()
    }

    // Optimistically append the user's message
    const nextMessages = [...messages, userMsg]
    setMessages(nextMessages)
    setInput('')
    setLoading(true)

    try {
      let res: Response
      let data: any

      if (mode === 'chat') {
        res = await fetch('/api/ai/gfxv1', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            prompt,
            mode,
            style: chatStyle,
            modelName: selectedModel,
            // Send short conversation history for multi-turn context
            messages: nextMessages.slice(-12).map(m => ({
              role: m.role,
              content: m.content,
            })),
          }),
        })
        data = await res.json()
      } else if (mode === 'photo') {
        res = await fetch('/api/ai/generate/image', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt, size: '1024x1024' }),
        })
        data = await res.json()
      } else if (mode === 'video') {
        res = await fetch('/api/ai/generate/video', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt, aspect: '16:9', duration: 5 }),
        })
        data = await res.json()
      } else {
        res = await fetch('/api/ai/generate/voice', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ text: prompt }),
        })
        data = await res.json()
      }

      if (!res.ok) {
        toast.error(data.error || 'AI process failed')
        return
      }

      const assistantMsg: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: mode === 'chat'
          ? data.response
          : mode === 'photo'
          ? `${selectedModel} has generated an image for your prompt.`
          : mode === 'video'
          ? `${selectedModel} has generated a video for your prompt.`
          : `${selectedModel} has generated audio for your prompt.`,
        type: mode === 'chat' ? (data.type || (chatStyle === 'code' ? 'code' : 'text')) : mode === 'photo' ? 'image' : (mode as any),
        mediaUrl: mode === 'chat'
          ? data.mediaUrl
          : mode === 'photo'
          ? data.imageUrl || data.url
          : mode === 'video'
          ? data.videoUrl || data.url
          : data.audioUrl || data.url,
        timestamp: new Date(),
      }

      setMessages(prev => [...prev, assistantMsg])
      fetchLimits()
    } catch (err) {
      toast.error('Connection failed')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="min-h-[100dvh] bg-[#06060c] text-white">
      <Navbar />
      
      <div className="max-w-6xl mx-auto px-3 sm:px-4 py-4 sm:py-6 h-[calc(100dvh-80px)] flex gap-4 sm:gap-6">
        {/* Sidebar */}
        <div className="w-64 hidden lg:flex flex-col gap-4">
          <Card className="bg-white/[0.03] border-white/10 p-4 rounded-3xl">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-purple-500 to-blue-600 flex items-center justify-center shadow-lg shadow-purple-500/20">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="font-bold text-lg leading-none">{selectedModel}</h2>
                <p className="text-[10px] text-white/40 uppercase tracking-widest font-bold mt-1">Multi-Modal Agent</p>
              </div>
            </div>

            <div className="mb-6">
              <div className="text-[10px] text-white/40 font-bold uppercase tracking-wider mb-2">
                Select Model
              </div>
              <div className="grid grid-cols-3 gap-1.5">
                {(['GFXV1', 'GFXV2', 'GFXV3'] as const).map(m => (
                  <button
                    key={m}
                    onClick={() => setSelectedModel(m)}
                    className={`px-2 py-2 rounded-xl text-[10px] font-black transition-all border ${
                      selectedModel === m
                        ? 'bg-white/10 border-white/20 text-white shadow-lg shadow-white/5'
                        : 'bg-white/[0.02] border-white/5 text-white/30 hover:bg-white/[0.05] hover:text-white/60'
                    }`}
                  >
                    {m}
                  </button>
                ))}
              </div>
            </div>

            <div className="space-y-1">
              {[
                { id: 'chat', label: 'Chat', icon: Bot },
                { id: 'photo', label: 'Photo Gen', icon: ImageIcon },
                { id: 'video', label: 'Video Gen', icon: Video },
                { id: 'audio', label: 'Audio/Music', icon: Music },
              ].map(item => (
                <button
                  key={item.id}
                  onClick={() => setMode(item.id as any)}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl transition-all ${
                    mode === item.id 
                    ? 'bg-white/10 text-white shadow-inner' 
                    : 'text-white/40 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  <item.icon className="w-4 h-4" />
                  <span className="text-sm font-medium">{item.label}</span>
                </button>
              ))}
            </div>

            {mode === 'chat' && (
              <div className="mt-4">
                <div className="text-[10px] text-white/40 font-bold uppercase tracking-wider mb-2">
                  Chat Mode
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={() => setChatStyle('general')}
                    className={`px-3 py-2 rounded-2xl text-xs font-semibold transition-all border ${
                      chatStyle === 'general'
                        ? 'bg-white/10 border-white/20 text-white'
                        : 'bg-white/[0.02] border-white/10 text-white/50 hover:bg-white/[0.05] hover:text-white/70'
                    }`}
                  >
                    General
                  </button>
                  <button
                    onClick={() => setChatStyle('code')}
                    className={`px-3 py-2 rounded-2xl text-xs font-semibold transition-all border ${
                      chatStyle === 'code'
                        ? 'bg-white/10 border-white/20 text-white'
                        : 'bg-white/[0.02] border-white/10 text-white/50 hover:bg-white/[0.05] hover:text-white/70'
                    }`}
                  >
                    Code
                  </button>
                </div>
              </div>
            )}
          </Card>

          <Card className="bg-white/[0.03] border-white/10 p-4 rounded-3xl mt-auto">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs text-white/40 font-bold uppercase tracking-wider">Usage Status</span>
              <Shield className="w-3.5 h-3.5 text-emerald-400" />
            </div>
            <div className="space-y-3">
              <div>
                <div className="flex justify-between text-[10px] mb-1">
                  <span className="text-white/40">Daily Limit</span>
                  <span className="text-white/80">{limits.usedToday} / {limits.daily}</span>
                </div>
                <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-purple-500 to-blue-500 transition-all duration-500" 
                    style={{ width: `${(limits.usedToday / limits.daily) * 100}%` }}
                  />
                </div>
              </div>
              <p className="text-[10px] text-white/30 leading-relaxed italic">
                * Limits refresh every 24 hours. Premium users get unlimited access.
              </p>
            </div>
          </Card>
        </div>

        {/* Main Chat Area */}
        <div className="flex-1 flex flex-col min-w-0">
          <Card className="flex-1 bg-white/[0.02] border-white/10 rounded-[32px] flex flex-col overflow-hidden relative">
            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
              {messages.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center max-w-md mx-auto">
                  <div className="w-20 h-20 rounded-[32px] bg-gradient-to-br from-purple-500/20 to-blue-600/20 border border-purple-500/20 flex items-center justify-center mb-6 animate-pulse">
                    <Sparkles className="w-10 h-10 text-purple-400" />
                  </div>
                  <h3 className="text-2xl font-black text-white mb-2">I am {selectedModel}</h3>
                  <p className="text-white/40 text-sm leading-relaxed">
                    How can I help you today? I am your advanced {selectedModel} agent, ready to assist with coding, design, and more.
                  </p>
                </div>
              ) : (
                messages.map(msg => (
                  <div key={msg.id} className={`flex gap-3 sm:gap-4 ${msg.role === 'assistant' ? 'flex-row' : 'flex-row-reverse'}`}>
                    <div className={`w-9 h-9 rounded-2xl flex-shrink-0 flex items-center justify-center border ${
                      msg.role === 'assistant' 
                      ? 'bg-purple-500/10 border-purple-500/20 text-purple-400' 
                      : 'bg-white/5 border-white/10 text-white/60'
                    }`}>
                      {msg.role === 'assistant' ? <Bot className="w-5 h-5" /> : <User className="w-5 h-5" />}
                    </div>
                    <div className={`max-w-[92%] sm:max-w-[85%] space-y-2 ${msg.role === 'user' ? 'text-right' : ''}`}>
                      <div className={`p-4 rounded-3xl inline-block text-left relative ${
                        msg.role === 'assistant' 
                        ? 'bg-white/[0.04] text-white/90' 
                        : 'bg-gradient-to-br from-purple-600 to-blue-600 text-white'
                      }`}>
                        {msg.role === 'assistant' && msg.type === 'code' && (
                          <div className="absolute top-2 right-2">
                            <Button
                              type="button"
                              variant="ghost"
                              size="sm"
                              className="h-7 px-2 text-[10px] text-white/70 hover:text-white"
                              onClick={() => copyText(msg.content)}
                            >
                              Copy all
                            </Button>
                          </div>
                        )}
                        {msg.type === 'text' || msg.type === 'code' ? (
                          <div className="prose prose-invert max-w-none text-sm leading-relaxed">
                            <ReactMarkdown
                              components={{
                                code({ children, className, inline, ...props }: any) {
                                  const raw = String(children ?? '')
                                  const text = raw.replace(/\n$/, '')
                                  const lang = (className || '').replace('language-', '')
                                  if (inline) {
                                    return (
                                      <code className="px-1.5 py-0.5 rounded bg-black/30 border border-white/10 text-white/90" {...props}>
                                        {children}
                                      </code>
                                    )
                                  }
                                  return (
                                    <div className="not-prose my-3 overflow-hidden rounded-2xl border border-white/10 bg-black/40">
                                      <div className="flex items-center justify-between px-3 py-2 border-b border-white/10 bg-black/30">
                                        <span className="text-[10px] font-black uppercase tracking-widest text-white/50">
                                          {lang || 'code'}
                                        </span>
                                        <Button
                                          type="button"
                                          variant="ghost"
                                          size="sm"
                                          className="h-7 px-2 text-[10px] text-white/70 hover:text-white"
                                          onClick={() => copyText(text)}
                                        >
                                          Copy
                                        </Button>
                                      </div>
                                      <pre className="p-3 overflow-x-auto text-[12px] leading-relaxed text-white/90">
                                        <code>{text}</code>
                                      </pre>
                                    </div>
                                  )
                                },
                              }}
                            >
                              {msg.content}
                            </ReactMarkdown>
                          </div>
                        ) : msg.type === 'image' ? (
                          <div className="space-y-3">
                            <div className="relative group">
                              <img src={msg.mediaUrl} alt="AI Gen" className="rounded-2xl w-full max-w-sm border border-white/10 shadow-2xl transition-transform hover:scale-[1.02] duration-500" />
                              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center rounded-2xl">
                                <Button size="sm" variant="ghost" className="text-white" onClick={() => window.open(msg.mediaUrl)}>
                                  <ImageIcon className="w-4 h-4 mr-2" /> View Full
                                </Button>
                              </div>
                            </div>
                            <Button size="sm" variant="outline" className="h-8 rounded-lg border-white/10 text-[10px] gap-2 w-full max-w-sm" onClick={() => window.open(msg.mediaUrl)}>
                              <Download className="w-3 h-3" /> Download High Res (Flux)
                            </Button>
                          </div>
                        ) : msg.type === 'video' ? (
                          <div className="space-y-3">
                            <div className="relative rounded-2xl overflow-hidden border border-white/10 shadow-2xl bg-black max-w-sm">
                              {/* Pollinations "video" is often a high-quality animated image or short clip */}
                              <img 
                                src={msg.mediaUrl} 
                                alt="AI Video Gen" 
                                className="w-full h-auto min-h-[200px] object-cover"
                                onError={(e) => {
                                  // Fallback to video tag if img fails (just in case)
                                  const target = e.target as any;
                                  target.style.display = 'none';
                                  if (target.nextSibling) target.nextSibling.style.display = 'block';
                                }}
                              />
                              <video 
                                src={msg.mediaUrl} 
                                controls 
                                autoPlay 
                                loop 
                                muted 
                                className="hidden w-full h-auto"
                                style={{ display: 'none' }}
                              />
                              <div className="absolute top-3 left-3 px-2 py-1 bg-purple-600/80 backdrop-blur-md rounded-md text-[8px] font-black uppercase tracking-widest flex items-center gap-1">
                                <Video className="w-2.5 h-2.5" /> GFXV1 Video Beta
                              </div>
                            </div>
                            <p className="text-[10px] text-white/40 italic px-2">
                              Short cinematic animation generated for your prompt.
                            </p>
                          </div>
                        ) : (
                          <div className="space-y-3 p-2">
                            <div className="flex items-center gap-3 bg-white/5 p-4 rounded-2xl border border-white/10">
                              <div className="w-10 h-10 rounded-full bg-purple-500/20 flex items-center justify-center">
                                <Music className="w-5 h-5 text-purple-400" />
                              </div>
                              <div className="flex-1">
                                <p className="text-xs font-bold mb-1">GFXV1 Generated Audio</p>
                                <audio src={msg.mediaUrl} controls className="h-8 w-full filter invert hue-rotate-180 opacity-70" />
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                      <p className="text-[10px] text-white/20 font-bold px-1 uppercase tracking-tighter">
                        {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </p>
                    </div>
                  </div>
                ))
              )}
              <div ref={scrollRef} />
            </div>

            {/* Input Area */}
            <div className="p-6 bg-gradient-to-t from-[#0a0a14] to-transparent">
              <div className="relative group">
                <div className="absolute inset-0 bg-gradient-to-r from-purple-500/20 to-blue-600/20 rounded-[24px] blur-xl opacity-0 group-focus-within:opacity-100 transition-opacity" />
                <div className="relative flex items-end gap-3 p-2 bg-white/[0.03] border border-white/10 rounded-[24px] focus-within:border-purple-500/50 transition-all">
                  <div className="flex gap-1 p-1">
                    <button className="p-2 rounded-xl hover:bg-white/5 text-white/40 transition-colors">
                      <Mic className="w-5 h-5" />
                    </button>
                  </div>
                  <textarea
                    rows={1}
                    value={input}
                    onChange={e => setInput(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), handleSend())}
                    placeholder={
                      mode === 'chat'
                        ? (chatStyle === 'code' ? 'Describe the feature/bug and paste code if needed...' : 'Ask GFXV1 anything...')
                        : mode === 'photo' ? 'Describe the photo you want to create...' :
                        mode === 'video' ? 'Describe the video scene...' : 'Describe the audio/music...'
                    }
                    className="flex-1 bg-transparent border-0 focus:ring-0 text-white placeholder:text-white/20 py-3 resize-none max-h-48 text-sm min-w-0"
                  />
                  <Button 
                    onClick={handleSend}
                    disabled={loading || (!input.trim() && mode === 'chat')}
                    className="h-11 w-11 rounded-2xl bg-gradient-to-br from-purple-500 to-blue-600 text-white shadow-lg shadow-purple-500/20 active:scale-95 transition-all p-0"
                  >
                    {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
                  </Button>
                </div>
              </div>
              <p className="text-center text-[10px] text-white/20 mt-4 uppercase tracking-[0.2em] font-black">
                {selectedModel} AGENT — POWERED BY GFXSTORE CORE
              </p>
            </div>
          </Card>
        </div>
      </div>

      <style jsx global>{`
        .custom-scrollbar::-webkit-scrollbar { width: 5px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.05); border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: rgba(255,255,255,0.1); }
      `}</style>
    </div>
  )
}
