import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Providers } from "@/components/providers";
import { SecurityGuard } from "@/components/security-guard";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:5000'),
  title: "GfxStore - Professional Content Marketplace",
  description: "Discover and download professional apps, code projects, videos, graphics, and more. Join the community of creators and developers.",
  keywords: ["apps", "code", "videos", "graphics", "marketplace", "professional", "content"],
  authors: [{ name: "GfxStore Team" }],
  icons: {
    icon: [
      { url: "/favicon.svg", type: "image/svg+xml" },
      { url: "/favicon.ico" }
    ],
    apple: "/logo.svg",
  },
  openGraph: {
    title: "GfxStore - Professional Content Marketplace",
    description: "Download high-quality apps, code, videos, and graphics. The ultimate hub for creators and developers.",
    url: "https://gfxstore.com",
    siteName: "GfxStore",
    images: [
      {
        url: "/opengraph.jpg",
        width: 1200,
        height: 630,
        alt: "GfxStore - Professional Content Marketplace",
      },
    ],
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "GfxStore - Professional Content Marketplace",
    description: "Download high-quality apps, code, videos, and graphics.",
    images: ["/opengraph.jpg"],
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="icon" href="/favicon.svg" type="image/svg+xml" />
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <Providers>
          <SecurityGuard />
          {children}
        </Providers>
      </body>
    </html>
  );
}
