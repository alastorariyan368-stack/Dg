'use client'

import { useState, useEffect, useRef } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import {
  ArrowLeft, Copy, CheckCircle2, AlertCircle, Smartphone, Bitcoin, Building2, Globe,
  Wallet, Download, Printer, ArrowRight, Loader2, QrCode, History, RefreshCw
} from 'lucide-react'
import { toast } from 'sonner'
import Link from 'next/link'

const METHOD_STYLE: Record<string, any> = {
  nagad:   { color: 'orange', icon: Smartphone, border: 'border-orange-500/30', bg: 'bg-orange-500/10', btn: 'from-orange-500 to-orange-600', badgeClass: 'bg-orange-500/20 text-orange-300 border-orange-500/30' },
  bkash:   { color: 'pink',   icon: Smartphone, border: 'border-pink-500/30',   bg: 'bg-pink-500/10',   btn: 'from-pink-500 to-pink-600',   badgeClass: 'bg-pink-500/20 text-pink-300 border-pink-500/30' },
  binance: { color: 'yellow', icon: Bitcoin,     border: 'border-yellow-500/30', bg: 'bg-yellow-500/10', btn: 'from-yellow-500 to-yellow-600', badgeClass: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30' },
  bank:    { color: 'blue',   icon: Building2,   border: 'border-blue-500/30',   bg: 'bg-blue-500/10',   btn: 'from-blue-500 to-blue-600',   badgeClass: 'bg-blue-500/20 text-blue-300 border-blue-500/30' },
  paypal:  { color: 'sky',    icon: Globe,       border: 'border-sky-500/30',    bg: 'bg-sky-500/10',    btn: 'from-sky-500 to-sky-600',     badgeClass: 'bg-sky-500/20 text-sky-300 border-sky-500/30' },
}

function CopyBtn({ text }: { text: string }) {
  const [done, setDone] = useState(false)
  return (
    <button onClick={() => { navigator.clipboard.writeText(text); setDone(true); setTimeout(() => setDone(false), 2000) }}
      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-white/[0.07] hover:bg-white/[0.12] text-white/50 hover:text-white text-xs transition-all flex-shrink-0">
      {done ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
      {done ? 'Copied' : 'Copy'}
    </button>
  )
}

function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between py-2.5 border-b border-white/[0.05] last:border-0">
      <span className="text-white/40 text-xs">{label}</span>
      <div className="flex items-center gap-2">
        <span className="font-mono text-sm text-white font-medium">{value}</span>
        <CopyBtn text={value} />
      </div>
    </div>
  )
}

type Step = 'method' | 'amount' | 'details' | 'receipt'

export default function DepositPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const receiptRef = useRef<HTMLDivElement>(null)

  const [step, setStep] = useState<Step>('method')
  const [methods, setMethods] = useState<any[]>([])
  const [methodsLoading, setMethodsLoading] = useState(true)
  const [selectedMethod, setSelectedMethod] = useState('')
  const [amount, setAmount] = useState('')
  const [transactionId, setTransactionId] = useState('')
  const [transactionType, setTransactionType] = useState('Send Money')
  const [paymentInfo, setPaymentInfo] = useState<any>(null)
  const [loadingInfo, setLoadingInfo] = useState(false)
  const [submitting, setSubmitting] = useState(false)
  const [receipt, setReceipt] = useState<any>(null)
  const [recentDeposits, setRecentDeposits] = useState<any[]>([])
  const [loadingHistory, setLoadingHistory] = useState(true)

  // Manual submission state
  const [manualTxId, setManualTxId] = useState('')
  const [manualAmount, setManualAmount] = useState('')
  const [manualType, setManualType] = useState('Send Money')
  const [manualMethod, setManualMethod] = useState('nagad')
  const [manualSubmitting, setManualSubmitting] = useState(false)

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin?callbackUrl=/deposit')
    if (status === 'authenticated') fetchHistory()
  }, [status, router])

  const fetchHistory = async () => {
    try {
      const res2 = await fetch('/api/transactions?type=DEPOSIT&limit=5')
      if (res2.ok) {
        const data = await res2.json()
        setRecentDeposits(data.transactions || [])
      }
    } catch { }
    finally { setLoadingHistory(false) }
  }

  const handleManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!manualTxId.trim() || !manualAmount) { toast.error('Fill all fields'); return }
    setManualSubmitting(true)
    try {
      const res = await fetch('/api/payment/deposit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          amount: parseFloat(manualAmount), 
          method: manualMethod, 
          transactionId: manualTxId,
          transactionType: manualType
        }),
      })
      if (res.ok) {
        toast.success('Transaction submitted for review!')
        setManualTxId(''); setManualAmount('')
        fetchHistory()
      } else {
        const d = await res.json()
        toast.error(d.error || 'Failed')
      }
    } catch { toast.error('Network error') }
    finally { setManualSubmitting(false) }
  }

  useEffect(() => {
    setMethodsLoading(true)
    fetch('/api/payment/deposit-info').then(r => r.json()).then(d => {
      setMethods(d.methods || [])
    }).catch(() => {}).finally(() => setMethodsLoading(false))
  }, [])

  const selectMethod = async (m: string) => {
    setSelectedMethod(m)
    setLoadingInfo(true)
    try {
      const res = await fetch('/api/payment/deposit-info', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ method: m }),
      })
      const data = await res.json()
      if (!res.ok) { toast.error(data.error || 'Failed'); return }
      setPaymentInfo(data)
      setStep('amount')
    } catch { toast.error('Network error') }
    finally { setLoadingInfo(false) }
  }

  const goToDetails = () => {
    if (!amount || parseFloat(amount) <= 0) { toast.error('Enter a valid amount'); return }
    setStep('details')
  }

  const confirmPayment = async () => {
    if (!transactionId.trim()) { toast.error('Please enter Transaction ID'); return }
    setSubmitting(true)
    try {
      const res = await fetch('/api/payment/deposit', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ amount: parseFloat(amount), method: selectedMethod, transactionId, transactionType }),
      })
      const data = await res.json()
      if (!res.ok) { toast.error(data.error || 'Failed'); return }

      // Build receipt
      const systemTxId = data.transaction?.id || 'N/A'
      const userRef = session?.user?.username || (session?.user as any)?.name || session?.user?.email || 'User'
      const shortOrderId = systemTxId.slice(-8).toUpperCase()
      const providedTrxId = transactionId.trim() || 'N/A'
      
      setReceipt({
        systemTxId,
        userReference: userRef,
        providedTrxId,
        shortOrderId,
        amount: parseFloat(amount),
        method: paymentInfo.methodName,
        methodKey: selectedMethod,
        transactionType,
        destination: paymentInfo.phoneNumber || paymentInfo.binanceId || paymentInfo.email
          || paymentInfo.bankDetails?.accountNumber || '',
        paymentInfo,
        timestamp: new Date().toLocaleString('en-BD', { timeZone: 'Asia/Dhaka' }),
        user: session?.user?.name || session?.user?.email || '',
      })
      setStep('receipt')
    } catch { toast.error('Network error') }
    finally { setSubmitting(false) }
  }

  const printReceipt = () => window.print()

  if (status === 'loading') return null

  const style = METHOD_STYLE[selectedMethod] || METHOD_STYLE.bank

  return (
    <div className="min-h-screen bg-[#060611]">
      <Navbar />

      <div className="max-w-xl mx-auto px-4 py-10">
        {/* Header */}
        <div className="flex items-center gap-3 mb-8">
          {step !== 'method' && step !== 'receipt' ? (
            <button onClick={() => setStep(step === 'amount' ? 'method' : 'amount')}
              className="text-white/30 hover:text-white transition p-2 rounded-xl hover:bg-white/[0.05]">
              <ArrowLeft className="w-4 h-4" />
            </button>
          ) : (
            <Link href="/" className="text-white/30 hover:text-white transition p-2 rounded-xl hover:bg-white/[0.05]">
              <ArrowLeft className="w-4 h-4" />
            </Link>
          )}
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-emerald-500/20 to-teal-600/20 border border-emerald-500/20 flex items-center justify-center">
            <Wallet className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-white">Add Funds</h1>
            <p className="text-white/40 text-sm">
              {step === 'method' && 'Select payment method'}
              {step === 'amount' && `Enter amount — ${paymentInfo?.methodName}`}
              {step === 'details' && 'Send payment to this address'}
              {step === 'receipt' && 'Payment submitted!'}
            </p>
          </div>
        </div>

        {/* Step indicators */}
        {step !== 'receipt' && (
          <div className="flex items-center gap-2 mb-8">
            {(['method', 'amount', 'details'] as Step[]).map((s, i) => (
              <div key={s} className="flex items-center gap-2">
                <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                  step === s ? 'bg-emerald-500 text-white' : 
                  (['method', 'amount', 'details'] as Step[]).indexOf(step) > i ? 'bg-emerald-500/30 text-emerald-400' : 
                  'bg-white/[0.06] text-white/30'
                }`}>{i + 1}</div>
                <span className={`text-xs capitalize ${step === s ? 'text-white' : 'text-white/30'}`}>
                  {s === 'method' ? 'Method' : s === 'amount' ? 'Amount' : 'Pay'}
                </span>
                {i < 2 && <div className="w-8 h-px bg-white/[0.08]" />}
              </div>
            ))}
          </div>
        )}

        {/* ── STEP 1: METHOD ── */}
        {step === 'method' && (
          <div className="space-y-4">
            {methodsLoading ? (
              <div className="py-16 flex justify-center"><Loader2 className="w-6 h-6 animate-spin text-white/30" /></div>
            ) : methods.length === 0 ? (
              <div className="py-16 text-center text-white/30 text-sm">No payment methods available. Contact admin.</div>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                {methods.map(m => {
                  const ms = METHOD_STYLE[m.id] || METHOD_STYLE.bank
                  const Icon = ms.icon
                  const isLoading = loadingInfo && selectedMethod === m.id
                  return (
                    <button key={m.id} onClick={() => !loadingInfo && selectMethod(m.id)}
                      disabled={loadingInfo}
                      className={`group p-5 rounded-2xl border ${ms.border} ${ms.bg} hover:brightness-125 transition-all text-left relative`}>
                      <Icon className={`w-6 h-6 text-${ms.color}-400 mb-3`} />
                      <p className={`font-bold text-${ms.color}-300 text-base`}>{m.label}</p>
                      <p className="text-white/30 text-xs mt-0.5">{m.badge}</p>
                      {isLoading && <div className="absolute inset-0 rounded-2xl bg-black/40 flex items-center justify-center"><Loader2 className="w-5 h-5 animate-spin text-white" /></div>}
                    </button>
                  )
                })}
              </div>
            )}
            <div className="flex items-center gap-2 p-3 rounded-xl bg-white/[0.03] border border-white/[0.06]">
              <AlertCircle className="w-4 h-4 text-amber-400 flex-shrink-0" />
              <p className="text-white/40 text-xs">Send payment first, then submit your reference. Wallet credited within 30 minutes.</p>
            </div>
          </div>
        )}

        {/* ── STEP 2: AMOUNT ── */}
        {step === 'amount' && paymentInfo && (
          <div className="space-y-5">
            <div className={`rounded-2xl border ${style.border} ${style.bg} p-5`}>
              <p className={`text-${style.color}-300 text-xs font-semibold uppercase tracking-wider mb-3`}>Selected method</p>
              <div className="flex items-center gap-2">
                <style.icon className={`w-5 h-5 text-${style.color}-400`} />
                <span className="text-white font-bold">{paymentInfo.methodName}</span>
              </div>
              {paymentInfo.instruction && (
                <p className="text-white/40 text-xs mt-2">{paymentInfo.instruction}</p>
              )}
            </div>

            <div>
              <label className="text-white/50 text-xs font-medium block mb-2">Amount (৳)</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-white/40 font-bold text-lg">৳</span>
                <Input
                  type="number" value={amount} onChange={e => setAmount(e.target.value)}
                  min="1" step="1" placeholder="0"
                  className="pl-9 h-14 bg-white/[0.04] border-white/[0.08] text-white text-2xl font-bold rounded-xl focus:border-emerald-500/50"
                  autoFocus
                />
              </div>
              <div className="flex gap-2 mt-2">
                {[100, 200, 500, 1000].map(v => (
                  <button key={v} onClick={() => setAmount(String(v))}
                    className="flex-1 py-1.5 rounded-lg bg-white/[0.05] hover:bg-white/[0.09] text-white/60 hover:text-white text-xs transition">
                    ৳{v}
                  </button>
                ))}
              </div>
            </div>

            <Button onClick={goToDetails} className={`w-full h-12 bg-gradient-to-r ${style.btn} text-white font-bold rounded-xl text-base gap-2`}>
              Continue <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        )}

        {/* ── STEP 3: PAYMENT DETAILS ── */}
        {step === 'details' && paymentInfo && (
          <div className="space-y-4">
            {/* Amount banner */}
            <div className="rounded-2xl bg-gradient-to-br from-emerald-500/15 to-teal-600/10 border border-emerald-500/20 p-5 text-center">
              <p className="text-emerald-400/70 text-sm mb-1">Amount to send</p>
              <p className="text-4xl font-bold text-white">৳{parseFloat(amount).toLocaleString()}</p>
              <p className="text-white/40 text-xs mt-1">via {paymentInfo.methodName}</p>
            </div>

            {/* Payment info */}
            <div className={`rounded-2xl border ${style.border} ${style.bg} p-5`}>
              <p className={`text-${style.color}-300 text-xs font-semibold uppercase tracking-wider mb-3`}>Send To</p>

              {paymentInfo.type === 'mobile' && paymentInfo.phoneNumber && (
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white/40 text-xs">Send Money Number</p>
                    <p className="font-mono font-bold text-2xl text-white tracking-wider mt-0.5">{paymentInfo.phoneNumber}</p>
                  </div>
                  <CopyBtn text={paymentInfo.phoneNumber} />
                </div>
              )}

              {paymentInfo.type === 'crypto' && paymentInfo.binanceId && (
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white/40 text-xs">Binance Pay ID</p>
                    <p className="font-mono font-bold text-2xl text-white tracking-wider mt-0.5">{paymentInfo.binanceId}</p>
                  </div>
                  <CopyBtn text={paymentInfo.binanceId} />
                </div>
              )}

              {paymentInfo.type === 'paypal' && paymentInfo.email && (
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-white/40 text-xs">PayPal Email</p>
                    <p className="font-mono font-bold text-lg text-white tracking-wider mt-0.5">{paymentInfo.email}</p>
                  </div>
                  <CopyBtn text={paymentInfo.email} />
                </div>
              )}

              {paymentInfo.type === 'bank' && paymentInfo.bankDetails && (
                <div className="space-y-0 divide-y divide-white/[0.06]">
                  {[
                    { label: 'Bank', value: paymentInfo.bankDetails.bankName },
                    { label: 'Account Name', value: paymentInfo.bankDetails.accountName },
                    { label: 'Account No.', value: paymentInfo.bankDetails.accountNumber },
                    { label: 'Routing No.', value: paymentInfo.bankDetails.routingNumber },
                    { label: 'SWIFT/BIC', value: paymentInfo.bankDetails.swiftCode },
                    { label: 'Branch', value: paymentInfo.bankDetails.branch },
                  ].filter(f => f.value).map(f => (
                    <InfoRow key={f.label} label={f.label} value={f.value} />
                  ))}
                </div>
              )}

              {paymentInfo.qr && (
                <div className="mt-4 flex justify-center">
                  <div className="p-3 bg-white rounded-2xl">
                    <img src={paymentInfo.qr} alt="QR" className="w-36 h-36 object-contain" />
                  </div>
                </div>
              )}
            </div>

            {paymentInfo.instruction && (
              <div className="flex items-start gap-2 p-3 rounded-xl bg-white/[0.03] border border-white/[0.06]">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" />
                <p className="text-white/50 text-xs">{paymentInfo.instruction}</p>
              </div>
            )}

            <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
              <p className="text-amber-300 text-xs">After sending, enter your Transaction ID below. Admin will verify and credit your wallet within 30 minutes.</p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-white/50 text-xs font-medium block">Transaction Type</label>
                <select
                  value={transactionType}
                  onChange={e => setTransactionType(e.target.value)}
                  className="w-full h-12 bg-white/[0.04] border border-white/[0.08] text-white text-sm rounded-xl px-4 appearance-none focus:outline-none focus:border-emerald-500/50"
                >
                  <option value="Send Money" className="bg-[#0e0e1a]">Send Money</option>
                  <option value="Cash Out" className="bg-[#0e0e1a]">Cash Out</option>
                  <option value="Payment" className="bg-[#0e0e1a]">Payment</option>
                  <option value="Transfer" className="bg-[#0e0e1a]">Transfer</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-white/50 text-xs font-medium block">Transaction ID / Reference</label>
                <Input
                  value={transactionId}
                  onChange={e => setTransactionId(e.target.value)}
                  placeholder="Enter Transaction ID"
                  className="h-12 bg-white/[0.04] border-white/[0.08] text-white rounded-xl focus:border-emerald-500/50"
                />
              </div>
            </div>

            <Button onClick={confirmPayment} disabled={submitting}
              className={`w-full h-12 bg-gradient-to-r ${style.btn} text-white font-bold rounded-xl text-base gap-2`}>
              {submitting ? <><Loader2 className="w-4 h-4 animate-spin" />Processing…</> : <>I've Sent the Payment — Submit</>}
            </Button>
          </div>
        )}

        {/* ── STEP 4: RECEIPT ── */}
        {step === 'receipt' && receipt && (
          <div className="space-y-4 animate-in fade-in zoom-in duration-300">
            {/* Success */}
            <div className="rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-6 text-center">
              <div className="w-14 h-14 rounded-full bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center mx-auto mb-3">
                <CheckCircle2 className="w-7 h-7 text-emerald-400" />
              </div>
              <h2 className="text-xl font-bold text-white mb-1">Payment Submitted!</h2>
              <p className="text-emerald-400/70 text-sm">Admin will verify and credit your wallet within 30 minutes.</p>
            </div>

            {/* Receipt card — printable */}
            <div ref={receiptRef} className="receipt-card rounded-2xl border border-white/[0.1] bg-[#0a0a14] p-6 space-y-4">
              <div className="flex items-center justify-between border-b border-white/[0.08] pb-4">
                <div>
                  <p className="text-lg font-bold text-white">GfxStore</p>
                  <p className="text-white/40 text-xs">Payment Receipt</p>
                </div>
                <div className="text-right">
                  <p className="text-emerald-400 font-bold text-sm">SUBMITTED</p>
                  <p className="text-white/30 text-xs">{receipt.timestamp}</p>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex justify-between items-center text-xs font-bold uppercase tracking-widest text-white/20 pb-1 border-b border-white/5">
                  <span>Payment Receipt</span>
                  <span className="text-emerald-500/50">#{receipt.shortOrderId}</span>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-white/40 text-sm">User / Account</span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-emerald-400 font-bold">{receipt.userReference}</span>
                    <CopyBtn text={receipt.userReference} />
                  </div>
                </div>

                <div className="flex justify-between">
                  <span className="text-white/40 text-sm">Amount Paid</span>
                  <span className="text-emerald-400 font-bold text-lg">৳{receipt.amount.toLocaleString()}</span>
                </div>

                <div className="flex justify-between">
                  <span className="text-white/40 text-sm">Sender TrxID</span>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-white/70 text-xs">{receipt.providedTrxId}</span>
                    <CopyBtn text={receipt.providedTrxId} />
                  </div>
                </div>

                <div className="flex justify-between">
                  <span className="text-white/40 text-sm">Method</span>
                  <span className="text-white font-medium">{receipt.method} ({receipt.transactionType})</span>
                </div>

                <div className="flex justify-between border-t border-white/5 pt-3 mt-3">
                  <span className="text-white/20 text-[10px] uppercase font-bold">Order Reference</span>
                  <span className="font-mono text-white/20 text-[10px]">#{receipt.shortOrderId}</span>
                </div>
                {receipt.destination && (
                  <div className="flex justify-between">
                    <span className="text-white/40 text-sm">Sent To</span>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-white text-sm">{receipt.destination}</span>
                      <CopyBtn text={receipt.destination} />
                    </div>
                  </div>
                )}
                {receipt.paymentInfo?.type === 'bank' && receipt.paymentInfo?.bankDetails && (
                  <div className="pt-2 border-t border-white/[0.06] space-y-2">
                    <p className="text-white/30 text-xs font-semibold uppercase tracking-wider">Bank Details</p>
                    {[
                      { label: 'Bank', value: receipt.paymentInfo.bankDetails.bankName },
                      { label: 'Account No.', value: receipt.paymentInfo.bankDetails.accountNumber },
                      { label: 'Routing No.', value: receipt.paymentInfo.bankDetails.routingNumber },
                      { label: 'SWIFT', value: receipt.paymentInfo.bankDetails.swiftCode },
                    ].filter(f => f.value).map(f => (
                      <div key={f.label} className="flex justify-between text-xs">
                        <span className="text-white/30">{f.label}</span>
                        <span className="text-white/60 font-mono">{f.value}</span>
                      </div>
                    ))}
                  </div>
                )}
                <div className="pt-2 border-t border-white/[0.06]">
                  <span className="text-white/40 text-sm">Account</span>
                  <span className="text-white/60 text-sm ml-2">{receipt.user}</span>
                </div>
              </div>

              <div className="rounded-xl bg-amber-500/10 border border-amber-500/20 p-3">
                <p className="text-amber-300 text-xs font-semibold mb-1">If there's any issue</p>
                <p className="text-amber-300/70 text-xs">Contact admin with your Order ID <strong className="text-amber-300">#{receipt.shortOrderId}</strong> and your TrxID. We'll resolve within 24 hours.</p>
              </div>
            </div>

            <div className="flex gap-3">
              <Button onClick={printReceipt} variant="outline"
                className="flex-1 h-11 border-white/10 text-white hover:bg-white/[0.06] bg-transparent gap-2">
                <Printer className="w-4 h-4" /> Print / Save PDF
              </Button>
              <Button onClick={() => router.push('/wallet')}
                className="flex-1 h-11 bg-emerald-600 hover:bg-emerald-500 text-white gap-2">
                <Wallet className="w-4 h-4" /> View Wallet
              </Button>
            </div>
          </div>
        )}

        {/* ── MANUAL SUBMISSION & HISTORY (Visible only on first step) ── */}
        <div className={`mt-16 pt-10 border-t border-white/[0.05] space-y-10 ${step !== 'method' ? 'hidden' : ''}`}>
          <div className="flex items-center gap-2 p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 mb-6">
            <AlertCircle className="w-4 h-4 text-amber-400 flex-shrink-0" />
            <p className="text-amber-300 text-xs">Use this section only if you forgot to submit your Transaction ID during the deposit process.</p>
          </div>
          {/* Manual Submission Form */}
          <section>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/20 flex items-center justify-center">
                <CheckCircle2 className="w-4 h-4 text-amber-400" />
              </div>
              <div>
                <h2 className="text-lg font-bold text-white">Manual Transaction Submission</h2>
                <p className="text-white/40 text-xs">If you forgot to submit your Transaction ID during the flow, do it here.</p>
              </div>
            </div>

            <Card className="bg-white/[0.02] border-white/10 p-6">
              <form onSubmit={handleManualSubmit} className="grid sm:grid-cols-3 gap-4">
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-white/30 uppercase tracking-widest ml-1">Payment Method</label>
                  <select 
                    value={manualMethod} 
                    onChange={e => setManualMethod(e.target.value)}
                    className="w-full h-11 bg-white/[0.04] border border-white/[0.08] text-white text-sm rounded-xl px-3 appearance-none focus:outline-none focus:border-emerald-500/50"
                  >
                    <option value="nagad" className="bg-[#0e0e1a]">Nagad</option>
                    <option value="bkash" className="bg-[#0e0e1a]">bKash</option>
                    <option value="binance" className="bg-[#0e0e1a]">Binance</option>
                    <option value="bank" className="bg-[#0e0e1a]">Bank Transfer</option>
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-white/30 uppercase tracking-widest ml-1">Transaction Type</label>
                  <select 
                    value={manualType} 
                    onChange={e => setManualType(e.target.value)}
                    className="w-full h-11 bg-white/[0.04] border border-white/[0.08] text-white text-sm rounded-xl px-3 appearance-none focus:outline-none focus:border-emerald-500/50"
                  >
                    <option value="Send Money" className="bg-[#0e0e1a]">Send Money</option>
                    <option value="Cash Out" className="bg-[#0e0e1a]">Cash Out</option>
                    <option value="Payment" className="bg-[#0e0e1a]">Payment</option>
                  </select>
                </div>
                <div className="space-y-1.5">
                  <label className="text-[10px] font-bold text-white/30 uppercase tracking-widest ml-1">Amount (৳)</label>
                  <Input 
                    type="number" 
                    placeholder="0.00" 
                    value={manualAmount}
                    onChange={e => setManualAmount(e.target.value)}
                    className="h-11 bg-white/[0.04] border-white/[0.08] text-white rounded-xl focus:border-emerald-500/50"
                  />
                </div>
                <div className="sm:col-span-3 space-y-1.5">
                  <label className="text-[10px] font-bold text-white/30 uppercase tracking-widest ml-1">Transaction ID / TrxID</label>
                  <div className="flex gap-2">
                    <Input 
                      placeholder="Enter the TrxID from your SMS/App" 
                      value={manualTxId}
                      onChange={e => setManualTxId(e.target.value)}
                      className="h-11 bg-white/[0.04] border-white/[0.08] text-white rounded-xl focus:border-emerald-500/50"
                    />
                    <Button 
                      disabled={manualSubmitting}
                      className="bg-emerald-600 hover:bg-emerald-500 text-white font-bold px-6 rounded-xl h-11 whitespace-nowrap"
                    >
                      {manualSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Submit Now'}
                    </Button>
                  </div>
                </div>
              </form>
            </Card>
          </section>

          {/* Recent Deposits History */}
          <section>
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-blue-500/10 border border-blue-500/20 flex items-center justify-center">
                  <History className="w-4 h-4 text-blue-400" />
                </div>
                <h2 className="text-lg font-bold text-white">Recent Deposits</h2>
              </div>
              <Button variant="ghost" size="sm" onClick={fetchHistory} className="text-white/30 hover:text-white h-8 w-8 p-0">
                <RefreshCw className="w-3.5 h-3.5" />
              </Button>
            </div>

            <Card className="bg-white/[0.02] border-white/10 overflow-hidden">
              {loadingHistory ? (
                <div className="py-10 flex justify-center"><Loader2 className="w-5 h-5 animate-spin text-white/20" /></div>
              ) : recentDeposits.length === 0 ? (
                <div className="py-10 text-center text-white/20 text-sm">No recent deposit records found.</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm">
                    <thead>
                      <tr className="border-b border-white/5 bg-white/[0.02]">
                        <th className="px-6 py-3.5 text-white/40 font-bold uppercase tracking-wider text-[10px]">Method & Date</th>
                        <th className="px-6 py-3.5 text-white/40 font-bold uppercase tracking-wider text-[10px]">Amount</th>
                        <th className="px-6 py-3.5 text-white/40 font-bold uppercase tracking-wider text-[10px]">Sender TrxID</th>
                        <th className="px-6 py-3.5 text-white/40 font-bold uppercase tracking-wider text-[10px]">Reference</th>
                        <th className="px-6 py-3.5 text-white/40 font-bold uppercase tracking-wider text-[10px]">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-white/5">
                      {recentDeposits.map((d) => (
                        <tr key={d.id} className="hover:bg-white/[0.02] transition-colors">
                          <td className="px-6 py-4">
                            <p className="text-white font-medium capitalize">{d.method}</p>
                            <p className="text-[10px] text-white/30">{new Date(d.createdAt).toLocaleString()}</p>
                          </td>
                          <td className="px-6 py-4">
                            <span className="text-white font-mono font-bold">৳{d.amount.toLocaleString()}</span>
                          </td>
                          <td className="px-6 py-4">
                            <code className="text-[11px] text-white/50 font-mono">
                              {d.reference || 'N/A'}
                            </code>
                          </td>
                          <td className="px-6 py-4">
                            <code className="text-[11px] text-emerald-400 bg-emerald-500/5 px-1.5 py-0.5 rounded border border-emerald-500/10">
                              {session?.user?.username || session?.user?.name || 'User'}
                            </code>
                          </td>
                          <td className="px-6 py-4">
                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${
                              d.status === 'APPROVED' || d.status === 'COMPLETED' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' :
                              d.status === 'PENDING' ? 'bg-amber-500/10 text-amber-400 border-amber-500/20' :
                              'bg-red-500/10 text-red-400 border-red-500/20'
                            }`}>
                              {d.status}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </Card>
          </section>
        </div>
      </div>

      <style jsx global>{`
        @media print {
          body > *:not(.receipt-print-area) { display: none !important; }
          .receipt-card { display: block !important; border: 1px solid #333 !important; background: white !important; color: black !important; }
        }
      `}</style>
    </div>
  )
}
