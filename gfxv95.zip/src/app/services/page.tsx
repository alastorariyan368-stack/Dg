'use client'

import { useEffect, useState } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Loader2, Play, Power, RefreshCw, Server, SquareTerminal, Cpu, HardDrive, MemoryStick, Clock, Zap, ShieldCheck, Globe } from 'lucide-react'
import { toast } from 'sonner'

type Service = {
  id: string
  status: string
  amount: number
  expiresAt?: string
  serverInfo?: any
  plan: { name: string; specs?: any; description?: string }
}

function formatMb(val?: number | string) {
  const n = Number(val || 0)
  if (!n) return '—'
  return n >= 1024 ? `${(n / 1024).toFixed(1)} GB` : `${n} MB`
}

function StatBox({ icon, label, value, color }: { icon: React.ReactNode; label: string; value: string; color: string }) {
  return (
    <div className={`rounded-2xl border p-4 flex items-center gap-3 ${color}`}>
      <div className="shrink-0">{icon}</div>
      <div>
        <p className="text-[10px] uppercase tracking-widest font-bold opacity-60">{label}</p>
        <p className="text-sm font-bold text-white">{value}</p>
      </div>
    </div>
  )
}

export default function ServicesPage() {
  const { status } = useSession()
  const router = useRouter()
  const [services, setServices] = useState<Service[]>([])
  const [loading, setLoading] = useState(true)
  const [actionLoading, setActionLoading] = useState<string | null>(null)
  const [now, setNow] = useState(new Date())

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin')
    if (status === 'authenticated') loadServices()
    const t = setInterval(() => setNow(new Date()), 60000)
    return () => clearInterval(t)
  }, [status, router])

  async function loadServices() {
    setLoading(true)
    try {
      const res = await fetch('/api/vps-orders')
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Failed to load services')
      setServices((data.orders || []).filter((o: Service) => ['APPROVED', 'SUSPENDED'].includes(o.status)))
    } catch (error: any) {
      toast.error(error.message || 'Failed to load services')
    } finally {
      setLoading(false)
    }
  }

  async function power(service: Service, action: 'start' | 'stop' | 'restart') {
    setActionLoading(`${service.id}-${action}`)
    try {
      const res = await fetch(`/api/services/${service.id}/power`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || `Failed to ${action}`)
      toast.success(`VPS ${action} command sent successfully`)
      loadServices()
    } catch (error: any) {
      toast.error(error.message || `Failed to ${action}`)
    } finally {
      setActionLoading(null)
    }
  }

  const activeCount = services.filter(s => s.status === 'APPROVED' && !(s.expiresAt && new Date(s.expiresAt) < now)).length
  const expiredCount = services.filter(s => s.expiresAt && new Date(s.expiresAt) < now).length
  const suspendedCount = services.filter(s => s.status === 'SUSPENDED').length

  return (
    <div className="min-h-screen bg-[#07070d] text-white flex flex-col">
      {/* Background grid */}
      <div className="fixed inset-0 bg-[linear-gradient(to_right,#ffffff04_1px,transparent_1px),linear-gradient(to_bottom,#ffffff04_1px,transparent_1px)] bg-[size:40px_40px] pointer-events-none" />
      <div className="fixed top-40 left-1/4 w-72 h-72 bg-cyan-600/10 rounded-full blur-3xl pointer-events-none" />
      <div className="fixed bottom-40 right-1/4 w-72 h-72 bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

      <Navbar />
      <main className="flex-1 container mx-auto px-4 py-10 max-w-6xl relative z-10">
        {/* Header */}
        <div className="flex flex-wrap items-start justify-between gap-4 mb-8">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <div className="w-10 h-10 rounded-2xl bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center">
                <Server className="h-5 w-5 text-cyan-400" />
              </div>
              <h1 className="text-3xl font-black text-white tracking-tight">My Services</h1>
            </div>
            <p className="text-white/40 text-sm ml-13">Manage and monitor your VPS instances in real-time.</p>
          </div>
          <div className="flex items-center gap-2">
            <Link href="/vps">
              <Button variant="outline" className="border-white/10 hover:bg-white/5 text-white/70 rounded-xl gap-2">
                <Zap className="h-4 w-4 text-cyan-400" /> Buy VPS
              </Button>
            </Link>
            <Button onClick={loadServices} variant="outline" className="border-white/10 hover:bg-white/5 text-white/70 rounded-xl gap-2">
              <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} /> Refresh
            </Button>
          </div>
        </div>

        {/* Stats row */}
        {services.length > 0 && (
          <div className="grid grid-cols-3 gap-3 mb-8">
            <div className="rounded-2xl border border-emerald-500/20 bg-emerald-500/5 p-4 text-center">
              <p className="text-2xl font-black text-emerald-400">{activeCount}</p>
              <p className="text-[11px] text-white/40 font-bold uppercase tracking-widest mt-0.5">Active</p>
            </div>
            <div className="rounded-2xl border border-orange-500/20 bg-orange-500/5 p-4 text-center">
              <p className="text-2xl font-black text-orange-400">{suspendedCount}</p>
              <p className="text-[11px] text-white/40 font-bold uppercase tracking-widest mt-0.5">Suspended</p>
            </div>
            <div className="rounded-2xl border border-red-500/20 bg-red-500/5 p-4 text-center">
              <p className="text-2xl font-black text-red-400">{expiredCount}</p>
              <p className="text-[11px] text-white/40 font-bold uppercase tracking-widest mt-0.5">Expired</p>
            </div>
          </div>
        )}

        {loading ? (
          <div className="flex flex-col items-center justify-center h-64 gap-4">
            <div className="w-12 h-12 border-2 border-cyan-500 border-t-transparent rounded-full animate-spin" />
            <p className="text-white/30 text-sm">Loading your services…</p>
          </div>
        ) : services.length === 0 ? (
          <div className="rounded-3xl border border-white/[0.07] bg-white/[0.02] p-16 text-center">
            <div className="w-20 h-20 rounded-3xl bg-white/[0.04] border border-white/10 flex items-center justify-center mx-auto mb-6">
              <Server className="h-10 w-10 text-white/20" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-3">No active services</h2>
            <p className="text-white/40 mb-8 max-w-sm mx-auto text-sm leading-relaxed">
              Purchase a VPS plan, complete payment, and wait for admin approval. Your server will appear here automatically.
            </p>
            <div className="flex justify-center gap-3">
              <Link href="/vps">
                <Button className="bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 text-white rounded-xl px-8 gap-2">
                  <Zap className="h-4 w-4" /> View VPS Plans
                </Button>
              </Link>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
            {services.map((service) => {
              const specs = service.plan.specs || {}
              const info = service.serverInfo || {}
              const expired = service.expiresAt && new Date(service.expiresAt) < now
              const suspended = service.status === 'SUSPENDED'
              const isLoading = (k: string) => actionLoading === `${service.id}-${k}`

              const statusLabel = expired ? 'EXPIRED' : suspended ? 'SUSPENDED' : 'ONLINE'
              const statusColor = expired
                ? 'bg-red-500/15 text-red-300 border-red-500/30'
                : suspended
                ? 'bg-orange-500/15 text-orange-300 border-orange-500/30'
                : 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'

              const pulseColor = expired ? 'bg-red-500' : suspended ? 'bg-orange-500' : 'bg-emerald-500'

              const identifier = info.gfxContainerName || info.pteroIdentifier || service.id.slice(-8).toUpperCase()

              return (
                <div
                  key={service.id}
                  className="group relative rounded-3xl border border-white/[0.07] bg-white/[0.025] overflow-hidden hover:border-white/[0.12] transition-all duration-300"
                >
                  {/* Top gradient accent */}
                  <div className={`h-0.5 w-full ${expired ? 'bg-red-500/50' : suspended ? 'bg-orange-500/50' : 'bg-gradient-to-r from-cyan-500 via-purple-500 to-emerald-500'}`} />

                  <div className="p-6">
                    {/* Header */}
                    <div className="flex items-start justify-between gap-4 mb-5">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2.5 mb-1">
                          <div className={`w-2.5 h-2.5 rounded-full ${pulseColor} ${!expired && !suspended ? 'animate-pulse' : ''}`} />
                          <h3 className="text-lg font-bold text-white truncate">{service.plan.name}</h3>
                        </div>
                        <p className="text-xs text-white/30 font-mono">{identifier}</p>
                      </div>
                      <Badge className={`shrink-0 border text-[10px] font-bold px-2.5 py-1 ${statusColor}`}>
                        {statusLabel}
                      </Badge>
                    </div>

                    {/* Specs grid */}
                    <div className="grid grid-cols-3 gap-2.5 mb-5">
                      <StatBox
                        icon={<MemoryStick className="h-4 w-4 text-cyan-400" />}
                        label="RAM"
                        value={formatMb(specs.ram)}
                        color="border-cyan-500/15 bg-cyan-500/5"
                      />
                      <StatBox
                        icon={<Cpu className="h-4 w-4 text-purple-400" />}
                        label="CPU"
                        value={specs.cpu ? `${specs.cpu}%` : '—'}
                        color="border-purple-500/15 bg-purple-500/5"
                      />
                      <StatBox
                        icon={<HardDrive className="h-4 w-4 text-emerald-400" />}
                        label="Disk"
                        value={formatMb(specs.disk)}
                        color="border-emerald-500/15 bg-emerald-500/5"
                      />
                    </div>

                    {/* GFX Panel info */}
                    {info.gfxPanel && (
                      <div className="rounded-2xl border border-cyan-500/20 bg-gradient-to-br from-cyan-500/10 to-blue-500/5 p-4 mb-4 space-y-1.5">
                        <div className="flex items-center gap-2 mb-2">
                          <ShieldCheck className="h-3.5 w-3.5 text-cyan-400" />
                          <span className="text-xs font-bold text-cyan-300">GFX Panel Access</span>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-[11px]">
                          <div>
                            <span className="text-white/30">Email:</span>
                            <p className="text-white font-mono truncate">{info.gfxLoginEmail || 'Your account email'}</p>
                          </div>
                          {info.gfxPassword && (
                            <div>
                              <span className="text-white/30">Password:</span>
                              <p className="text-white font-mono">{info.gfxPassword}</p>
                            </div>
                          )}
                        </div>
                        {info.gfxVpsId && (
                          <p className="text-[11px] text-white/30">VPS ID: <span className="text-white/60 font-mono">{info.gfxVpsId}</span></p>
                        )}
                      </div>
                    )}

                    {/* Pterodactyl info */}
                    {info.pteroPanel && (
                      <div className="rounded-2xl border border-purple-500/20 bg-gradient-to-br from-purple-500/10 to-violet-500/5 p-4 mb-4 space-y-1.5">
                        <div className="flex items-center gap-2 mb-2">
                          <Globe className="h-3.5 w-3.5 text-purple-400" />
                          <span className="text-xs font-bold text-purple-300">Pterodactyl Panel</span>
                        </div>
                        {info.pteroIdentifier && (
                          <p className="text-[11px] text-white/30">Server ID: <span className="text-white/70 font-mono">{info.pteroIdentifier}</span></p>
                        )}
                        {info.pteroPassword && (
                          <p className="text-[11px] text-white/30">Password: <span className="text-white/70 font-mono">{info.pteroPassword}</span></p>
                        )}
                      </div>
                    )}

                    {/* Expiry */}
                    {service.expiresAt && (
                      <div className={`rounded-xl px-3 py-2 mb-4 text-[11px] flex items-center gap-2 ${expired ? 'bg-red-500/10 border border-red-500/20 text-red-300' : 'bg-white/[0.03] border border-white/[0.06] text-white/40'}`}>
                        <Clock className="h-3 w-3 shrink-0" />
                        {expired ? 'Expired on ' : 'Expires: '}
                        {new Date(service.expiresAt).toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' })}
                      </div>
                    )}

                    {/* Actions */}
                    <div className="flex flex-wrap gap-2">
                      <Button
                        size="sm"
                        onClick={() => power(service, 'start')}
                        disabled={!!actionLoading}
                        className="bg-emerald-600/80 hover:bg-emerald-600 text-white border-0 rounded-xl gap-1.5 h-8 text-xs"
                      >
                        {isLoading('start') ? <Loader2 className="h-3 w-3 animate-spin" /> : <Play className="h-3 w-3" />}
                        Start
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => power(service, 'stop')}
                        disabled={!!actionLoading}
                        className="border-white/10 text-white/70 hover:bg-white/5 rounded-xl gap-1.5 h-8 text-xs"
                      >
                        {isLoading('stop') ? <Loader2 className="h-3 w-3 animate-spin" /> : <Power className="h-3 w-3" />}
                        Stop
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => power(service, 'restart')}
                        disabled={!!actionLoading}
                        className="border-white/10 text-white/70 hover:bg-white/5 rounded-xl gap-1.5 h-8 text-xs"
                      >
                        {isLoading('restart') ? <Loader2 className="h-3 w-3 animate-spin" /> : <RefreshCw className="h-3 w-3" />}
                        Restart
                      </Button>
                      {info.gfxPanel && (
                        <a href={`${String(info.gfxPanel).replace(/\/$/, '')}/login`} target="_blank" rel="noreferrer">
                          <Button size="sm" variant="outline" className="border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10 rounded-xl gap-1.5 h-8 text-xs">
                            <SquareTerminal className="h-3 w-3" /> GFX Panel
                          </Button>
                        </a>
                      )}
                      {info.pteroPanel && (
                        <a href={info.pteroPanel} target="_blank" rel="noreferrer">
                          <Button size="sm" variant="outline" className="border-purple-500/30 text-purple-400 hover:bg-purple-500/10 rounded-xl gap-1.5 h-8 text-xs">
                            <SquareTerminal className="h-3 w-3" /> Pterodactyl
                          </Button>
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </main>
      <Footer />
    </div>
  )
}
