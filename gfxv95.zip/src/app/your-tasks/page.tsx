'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useSession } from 'next-auth/react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { ArrowLeft, Coins, Briefcase, Plus } from 'lucide-react'

interface Task {
  id: string; title: string; description: string
  rewardAmount: number; totalSlots: number; filledSlots: number
  status: string; budgetLocked: number
  _count: { submissions: number }
}

export default function YourTasksPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [tasks, setTasks] = useState<Task[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (status === 'loading') return
    if (status === 'unauthenticated') { router.push('/auth/signin'); return }
    fetch('/api/tasks?mine=created', { cache: 'no-store' })
      .then((r) => r.json())
      .then((d) => setTasks(d?.tasks || []))
      .finally(() => setLoading(false))
  }, [status])

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      <div className="container mx-auto max-w-4xl px-4 py-8">
        <Link href="/tasks" className="inline-flex items-center gap-2 text-white/50 hover:text-white text-sm mb-6">
          <ArrowLeft className="w-4 h-4" /> Back to tasks
        </Link>

        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold flex items-center gap-2">
              <Briefcase className="w-6 h-6 text-violet-400" /> Your tasks
            </h1>
            <p className="text-sm text-white/50">Tasks you've created — review submissions and pay workers.</p>
          </div>
          <Link href="/tasks">
            <Button className="bg-gradient-to-r from-violet-600 to-cyan-600 text-white border-0 gap-2">
              <Plus className="w-4 h-4" /> New task
            </Button>
          </Link>
        </div>

        {loading ? (
          <div className="text-center py-16 text-white/40">Loading…</div>
        ) : tasks.length === 0 ? (
          <Card className="bg-white/[0.02] border-white/10 p-10 text-center">
            <Briefcase className="w-10 h-10 text-white/30 mx-auto mb-3" />
            <p className="text-white/60 mb-4">You haven't created any tasks yet.</p>
            <Link href="/tasks">
              <Button className="bg-gradient-to-r from-violet-600 to-cyan-600 text-white border-0">Post your first task</Button>
            </Link>
          </Card>
        ) : (
          <div className="space-y-3">
            {tasks.map((t) => (
              <Link key={t.id} href={`/tasks/${t.id}`}>
                <Card className="bg-white/[0.02] border-white/10 hover:border-violet-500/40 transition">
                  <CardContent className="p-5 flex items-center justify-between gap-4">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-bold text-white truncate">{t.title}</h3>
                        <Badge className={
                          t.status === 'COMPLETED' ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30' :
                          'bg-violet-500/15 text-violet-300 border-violet-500/30'
                        }>{t.status}</Badge>
                      </div>
                      <p className="text-sm text-white/60 line-clamp-1 mb-1">{t.description}</p>
                      <div className="flex items-center gap-3 text-xs text-white/50">
                        <span>{t.filledSlots}/{t.totalSlots} done</span>
                        <span>{t._count.submissions} submission(s)</span>
                        <span className="flex items-center gap-1">
                          <Coins className="w-3 h-3" /> {t.budgetLocked.toFixed(2)} locked
                        </span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
      <Footer />
    </div>
  )
}
