'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { useSession } from 'next-auth/react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import {
  Coins, Plus, Trophy, Clock, Users as UsersIcon, ExternalLink, CheckCircle2,
  Sparkles, Briefcase
} from 'lucide-react'
import { toast } from 'sonner'

interface Task {
  id: string
  title: string
  description: string
  rewardAmount: number
  totalSlots: number
  filledSlots: number
  status: string
  url?: string | null
  category?: string | null
  createdAt: string
  creator: { id: string; username: string; avatar?: string | null }
  _count: { submissions: number }
}

export default function TasksPage() {
  const { data: session } = useSession()
  const [tasks, setTasks] = useState<Task[]>([])
  const [loading, setLoading] = useState(true)
  const [creating, setCreating] = useState(false)
  const [open, setOpen] = useState(false)
  const [form, setForm] = useState({
    title: '', description: '', instructions: '',
    proofType: 'SCREENSHOT', url: '', category: '',
    rewardAmount: 0.5, totalSlots: 10,
    deadline: '', videoTutorialUrl: '', maxPerUser: 1,
    requiresLink: false, difficulty: 'EASY', estimatedMinutes: 5,
    bannerImage: '',
  })
  const [bannerUploading, setBannerUploading] = useState(false)

  const uploadBanner = async (file: File) => {
    setBannerUploading(true)
    try {
      const fd = new FormData(); fd.append('file', file); fd.append('category', 'tasks')
      const res = await fetch('/api/upload', { method: 'POST', body: fd })
      const d = await res.json()
      if (!res.ok) throw new Error(d?.error || 'Upload failed')
      setForm((f) => ({ ...f, bannerImage: d.url || d.path || '' }))
      toast.success('Banner uploaded')
    } catch (e: any) { toast.error(e.message || 'Upload failed') }
    finally { setBannerUploading(false) }
  }

  const load = async () => {
    setLoading(true)
    try {
      const r = await fetch('/api/tasks?status=OPEN', { cache: 'no-store' })
      const d = await r.json()
      setTasks(Array.isArray(d?.tasks) ? d.tasks : [])
    } finally { setLoading(false) }
  }
  useEffect(() => { load() }, [])

  const create = async () => {
    if (!session?.user) { toast.error('Sign in to create a task'); return }
    if (!form.title || !form.description || !form.instructions) {
      toast.error('Title, description, and instructions are required'); return
    }
    setCreating(true)
    try {
      const res = await fetch('/api/tasks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data?.error || 'Failed')
      toast.success('Task created! Workers can now submit proofs.')
      setOpen(false)
      setForm({ title: '', description: '', instructions: '', proofType: 'SCREENSHOT', url: '', category: '', rewardAmount: 0.5, totalSlots: 10, deadline: '', videoTutorialUrl: '', maxPerUser: 1, requiresLink: false, difficulty: 'EASY', estimatedMinutes: 5, bannerImage: '' })
      load()
    } catch (e: any) {
      toast.error(e.message || 'Failed to create task')
    } finally { setCreating(false) }
  }

  const totalCost = (form.rewardAmount || 0) * (form.totalSlots || 0)

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />

      <section className="relative py-16 px-4 overflow-hidden border-b border-white/5">
        <div className="absolute inset-0 bg-gradient-to-br from-violet-600/10 via-transparent to-cyan-600/10" />
        <div className="container mx-auto max-w-5xl relative">
          <div className="flex flex-col sm:flex-row gap-4 sm:items-end justify-between">
            <div>
              <Badge className="bg-violet-500/15 text-violet-300 border-violet-500/30 mb-3">
                <Sparkles className="w-3 h-3 mr-1" /> Earn & Tasks
              </Badge>
              <h1 className="text-4xl md:text-5xl font-black mb-2">
                Earn by completing tasks
              </h1>
              <p className="text-white/60 max-w-xl">
                Post a task and pay other users to do it, or pick a task and earn money. Funds are locked when a task is created and transferred instantly to the worker on approval.
              </p>
            </div>
            <Dialog open={open} onOpenChange={setOpen}>
              <DialogTrigger asChild>
                <Button className="bg-gradient-to-r from-violet-600 to-cyan-600 hover:from-violet-500 hover:to-cyan-500 text-white border-0 gap-2 h-12 px-6">
                  <Plus className="w-5 h-5" /> Create task
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-[#0f0f1a] border-white/10 text-white sm:max-w-lg max-h-[85vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle className="text-white flex items-center gap-2">
                    <Briefcase className="w-5 h-5 text-violet-400" /> New task
                  </DialogTitle>
                </DialogHeader>
                <div className="space-y-3">
                  <div>
                    <Label className="text-xs text-white/60">Title</Label>
                    <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="bg-black/40 border-white/10" placeholder="e.g. Subscribe to my YouTube channel" />
                  </div>
                  <div>
                    <Label className="text-xs text-white/60">Short description</Label>
                    <Input value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="bg-black/40 border-white/10" placeholder="One-line summary" />
                  </div>
                  <div>
                    <Label className="text-xs text-white/60">Instructions for worker</Label>
                    <Textarea value={form.instructions} onChange={(e) => setForm({ ...form, instructions: e.target.value })} className="bg-black/40 border-white/10 min-h-[80px]" placeholder="Step-by-step what they must do and what proof to provide" />
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label className="text-xs text-white/60">Link (optional)</Label>
                      <Input value={form.url} onChange={(e) => setForm({ ...form, url: e.target.value })} className="bg-black/40 border-white/10" placeholder="https://..." />
                    </div>
                    <div>
                      <Label className="text-xs text-white/60">Category (optional)</Label>
                      <Input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} className="bg-black/40 border-white/10" placeholder="social, signup, review…" />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label className="text-xs text-white/60">Reward per worker</Label>
                      <Input type="number" step="0.01" min="0.01" value={form.rewardAmount} onChange={(e) => setForm({ ...form, rewardAmount: Number(e.target.value) })} className="bg-black/40 border-white/10" />
                    </div>
                    <div>
                      <Label className="text-xs text-white/60">Number of workers</Label>
                      <Input type="number" min="1" value={form.totalSlots} onChange={(e) => setForm({ ...form, totalSlots: Number(e.target.value) })} className="bg-black/40 border-white/10" />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label className="text-xs text-white/60">Deadline (optional)</Label>
                      <Input type="datetime-local" value={form.deadline} onChange={(e) => setForm({ ...form, deadline: e.target.value })} className="bg-black/40 border-white/10" />
                    </div>
                    <div>
                      <Label className="text-xs text-white/60">Estimated time (min)</Label>
                      <Input type="number" min="1" value={form.estimatedMinutes} onChange={(e) => setForm({ ...form, estimatedMinutes: Number(e.target.value) })} className="bg-black/40 border-white/10" />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label className="text-xs text-white/60">Difficulty</Label>
                      <select value={form.difficulty} onChange={(e) => setForm({ ...form, difficulty: e.target.value })} className="w-full h-9 rounded-md bg-black/40 border border-white/10 text-white text-sm px-2">
                        <option value="EASY">Easy</option>
                        <option value="MEDIUM">Medium</option>
                        <option value="HARD">Hard</option>
                      </select>
                    </div>
                    <div>
                      <Label className="text-xs text-white/60">Max submissions / user</Label>
                      <Input type="number" min="1" max="50" value={form.maxPerUser} onChange={(e) => setForm({ ...form, maxPerUser: Number(e.target.value) })} className="bg-black/40 border-white/10" />
                    </div>
                  </div>

                  <div>
                    <Label className="text-xs text-white/60">Video tutorial URL (optional, YouTube/Loom)</Label>
                    <Input value={form.videoTutorialUrl} onChange={(e) => setForm({ ...form, videoTutorialUrl: e.target.value })} className="bg-black/40 border-white/10" placeholder="https://youtube.com/watch?v=..." />
                  </div>

                  <div>
                    <Label className="text-xs text-white/60">Banner image (optional)</Label>
                    <div className="flex items-center gap-2">
                      <Input type="file" accept="image/*" onChange={(e) => e.target.files?.[0] && uploadBanner(e.target.files[0])} disabled={bannerUploading} className="bg-black/40 border-white/10 text-xs" />
                      {form.bannerImage && <img src={form.bannerImage} alt="" className="h-8 w-12 object-cover rounded" />}
                    </div>
                  </div>

                  <label className="flex items-center gap-2 text-sm text-white/70 cursor-pointer">
                    <input type="checkbox" checked={form.requiresLink} onChange={(e) => setForm({ ...form, requiresLink: e.target.checked })} className="accent-violet-500" />
                    Require workers to submit a verification link/URL with their proof
                  </label>

                  <div className="rounded-lg bg-violet-500/10 border border-violet-500/30 p-3 text-sm">
                    <div className="flex justify-between text-white/70">
                      <span>Total locked from your wallet:</span>
                      <span className="font-bold text-violet-300">{totalCost.toFixed(2)} coins</span>
                    </div>
                  </div>
                  <Button onClick={create} disabled={creating} className="w-full bg-gradient-to-r from-violet-600 to-cyan-600 text-white border-0">
                    {creating ? 'Creating…' : `Lock ${totalCost.toFixed(2)} & post task`}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-8">
            {[
              { icon: Coins, label: 'Locked & instant pay' },
              { icon: Trophy, label: 'No middleman fees' },
              { icon: Clock, label: 'Quick review by owner' },
              { icon: UsersIcon, label: 'Anyone can earn' },
            ].map((b, i) => (
              <div key={i} className="rounded-xl border border-white/10 bg-white/[0.02] p-3 flex items-center gap-2 text-xs text-white/70">
                <b.icon className="w-4 h-4 text-violet-300" /> {b.label}
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="container mx-auto max-w-5xl px-4 py-10">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-xl font-bold">Open tasks</h2>
          <Link href="/your-tasks" className="text-xs text-violet-300 hover:text-violet-200">My tasks →</Link>
        </div>

        {loading ? (
          <div className="text-center py-16 text-white/40">Loading…</div>
        ) : tasks.length === 0 ? (
          <Card className="bg-white/[0.02] border-white/10 p-10 text-center">
            <Briefcase className="w-10 h-10 text-white/30 mx-auto mb-3" />
            <p className="text-white/60">No open tasks yet. Be the first to post one!</p>
          </Card>
        ) : (
          <div className="grid sm:grid-cols-2 gap-4">
            {tasks.map((t) => {
              const remaining = t.totalSlots - t.filledSlots
              return (
                <Link key={t.id} href={`/tasks/${t.id}`} className="block">
                  <Card className="bg-white/[0.02] border-white/10 hover:border-violet-500/40 transition-all h-full">
                    <CardContent className="p-5">
                      <div className="flex items-start justify-between gap-3 mb-2">
                        <h3 className="font-bold text-white text-base line-clamp-2">{t.title}</h3>
                        <Badge className="bg-emerald-500/15 text-emerald-300 border-emerald-500/30 flex-shrink-0">
                          <Coins className="w-3 h-3 mr-1" /> {t.rewardAmount.toFixed(2)}
                        </Badge>
                      </div>
                      <p className="text-sm text-white/60 line-clamp-2 mb-3">{t.description}</p>
                      <div className="flex items-center justify-between text-xs text-white/50">
                        <span className="flex items-center gap-1">
                          <UsersIcon className="w-3 h-3" /> {remaining} of {t.totalSlots} left
                        </span>
                        <span>by @{t.creator.username}</span>
                      </div>
                      {t.url && (
                        <div className="flex items-center gap-1 mt-2 text-xs text-violet-300/80">
                          <ExternalLink className="w-3 h-3" /> Link provided
                        </div>
                      )}
                      {remaining === 0 && (
                        <Badge className="mt-2 bg-white/10 text-white/60 border-white/10">
                          <CheckCircle2 className="w-3 h-3 mr-1" /> Filled
                        </Badge>
                      )}
                    </CardContent>
                  </Card>
                </Link>
              )
            })}
          </div>
        )}
      </section>

      <Footer />
    </div>
  )
}
