'use client'

import { useEffect, useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import Link from 'next/link'
import { useSession } from 'next-auth/react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  ArrowLeft, Coins, Users as UsersIcon, ExternalLink,
  CheckCircle2, XCircle, Clock, ImageIcon, Trash2
} from 'lucide-react'
import { toast } from 'sonner'

interface Submission {
  id: string
  workerId: string
  proofText?: string | null
  proofImage?: string | null
  status: string
  rejectReason?: string | null
  createdAt: string
  worker: { id: string; username: string; avatar?: string | null }
}

interface Task {
  id: string
  title: string
  description: string
  instructions: string
  proofType: string
  rewardAmount: number
  totalSlots: number
  filledSlots: number
  status: string
  url?: string | null
  category?: string | null
  creatorId: string
  createdAt: string
  creator: { id: string; username: string; avatar?: string | null }
  submissions: Submission[]
}

export default function TaskDetailPage() {
  const { data: session } = useSession()
  const router = useRouter()
  const params = useParams() as { id: string }
  const [task, setTask] = useState<Task | null>(null)
  const [isOwner, setIsOwner] = useState(false)
  const [mySubmission, setMySubmission] = useState<Submission | null>(null)
  const [loading, setLoading] = useState(true)
  const [proofText, setProofText] = useState('')
  const [proofImage, setProofImage] = useState('')
  const [proofUrl, setProofUrl] = useState('')
  const [proofImages, setProofImages] = useState<string[]>([])
  const [submitting, setSubmitting] = useState(false)
  const [uploadingProof, setUploadingProof] = useState(false)

  const uploadProofFile = async (file: File) => {
    setUploadingProof(true)
    try {
      const fd = new FormData(); fd.append('file', file); fd.append('category', 'task-proofs')
      const r = await fetch('/api/upload', { method: 'POST', body: fd })
      const d = await r.json()
      if (!r.ok) throw new Error(d?.error || 'Upload failed')
      const url = d.url || d.path || ''
      if (url) {
        setProofImages((prev) => [...prev, url].slice(0, 10))
        if (!proofImage) setProofImage(url)
        toast.success('Screenshot uploaded')
      }
    } catch (e: any) { toast.error(e.message || 'Upload failed') }
    finally { setUploadingProof(false) }
  }

  const load = async () => {
    setLoading(true)
    try {
      const r = await fetch(`/api/tasks/${params.id}`, { cache: 'no-store' })
      const d = await r.json()
      if (!r.ok) { toast.error(d?.error || 'Failed'); return }
      setTask(d.task); setIsOwner(d.isOwner); setMySubmission(d.mySubmission)
    } finally { setLoading(false) }
  }
  useEffect(() => { load() }, [params.id])

  const submit = async () => {
    if (!session?.user) { router.push('/auth/signin'); return }
    if (!proofText && !proofImage && !proofUrl && proofImages.length === 0) {
      toast.error('Add at least one piece of proof: text, screenshot, or link.'); return
    }
    setSubmitting(true)
    try {
      const r = await fetch(`/api/tasks/${params.id}/submit`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ proofText, proofImage, proofUrl, proofImages }),
      })
      const d = await r.json()
      if (!r.ok) throw new Error(d?.error || 'Failed')
      toast.success('Submitted! The owner will review your proof.')
      setProofText(''); setProofImage(''); setProofUrl(''); setProofImages([])
      load()
    } catch (e: any) {
      toast.error(e.message || 'Failed')
    } finally { setSubmitting(false) }
  }

  const review = async (submissionId: string, action: 'approve' | 'reject', reason?: string) => {
    try {
      const r = await fetch(`/api/tasks/${params.id}/review`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ submissionId, action, reason }),
      })
      const d = await r.json()
      if (!r.ok) throw new Error(d?.error || 'Failed')
      toast.success(action === 'approve' ? 'Approved & paid' : 'Rejected')
      load()
    } catch (e: any) {
      toast.error(e.message || 'Failed')
    }
  }

  const remove = async () => {
    if (!confirm('Delete this task? Unspent budget will be refunded to you.')) return
    try {
      const r = await fetch(`/api/tasks/${params.id}`, { method: 'DELETE' })
      const d = await r.json()
      if (!r.ok) throw new Error(d?.error || 'Failed')
      toast.success(`Task deleted. ${d.refunded ? 'Refunded ' + d.refunded.toFixed(2) : ''}`)
      router.push('/tasks')
    } catch (e: any) { toast.error(e.message || 'Failed') }
  }

  if (loading || !task) {
    return (
      <div className="min-h-screen bg-[#0a0a0f] text-white">
        <Navbar />
        <div className="container mx-auto px-4 py-20 text-center text-white/40">Loading…</div>
      </div>
    )
  }

  const remaining = task.totalSlots - task.filledSlots

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white">
      <Navbar />
      <div className="container mx-auto px-4 py-8 max-w-3xl">
        <Link href="/tasks" className="inline-flex items-center gap-2 text-white/50 hover:text-white text-sm mb-6">
          <ArrowLeft className="w-4 h-4" /> All tasks
        </Link>

        <Card className="bg-white/[0.02] border-white/10 mb-6">
          <CardContent className="p-6">
            <div className="flex items-start justify-between gap-3 mb-3">
              <div>
                <h1 className="text-2xl font-bold mb-1">{task.title}</h1>
                <p className="text-sm text-white/60">by @{task.creator.username}</p>
              </div>
              <Badge className="bg-emerald-500/15 text-emerald-300 border-emerald-500/30">
                <Coins className="w-3 h-3 mr-1" /> {task.rewardAmount.toFixed(2)} per worker
              </Badge>
            </div>
            <p className="text-white/80 mb-4">{task.description}</p>
            {task.url && (
              <a href={task.url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-violet-300 hover:text-violet-200 text-sm mb-4">
                <ExternalLink className="w-4 h-4" /> Open task link
              </a>
            )}
            <div className="rounded-lg bg-black/40 border border-white/10 p-4 mt-2">
              <Label className="text-xs uppercase tracking-wider text-white/40 mb-2 block">Instructions</Label>
              <p className="text-sm text-white/80 whitespace-pre-wrap">{task.instructions}</p>
            </div>
            <div className="flex items-center justify-between text-xs text-white/50 mt-4">
              <span className="flex items-center gap-1"><UsersIcon className="w-3 h-3" /> {remaining} of {task.totalSlots} slots left</span>
              <span>{task.status}</span>
            </div>
          </CardContent>
        </Card>

        {isOwner ? (
          <>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-lg font-bold">Submissions ({task.submissions.length})</h2>
              <Button variant="ghost" onClick={remove} className="text-red-300 hover:text-red-200 hover:bg-red-500/10">
                <Trash2 className="w-4 h-4 mr-2" /> Delete & refund
              </Button>
            </div>
            {task.submissions.length === 0 ? (
              <p className="text-white/40 text-sm py-6 text-center">No submissions yet.</p>
            ) : (
              <div className="space-y-3">
                {task.submissions.map((s) => (
                  <Card key={s.id} className="bg-white/[0.02] border-white/10">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-2">
                        <div className="text-sm font-semibold">@{s.worker.username}</div>
                        <Badge className={
                          s.status === 'APPROVED' ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30' :
                          s.status === 'REJECTED' ? 'bg-red-500/15 text-red-300 border-red-500/30' :
                          'bg-amber-500/15 text-amber-300 border-amber-500/30'
                        }>
                          {s.status === 'APPROVED' && <CheckCircle2 className="w-3 h-3 mr-1" />}
                          {s.status === 'REJECTED' && <XCircle className="w-3 h-3 mr-1" />}
                          {s.status === 'PENDING' && <Clock className="w-3 h-3 mr-1" />}
                          {s.status}
                        </Badge>
                      </div>
                      {s.proofText && <p className="text-sm text-white/80 mb-2 whitespace-pre-wrap">{s.proofText}</p>}
                      {s.proofImage && (
                        <a href={s.proofImage} target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-violet-300 text-xs hover:text-violet-200">
                          <ImageIcon className="w-3 h-3" /> View proof image
                        </a>
                      )}
                      {s.rejectReason && <p className="text-xs text-red-300 mt-2">Reason: {s.rejectReason}</p>}
                      {s.status === 'PENDING' && (
                        <div className="flex gap-2 mt-3">
                          <Button size="sm" onClick={() => review(s.id, 'approve')} className="bg-emerald-600 hover:bg-emerald-500 text-white border-0">
                            <CheckCircle2 className="w-3 h-3 mr-1" /> Approve & pay
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => {
                            const r = prompt('Reason for rejection (optional):') || ''
                            review(s.id, 'reject', r)
                          }} className="border-white/10 text-white/70 hover:bg-white/5">
                            <XCircle className="w-3 h-3 mr-1" /> Reject
                          </Button>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </>
        ) : mySubmission ? (
          <Card className="bg-white/[0.02] border-white/10">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-3">
                <h2 className="text-lg font-bold">Your submission</h2>
                <Badge className={
                  mySubmission.status === 'APPROVED' ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30' :
                  mySubmission.status === 'REJECTED' ? 'bg-red-500/15 text-red-300 border-red-500/30' :
                  'bg-amber-500/15 text-amber-300 border-amber-500/30'
                }>
                  {mySubmission.status}
                </Badge>
              </div>
              {mySubmission.proofText && <p className="text-sm text-white/80 mb-2 whitespace-pre-wrap">{mySubmission.proofText}</p>}
              {mySubmission.proofImage && (
                <a href={mySubmission.proofImage} target="_blank" rel="noopener noreferrer" className="text-violet-300 text-xs">View proof image</a>
              )}
              {mySubmission.rejectReason && (
                <p className="text-xs text-red-300 mt-2">Reason: {mySubmission.rejectReason}</p>
              )}
              {mySubmission.status === 'APPROVED' && (
                <p className="text-emerald-300 text-sm mt-3">✓ Reward of {task.rewardAmount.toFixed(2)} added to your wallet.</p>
              )}
            </CardContent>
          </Card>
        ) : remaining > 0 ? (
          <Card className="bg-white/[0.02] border-white/10">
            <CardContent className="p-5 space-y-4">
              <div>
                <h2 className="text-lg font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  Submit your proof
                </h2>
                <p className="text-xs text-white/50 mt-1">The task owner will review your submission and pay you instantly on approval.</p>
              </div>

              <div>
                <Label className="text-xs text-white/60">📝 Detailed proof / notes for the owner <span className="text-rose-400">*</span></Label>
                <Textarea value={proofText} onChange={(e) => setProofText(e.target.value)} className="bg-black/40 border-white/10 min-h-[100px]" placeholder="Describe step-by-step what you did. Include your username, transaction ID, timestamp, or any details the owner can verify." />
                <p className="text-[10px] text-white/30 mt-1">{proofText.length}/4000 characters</p>
              </div>

              <div>
                <Label className="text-xs text-white/60">📷 Screenshot(s) — upload from device</Label>
                <div className="rounded-lg border border-dashed border-white/15 bg-black/30 p-3">
                  <Input type="file" accept="image/*" disabled={uploadingProof} onChange={(e) => e.target.files?.[0] && uploadProofFile(e.target.files[0])} className="bg-transparent border-0 text-xs file:bg-violet-500/20 file:text-violet-200 file:border-0 file:rounded file:px-2 file:py-1 file:mr-2" />
                  {uploadingProof && <p className="text-xs text-violet-300 mt-1">Uploading…</p>}
                  {proofImages.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-2">
                      {proofImages.map((u, i) => (
                        <div key={u} className="relative group">
                          <img src={u} alt="" className="h-16 w-24 object-cover rounded border border-white/10" />
                          <button type="button" onClick={() => setProofImages((prev) => prev.filter((_, j) => j !== i))} className="absolute -top-1 -right-1 bg-rose-500 text-white rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition">
                            <Trash2 className="w-3 h-3" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
                <p className="text-[10px] text-white/30 mt-1">Up to 10 screenshots. PNG/JPG/WEBP supported.</p>
              </div>

              <div>
                <Label className="text-xs text-white/60">🔗 Proof image URL (or paste from imgur)</Label>
                <Input value={proofImage} onChange={(e) => setProofImage(e.target.value)} className="bg-black/40 border-white/10" placeholder="https://i.imgur.com/screenshot.png" />
              </div>

              <div>
                <Label className="text-xs text-white/60">
                  🌐 Verification link / URL {(task as any).requiresLink ? <span className="text-rose-400">* required</span> : '(optional)'}
                </Label>
                <Input value={proofUrl} onChange={(e) => setProofUrl(e.target.value)} className="bg-black/40 border-white/10" placeholder="https://your-tweet-url.com or https://review-url.com" />
                <p className="text-[10px] text-white/30 mt-1">Paste the public link the owner can open to verify (your tweet, post, review, profile, etc.).</p>
              </div>

              <Button onClick={submit} disabled={submitting || uploadingProof} className="bg-gradient-to-r from-violet-600 to-cyan-600 text-white border-0 w-full h-11">
                {submitting ? 'Submitting…' : `🚀 Submit & earn ${task.rewardAmount.toFixed(2)} coins`}
              </Button>
            </CardContent>
          </Card>
        ) : (
          <Card className="bg-white/[0.02] border-white/10 p-6 text-center text-white/60">
            All slots are filled. Check other open tasks!
          </Card>
        )}
      </div>
      <Footer />
    </div>
  )
}
