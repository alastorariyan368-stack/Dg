'use client'

import { useState, useRef, useCallback } from 'react'
import { Navbar } from '@/components/navbar'
import { Footer } from '@/components/footer'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { toast } from 'sonner'
import {
  Search, X, Download, ExternalLink, Music, Video, Clock, Eye,
  ThumbsUp, Calendar, User, Tag, FileDown, Loader2, CheckCircle2,
  AlertCircle
} from 'lucide-react'
import Link from 'next/link'

interface VideoInfo {
  id: string
  title: string
  description: string
  thumbnail: string
  thumbnailHQ: string
  duration: number
  durationLabel: string
  viewCount: number
  viewCountLabel: string
  channel: string
  channelUrl: string
  channelSubs: string
  publishedAt: string
  publishedLabel: string
  ageRestricted: boolean
  likes: number
  category: string
  tags: string[]
  formats: {
    itag: number
    quality: string
    container: string
    codecs: string
    fps: number
    contentLength: string
    hasVideo: boolean
    hasAudio: boolean
    url: string
  }[]
  audioFormats: {
    itag: number
    audioBitrate: number
    audioCodec: string
    container: string
    contentLength: string
    url: string
  }[]
}

const QUALITY_LABELS: Record<string, string> = {
  '144p': '144p (Lowest)',
  '240p': '240p',
  '360p': '360p',
  '480p': '480p',
  '720p': '720p HD',
  '720p60': '720p60 HD',
  '1080p': '1080p Full HD',
  '1080p60': '1080p60 Full HD',
  'highest': 'Best Available',
  'lowest': 'Lowest Available',
}

export default function YtVideoPage() {
  const [url, setUrl] = useState('')
  const [videoId, setVideoId] = useState<string | null>(null)
  const [videoInfo, setVideoInfo] = useState<VideoInfo | null>(null)
  const [loading, setLoading] = useState(false)
  const [downloading, setDownloading] = useState(false)
  const [downloadProgress, setDownloadProgress] = useState(0)
  const [selectedQuality, setSelectedQuality] = useState('720p')
  const [selectedFormat, setSelectedFormat] = useState('mp4')
  const [error, setError] = useState<string | null>(null)

  const extractVideoId = (input: string): string | null => {
    const trimmed = input.trim()
    const patterns = [
      /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/|youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/,
      /^([a-zA-Z0-9_-]{11})$/,
    ]
    for (const p of patterns) {
      const m = trimmed.match(p)
      if (m) return m[1]
    }
    return null
  }

  const fetchVideoInfo = async () => {
    const id = extractVideoId(url)
    if (!id) {
      toast.error('Invalid YouTube URL or video ID')
      return
    }

    setLoading(true)
    setError(null)
    setVideoInfo(null)

    try {
      const res = await fetch(`/api/yt-video/info?url=${encodeURIComponent(id)}`)
      if (!res.ok) {
        const err = await res.json().catch(() => ({ error: 'Failed to fetch' }))
        throw new Error(err.error || `Error ${res.status}`)
      }
      const data = await res.json()
      setVideoInfo(data)
      setVideoId(data.id)
    } catch (err: any) {
      setError(err.message || 'Failed to load video info')
      toast.error(err.message || 'Failed to load video info')
    } finally {
      setLoading(false)
    }
  }

  const handleDownload = async () => {
    if (!videoId) return

    setDownloading(true)
    setDownloadProgress(0)

    const videoUrl = `https://www.youtube.com/watch?v=${videoId}`
    const quality = selectedFormat === 'mp3' ? 'highest' : selectedQuality
    const downloadUrl = `/api/yt-video/download?url=${encodeURIComponent(videoUrl)}&format=${selectedFormat}&quality=${quality}`

    try {
      const res = await fetch(downloadUrl)
      if (!res.ok) {
        const errData = await res.json().catch(() => ({ error: 'Download failed' }))
        throw new Error(errData.error || `HTTP ${res.status}`)
      }

      const contentLength = res.headers.get('content-length')
      const total = contentLength ? parseInt(contentLength, 10) : 0

      if (!res.body) {
        throw new Error('No response body')
      }

      const reader = res.body.getReader()
      const chunks: Uint8Array[] = []
      let received = 0

      while (true) {
        const { done, value } = await reader.read()
        if (done) break
        chunks.push(value)
        received += value.length
        if (total) {
          setDownloadProgress(Math.round((received / total) * 100))
        }
      }

      const blob = new Blob(chunks, {
        type: selectedFormat === 'mp3' ? 'audio/mpeg' : 'video/mp4',
      })
      const ext = selectedFormat === 'mp3' ? 'mp3' : 'mp4'
      const qualityLabel = selectedFormat === 'mp3' ? 'audio' : selectedQuality
      const filename = `${videoInfo?.title || videoId}-${qualityLabel}.${ext}`
        .replace(/[<>:"/\\|?*]/g, '_')
        .slice(0, 200)

      const objUrl = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = objUrl
      a.download = filename
      document.body.appendChild(a)
      a.click()
      document.body.removeChild(a)
      URL.revokeObjectURL(objUrl)

      toast.success(`Downloaded: ${filename}`)
      setDownloadProgress(100)
    } catch (err: any) {
      toast.error(err.message || 'Download failed')
      window.open(`https://youtube.com/watch?v=${videoId}`, '_blank')
    } finally {
      setDownloading(false)
    }
  }

  const handleClear = () => {
    setUrl('')
    setVideoId(null)
    setVideoInfo(null)
    setError(null)
    setDownloadProgress(0)
  }

  const formatFileSize = (bytes: string | undefined): string => {
    if (!bytes) return 'Unknown'
    const num = parseInt(bytes, 10)
    if (!num) return 'Unknown'
    const units = ['B', 'KB', 'MB', 'GB']
    let i = 0
    let size = num
    while (size >= 1024 && i < units.length - 1) {
      size /= 1024
      i++
    }
    return `${size.toFixed(1)} ${units[i]}`
  }

  const getQualityGroup = (q: string) => {
    const num = parseInt(q)
    if (q.includes('60')) return '60fps'
    if (num >= 1080) return 'fullhd'
    if (num >= 720) return 'hd'
    if (num >= 480) return 'sd'
    return 'low'
  }

  return (
    <div className="min-h-screen bg-[#0a0a12] text-white flex flex-col">
      <Navbar />

      <div className="flex-1 container mx-auto px-4 py-10 max-w-5xl">
        {/* Header */}
        <div className="text-center mb-10">
          <div className="inline-flex items-center gap-2 bg-rose-500/10 border border-rose-500/20 rounded-full px-4 py-1.5 mb-4">
            <Video className="w-4 h-4 text-rose-400" />
            <span className="text-rose-300 text-sm font-medium">Free Tool</span>
          </div>
          <h1 className="text-3xl sm:text-4xl font-black text-white mb-2">
            YouTube Video Downloader
          </h1>
          <p className="text-white/50 max-w-xl mx-auto">
            Download YouTube videos in MP4 or MP3 format. Supports 360p to 1080p Full HD.
          </p>
        </div>

        {/* Search bar */}
        <div className="flex gap-2 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/30" />
            <Input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && !loading && !videoInfo && fetchVideoInfo()}
              placeholder="Paste YouTube URL or video ID…"
              className="pl-10 bg-white/[0.05] border-white/10 text-white placeholder:text-white/30 h-12 rounded-xl"
              disabled={loading}
            />
            {url && !loading && (
              <button
                onClick={handleClear}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60 transition"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
          <Button
            onClick={fetchVideoInfo}
            disabled={!url.trim() || loading}
            className="h-12 px-6 bg-rose-600 hover:bg-rose-500 border-0 rounded-xl text-white font-semibold"
          >
            {loading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : (
              <>
                <Search className="w-4 h-4 mr-1" />
                Get Info
              </>
            )}
          </Button>
        </div>

        {/* Loading state */}
        {loading && (
          <div className="flex flex-col items-center justify-center py-16">
            <Loader2 className="w-8 h-8 text-rose-400 animate-spin mb-4" />
            <p className="text-white/50 text-sm">Fetching video information…</p>
          </div>
        )}

        {/* Error state */}
        {error && !loading && (
          <div className="rounded-2xl border border-red-500/20 bg-red-500/5 p-8 text-center">
            <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-red-300 mb-1">Failed to Load Video</h3>
            <p className="text-sm text-red-400/70 mb-4">{error}</p>
            <Button onClick={fetchVideoInfo} variant="outline" className="border-white/10 text-white">
              Try Again
            </Button>
          </div>
        )}

        {/* Video info + download */}
        {videoInfo && (
          <div className="space-y-6">
            {/* Hero card */}
            <div className="rounded-2xl border border-white/[0.07] bg-gradient-to-b from-white/[0.03] to-transparent overflow-hidden">
              <div className="grid sm:grid-cols-[280px_1fr] gap-5 p-5">
                {/* Thumbnail */}
                <div className="relative group">
                  <div className="aspect-video rounded-xl overflow-hidden bg-black/40">
                    <img
                      src={videoInfo.thumbnail}
                      alt={videoInfo.title}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = videoInfo.thumbnailHQ
                      }}
                    />
                  </div>
                  {/* Duration badge */}
                  <div className="absolute bottom-2 right-2 bg-black/80 backdrop-blur-sm text-white text-xs font-bold px-2 py-0.5 rounded-md flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {videoInfo.durationLabel}
                  </div>
                </div>

                {/* Details */}
                <div className="flex flex-col min-w-0">
                  <h2 className="text-lg sm:text-xl font-bold text-white line-clamp-2 mb-2">
                    {videoInfo.title}
                  </h2>

                  <Link
                    href={videoInfo.channelUrl}
                    target="_blank"
                    className="flex items-center gap-2 text-sm text-white/60 hover:text-rose-400 transition mb-3 group/ch"
                  >
                    <User className="w-4 h-4" />
                    <span>{videoInfo.channel}</span>
                    {videoInfo.channelSubs !== 'N/A' && (
                      <span className="text-xs text-white/30">{videoInfo.channelSubs} subscribers</span>
                    )}
                    <ExternalLink className="w-3 h-3 opacity-0 group-hover/ch:opacity-100 transition" />
                  </Link>

                  {/* Stats row */}
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1.5 text-xs text-white/40 mb-3">
                    <span className="flex items-center gap-1"><Eye className="w-3.5 h-3.5" />{videoInfo.viewCountLabel} views</span>
                    {videoInfo.likes > 0 && (
                      <span className="flex items-center gap-1"><ThumbsUp className="w-3.5 h-3.5" />{videoInfo.likes >= 1000 ? `${(videoInfo.likes / 1000).toFixed(1)}K` : videoInfo.likes}</span>
                    )}
                    <span className="flex items-center gap-1"><Calendar className="w-3.5 h-3.5" />{videoInfo.publishedLabel}</span>
                    {videoInfo.category && (
                      <span className="flex items-center gap-1"><Tag className="w-3.5 h-3.5" />{videoInfo.category}</span>
                    )}
                  </div>

                  {/* Tags */}
                  {videoInfo.tags.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 mb-3">
                      {videoInfo.tags.map((tag, i) => (
                        <span key={i} className="text-[10px] bg-white/[0.04] border border-white/[0.06] text-white/40 rounded-full px-2 py-0.5">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  )}

                  {/* Description */}
                  {videoInfo.description && (
                    <p className="text-xs text-white/30 line-clamp-2 leading-relaxed">
                      {videoInfo.description}
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* Download section */}
            <div className="rounded-2xl border border-white/[0.07] bg-white/[0.02] p-5">
              <h3 className="text-base font-semibold text-white mb-4 flex items-center gap-2">
                <Download className="w-4 h-4 text-rose-400" />
                Download Options
              </h3>

              <Tabs defaultValue="mp4" onValueChange={(v) => setSelectedFormat(v)} className="mb-4">
                <TabsList className="bg-white/[0.04] border border-white/[0.06] p-1">
                  <TabsTrigger value="mp4" className="data-[state=active]:bg-rose-600 data-[state=active]:text-white text-white/60 gap-2">
                    <Video className="w-4 h-4" /> MP4 Video
                  </TabsTrigger>
                  <TabsTrigger value="mp3" className="data-[state=active]:bg-rose-600 data-[state=active]:text-white text-white/60 gap-2">
                    <Music className="w-4 h-4" /> MP3 Audio
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="mp4" className="mt-4 space-y-4">
                  {/* Quality selector */}
                  <div>
                    <label className="text-sm text-white/60 mb-2 block">Select Quality</label>
                    <Select value={selectedQuality} onValueChange={setSelectedQuality}>
                      <SelectTrigger className="w-full sm:w-64 bg-white/[0.04] border-white/[0.08] text-white">
                        <SelectValue placeholder="Choose quality" />
                      </SelectTrigger>
                      <SelectContent className="bg-[#0f0f1a] border-white/[0.08] text-white">
                        {videoInfo.formats
                          .filter(f => f.container === 'mp4' && f.hasVideo)
                          .map(f => (
                            <SelectItem key={f.itag} value={f.quality} className="focus:bg-rose-600/20 focus:text-white">
                              <div className="flex items-center justify-between w-full gap-4">
                                <span>{QUALITY_LABELS[f.quality] || f.quality}</span>
                                <span className="text-xs text-white/30">
                                  {formatFileSize(f.contentLength)}
                                </span>
                              </div>
                            </SelectItem>
                          ))}
                        {videoInfo.formats.filter(f => f.container === 'mp4' && f.hasVideo).length === 0 && (
                          <SelectItem value="highest" className="focus:bg-rose-600/20 focus:text-white">
                            Best Available
                          </SelectItem>
                        )}
                      </SelectContent>
                    </Select>
                  </div>

                  {/* Format chips */}
                  {videoInfo.formats.filter(f => f.container === 'mp4' && f.hasVideo).length > 0 && (
                    <div>
                      <label className="text-sm text-white/60 mb-2 block">Quick Select</label>
                      <div className="flex flex-wrap gap-2">
                        {['360p', '480p', '720p', '1080p'].map(q => {
                          const hasFormat = videoInfo.formats.some(f => f.quality === q)
                          if (!hasFormat) return null
                          return (
                            <button
                              key={q}
                              onClick={() => setSelectedQuality(q)}
                              className={`px-3 py-1.5 rounded-lg text-xs font-medium border transition ${
                                selectedQuality === q
                                  ? 'bg-rose-600 border-rose-500 text-white'
                                  : 'bg-white/[0.04] border-white/[0.08] text-white/60 hover:border-white/20'
                              }`}
                            >
                              {q}
                            </button>
                          )
                        })}
                      </div>
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="mp3" className="mt-4">
                  <div className="bg-amber-500/5 border border-amber-500/20 rounded-lg p-4">
                    <div className="flex items-start gap-3">
                      <Music className="w-5 h-5 text-amber-400 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="text-sm font-medium text-amber-200">Audio Only (MP3)</p>
                        <p className="text-xs text-amber-300/60 mt-1">
                          Downloads the highest quality audio stream. File size is typically 3–15 MB.
                        </p>
                        {videoInfo.audioFormats.length > 0 && (
                          <div className="mt-2 flex flex-wrap gap-2">
                            {videoInfo.audioFormats.slice(0, 3).map(f => (
                              <span key={f.itag} className="text-[10px] bg-white/[0.04] border border-white/[0.06] text-white/40 rounded-full px-2 py-0.5">
                                {f.audioBitrate}kbps {f.audioCodec} · {formatFileSize(f.contentLength)}
                              </span>
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>

              {/* Download progress */}
              {downloadProgress > 0 && downloadProgress < 100 && (
                <div className="mb-4 space-y-2">
                  <div className="flex items-center justify-between text-xs text-white/50">
                    <span>{downloading ? 'Downloading…' : 'Processing…'}</span>
                    <span>{downloadProgress}%</span>
                  </div>
                  <Progress value={downloadProgress} className="h-2 bg-white/[0.06] [&>div]:bg-rose-500" />
                </div>
              )}
              {downloadProgress === 100 && !downloading && (
                <div className="mb-4 flex items-center gap-2 text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 rounded-lg px-3 py-2">
                  <CheckCircle2 className="w-4 h-4" />
                  Download complete!
                </div>
              )}

              {/* Download button */}
              <div className="flex flex-col sm:flex-row gap-3">
                <Button
                  onClick={handleDownload}
                  disabled={downloading || !videoId}
                  className="flex-1 h-12 bg-gradient-to-r from-rose-600 to-pink-600 hover:from-rose-500 hover:to-pink-500 border-0 rounded-xl text-white font-semibold text-base gap-2"
                >
                  {downloading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Downloading…
                    </>
                  ) : (
                    <>
                      <FileDown className="w-5 h-5" />
                      Download {selectedFormat === 'mp3' ? 'MP3' : selectedQuality} {selectedFormat === 'mp3' ? 'Audio' : 'Video'}
                    </>
                  )}
                </Button>
                <Link
                  href={`https://youtube.com/watch?v=${videoId}`}
                  target="_blank"
                  className="flex items-center justify-center gap-2 px-6 h-12 bg-white/[0.04] hover:bg-white/[0.07] border border-white/[0.08] rounded-xl text-white/60 hover:text-white transition text-sm"
                >
                  <ExternalLink className="w-4 h-4" />
                  Open on YouTube
                </Link>
              </div>

              {/* Available formats table */}
              <details className="mt-5 group">
                <summary className="text-xs text-white/30 hover:text-white/50 transition cursor-pointer select-none">
                  Show all {videoInfo.formats.length} available formats
                </summary>
                <div className="mt-3 overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="text-white/30 border-b border-white/[0.05]">
                        <th className="text-left py-2 pr-3">Quality</th>
                        <th className="text-left py-2 pr-3">Container</th>
                        <th className="text-left py-2 pr-3">Codec</th>
                        <th className="text-left py-2 pr-3">FPS</th>
                        <th className="text-left py-2 pr-3">Size</th>
                        <th className="text-left py-2 pr-3">Audio</th>
                      </tr>
                    </thead>
                    <tbody>
                      {videoInfo.formats.map(f => (
                        <tr key={f.itag} className="border-b border-white/[0.03] text-white/50 hover:text-white/80 transition">
                          <td className="py-1.5 pr-3 font-medium">{f.quality || `itag ${f.itag}`}</td>
                          <td className="py-1.5 pr-3">{f.container}</td>
                          <td className="py-1.5 pr-3 text-[10px]">{f.codecs?.slice(0, 20) || '-'}</td>
                          <td className="py-1.5 pr-3">{f.fps || '-'}</td>
                          <td className="py-1.5 pr-3">{formatFileSize(f.contentLength)}</td>
                          <td className="py-1.5 pr-3">{f.hasAudio ? '✅' : '❌'}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </details>
            </div>

            {/* Disclaimer */}
            <div className="bg-yellow-500/5 border border-yellow-500/15 rounded-lg p-3 text-xs text-yellow-200/60">
              ⚠️ Only download videos you own or have permission to download. Respect copyright laws and YouTube's Terms of Service.
            </div>
          </div>
        )}

        {/* Empty state */}
        {!videoInfo && !loading && !error && (
          <div className="text-center py-16">
            <div className="w-20 h-20 rounded-3xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center mx-auto mb-4">
              <Video className="w-9 h-9 text-rose-400/60" />
            </div>
            <p className="text-white/30 text-sm">Paste a YouTube URL above and click "Get Info"</p>
            <p className="text-white/20 text-xs mt-1">
              Supports youtube.com, youtu.be, shorts and direct video IDs
            </p>
          </div>
        )}
      </div>

      <Footer />
    </div>
  )
}
