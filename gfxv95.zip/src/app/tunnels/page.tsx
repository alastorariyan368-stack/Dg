'use client'

import { useState, useEffect, useCallback } from 'react'
import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { Navbar } from '@/components/navbar'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { toast } from 'sonner'
import {
  Globe, Plus, Trash2, Loader2, Copy, Shield,
  CheckCircle, ExternalLink, ChevronDown, AlertTriangle,
  RefreshCw, Wifi, WifiOff, ArrowRight, Activity,
  ChevronRight, ChevronUp, ArrowLeft, Edit2, Server,
  Terminal, Settings, Link, X, Pencil
} from 'lucide-react'

interface Zone { id: string; name: string }
interface UsedSubdomain { tunnelId: string; subdomain: string | null; zoneId: string | null; zoneDomain: string | null }

interface Tunnel {
  id: string
  name: string
  cfTunnelId?: string
  cfTunnelToken?: string
  subdomain?: string
  zoneId?: string
  zoneDomain?: string
  targetPort: number
  targetHost: string
  protocol: string
  status: string
  errorMsg?: string
  createdAt: string
  updatedAt: string
}

type OS = 'linux-deb' | 'linux-rpm' | 'windows' | 'docker'
type CreateStep = 'type' | 'name' | 'connect' | 'route'
type TunnelTab = 'connector' | 'hostname' | 'settings'

const OS_TABS: { key: OS; label: string; emoji: string }[] = [
  { key: 'linux-deb', label: 'Debian / Ubuntu', emoji: '🐧' },
  { key: 'linux-rpm', label: 'RHEL / CentOS', emoji: '🎩' },
  { key: 'windows', label: 'Windows', emoji: '🪟' },
  { key: 'docker', label: 'Docker', emoji: '🐳' },
]

const ADJECTIVES = ['brave','calm','cool','dark','epic','fast','free','good','hard','keen','lush','nice','pure','rich','safe','slim','soft','true','vast','wild']
const ANIMALS = ['bear','bird','bull','crab','deer','duck','fish','frog','hawk','ibis','kite','lamb','lion','lynx','mole','mink','newt','puma','rook','seal','stag','toad','vole','wolf','wren']

function randomName() {
  const adj = ADJECTIVES[Math.floor(Math.random() * ADJECTIVES.length)]
  const animal = ANIMALS[Math.floor(Math.random() * ANIMALS.length)]
  const suffix = Math.random().toString(36).slice(2, 6)
  return `${adj}-${animal}-${suffix}`
}

function getInstallSteps(os: OS, token: string): { title: string; cmd: string }[] {
  switch (os) {
    case 'linux-deb':
      return [
        {
          title: 'Add Cloudflare repository & install cloudflared',
          cmd: 'curl -fsSL https://pkg.cloudflare.com/cloudflare-main.gpg | sudo tee /usr/share/keyrings/cloudflare-main.gpg >/dev/null\necho "deb [signed-by=/usr/share/keyrings/cloudflare-main.gpg] https://pkg.cloudflare.com/cloudflared $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/cloudflared.list\nsudo apt-get update && sudo apt-get install cloudflared'
        },
        {
          title: 'Install as a system service (auto-starts on boot)',
          cmd: `sudo cloudflared service install ${token}`
        },
      ]
    case 'linux-rpm':
      return [
        {
          title: 'Install via yum/dnf',
          cmd: `curl -fsSl https://pkg.cloudflare.com/cloudflare-main.gpg | sudo gpg --dearmor -o /etc/pki/rpm-gpg/cloudflare-main.gpg\nsudo tee /etc/yum.repos.d/cloudflared.repo <<'EOF'\n[cloudflared]\nname=Cloudflared\nbaseurl=https://pkg.cloudflare.com/cloudflared/rpm/\nenabled=1\ngpgcheck=1\ngpgkey=file:///etc/pki/rpm-gpg/cloudflare-main.gpg\nEOF\nsudo yum install cloudflared`
        },
        {
          title: 'Install as a system service',
          cmd: `sudo cloudflared service install ${token}`
        },
      ]
    case 'windows':
      return [
        {
          title: 'Install via winget (run PowerShell as Administrator)',
          cmd: 'winget install --id Cloudflare.cloudflared'
        },
        {
          title: 'Install as a Windows service (run PowerShell as Administrator)',
          cmd: `cloudflared.exe service install ${token}`
        },
      ]
    case 'docker':
      return [
        {
          title: 'Run cloudflared as a container',
          cmd: `docker run -d --name cloudflared \\\n  --restart unless-stopped \\\n  cloudflare/cloudflared:latest \\\n  tunnel --no-autoupdate run --token ${token}`
        },
      ]
  }
}

function CopyBtn({ text, label = 'Copy' }: { text: string; label?: string }) {
  const [done, setDone] = useState(false)
  return (
    <button
      onClick={() => { navigator.clipboard.writeText(text); setDone(true); setTimeout(() => setDone(false), 2000) }}
      className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-md bg-white/[0.07] hover:bg-white/[0.14] text-white/50 hover:text-white transition text-xs flex-shrink-0"
    >
      {done ? <CheckCircle className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
      {done ? 'Copied!' : label}
    </button>
  )
}

function StatusBadge({ status }: { status: string }) {
  if (status === 'ACTIVE') return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/20 text-[10px] font-medium text-emerald-400">
      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" /> Healthy
    </span>
  )
  if (status === 'ERROR') return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-red-500/15 border border-red-500/20 text-[10px] font-medium text-red-400">
      <span className="w-1.5 h-1.5 rounded-full bg-red-400" /> Error
    </span>
  )
  if (status === 'PENDING') return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/20 text-[10px] font-medium text-amber-400">
      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse" /> Setting up
    </span>
  )
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-white/[0.07] border border-white/[0.08] text-[10px] font-medium text-white/40">
      <span className="w-1.5 h-1.5 rounded-full bg-white/30" /> {status}
    </span>
  )
}

// Published Applications — top section listing all tunnels that have a public hostname
function PublishedApps({ tunnels }: { tunnels: Tunnel[] }) {
  const published = tunnels.filter(t => t.subdomain && t.zoneDomain && t.status !== 'DELETED')
  if (published.length === 0) return null

  return (
    <div className="mb-10">
      <div className="flex items-center justify-between mb-4 px-1">
        <div className="flex items-center gap-2">
          <div className="w-1.5 h-1.5 rounded-full bg-blue-500 animate-pulse" />
          <h2 className="text-[11px] font-bold text-white/40 uppercase tracking-[0.2em]">Published Applications</h2>
        </div>
        <span className="text-[10px] font-medium text-white/20 bg-white/5 px-2 py-0.5 rounded-full border border-white/5">
          {published.length} Live
        </span>
      </div>
      <div className="grid grid-cols-1 gap-3">
        {published.map(t => {
          const url = `https://${t.subdomain}.${t.zoneDomain}`
          return (
            <div key={t.id} className="group relative flex items-center gap-4 px-5 py-4 rounded-3xl border border-white/[0.06] bg-gradient-to-r from-white/[0.02] to-transparent hover:border-blue-500/20 hover:bg-blue-500/[0.02] transition-all duration-300">
              <div className="w-10 h-10 rounded-2xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform duration-300">
                <Globe className="w-5 h-5 text-blue-400" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 mb-0.5">
                  <p className="text-sm font-bold text-white truncate">{t.name}</p>
                  <StatusBadge status={t.status} />
                </div>
                <p className="text-[11px] text-white/30 font-mono truncate tracking-tight">{url}</p>
              </div>
              <div className="flex items-center gap-2 flex-shrink-0">
                <div className="hidden sm:flex flex-col items-end mr-2">
                  <span className="text-[10px] font-bold text-white/20 uppercase tracking-tighter">Backend</span>
                  <span className="text-[11px] text-white/40 font-mono">
                    {t.protocol}://{t.targetHost}:{t.targetPort}
                  </span>
                </div>
                <div className="flex items-center gap-1 bg-white/[0.03] p-1 rounded-2xl border border-white/5 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <CopyBtn text={url} label="URL" />
                  <a href={url} target="_blank" rel="noopener noreferrer"
                    className="p-2 rounded-xl text-white/30 hover:text-white hover:bg-white/[0.08] transition-all">
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

// Edit Route modal/panel for updating subdomain + service config
function EditRoute({
  tunnel,
  allowedZones,
  usedSubdomains,
  onSaved,
  onClose
}: {
  tunnel: Tunnel
  allowedZones: Zone[]
  usedSubdomains: UsedSubdomain[]
  onSaved: () => void
  onClose: () => void
}) {
  const [subdomain, setSubdomain] = useState(tunnel.subdomain || '')
  const [zoneId, setZoneId] = useState(tunnel.zoneId || allowedZones[0]?.id || '')
  const [protocol, setProtocol] = useState(tunnel.protocol || 'http')
  const [host, setHost] = useState(tunnel.targetHost || 'localhost')
  const [port, setPort] = useState(String(tunnel.targetPort || 3000))
  const [noTlsVerify, setNoTlsVerify] = useState((tunnel as any).noTlsVerify || false)
  const [originHostHeader, setOriginHostHeader] = useState((tunnel as any).originHostHeader || '')
  
  // Advanced Config
  const adv = (tunnel as any).advancedConfig || {}
  const [originServerName, setOriginServerName] = useState(adv.originServerName || '')
  const [httpConnectTimeout, setHttpConnectTimeout] = useState(String(adv.httpConnectTimeout || '30'))
  const [httpTLSHandshakeTimeout, setHttpTLSHandshakeTimeout] = useState(String(adv.httpTLSHandshakeTimeout || '10'))
  const [noHappyEyeballs, setNoHappyEyeballs] = useState(adv.noHappyEyeballs || false)
  const [proxyType, setProxyType] = useState(adv.proxyType || '')

  const [saving, setSaving] = useState(false)

  const selectedZone = allowedZones.find(z => z.id === zoneId)
  const previewUrl = subdomain && selectedZone ? `https://${subdomain}.${selectedZone.name}` : null

  const conflict = usedSubdomains.find(s =>
    s.subdomain === subdomain.toLowerCase() &&
    s.zoneId === zoneId &&
    s.tunnelId !== tunnel.id
  )

  const save = async () => {
    if (!subdomain.trim()) { toast.error('Subdomain required'); return }
    if (conflict) { toast.error(`Subdomain already used by another tunnel`); return }
    setSaving(true)
    try {
      const res = await fetch(`/api/tunnels/${tunnel.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subdomain: subdomain.trim(),
          zoneId,
          targetPort: parseInt(port) || 3000,
          targetHost: host,
          protocol,
          noTlsVerify,
          originHostHeader: originHostHeader.trim(),
          advancedConfig: {
            originServerName: originServerName.trim(),
            httpConnectTimeout: parseInt(httpConnectTimeout) || 30,
            httpTLSHandshakeTimeout: parseInt(httpTLSHandshakeTimeout) || 10,
            noHappyEyeballs,
            proxyType: proxyType || undefined
          }
        }),
      })
      const data = await res.json()
      if (res.ok) {
        toast.success(`Route updated → ${data.fullHostname}`)
        onSaved()
        onClose()
      } else {
        toast.error(data.error || 'Failed to update route')
      }
    } finally { setSaving(false) }
  }

  return (
    <div className="border-t border-white/[0.06] bg-[#0a0a15] px-5 py-5 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-white flex items-center gap-2">
          <Pencil className="w-3.5 h-3.5 text-blue-400" /> Edit Public Hostname
        </h3>
        <button onClick={onClose} className="text-white/30 hover:text-white transition p-1 rounded-lg hover:bg-white/[0.06]">
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Subdomain + Domain */}
      <div className="grid grid-cols-[1fr_auto_1fr] gap-2 items-end">
        <div>
          <Label className="text-white/40 text-xs mb-1.5 block">Subdomain</Label>
          <Input
            value={subdomain}
            onChange={e => setSubdomain(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ''))}
            placeholder="myapp"
            className={`bg-white/[0.04] border-white/[0.08] text-white rounded-lg h-9 text-sm ${conflict ? 'border-red-500/50' : ''}`}
          />
        </div>
        <div className="flex items-end pb-2 justify-center text-white/20 font-bold text-lg">.</div>
        <div>
          <Label className="text-white/40 text-xs mb-1.5 block">Domain</Label>
          <div className="relative">
            <select value={zoneId} onChange={e => setZoneId(e.target.value)}
              className="w-full h-9 bg-white/[0.04] border border-white/[0.08] text-white text-sm rounded-lg px-3 appearance-none focus:outline-none focus:border-blue-500/50 transition">
              {allowedZones.map(z => <option key={z.id} value={z.id} className="bg-[#0e0e1a]">{z.name}</option>)}
            </select>
            <ChevronDown className="w-3 h-3 text-white/25 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>
        </div>
      </div>

      {conflict && (
        <p className="text-xs text-red-400 flex items-center gap-1.5">
          <AlertTriangle className="w-3 h-3" /> This subdomain is already in use by another tunnel
        </p>
      )}
      {previewUrl && !conflict && (
        <p className="text-xs text-emerald-400 flex items-center gap-1.5">
          <CheckCircle className="w-3 h-3" /> {previewUrl}
        </p>
      )}

      {/* Service config */}
      <div>
        <Label className="text-white/40 text-xs mb-1.5 block">Service (what this tunnel points to)</Label>
        <div className="grid grid-cols-3 gap-2">
          <div>
            <select value={protocol} onChange={e => setProtocol(e.target.value)}
              className="w-full h-9 bg-white/[0.04] border border-white/[0.08] text-white text-sm rounded-lg px-3 appearance-none">
              {['http', 'https', 'tcp', 'ssh'].map(p => <option key={p} value={p} className="bg-[#0e0e1a]">{p}</option>)}
            </select>
          </div>
          <Input value={host} onChange={e => setHost(e.target.value)} placeholder="localhost"
            className="bg-white/[0.04] border-white/[0.08] text-white rounded-lg h-9 text-sm" />
          <Input type="number" value={port} onChange={e => setPort(e.target.value)} placeholder="3000"
            className="bg-white/[0.04] border-white/[0.08] text-white rounded-lg h-9 text-sm" />
        </div>
        <p className="text-[11px] text-white/25 mt-1.5">
          Traffic to <span className="text-white/40 font-mono">{previewUrl || '(your domain)'}</span> will be forwarded to{' '}
          <span className="text-white/40 font-mono">{protocol}://{host}:{port}</span>
        </p>
      </div>

      {/* Advanced Settings */}
      <div className="pt-2 space-y-4">
        <p className="text-[10px] font-bold text-white/20 uppercase tracking-widest">Advanced Options</p>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="flex items-center justify-between p-3 rounded-xl bg-white/[0.02] border border-white/[0.05]">
            <div className="space-y-0.5">
              <Label className="text-xs text-white/70">No TLS Verify</Label>
              <p className="text-[10px] text-white/30">Disable certificate verification</p>
            </div>
            <input
              type="checkbox"
              checked={noTlsVerify}
              onChange={e => setNoTlsVerify(e.target.checked)}
              className="w-4 h-4 rounded border-white/10 bg-white/5 text-blue-500 focus:ring-blue-500/20"
            />
          </div>

          <div className="flex items-center justify-between p-3 rounded-xl bg-white/[0.02] border border-white/[0.05]">
            <div className="space-y-0.5">
              <Label className="text-xs text-white/70">No Happy Eyeballs</Label>
              <p className="text-[10px] text-white/30">Disable IPv6/IPv4 fast fallback</p>
            </div>
            <input
              type="checkbox"
              checked={noHappyEyeballs}
              onChange={e => setNoHappyEyeballs(e.target.checked)}
              className="w-4 h-4 rounded border-white/10 bg-white/5 text-blue-500 focus:ring-blue-500/20"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="space-y-1.5">
            <Label className="text-xs text-white/70">Origin Host Header</Label>
            <Input
              value={originHostHeader}
              onChange={e => setOriginHostHeader(e.target.value)}
              placeholder="e.g. example.com"
              className="bg-white/[0.04] border-white/[0.08] text-white rounded-lg h-9 text-xs"
            />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs text-white/70">Origin Server Name (SNI)</Label>
            <Input
              value={originServerName}
              onChange={e => setOriginServerName(e.target.value)}
              placeholder="e.g. sni.example.com"
              className="bg-white/[0.04] border-white/[0.08] text-white rounded-lg h-9 text-xs"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="space-y-1.5">
            <Label className="text-xs text-white/70">Connect Timeout (s)</Label>
            <Input
              type="number"
              value={httpConnectTimeout}
              onChange={e => setHttpConnectTimeout(e.target.value)}
              className="bg-white/[0.04] border-white/[0.08] text-white rounded-lg h-9 text-xs"
            />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs text-white/70">TLS Timeout (s)</Label>
            <Input
              type="number"
              value={httpTLSHandshakeTimeout}
              onChange={e => setHttpTLSHandshakeTimeout(e.target.value)}
              className="bg-white/[0.04] border-white/[0.08] text-white rounded-lg h-9 text-xs"
            />
          </div>
          <div className="space-y-1.5">
            <Label className="text-xs text-white/70">Proxy Type</Label>
            <select
              value={proxyType}
              onChange={e => setProxyType(e.target.value)}
              className="w-full h-9 bg-white/[0.04] border border-white/[0.08] text-white text-xs rounded-lg px-3 appearance-none focus:outline-none focus:border-blue-500/50 transition"
            >
              <option value="" className="bg-[#0e0e1a]">None</option>
              <option value="socks" className="bg-[#0e0e1a]">SOCKS5</option>
            </select>
          </div>
        </div>
      </div>

      <div className="flex gap-2 pt-1">
        <Button onClick={onClose} variant="outline"
          className="border-white/[0.08] text-white/40 hover:text-white bg-transparent rounded-lg text-sm h-9">
          Cancel
        </Button>
        <Button onClick={save} disabled={saving || !!conflict}
          className="bg-blue-600 hover:bg-blue-500 text-white rounded-lg text-sm h-9 gap-2 flex-1">
          {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <CheckCircle className="w-3.5 h-3.5" />}
          {saving ? 'Saving...' : 'Save Route'}
        </Button>
      </div>
    </div>
  )
}

function TunnelCard({
  tunnel,
  allowedZones,
  usedSubdomains,
  onDelete,
  onRefresh,
}: {
  tunnel: Tunnel
  allowedZones: Zone[]
  usedSubdomains: UsedSubdomain[]
  onDelete: (id: string, name: string) => void
  onRefresh: () => void
}) {
  const [open, setOpen] = useState(false)
  const [tab, setTab] = useState<TunnelTab>('connector')
  const [os, setOs] = useState<OS>('linux-deb')
  const [showEdit, setShowEdit] = useState(false)
  const [deleting, setDeleting] = useState(false)
  const [checkingStatus, setCheckingStatus] = useState(false)

  const hasHostname = !!(tunnel.subdomain && tunnel.zoneDomain)
  const fullUrl = hasHostname ? `https://${tunnel.subdomain}.${tunnel.zoneDomain}` : null
  const steps = tunnel.cfTunnelToken ? getInstallSteps(os, tunnel.cfTunnelToken) : []

  const checkConnectorStatus = async () => {
    setCheckingStatus(true)
    try {
      const res = await fetch(`/api/tunnels/${tunnel.id}?refreshStatus=1`)
      const data = await res.json()
      if (!res.ok) {
        toast.error(data.error || 'Failed to check connector status')
        return
      }
      if (data.tunnel?.status === 'ACTIVE') {
        toast.success('Connector is online. Tunnel is active.')
      } else {
        toast.info('Connector not online yet. Run cloudflared command and retry.')
      }
      onRefresh()
    } catch {
      toast.error('Failed to check connector status')
    } finally {
      setCheckingStatus(false)
    }
  }

  const handleDelete = async () => {
    if (!confirm(`Delete tunnel "${tunnel.name}"?\n\nThis will remove it from Cloudflare and delete the DNS record.`)) return
    setDeleting(true)
    await onDelete(tunnel.id, tunnel.name)
    setDeleting(false)
  }

  const borderColor = tunnel.status === 'ACTIVE'
    ? 'border-emerald-500/10'
    : tunnel.status === 'ERROR'
      ? 'border-red-500/15'
      : 'border-white/[0.06]'

  return (
    <div className={`rounded-2xl border overflow-hidden transition-all duration-300 bg-[#07070f] group ${borderColor} hover:shadow-[0_0_20px_rgba(59,130,246,0.05)]`}>
      {/* Header row */}
      <div
        className="flex items-center gap-3 px-4 py-4 cursor-pointer select-none hover:bg-white/[0.03] transition-colors"
        onClick={() => setOpen(o => !o)}
      >
        {/* Status icon with pulse effect */}
        <div className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 border transition-transform duration-300 group-hover:scale-105 ${
          tunnel.status === 'ACTIVE' ? 'bg-emerald-500/10 border-emerald-500/20 shadow-[0_0_10px_rgba(16,185,129,0.1)]' :
          tunnel.status === 'ERROR' ? 'bg-red-500/10 border-red-500/20 shadow-[0_0_10px_rgba(239,68,68,0.1)]' :
          'bg-white/[0.04] border-white/[0.08]'
        }`}>
          {tunnel.status === 'ACTIVE' ? <Wifi className="w-5 h-5 text-emerald-400" /> :
           tunnel.status === 'ERROR' ? <WifiOff className="w-5 h-5 text-red-400" /> :
           <Loader2 className="w-5 h-5 text-white/25 animate-spin" />}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap mb-0.5">
            <span className="text-sm font-bold text-white tracking-tight">{tunnel.name}</span>
            <StatusBadge status={tunnel.status} />
          </div>
          <div className="flex items-center gap-1.5 text-[11px] text-white/30 font-mono">
            {fullUrl
              ? (
                <div className="flex items-center gap-1 overflow-hidden">
                  <Globe className="w-3 h-3 flex-shrink-0" />
                  <span className="text-blue-400/80 truncate">{fullUrl}</span>
                </div>
              )
              : <span className="text-white/20 italic flex items-center gap-1"><AlertTriangle className="w-3 h-3" /> No public hostname</span>
            }
          </div>
        </div>

        <div className="flex items-center gap-1.5 flex-shrink-0">
          {fullUrl && (
            <a href={fullUrl} target="_blank" rel="noopener noreferrer" onClick={e => e.stopPropagation()}
              className="p-2 rounded-xl text-white/20 hover:text-blue-400 hover:bg-blue-500/10 transition-all">
              <ExternalLink className="w-4 h-4" />
            </a>
          )}
          <button onClick={e => { e.stopPropagation(); handleDelete() }} disabled={deleting}
            className="p-2 rounded-xl text-white/20 hover:text-red-400 hover:bg-red-500/10 transition-all">
            {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
          </button>
          <div className={`p-1.5 rounded-lg bg-white/[0.03] transition-transform duration-300 ${open ? 'rotate-180' : ''}`}>
            <ChevronDown className="w-4 h-4 text-white/20" />
          </div>
        </div>
      </div>

      {/* Error message */}
      {tunnel.status === 'ERROR' && tunnel.errorMsg && (
        <div className="mx-4 mb-3 flex items-start gap-2 px-3 py-2.5 rounded-xl bg-red-500/8 border border-red-500/15 text-xs text-red-300">
          <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
          <span>{tunnel.errorMsg}</span>
        </div>
      )}

      {/* Expanded */}
      {open && (
        <div className="border-t border-white/[0.05]">
          {/* Tabs */}
          <div className="flex border-b border-white/[0.05] px-4 bg-black/20">
            {([
              { key: 'connector', label: 'Connector', icon: Terminal },
              { key: 'hostname', label: 'Public Hostname', icon: Link },
              { key: 'settings', label: 'Settings', icon: Settings },
            ] as { key: TunnelTab; label: string; icon: any }[]).map(({ key, label, icon: Icon }) => (
              <button key={key} onClick={() => { setTab(key); setShowEdit(false) }}
                className={`flex items-center gap-1.5 px-3 py-3 text-xs font-medium border-b-2 -mb-px transition whitespace-nowrap ${
                  tab === key
                    ? 'border-blue-500 text-white'
                    : 'border-transparent text-white/40 hover:text-white/70'
                }`}>
                <Icon className="w-3.5 h-3.5" />
                {label}
              </button>
            ))}
          </div>

          {/* Tab: Connector */}
          {tab === 'connector' && (
            <div className="px-5 py-5 space-y-4">
              {!tunnel.cfTunnelToken ? (
                <div className="text-center py-8">
                  <WifiOff className="w-8 h-8 text-white/10 mx-auto mb-2" />
                  <p className="text-sm text-white/30">No connector token — tunnel may have failed to create</p>
                  <p className="text-xs text-white/20 mt-1">Try deleting and recreating this tunnel</p>
                </div>
              ) : (
                <>
                  <div>
                    <p className="text-xs font-medium text-white/50 mb-1">Tunnel Token</p>
                    <div className="flex items-center gap-2 p-3 rounded-xl bg-black/40 border border-white/[0.06] font-mono text-[11px] text-white/40 overflow-hidden">
                      <span className="flex-1 truncate">{tunnel.cfTunnelToken.slice(0, 40)}…</span>
                      <CopyBtn text={tunnel.cfTunnelToken} label="Copy token" />
                    </div>
                  </div>

                  <div>
                    <p className="text-xs font-medium text-white/50 mb-3">Choose your operating system and run the commands below</p>
                    <div className="flex gap-2 overflow-x-auto scrollbar-none flex-wrap">
                      {OS_TABS.map(tab => (
                        <button key={tab.key} onClick={() => setOs(tab.key)}
                          className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium whitespace-nowrap rounded-xl transition border ${
                            os === tab.key
                              ? 'bg-blue-500/15 text-white border-blue-500/30'
                              : 'bg-white/[0.03] text-white/40 border-white/[0.07] hover:text-white/70 hover:bg-white/[0.06]'
                          }`}>
                          <span>{tab.emoji}</span> {tab.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-3">
                    {steps.map((step, i) => (
                      <div key={i}>
                        <div className="flex items-center gap-2 mb-2">
                          <span className="w-5 h-5 rounded-full bg-blue-600 text-white text-[10px] font-bold flex items-center justify-center flex-shrink-0">{i + 1}</span>
                          <span className="text-xs font-medium text-white/70">{step.title}</span>
                        </div>
                        <div className="relative">
                          <pre className="bg-[#0d0d1a] border border-white/[0.07] rounded-xl px-4 py-3.5 text-[12px] text-cyan-300 font-mono overflow-x-auto whitespace-pre leading-relaxed pr-20">
                            {step.cmd}
                          </pre>
                          <div className="absolute top-3 right-3">
                            <CopyBtn text={step.cmd} />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="pt-1">
                    <Button
                      onClick={checkConnectorStatus}
                      disabled={checkingStatus}
                      variant="outline"
                      className="border-white/10 text-white bg-transparent hover:bg-white/5 text-xs h-9 gap-2"
                    >
                      {checkingStatus ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
                      {checkingStatus ? 'Checking…' : 'Check connector status'}
                    </Button>
                  </div>
                </>
              )}
            </div>
          )}

          {/* Tab: Public Hostname */}
          {tab === 'hostname' && (
            <div className="px-5 py-5 space-y-4">
              {hasHostname ? (
                <>
                  <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/5 px-4 py-3.5">
                    <div className="flex items-center gap-2 mb-3">
                      <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                      <span className="text-xs font-semibold text-emerald-400 uppercase tracking-wide">Active Route</span>
                    </div>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-white/40 w-20 flex-shrink-0">Hostname</span>
                        <div className="flex items-center gap-2 flex-1 min-w-0">
                          <span className="text-sm text-white font-mono truncate">{fullUrl}</span>
                          <CopyBtn text={fullUrl!} />
                          <a href={fullUrl!} target="_blank" rel="noopener noreferrer"
                            className="p-1 rounded-lg text-white/30 hover:text-white transition flex-shrink-0">
                            <ExternalLink className="w-3.5 h-3.5" />
                          </a>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-white/40 w-20 flex-shrink-0">Service</span>
                        <span className="text-sm text-white/60 font-mono">{tunnel.protocol}://{tunnel.targetHost}:{tunnel.targetPort}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-white/40 w-20 flex-shrink-0">Protocol</span>
                        <span className="text-xs text-white/60 uppercase font-medium">{tunnel.protocol}</span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => setShowEdit(e => !e)}
                    className="flex items-center gap-2 text-sm text-blue-400 hover:text-blue-300 transition font-medium"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                    {showEdit ? 'Cancel editing' : 'Edit this route'}
                  </button>
                </>
              ) : (
                <div className="text-center py-6">
                  <Globe className="w-8 h-8 text-white/10 mx-auto mb-2" />
                  <p className="text-sm text-white/30 mb-1">No public hostname configured</p>
                  <p className="text-xs text-white/20 mb-4">Add a subdomain to expose this tunnel to the internet</p>
                  <Button onClick={() => setShowEdit(true)} size="sm"
                    className="bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs gap-2">
                    <Plus className="w-3.5 h-3.5" /> Add Public Hostname
                  </Button>
                </div>
              )}
            </div>
          )}

          {/* Tab: Settings */}
          {tab === 'settings' && (
            <div className="px-5 py-5 space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between p-3 rounded-xl border border-white/[0.06] bg-white/[0.02]">
                  <div>
                    <p className="text-xs font-medium text-white/70">Tunnel ID</p>
                    <p className="text-xs text-white/30 font-mono mt-0.5">{tunnel.cfTunnelId || 'Not assigned'}</p>
                  </div>
                  {tunnel.cfTunnelId && <CopyBtn text={tunnel.cfTunnelId} />}
                </div>
                <div className="flex items-center justify-between p-3 rounded-xl border border-white/[0.06] bg-white/[0.02]">
                  <div>
                    <p className="text-xs font-medium text-white/70">Created</p>
                    <p className="text-xs text-white/30 mt-0.5">{new Date(tunnel.createdAt).toLocaleString()}</p>
                  </div>
                </div>
                <div className="flex items-center justify-between p-3 rounded-xl border border-white/[0.06] bg-white/[0.02]">
                  <div>
                    <p className="text-xs font-medium text-white/70">Last Updated</p>
                    <p className="text-xs text-white/30 mt-0.5">{new Date(tunnel.updatedAt).toLocaleString()}</p>
                  </div>
                </div>
              </div>

              <div className="pt-2 border-t border-white/[0.05]">
                <p className="text-xs text-white/30 mb-3 font-medium">Danger Zone</p>
                <button onClick={handleDelete} disabled={deleting}
                  className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-red-500/20 bg-red-500/5 text-red-400 hover:bg-red-500/10 hover:border-red-500/30 transition text-sm font-medium">
                  {deleting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                  Delete Tunnel
                </button>
              </div>
            </div>
          )}

          {/* Edit Route panel — appears below any tab */}
          {showEdit && allowedZones.length > 0 && (
            <EditRoute
              tunnel={tunnel}
              allowedZones={allowedZones}
              usedSubdomains={usedSubdomains}
              onSaved={onRefresh}
              onClose={() => setShowEdit(false)}
            />
          )}
          {showEdit && allowedZones.length === 0 && (
            <div className="px-5 py-4 border-t border-white/[0.05] text-xs text-amber-400 flex items-center gap-2">
              <AlertTriangle className="w-3.5 h-3.5" />
              No domains configured. Admin must add allowed zones in the Cloudflare settings.
            </div>
          )}
        </div>
      )}
    </div>
  )
}

// 4-step Create Wizard
function CreateWizard({
  onCreated,
  onCancel,
  allowedZones,
  usedSubdomains,
}: {
  onCreated: () => void
  onCancel: () => void
  allowedZones: Zone[]
  usedSubdomains: UsedSubdomain[]
}) {
  const [step, setStep] = useState<CreateStep>('type')
  const [tunnelName, setTunnelName] = useState(randomName())
  const [os, setOs] = useState<OS>('linux-deb')
  const [newTunnel, setNewTunnel] = useState<Tunnel | null>(null)
  const [creating, setCreating] = useState(false)
  const [subdomain, setSubdomain] = useState('')
  const [zoneId, setZoneId] = useState(allowedZones[0]?.id || '')
  const [port, setPort] = useState('3000')
  const [host, setHost] = useState('localhost')
  const [protocol, setProtocol] = useState('http')
  const [noTlsVerify, setNoTlsVerify] = useState(false)
  const [originHostHeader, setOriginHostHeader] = useState('')
  
  // Advanced Config for Wizard
  const [originServerName, setOriginServerName] = useState('')
  const [httpConnectTimeout, setHttpConnectTimeout] = useState('30')
  const [httpTLSHandshakeTimeout, setHttpTLSHandshakeTimeout] = useState('10')
  const [noHappyEyeballs, setNoHappyEyeballs] = useState(false)
  const [proxyType, setProxyType] = useState('')

  const [addingHostname, setAddingHostname] = useState(false)
  const [checkingConnector, setCheckingConnector] = useState(false)

  const selectedZone = allowedZones.find(z => z.id === zoneId)
  const previewUrl = subdomain && selectedZone ? `https://${subdomain}.${selectedZone.name}` : null
  const steps_cmds = newTunnel?.cfTunnelToken ? getInstallSteps(os, newTunnel.cfTunnelToken) : []
  const connectorActive = newTunnel?.status === 'ACTIVE'

  const subConflict = usedSubdomains.find(s =>
    s.subdomain === subdomain.toLowerCase() && s.zoneId === zoneId
  )

  const createTunnel = async () => {
    if (!tunnelName.trim()) { toast.error('Tunnel name required'); return }
    setCreating(true)
    try {
      const res = await fetch('/api/tunnels', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: tunnelName.trim() }),
      })
      const data = await res.json()
      if (res.ok) {
        setNewTunnel(data.tunnel)
        if (data.tunnel.status === 'ERROR') {
          toast.error(data.tunnel.errorMsg || 'Tunnel created but Cloudflare registration failed')
        } else {
          toast.success('Tunnel created! Now install the connector.')
        }
        setStep('connect')
      } else {
        toast.error(data.error || 'Failed to create tunnel')
      }
    } finally { setCreating(false) }
  }

  const addHostname = async () => {
    if (!subdomain.trim()) { toast.error('Subdomain required'); return }
    if (!newTunnel?.id) return
    if (subConflict) { toast.error('That subdomain is already in use'); return }
    setAddingHostname(true)
    try {
      const res = await fetch(`/api/tunnels/${newTunnel.id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subdomain: subdomain.trim(),
          zoneId,
          targetPort: parseInt(port) || 3000,
          targetHost: host,
          protocol,
          noTlsVerify,
          originHostHeader: originHostHeader.trim(),
          advancedConfig: {
            originServerName: originServerName.trim(),
            httpConnectTimeout: parseInt(httpConnectTimeout) || 30,
            httpTLSHandshakeTimeout: parseInt(httpTLSHandshakeTimeout) || 10,
            noHappyEyeballs,
            proxyType: proxyType || undefined
          }
        }),
      })
      const data = await res.json()
      if (res.ok) {
        toast.success(`Live at ${data.fullHostname}`)
        onCreated()
      } else {
        toast.error(data.error || 'Failed to set hostname')
      }
    } finally { setAddingHostname(false) }
  }

  const refreshConnectorStatus = async () => {
    if (!newTunnel?.id) return
    setCheckingConnector(true)
    try {
      const res = await fetch(`/api/tunnels/${newTunnel.id}?refreshStatus=1`)
      const data = await res.json()
      if (!res.ok) {
        toast.error(data.error || 'Failed to check connector status')
        return
      }
      setNewTunnel(data.tunnel)
      if (data.tunnel?.status === 'ACTIVE') {
        toast.success('Connector connected. You can continue to Public Hostname.')
      } else {
        toast.info('Still waiting for connector. Please run the install command on your server.')
      }
    } catch {
      toast.error('Failed to check connector status')
    } finally {
      setCheckingConnector(false)
    }
  }

  const STEP_LABELS: Record<CreateStep, string> = {
    type: 'Select type',
    name: 'Name tunnel',
    connect: 'Install connector',
    route: 'Route traffic'
  }

  const stepOrder: CreateStep[] = ['type', 'name', 'connect', 'route']

  return (
    <div className="rounded-2xl border border-white/[0.08] bg-[#08080f] overflow-hidden">
      {/* Wizard header */}
      <div className="px-6 pt-6 pb-4">
        <div className="flex items-center gap-2 mb-5 overflow-x-auto scrollbar-none">
          {stepOrder.map((s, i) => {
            const currentIdx = stepOrder.indexOf(step)
            const isDone = i < currentIdx
            const isCurrent = s === step
            return (
              <div key={s} className="flex items-center gap-2 flex-shrink-0">
                <button
                  onClick={() => { if (isDone || isCurrent) setStep(s) }}
                  className={`flex items-center gap-1.5 text-xs font-medium transition ${
                    isCurrent ? 'text-white' : isDone ? 'text-emerald-400 hover:text-emerald-300' : 'text-white/25 cursor-default'
                  }`}
                >
                  <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold border flex-shrink-0 ${
                    isDone ? 'bg-emerald-500/20 border-emerald-500/30 text-emerald-400' :
                    isCurrent ? 'bg-blue-600 border-blue-500 text-white' :
                    'bg-white/[0.04] border-white/[0.08] text-white/25'
                  }`}>
                    {isDone ? '✓' : i + 1}
                  </span>
                  {STEP_LABELS[s]}
                </button>
                {i < stepOrder.length - 1 && <ChevronRight className="w-3 h-3 text-white/15 flex-shrink-0" />}
              </div>
            )
          })}
          <button onClick={onCancel} className="ml-auto text-white/30 hover:text-white transition flex-shrink-0">
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Step: Type */}
        {step === 'type' && (
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-bold text-white">Select your tunnel type</h2>
              <p className="text-sm text-white/40 mt-1">Choose the method used to connect your resources to Cloudflare's global network.</p>
            </div>
            <div className="grid sm:grid-cols-2 gap-3 mt-4">
              {[
                { name: 'Cloudflared', tag: 'Recommended', info: 'Establishes a secure, outbound-only connection to Cloudflare for user-to-network connectivity.', active: true },
                { name: 'Mesh (Beta)', tag: 'Linux only', info: 'Supports on-ramping and off-ramping traffic for site-to-site, bidirectional, and mesh networking.', active: false },
              ].map(t => (
                <div key={t.name}
                  className={`p-4 rounded-2xl border transition cursor-pointer ${
                    t.active ? 'border-blue-500/30 bg-blue-500/5 hover:border-blue-500/50 hover:bg-blue-500/8' : 'border-white/[0.06] bg-white/[0.02] opacity-50 cursor-not-allowed'
                  }`}
                  onClick={() => t.active && setStep('name')}
                >
                  <div className="flex items-center gap-2 mb-1.5">
                    <p className="font-semibold text-white text-sm">{t.name}</p>
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-medium ${t.active ? 'bg-blue-500/20 text-blue-300' : 'bg-white/[0.08] text-white/30'}`}>{t.tag}</span>
                  </div>
                  <p className="text-xs text-white/40 leading-relaxed">{t.info}</p>
                </div>
              ))}
            </div>
            <Button onClick={() => setStep('name')} className="bg-blue-600 hover:bg-blue-500 text-white rounded-xl gap-2 mt-2">
              Select Cloudflared <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        )}

        {/* Step: Name */}
        {step === 'name' && !newTunnel && (
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-bold text-white">Name your tunnel</h2>
              <p className="text-sm text-white/40 mt-1">Use a descriptive name based on the network you want to connect. You can create multiple tunnels for different projects.</p>
            </div>
            <div className="space-y-2 mt-4">
              <Label className="text-white/40 text-xs">Tunnel name <span className="text-red-400">*</span></Label>
              <div className="flex gap-2">
                <Input value={tunnelName} onChange={e => setTunnelName(e.target.value)}
                  placeholder="my-production-server"
                  className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl h-10 flex-1 font-mono" />
                <Button variant="outline" onClick={() => setTunnelName(randomName())}
                  className="border-white/[0.08] text-white/40 hover:text-white hover:bg-white/[0.07] bg-transparent h-10 rounded-xl px-4">
                  Shuffle
                </Button>
              </div>
            </div>
            <div className="flex gap-2 mt-4">
              <Button onClick={() => setStep('type')} variant="outline"
                className="border-white/[0.08] text-white/40 hover:text-white bg-transparent rounded-xl">
                <ArrowLeft className="w-4 h-4" />
              </Button>
              <Button onClick={createTunnel} disabled={creating || !tunnelName.trim()}
                className="bg-blue-600 hover:bg-blue-500 text-white rounded-xl gap-2 flex-1">
                {creating ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
                {creating ? 'Creating tunnel...' : 'Save Tunnel →'}
              </Button>
            </div>
          </div>
        )}

        {/* Step: Connect */}
        {step === 'connect' && newTunnel && (
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-bold text-white">Install and run a connector</h2>
              <p className="text-sm text-white/40 mt-1">
                Run <span className="text-white/60 font-mono text-xs">cloudflared</span> on the machine you want to expose. Choose your OS below.
              </p>
            </div>

            {newTunnel.status === 'ERROR' && (
              <div className="flex items-start gap-2 p-3 rounded-xl bg-red-500/8 border border-red-500/20 text-xs text-red-300">
                <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium">Cloudflare registration failed</p>
                  <p className="text-red-400/70 mt-0.5">{newTunnel.errorMsg}</p>
                  <p className="mt-1">The tunnel was saved locally. You can still try to add a hostname, but it may not work until Cloudflare is configured correctly by admin.</p>
                </div>
              </div>
            )}

            <div className="flex gap-2 flex-wrap">
              {OS_TABS.map(tab => (
                <button key={tab.key} onClick={() => setOs(tab.key)}
                  className={`flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium rounded-xl transition border whitespace-nowrap ${
                    os === tab.key
                      ? 'bg-blue-500/15 text-white border-blue-500/30'
                      : 'bg-white/[0.03] text-white/40 border-white/[0.07] hover:text-white/70 hover:bg-white/[0.06]'
                  }`}>
                  <span>{tab.emoji}</span> {tab.label}
                </button>
              ))}
            </div>

            <div className="space-y-3">
              {steps_cmds.map((s, i) => (
                <div key={i}>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="w-5 h-5 rounded-full bg-blue-600 text-white text-[10px] font-bold flex items-center justify-center flex-shrink-0">{i + 1}</span>
                    <span className="text-xs font-medium text-white/70">{s.title}</span>
                  </div>
                  <div className="relative">
                    <pre className="bg-[#0d0d1a] border border-white/[0.07] rounded-xl px-4 py-3.5 text-[12px] text-cyan-300 font-mono overflow-x-auto whitespace-pre leading-relaxed pr-20">
                      {s.cmd}
                    </pre>
                    <div className="absolute top-3 right-3">
                      <CopyBtn text={s.cmd} />
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="rounded-xl border border-white/[0.08] bg-white/[0.02] p-3 text-xs">
              <div className="flex items-center justify-between gap-3">
                <span className="text-white/60">Connector status</span>
                <StatusBadge status={newTunnel.status} />
              </div>
              <p className="text-white/35 mt-1">
                Run the command above on your machine, then click check.
              </p>
              <Button
                onClick={refreshConnectorStatus}
                disabled={checkingConnector}
                variant="outline"
                className="mt-3 border-white/10 text-white bg-transparent hover:bg-white/5 text-xs h-8 gap-2"
              >
                {checkingConnector ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
                {checkingConnector ? 'Checking…' : 'Check connector status'}
              </Button>
            </div>

            <div className="flex gap-2 pt-2">
              <Button onClick={() => { setStep('name'); setNewTunnel(null) }} variant="outline"
                className="border-white/[0.08] text-white/40 hover:text-white bg-transparent rounded-xl">
                <ArrowLeft className="w-4 h-4" />
              </Button>
              <Button
                onClick={() => setStep('route')}
                disabled={!connectorActive}
                className="bg-blue-600 hover:bg-blue-500 text-white rounded-xl gap-2 flex-1 disabled:opacity-50"
              >
                Next: Route Traffic <ArrowRight className="w-4 h-4" />
              </Button>
            </div>
            {!connectorActive && (
              <p className="text-xs text-amber-400">
                Connector must be active before creating a public hostname.
              </p>
            )}
          </div>
        )}

        {/* Step: Route */}
        {step === 'route' && newTunnel && (
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-bold text-white">Route traffic</h2>
              <p className="text-sm text-white/40 mt-1">Add a public hostname so traffic from the internet reaches your service through this tunnel.</p>
            </div>

            {allowedZones.length === 0 ? (
              <div className="flex items-center gap-2 p-4 rounded-xl bg-amber-500/8 border border-amber-500/20 text-sm text-amber-300">
                <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                No domains configured. Admin needs to add allowed zones in Cloudflare settings. You can skip for now.
              </div>
            ) : (
              <>
                <div className="grid grid-cols-[1fr_auto_1fr] gap-2 items-end">
                  <div>
                    <Label className="text-white/40 text-xs mb-1.5 block">Subdomain</Label>
                    <Input value={subdomain}
                      onChange={e => setSubdomain(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, ''))}
                      placeholder="myapp"
                      className={`bg-white/[0.04] border-white/[0.08] text-white rounded-xl h-9 text-sm ${subConflict ? 'border-red-500/50' : ''}`} />
                  </div>
                  <div className="flex items-end pb-2 justify-center text-white/20 font-bold text-lg">.</div>
                  <div>
                    <Label className="text-white/40 text-xs mb-1.5 block">Domain</Label>
                    <div className="relative">
                      <select value={zoneId} onChange={e => setZoneId(e.target.value)}
                        className="w-full h-9 bg-white/[0.04] border border-white/[0.08] text-white text-sm rounded-xl px-3 appearance-none focus:outline-none">
                        {allowedZones.map(z => <option key={z.id} value={z.id} className="bg-[#0e0e1a]">{z.name}</option>)}
                      </select>
                      <ChevronDown className="w-3 h-3 text-white/25 absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                    </div>
                  </div>
                </div>

                {subConflict && <p className="text-xs text-red-400 flex items-center gap-1"><AlertTriangle className="w-3 h-3" /> Subdomain already in use</p>}
                {previewUrl && !subConflict && <p className="text-xs text-emerald-400 flex items-center gap-1"><CheckCircle className="w-3 h-3" /> {previewUrl}</p>}

                <div>
                  <Label className="text-white/40 text-xs mb-1.5 block">Service</Label>
                  <div className="grid grid-cols-3 gap-2">
                    <select value={protocol} onChange={e => setProtocol(e.target.value)}
                      className="w-full h-9 bg-white/[0.04] border border-white/[0.08] text-white text-sm rounded-xl px-3 appearance-none">
                      {['http', 'https', 'tcp', 'ssh'].map(p => <option key={p} value={p} className="bg-[#0e0e1a]">{p}</option>)}
                    </select>
                    <Input value={host} onChange={e => setHost(e.target.value)} placeholder="localhost"
                      className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl h-9 text-sm" />
                    <Input type="number" value={port} onChange={e => setPort(e.target.value)} placeholder="3000"
                      className="bg-white/[0.04] border-white/[0.08] text-white rounded-xl h-9 text-sm" />
                  </div>
                </div>

                {/* Advanced Settings for Wizard */}
                <div className="pt-2 space-y-4">
                  <p className="text-[10px] font-bold text-white/20 uppercase tracking-widest">Advanced Options</p>
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="flex items-center justify-between p-2.5 rounded-xl bg-white/[0.02] border border-white/[0.05]">
                      <div className="space-y-0.5">
                        <Label className="text-[11px] text-white/70">No TLS Verify</Label>
                        <p className="text-[9px] text-white/30 tracking-tight">Disable certificate verification</p>
                      </div>
                      <input
                        type="checkbox"
                        checked={noTlsVerify}
                        onChange={e => setNoTlsVerify(e.target.checked)}
                        className="w-3.5 h-3.5 rounded border-white/10 bg-white/5 text-blue-500 focus:ring-blue-500/20"
                      />
                    </div>

                    <div className="flex items-center justify-between p-2.5 rounded-xl bg-white/[0.02] border border-white/[0.05]">
                      <div className="space-y-0.5">
                        <Label className="text-[11px] text-white/70">No Happy Eyeballs</Label>
                        <p className="text-[9px] text-white/30 tracking-tight">Disable IPv6/IPv4 fast fallback</p>
                      </div>
                      <input
                        type="checkbox"
                        checked={noHappyEyeballs}
                        onChange={e => setNoHappyEyeballs(e.target.checked)}
                        className="w-3.5 h-3.5 rounded border-white/10 bg-white/5 text-blue-500 focus:ring-blue-500/20"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <Label className="text-[11px] text-white/40 ml-1">Origin Host Header</Label>
                      <Input
                        value={originHostHeader}
                        onChange={e => setOriginHostHeader(e.target.value)}
                        placeholder="e.g. example.com"
                        className="bg-white/[0.04] border-white/[0.08] text-white rounded-lg h-8 text-[11px]"
                      />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-[11px] text-white/40 ml-1">Origin Server Name (SNI)</Label>
                      <Input
                        value={originServerName}
                        onChange={e => setOriginServerName(e.target.value)}
                        placeholder="e.g. sni.example.com"
                        className="bg-white/[0.04] border-white/[0.08] text-white rounded-lg h-8 text-[11px]"
                      />
                    </div>
                  </div>
                </div>
              </>
            )}

            <div className="flex gap-2 pt-2">
              <Button onClick={() => setStep('connect')} variant="outline"
                className="border-white/[0.08] text-white/40 hover:text-white bg-transparent rounded-xl">
                <ArrowLeft className="w-4 h-4" />
              </Button>
              {allowedZones.length > 0 ? (
                <Button onClick={addHostname} disabled={addingHostname || !!subConflict || !subdomain.trim()}
                  className="bg-blue-600 hover:bg-blue-500 text-white rounded-xl gap-2 flex-1">
                  {addingHostname ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle className="w-4 h-4" />}
                  {addingHostname ? 'Setting up...' : 'Save & Finish'}
                </Button>
              ) : (
                <Button onClick={onCreated} className="bg-white/[0.08] hover:bg-white/[0.12] text-white rounded-xl gap-2 flex-1">
                  Finish without hostname
                </Button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

// ─── Main Page ───────────────────────────────────────────────────────────────
export default function TunnelsPage() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [tunnels, setTunnels] = useState<Tunnel[]>([])
  const [allowedZones, setAllowedZones] = useState<Zone[]>([])
  const [usedSubdomains, setUsedSubdomains] = useState<UsedSubdomain[]>([])
  const [cfConfigured, setCfConfigured] = useState(false)
  const [maxTunnels, setMaxTunnels] = useState(2)
  const [loading, setLoading] = useState(true)
  const [showCreate, setShowCreate] = useState(false)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    if (status === 'unauthenticated') router.push('/auth/signin')
  }, [status, router])

  const loadAll = useCallback(async () => {
    setLoading(true)
    setError(null)
    try {
      const [tRes, dRes] = await Promise.all([
        fetch('/api/tunnels'),
        fetch('/api/tunnels/domains'),
      ])
      if (!tRes.ok && tRes.status !== 401) {
        const d = await tRes.json().catch(() => ({}))
        throw new Error(d.error || `Failed to load tunnels (${tRes.status})`)
      }
      if (tRes.ok) {
        const d = await tRes.json()
        setTunnels(d.tunnels || [])
      }
      if (dRes.ok) {
        const d = await dRes.json()
        setAllowedZones(d.allowedZones || [])
        setCfConfigured(d.cfConfigured || false)
        setMaxTunnels(d.maxTunnelsPerUser || 2)
        setUsedSubdomains(d.usedSubdomains || [])
      }
    } catch (e: any) {
      setError(e.message || 'Failed to load')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    if (status === 'authenticated') loadAll()
  }, [status, loadAll])

  const deleteTunnel = async (id: string, name: string) => {
    try {
      const res = await fetch(`/api/tunnels/${id}`, { method: 'DELETE' })
      const data = await res.json()
      if (res.ok) {
        toast.success(`Tunnel "${name}" deleted`)
        loadAll()
      } else {
        toast.error(data.error || 'Failed to delete tunnel')
      }
    } catch {
      toast.error('Network error while deleting tunnel')
    }
  }

  if (status === 'loading') return null

  const active = tunnels.filter(t => t.status !== 'DELETED')
  const atLimit = active.length >= maxTunnels

  return (
    <div className="min-h-screen bg-[#060611]">
      <Navbar />
      <div className="max-w-4xl mx-auto px-4 py-10">

        {/* Header with improved typography */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6 mb-12">
          <div className="flex items-center gap-5">
            <div className="w-14 h-14 rounded-[2rem] bg-gradient-to-br from-orange-500/20 to-amber-600/20 border border-orange-500/20 flex items-center justify-center shadow-[0_0_30px_rgba(249,115,22,0.1)]">
              <Globe className="w-7 h-7 text-orange-400" />
            </div>
            <div>
              <h1 className="text-3xl font-black text-white tracking-tighter sm:text-4xl">
                Zero Trust <span className="text-transparent bg-clip-text bg-gradient-to-r from-orange-400 to-amber-500">Tunnels</span>
              </h1>
              <p className="text-sm text-white/30 font-medium tracking-wide">Expose your local server securely via Cloudflare</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button onClick={loadAll} className="flex items-center gap-2 px-4 py-2.5 rounded-2xl bg-white/[0.03] border border-white/5 text-white/40 hover:text-white hover:bg-white/[0.08] transition-all group">
              <RefreshCw className="w-4 h-4 group-hover:rotate-180 transition-transform duration-500" />
              <span className="text-xs font-bold uppercase tracking-widest">Refresh</span>
            </button>
          </div>
        </div>

        {/* Stats with glow effects */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-10">
          {[
            { icon: Shield, label: 'Zero Trust Security', value: 'Cloudflare', color: 'text-blue-400', bg: 'bg-blue-500/5 border-blue-500/10 shadow-[0_0_15px_rgba(59,130,246,0.03)]' },
            { icon: Globe, label: 'Available Domains', value: String(allowedZones.length), color: 'text-orange-400', bg: 'bg-orange-500/5 border-orange-500/10 shadow-[0_0_15px_rgba(249,115,22,0.03)]' },
            { icon: Activity, label: 'Active Tunnels', value: `${active.length} / ${maxTunnels}`, color: atLimit ? 'text-red-400' : 'text-emerald-400', bg: atLimit ? 'bg-red-500/5 border-red-500/10 shadow-[0_0_15px_rgba(239,68,68,0.03)]' : 'bg-emerald-500/5 border-emerald-500/10 shadow-[0_0_15px_rgba(16,185,129,0.03)]' },
          ].map(({ icon: Icon, label, value, color, bg }) => (
            <div key={label} className={`${bg} border rounded-3xl p-5 transition-all duration-300 hover:translate-y-[-2px] hover:bg-white/[0.02]`}>
              <div className="flex items-center gap-3 mb-3">
                <div className={`p-2 rounded-xl ${bg.split(' ')[0]} border border-white/5`}>
                  <Icon className={`w-4 h-4 ${color}`} />
                </div>
                <p className="text-[11px] font-bold text-white/30 uppercase tracking-widest">{label}</p>
              </div>
              <p className="text-2xl font-black text-white tracking-tight">{value}</p>
            </div>
          ))}
        </div>

        {/* CF not configured warning */}
        {!cfConfigured && !loading && (
          <div className="flex items-start gap-3 p-4 rounded-2xl border border-amber-500/20 bg-amber-500/5 mb-6">
            <AlertTriangle className="w-4 h-4 text-amber-400 mt-0.5 flex-shrink-0" />
            <div>
              <p className="text-sm font-medium text-amber-300">Cloudflare not configured</p>
              <p className="text-xs text-amber-400/60 mt-0.5">Admin needs to set cfApiToken, cfAccountId, and allowed zones. Tunnels can't be created until this is done.</p>
            </div>
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="flex items-center gap-3 p-4 rounded-2xl border border-red-500/20 bg-red-500/5 mb-6">
            <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
            <p className="text-sm text-red-300 flex-1">{error}</p>
            <button onClick={loadAll} className="text-red-400 hover:text-red-300 text-xs underline">Retry</button>
          </div>
        )}

        {/* Loading */}
        {loading && (
          <div className="flex items-center justify-center py-24">
            <Loader2 className="w-6 h-6 animate-spin text-white/20" />
          </div>
        )}

        {!loading && (
          <>
            {/* Published Applications section */}
            <PublishedApps tunnels={tunnels} />

            {/* Create button / at limit with improved design */}
            {!showCreate && (
              <div className="mb-10">
                {atLimit ? (
                  <div className="flex items-center gap-3 p-5 rounded-3xl border border-white/[0.06] bg-white/[0.01] text-sm text-white/40">
                    <div className="w-8 h-8 rounded-xl bg-white/5 flex items-center justify-center">
                      <Activity className="w-4 h-4" />
                    </div>
                    <p>You've reached the limit of <span className="text-white font-bold">{maxTunnels} tunnels</span>. Delete one to create another.</p>
                  </div>
                ) : cfConfigured ? (
                  <Button onClick={() => setShowCreate(true)} size="lg"
                    className="group relative overflow-hidden bg-gradient-to-r from-orange-600 to-amber-600 hover:from-orange-500 hover:to-amber-500 text-white rounded-2xl text-sm font-bold gap-2 px-8 h-12 shadow-[0_10px_30px_rgba(249,115,22,0.2)] hover:shadow-[0_15px_40px_rgba(249,115,22,0.3)] transition-all duration-300">
                    <div className="absolute inset-0 bg-white/10 translate-y-full group-hover:translate-y-0 transition-transform duration-300" />
                    <Plus className="w-5 h-5 relative z-10" /> 
                    <span className="relative z-10 uppercase tracking-widest">Create New Tunnel</span>
                  </Button>
                ) : null}
              </div>
            )}

            {/* Create Wizard */}
            {showCreate && (
              <div className="mb-8">
                <CreateWizard
                  onCreated={() => { setShowCreate(false); loadAll() }}
                  onCancel={() => setShowCreate(false)}
                  allowedZones={allowedZones}
                  usedSubdomains={usedSubdomains}
                />
              </div>
            )}

            {/* Tunnel list */}
            {active.length > 0 && (
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <Server className="w-3.5 h-3.5 text-white/30" />
                  <h2 className="text-xs font-semibold text-white/40 uppercase tracking-wider">Your Tunnels ({active.length})</h2>
                </div>
                <div className="space-y-3">
                  {active.map(t => (
                    <TunnelCard
                      key={t.id}
                      tunnel={t}
                      allowedZones={allowedZones}
                      usedSubdomains={usedSubdomains}
                      onDelete={deleteTunnel}
                      onRefresh={loadAll}
                    />
                  ))}
                </div>
              </div>
            )}

            {/* Empty state */}
            {active.length === 0 && !showCreate && cfConfigured && (
              <div className="rounded-2xl border border-white/[0.06] bg-white/[0.015] p-16 text-center">
                <div className="w-14 h-14 rounded-2xl bg-orange-500/10 border border-orange-500/15 flex items-center justify-center mx-auto mb-4">
                  <Globe className="w-7 h-7 text-orange-400/60" />
                </div>
                <p className="text-white/40 text-sm mb-1 font-medium">No tunnels yet</p>
                <p className="text-white/20 text-xs mb-5">Create a tunnel to expose your server without opening firewall ports</p>
                <Button onClick={() => setShowCreate(true)}
                  className="bg-orange-600 hover:bg-orange-500 text-white rounded-xl text-sm gap-2">
                  <Plus className="w-4 h-4" /> Create your first tunnel
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}
