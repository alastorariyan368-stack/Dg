import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'

const SKIP_PATHS = [
  '/admin',
  '/auth',
  '/api/auth',
  '/api/maintenance',
  '/api/admin',
  '/_next',
  '/favicon.ico',
  '/maintenance',
  '/uploads'
]

const rateLimitMap = new Map<string, { count: number; resetTime: number }>()
const RATE_LIMIT_PAGE = 100
const RATE_LIMIT_API = 300
const RATE_WINDOW = 60_000

// Small in-memory cache for maintenance mode to reduce `/api/maintenance` calls.
let maintenanceCache: { value: boolean; until: number } = { value: false, until: 0 }

function checkRateLimit(ip: string, limit: number): boolean {
  const now = Date.now()
  const entry = rateLimitMap.get(ip)

  if (!entry || now > entry.resetTime) {
    rateLimitMap.set(ip, { count: 1, resetTime: now + RATE_WINDOW })
    return true
  }

  entry.count++
  if (entry.count > limit) return false

  return true
}

if (typeof setInterval !== 'undefined') {
  setInterval(() => {
    const now = Date.now()
    for (const [ip, entry] of rateLimitMap) {
      if (now > entry.resetTime) rateLimitMap.delete(ip)
    }
  }, 60_000)
}

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl

  // 🔥 1. STOP INTERNAL REQUEST LOOP
  if (request.headers.get('x-middleware-check')) {
    return NextResponse.next()
  }

  // Dev: avoid calling internal APIs from middleware.
  // During first compile/hot reload, `/api/maintenance` can take a very long time,
  // which causes noisy AbortError logs and slows down every request.
  if (process.env.NODE_ENV === 'development') {
    return NextResponse.next()
  }

  const ip =
    request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
    request.headers.get('x-real-ip') ||
    'unknown'

  const isApi = pathname.startsWith('/api/')
  const limit = isApi ? RATE_LIMIT_API : RATE_LIMIT_PAGE

  // Basic request size protection (helps prevent request-body DoS).
  // Skip for upload endpoints which need to handle large files
  const isUploadPath = pathname.includes('/upload') || pathname.includes('/api/upload')
  if (!isUploadPath && ['POST', 'PUT', 'PATCH', 'DELETE'].includes(request.method)) {
    const contentLength = request.headers.get('content-length')
    const maxBytes = isApi ? 2_000_000 : 1_000_000 // 2MB API / 1MB pages
    if (contentLength) {
      const asNum = Number(contentLength)
      if (Number.isFinite(asNum) && asNum > maxBytes) {
        return NextResponse.json({ error: 'Payload too large' }, { status: 413 })
      }
    }
  }

  if (!checkRateLimit(ip, limit)) {
    return NextResponse.json(
      { error: 'Too many requests. Please slow down.' },
      { status: 429, headers: { 'Retry-After': '60' } }
    )
  }

  if (SKIP_PATHS.some(p => pathname.startsWith(p))) {
    return NextResponse.next()
  }

  try {
    // 🔥 FIX: maintenance must follow admin DB flag (not a browser cookie).
    const now = Date.now()
    let maintenance = maintenanceCache.value

    if (now > maintenanceCache.until) {
      try {
        // Get the origin from request headers for better reliability
        const origin = request.headers.get('x-forwarded-proto')
          ? `${request.headers.get('x-forwarded-proto')}://${request.headers.get('x-forwarded-host') || request.headers.get('host')}`
          : request.nextUrl.origin

        const controller = new AbortController()
        // Dev builds can be slow on first compile; allow more time to avoid noisy AbortError logs.
        const timeoutMs = process.env.NODE_ENV === ('development' as string) ? 15000 : 5000
        const timeoutId = setTimeout(() => controller.abort(), timeoutMs)

        const maintenanceRes = await fetch(`${origin}/api/maintenance`, {
          headers: { 'x-middleware-check': '1' },
          cache: 'no-store',
          signal: controller.signal,
        }).finally(() => clearTimeout(timeoutId))

        if (maintenanceRes.ok) {
          try {
            const contentType = maintenanceRes.headers.get('content-type')
            if (contentType?.includes('application/json')) {
              const data = (await maintenanceRes.json()) as { maintenance?: boolean }
              maintenance = !!data.maintenance
            }
          } catch (parseErr) {
            // If JSON parsing fails, just skip and use cache
            console.debug('Failed to parse maintenance response:', parseErr)
            maintenance = false
          }
        }
      } catch (fetchErr) {
        // If fetch fails, just skip maintenance check and continue
        console.debug('Maintenance check failed:', fetchErr)
        maintenance = false
      }

      // Cache the DB-backed maintenance flag to avoid fetching on every request.
      maintenanceCache = { value: maintenance, until: now + 30_000 } // 30s cache
    }

    if (maintenance) {
      const sessionToken =
        request.cookies.get('next-auth.session-token')?.value ||
        request.cookies.get('__Secure-next-auth.session-token')?.value

      // Admin bypass for maintenance mode
      if (sessionToken) {
        try {
          const origin = request.headers.get('x-forwarded-proto')
            ? `${request.headers.get('x-forwarded-proto')}://${request.headers.get('x-forwarded-host') || request.headers.get('host')}`
            : request.nextUrl.origin
          const cookieHeader = request.headers.get('cookie') || ''

          const controller = new AbortController()
          const timeoutId = setTimeout(() => controller.abort(), 5000) // 5s timeout

          const sessionRes = await fetch(`${origin}/api/auth/session`, {
            headers: {
              Cookie: cookieHeader,
              'x-middleware-check': '1'
            },
            cache: 'no-store',
            signal: controller.signal,
          }).finally(() => clearTimeout(timeoutId))

          if (sessionRes.ok) {
            try {
              const contentType = sessionRes.headers.get('content-type')
              if (contentType?.includes('application/json')) {
                const session = await sessionRes.json()

                // Check if user is admin or super_admin
                const userRole = session?.user?.role
                if (userRole === 'ADMIN' || userRole === 'SUPER_ADMIN') {
                  // Admin can access everything, including admin pages
                  return NextResponse.next()
                }
              }
            } catch (parseErr) {
              console.debug('Failed to parse session response:', parseErr)
            }
          }
        } catch (err) {
          console.debug('Session check error during maintenance mode:', err)
        }
      }

      const url = request.nextUrl.clone()

      if (pathname !== '/maintenance') {
        url.pathname = '/maintenance'
        return NextResponse.redirect(url)
      }
    }
  } catch (err) {
    console.error('Middleware error:', err)
    // Don't fail the entire request due to middleware error - just continue
  }

  const response = NextResponse.next()

  // Security headers
  response.headers.set('X-Content-Type-Options', 'nosniff')
  response.headers.set('X-Frame-Options', 'DENY')
  response.headers.set('X-XSS-Protection', '1; mode=block')
  response.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin')

  // Performance headers - Cache Control
  if (pathname.startsWith('/api/') && request.method === 'GET') {
    // Cache API responses for 5 seconds to reduce database load
    if (pathname.match(/^\/api\/(announcements|categories|ads|analytics)\/?$/)) {
      response.headers.set('Cache-Control', 'public, max-age=300, s-maxage=300')
    } else if (pathname.includes('/api/ai/limits') || pathname.includes('/api/ai/')) {
      response.headers.set('Cache-Control', 'private, max-age=60, s-maxage=60')
    }
  }

  return response
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico|uploads/).*)'],
}