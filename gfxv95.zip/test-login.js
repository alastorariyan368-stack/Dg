const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

async function testLogin() {
  const db = new PrismaClient();
  try {
    // Get admin user
    const user = await db.user.findUnique({
      where: { email: 'kakmare.pa@gmail.com' }
    });
    
    console.log('Admin user found:', !!user);
    if (!user) {
      console.log('ERROR: Admin user not found!');
      process.exit(1);
    }
    
    console.log('Email:', user.email);
    console.log('Username:', user.username);
    console.log('Role:', user.role);
    console.log('Password stored:', user.password ? 'Yes' : 'No');
    
    if (!user.password) {
      console.log('ERROR: No password stored!');
      process.exit(1);
    }
    
    // Test password
    const testPassword = 'akash9x1';
    const isValid = await bcrypt.compare(testPassword, user.password);
    
    console.log('\nPassword test:');
    console.log('Testing password: akash9x1');
    console.log('Stored hash starts with:', user.password.substring(0, 10) + '...');
    console.log('Password matches:', isValid ? 'YES ✓' : 'NO ✗');
    
    if (!isValid) {
      console.log('\nERROR: Password does not match!');
      process.exit(1);
    }
    
    console.log('\n✅ Login credentials are valid');
  } catch (error) {
    console.error('Error:', error.message);
    process.exit(1);
  } finally {
    await db.$disconnect();
  }
}

testLogin();
