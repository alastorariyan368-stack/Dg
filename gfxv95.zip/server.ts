import { createServer, request as httpRequest } from 'http'
import { parse } from 'url'
import next from 'next'
import { Server as SocketIOServer } from 'socket.io'
import { PrismaClient } from '@prisma/client'
import { getToken } from 'next-auth/jwt'
import { IncomingMessage } from 'http'
import { readFile } from 'fs/promises'
import { join } from 'path'
import { existsSync } from 'fs'
import { setupDatabase } from './src/lib/setup'
import { ensureDatabaseReady, db as prisma } from './src/lib/db'
import { startBuiltinSmtpServer, stopBuiltinSmtpServer } from './src/lib/smtp-server'
import { autoSeedTempServices, startTempServicesCleanup } from './src/lib/temp-services-seed'
import { getRunningApps } from './src/lib/app-runner'

const dev = process.env.NODE_ENV !== 'production'
const hostname = '0.0.0.0'
const port = parseInt(process.env.PORT || '5000', 10)

// Auto-detect public URL for Replit/custom domain environments
const replitDomain = process.env.REPLIT_DEV_DOMAIN
const customDomain = process.env.CUSTOM_DOMAIN // e.g. store.akashyt.qzz.io
if (customDomain) {
  process.env.NEXTAUTH_URL = `https://${customDomain}`
  process.env.NEXT_PUBLIC_APP_URL = `https://${customDomain}`
} else if (replitDomain && (!process.env.NEXTAUTH_URL || process.env.NEXTAUTH_URL.includes('localhost'))) {
  process.env.NEXTAUTH_URL = `https://${replitDomain}`
  process.env.NEXT_PUBLIC_APP_URL = `https://${replitDomain}`
}

const app = next({ dev, hostname, port })
const handle = app.getRequestHandler()

interface AuthenticatedUser {
  id: string
  username: string
  role: string
}

const chatUsers: Map<string, { id: string; username: string }> = new Map()
// map from userId to socket.id for private messaging
const userSockets: Map<string, string> = new Map()

async function getAuthenticatedUser(req: IncomingMessage): Promise<AuthenticatedUser | null> {
  try {
    const token = await getToken({
      req: req as any,
      secret: process.env.NEXTAUTH_SECRET || process.env.SESSION_SECRET
    })
    
    if (!token?.sub) return null
    
    const user = await prisma.user.findUnique({
      where: { id: token.sub },
      select: { id: true, username: true, role: true }
    })
    
    return user
  } catch (error) {
    console.error('Auth error:', error)
    return null
  }
}

app.prepare().then(async () => {
  // Auto-setup database on first run
  // Ensure database connection is ready
  await ensureDatabaseReady()
  
  // Auto-setup database on first run (only runs schema/seed when needed)
  await setupDatabase()

  // ─── Built-in SMTP server for Temp Mail ──────────────────────────────
  const smtpPort = parseInt(process.env.SMTP_PORT || '25', 10)
  try {
    startBuiltinSmtpServer(smtpPort)
  } catch (e: any) {
    console.warn(`> [SMTP] Could not start on port ${smtpPort}: ${e.message}. Try SMTP_PORT=2525 if port 25 is blocked.`)
  }

  // ─── Auto-seed Temp Mail domains + Temp Number country configs ────────
  await autoSeedTempServices()
  startTempServicesCleanup()

  // ─── Lightweight request-level activity logger ───────────────────────
  // Captures every meaningful action across the site and persists it with
  // username + IP + path + method + status. Skips noise (static, polling).
  const LOG_SKIP_PREFIXES = [
    '/_next', '/favicon', '/uploads/', '/api/socket', '/api/maintenance',
    '/api/admin/logs',          // never log the log viewer itself
    '/api/notifications',       // notification polling spam
    '/api/messages/conversations',
    '/api/friends/list', '/api/friends/requests', '/api/users/search',
    '/api/auth/session', '/api/auth/_log', '/api/auth/csrf', '/api/auth/providers',
  ]
  function shouldLogRequest(pathname: string, method: string): boolean {
    if (LOG_SKIP_PREFIXES.some(p => pathname.startsWith(p))) return false
    // Always log auth callbacks (covers Discord/Google login redirects + IP)
    if (pathname.startsWith('/api/auth/callback') || pathname.startsWith('/api/auth/signin') || pathname.startsWith('/api/auth/signout')) return true
    // Log all write operations
    if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(method)) return true
    // Log notable page navigations
    if (method === 'GET' && (
      pathname === '/' ||
      pathname.startsWith('/admin') ||
      pathname.startsWith('/auth/') ||
      pathname.startsWith('/messages') ||
      pathname.startsWith('/profile') ||
      pathname.startsWith('/checkout') ||
      pathname.startsWith('/orders') ||
      pathname.startsWith('/ai-')
    )) return true
    return false
  }
  function cleanIp(raw: string | undefined): string | undefined {
    if (!raw) return undefined
    let ip = String(raw).trim()
    // Strip IPv6-mapped IPv4 prefix (::ffff:1.2.3.4 -> 1.2.3.4)
    if (ip.toLowerCase().startsWith('::ffff:')) ip = ip.slice(7)
    // Drop loopback / internal placeholders so we don't store them
    if (!ip || ip === '::1' || ip === '127.0.0.1' || ip === '0.0.0.0') return undefined
    return ip
  }
  function getReqIp(req: any): string | undefined {
    // Prefer headers set by trusted edge proxies (Cloudflare, Replit, Vercel) — these reflect the real client (user's phone) IP.
    const cf = req.headers['cf-connecting-ip']
    if (cf) { const c = cleanIp(String(cf)); if (c) return c }
    const tci = req.headers['true-client-ip']
    if (tci) { const c = cleanIp(String(tci)); if (c) return c }
    const xff = req.headers['x-forwarded-for']
    if (xff) {
      const first = String(xff).split(',')[0].trim()
      const c = cleanIp(first); if (c) return c
    }
    const xreal = req.headers['x-real-ip']
    if (xreal) { const c = cleanIp(String(xreal)); if (c) return c }
    // Do NOT fall back to req.socket.remoteAddress — that's the proxy/server IP, not the user's.
    return undefined
  }
  async function logRequest(req: any, res: any, pathname: string, method: string) {
    try {
      let userId: string | null = null
      let username: string | null = null
      try {
        const token = await getToken({ req, secret: process.env.NEXTAUTH_SECRET || process.env.SESSION_SECRET })
        if (token?.sub) {
          userId = token.sub
          username = (token.username as string) || (token.email as string) || null
        }
      } catch {}
      const ip = getReqIp(req)
      const ua = req.headers['user-agent'] || undefined
      const action = pathname.startsWith('/api/auth/callback') ? 'OAUTH_CALLBACK'
        : pathname.startsWith('/api/auth/signin') ? 'SIGNIN_ATTEMPT'
        : pathname.startsWith('/api/auth/signout') ? 'LOGOUT'
        : (method === 'GET' ? 'PAGE_VIEW' : `${method}_REQUEST`)
      await prisma.activityLog.create({
        data: {
          userId, username, action, details: null,
          ipAddress: ip, userAgent: typeof ua === 'string' ? ua.slice(0, 500) : null,
          path: pathname.slice(0, 500), method,
          status: typeof res.statusCode === 'number' ? res.statusCode : null,
        }
      })
    } catch {/* never block requests on logging */}
  }

  const httpServer = createServer(async (req, res) => {
    try {
      const parsedUrl = parse(req.url!, true)
      const pathname = parsedUrl.pathname || ''
      const method = (req.method || 'GET').toUpperCase()
      const willLog = shouldLogRequest(pathname, method)
      if (willLog) {
        res.on('finish', () => { logRequest(req, res, pathname, method).catch(() => {}) })
      }

      // 🩺 Health counters (used by /admin/health)
      try {
        const g: any = global as any
        if (!g.__healthCounters) g.__healthCounters = { bootedAt: Date.now(), requests: 0, requests1m: [], errors: 0, errors1m: [], threats: [], activeSockets: 0 }
        const hc = g.__healthCounters
        const isStatic = pathname.startsWith('/_next/') || pathname.startsWith('/uploads/') || pathname === '/favicon.ico'
        if (!isStatic) {
          hc.requests++
          hc.requests1m.push(Date.now())
          if (hc.requests1m.length > 5000) hc.requests1m.splice(0, hc.requests1m.length - 5000)
          res.on('finish', () => {
            if (res.statusCode >= 500) {
              hc.errors++
              hc.errors1m.push(Date.now())
            }
            // Heuristic threat detection
            const ip = (req.headers['x-forwarded-for'] as string)?.split(',')[0]?.trim() || (req.headers['x-real-ip'] as string) || (req.socket?.remoteAddress as string) || 'unknown'
            if (res.statusCode === 429) hc.threats.push({ at: Date.now(), ip, reason: 'Rate limit exceeded', path: pathname })
            else if (res.statusCode === 403) hc.threats.push({ at: Date.now(), ip, reason: 'Forbidden access attempt', path: pathname })
            else if (res.statusCode === 401 && method !== 'GET') hc.threats.push({ at: Date.now(), ip, reason: 'Unauthorized write attempt', path: pathname })
            else if (/\.(php|env|git|sql|bak|asp|jsp)$/i.test(pathname)) hc.threats.push({ at: Date.now(), ip, reason: 'Suspicious file probe', path: pathname })
            else if (/(union\s+select|<script|\.\.\/\.\.\/|wp-admin|phpmyadmin)/i.test(decodeURIComponent(pathname + (parsedUrl.search || '')))) hc.threats.push({ at: Date.now(), ip, reason: 'Injection / scan signature', path: pathname })
            if (hc.threats.length > 500) hc.threats.splice(0, hc.threats.length - 500)
          })
        }
      } catch {}

      // ── Reverse proxy for deployed apps (/deployed/:id/*)
      if (pathname.startsWith('/deployed/')) {
        const segments = pathname.split('/').filter(Boolean)
        const deployId = segments[1]
        if (deployId) {
          const apps = getRunningApps()
          const appInfo = apps.get(deployId)
          if (appInfo && appInfo.port) {
            const proxyPath = ('/' + segments.slice(2).join('/')) + (parsedUrl.search || '')
            const proxyReq = httpRequest({
              hostname: '127.0.0.1',
              port: appInfo.port,
              path: proxyPath || '/',
              method: req.method || 'GET',
              headers: { ...req.headers, host: `localhost:${appInfo.port}` },
            }, (proxyRes) => {
              res.writeHead(proxyRes.statusCode || 200, proxyRes.headers)
              proxyRes.pipe(res)
            })
            proxyReq.on('error', () => {
              if (!res.headersSent) {
                res.writeHead(502, { 'Content-Type': 'text/html' })
                res.end('<html><body style="background:#0f0f0f;color:#fff;font-family:system-ui;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0"><div style="text-align:center"><h2>App Error</h2><p style="color:#666">The deployed app encountered an error. Check the console logs.</p></div></body></html>')
              }
            })
            req.pipe(proxyReq)
            return
          }
        }
        res.writeHead(503, { 'Content-Type': 'text/html' })
        res.end('<html><body style="background:#0f0f0f;color:#fff;font-family:system-ui;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0"><div style="text-align:center"><h2 style="color:#ccc;margin-bottom:8px">App Not Running</h2><p style="color:#666;margin:0">Start the app from the AppDeploy page to access it here.</p><p style="margin-top:16px"><a href="/appdeploy" style="color:#7c3aed">Go to AppDeploy</a></p></div></body></html>')
        return
      }

      // Serve static files from uploads directory
      if (parsedUrl.pathname?.startsWith('/uploads/')) {
        // Check public/uploads/ first (Next.js convention), then fall back to uploads/
        const publicFilePath = join(process.cwd(), 'public', parsedUrl.pathname)
        const directFilePath = join(process.cwd(), parsedUrl.pathname)
        const filePath = existsSync(publicFilePath) ? publicFilePath : directFilePath
        if (existsSync(filePath)) {
          const fileBuffer = await readFile(filePath)
          const ext = filePath.split('.').pop()?.toLowerCase()
          const mimeTypes: Record<string, string> = {
            jpg: 'image/jpeg',
            jpeg: 'image/jpeg',
            png: 'image/png',
            gif: 'image/gif',
            webp: 'image/webp',
            jar: 'application/java-archive'
          }
          res.setHeader('Content-Type', mimeTypes[ext || ''] || 'application/octet-stream')
          res.setHeader('Cache-Control', 'public, max-age=3600')
          res.end(fileBuffer)
          return
        }
      }
      
      await handle(req, res, parsedUrl)
    } catch (err) {
      console.error('Error occurred handling', req.url, err)
      res.statusCode = 500
      res.end('internal server error')
    }
  })

  const io = new SocketIOServer(httpServer, {
    path: '/socket.io/',
    cors: {
      origin: true, // Allow all origins for dynamic domain support
      methods: ['GET', 'POST'],
      credentials: true
    },
    transports: ['websocket', 'polling'],
    allowEIO3: true,
    // Performance optimization
    pingInterval: 25000, // Send ping every 25s (default 25s)
    pingTimeout: 60000, // Wait 60s for pong before disconnecting
    maxHttpBufferSize: 1e5, // 100KB max buffer
    // Enable compression
    serveClient: false, // Don't serve client lib - use npm package instead
    // Better defaults for high-traffic
    maxConnections: 10000,
    upgradeTimeout: 10000,
  })

  const notificationNamespace = io.of('/notifications')

  // Simple chat on main namespace
  io.on('connection', async (socket) => {
    console.log('🔌 Client connected:', socket.id)
    let user: AuthenticatedUser | null = null

    const authData = (socket.handshake.auth as any)
    console.log('🔐 Auth data received:', authData)

    try {
      user = await getAuthenticatedUser(socket.request)
    } catch (error) {
      console.error('❌ Cookie auth error:', error)
    }

    if (!user && authData?.userId && !String(authData.userId).startsWith('guest_')) {
      try {
        const dbUser = await prisma.user.findUnique({
          where: { id: authData.userId },
          select: { id: true, username: true, role: true }
        })
        if (dbUser) {
          user = dbUser
        }
      } catch (error) {
        console.error('❌ DB lookup error:', error)
      }
    }

    // Guest fallback — public homepage chat works for visitors too
    let isGuest = false
    if (!user && authData?.guest) {
      const safeName = String(authData?.username || 'Guest').replace(/[^a-zA-Z0-9_]/g, '').slice(0, 24) || 'Guest'
      const safeId = String(authData?.userId || ('guest_' + socket.id)).slice(0, 64)
      user = { id: safeId, username: safeName, role: 'GUEST' } as any
      isGuest = true
    }

    if (user) {
      console.log('✅ User connected:', user.username, isGuest ? '(guest)' : '')
      chatUsers.set(socket.id, { id: user.id, username: user.username, guest: isGuest } as any)
      if (!isGuest) userSockets.set(user.id, socket.id)
      io.emit('onlineUsers', chatUsers.size)

      // Send recent public messages
      try {
        const messages = await prisma.chatMessage.findMany({
          where: { roomId: null, type: 'PUBLIC' },
          include: { user: { select: { username: true, id: true } } },
          orderBy: { createdAt: 'desc' },
          take: 50
        })
        socket.emit('chatMessages', messages.reverse().map(m => ({
          id: m.id,
          userId: m.user.id,
          username: m.user.username,
          message: m.content,
          timestamp: m.createdAt
        })))
      } catch (error) {
        console.error('❌ Error loading messages:', error)
      }
    } else {
      console.log('⚠️ Could not establish chat identity for:', socket.id)
    }

    socket.on('sendMessage', async (data: { text: string, mentions?: string[] }) => {
      console.log('💬 Received message from', socket.id, ':', data)
      // Throttle spam from a single socket instance.
      const now = Date.now()
      const store = (socket as any).data || ((socket as any).data = {})
      const bucketKey = 'publicSendMessage'
      const bucket = store[bucketKey] || { count: 0, resetTime: now + 10_000 }
      if (now > bucket.resetTime) {
        bucket.count = 0
        bucket.resetTime = now + 10_000
      }
      bucket.count += 1
      store[bucketKey] = bucket
      if (bucket.count > 8) {
        socket.emit('error', { message: 'Rate limit exceeded. Please slow down.' })
        return
      }

      const userData = chatUsers.get(socket.id) as any
      if (!userData) return
      if (!data?.text?.trim()) return

      try {
        const text = data.text.trim().slice(0, 1000)
        let savedMsg: any = null
        if (!userData.guest) {
          savedMsg = await prisma.chatMessage.create({
            data: { userId: userData.id, content: text, type: 'PUBLIC', roomId: null },
            include: { user: { select: { username: true } } }
          })
        }
        const msg = savedMsg || {
          id: 'g_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8),
          content: text,
          createdAt: new Date(),
          user: { username: userData.username },
        }

        const mentions = Array.isArray(data.mentions)
          ? data.mentions.map((m) => (typeof m === 'string' ? m.trim() : '')).filter(Boolean).slice(0, 5)
          : []

        // Send notifications to mentioned users
        if (mentions.length > 0) {
          const mentionedUsers = await prisma.user.findMany({
            where: { username: { in: mentions } },
            select: { id: true }
          })

          for (const mentionedUser of mentionedUsers) {
            try {
              if (mentionedUser && (global as any).sendNotification) {
                await (global as any).sendNotification(mentionedUser.id, {
                  title: '💬 You were mentioned in chat',
                  content: `${userData.username} mentioned you: "${data.text.slice(0, 50)}..."`,
                  type: 'USER_MENTIONED'
                })
              }
            } catch (mentionError) {
              console.error('Failed to send mention notification:', mentionError)
            }
          }
        }
        
        console.log('📣 Broadcasting message to all clients')
        io.emit('newMessage', {
          id: msg.id,
          username: msg.user.username,
          message: msg.content,
          timestamp: msg.createdAt,
          mentions
        })
      } catch (error) {
        console.error('❌ Failed to save message:', error)
      }
    })

    socket.on('disconnect', () => {
      chatUsers.delete(socket.id)
      io.emit('onlineUsers', chatUsers.size)
      console.log('Client disconnected:', socket.id)
    })
  })

  notificationNamespace.use(async (socket, next) => {
    try {
      let user: AuthenticatedUser | null = null
      user = await getAuthenticatedUser(socket.request)
      if (!user) {
        const authData = (socket.handshake.auth as any)
        if (authData?.userId) {
          const dbUser = await prisma.user.findUnique({
            where: { id: authData.userId },
            select: { id: true, username: true, role: true }
          })
          if (dbUser) user = dbUser
        }
      }
      if (user) {
        (socket as any).user = user
        next()
      } else {
        next(new Error('Authentication required'))
      }
    } catch (error) {
      next(new Error('Authentication failed'))
    }
  })

  notificationNamespace.on('connection', async (socket) => {
    const user = (socket as any).user as AuthenticatedUser
    
    if (!user) {
      socket.disconnect(true)
      return
    }

    console.log('Notification client connected:', socket.id, 'User:', user.username)

    userSockets.set(user.id, socket.id)
    socket.join(`user:${user.id}`)
    
    if (['ADMIN', 'SUPER_ADMIN', 'MODERATOR'].includes(user.role)) {
      socket.join('admins')
    }

    try {
      const notifications = await prisma.notification.findMany({
        where: { userId: user.id },
        orderBy: { createdAt: 'desc' },
        take: 50
      })
      socket.emit('notifications', notifications)
    } catch (error) {
      console.error('Error fetching notifications:', error)
    }

    socket.on('disconnect', () => {
      userSockets.delete(user.id)
      console.log('Notification client disconnected:', socket.id)
    })
  })

  // Private messaging namespace
  const messagesNamespace = io.of('/messages')

  messagesNamespace.use(async (socket, next) => {
    try {
      let user: AuthenticatedUser | null = null
      user = await getAuthenticatedUser(socket.request)
      if (!user) {
        const authData = (socket.handshake.auth as any)
        if (authData?.userId) {
          const dbUser = await prisma.user.findUnique({
            where: { id: authData.userId },
            select: { id: true, username: true, role: true }
          })
          if (dbUser) user = dbUser
        }
      }
      if (user) {
        (socket as any).user = user
        next()
      } else {
        next(new Error('Authentication required'))
      }
    } catch (error) {
      next(new Error('Authentication failed'))
    }
  })

  messagesNamespace.on('connection', async (socket) => {
    const user = (socket as any).user as AuthenticatedUser
    
    if (!user) {
      socket.disconnect(true)
      return
    }

    console.log('Messages client connected:', socket.id, 'User:', user.username)
    socket.join(`user:${user.id}`)

    socket.on('join', (data: { userId: string }) => {
      if (data?.userId === user.id) {
        socket.join(`user:${user.id}`)
        console.log(`👤 User ${user.username} joined room: user:${user.id}`)
      }
    })

    socket.on('sendMessage', async (data: { receiverId: string; content: string; vpsOrderInfo?: any }) => {
      try {
        const now = Date.now()
        const store = (socket as any).data || ((socket as any).data = {})
        const bucketKey = 'privateSendMessage'
        const bucket = store[bucketKey] || { count: 0, resetTime: now + 10_000 }
        if (now > bucket.resetTime) {
          bucket.count = 0
          bucket.resetTime = now + 10_000
        }
        bucket.count += 1
        store[bucketKey] = bucket
        if (bucket.count > 10) { // Slightly more relaxed limit
          socket.emit('error', { message: 'Rate limit exceeded.' })
          return
        }

        if (!data?.receiverId || !data?.content?.trim()) return
        
        const message = await prisma.privateMessage.create({
          data: {
            senderId: user.id,
            receiverId: data.receiverId,
            content: data.content.trim().slice(0, 2000),
            vpsOrderInfo: data.vpsOrderInfo || null
          },
          include: {
            sender: { select: { id: true, username: true, avatar: true } },
            receiver: { select: { id: true, username: true, avatar: true } }
          }
        })

        // Standardize event names: always emit 'newPrivateMessage'
        messagesNamespace.to(`user:${user.id}`).emit('newPrivateMessage', message)
        messagesNamespace.to(`user:${data.receiverId}`).emit('newPrivateMessage', message)

        // Also notify via notification namespace
        notificationNamespace.to(`user:${data.receiverId}`).emit('notification', {
          id: message.id,
          title: 'New Message',
          content: `${user.username}: ${message.content.slice(0, 50)}`,
          type: 'NEW_MESSAGE',
          createdAt: new Date(),
          isRead: false
        })

        console.log('✅ Private message sent:', message.id)
      } catch (error) {
        console.error('❌ Failed to send private message:', error)
      }
    })

    // Typing indicator
    socket.on('typing', (data: { receiverId: string; isTyping: boolean }) => {
      if (!data?.receiverId) return
      messagesNamespace.to(`user:${data.receiverId}`).emit('peerTyping', {
        userId: user.id, username: user.username, isTyping: !!data.isTyping,
      })
    })

    socket.on('groupTyping', (data: { groupId: string; memberIds: string[]; isTyping: boolean }) => {
      if (!data?.groupId || !Array.isArray(data?.memberIds)) return
      for (const uid of data.memberIds) {
        if (uid === user.id) continue
        messagesNamespace.to(`user:${uid}`).emit('groupPeerTyping', {
          groupId: data.groupId, userId: user.id, username: user.username, isTyping: !!data.isTyping,
        })
      }
    })

    // ─── WebRTC signaling for 1:1 and group calls ────────────────────────
    // Caller pings the recipient(s) that a call is incoming. The peer should fetch the call by id, answer/reject,
    // then exchange SDP + ICE via the events below.
    socket.on('call:invite', (data: { callId: string; targetUserIds: string[]; type: 'AUDIO' | 'VIDEO'; groupId?: string; from: { id: string; username: string; avatar?: string } }) => {
      if (!data?.callId || !Array.isArray(data?.targetUserIds)) return
      for (const uid of data.targetUserIds) {
        if (uid === user.id) continue
        const payload = {
          callId: data.callId,
          type: data.type,
          groupId: data.groupId || null,
          from: { id: user.id, username: user.username, avatar: data.from?.avatar || null },
        }
        // Deliver via messages namespace (when callee is on messages page)
        messagesNamespace.to(`user:${uid}`).emit('call:incoming', payload)
        // ALSO deliver via notification namespace — every authenticated user is
        // reliably connected here (session-cookie auth), so this is the safe fallback.
        notificationNamespace.to(`user:${uid}`).emit('call:incoming', payload)
      }
    })

    socket.on('call:cancel', (data: { callId: string; targetUserIds: string[] }) => {
      if (!data?.callId || !Array.isArray(data?.targetUserIds)) return
      for (const uid of data.targetUserIds) {
        messagesNamespace.to(`user:${uid}`).emit('call:cancelled', { callId: data.callId })
        notificationNamespace.to(`user:${uid}`).emit('call:cancelled', { callId: data.callId })
      }
    })

    socket.on('call:accept', (data: { callId: string; targetUserId: string }) => {
      if (!data?.callId || !data?.targetUserId) return
      messagesNamespace.to(`user:${data.targetUserId}`).emit('call:accepted', {
        callId: data.callId, from: { id: user.id, username: user.username },
      })
    })

    socket.on('call:reject', (data: { callId: string; targetUserId: string }) => {
      if (!data?.callId || !data?.targetUserId) return
      messagesNamespace.to(`user:${data.targetUserId}`).emit('call:rejected', { callId: data.callId, from: user.id })
    })

    socket.on('call:end', (data: { callId: string; targetUserIds: string[] }) => {
      if (!data?.callId || !Array.isArray(data?.targetUserIds)) return
      for (const uid of data.targetUserIds) {
        messagesNamespace.to(`user:${uid}`).emit('call:ended', { callId: data.callId, from: user.id })
      }
    })

    // SDP / ICE relay (peer-to-peer signaling)
    // webrtc:ready — callee signals its CallModal is mounted + media is ready.
    // Caller waits for this before creating the offer, eliminating the race condition
    // where the offer arrives before the callee's listeners are registered.
    socket.on('webrtc:ready', (data: { callId: string; to: string }) => {
      if (!data?.to) return
      messagesNamespace.to(`user:${data.to}`).emit('webrtc:ready', { callId: data.callId, from: user.id })
    })

    socket.on('webrtc:offer', (data: { callId: string; to: string; sdp: any }) => {
      if (!data?.to || !data?.sdp) return
      messagesNamespace.to(`user:${data.to}`).emit('webrtc:offer', { callId: data.callId, from: user.id, sdp: data.sdp })
    })

    socket.on('webrtc:answer', (data: { callId: string; to: string; sdp: any }) => {
      if (!data?.to || !data?.sdp) return
      messagesNamespace.to(`user:${data.to}`).emit('webrtc:answer', { callId: data.callId, from: user.id, sdp: data.sdp })
    })

    socket.on('webrtc:ice', (data: { callId: string; to: string; candidate: any }) => {
      if (!data?.to || !data?.candidate) return
      messagesNamespace.to(`user:${data.to}`).emit('webrtc:ice', { callId: data.callId, from: user.id, candidate: data.candidate })
    })

    socket.on('markAsRead', async (data: { senderId: string }) => {
      // Throttle read receipts spam.
      const now = Date.now()
      const store = (socket as any).data || ((socket as any).data = {})
      const bucketKey = 'privateMarkAsRead'
      const bucket = store[bucketKey] || { count: 0, resetTime: now + 10_000 }
      if (now > bucket.resetTime) {
        bucket.count = 0
        bucket.resetTime = now + 10_000
      }
      bucket.count += 1
      store[bucketKey] = bucket
      if (bucket.count > 3) return

      try {
        await prisma.privateMessage.updateMany({
          where: {
            AND: [
              { receiverId: user.id },
              { senderId: data.senderId }
            ]
          },
          data: { isRead: true }
        })
      } catch (error) {
        console.error('Error marking as read:', error)
      }
    })

    socket.on('disconnect', () => {
      console.log('Messages client disconnected:', socket.id)
    })
  })

  const sendNotification = async (userId: string, notification: {
    title: string
    content: string
    type: string
    itemId?: string
  }) => {
    try {
      const savedNotification = await prisma.notification.create({
        data: {
          userId,
          title: notification.title,
          content: notification.content,
          type: notification.type as any,
          itemId: notification.itemId
        }
      })
      notificationNamespace.to(`user:${userId}`).emit('notification', savedNotification)
    } catch (error) {
      console.error('Error sending notification:', error)
    }
  }

  const broadcastToAdmins = (notification: any) => {
    notificationNamespace.to('admins').emit('adminNotification', notification)
  }

  ;(global as any).sendNotification = sendNotification
  ;(global as any).broadcastToAdmins = broadcastToAdmins
  ;(global as any).io = io
  ;(global as any).messagesIo = messagesNamespace

  httpServer.listen(port, hostname, () => {
    console.log(`> Server ready on http://${hostname}:${port}`)
    console.log(`> Real-time chat and notifications enabled (authenticated)`)
  })

  // ─── GfxV1 AI Background Brain Trainer ───────────────────────────────
  // Runs every 10 minutes while the server is alive.
  // Promotes high-usage "learned" entries to higher confidence,
  // demotes stale auto-learned entries, and keeps the brain healthy.
  const startAiBrainTrainer = () => {
    const INTERVAL = 10 * 60 * 1000 // 10 minutes
    const AUTO_TRAIN_INTERVAL = 30 * 60 * 1000 // 30 minutes

    const runTraining = async () => {
      try {
        // Boost confidence of frequently-used learned entries
        await prisma.$executeRawUnsafe(`
          UPDATE gfx_ai_brain
          SET confidence = LEAST(1.0, confidence + 0.05), "updatedAt" = NOW()
          WHERE source IN ('learned','api') AND "usageCount" >= 5 AND confidence < 0.95
        `)
        // Demote very stale low-use auto-learned entries (older than 7 days, used < 2 times)
        await prisma.$executeRawUnsafe(`
          UPDATE gfx_ai_brain
          SET "isActive" = false
          WHERE source = 'learned' AND "usageCount" < 2
            AND "createdAt" < NOW() - INTERVAL '7 days'
            AND confidence < 0.5
        `)
        // Trim excess auto-learned entries (keep top 2000 by usage)
        await prisma.$executeRawUnsafe(`
          DELETE FROM gfx_ai_brain
          WHERE id IN (
            SELECT id FROM gfx_ai_brain
            WHERE source = 'learned'
            ORDER BY "usageCount" ASC, "createdAt" ASC
            OFFSET 2000
          )
        `)
        // Trim old memory rows (keep last 5000 per user, delete excess)
        await prisma.$executeRawUnsafe(`
          DELETE FROM gfx_ai_memory
          WHERE "createdAt" < NOW() - INTERVAL '30 days'
        `)
        console.log('> [GfxV1 Brain] Background training cycle complete')
      } catch (e: any) {
        console.warn('> [GfxV1 Brain] Training error (non-fatal):', e?.message)
      }
    }

    // ── API Auto-Training ─────────────────────────────────────────────────
    // Uses configured AI API keys to automatically generate new training data
    // for the GfxV1 brain on a 30-minute cycle
    const runApiAutoTraining = async () => {
      try {
        // Load site settings for API keys
        const settings = await prisma.siteSettings.findFirst()
        if (!settings) return

        const tc = (settings.themeConfig as any) || {}
        const ai = tc.ai || {}
        const apiKeys = {
          geminiApiKey: ai.geminiApiKey || process.env.GEMINI_API_KEY,
          openaiApiKey: ai.openaiApiKey || process.env.OPENAI_API_KEY,
          anthropicApiKey: ai.anthropicApiKey || process.env.ANTHROPIC_API_KEY,
          deepseekApiKey: ai.deepseekApiKey || process.env.DEEPSEEK_API_KEY,
          mistralApiKey: ai.mistralApiKey || process.env.MISTRAL_API_KEY,
          groqApiKey: ai.groqApiKey || process.env.GROQ_API_KEY,
          xaiApiKey: ai.xaiApiKey || process.env.XAI_API_KEY,
          togetherApiKey: ai.togetherApiKey || process.env.TOGETHER_API_KEY,
          cohereApiKey: ai.cohereApiKey || process.env.COHERE_API_KEY,
        }

        const hasAnyKey = Object.values(apiKeys).some(v => v)
        if (!hasAnyKey) return // No API keys configured, skip

        // Check how many brain entries we already have from API
        const existing = await prisma.$queryRawUnsafe<any[]>(
          `SELECT COUNT(*) as count FROM gfx_ai_brain WHERE source = 'api'`
        )
        const apiCount = parseInt(existing?.[0]?.count || '0')
        if (apiCount >= 500) return // Brain has plenty of API entries

        // Import the AI engine helper
        const { callExternalApi } = await import('./src/lib/gfx-ai-engine')

        // Topic categories to auto-generate training for
        const topicCategories = [
          { category: 'gfxstore', topics: [
            'What is GfxStore and what can I buy here?',
            'How do I create an account on GfxStore?',
            'How do I upload and sell my digital assets on GfxStore?',
            'What payment methods does GfxStore accept?',
            'How does the wallet system work in GfxStore?',
          ]},
          { category: 'ai_tools', topics: [
            'What AI tools are available on GfxStore?',
            'How can I use AI to generate graphics?',
            'Explain how the GFXV1 AI assistant works',
            'What is AI image generation and how does it work?',
            'How do I use AI voice text-to-speech?',
          ]},
          { category: 'digital_assets', topics: [
            'What types of digital assets can I find on GfxStore?',
            'How do I download assets I purchased?',
            'What is the difference between free and premium assets?',
            'How do I get a refund on GfxStore?',
            'Can I use GfxStore assets for commercial projects?',
          ]},
          { category: 'earning', topics: [
            'How can I earn money on GfxStore?',
            'What is the AFK earning feature?',
            'How do task rewards work on GfxStore?',
            'What is the GfxStore affiliate program?',
            'How do I withdraw my earnings from GfxStore?',
          ]},
        ]

        const systemPrompt = `You are a helpful assistant for GfxStore, a digital marketplace for AI tools, scripts, graphics, mods, and digital assets. Provide accurate, helpful, friendly answers about GfxStore features and digital assets. Keep answers concise (2-4 sentences).`

        let trainedCount = 0
        for (const { category, topics } of topicCategories) {
          for (const question of topics) {
            try {
              const answer = await callExternalApi(apiKeys, systemPrompt, [{ role: 'user', content: question }], 300)
              if (answer && answer.length > 20) {
                // Check if we already have a very similar entry
                const similar = await prisma.$queryRawUnsafe<any[]>(
                  `SELECT id FROM gfx_ai_brain WHERE question ILIKE $1 LIMIT 1`,
                  '%' + question.slice(0, 30) + '%'
                )
                if (similar.length === 0) {
                  const keywords = question.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/).filter(w => w.length > 2).slice(0, 15).join(' ')
                  await prisma.$executeRawUnsafe(
                    `INSERT INTO gfx_ai_brain (id, category, question, answer, keywords, confidence, source, "usageCount", "isActive", "createdAt", "updatedAt")
                     VALUES (gen_random_uuid(), $1, $2, $3, $4, 0.85, 'api', 0, true, NOW(), NOW())
                     ON CONFLICT DO NOTHING`,
                    category, question.slice(0, 500), answer.slice(0, 3000), keywords
                  )
                  trainedCount++
                }
              }
            } catch {}
          }
          if (trainedCount > 0) break // Train one category at a time to avoid API overuse
        }

        if (trainedCount > 0) {
          console.log(`> [GfxV1 Brain] Auto-trained ${trainedCount} new entries from API`)
        }
      } catch (e: any) {
        console.warn('> [GfxV1 Brain] API auto-training error (non-fatal):', e?.message)
      }
    }

    // First maintenance run after 2 min, then every 10 min
    setTimeout(() => {
      runTraining()
      setInterval(runTraining, INTERVAL)
    }, 2 * 60 * 1000)

    // First API auto-train run after 5 min, then every 30 min
    setTimeout(() => {
      runApiAutoTraining()
      setInterval(runApiAutoTraining, AUTO_TRAIN_INTERVAL)
    }, 5 * 60 * 1000)

    console.log('> [GfxV1 Brain] Background trainer scheduled (maintenance every 10min, API auto-train every 30min)')
  }

  startAiBrainTrainer()
})

process.on('SIGTERM', async () => {
  stopBuiltinSmtpServer()
  await prisma.$disconnect()
  process.exit(0)
})
