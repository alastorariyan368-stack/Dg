Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "cmd /c ""C:\Program Files\nodejs\npx.cmd"" tsx server.ts", 0, False
