import { signIn } from 'next-auth/react'

async function testSignIn() {
  console.log('Testing signIn...');
  
  const result = await signIn('credentials', {
    email: 'kakmare.pa@gmail.com',
    password: 'akash9x1',
    redirect: false
  });
  
  console.log('Result:', result);
  
  if (result?.error) {
    console.log('Error:', result.error);
  } else if (result?.ok) {
    console.log('Success! Logged in');
  }
}

testSignIn();
