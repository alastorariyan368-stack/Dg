# GfxStore

## Latest additions (Apr 26, 2026 — Admin LOGIN config + real-time activity logging)
- **Admin LOGIN Config section** (`/admin/api-keys`): new card lets admin paste Discord + Google OAuth client ID/secret with a master enable toggle. The sign-in page automatically picks them up — no restart needed (new dynamic NextAuth route handler builds providers per request via `getAuthOptions()` reading from DB+env).
- **Schema**: SiteSettings gained `discordClientId`, `discordClientSecret`, `googleClientId`, `googleClientSecret`, `oauthEnabled`. Settings GET masks secrets with `****`; PATCH ignores masked placeholder values.
- **Real-time activity logs**: admin Logs page auto-refresh now defaults to ON at 2-second polling. A global request logger in `server.ts` writes every meaningful action (auth callbacks, all POST/PATCH/PUT/DELETE, key page navigations) to ActivityLog with userId, username, IP, user-agent, path, method, status — captures Discord/Google OAuth callback IPs as well as credential login IPs (the latter logged inside `authorize()`).
- **Friends tab**: "Find Friends" header (was "People You May Know") with live count badge; the user list now always renders even when no users match (shows "No users found" instead of hiding) — search and "Add" buttons unchanged.

## Latest additions (Apr 26, 2026 — Discord/Google OAuth, Friends tab overhaul, Activity logging, Email fix)

- **Discord + Google OAuth**: Added Discord and Google social login to `src/lib/auth.ts` using NextAuth providers (conditionally activated via `DISCORD_CLIENT_ID/SECRET`, `GOOGLE_CLIENT_ID/SECRET` env vars). New `Account` and `VerificationToken` Prisma models added and migrated. Sign-in page now shows Discord/Google buttons. OAuth users get auto-created accounts with generated usernames.
- **Messages Friends tab overhaul** (`/messages`): Friends tab now shows (1) pending received friend requests with Accept/Decline buttons at top, (2) "People You May Know" section listing ALL users (no longer requires search), (3) confirmed friends list. User search updated to support empty queries and case-insensitive search.
- **Activity Logging system**: Created `src/lib/log-activity.ts` helper. Registration route logs `REGISTER` events with IP. NextAuth signIn callback logs `LOGIN` (credentials) and `OAUTH_LOGIN/REGISTER` events. Admin logs API now allows both `ADMIN` and `SUPER_ADMIN` roles.
- **Email settings integration**: `src/lib/email.ts` now reads from `smtpConfig.provider === 'gmail'` (the Admin → Email Settings page) in addition to the direct gmailUser/gmailAppPassword fields. Admin can configure Gmail via the existing email-settings page.
- **User search API** (`/api/users/search`): now shows all users when no query is provided (removed 2-character minimum), uses case-insensitive search.
- **Prisma schema**: Added `Account`, `VerificationToken` models for OAuth. Made `password` field optional on `User` (OAuth users don't have passwords). Migrated to DB.

## Latest additions (Apr 26, 2026 — OTP verification, Gmail API, Logs, Video providers, Code upload)

- **OTP Email Verification**: Registration sends a 6-digit OTP if `emailVerificationEnabled` is ON in Admin → API Keys → Email section. Uses the existing email providers (Resend, Gmail, SMTP). API: `POST /api/auth/register` (returns `requiresVerification: true`), `POST /api/auth/verify-otp`, `DELETE /api/auth/verify-otp` (resend).
- **Gmail API Config**: Admin → API Keys now has a full Gmail section — Gmail address, App Password (simpler), OR full OAuth2 (Client ID / Secret / Refresh Token). `src/lib/email.ts` tries: Resend → Gmail OAuth2 → Gmail App Password → SMTP. Added `otpEmailHtml()` template.
- **Admin → Activity Logs** (`/admin/logs`): live-refreshing log table (auto-refresh every 5s), search by action/username/IP/path, pagination, method/status color-coding, IP address display. Linked from admin sidebar as "Activity Logs" (System section).
- **Code upload** (`/code/upload`): new **Cover / Profile Image** upload section at the top of the form. `POST /api/code` now accepts and saves `coverImage` field.
- **Video Generation** (`/api/ai/generate/video`): expanded to support **ModelsLab** (free tier, Zeroscope/AnimateDiff), **Stability AI** (SVD image-to-video), and 6 more **HuggingFace** free models (damo-vilab text-to-video, Zeroscope v2, CogVideoX-5B, LTX-Video, I2VGen-XL, AnimateDiff). HuggingFace function improved with retry on model loading (503). Admin API keys now shows ModelsLab key input.
- **Messages media**: existing upload endpoint (`/api/messages/upload`) already supports images, audio (voice recordings), video, and files — all working via Socket.io + MediaRecorder.
- **Prisma schema**: added `gmailAppPassword`, `modelsLabApiKey` to `SiteSettings`. Schema pushed to DB.
- **Admin Settings API** (`/api/admin/settings`): now handles all new Gmail/ModelsLab/emailVerification fields.



The ultimate digital marketplace for every kind of digital content (graphics, plugins, mods, texture packs, maps, videos, reels, apps, code, and more) — built with Next.js 15, Prisma, and NextAuth.

## Latest additions (Apr 26, 2026 — Messenger + AI Studio expansion)
- **Messenger-style /messages**: brand-new full-screen UI with sidebar tabs (Chats / Groups / Friends), unread badges, online dots, photo/video/file/voice attachments (50 MB cap, stored in `/public/uploads/chat/`), in-app voice recorder (MediaRecorder + WebM/Opus), typing indicators, group create modal, friend search & add.
- **WebRTC audio/video calls**: 1:1 voice and video calls with mute / camera-off / hangup controls, ringing toast for incoming calls, automatic call-log message inserted into the conversation, ICE/SDP relayed through the `/messages` Socket.io namespace (Google STUN). Group calls UI placeholder ("coming soon" toast). New `CallSession` model + `/api/calls` for create / accept / reject / end.
- **Group system**: `Group`, `GroupMember`, `GroupMessage` Prisma models with admin/owner roles, member management, group messaging endpoints (`/api/groups`, `/api/groups/[id]/members`, `/api/groups/[id]/messages`).
- **Sign In / Sign Up buttons** in navbar fixed (now `<Button asChild><Link>` so clicks consistently route).
- **Home page AI Studio section**: large gradient cards linking to YouTube Gen, AI Video Gen, and Messenger directly under the hero.
- **Admin → AI API Keys**: every provider now shows a colored **FREE / FREE + PAID / PAID** badge. Added new free providers: **Pollinations (no key needed)**, **Mistral (free tier)**, **Cohere (free trial)**, **Cloudflare Workers AI (free Llama)**. Schema columns added: `mistralApiKey`, `cohereApiKey`, `cloudflareAiApiKey`, `pollinationsApiKey`.
- **Schema**: extended `PrivateMessage` with `kind`, `mediaUrl`, `mediaName`, `mimeType`, `durationSec`, `thumbnailUrl`, `callId`, `editedAt`, `deletedAt` for rich messaging.

## Recent additions (Apr 2026)
- **YouTube Gen** (`/youtube-gen`) — give one prompt, get a click-worthy YouTube **title, description, tags, hashtags, chapters, short description, and a custom 16:9 thumbnail**. Auto-falls back across every configured chat AI provider; thumbnail uses the existing image-gen pipeline. EN + Bengali output. API: `POST /api/ai/generate/youtube`.
- **AI Video Gen** (`/ai-video`) — text-to-video with multi-provider fallback. Tries the admin-configured default video model first, then FAL.ai → Replicate → Luma → MiniMax → Hugging Face (free fallback). Aspect ratios 16:9 / 9:16 / 1:1. Polls async jobs, downloads MP4 to `/public/uploads/ai-video/`. API: `POST /api/ai/generate/video`.
- **Admin → AI API Keys**: new **Video providers** section (FAL.ai, Replicate, Runway, Luma, Kling, MiniMax, Hugging Face) + **Default Video Model** selector with grouped options (FAL.ai, Replicate, direct provider APIs, free fallback).
- **SiteSettings** schema: added `falApiKey`, `runwayApiKey`, `lumaApiKey`, `klingApiKey`, `minimaxApiKey`, `videoModel` columns.
- **Shared AI helper** (`src/lib/ai-text.ts`): `callAiText()` runs chat completion with automatic cross-provider fallback (used by YouTube Gen, can be reused by future text features). Includes `extractJson()` for robust parsing of model JSON output.
- **Navbar 3-dot dropdown**: added an **AI Studio** group with AI Assistant, AI Image Gen, YouTube Gen, AI Video Gen.

## Previous fixes (Apr 2026)
- Navbar 3-dot user dropdown: added "Tasks" and "My Tasks" entries.
- AI chat (`/api/ai-chat`) system prompt rewritten so the assistant identifies **Akash Devx** as the founder/owner of GfxStore and the builder of the AI; it still hides the underlying model.
- AI chat page (`/ai-chat`): mobile layout pinned (`fixed inset-0` + `100dvh` + `overflow-hidden`) so the chat no longer scrolls past the viewport on phones.
- Admin announcement toast in `/admin → Settings → Basic` now reads the correct response field (`notifiedUsers`) and reports email blast status.
- Admin Settings page: fixed pre-existing JSX bug — the **Basic Settings** tab was missing its `{activeTab === 'basic' && (` wrapper, which made `/admin` and `/admin/api-keys` return 500.
- Admin AI tab now links to the full multi-provider key panel at `/admin/api-keys`.
- Replaced "Minecraft"-specific copy with generic marketplace wording in video upload page, sample seed, and AI SEO route.

## Project Overview

GfxStore is a feature-rich digital marketplace with:
- Digital item marketplace (browse, buy, sell)
- Reels / short video feed (TikTok-style)
- Videos section
- Apps, Code, Freebies marketplace
- Premium memberships
- Wallet system (deposit/withdraw)
- AI chat and AI generation tools
- Leaderboard for top sellers and items
- VPS hosting listings
- Team & collaboration tools
- Badge system & rewards

## Tech Stack

- **Framework**: Next.js 15 (App Router)
- **Database**: PostgreSQL via Prisma ORM
- **Auth**: NextAuth.js (credentials-based JWT)
- **UI**: Tailwind CSS v4 + shadcn/ui (Radix UI)
- **Styling**: Dark theme (`#0a0a12` base, violet/cyan gradients)
- **State**: React hooks + Zustand
- **Realtime**: Socket.io
- **File Uploads**: AWS S3

## Running the App

```bash
npm run dev        # Development (port 3000)
npm run build      # Production build
npm run start      # Production server
```

## Environment Setup

Requires `.env` with:
- `DATABASE_URL` - PostgreSQL connection string
- `NEXTAUTH_SECRET` / `SESSION_SECRET` - Auth secret
- `NEXTAUTH_URL` - App URL
- AWS S3 credentials for file uploads

After fresh install, run:
```bash
npx prisma generate   # Generate Prisma client
npx prisma db push    # Push schema to DB
```

## Key Pages

| Route | Description |
|-------|-------------|
| `/` | Homepage |
| `/browse` | Browse all items |
| `/reels` | TikTok-style reel feed |
| `/videos` | Video library |
| `/leaderboard` | Top sellers & items |
| `/profile` | User profile |
| `/dashboard` | Seller dashboard |
| `/upload` | Upload items/content |
| `/wallet` | Wallet & transactions |
| `/settings` | Account settings |
| `/admin` | Admin panel (admin only) |

## Architecture Notes

- Session avatar stored in `session.user.image` (NextAuth standard)
- Navbar reads avatar from `session.user.image || (session.user as any).avatar`
- Reels page uses `h-screen overflow-hidden flex-col` to prevent body scroll
- Leaderboard at `/leaderboard` with top sellers & top items tabs

## Recent Updates (2026-04-25)

- Homepage cleaned: removed "Latest Upload" hero & "Discover something new" slides; shrunk Reels section
- AI Image Generation: new fallback chain (OpenAI → NanoBanana → Imagen → Together FLUX → Stability → Replicate → HuggingFace → Pollinations → Pixabay/Unsplash); admin keys page split into Chat / Image / Email sections
- AI Chat: hardened identity prompt — branded as "GFX AI Beta" / "GFX Model"; never names underlying providers
- "Minecraft marketplace" branding swept to "Ultimate marketplace" / generic digital wording
- Announcements: top banner + email blast with Resend→SMTP fallback; new `Announcement` model and notifications
- Public homepage chat now supports guest mode (sessionStorage id, broadcast-only, no DB persistence)
- New **Tasks / Earn** system (gigclickers-style):
  - `EarnTask` & `EarnTaskSubmission` Prisma models
  - Creator locks `rewardAmount × totalSlots` from wallet on task creation
  - Workers submit proof (text/image), owner reviews on `/tasks/[id]`
  - On approval: reward transferred to worker, task auto-closes when full
  - Pages: `/tasks` (browse + create dialog), `/tasks/[id]` (detail + review), `/your-tasks` (creator inbox)
  - APIs: `/api/tasks`, `/api/tasks/[id]`, `/api/tasks/[id]/submit`, `/api/tasks/[id]/review`
  - Navbar: added "Earn" link

## Recent Fixes (2026-04-23)

- Fixed profile picture not showing in navbar (was reading wrong session field)
- Enhanced 3-dot dropdown: added Deposit, Withdraw, Wallet, Upload Item, My Orders, Messages, Leaderboard
- Enhanced mobile side drawer: same extra options organized by sections
- Created Leaderboard page at `/leaderboard` with podium, seller rankings, item rankings
- Fixed Reels fullscreen issue: `h-screen overflow-hidden` prevents body scroll
- Fixed Reels video height: uses `100svh - 64px` for proper full-height display
- Fixed workflow: now runs `npm run dev` on port 3000
- Added Prisma generate to setup flow

## 2026-04-26: Bengali user multi-part fix
- Activity Log IP detection now uses cf-connecting-ip → true-client-ip → x-forwarded-for[0] → x-real-ip (strips ::ffff:, rejects loopback) — captures user's REAL phone IP, not server IP
- Added 5 new free worldwide video providers: Cloudflare Workers AI, DeepInfra (LTX-Video), Segmind (LTX-Video), Together (Mochi-1), A4F.co (aggregator with Wan 2.1 / Luma Ray 2 / Veo)
- Image gen: pro 8K cinematic prompt enhancement for purpose=thumbnail/banner/avatar/image; Pollinations switched to flux model with enhance=true
- Email: Gmail App Password is now FIRST priority (Resend is last); every email is logged to db.sentEmail (admin Email Inbox sees all, even failures get [FAILED] prefix)
- Discord/Gmail OAuth: providers loaded dynamically from SiteSettings + env (already done)
- Messages page: shows up to 200 site users (was 30)
- Admin Email Inbox sees every outbound email
- Earn Tasks: schema extended with deadline, videoTutorialUrl, maxPerUser, requiresLink, difficulty, estimatedMinutes, bannerImage, proofImages[], proofUrl, proofExtra
- Removed @@unique([taskId, workerId]) so users can submit up to maxPerUser times per task
- Task creation Dialog: now includes deadline picker, est minutes, difficulty select, max-per-user, video tutorial URL, banner image upload, requires-link toggle
- Task submission UI: file-upload screenshots (multi, with preview & delete), proof URL field, proof image URL, larger proof text — much friendlier mobile workflow
- Home page AI Studio: 6 tiles total (added AI Image Gen, AI Chat, Earn Tasks)
- Admin API Keys page: added DeepInfra, Segmind, A4F.co, Cloudflare-AI-as-video entries

## 2026-04-26: Bengali user — chat, deposit, mirror, providers fix
- **Deposit modal fix**: Navbar now passes `isOpen` + `onSuccess` props to DepositModal — previously dialog never opened (mobile + desktop). Deposit button works on home and navbar everywhere.
- **Admin Clear Old Logs fix**: `/api/admin/logs` POST no longer requires JSON body (was throwing 500). Added `?days=N` and `?all=1` query params. UI now has two buttons: **Clear Old (30d)** and **Clear All** with confirm dialogs and a `<deleted N>` toast message.
- **Video call mirror fix**: local self-view in `call-modal.tsx` now uses `[transform:scaleX(-1)]` so it acts like a mirror (left/right matches what the user expects). Remote video stays unmirrored.
- **Private message friendship requirement removed**: text/photo/voice/file/CALL DMs now work between any two users (with a self-DM and block-list guard). This unblocks chat, voice notes, photo and call functionality reported as broken.
- **Many new AI providers added** to `/admin/api-keys` (with schema fields + GET masking + PATCH save):
  - **Chat**: Perplexity, Fireworks, AI21, NVIDIA NIM, SambaNova, Novita
  - **Image**: Black Forest Labs (FLUX direct), Ideogram, Recraft V3, Leonardo.AI, getimg.ai
  - **Video**: Pika Labs, Vidu, Hedra, Hotshot, LTX Studio (Lightricks)
  - **Voice / Audio**: ElevenLabs, Deepgram, AssemblyAI (new section in admin UI)

## 2026-04-26 (continued): AI Voice / TTS feature
- New page `/ai-voice` — text-to-speech studio with 5000-char prompt, provider selector (auto / ElevenLabs / Deepgram / OpenAI / Pollinations), voice picker for each provider, sample-script button, audio player, MP3 download, attempt-log display
- New API `/api/ai/generate/voice` — POST {text, voiceId, deepgramVoice, openaiVoice}; tries ElevenLabs (eleven_multilingual_v2) → Deepgram Aura (12 voices) → OpenAI TTS (tts-1, 6 voices) → Pollinations free fallback (no key needed). Saves output to `/public/uploads/ai-voice/{uuid}.mp3` and returns audioUrl + provider + attempts log.
- Added "AI Voice / TTS" tile to home page AI Studio (amber/orange gradient)
- Added "AI Voice (TTS)" item to navbar AI Studio dropdown (Mic icon)

## Recent additions (Apr 27, 2026)

### Support Ticket System (`/tickets`, `/admin/tickets`)
- Models: `Ticket`, `TicketMessage` (with auto-incrementing `ticketNumber`).
- User flow: create at `/tickets/new` → chat at `/tickets/[id]` with text/image/file/voice attachments.
- Admin flow: `/admin/tickets` list + per-ticket panel with status/priority/category controls.
- Live updates over Socket.io room `ticket:<id>`.
- Email notifications via `sendMail`: admins on new ticket and user reply; user on admin reply and on closure.

### Admin "CHECK-HEALTH" page (`/admin/health`)
- API: `/api/admin/health` returns CPU%, memory, disk (df -k), system & process uptime, request/error counters, threat list, active socket count, DB row counts.
- Counters maintained in `global.__healthCounters` populated by the HTTP handler in `server.ts` (request count + status-code based threat heuristics).
- Page auto-refreshes every 5s.

### Messaging fixes
- `src/app/messages/page.tsx` `sendText` & `sendAttachment`: optimistic UI insert (no longer reliant only on socket).
- `src/app/api/calls/route.ts` POST: emits `call:incoming` socket event to receiver (or every group member); friendship requirement removed.

### Group member management
- `DELETE /api/groups/[groupId]/members/[userId]` — kick/leave with system message + socket events.
- `PATCH …` — owner-only role change (ADMIN/MEMBER).

### Mobile menu
- AI Voice + Support Tickets added to `SECONDARY_LINKS` in `src/components/navbar.tsx`.
